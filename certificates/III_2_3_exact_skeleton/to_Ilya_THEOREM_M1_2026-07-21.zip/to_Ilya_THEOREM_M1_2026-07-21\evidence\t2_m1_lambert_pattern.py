# t2_m1_lambert_pattern.py — G-M1 first pattern-check: the lambda-side Lambert route.
# New campaign folder T2_M1_weight_transfer_2026-07-19; session 2026-07-19 (late).
#
# The ledger's claim to test: "uniform measure in lambda = 1/x IS Lambert 1,3,5,7
# directly — first pattern-check is cheap." Sharpened here before testing:
#   G_N(w) = sum_{n<=N} 1/(w - x_n) = N/w + (1/w) sum_{n<=N} x_n/(w - x_n)
# — ALL N-dependence of the uniform-N system is isolated in the single divergent
# moment m_0 = N; every higher moment converges to the EXACT zeta-rationals
#   m_k = (2^{2k}-1) zeta(2k) / pi^{2k}   (the SAME rationals as (F5)'s row-sum
# identity), and these are the Taylor coefficients of tan(sqrt(l))/(2 sqrt(l)) —
# Lambert's 1,3,5,7 continued fraction. Structural predictions tested below:
#   (H1) head identities: alpha_1 = m_1(N)/N, beta_1^2 = m_2(N)/N - (m_1(N)/N)^2.
#   (H2) the DEEP BLOCK converges to the x^2-WEIGHTED system (second Christoffel
#        transform of uniform = ONE FORWARD Christoffel step from the solved
#        companion), NOT to the shifted companion itself — i.e. the weight transfer
#        can run in the STABLE direction, bypassing the |r_i| ~ 1.15 inverse
#        telescope of P1_string_bessel section 2.
# Anchors kept exact (sympy): the moment/tan identity and the CF-contraction
# dictionary (Lambert a-sequence -> companion x-side Jacobi closed form).
import numpy as np
import mpmath as mp
import sympy as sp

mp.mp.dps = 30

print("=== (M1) EXACT: uniform x-moments = tan-series = zeta-rationals (Lambert bridge) ===")
lam = sp.symbols('lam')
ser = sp.series(sp.tan(sp.sqrt(lam)) / (2 * sp.sqrt(lam)), lam, 0, 9).removeO()
ok = True
for k in range(1, 9):
    m_tan = sp.nsimplify(ser.coeff(lam, k - 1))
    m_zeta = sp.Rational((2 ** (2 * k) - 1)) * sp.zeta(2 * k) / sp.pi ** (2 * k)
    m_zeta = sp.simplify(m_zeta)          # zeta(2k) = rational * pi^(2k) -> rational
    ok &= sp.simplify(m_tan - m_zeta) == 0
    if k <= 4:
        print(f"  m_{k} = {m_tan}  (= (2^{2*k}-1) zeta({2*k})/pi^{2*k})")
print(f"  identity m_k = [lam^(k-1)] tan(sqrt(lam))/(2 sqrt(lam)), k <= 8: "
      f"{'EXACT — all agree' if ok else 'FAILED'}")

print("=== (M2) EXACT: Lambert CF contraction = EVEN block; the ODD block is the x^2 system ===")
# Squaring the symmetric y-side Lambert J (off-diags b_k = 1/sqrt((2k-1)(2k+1))) splits
# into two closed-form x-side systems:
#   EVEN block (= companion-x, the pushforward of mu_L under y -> x = y^2):
#     alpha^E_1 = b_1^2 = 1/3;  alpha^E_j = b_{2j-2}^2 + b_{2j-1}^2 (j >= 2);
#     beta^E_j = b_{2j-1} b_{2j}.
#   ODD block (= x-weighted companion-x = x^2-weighted UNIFORM):
#     alpha^O_j = b_{2j-1}^2 + b_{2j}^2;  beta^O_j = b_{2j} b_{2j+1}
#     = 1/((4j-3)(4j-1)) + 1/((4j-1)(4j+1));  1/((4j+1) sqrt((4j-1)(4j+3))).
# The lambda-side Lambert S-fraction contraction must equal the EVEN block:
a = {k + 1: sp.Rational(1, (2 * k - 1) * (2 * k + 1)) for k in range(1, 22)}
b2 = {k: sp.Rational(1, (2 * k - 1) * (2 * k + 1)) for k in range(1, 22)}   # b_k^2
ok2 = True
for j in range(1, 9):
    al_cf = a[2] if j == 1 else a[2 * j - 1] + a[2 * j]
    al_even = b2[1] if j == 1 else b2[2 * j - 2] + b2[2 * j - 1]
    ok2 &= sp.simplify(al_cf - al_even) == 0
    ok2 &= sp.simplify(a[2 * j] * a[2 * j + 1] - b2[2 * j - 1] * b2[2 * j]) == 0
print(f"  CF-contraction == EVEN (companion-x) block, j <= 8: "
      f"{'EXACT — all agree' if ok2 else 'FAILED'}")
print("  EVEN: alpha^E_1 = 1/3, alpha^E_2 = 2/21 = 0.095238...  |  ODD: alpha^O_1 = 2/5,"
      " alpha^O_2 = 14/315 = 0.044444... — the two blocks are distinct")

print("=== (M3) the renormalized-transform identity (all N-dependence in m_0 = N) ===")
for N, wv in [(50, 0.7), (200, -0.3), (400, 1.9)]:
    z = (np.arange(1, N + 1) - 0.5) * np.pi
    x = 1.0 / z ** 2
    lhs = np.sum(1.0 / (wv - x))
    rhs = N / wv + (1.0 / wv) * np.sum(x / (wv - x))
    print(f"  N = {N}, w = {wv}: |G_N - [N/w + (1/w) sum x/(w-x)]| = {abs(lhs-rhs):.2e}")

def lanczos_w(x, wts, m):
    """weighted Lanczos with full reorthogonalization (float64)."""
    v = np.sqrt(wts / np.sum(wts))
    al, be, Vs = [], [], [v]
    w = x * v
    a0 = v @ w; al.append(a0); w = w - a0 * v
    for j in range(1, m):
        b = np.linalg.norm(w)
        if b < 1e-14: break
        be.append(b)
        vn = w / b
        for u in Vs: vn = vn - (u @ vn) * u
        vn /= np.linalg.norm(vn)
        Vs.append(vn)
        w = x * vn - b * Vs[-2]
        aj = vn @ w; al.append(aj); w = w - aj * vn
    return np.array(al), np.array(be)

print("=== (M4) THE PATTERN-CHECK: uniform-N = head(m_0=N) + ODD-Lambert block, 1/N rate ===")
# ODD-block closed form (the claimed x^2-weighted / deep-block limit):
alO = np.array([1.0 / ((4 * j - 3) * (4 * j - 1)) + 1.0 / ((4 * j - 1) * (4 * j + 1))
                for j in range(1, 26)])
beO = np.array([1.0 / ((4 * j + 1) * np.sqrt((4 * j - 1.0) * (4 * j + 3))) for j in range(1, 26)])
alE1 = 1.0 / 3.0                                   # EVEN-block alpha_1 (distinctness witness)
# validate the ODD closed form against the x^2-weighted atoms directly (M = 20000 trunc):
Mbig = 20000
zb = (np.arange(1, Mbig + 1) - 0.5) * np.pi
xb = 1.0 / zb ** 2
al2, be2 = lanczos_w(xb, xb ** 2, 26)
v_o = max(np.max(np.abs(al2[:12] - alO[:12]) / alO[:12]),
          np.max(np.abs(be2[:12] - beO[:12]) / beO[:12]))
print(f"  ODD closed form vs x^2-weighted Lanczos (M = 20000, j <= 12): max rel dev = {v_o:.1e}"
      f"   [truncation floor — the closed form IS the x^2 system]")
DEVS = {}
for N in [200, 400, 800]:
    z = (np.arange(1, N + 1) - 0.5) * np.pi
    x = 1.0 / z ** 2
    alU, beU = lanczos_w(x, np.ones(N), 26)
    m1 = np.sum(x); m2 = np.sum(x ** 2)
    h1 = abs(alU[0] - m1 / N)
    h2 = abs(beU[0] ** 2 - (m2 / N - (m1 / N) ** 2))
    JJ = 10
    deva = np.abs(alU[1:JJ + 1] - alO[:JJ]) / alO[:JJ]
    devb = np.abs(beU[1:JJ + 1] - beO[:JJ]) / beO[:JJ]
    DEVS[N] = (deva, devb)
    print(f"  N = {N}: head ids |da1| = {h1:.1e}, |db1^2| = {h2:.1e};"
          f"  block(j<=10) rel dev vs ODD block: al {np.max(deva):.3e}, be {np.max(devb):.3e}"
          f"   [vs EVEN alpha_1 = 1/3: {abs(alU[1]-alE1)/alE1:.2f} — distinct, as it must be]")
print("  1/N law: dev(200)/dev(400) = %.3f, dev(400)/dev(800) = %.3f   [2.0 = clean 1/N]"
      % (np.max(DEVS[200][0]) / np.max(DEVS[400][0]), np.max(DEVS[400][0]) / np.max(DEVS[800][0])))
print("  j-profile of the deviation at N = 800 (alpha):",
      " ".join(f"j{j+2}:{DEVS[800][0][j]:.1e}" for j in range(0, 10, 2)))

print("=== (M5) the head-block coupling and the N-law ===")
for N in [200, 400, 800]:
    z = (np.arange(1, N + 1) - 0.5) * np.pi
    x = 1.0 / z ** 2
    alU, beU = lanczos_w(x, np.ones(N), 26)
    print(f"  N = {N}: alpha_1 = {alU[0]:.6e} (= m1/N, -> 0);  beta_1 = {beU[0]:.6e};"
          f"  alpha_2 = {alU[1]:.8f};  beta_2 = {beU[1]:.8f}")
print(f"  ODD-block targets: alpha^O_1 = 2/5 = 0.4 exactly (= m3/m2);"
      f"  beta^O_1 = 1/(5 sqrt(21)) = {1/(5*np.sqrt(21)):.8f}")
print(f"  head law: beta_1(N) = sqrt(m2/N)(1+o(1)) = 0.40825/sqrt(N) — check:"
      f" 0.40825/sqrt(800) = {0.40825/np.sqrt(800):.6f}")
print("done.")
