# t2_m1_stageA_arrowhead.py — Stage A of the M1 campaign: the bordered-perturbation
# structure made EXACT, and the redistribution term identified (task item 1b).
# Session 3 of the campaign, 2026-07-19.
#
# Structure (derived before running, verified below): in atom space R^N with the
# UNIT-weight inner product, the uniform system's Krylov/degree filtration is spanned
# in order by the frame
#     F = [ e0 | V2[:, 0], V2[:, 1], ... ],   e0 = 1/sqrt(N),
# where V2 = the Lanczos basis of the ODD (w = x^2) system: V2[n, j] =
# x_n p^O_j(x_n)/sqrt(m2) — because span{1, x*P_{j-1}} = P_j degree-by-degree.
# Hence EXACTLY (finite N, no asymptotics):
#     J(uniform) = tri( Q^T diag(x) Q ),  Q = ordered orthonormalization of F,
# i.e. an explicit transform of [head row + J^ODD] driven by the arrowhead Gram
#     G = I + (e0-couplings),   g_j = <e0, V2_j> = (column mean of V2) * sqrt(N)^0...
# g_j = (1/sqrt(N)) sum_n V2[n, j]. The Stage-B "O(0.7) redistribution" must then BE
# the cumulative g-profile (e0 e0^T expressed in the ODD frame) — item 1b's projector
# statement. Everything below is measured; the lemma statement follows the data.
import numpy as np

def lanczos_full(x, wts, m):
    v = np.sqrt(wts / np.sum(wts))
    al, be, Vs = [], [], [v]
    w = x * v
    a0 = v @ w; al.append(a0); w = w - a0 * v
    for j in range(1, m):
        b = np.linalg.norm(w)
        if b < 1e-14: break
        be.append(b)
        vn = w / b
        for u in Vs: vn = vn - (u @ vn) * u
        vn /= np.linalg.norm(vn)
        Vs.append(vn)
        w = x * vn - b * Vs[-2]
        aj = vn @ w; al.append(aj); w = w - aj * vn
    return np.array(al), np.array(be), np.column_stack(Vs)

print("=== (A1) THE EXACT IDENTITY: J(uniform) from the arrowhead frame over J^ODD ===")
for N in [100, 200, 400]:
    z = (np.arange(1, N + 1) - 0.5) * np.pi
    x = 1.0 / z ** 2
    J = 40
    alU, beU, VU = lanczos_full(x, np.ones(N), J + 1)
    al2, be2, V2 = lanczos_full(x, x ** 2, J + 1)
    # frame: e0 then the V2 columns; ordered Gram-Schmidt = QR with sign fix
    F = np.column_stack([np.ones(N) / np.sqrt(N), V2[:, :J]])
    Qm, R = np.linalg.qr(F)
    s = np.sign(np.diag(R)); Qm = Qm * s        # enforce GS orientation
    T = Qm.T @ (x[:, None] * Qm)
    alF = np.diag(T)[:J]; beF = np.diag(T, 1)[:J - 1]
    dev = max(np.max(np.abs(alF - alU[:J])), np.max(np.abs(beF - beU[:J - 1])))
    off = np.max(np.abs(T - np.diag(np.diag(T)) - np.diag(np.diag(T, 1), 1)
                        - np.diag(np.diag(T, -1), -1))[:J - 2, :J - 2])
    print(f"  N = {N}: max|J(frame) - J(Lanczos)| = {dev:.2e};  non-tridiagonal leak "
          f"= {off:.2e}   [machine zero = the identity is EXACT]")

print("=== (A2) the coupling profile g_j (item 1b: the redistribution term identified) ===")
for N in [200, 400, 800]:
    z = (np.arange(1, N + 1) - 0.5) * np.pi
    x = 1.0 / z ** 2
    _, _, V2 = lanczos_full(x, x ** 2, min(N - 2, 160) + 1)
    g = V2.T @ (np.ones(N) / np.sqrt(N))
    cum = np.cumsum(g ** 2)
    j50 = int(np.searchsorted(cum, 0.50 * cum[-1])) + 1
    j90 = int(np.searchsorted(cum, 0.90 * cum[-1])) + 1
    print(f"  N = {N}: sum g^2 (j <= {len(g)-1}) = {cum[-1]:.4f} (Bessel <= 1);"
          f"  g_0..g_5 = " + " ".join(f"{v:+.4f}" for v in g[:6]))
    print(f"           mass: 50% by j = {j50}, 90% by j = {j90};"
          f"  |g_j| at j = 20/40/80: {abs(g[20]):.2e}/{abs(g[40]):.2e}/"
          f"{abs(g[80]) if len(g) > 80 else float('nan'):.2e}")
# decay law of |g_j|
N = 800
z = (np.arange(1, N + 1) - 0.5) * np.pi
x = 1.0 / z ** 2
_, _, V2 = lanczos_full(x, x ** 2, 161)
g = V2.T @ (np.ones(N) / np.sqrt(N))
jj = np.arange(4, 120)
gv = np.abs(g[jj]); sel = gv > 0
A = np.column_stack([np.ones(sel.sum()), np.log(jj[sel])])
co, *_ = np.linalg.lstsq(A, np.log(gv[sel]), rcond=None)
print(f"  decay law (N = 800, j = 4..119): |g_j| ~ C j^(-s), s = {-co[1]:.2f}"
      f"  (C = {np.exp(co[0]):.3f})")

print("=== (A3) J(N)-breakdown: where does the 1/N flatness fail? ===")
z = (np.arange(1, 20001) - 0.5) * np.pi
xb = 1.0 / z[:20000] ** 2
alR, beR, _ = lanczos_full(xb, xb ** 2, 170)     # deep-truncation ODD reference
for N in [200, 400]:
    zc = (np.arange(1, N + 1) - 0.5) * np.pi
    x = 1.0 / zc ** 2
    JM = min(N - 4, 160)
    alU, beU, _ = lanczos_full(x, np.ones(N), JM + 1)
    devs = np.abs(alU[1:JM] - alR[:JM - 1]) / np.abs(alR[:JM - 1])
    line = []
    for j in [4, 8, 16, 32, 64, 96, 128]:
        if j < JM - 1:
            line.append(f"j={j}: {devs[j - 1]:.1e}")
    print(f"  N = {N}: rel dev alpha_(j+1) vs ODD-ref:  " + "   ".join(line))
print("  [flat plateau = the 1/N regime; the rise marks J(N) — gates the lemma range]")
print("done.")
