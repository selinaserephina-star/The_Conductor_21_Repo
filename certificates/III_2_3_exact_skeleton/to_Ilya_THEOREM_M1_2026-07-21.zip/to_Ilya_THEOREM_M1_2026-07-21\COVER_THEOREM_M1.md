# To Ilya — THEOREM-M1: the weight transfer solved (G-M1 + G-M3 closed; the telescope is dead)

**Merkabit · Selina + Claude · 2026-07-21 (a ten-session campaign, folder
`T2_M1_weight_transfer_2026-07-19`, complete record in `evidence/`). Not RH/GRH.**

**Lineage:** follows `to_Ilya_CAUSTIC_THEOREM_2026-07-19` (SHA 284d21b5…9326b7),
`to_Ilya_T2a_CERTIFICATE_2026-07-21` + its khat addendum (SHAs 60410732… /
9a92a6e7…), and the Q2-audit package (SHA 930b3315…). All prior packages immutable.

## The theorem (one breath)

The uniform string system is EXACTLY a one-row bordering of the closed-form
odd-Lambert block: J_N(uniform) = tri(QᵀXQ) over [e₀ | V₂] (proven, two lines,
machine-verified 3.3e−16), with the whole Gram–Schmidt collapsing to an explicit
two-term recursion because Xe₀ = √(m₂/N)·w₀. The couplings have the PROVEN closed
form g_j ≈ (−1)^j√((4j+3)/2N), from the identity

    **Σ_{n≥1} (−1)^{n+1} j_{2j+1}((n−½)π) = (−1)^j / 2   (every j ≥ 0)**

— Poisson representation + your string's own sine basis read at the free endpoint
(P_{2j+1}(1) = 1); the finite-N deviation is exactly k(k+1)/(2π²N)(1+o(1)). The
deviation law, the truncation lemma (with proven crude constants and 6.5e5 stable
headroom), the sharp horizon 3.2√N, the verbatim production transfer, and the
head-suppressed structure of V are parts (V)–(VIII). Full statement with per-part
grades: `evidence/M1_THEOREM_note_2026-07-21.md`; the three write-ups:
`M1_glemma_stepA_…`, `M1_glemma_stepB_…`, `M1_truncation_GS_stability_…`.

## What this closes on the menu

- **G-M1 (weight transfer): CLOSED.** The cancellation-laden inverse telescope
  (|r_i| ≈ 1.15) from the K1K2 package §2 is BYPASSED — the transfer runs in the
  stable forward direction. The caustic theorem's constants transfer to the
  uniform normalization at the κ-level (matched rows 0.9–2.6%, caustic clean).
- **G-M3 (finite-section truncation): PROVEN** (unified tail-measure-removal lemma;
  rates exact: ODD 1/(3π⁴N³), companion 2/(π²N) — the shape of the 0.33k/2M drift
  you have in the packages). This also answers your audit's Task-1 residue: the
  finite sections converge to the canonical completions at explicit rates.
- **For G4** (the decision that is yours): the arrowhead identity is
  measure-agnostic (machine zero on production, both μ_D and μ_F); V = J(μ_F) −
  J(μ_D) is HEAD-SUPPRESSED (head 5–9% of scale, V₁₁ = (m₁^F−m₁^D)/N exact; deep
  block = shifted ODD-difference + 15–30% corrections, all exact via the downdate
  algebra). Recommendation on the table: build the V-limit on the ODD-difference
  principal term, carrying the escaping head as an explicit correction.

## The gem, separately

The identity above is, we think, to your taste: a Dini-type spherical-Bessel
evaluation through the string's Sturm–Liouville basis, with the alternation minted
in one sign line ((−i)^{2j+1}·i = (−1)^j) and the endpoint convergence carried by
the reflection to a period-4 odd-harmonic series. Steps written out and
line-verified (sympy-exact anchors; finite-N assembly identity at 1.1e−14).

## Honest scope

Parts (I)–(VI): proven/exact (grades itemized in the theorem note). Part (VII):
production structure at machine zero; production CONSTANTS are float64 — the ball
run with the T2a machinery upgrades them to certificate grade when wanted (optional;
~an hour). Part (VIII): measured with exact-formula control. Ten sessions, seven
numerical traps caught by the verify-before-use discipline along the way — the
forensic record is in `evidence/RESULTS.md`.

*SHA seal in `to_Ilya_THEOREM_M1_2026-07-21.zip.sha256.txt`; per-file manifest in
`SHA256SUMS.txt`.*
