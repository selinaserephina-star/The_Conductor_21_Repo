# t2_m1_truncation_lemma.py — session 7: the UNIFIED TRUNCATION LEMMA (item c = G-M3)
# and the closed-form cross-check of the deviation identity. 2026-07-21.
#
# THE LEMMA (tail-measure removal, one mechanism, two rates):
#   mu_N = mu_inf - tau_N with tau_N >= 0 supported in [0, x_{N+1}]. For fixed j, the
#   Jacobi data of mu_N vs mu_inf perturb by
#       |Delta a_j| + |Delta b_j|  <=  C_GS(j) * ||tau_N|| * B_j^2,
#   B_j = max_{i <= j+1} sup_{[0, x_{N+1}]} |p_i|  (edge values, GEOMETRIC growth),
#   C_GS(j) = the fixed-j Gram-Schmidt stability constant (explicit, O(j)-ish).
#   Rates: ODD system   ||tau|| = sum_{n>N} x_n^4-weights = sum z^-4 ~ 1/(3 pi^4 N^3);
#          companion    ||tau|| = sum_{n>N} 2 x_n = 2 sum z^-2 ~ 2/(pi^2 N)
#   => ODD truncation ~ N^-3 (matches the measured 7.7e-10 at M = 20000);
#      companion drift ~ k-growth/N (the SHAPE of the measured 0.33 k/2M law).
# Numerics below: (T1) tail masses exact; (T2) edge-value growth B_j (geometric, rate
# measured); (T3) ODD truncation deviation vs the lemma scale at two truncations;
# (T4) closed-form deviation identity: plug the g-lemma closed form into the Stage-A
# deviation identity and compare to the MEASURED uniform-vs-ODD deviations.
import numpy as np
import mpmath as mp

mp.mp.dps = 40

def lanczos_w(x, wts, m):
    v = np.sqrt(wts / np.sum(wts))
    al, be, Vs = [], [], [v]
    w = x * v
    a0 = v @ w; al.append(a0); w = w - a0 * v
    for j in range(1, m):
        b = np.linalg.norm(w)
        if b < 1e-14: break
        be.append(b)
        vn = w / b
        for u in Vs: vn = vn - (u @ vn) * u
        vn /= np.linalg.norm(vn)
        Vs.append(vn)
        w = x * vn - b * Vs[-2]
        aj = vn @ w; al.append(aj); w = w - aj * vn
    return np.array(al), np.array(be)

alO = lambda j: 1.0 / ((4 * j - 3) * (4 * j - 1)) + 1.0 / ((4 * j - 1) * (4 * j + 1))
beO = lambda j: 1.0 / ((4 * j + 1) * np.sqrt((4 * j - 1.0) * (4 * j + 3)))

print("=== (T1) tail masses (exact scales of the lemma) ===")
for N in [200, 800, 20000]:
    z = (np.arange(N + 1, N + 400001) - 0.5) * np.pi
    t_odd = np.sum(1.0 / z ** 4)          # ODD weights x^2 = z^-4
    t_comp = np.sum(2.0 / z ** 2)         # companion weights 2x = 2 z^-2
    print(f"  N = {N:6d}: ||tau_ODD|| = {t_odd:.3e} (~1/(3 pi^4 N^3) = "
          f"{1/(3*np.pi**4*N**3):.3e});  ||tau_comp|| = {t_comp:.3e}"
          f" (~2/(pi^2 N) = {2/(np.pi**2*N):.3e})")

print("=== (T2) edge-value growth B_j: |p^O_j(0)| from the closed-form recurrence ===")
# p_{j+1}(0) = (-a_j p_j(0) - b_{j-1} p_{j-1}(0)) / b_j   (mp, closed-form a, b)
p0 = [mp.mpf(1)]
a0v = mp.mpf(2) / 5                       # alpha^O_1 = 2/5
b = [mp.mpf(1) / ((4 * j + 1) * mp.sqrt(mp.mpf((4 * j - 1) * (4 * j + 3)))) for j in range(1, 130)]
a = [mp.mpf(1) / ((4 * j - 3) * (4 * j - 1)) + mp.mpf(1) / ((4 * j - 1) * (4 * j + 1))
     for j in range(1, 130)]
p0.append(-a[0] / b[0])                   # p_1(0) = (0 - a_0)/b_0 * p_0
for j in range(1, 128):
    p0.append((-a[j] * p0[j] - (b[j - 1] * p0[j - 1] if j >= 1 else 0)) / b[j])
g_rates = [float(abs(p0[j + 1] / p0[j])) for j in [10, 20, 40, 80, 120]]
print("  growth |p_{j+1}(0)/p_j(0)| at j = 10/20/40/80/120: " +
      " ".join(f"{r:.4f}" for r in g_rates))
print(f"  |p_60(0)| = {mp.nstr(abs(p0[60]), 3)}   [GEOMETRIC, rate -> ~1 — B_j is tame:"
      f" the N^-3 mass dominates the lemma]")

print("=== (T3) ODD truncation: measured deviation vs the lemma scale ===")
for M in [2000, 20000]:
    z = (np.arange(1, M + 1) - 0.5) * np.pi
    x = 1.0 / z ** 2
    al2, be2 = lanczos_w(x, x ** 2, 14)
    devs = [abs(al2[j - 1] - alO(j)) / alO(j) for j in range(1, 13)]
    tail = 1 / (3 * np.pi ** 4 * M ** 3)
    print(f"  M = {M:6d}: max rel dev (j <= 12) = {max(devs):.2e};"
          f"  lemma scale ||tau||/alpha ~ {tail/alO(6):.2e}   "
          f"[ratio {max(devs)/(tail/alO(6)):.1f} = C_GS x B^2 head-room]")

print("=== (T4) the deviation identity with the g-lemma closed form vs MEASURED ===")
# Stage-A identity: alpha^U_{j+2} - a_j = [g_j^2 (a_j + eta_j) + 2 g_j g_{j-1} b_{j-1}]
#                                          / s_{j+1}^2
# with the closed form g_j = (-1)^j sqrt((4j+3)/2N): the two leading terms CANCEL at
# order 1/(4jN) (alternation!), leaving the predicted residual. Compare vs truth:
for N in [400, 800]:
    zN = (np.arange(1, N + 1) - 0.5) * np.pi
    x = 1.0 / zN ** 2
    alU, beU = lanczos_w(x, np.ones(N), 30)
    g = np.array([(-1) ** j * np.sqrt((4 * j + 3) / (2.0 * N)) for j in range(30)])
    s2 = 1.0 - np.cumsum(g ** 2)
    line = []
    for j in [4, 8, 16]:
        # 0-based Stage-A indexing: a_j = alO(j+1), b_{j-1} = beO(j)  [1-based fns]
        lead1 = g[j] ** 2 * alO(j + 1)                 # eta_j ~ 1e-5, negligible here
        lead2 = 2 * g[j] * g[j - 1] * beO(j)
        pred = (lead1 + lead2) / s2[j]
        true = alU[j + 1] - alO(j + 1)
        line.append(f"j={j}: pred {pred:+.2e} / true {true:+.2e}")
    print(f"  N = {N}:  " + "   ".join(line))
print("  [prediction from PURE closed forms (g-lemma + ODD forms) — no fitted numbers]")
print("done.")
