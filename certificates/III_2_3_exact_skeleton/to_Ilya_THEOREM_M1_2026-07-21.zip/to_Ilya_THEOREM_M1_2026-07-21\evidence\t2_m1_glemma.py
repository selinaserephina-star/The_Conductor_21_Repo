# t2_m1_glemma.py — THE g-LEMMA (M1 item b), session 6 of the campaign, 2026-07-21.
# Derivation (hand, verified below):
#   g_j = <e0, w_j>:  w_j column sums map to the ODD companion OPs, whose atom values
#   are ELEMENTARY (Theorem B1):  shat_{2j+1}(1/z_n) = sqrt((4j+3)pi/2)(-1)^{n+1}
#   sqrt(z_n) J_{2j+3/2}(z_n),  and J_{k+1/2}(z)/sqrt(z) = sqrt(2/pi) j_k(z). Hence
#     (EXACT map)   g_j(N) = sqrt(2(4j+3)/N) * SUM_{n<=N} (-1)^{n+1} j_{2j+1}(z_n)
#   up to finite-N OP-truncation (the Lanczos OPs of the N-atom ODD system vs the
#   infinite shat family — measured below). The infinite sum has a CLOSED FORM:
#     (IDENTITY)    SUM_{n>=1} (-1)^{n+1} j_{2j+1}(z_n) = (-1)^j / 2
#   Proof skeleton (to be written in the note):
#     (a) Poisson: j_{2j+1}(z) = (-1)^j INT_0^1 sin(zt) P_{2j+1}(t) dt;
#     (b) {sqrt2 sin(z_n t)} is the Neumann-at-1 ONB of L^2(0,1) (uniform string);
#         its half-range sine series of a C^1 function converges POINTWISE at the
#         free endpoint t = 1 (classical);
#     (c) sin(z_n * 1) = (-1)^{n+1}, so the sum is (1/2) x [series of P_{2j+1} at
#         t = 1] = (1/2) P_{2j+1}(1) = 1/2, times the (-1)^j of (a).
#   Consequences: sign(g_j) = (-1)^j (THE ALTERNATION LEMMA); |g_j| ~ sqrt((4j+3)/2N)
#   until truncation bites; SUM g^2 ~ SUM (4j+3)/2N reaches 1 at J ~ sqrt(N) — the
#   measured sqrt(N) mass location DERIVED. j = 0 case is already proven exactly:
#   j_1(z_n) = (-1)^{n+1}/z_n^2  =>  S_0 = SUM 1/z_n^2 = m_1 = 1/2.
import numpy as np
import mpmath as mp
from scipy.special import spherical_jn

def lanczos_w(x, wts, m):
    v = np.sqrt(wts / np.sum(wts))
    al, be, Vs = [], [], [v]
    w = x * v
    a0 = v @ w; al.append(a0); w = w - a0 * v
    for j in range(1, m):
        b = np.linalg.norm(w)
        if b < 1e-14: break
        be.append(b)
        vn = w / b
        for u in Vs: vn = vn - (u @ vn) * u
        vn /= np.linalg.norm(vn)
        Vs.append(vn)
        w = x * vn - b * Vs[-2]
        aj = vn @ w; al.append(aj); w = w - aj * vn
    return np.array(al), np.array(be), np.column_stack(Vs)

print("=== (G0) the j = 0 anchor is EXACT: S_0 = sum 1/z_n^2 = 1/2 (proven) ===")
z = (np.arange(1, 200001) - 0.5) * np.pi
print(f"  sum_(n<=2e5) 1/z_n^2 = {np.sum(1.0/z**2):.10f}  -> 1/2 with O(1/N) tail")

print("=== (G1) the IDENTITY S_j = (-1)^j/2: high-precision verification ===")
# mp evaluation with tail correction: j_k(z_n) tail ~ (-1)^{n+1}(-1)^j k(k+1)/(2 z^2)
mp.mp.dps = 30
for j in [0, 1, 2, 5, 10, 20, 40]:
    k = 2 * j + 1
    NBIG = 4000 + 40 * k
    s = mp.mpf(0)
    for n in range(1, NBIG + 1):
        zn = (n - mp.mpf('0.5')) * mp.pi
        s += (-1) ** (n + 1) * mp.sqrt(mp.pi / (2 * zn)) * mp.besselj(k + mp.mpf('0.5'), zn)
    # one-signed tail estimate: sum_{n>NBIG} ~ (-1)^j k(k+1)/(2 pi^2) * 1/(NBIG)
    tail = mp.mpf(k * (k + 1)) / (2 * mp.pi ** 2 * NBIG)
    dev = abs(s - (-1) ** j * mp.mpf('0.5'))
    print(f"  j = {j:3d}: S_j(N={NBIG}) = {mp.nstr(s, 10):>15s}   |S_j - (-1)^j/2| = "
          f"{mp.nstr(dev, 3):>10s}   (tail scale {mp.nstr(tail, 2)})")

print("=== (G2) the finite-N map: g_j(Lanczos) vs the Bessel-sum formula ===")
for N in [200, 800]:
    zN = (np.arange(1, N + 1) - 0.5) * np.pi
    x = 1.0 / zN ** 2
    _, _, V2 = lanczos_w(x, x ** 2, 121)
    g = V2.T @ (np.ones(N) / np.sqrt(N))
    print(f"  N = {N}:")
    print("      j    g_j(Lanczos)    formula sqrt(2(4j+3)/N)*S_j(N)    closed (-1)^j sqrt((4j+3)/2N)")
    for j in [0, 1, 2, 5, 10, 20, 40]:
        k = 2 * j + 1
        Sn = np.sum(((-1.0) ** (np.arange(1, N + 1) + 1)) * spherical_jn(k, zN))
        form = np.sqrt(2 * (4 * j + 3) / N) * Sn
        closed = (-1) ** j * np.sqrt((4 * j + 3) / (2 * N))
        print(f"    {j:3d}   {g[j]:+.6f}        {form:+.6f}                      {closed:+.6f}")
    # alternation check over the whole certified-clean range
    Jmax = min(115, N // 3)
    signs_ok = all(np.sign(g[j]) == (-1) ** j for j in range(Jmax) if abs(g[j]) > 1e-13)
    print(f"    alternation sign(g_j) = (-1)^j over j < {Jmax}: {'HOLDS' if signs_ok else 'FAILS'}")

print("=== (G3) where the closed form bends: the truncation law (the sqrt(N) hump) ===")
N = 800
zN = (np.arange(1, N + 1) - 0.5) * np.pi
x = 1.0 / zN ** 2
_, _, V2 = lanczos_w(x, x ** 2, 121)
g = V2.T @ (np.ones(N) / np.sqrt(N))
print("      j    |g_j| / closed-form    (1 = pure law; falls when truncation bites)")
for j in [2, 5, 10, 15, 20, 25, 30, 40, 60, 90]:
    closed = np.sqrt((4 * j + 3) / (2 * N))
    print(f"    {j:3d}       {abs(g[j])/closed:.4f}")
cum_pred = np.cumsum([(4 * j + 3) / (2 * N) for j in range(120)])
jhalf = int(np.searchsorted(cum_pred, 0.5)) + 1
print(f"  predicted 50%-mass location from sum (4j+3)/2N: j = {jhalf}"
      f"   (measured session 3: j = 23 at N = 800)")
print("done.")
