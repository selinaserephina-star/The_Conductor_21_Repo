# PLAN — T2_M1_weight_transfer campaign (opened 2026-07-19, the G-M1 lane)

**Goal:** close G-M1 (weight transfer companion → uniform) on the λ-side Lambert route
confirmed in this folder's first session, and deliver the uniform-K1 consequence to the
T2 chain. Master ledger: `../LEDGER/EVIDENCE_CHAIN_T2_pin.md` (G-M1 entry + spine);
package traffic: `../LEDGER/AUDIT_REGISTER.md`. Not RH/GRH.

## State (end of session 1, 2026-07-19 — see `M1_lambert_pattern_note_2026-07-19.md`)

**PATTERN CONFIRMED, telescope bypassed:**
  J_N(uniform) = head(m₀ = N; α₁ = m₁/N exact, β₁ ≈ √(m₂/N)) ⊕ ODD-Lambert block
  (closed form) + O(1/N) FLAT in j.
Moments = (2^{2k}−1)ζ(2k)/π^{2k} = tan-series EXACT; EVEN block = companion-x = CF
contraction (exact); ODD block = x²-system (7.7e−10); 1/N ratios 1.999/1.999.

## Stages

- **Stage A — the bordered-perturbation lemma.** Prove |α_{j+1}(N) − α^O_j| +
  |β_{j+1}(N) − β^O_j| ≤ C/N uniformly in j ≤ J(N). Route: the finite-N functional
  differs from the ideal one only in moment tails (Σ_{n>N}x_n^k, explicit) plus the
  m₀ = N head; moment-perturbation → Jacobi-perturbation via the (bounded-support)
  determinacy machinery. Same genus as G-M3 (finite-M truncation drift 0.33k/2M) —
  attack both together; a joint lemma likely covers the Q2-audit's Task-1 "canonical
  completion" question as a corollary.
- **Stage B — the K1-kernel consequence.** Uniform kernels vs ODD-block kernels
  through the one-row bordering: does the head's O(N^{−1/2}) coupling move the kernel
  partial sums at the κ-level? Expected NO (the caustic lives at n/j = 2/π mid-range;
  the head is one row at the spectrum's bottom). If confirmed: uniform-K1 = ODD-K1 +
  O(N^{−1/2}) and the (F10) caustic theorem transfers to the production normalization
  with the SAME a_∞ — the full model-K1 statement.
- **Stage C — write-up + sync.** Dated send when A+B land (uniform-K1 = the last
  ingredient of the model-K1 line per the spine); G4 note to IB updated (the
  even/odd-block dictionary is direct input to the identification question).

## Standing rules
Verify every identity numerically BEFORE building on it. Negative results are results
(→ RESULTS.md). Frozen/sent folders untouched. No SHA until a send. Grades per entry.
All five float-trap lessons live (see the caustic package's task files). Check CPU
contention before long runs.
