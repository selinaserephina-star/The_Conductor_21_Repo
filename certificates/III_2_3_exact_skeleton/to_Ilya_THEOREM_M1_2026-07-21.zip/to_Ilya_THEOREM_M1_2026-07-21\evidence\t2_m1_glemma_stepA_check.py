# t2_m1_glemma_stepA_check.py — line-by-line verification of the step-(a) write-up
# (M1_glemma_stepA_Poisson_sign_2026-07-21.md). Session 8, 2026-07-21.
import numpy as np
import sympy as sp
from scipy.special import spherical_jn, eval_legendre
from scipy.integrate import quad

print("=== (L1) Poisson representation j_k(z) = ((-i)^k/2) int_{-1}^1 e^{izt} P_k dt ===")
worst = 0.0
for k in range(8):
    for z in [0.7, 3.3, 11.0]:
        re = quad(lambda t: np.cos(z * t) * eval_legendre(k, t), -1, 1, limit=200)[0]
        im = quad(lambda t: np.sin(z * t) * eval_legendre(k, t), -1, 1, limit=200)[0]
        val = ((-1j) ** k / 2) * (re + 1j * im)
        ref = spherical_jn(k, z)
        worst = max(worst, abs(val - ref), abs(val.imag))
print(f"  k = 0..7, three z: max |dev| (incl. imaginary leak) = {worst:.2e}")

print("=== (L2)+(L3) the reduced form j_(2j+1)(z) = (-1)^j int_0^1 sin(zt) P_(2j+1) dt ===")
worst = 0.0
for j in range(6):
    k = 2 * j + 1
    for z in [0.7, 3.3, 11.0]:
        val = (-1) ** j * quad(lambda t: np.sin(z * t) * eval_legendre(k, t), 0, 1, limit=200)[0]
        worst = max(worst, abs(val - spherical_jn(k, z)))
print(f"  j = 0..5, three z: max |dev| = {worst:.2e}   [the (-1)^j sign is RIGHT]")

print("=== (L3 anchors) SYMBOLIC at j = 0 and j = 1 (sympy-exact) ===")
z, t = sp.symbols('z t', positive=True)
lhs0 = sp.integrate(sp.sin(z * t) * t, (t, 0, 1))
j1 = sp.sin(z) / z ** 2 - sp.cos(z) / z
print(f"  j = 0: int sin(zt) t dt - j_1(z) = {sp.simplify(lhs0 - j1)}   [0 = exact]")
P3 = (5 * t ** 3 - 3 * t) / 2
lhs1 = -sp.integrate(sp.sin(z * t) * P3, (t, 0, 1))          # (-1)^1 * integral
j3 = (15 / z ** 3 - 6 / z) * sp.sin(z) / z - (15 / z ** 2 - 1) * sp.cos(z) / z
print(f"  j = 1: (-1)*int sin(zt) P_3 dt - j_3(z) = {sp.simplify(lhs1 - j3)}   [0 = exact]")

print("=== (L4) the finite-N assembly IDENTITY (machine precision, no convergence) ===")
# sum_{n<=N} (-1)^{n+1} j_{2j+1}(z_n)  ==  (-1)^j * (1/2) * [S_N P_{2j+1}](1)
worst = 0.0
for j in [0, 1, 3, 7, 15]:
    k = 2 * j + 1
    for N in [50, 400]:
        zn = (np.arange(1, N + 1) - 0.5) * np.pi
        lhs = np.sum(((-1.0) ** (np.arange(1, N + 1) + 1)) * spherical_jn(k, zn))
        # sine coefficients of P_k in the string basis, evaluated at t = 1
        coeff = np.array([quad(lambda t, w=w: np.sin(w * t) * eval_legendre(k, t),
                               0, 1, limit=400)[0] for w in zn])
        SN_at_1 = np.sum(2 * coeff * np.sin(zn * 1.0))
        rhs = (-1) ** j * 0.5 * SN_at_1
        worst = max(worst, abs(lhs - rhs))
print(f"  (j, N) grid: max |LHS - RHS| = {worst:.2e}   [IDENTITY holds at machine level;")
print("   all remaining analytic content = step (b): [S_N P](1) -> P(1) = 1]")
print("done.")
