# g-lemma, step (a): the Poisson sign — written out (THEOREM-M1 part III, first pending write-up)

**Merkabit · Stenberg + Claude · 2026-07-21 (session 8 of the campaign). Every numbered
line below is verified in `t2_m1_glemma_stepA_check.py` (symbolic where possible,
numeric otherwise) — per the standing rule, since signs are where three-line arguments
die. Not RH/GRH.**

## Claim

For every j ≥ 0 and all z ∈ ℂ:

  **j_{2j+1}(z) = (−1)^j ∫₀¹ sin(zt) · P_{2j+1}(t) dt.**  (★)

## Derivation

**(L1) The Poisson (Rayleigh) representation** [DLMF 10.54.2]: for integer k ≥ 0,

  j_k(z) = ((−i)^k / 2) ∫_{−1}^{1} e^{izt} P_k(t) dt.

Anchor check (k = 0): (1/2)∫₋₁¹e^{izt}dt = (e^{iz} − e^{−iz})/(2iz) = sin z / z =
j₀(z). ✓ [verified numerically for k = 0..7 at several z]

**(L2) Parity split.** P_k(−t) = (−1)^k P_k(t). Write e^{izt} = cos(zt) + i sin(zt).
For k ODD: cos(zt)P_k(t) is odd in t (even × odd), so its ∫₋₁¹ vanishes;
sin(zt)P_k(t) is even (odd × odd), so its ∫₋₁¹ = 2∫₀¹. Hence for odd k:

  ∫_{−1}^{1} e^{izt} P_k(t) dt = 2i ∫₀¹ sin(zt) P_k(t) dt.

**(L3) The sign bookkeeping** (the line that must not be rushed). With k = 2j+1:

  (−i)^{2j+1} = ((−i)²)^j · (−i) = (−1)^j · (−i),

so

  j_{2j+1}(z) = ((−i)^{2j+1}/2) · 2i ∫₀¹ sin(zt)P_{2j+1} dt
             = (−1)^j · (−i)(i) · ∫₀¹ sin(zt)P_{2j+1} dt
             = (−1)^j · (+1) · ∫₀¹ sin(zt)P_{2j+1} dt,

since (−i)(i) = −i² = +1. This proves (★). ∎

Anchor check (j = 0, k = 1), fully symbolic: ∫₀¹ sin(zt)·t dt = sin z/z² − cos z/z =
j₁(z), with the + sign — matching (−1)⁰ = +1. [sympy-exact; also j = 1 (k = 3)
against P₃ = (5t³ − 3t)/2, sympy-exact]

## The assembly chain (finite-N form — an IDENTITY, no convergence needed)

With z_n = (n−½)π one has sin(z_n · 1) = (−1)^{n+1} exactly, so for EVERY finite N:

  **(L4)  Σ_{n≤N} (−1)^{n+1} j_{2j+1}(z_n)
        = (−1)^j Σ_{n≤N} sin(z_n) ∫₀¹ sin(z_n t) P_{2j+1}(t) dt
        = (−1)^j · ½ · [S_N P_{2j+1}](1),**

where [S_N f](t) := Σ_{n≤N} 2⟨sin(z_n·), f⟩ sin(z_n t) is the N-term half-range sine
series of f in the string basis {√2 sin(z_n t)} (Neumann end at t = 1). Line (L4) is
a finite identity — verified below to machine precision at every (j, N) tested — and
isolates ALL remaining analytic content in one classical statement:

  **(step b, separate write-up):  [S_N P_{2j+1}](1) → P_{2j+1}(1) = 1  as N → ∞,**

whence Σ_{n≥1}(−1)^{n+1} j_{2j+1}(z_n) = (−1)^j/2. The alternation of the g-profile
is exactly the (−1)^j minted in line (L3).

## Status

Step (a) is now WRITTEN and line-verified (symbolic anchors at j = 0, 1; numeric
k ≤ 7; the finite-N assembly (L4) at machine precision). THEOREM-M1 part (III)'s
pending list shrinks to step (b) alone (endpoint convergence of the Neumann-at-1
sine series for polynomials — classical Dirichlet-kernel argument).
