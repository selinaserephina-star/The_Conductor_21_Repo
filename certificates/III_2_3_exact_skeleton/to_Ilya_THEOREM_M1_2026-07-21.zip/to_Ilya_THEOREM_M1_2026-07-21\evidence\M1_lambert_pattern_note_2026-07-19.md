# G-M1 pattern-check: CONFIRMED — the uniform system is a bordered ODD-Lambert block (closed form + flat 1/N)

**Merkabit · Stenberg + Claude · 2026-07-19 (late session; new campaign folder).
Script `t2_m1_lambert_pattern.py` + log this folder. Not RH/GRH.**

## The claim tested, and what it became

Ledger G-M1 route: *"uniform measure in λ = 1/x IS Lambert 1,3,5,7 directly — first
pattern-check is cheap."* Sharpened before testing via the renormalized-transform
identity (verified exact, (M3)):

  G_N(w) = Σ_{n≤N} 1/(w − x_n) = **N/w** + (1/w)·Σ x_n/(w − x_n)

— all N-dependence of the uniform-N system is isolated in the single divergent moment
m₀ = N; every higher moment converges to the EXACT rationals
m_k = (2^{2k}−1)ζ(2k)/π^{2k} (= 1/2, 1/6, 1/15, 17/630, …), which are precisely the
Taylor coefficients of tan(√λ)/(2√λ) — Lambert's 1,3,5,7 continued fraction — and the
SAME rationals as (F5)'s row-sum identity. ((M1), sympy-exact, k ≤ 8.)

## The structure (all three systems closed form)

Squaring the symmetric y-side Lambert matrix (off-diagonals b_k = 1/√((2k−1)(2k+1)),
Theorem B1) splits into TWO elementary x-side systems ((M2), sympy-exact j ≤ 8):

- **EVEN block = companion-x** (pushforward of μ_L under y → x = y²): α^E₁ = 1/3,
  α^E_j = b²_{2j−2} + b²_{2j−1}, β^E_j = b_{2j−1}b_{2j}. The λ-side Lambert
  S-fraction contraction equals exactly this block.
- **ODD block = the x²-weighted uniform system** (= x·companion-x — ONE FORWARD
  Christoffel step from the solved companion, the stable direction):
    **α^O_j = 1/((4j−3)(4j−1)) + 1/((4j−1)(4j+1)),
     β^O_j = 1/((4j+1)√((4j−1)(4j+3)))** — verified against x²-weighted Lanczos at
  M = 20000 to max rel dev **7.7e−10** (truncation floor): the closed form IS the
  x²-system.

## THE RESULT ((M4)/(M5), the pattern-check proper)

  **J_N(uniform) = [head row: α₁ = m₁(N)/N exactly, β₁ = √(m₂/N)·(1+o(1))]
                   ⊕ [ODD-Lambert block] + O(1/N), FLAT in j.**

Measured: head identities hold to 1e−18/1e−19 (they are Lanczos identities); the deep
block (rows 2..11) matches the ODD closed form with max rel dev 4.99e−3 / 2.50e−3 /
1.25e−3 at N = 200/400/800 — **ratio 1.999 and 1.999: a clean 1/N law** — and the
j-profile of the deviation at N = 800 is FLAT (1.2e−3 at every j ≤ 10; no growth).
Distinctness witnessed: measured α₂ = 0.3995 vs EVEN α^E₁ = 1/3 (dev 0.20) — the deep
block is the ODD system, NOT the shifted companion. Head laws: α₁ = 1/(2N)-class
exactly (this is also the Q2-audit's measured α₁(N) ~ c/N, now with c = m₁ = 1/2
identified); β₁(N) = 0.40825/√N (measured 0.014420 vs law 0.014434 at N = 800).

## What this does to G-M1

The cancellation-laden inverse-Christoffel telescope (|r_i| ≈ 1.15 growth,
P1_string_bessel §2) is **BYPASSED**: the uniform system is not "companion pushed
through an unstable inverse step" — it is a one-row bordering of the ODD Lambert
block, and the transfer runs in the STABLE forward direction (companion → x·companion
= ODD block, one classical Christoffel step, closed form). G-M1 RETARGETS:

1. ~~prove the r,c-telescope resummation~~ → **prove the bordered-perturbation lemma:**
   J_N(uniform) − [head ⊕ J^ODD] = O(1/N) flat in j (measured here; perturbative,
   same genus as G-M3 — the two gaps likely close together, since both are "finite-N
   vs canonical completion" statements).
2. Uniform-K1 kernels then relate to ODD-block kernels (closed form, elementary
   Bessel) through the bordering — the K1-kernel consequence is the natural next
   session ("does the head row's O(N^{−1/2}) coupling perturb the kernel partial sums
   at the κ-level?" — expect no: the caustic lives at j ~ mid-range, the head is one
   row).
3. The λ-side reading is confirmed as stated in the ledger: uniform-in-λ IS Lambert
   1,3,5,7 — through m₀-renormalization + the even/odd split.

## Grades

(M1)/(M2) sympy-exact. (M3) exact identity, float-verified. (M4)/(M5) float64 Lanczos
with full reorthogonalization (head identities at 1e−18 confirm the pipeline); ODD
closed form certified at 7.7e−10 against an independent M = 20000 truncation; the 1/N
law measured over two octaves with ratio 1.999 twice. No mp needed at this grade; the
bordered-perturbation lemma (item 1) is where rigor lands next.
