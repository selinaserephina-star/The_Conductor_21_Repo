# t2_m1_vheadfree_production.py — the flagged M1 observation, tested (session 5 of the
# campaign, 2026-07-21): (i) the arrowhead identity is MEASURE-AGNOSTIC — verify it on
# the PRODUCTION atoms; (ii) V-HEAD-FREE: both arrowheads (mu_D, mu_F) share the
# identical head vector e0 = 1/sqrt(N), so the head should CANCEL in V = J(muF) - J(muD)
# at leading order, leaving V ~ the shifted difference of the two ODD blocks — i.e. the
# pin's own object would be immune to the escaping-state pathology of the N -> inf limit.
# Feeds G4 directly.
import os
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))

def lanczos_w(x, wts, m):
    v = np.sqrt(wts / np.sum(wts))
    al, be, Vs = [], [], [v]
    w = x * v
    a0 = v @ w; al.append(a0); w = w - a0 * v
    for j in range(1, m):
        b = np.linalg.norm(w)
        if b < 1e-14: break
        be.append(b)
        vn = w / b
        for u in Vs: vn = vn - (u @ vn) * u
        vn /= np.linalg.norm(vn)
        Vs.append(vn)
        w = x * vn - b * Vs[-2]
        aj = vn @ w; al.append(aj); w = w - aj * vn
    return np.array(al), np.array(be), np.column_stack(Vs)

q = np.loadtxt(os.path.join(HERE, '..', 'T2_K1K2_kernel_bounds_2026-07-18',
                            'quantiles_production.csv'), delimiter=",", skiprows=1)
gD, gF = q[:, 1], q[:, 2]

print("=== (V1) the arrowhead identity on PRODUCTION atoms (measure-agnostic claim) ===")
for tag, gg in [("mu_D", gD), ("mu_F", gF)]:
    x = 1.0 / gg ** 2
    N = len(x)
    J = 40
    alU, beU, _ = lanczos_w(x, np.ones(N), J + 1)
    _, _, V2 = lanczos_w(x, x ** 2, J + 1)
    F = np.column_stack([np.ones(N) / np.sqrt(N), V2[:, :J]])
    Qm, R = np.linalg.qr(F)
    s = np.sign(np.diag(R)); Qm = Qm * s
    T = Qm.T @ (x[:, None] * Qm)
    dev = max(np.max(np.abs(np.diag(T)[:J] - alU[:J])),
              np.max(np.abs(np.diag(T, 1)[:J - 1] - beU[:J - 1])))
    print(f"  {tag} (N = {N}): max|J(frame) - J(Lanczos)| = {dev:.2e}   [machine zero"
          f" = the identity holds verbatim on production]")

print("=== (V2) THE V-HEAD-FREE CHECK (production, full N = 149 and drops) ===")
for drop in [0, 1, 4]:
    xD = 1.0 / gD[drop:] ** 2
    xF = 1.0 / gF[drop:] ** 2
    N = len(xD)
    J = 42
    alUD, beUD, _ = lanczos_w(xD, np.ones(N), J + 2)
    alUF, beUF, _ = lanczos_w(xF, np.ones(N), J + 2)
    alOD, beOD, _ = lanczos_w(xD, xD ** 2, J + 2)
    alOF, beOF, _ = lanczos_w(xF, xF ** 2, J + 2)
    # V in uniform coordinates
    Vd = alUF[:J] - alUD[:J]              # diagonal of V
    Vo = beUF[:J - 1] - beUD[:J - 1]      # off-diagonal of V
    vscale = max(np.max(np.abs(Vd)), np.max(np.abs(Vo)))
    # head entries of V
    h11 = Vd[0]; h12 = Vo[0]
    # deep block of V vs the SHIFTED ODD-difference
    dOd = alOF[:J - 1] - alOD[:J - 1]
    dOo = beOF[:J - 2] - beOD[:J - 2]
    JJ = 30
    num_d = np.abs(Vd[1:JJ + 1] - dOd[:JJ])
    num_o = np.abs(Vo[1:JJ + 1] - dOo[:JJ])
    den_d = np.maximum(np.abs(dOd[:JJ]), 1e-18)
    rel_med = np.median(num_d / den_d)
    print(f"  drop-{drop} (N = {N}):  ||V||-scale = {vscale:.4f}")
    print(f"      head entries:  V_11 = {h11:+.2e}  V_12 = {h12:+.2e}"
          f"   ->  head/scale = {max(abs(h11), abs(h12))/vscale:.2e}")
    print(f"      deep block vs shifted ODD-difference (j <= {JJ}): max|dev| = "
          f"{max(np.max(num_d), np.max(num_o)):.2e}  (median rel {rel_med:.3f});"
          f"  max|ODDdiff| = {np.max(np.abs(dOd[:JJ])):.4f}")

print("=== (V3) N-trend of the head cancellation (production sections) ===")
for N in [60, 100, 149]:
    xD = 1.0 / gD[:N] ** 2
    xF = 1.0 / gF[:N] ** 2
    alUD, beUD, _ = lanczos_w(xD, np.ones(N), 8)
    alUF, beUF, _ = lanczos_w(xF, np.ones(N), 8)
    h11 = alUF[0] - alUD[0]
    m1D = np.sum(xD); m1F = np.sum(xF)
    pred = (m1F - m1D) / N
    print(f"  N = {N}: V_11 = {h11:+.3e}  vs exact (m1F - m1D)/N = {pred:+.3e}"
          f"  (identity);  scale relative to ||V|| ~ 1e-1: {abs(h11)/0.1:.1e}")
print("done.")
