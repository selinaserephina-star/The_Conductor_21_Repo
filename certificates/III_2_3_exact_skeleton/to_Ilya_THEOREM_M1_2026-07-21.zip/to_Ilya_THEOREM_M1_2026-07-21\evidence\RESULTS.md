# RESULTS — T2_M1_weight_transfer campaign

## 2026-07-19 — session 1: G-M1 PATTERN CONFIRMED (λ-side Lambert route; telescope bypassed)
- script `t2_m1_lambert_pattern.py` + log; note `M1_lambert_pattern_note_2026-07-19.md`;
  ledger G-M1 tag flipped + spine updated (commit 3aafd5f).
- EXACT: m_k = (2^(2k)-1) zeta(2k)/pi^(2k) = [lam^(k-1)] tan(sqrt(lam))/(2 sqrt(lam)),
  k <= 8 (sympy) — Lambert 1,3,5,7 = the (F5) rationals. Renormalized-transform
  identity: ALL N-dependence in m_0 = N.
- EXACT: CF contraction = EVEN block = companion-x; ODD block = x^2-weighted system,
  closed form alpha^O_j = 1/((4j-3)(4j-1)) + 1/((4j-1)(4j+1)),
  beta^O_j = 1/((4j+1) sqrt((4j-1)(4j+3))) — verified 7.7e-10 vs M = 20000 truncation.
- THE RESULT: J_N(uniform) = head(m_0 = N; alpha_1 = m_1/N at 1e-18, beta_1 =
  sqrt(m_2/N) at 0.1%) + ODD block + O(1/N) FLAT in j (dev 4.99e-3/2.50e-3/1.25e-3 at
  N = 200/400/800, ratios 1.999/1.999; j-profile flat at 1.2e-3, j <= 10, N = 800).
- Q2-audit cross-link: its measured alpha_1(N) ~ c/N now has c = m_1 = 1/2 identified.
- grade: sympy-exact anchors; float64 Lanczos with full reorthogonalization (pipeline
  confirmed by the 1e-18 head identities); closed form certified at 7.7e-10.

## 2026-07-19 — session 2 (Stage B): kappa-level transfer CONFIRMED; caustic clean at N^(-1/2); one honest O(1) surprise; SIXTH float-trap recorded
- script `t2_m1_stageB_kernel_bordering.py` + log.
- **SIXTH FLOAT-TRAP (new lesson, recurrence genus):** evaluating orthonormal OP
  values/derivatives by forward three-term recurrence EXPLODES in float64 at the
  spectrum edge and in the deep atom cluster (got 1e26-1e172 where the Lanczos-matrix
  bound |p_j(x_n)| <= sqrt(N) proves boundedness; first FD spot-checks passed because
  they only probed the safe zone — spot-checks must cover the EDGES). The K1K2 "mp
  pipeline" warning re-confirmed concretely. Fix used here: kernels = centered FD of
  the Lanczos map itself (stable outputs of stable runs); two-h consistency 4.0e-5.
  True kernels are O(1) (max|K| = 1.41) — the astronomic first run was pure artifact.
- **kappa ladders at matched rows (unif j+1 <-> ODD j), F7 protocol, N = 100/200/400:**
  agree to 0.9-2.6% at N = 400 and improving in j (j=32: 1.596/1.582). The
  caustic-class constant TRANSFERS at the measured level.
- **Caustic window: clean.** PS(diff) inside the moving caustic window decays
  ~N^(-1/2)-class (j=16: 0.314/0.198/0.142) — the head coupling does NOT reach the
  caustic. The (F10) transfer expectation holds WHERE IT MATTERS.
- **HONEST SURPRISE (recorded):** sup|PS(K^unif_{j+1} - K^ODD_j)| ~ 0.6-0.8, N-STABLE
  (not decaying), localized mid/deep (n_sup = 25/82/255 at j = 8/16/32, N = 400) —
  the head-projector's mass redistribution over the deep cluster. It never moves the
  kappa-sup (attained elsewhere), so kappa-level transfer stands; but the naive
  "uniform-K1 = ODD-K1 + O(N^(-1/2)) uniformly in rows" is TOO STRONG. Correct shape:
  row-restricted transfer (caustic window + sup locations) + an O(1) smooth
  redistribution term away from them. Stage A's lemma should carry this split.
- grade: FD kernels two-h-verified 4e-5 (N = 200 uniform anchor); ladders single-h
  (hrel 1e-4); float64 throughout with the trap actively avoided.

## 2026-07-19 — session 3 (Stage A): the ARROWHEAD IDENTITY IS EXACT; g-profile = the redistribution term; J(N) ~ sqrt(N) measured
- script `t2_m1_stageA_arrowhead.py` + log.
- **(A1) EXACT FINITE-N IDENTITY (verified machine zero, 3.3e-16, N = 100/200/400):**
  J_N(uniform) = tri(Q^T diag(x) Q), Q = ordered orthonormalization of the frame
  [e0 | V2], e0 = 1/sqrt(N), V2 = the ODD-system Lanczos basis. Proof = degree
  filtration (span{1, x P_{j-1}} = P_j), two lines, rigorous. The bordered
  "perturbation lemma" is now explicit algebra on a PROVEN identity, not an
  asymptotic claim.
- **(A2) the coupling profile (item 1b ANSWERED):** g_j = <e0, V2_j>; sum g^2 =
  1.0000 (completeness); the mass sits at j ~ 0.8 sqrt(N) (50% by j = 12/16/23 at
  N = 200/400/800), tail |g_j| ~ 1047 j^(-3) (N = 800 fit). The Stage-B O(0.7)
  redistribution = the head state's Fourier profile in the ODD basis — a projector
  statement, as predicted; its sqrt(N)-located mass explains the mid/deep
  localization of the kernel PS-difference.
- **(A3) J(N) breakdown measured:** dev(alpha) flat ~1/N for j <~ sqrt(N), rises
  past j ~ (2-5) sqrt(N) (N = 200: rise at 64+; N = 400: at 96+). Two separated
  sources: flat-1/N = ODD-truncation moment tails (the true G-M3 twin); the
  g-coupling takes over at j ~ sqrt(N).
- **SPLIT LEMMA (statement fixed by the data; proof work remaining is mechanical):**
  for j <= c sqrt(N): |alpha_{j+1}(N) - alpha^O_j| + |beta_{j+1}(N) - beta^O_j| <=
  C_t/N (ODD truncation) + C_g Gamma_j-terms (explicit GS/rank-one-downdate algebra
  in the g_j); beyond j ~ sqrt(N) the head mixes and no transfer is claimed.
  Remaining proof work: (a) write out the downdate algebra (mechanical); (b) g_j
  closed form/bounds (Fourier coefficients of 1 in the elementary ODD system —
  Bessel-summable candidate, the elegant next step); (c) the ODD-truncation moment
  lemma = G-M3, now precisely twinned.
- grade: identity machine-zero at three N; profiles float64 Lanczos (full reorth);
  fits over j = 4..119; breakdown vs a deep M = 20000 ODD reference.

## 2026-07-19 — session 4 (Stage A item a): the DOWNDATE ALGEBRA WRITTEN OUT and machine-verified; horizon J(N) = 3.2 sqrt(N) sharp; sharp bound reduced to the g-alternation lemma
- script `t2_m1_stageA2_downdate_algebra.py` + log.
- **The algebra (exact, encoded in the script header):** ordered GS of the arrowhead
  frame = a two-term recursion in (w_j, ehat_j) driven by s_{j+1}^2 = s_j^2 - g_j^2,
  with the collapse X e0 = sqrt(m2/N) w0 (the constant's X-image IS the first ODD
  basis vector) killing all cross terms; scalar eta_j = <ehat_j, X ehat_j> obeys a
  one-line recursion. Exact uniform entries: alpha^U_1 = m1/N; beta^U_1 =
  sqrt(m2/N) s_1; alpha^U_{j+2}, beta^U_{j+2} explicit in {g, a, b, m1, m2}.
- **Machine verification:** formulas vs direct Lanczos: 1.5e-13/1.1e-13/5.5e-14
  (alpha), similar beta, at N = 200/400/800, over ALL rows up to the s^2-floor.
- **The horizon is SHARP and measured by the algebra itself:** s^2 hits 1e-6 at
  j = 45/65/93 = 3.2/3.25/3.3 sqrt(N) — J(N) = 3.2 sqrt(N) with a stable constant
  (the transfer horizon of the split lemma, no longer an eyeball estimate).
- **Deviation identity (verified exact per-point):**
  alpha^U_{j+2} - a_j = [g_j^2(a_j + eta_j) + 2 g_j g_{j-1} b_{j-1}] / s_{j+1}^2.
  Crude bound (absolute values): explicit, with measured slack 9-27x = the
  ALTERNATING-SIGN cancellation g_j g_{j-1} < 0 between the two leading terms (also
  keeps eta_j at 1e-5 vs its 0.05-0.5 crude ceiling). One transcription sign error
  caught by the per-point check (the identity matched, the rearrangement didn't) —
  the verify-before-use discipline paid again.
- **Item (a) DONE. The sharp bound is now reduced to ONE structural fact — the
  g-alternation lemma: sign(g_j) = (-1)^j (measured at every j, all N; g_j =
  <e0, w_j> proportional to sum_n x_n p^O_j(x_n) — a Chebyshev-like positivity
  statement in the elementary ODD system). That is item (b)'s closed-form work,
  now doubly motivated: it gives BOTH the g-decay law and the cancellation.**
- grade: identity + deviation formulas machine-verified (1e-13) at three N over the
  full pre-horizon range; bounds explicit; float64 with the six traps live.

## 2026-07-21 — session 5: production arrowhead CONFIRMED verbatim; V is HEAD-SUPPRESSED (not head-free) — quantified with exact formulas
- script `t2_m1_vheadfree_production.py` + log.
- **(V1) The arrowhead identity is measure-agnostic — CONFIRMED on production:**
  J_N(uniform) = tri(Q^T X Q) over [e0 | V2] at machine zero (1.4e-14 mu_D,
  3.3e-14 mu_F, N = 149). Everything proven about the arrowhead structure applies
  to the production operator verbatim.
- **(V2) The flagged V-head-free conjecture, honestly refined: SUPPRESSION, not
  annihilation.** Head entries of V = J(muF) - J(muD): 5-9% of ||V||-scale
  (drop-0/1/4: 7.9e-2/9.1e-2/5.0e-2 relative); V_11 = (m1F - m1D)/N EXACTLY
  (identity verified at N = 60/100/149, ~1/N decay). Deep block vs the shifted
  ODD-difference: leading-order correspondence with 15-30% median corrections
  (decaying with drop; max dev 1e-2/4e-3/1.7e-3 vs scales 1.47/0.20/0.011).
- **Verdict for the M-bridge and G4:** the escaping-state pathology does NOT
  dominate the pin's object — V's principal part IS the ODD-block difference
  (bounded, e.s.a., closed-form-friendly world), the head enters at a quantified
  ~5-9%, and ALL corrections are exact expressions in (g^D, g^F, s-factors) via
  the downdate algebra. G4 guidance: build the limit story for V on the
  ODD-difference as principal term + explicitly-controlled head/coupling terms.
- grade: float64 Lanczos with full reorth (validated pipeline); identities exact
  where claimed; suppression ratios measured at three drops + three N.

## 2026-07-21 — session 6: THE g-LEMMA (item b) — closed form, alternation, and the sqrt(N) hump, all from ONE identity
- script `t2_m1_glemma.py` + log.
- **THE IDENTITY: SUM_{n>=1} (-1)^{n+1} j_{2j+1}(z_n) = (-1)^j / 2 for every j >= 0.**
  Verified: finite-sum deviations EQUAL the computable one-signed tail at every j
  tested (j <= 40; e.g. j = 40: dev 0.0464 vs tail 0.046). The j = 0 case is exactly
  proven already (j_1(z_n) = (-1)^{n+1}/z_n^2 => S_0 = m_1 = 1/2).
  Proof skeleton (both steps classical, to be written): (a) Poisson gives
  j_{2j+1}(z) = (-1)^j INT_0^1 sin(zt) P_{2j+1}(t) dt; (b) the half-range sine basis
  {sqrt2 sin(z_n t)} (Neumann-at-1, the uniform string) converges pointwise at the
  free endpoint for C^1 functions; (c) sin(z_n) = (-1)^{n+1} => the sum is
  (1/2) P_{2j+1}(1) = 1/2 times the (-1)^j.
- **THE MAP (exact modulo ODD-Lanczos truncation):**
  g_j(N) = sqrt(2(4j+3)/N) * SUM_{n<=N}(-1)^{n+1} j_{2j+1}(z_n) — verified to SIX
  DECIMALS at j <= 2 (both N), 1e-4 at j = 5; deviations at larger j = the finite-N
  OP truncation (same moment-tail genus as G-M3 — the two remainders are one).
- **CONSEQUENCES, all measured-confirmed:** closed form g_j ~ (-1)^j sqrt((4j+3)/2N)
  (0.1-0.4% at low j); **sign(g_j) = (-1)^j HOLDS over the whole clean range**
  (j < 66 at N = 200, j < 115 at N = 800) — the ALTERNATION LEMMA; sum g^2 ~
  sum (4j+3)/2N reaches 1 at J ~ sqrt(N) — the sqrt(N) mass hump DERIVED (predicted
  50% at j = 20 vs measured 23); the truncation envelope measured (0.996 -> 0.002
  over j = 2..90).
- **Status of item (b): derivation + verification COMPLETE; the formal write-up is
  two classical steps (Poisson sign bookkeeping + endpoint convergence of the
  Neumann sine series) — textbook, no research content remaining. The sharp split
  lemma's cancellation input is now closed-form.**
- grade: identity verified mp dps-30 with tail-matched deviations; map float64
  Lanczos (validated pipeline) vs scipy spherical_jn; closed form vs measurement
  at three digits.

## 2026-07-21 — session 7: THEOREM-M1 ASSEMBLED — G-M1 closed, G-M3 closed at lemma grade
- script `t2_m1_truncation_lemma.py` + log; note `M1_THEOREM_note_2026-07-21.md`
  (the 8-part theorem with per-part grades); ledger tags flipped.
- **(T1) tail masses EXACT** (4 digits): ||tau_ODD|| = 1/(3 pi^4 N^3);
  ||tau_comp|| = 2/(pi^2 N) — the measured 0.33k/2M companion drift's shape.
- **(T2) edge values geometric, rate -> 1** (|p^O_60(0)| = 6.6e4) — B_j tame.
- **(T3) the truncation lemma verified quantitatively:** ODD deviation scales
  EXACTLY as M^-3 over a decade (3.90e-7 -> 3.90e-10 at M = 2000 -> 20000) with
  the effective constant C_GS x B^2 ~ 3.5e3 STABLE (3472.9 vs 3476.0).
- **(T4) the deviation law from pure closed forms:** alternation cancellation ->
  ~1/(4jN) residual; predicts true uniform-vs-ODD deviations at 8% (j=4) to ~30%
  (mid-range), clean 1/N scaling; DERIVES session 1's flat 1.2e-3 rel-dev law.
  (One indexing bug — uniform row j+2 vs ODD row j instead of j+1 — caught by the
  per-point check and fixed same run; the seventh catch of the campaign's
  verify-before-use discipline.)
- Remaining polish (no research content): g-lemma's two classical write-ups;
  the GS-stability constant written out; production-constants ball run (T2a
  machinery) for certificate-grade constants.
- grade: per-part grades in the theorem note; this session float64 (validated
  pipeline) + mp edge recurrence + exact tail sums.

## 2026-07-21 — session 8: g-lemma step (a) WRITTEN AND LINE-VERIFIED (Poisson sign)
- note `M1_glemma_stepA_Poisson_sign_2026-07-21.md`; script
  `t2_m1_glemma_stepA_check.py` + log.
- (L1) Poisson rep j_k = ((-i)^k/2) int e^{izt} P_k: 1.4e-16, zero imaginary leak
  (k <= 7). (L2)+(L3) parity reduction + sign bookkeeping ((-i)^{2j+1} * i = (-1)^j):
  reduced form verified 1.25e-15, j <= 5. SYMBOLIC anchors sympy-EXACT at j = 0
  (against j_1) and j = 1 (against j_3).
- **(L4) the finite-N assembly IDENTITY:** sum_{n<=N}(-1)^{n+1} j_{2j+1}(z_n) =
  (-1)^j (1/2) [S_N P_{2j+1}](1) at 1.1e-14 over a (j, N) grid — an identity, no
  convergence used; ALL remaining analytic content of part (III) is isolated in
  step (b): [S_N P](1) -> P(1) = 1 (Neumann-at-1 sine series, classical).
- The alternation's (-1)^j is minted in line (L3): (-i)^{2j+1} * i = +(-1)^j.
- grade: symbolic-exact anchors; quadrature/machine-level line checks.

## 2026-07-21 — session 9: g-lemma step (b) WRITTEN — PART (III) IS PROVEN
- note `M1_glemma_stepB_endpoint_2026-07-21.md`; script
  `t2_m1_glemma_stepB_check.py` + log.
- (B1) reflection identity: the half-range string series IS the period-4
  odd-harmonic Fourier series of the (odd-about-0, even-about-1) extension —
  machine identity 4.4e-15, even harmonics vanish. (B2) regularity sympy-exact:
  P_(2j+1)(0) = 0 (continuity of the extension), P'_k(1) = k(k+1)/2 (the corner).
  (B3) Dirichlet-Jordan (textbook citation) gives pointwise endpoint convergence.
  (B4) quantitative rate by double IBP: 1 - [S_N P_k](1) = k(k+1)/(pi^2 N)(1+o(1))
  — matches measurement to FOUR SIGNIFICANT FIGURES (2.026e-3 vs 2.026e-3 at k=1,
  N=100); via step (a)'s 1/2 this is exactly the session-6 tail law.
- **CHAIN COMPLETE: sum_{n>=1}(-1)^{n+1} j_{2j+1}(z_n) = (-1)^j/2 is PROVEN**
  (DLMF 10.54.2 + parity + the sign line + reflection + DJ + P_k(0)=0, P_k(1)=1),
  with explicit finite-N rate. Alternation and closed form of g at PROVEN grade.
- THEOREM-M1 remaining polish: GS-stability write-out (part IV) + optional
  production ball run. Part (III) closed.
- grade: identities machine-level; regularity inputs sympy-exact; rate 4 sig figs.

## 2026-07-21 — session 10: GS-stability WRITTEN — PART (IV) PROVEN; THEOREM-M1 HAS NO PENDING WRITE-UPS
- note `M1_truncation_GS_stability_2026-07-21.md`; script + log.
- The lemma: |Delta alpha_i| + |Delta beta_i| <= 6 x1 (j+2) ||tau|| B_j^2 for
  ||E|| <= 1/4, via (S1) tau-pairing bounds, (S2) the two-line Cholesky fixed
  point ||S|| <= 2||E|| (verified: max ratio 0.944 over 120 random trials), (S3)
  assembly with ||X|| <= x1.
- Instantiation: ODD deviations covered with 6.5e5x headroom, STABLE across a
  decade of M (647094 vs 646041) — the proven envelope runs exactly parallel to
  the M^-3 truth. B_13 = 1618.5 (closed-form recurrence), x1 = 0.405.
- **THEOREM-M1: parts (I)-(VI) proven/exact; (VII) structure machine-zero with
  optional ball-run constants; (VIII) measured with exact-formula control. The
  campaign's mathematical content is COMPLETE.**
- grade: proof with crude explicit constants; verification numeric (120-trial
  Cholesky; two-decade instantiation).
