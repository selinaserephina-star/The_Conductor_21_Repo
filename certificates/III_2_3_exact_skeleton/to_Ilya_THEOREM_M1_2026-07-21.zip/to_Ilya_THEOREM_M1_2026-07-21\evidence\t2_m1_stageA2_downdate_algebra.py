# t2_m1_stageA2_downdate_algebra.py — Stage A item (a): the GS/downdate algebra of the
# arrowhead frame WRITTEN OUT and machine-verified. Session 4 of the campaign, 2026-07-19.
#
# Frame: [e0 | w_0, w_1, ...], e0 = 1/sqrt(N), w_j = ODD Lanczos basis columns.
# Data: g_j = <e0, w_j>;  a_j = w_j^T X w_j, b_j = w_j^T X w_{j+1} (the ODD Jacobi);
#       mu = m1/N = e0^T X e0;  tau = sqrt(m2/N)  [because X e0 = tau * w_0 EXACTLY —
#       the constant's image under X IS the first ODD basis vector].
# Ordered GS: q_0 = e0;  ehat_0 = e0;  s_0 = 1;  and for j >= 0:
#   s_{j+1}^2 = s_j^2 - g_j^2
#   q_{j+1}   = (s_j w_j - g_j ehat_j) / s_{j+1}         [modulo the ehat/w mix sign]
#   ehat_{j+1}= (s_j ehat_j - g_j w_j) / s_{j+1}
# with the scalar eta_j := <ehat_j, X ehat_j> obeying
#   eta_0 = mu;   s_{j+1}^2 eta_{j+1} = s_j^2 eta_j - 2 g_j (tau d_{j0} - g_{j-1} b_{j-1})
#                                        + g_j^2 a_j.
# EXACT uniform Jacobi entries (derived by expanding q^T X q with X w tridiagonal and
# <e0, X w_j> = tau d_{j0}):
#   alpha^U_1   = mu
#   beta^U_1    = tau * s_1
#   alpha^U_{j+2} = [ s_j^2 a_j - 2 g_j (tau d_{j0} - g_{j-1} b_{j-1}) + g_j^2 eta_j ]
#                   / s_{j+1}^2
#   beta^U_{j+2}  = { s_j s_{j+1} b_j
#                     - g_{j+1} s_j [tau d_{j0} - g_{j-1} b_{j-1} - g_j a_j] / s_{j+1}
#                     + g_j g_{j+1} [ s_j eta_j - g_j (tau d_{j0} - g_{j-1} b_{j-1})/s_j ]
#                       / s_{j+1} } / (s_{j+1} s_{j+2})
# Deviation form (the lemma's engine; s_j^2 - s_{j+1}^2 = g_j^2):
#   alpha^U_{j+2} - a_j = [ g_j^2 (a_j + eta_j) + 2 g_j g_{j-1} b_{j-1}
#                           - 2 g_j tau d_{j0} ] / s_{j+1}^2
# Everything below: encode, verify vs direct Lanczos at machine precision, then
# evaluate the bound vs the actual deviation (margins + the alternating-sign slack).
import numpy as np

def lanczos_full(x, wts, m):
    v = np.sqrt(wts / np.sum(wts))
    al, be, Vs = [], [], [v]
    w = x * v
    a0 = v @ w; al.append(a0); w = w - a0 * v
    for j in range(1, m):
        b = np.linalg.norm(w)
        if b < 1e-14: break
        be.append(b)
        vn = w / b
        for u in Vs: vn = vn - (u @ vn) * u
        vn /= np.linalg.norm(vn)
        Vs.append(vn)
        w = x * vn - b * Vs[-2]
        aj = vn @ w; al.append(aj); w = w - aj * vn
    return np.array(al), np.array(be), np.column_stack(Vs)

def formulas(g, a, b, mu, tau, J):
    """exact alpha^U, beta^U from the downdate algebra; returns arrays + s, eta."""
    alF = np.zeros(J); beF = np.zeros(J - 1)
    s2 = np.zeros(J + 2); s2[0] = 1.0
    eta = np.zeros(J + 1); eta[0] = mu
    alF[0] = mu
    for j in range(0, J):
        s2[j + 1] = s2[j] - g[j] ** 2
    beF[0] = tau * np.sqrt(s2[1])
    for j in range(0, J - 1):
        cross = (tau if j == 0 else 0.0) - (g[j - 1] * b[j - 1] if j >= 1 else 0.0)
        if j + 1 < J:
            alF[j + 1] = (s2[j] * a[j] - 2 * g[j] * cross + g[j] ** 2 * eta[j]) / s2[j + 1]
        eta[j + 1] = (s2[j] * eta[j] - 2 * g[j] * cross + g[j] ** 2 * a[j]) / s2[j + 1]
        if j + 2 < J and s2[j + 2] > 0:
            sj = np.sqrt(s2[j]); sj1 = np.sqrt(s2[j + 1]); sj2 = np.sqrt(s2[j + 2])
            t1 = sj * sj1 * b[j]
            t2 = -g[j + 1] * sj * (cross - g[j] * a[j]) / sj1
            t3 = g[j] * g[j + 1] * (sj * eta[j] - g[j] * cross / sj) / sj1
            beF[j + 1] = (t1 + t2 + t3) / (sj1 * sj2)
    return alF, beF, s2, eta

print("=== (D1) the algebra vs direct Lanczos: exact formulas must match at machine level ===")
KEEP = {}
for N in [200, 400, 800]:
    z = (np.arange(1, N + 1) - 0.5) * np.pi
    x = 1.0 / z ** 2
    J = 120
    alU, beU, _ = lanczos_full(x, np.ones(N), J + 2)
    a, b, V2 = lanczos_full(x, x ** 2, J + 3)
    g = V2.T @ (np.ones(N) / np.sqrt(N))
    mu = np.sum(x) / N; tau = np.sqrt(np.sum(x ** 2) / N)
    alF, beF, s2, eta = formulas(g, a, b, mu, tau, J)
    jmax = int(np.searchsorted(-s2[:J], -1e-6))          # stop before s^2 degenerates
    jv = min(jmax - 2, J - 2)
    devA = np.max(np.abs(alF[:jv] - alU[:jv]))
    devB = np.max(np.abs(beF[:jv] - beU[:jv]))
    KEEP[N] = (g, a, b, mu, tau, s2, eta, alU, alF, jv)
    print(f"  N = {N}: rows verified j <= {jv} (s^2 floor 1e-6): max|alpha diff| = "
          f"{devA:.2e}, max|beta diff| = {devB:.2e}   [machine = algebra EXACT]")

print("=== (D2) the deviation formula and the bound (the lemma's engine) ===")
for N in [200, 400, 800]:
    g, a, b, mu, tau, s2, eta, alU, alF, jv = KEEP[N]
    print(f"  N = {N}:")
    for j in [4, 8, 16, 32]:
        if j + 1 >= jv: continue
        cross = -(g[j - 1] * b[j - 1])
        # deviation identity: alpha^U_{j+2} - a_j = [g_j^2(a_j + eta_j) - 2 g_j cross]/s_{j+1}^2
        #                                        = [g_j^2(a_j + eta_j) + 2 g_j g_{j-1} b_{j-1}]/s_{j+1}^2
        dev_formula = (g[j] ** 2 * (a[j] + eta[j]) - 2 * g[j] * cross) / s2[j + 1]
        dev_true = alU[j + 1] - a[j]
        # crude bound (no sign structure): term-by-term absolute values
        bound = (g[j] ** 2 * (a[j] + abs(eta[j])) + 2 * abs(g[j] * g[j - 1]) * b[j - 1]) / s2[j + 1]
        canc = abs(g[j] ** 2 * (a[j] + eta[j])) / max(abs(dev_true), 1e-18)
        print(f"    j = {j:3d}: dev(true) = {dev_true:+.3e}  dev(formula) = {dev_formula:+.3e}"
              f"  |crude bound| = {bound:.3e}  (cancellation {canc:5.1f}x)")
print("  [dev(formula) == dev(true) exactly; the crude bound's slack IS the alternating-")
print("   sign cancellation g_j g_{j-1} < 0 between the two leading terms — the sharp")
print("   bound needs the g-alternation lemma (item b: sign structure of <e0, w_j>)]")

print("=== (D3) the lemma constants: Gamma_j^2 = 1 - s_{j+1}^2 and the eta ceiling ===")
for N in [200, 400, 800]:
    g, a, b, mu, tau, s2, eta, alU, alF, jv = KEEP[N]
    for j in [8, 32]:
        if j >= jv: continue
        print(f"  N = {N}, j = {j}: Gamma^2 = {1 - s2[j]:.4f};  eta_j = {eta[j]:.3e}"
              f"  (ceiling mu + 2 tau|g0| + Gamma^2 max(a+2b) = "
              f"{mu + 2 * tau * abs(g[0]) + (1 - s2[j]) * np.max(a[:j] + 2 * np.r_[b[:j-1], 0][:j]):.3e})")
print("done.")
