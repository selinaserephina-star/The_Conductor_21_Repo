# NEXT SESSION TASK — the g-alternation/closed-form lemma (item b), then the sharp split lemma and G-M3

**Campaign `T2_M1_weight_transfer_2026-07-19/` · staged 2026-07-19 (end of the
four-session campaign day) · supersedes `NEXT_SESSION_TASK_bordering_lemma.md`
(its Stage B, the arrowhead identity, the downdate algebra, and item 1b are ALL
EXECUTED — sessions 2–4; see RESULTS). Not RH/GRH.**

## Read first (in this order)
1. `RESULTS.md` this folder — all four session entries (pattern; kernel transfer;
   arrowhead identity; downdate algebra). The state below summarizes; RESULTS is
   authoritative.
2. `t2_m1_stageA2_downdate_algebra.py` HEADER — the exact algebra and formulas
   (machine-verified 1e−13; do NOT re-derive).
3. `M1_lambert_pattern_note_2026-07-19.md` + `PLAN.md` (stages; Stage C pending).
4. Ledger `../LEDGER/EVIDENCE_CHAIN_T2_pin.md`: G-M1 (session-4 §9 entry), G-M3.
5. For the closed-form work: `../T2_K1K2_kernel_bounds_2026-07-18/P1_string_bessel_2026-07-18.md`
   Theorem B1 (the companion OP values = Riccati–Bessel, the Parseval/Dini
   machinery) and Theorem B2 (the Christoffel step) — read-only, the tools live there.

## Established state (do NOT re-derive; all committed)
- **EXACT identity:** J_N(uniform) = tri(QᵀXQ) over [e₀ | V₂]; downdate algebra
  explicit with Xe₀ = √(m₂/N)·w₀; α^U/β^U formulas in {g, a, b, m₁, m₂} verified
  1e−13; **horizon J(N) = 3.2√N sharp** (s²-floor).
- **Deviation identity (per-point exact):**
  α^U_{j+2} − a_j = [g_j²(a_j + η_j) + 2g_jg_{j−1}b_{j−1}]/s²_{j+1}, η-recursion
  one line. Crude bound explicit; measured 9–27× slack = the alternating-sign
  cancellation.
- **g-profile (measured):** g_j = ⟨e₀, w_j⟩; Σg² = 1; **sign(g_j) = (−1)^j at every
  j and N**; mass at j ≈ 0.8√N; tail |g_j| ~ j^{−3}; g₀ = 1.22/√N-class.
- **ODD block closed form:** α^O_j = 1/((4j−3)(4j−1)) + 1/((4j−1)(4j+1)),
  β^O_j = 1/((4j+1)√((4j−1)(4j+3))); ODD = x·companion (one FORWARD Christoffel
  step); companion OP values elementary (Riccati–Bessel, Theorem B1).
- Kernel side (Stage B): κ-transfer 0.9–2.6%, caustic clean ~N^{−1/2}, O(0.7)
  redistribution = the g-profile (item 1b closed).
- SIX float-traps live — see RESULTS session-2 for the newest (recurrence genus;
  spot-checks must cover the EDGES).

## The task, in order
1. **(b) the g-lemma — closed form and/or alternation.** g_j ∝ Σ_n x_n p^O_j(x_n).
   Route: (i) express p^O_j through the companion OPs via the forward Christoffel
   step (CD-kernel formula for x·dμ — stable direction, standard); (ii) the sum
   becomes a Dini-type Bessel series over z_n = (n−½)π — evaluate with the SAME
   string-Parseval machinery as Theorem B1(iii) ({√2cos z_nt}, {√2sin z_nt} ONBs of
   L²(0,1)); (iii) targets, in decreasing strength: exact g_j(N); or the ∞-profile
   γ_j = lim √N·g_j closed + sign; or at minimum PROVE sign(g_j) = (−1)^j and
   |g_j| decay. Verify EVERY intermediate identity numerically before composing
   (the discipline caught a sign error in session 4 — it will catch yours too).
2. **The sharp split lemma.** Plug alternation + decay into the deviation identity:
   the two leading terms carry opposite signs, so |dev| ≤ explicit-with-cancellation;
   state **THEOREM-M1: J_N(uniform) = bordered ODD-Lambert, explicit constants,
   horizon 3.2√N** — with grades per ingredient (exact identity / closed forms /
   g-lemma / finite-numeric margins).
3. **(c) the ODD-truncation moment lemma (= G-M3).** |a_j(N) − a_j^∞|-class bounds
   from the explicit moment tails (Σ_{n>N}x_n^k ≤ x_N^{k−1}·tail); perturbative;
   if it closes, flip G-M3 and state the unified finite-N-vs-canonical-completion
   lemma (also answers the Q2-audit's Task-1 residue).
4. Ledger updates (G-M1 → THEOREM if 2 lands; G-M3 tag; spine; propagation grep —
   search the ledger for both gap names before ending), RESULTS, PLAN state block.
5. **Stage C decision (Selina's):** if 2+3 land, the campaign is send-ready — dated
   `to_Ilya_M1_*` package + the G4 note (the even/odd Lambert dictionary is direct
   input to his identification question; the g-lemma, if unproven, is a clean
   one-afternoon dispatch for him — offer it, don't pre-assign).

## Flagged observation — TESTED 2026-07-21 (session 5; see RESULTS)
**Outcome: production arrowhead CONFIRMED verbatim (machine zero, both measures);
V is HEAD-SUPPRESSED, not head-free** — head entries 5–9% of ‖V‖-scale (V₁₁ =
(m₁F−m₁D)/N exact identity, ~1/N); deep block = shifted ODD-difference at leading
order with 15–30% median corrections, ALL exact via the downdate algebra. The
escaping-state pathology does not dominate the pin's object. G4 guidance: build
the V-limit on the ODD-difference principal term + explicitly-controlled
head/coupling corrections. (This block kept as the record of the conjecture and
its honest refinement.)

## Traps (all six live; pointers)
1–5: see the caustic package task files (rational forms; Miller only; exactness
leaks; garbage-finite scipy; divergent-integral). 6 (NEW, session 2): recurrence
evaluation of orthonormal OPs explodes at edges/deep cluster in float64 — values
from Lanczos V-columns only; FD-of-the-map for derivatives; SPOT-CHECKS MUST COVER
THE EDGES. For the closed-form work: sympy exact discipline (cancel + numer/denom,
never nsimplify exact data). Check CPU contention before long runs.

## Suggested opening prompt for the next context window
> M1 continuation — the g-lemma session. Read first:
> T2_M1_weight_transfer_2026-07-19/NEXT_SESSION_TASK_g_alternation.md, then RESULTS
> (four entries) and the stageA2 script header in the same folder. Task: derive the
> closed form / alternation of g_j = <e0, w_j> via the Christoffel step + string
> Parseval (Theorem B1 machinery, K1K2 folder, read-only); then assemble THEOREM-M1
> (sharp split lemma, horizon 3.2 sqrt(N)); then the ODD-truncation moment lemma
> (= G-M3). Verify every identity numerically before composing; grep the ledger for
> G-M1/G-M3 propagation before ending; negative results are results. Not RH/GRH.
> Don't touch sealed folders.
