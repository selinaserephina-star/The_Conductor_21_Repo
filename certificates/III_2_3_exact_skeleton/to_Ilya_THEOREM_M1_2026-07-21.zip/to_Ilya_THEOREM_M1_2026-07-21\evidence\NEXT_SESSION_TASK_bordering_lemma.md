# NEXT SESSION TASK — the bordered-perturbation lemma (Stage A) + the K1-kernel consequence (Stage B)

**[SUPERSEDED 2026-07-19 (end of day): Stage B, the arrowhead identity, the downdate
algebra, and item 1b were ALL EXECUTED (campaign sessions 2–4; see RESULTS). The live
staging is now `NEXT_SESSION_TASK_g_alternation.md`. Kept for the record.]**

**Campaign `T2_M1_weight_transfer_2026-07-19/` · staged 2026-07-19 (end of session 1) ·
not RH/GRH.**

## Read first (in this order)
1. `M1_lambert_pattern_note_2026-07-19.md` — the confirmed pattern, closed forms, and
   the measured 1/N law. Do NOT re-derive; the script is the certificate.
2. `PLAN.md` this folder (Stages A/B/C).
3. Ledger `../LEDGER/EVIDENCE_CHAIN_T2_pin.md`: G-M1 (retargeted), G-M3 (the sibling
   gap — attack together), the spine paragraph, and the Q2-audit §9 entry (its Task-1
   "canonical completion" question is a likely corollary of Stage A).
4. For Stage B: the caustic package's (F10)/(F11) blocks (the kernel objects the
   bordering must not disturb) — `../to_Ilya_CAUSTIC_THEOREM_2026-07-19/evidence/`
   D2 note §7 (read-only; cite, don't touch).

## Established state (do NOT re-derive)
- J_N(uniform) = head(m₀ = N) ⊕ ODD-Lambert block + O(1/N) flat in j; all closed
  forms and exact anchors per the note; head identities are Lanczos-exact.
- Moment tails are explicit: m_k(N) − m_k^∞ = −Σ_{n>N}x_n^k, |·| ≤ x_N^{k−1}·Σ_{n>N}x_n
  ~ (π²)^{1−k}N^{1−2k}-class — the perturbation input for Stage A.
- G-M3's measured drift 0.33·k/2M and the Q2-audit's β-truncation rate 0.008·k/2M are
  DIFFERENT observables (value-law vs coefficient-law — the audit's variable-discipline
  note); do not conflate when unifying.

**[UPDATE 2026-07-19, Stage B EXECUTED same day (session 2 — see RESULTS):** κ-level
transfer CONFIRMED (0.9–2.6% at N = 400, caustic window clean at ~N^{−1/2});
HONEST SURPRISE: an O(0.7) N-stable PS-difference component mid/deep (head-projector
redistribution) — so Stage A's lemma must carry a SPLIT statement (transfer at the
caustic + sup locations; O(1) smooth redistribution elsewhere), NOT row-uniform
O(N^{−1/2}). SIXTH float-trap recorded: forward-recurrence OP evaluation explodes at
edges/deep cluster; kernels = centered FD of the Lanczos map; spot-checks must cover
the edges. Stage B item 3 below is DONE; remaining = Stage A (split form) + the
redistribution-term characterization.]**

## The task, in order
1. **Stage A (the lemma, SPLIT form per the Stage-B result).** Prove: for the string
   atom system, |α_{j+1}(N) − α^O_j| + |β_{j+1}(N) − β^O_j| ≤ C/N for j ≤ J(N), with
   explicit C and the widest honest J(N). Route: moment-perturbation → Jacobi
   stability on compactly-supported determinate systems (the ODD block has spectrum
   in [0, x₁]); the head row enters as a rank-one bordering with coupling
   β₁ = √(m₂/N). Verify every intermediate inequality numerically at N = 200/400/800
   BEFORE composing. Measure J(N)'s actual breakdown point (where does the 1/N
   flatness fail? j ~ √N? ~N?) — the measured law GATES the lemma statement.
1b. **Characterize the redistribution term** (the Stage-B surprise): identify the
   O(0.7) mid/deep PS-difference component as the head-projector mass profile
   (predict: PS(diff) ≈ the extra spectral direction's cumulative weight; test
   against the Lanczos head eigenvector directly). If confirmed, the split lemma's
   second term is a PROJECTOR statement, not a kernel estimate — likely easier.
2. **Unify with G-M3** (finite-M truncation): state one lemma covering both if the
   mechanism is the same (moment-tail perturbation); if not, record why not.
3. **Stage B (kernel consequence).** Compute uniform-N kernel rows K_j(n) and
   ODD-block kernel rows at matched j (j = 8..64, N large); measure the difference's
   partial-sum profile at the κ-level. Expected: O(N^{−1/2}) from the head coupling,
   localized at the spectrum bottom, NOT at the caustic — verify, then state:
   uniform-K1 = ODD-K1 + explicit head term, and the (F10) theorem transfers with the
   SAME a_∞. If the head DOES reach the caustic: that is a result — record it.
4. Ledger updates (G-M1/G-M3 tags, spine), RESULTS entries, commit. If A+B close →
   Stage C (dated send; Selina decides) + G4 note to IB (the even/odd dictionary).

## Traps
1. All five float-trap lessons live (caustic package task files) — esp. exactness
   leaks in sympy and the boundary-layer ≠ tail separation when measuring J(N).
2. The Hankel/moment→Jacobi direction is exponentially ill-conditioned in float —
   if Stage A needs it numerically, use mp at high dps and certify a-posteriori;
   NEVER trust float64 Hankel beyond j ~ 8.
3. Lanczos full-reorthogonalization is load-bearing at j ≳ 20 (checked in session 1);
   keep it.
4. Frozen/sent folders read-only; continuation work lands HERE.

## Suggested opening prompt for the next context window
> G-M1 continuation — the bordered-perturbation lemma. Read first:
> T2_M1_weight_transfer_2026-07-19/NEXT_SESSION_TASK_bordering_lemma.md, then the
> pattern note and PLAN in the same folder. Task: Stage A — prove the O(1/N)
> bordered-perturbation lemma (measure J(N)'s breakdown first; it gates the
> statement), unify with G-M3 if the mechanism matches; Stage B — the K1-kernel
> consequence through the bordering (expect head-localized O(N^(-1/2)), caustic
> untouched — verify, don't assume). Verify every inequality numerically before
> composing; negative results are results; update ledger + RESULTS before ending.
> Not RH/GRH. Don't touch sealed folders.
