# t2_m1_stageB_kernel_bordering.py — Stage B of the M1 campaign: does the head row's
# coupling disturb the K1 kernels at the caustic? Session 2 of the campaign, 2026-07-19.
# REWRITTEN after a trap hit (recorded in RESULTS): evaluating orthonormal OPs and
# derivatives by forward three-term recurrence EXPLODES in float64 at the spectrum edge
# and in the deep atom cluster (values 1e26+ where the Lanczos-matrix bound |p_j(x_n)|
# <= sqrt(N) proves the truth is bounded) — exactly the K1K2 memory's warning. The
# kernels here are computed as CENTERED FINITE DIFFERENCES OF THE LANCZOS MAP itself
# (alpha_j is a stable output of stable Lanczos with full reorthogonalization) — slow
# but trap-free; verified by two-h self-consistency.
#
# Question: J_N(uniform) = head(m_0 = N) + ODD-Lambert block + O(1/N) (session 1).
# Does K^unif_{j+1} - K^ODD_j stay away from the caustic (n* = 2j/pi) at the
# kappa-level? If yes: uniform-K1 = ODD-K1 + head term, and the (F10) caustic theorem
# transfers to the production normalization with the SAME a_inf.
import numpy as np

def lanczos_alphas(x, wts, m):
    v = np.sqrt(wts / np.sum(wts))
    al, be, Vs = [], [], [v]
    w = x * v
    a0 = v @ w; al.append(a0); w = w - a0 * v
    for j in range(1, m):
        b = np.linalg.norm(w)
        if b < 1e-14: break
        be.append(b)
        vn = w / b
        for u in Vs: vn = vn - (u @ vn) * u
        vn /= np.linalg.norm(vn)
        Vs.append(vn)
        w = x * vn - b * Vs[-2]
        aj = vn @ w; al.append(aj); w = w - aj * vn
    return np.array(al), np.array(be)

def fd_kernels(x, wts, m, hrel=1e-4):
    """K[j][n] = d alpha_j / d x_n by centered FD; h_n = hrel * local gap (stays in
    the derivative regime even in the deep cluster)."""
    Nn = len(x)
    gaps = np.empty(Nn)
    gaps[:-1] = np.abs(np.diff(x)); gaps[-1] = gaps[-2]
    gaps = np.minimum(gaps, np.abs(x))            # never step across 0
    K = np.zeros((m, Nn))
    for n in range(Nn):
        h = hrel * gaps[n]
        xp = x.copy(); xp[n] += h
        xm = x.copy(); xm[n] -= h
        alp, _ = lanczos_alphas(xp, wts, m)
        alm, _ = lanczos_alphas(xm, wts, m)
        K[:, n] = (alp[:m] - alm[:m]) / (2 * h)
    return K

print("=== (B1) trap record + machinery verification ===")
print("  TRAP (recorded): forward-recurrence OP evaluation exploded (1e26+ at the edge")
print("  where |p_j(x_n)| <= sqrt(N) is provable from Lanczos orthogonality) — the")
print("  K1K2 memory's float64 warning re-confirmed. Kernels below = FD of the Lanczos")
print("  map; verification = two-h self-consistency:")
N0 = 200
z = (np.arange(1, N0 + 1) - 0.5) * np.pi
x0 = 1.0 / z ** 2
K_a = fd_kernels(x0, np.ones(N0), 26, hrel=1e-4)
K_b = fd_kernels(x0, np.ones(N0), 26, hrel=3e-4)
scale = np.maximum(np.max(np.abs(K_a), axis=1, keepdims=True), 1.0)
print(f"  uniform N = 200, j <= 26: max rel(two-h) dev = "
      f"{np.max(np.abs(K_a - K_b) / scale):.2e};  max|K| = {np.max(np.abs(K_a)):.3e}"
      f"  (genuinely large deep-cluster sensitivities are HONEST here)")

print("=== (B2) kappa ladders at matched rows (bordering shift: unif j+1 <-> ODD j) ===")
KAP = {}
for N in [100, 200, 400]:
    z = (np.arange(1, N + 1) - 0.5) * np.pi
    x = 1.0 / z ** 2
    JM = 34
    KU = fd_kernels(x, np.ones(N), JM + 1)
    KO = fd_kernels(x, x ** 2, JM + 1)
    KAP[N] = (KU, KO, x)
    line = []
    for j in [8, 16, 24, 32]:
        # kappa = max over both branches (fwd head-sums and rev tail-sums), F7 protocol
        kU = max(np.max(np.abs(np.cumsum(KU[j]))), np.max(np.abs(np.cumsum(KU[j][::-1]))))
        kO = max(np.max(np.abs(np.cumsum(KO[j - 1]))), np.max(np.abs(np.cumsum(KO[j - 1][::-1]))))
        line.append(f"j={j}: {kU:7.3f}/{kO:7.3f}")
    print(f"  N = {N}:  " + "   ".join(line))
print("  [sanity: O(1)-to-j^(1/3) class values, NOT 1e58 — the FD route is clean]")

print("=== (B3) the kernel-row DIFFERENCE: partial sums, N-scaling, localization ===")
for N in [100, 200, 400]:
    KU, KO, x = KAP[N]
    print(f"  N = {N}:")
    for j in [8, 16, 32]:
        d = KU[j] - KO[j - 1]              # matched rows: unif alpha_{j+1} vs ODD alpha_j
        ps = np.cumsum(d)
        sup = np.max(np.abs(ps))
        nstar = max(1, int(round(2 * j / np.pi)))
        hw = max(2, int(round(3 * (2 * j + 0.5) ** (1 / 3))))
        caus = np.max(np.abs(ps[max(nstar - hw - 1, 0):nstar + hw]))
        i_sup = int(np.argmax(np.abs(ps))) + 1
        print(f"      j={j:2d}: sup|PS(diff)| = {sup:.4f} at n = {i_sup}"
              f"  |  at the caustic window: {caus:.4f}  (n* = {nstar}, hw = {hw})")
print("  [prediction: sup ~ N^(-1/2)-class, sitting at the HEAD (small n), caustic clean]")
print("done.")
