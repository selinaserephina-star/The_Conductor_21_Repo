# g-lemma, step (b): endpoint convergence of the string sine series — written out (THEOREM-M1 part III, final pending line)

**Merkabit · Stenberg + Claude · 2026-07-21 (session 9 of the campaign). Every numbered
line verified in `t2_m1_glemma_stepB_check.py`. With step (a)
(`M1_glemma_stepA_Poisson_sign_2026-07-21.md`) this COMPLETES the proof of the
identity Σ_{n≥1}(−1)^{n+1}j_{2j+1}(z_n) = (−1)^j/2 — the g-lemma is PROVEN (modulo
one textbook citation, Dirichlet–Jordan). Not RH/GRH.**

## Claim

For f = P_{2j+1} (any j ≥ 0), the string-basis series converges at the free endpoint:

  **[S_N f](1) := Σ_{n≤N} 2⟨sin(z_n·), f⟩_{L²(0,1)} sin(z_n·1) → f(1) = 1**,  (★b)

with the quantitative rate |[S_N f](1) − 1| = (k(k+1)/π²)·N^{−1}·(1 + o(1)),
k = 2j+1.

## Proof

**(B1) The reflection construction.** Extend f to F̃ on ℝ: odd about t = 0, even
about t = 1 (hence 4-periodic: F̃(t) = f(t) on [0,1], f(2−t) on [1,2], −F̃(−t),
period 4). The string modes sin(z_nt) = sin((2n−1)(π/2)t) are precisely the
odd-harmonic sine modes of period 4, and each is even about t = 1
(sin((2n−1)(π/2)(2−t)) = +sin((2n−1)(π/2)t), since cos((2n−1)π) = −1); the
even-harmonic modes sin(nπt) are odd about t = 1 and therefore have ZERO Fourier
coefficient against the even-about-1 function F̃. **Consequently the half-range
series S_N f on [0,1] IS the (4-periodic) Fourier sine series of F̃, truncated to
its first N (odd) harmonics.** [Verified as a machine identity: partial sums of the
two constructions agree to 1e−15 at several (f, N).]

**(B2) Regularity of the extension.** For f = P_{2j+1}: f(0) = 0 (odd Legendre
polynomials vanish at 0 — sympy-exact), so the odd extension is CONTINUOUS at t ≡ 0
with matching derivative (odd extension of an odd-symmetric germ); at t ≡ 1 the even
reflection is continuous with a derivative sign-flip (a corner, since
f′(1) = k(k+1)/2 ≠ 0). Hence F̃ is continuous and piecewise-C¹ on the circle.

**(B3) Pointwise convergence** [Dirichlet–Jordan, textbook]: the Fourier series of a
continuous, piecewise-C¹ periodic function converges to it at every point (uniformly,
in fact). At t = 1: [S_N f](1) → F̃(1) = f(1) = P_{2j+1}(1) = 1. ∎ (★b)

**(B4) The quantitative rate** (two integrations by parts; also fixes the tail law
used since session 6): with c_n = ∫₀¹ f(t)sin(z_nt)dt and f(0) = 0,

  c_n = (−1)^{n+1} f′(1)/z_n² − z_n^{−2}∫₀¹ f″(t) sin(z_nt) dt,

so the endpoint tail is Σ_{n>N} 2(−1)^{n+1}c_n = 2f′(1)·Σ_{n>N}z_n^{−2} + (f″-term,
one order smaller by another IBP) = (2f′(1)/π²)·N^{−1}(1+o(1)). With P′_k(1) =
k(k+1)/2 [sympy-exact]:

  **1 − [S_N P_k](1) = (k(k+1)/π²)·N^{−1}·(1 + o(1))**,

and via step (a)'s factor ½, the identity's finite-sum deviation is
k(k+1)/(2π²N)(1+o(1)) — EXACTLY the tail law that matched the session-6
measurements at every j (e.g. j = 40: predicted 0.0464 vs measured 0.0464).

## What is now proven

Chaining (a) + (b): **Σ_{n≥1}(−1)^{n+1} j_{2j+1}(z_n) = (−1)^j/2 for every j ≥ 0 —
PROVEN** (ingredients: DLMF 10.54.2, parity, the sign line (−i)^{2j+1}i = (−1)^j,
the reflection identity (B1), Dirichlet–Jordan (cited), P_k(0) = 0, P_k(1) = 1),
with the quantitative finite-N rate (B4). Hence the ALTERNATION sign(g_j) = (−1)^j
and the closed form g_j ≈ (−1)^j√((4j+3)/2N) hold at PROVEN grade in the range where
the map g ↔ Bessel-sum is exact (low j; the finite-N OP-truncation correction is
part IV's lemma). THEOREM-M1 part (III): the two classical write-ups are DONE.
