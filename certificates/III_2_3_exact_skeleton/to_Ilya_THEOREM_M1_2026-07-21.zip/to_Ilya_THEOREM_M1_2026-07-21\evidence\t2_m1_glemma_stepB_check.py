# t2_m1_glemma_stepB_check.py — line-by-line verification of step (b)
# (M1_glemma_stepB_endpoint_2026-07-21.md). Session 9, 2026-07-21.
import numpy as np
import sympy as sp
from scipy.special import eval_legendre
from scipy.integrate import quad

print("=== (B1) reflection identity: half-range series == period-4 odd-harmonic series ===")
# [S_N f](t) on [0,1] vs the Fourier construction on the 4-periodic extension F~
def Ftilde(t, k):
    t = np.mod(t + 2.0, 4.0) - 2.0            # into [-2, 2)
    s = np.sign(t); t = np.abs(t)             # odd about 0
    t = np.where(t > 1.0, 2.0 - t, t)         # even about 1
    return s * eval_legendre(k, t)
worst = 0.0
for k in [3, 7]:
    for N in [8, 40]:
        zn = (np.arange(1, N + 1) - 0.5) * np.pi
        tg = np.array([0.3, 0.77, 1.0])
        half = np.zeros_like(tg)
        four = np.zeros_like(tg)
        for i, w in enumerate(zn):
            c_half = quad(lambda t: eval_legendre(k, t) * np.sin(w * t), 0, 1, limit=400)[0]
            half += 2 * c_half * np.sin(w * tg)
            # period-4 Fourier sine coefficient of F~ over [0, 2], mode sin(w t):
            c_four = quad(lambda t: Ftilde(t, k) * np.sin(w * t), 0, 2, limit=400)[0]
            four += c_four * np.sin(w * tg)    # (2/2)=1 normalization on [0,2]
        worst = max(worst, np.max(np.abs(half - four)))
        # even harmonics vanish against F~:
        ev = quad(lambda t: Ftilde(t, k) * np.sin(2 * np.pi * t / 2), 0, 2, limit=400)[0]
        worst = max(worst, abs(ev))
print(f"  (k, N) grid + even-harmonic vanishing: max |dev| = {worst:.2e}   [IDENTITY]")

print("=== (B2) regularity inputs: P_k(0) = 0 and P_k'(1) = k(k+1)/2 (sympy-exact) ===")
t = sp.symbols('t')
ok = True
for j in range(6):
    k = 2 * j + 1
    Pk = sp.legendre(k, t)
    ok &= (Pk.subs(t, 0) == 0)
    ok &= sp.simplify(sp.diff(Pk, t).subs(t, 1) - sp.Rational(k * (k + 1), 2)) == 0
print(f"  P_(2j+1)(0) = 0 and P'_k(1) = k(k+1)/2, j <= 5: {'EXACT — all hold' if ok else 'FAIL'}")

print("=== (B3) endpoint convergence measured against the (B4) rate ===")
print("      k      N     1 - [S_N P_k](1)     predicted k(k+1)/(pi^2 N)")
for k in [1, 3, 9, 21]:
    for N in [100, 400]:
        zn = (np.arange(1, N + 1) - 0.5) * np.pi
        c = np.array([quad(lambda t, w=w: eval_legendre(k, t) * np.sin(w * t),
                           0, 1, limit=400)[0] for w in zn])
        SN1 = np.sum(2 * c * np.sin(zn))
        pred = k * (k + 1) / (np.pi ** 2 * N)
        print(f"  {k:5d}  {N:5d}     {1 - SN1:+.3e}          {pred:.3e}")
print("  [ratio -> 1: the IBP rate is the truth; convergence to the endpoint value]")
print("done.")
