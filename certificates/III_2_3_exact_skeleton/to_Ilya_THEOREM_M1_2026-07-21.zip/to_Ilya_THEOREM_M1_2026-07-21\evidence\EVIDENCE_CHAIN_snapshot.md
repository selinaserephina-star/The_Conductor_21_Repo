﻿# EVIDENCE CHAIN — the T2 pin program, full proof ledger

**Merkabit · Stenberg + Claude (era 2, "middle Claude") · opened 2026-07-19.**
**[MOVED 2026-07-19 (Selina's reorganization): this living ledger now lives in
`LEDGER/`, next to `AUDIT_REGISTER.md` — the cross-stream record of receipts, audits,
and sends. From this move on, §9 below stays a PROOF log; package traffic goes to the
register. Relative paths in older entries are relative to the era-3 working folder
`T2_P1_completion_2026-07-19/`, where a pointer file remains. Snapshots of this ledger
inside sealed packages are frozen as-sent.]**
This is the LIVING master ledger of the T2 pin proof chain across its three eras:

- **Era 1** — operator program & stage 2.6 (first Claude: the operator skeleton was built
  in the COMPLETENESS-ENGINE session, the T2 stages ran in the skeleton/pin sessions, and
  stage 2.6 in the volhard worktree session); frozen record:
  `to_Ilya_operator_program_2026-07-18/` (zip SHA 16cd0374…521944).
- **Era 2** — K1/K2 → P1 → string/Bessel → D1 (this ledger's author);
  frozen record: `to_Ilya_K1K2_P1_program_2026-07-18/` (zip SHA 3b17a4f0…bb9cf)
  + working folder `T2_K1K2_kernel_bounds_2026-07-18/` (on main, complete).
- **Era 3** — D2 and onward (current sessions); working folder `T2_P1_completion_2026-07-19/`
  (this folder). **Era-3 sessions: append status updates in §9 and flip tags IN PLACE with
  a date — never edit the frozen packages; this file is the only living summary.**

**Primary working folders (on main; these hold the scripts/logs/tables the tags cite):**
- `Operator_program_addendum/` — the OPERATOR-DEFINITION home (reorganized 2026-07-19 from
  loose scripts): `operator_skeleton_hdv.py` — the script that CONSTRUCTS D and V, i.e.
  the object every layer below is about — plus `operator_skeleton_twin.py`,
  `gen_an_chi8.py` (Dirichlet coefficients), the 40-zero list, T3 twin table/log copies,
  and `resonance_spectrum_2026-07-18/` (moved here from `unbounded/`).
- `T2_pin_conjecture_2026-07-17/` — era-1 home: the T2 RESULTS ledger (all stage entries
  2.1–2.6 + K1/K2 + P1 session entries), `kato_pencil.py`, stage-22/22b/26 scripts, kato
  and frontier tables, `window_norm_knee.py`, `quantiles_production.csv` (original).
- `T2_K1K2_kernel_bounds_2026-07-18/` — era-2 home: all four era-2 notes (K1K2, R-, B-,
  D1), the t2_k1/k2/p1 scripts + run logs, `t2_k1_partial_sums.csv`, `t2_p1_model_zoo.csv`,
  and the mp-certified kernel caches `k1_kernels_k{k}_N{N}.npz` (regenerable).
- `T3_twin_skeleton_2026-07-17/` — era-1 control home: the twin experiment
  (`operator_skeleton_twin.py`, `zeros_twin_21_from_0628run.csv`, T3 comparison note/table)
  — supplies the twin local factors used by stage 2.4 and the object-identification verdict.
- `T2_P1_completion_2026-07-19/` — era-3 home: PLAN, RESULTS, D2 note + scripts, this ledger.
- The two `to_Ilya_*_2026-07-18/` folders are FROZEN snapshots for exchange, not working
  homes; cite them only for what was sent (SHAs above).

Not RH/GRH anywhere in this chain (see item 7.9 for where the wall stands).

## 0. Tag conventions

- **[PROVEN]** written proof exists at the cited location.
- **[PROVEN+VER]** proof + independent numerical verification (tolerance quoted).
- **[VERIFIED]** machine-verified identity at stated tolerance (proof mechanical/classical
  or given in-line; distinguishes from measured constants).
- **[MEASURED]** numerical value/profile, float64 or mp grade; no proof claimed.
- **[CERTIFIED]** interval/ball-arithmetic certificate (first entries 2026-07-21: the
  T2a session — sup|S_P|, sup|S_P'|, and the four PSD margins; see §9).
- **[REFUTED]** negative result — statement or route is false; measured or proven.
- **[GAP]** open statement, precisely posed at the cited location.
- **[LANE:IB]** with Ilya per the K1K2/P1 package menu (his priorities first).

Format per item: ID · statement · tag · where (file §) · evidence (script/log, tolerance).

## 1. Layer 0 — setting and data (era 1)

- **0.0** The operator itself: D = diag(x_n) and V = J(μ_F) − J(μ_D) constructed by
  `Operator_program_addendum/operator_skeleton_hdv.py` (imported by `kato_pencil.py` and
  the stage scripts) from the ladders of 0.1 and the Euler data of `gen_an_chi8.py`.
  [DEFINITION — the artifact every tag below refers to; twin variant
  `operator_skeleton_twin.py` for item 1.5.]
- **0.1** Quantile ladders: γ_n^D solves θ/π = n−½; γ_n^F solves θ/π + S_P = n−½ (P = 2×10⁵,
  18,120 terms); atoms x = 1/γ², uniform masses 1/M; production N = 149.
  [MEASURED — float64 ladder; THESE DEFINITIONS ARE THE FROZEN CERTIFICATE HYPOTHESES.]
  `to_Ilya_operator_program…/tables/quantiles_production.csv` (copies in both era-2 folders).
- **0.2** Data grade: production zeros numerical_anchored (γ1–24 certified separately,
  CHI8_FIRST24 closure); zeros used NOWHERE in the T2 ladder (Euler side only). [MEASURED]
- **0.3** κ(P) stability ~1% (stage 2.3). [MEASURED]

## 2. Layer 1 — the pin at production scale (era 1)

All layer-1 items: `T2_pin_conjecture_2026-07-17/RESULTS.md` (the stage ledger) + its
scripts/tables (`t2_stage22_production.py`, `t2_stage22b_frontier.py`,
`kato_table_production_drop{0,1,2,4}.csv`, `frontier_*.csv`, `window_knee_production.csv`):

- **1.1** Original pin (form-bound < 1 for FULL V): κ_full = 1.1822, flat m = 20..149.
  **[REFUTED]** stage-2.2 entry.
- **1.2** Tail pin: drop-k κ ∈ {0.431, 0.294, 0.309} flat in m. [MEASURED]
- **1.3** κ_tail(N) growth is b-TYPE (absorbable): fixed pairs (a,b) = (0.3, 0.011) drop-1,
  (0.3, 0.0001) drop-4 PSD-verified for all N ≤ 149; b_needed non-increasing in N; knee at
  b ~ D_min. [MEASURED — float64 eigenchecks] stage-2.2b-frontier entry.
- **1.4** Window-knee elbow at w ≈ 3, saturation < 1 for tail V; no S-norm can bound the
  top block (pointwise C = 1.37 > 1). [MEASURED] stage-2.5/2.2 entries; see gap G-E.
- **1.5** Twin control (stage 2.4): same D (Γ_ℂ⁴, N = 21¹⁰ preserved ⇒ D_twin ≡ D_genome),
  twin local factors ⇒ κ^twin = 0.3233 flat; genome/twin ratio 2.35 independently
  reproduces T3's ~2.4× twist-decoherence. **V is object-identifying (carries the
  arithmetic content); D is genome-blind.** [MEASURED — two independent routes agreeing]
  Home: `T3_twin_skeleton_2026-07-17/` (+ `kato_table_twin21.csv` in the era-1 home;
  T3 verdict note `T3_twin_V_comparison_2026-07-17.md`, copy in the operator package).
  Interpretive weight: this is why bounding V (not discarding it) is the program — the
  perturbation IS the genome signal, and the pin must tame it without erasing it.

## 3. Layer 2 — stage 2.6 trichotomy (era 1)

Note: `unbounded/LEMMA_tail_KLMN_attempt_2026-07-18.md` (on main; copies in both packages);
scripts + logs: `T2_pin_conjecture_2026-07-17/t2_stage26{,b,c,d}_*.py` and tables there:

- **2.1 Theorem A** (atom-map KLMN): a = ε_k, b = 0, positivity-transferring; ε₄ = 0.0569;
  per-n analytic bound 149/149. **[PROVEN+VER]**
- **2.2 Theorem B** (pencil factorization): V = Wᵀ(T(J_D)−J_D)W + R; ‖T(J_D)−J_D‖ =
  max|x^F−x^D| exact. **[PROVEN+VER 1.1e−15]**; ‖R‖ ≈ 0.009 drop-4, flat in N [MEASURED].
- **2.3 Theorem C** (basis-free/test-function route): κ_Q ≥ 1 from degree 3–5, ~1e31 full.
  **[REFUTED]** — do not revive.
- **2.4** Kernel sum rules ΣK^α = 1, ΣK^β = 0, x-weighted = α_j, β_j. **[PROVEN+VER 1e−6 FD]**
- **2.5** Identification-dependence of the KLMN pair (I/II/III table). [PROVEN by 2.1–2.3]
  → program question G4.

## 4. Layer 3 — K1/K2 kernel session (era 2)

`T2_K1K2_kernel_bounds_2026-07-18/K1K2_kernel_bounds_2026-07-18.md`:

- **3.1 Theorem 1** (exact kernel closed forms, uniform weights): K_j^α = w·Φ_j′(x_n),
  K_j^β = w·Ψ_j′(x_n); Φ_j = β_jp_jp_{j+1} − β_{j−1}p_{j−1}p_j, Ψ_j = (β_j/2)(p_{j+1}²−p_j²);
  boundary row via r′(x_n) = M/p_{M−1}(x_n). **[PROVEN+VER 5e−9…1e−7 (FD floor), ALL j,
  5 sections; sum rules 3e−15; column rule 4.4e−15]**
- **3.2** Naive conjecture K^α = q², K^β = qq: sum-rule-invisible but false pointwise
  (dev → 1.72). **[REFUTED]**
- **3.3 Theorem 2** (partial sums = projection ∈ [0,1] + derivative pairings). **[PROVEN]**
- **3.4** Cauchy–Schwarz route to K1: ν_j = β_j‖p_j′‖ ~ e^{cj} (9e73 at j = 54) vs partial
  sums ≤ 4.7. **[REFUTED]** — K1 is pure oscillation cancellation.
- **3.5** K1 with absolute constant: false beyond j ≈ 12; per-j flat in M; bulk ~0.5–0.6
  log(2+j) + ≤5-row boundary layer; range certificate κ̂ = 5.5956 (α) / 2.8598 (β), all
  j,m, both drops, N ≤ 149. [MEASURED — the T2a-range constants]
  [FLAG 2026-07-21 → RESOLVED-CONFIRMED same day (T2a session 3,
  `t2a_khat_regrade.py`): **κ̂ = 5.5956 CONFIRMED AT CERTIFIED BALL GRADE** — deep
  rows j = 135..144 match the frozen npz to 4 decimals; boundary row via the exact
  trace identity K_M = 1 − Σ_{j<M}K_j reproduces 5.5956; sum rules ball-zero on ALL
  rows; shallow validation 2.7e−15. The float64 record was RIGHT: the sum-rule
  structure protects the kernels even where raw entries sit at the noise floor.
  NEW CERTIFIED FACT: production boundary (5.60 at ℓ = 1) is ~8× milder than the
  generic Chebyshev law (46.15) — quantile-structure mildness certified. Item 3.5
  upgrades: κ̂ [MEASURED → CERTIFIED].]
- **3.6 Theorem 3 / (L-ORD)**: linear transport segments preserve atom ordering
  (gap_n(s) ≥ min endpoint gaps); replaces the |S| < 1 safety condition. **[PROVEN]**
- **3.7** K2 remainder: ‖V − V^lin‖ ≤ ½sup_s|J″| per entry. **[PROVEN structure;
  MEASURED constants, ≥2× margin, quality 8–25%; stencil consistency 1e−3]**
- **3.8** Abel assembly |dα_j| ≤ κ_j(TV(dx)+|dx_M|) + ½sup|α_j″|: holds all j, 3 sections.
  **[PROVEN inequality; VERIFIED on data]** Loss 5× (peak rows) to 26× (uniform).

## 5. Layer 4 — spectral reduction and models (era 2)

`…/P1_spectral_reduction_2026-07-18.md`:

- **4.1 Theorem R1** (cut eliminated): C_j(m) = Σ_{i≤min(2j,M−1)}ĥ_i^{(j)}ĉ_i(m); ĥ_0 = 0;
  Σĉ² = m/M. **[PROVEN+VER 1.3e−15 bandwidth, 2.7e−15 reconstruction]**
- **4.2 Theorem R2** (assembly): κ_j ≤ 1 + a₃W_j; (P1a) + (P1b) ⇒ log-law. **[PROVEN]**
  (Caveat: absolute-value assembly not order-sharp for arcsine-type measures.)
- **4.3 Theorem R3** (Chebyshev model SOLVED): p_j = √2T_j exact; K_j = [(2j−1)T_{2j} +
  U_{2j}]/M (ver 3.7e−13); bulk |PS| < 2.77 via Fejér–Jackson (measured = 1.000);
  boundary κ_{M−ℓ} ≍ M/(πℓ) — blow-up PROVEN (measured 41.02 vs M/π = 40.74).
  **[PROVEN+VER]** ⇒ mild boundary is quantile structure, NOT generic.
- **4.4** Zoo: 1/n² hard-edge model reproduces production to 3 digits (a₃ 2.223/2.225,
  boundary resonance i* 60/59, bulk slope 0.50/0.57). [MEASURED]
- **4.5** (P1a) uniform-system constant a₃ = 2.225 (N=149). [MEASURED]
- **4.6** Verified per-section bound κ_j ≤ 1 + Σ|ĥ_i|sup_m|ĉ_i| within 1.76× of κ̂.
  **[PROVEN inequality; VERIFIED]**

## 6. Layer 5 — the string, the companion, D1 (era 2)

`…/P1_string_bessel_2026-07-18.md`, `…/P1a_companion_theorem_2026-07-18.md`:

- **5.1** The pure model is the uniform Neumann–Dirichlet string: θ/π = n−½ ⇒ z_n = (n−½)π;
  sharpened model matches production (a₃ 2.221/2.225, i* 60/59). [MEASURED]
- **5.2 Theorem B1** (companion EXACTLY SOLVED): μ_L = Σ2x_nδ (mass 1 exact);
  G_L(y) = tan(1/y); Lambert CF ⇒ β_k = 1/√((2k−1)(2k+1)) exact; value law
  ŝ_k(1/z_n) = √((2k+1)π/2)(−1)^{n+1}√z_nJ_{k+½}(z_n); normalization via Poisson +
  Parseval in string eigenbases (Dini sum = 1/((2k+1)π)). **[PROVEN+VER: b₁√3 = 1.00000000;
  value law rel std 9.5e−7, constant 1.000010; Dini 1e−10 odd k; truncation drift ≈ 0.33k/2M
  measured]**
- **5.3 Theorem B2** (Christoffel transfer x·μ_U ∝ μ_L): p^L_i = c_i[p^U_{i+1} − r_ip^U_i]/x.
  **[PROVEN+VER 2.6e−14, i ≤ 45]**; transfer sequences r_i → −1.15…−1.19, c_i ≈ 0.013/i
  [MEASURED].
- **5.4 Lemma A** (cut regimes): |ĉ_i(m)| ≤ min(√(m/M),√(1−m/M)); super-polynomial decay
  for i ≳ Cm² (Jackson through the cut gap). **[PROVEN]**
- **5.5 THEOREM D1** ((P1a)-companion): exact representation ĉ^L_i(m) = (−1)^{m+i+1}/√(4i+1)
  ·∫₀¹[sin(mπt)/cos(πt/2)](P_{2i+1}−P_{2i−1})dt; L¹ bound L(k) ≤ 3/k + 10c₁/√k ⇒
  **sup_m(1+i)|ĉ^L_i(m)| ≤ 1.263.** **[PROVEN+VER: representation 2.3e−15; √k·L(k) ≤ 3.065;
  true constant 0.783 measured (theorem not sharp — data ~ (1+i)^{−1.45})]**

## 7. Layer 6 — D2, era 3 (ACTIVE — `T2_P1_completion_2026-07-19/`)

`D2_progress_bessel_kernels_2026-07-19.md` + RESULTS.md this folder:

- **6.1 Theorem 1′** (kernel closed forms, GENERAL fixed weights — uniformity never used).
  **[PROVEN (verbatim carry) + VER 4e−7/1.3e−6 FD floor; sum rules 1.6e−15]**
- **6.2** (P1b) as W-log for the companion: W_j ≈ 0.85j LINEAR while κ_j stays log.
  **[REFUTED]** — the ĥ/ĉ absolute split discards companion sign cancellation; W-log is a
  uniform-weights phenomenon. D2 retargeted to direct C_j bound.
- **6.3** V1 global value law ŝ_k = √(2k+1)R_{k,½}(1/y), Bessel form
  √(πz/2)[J_{k+½}sin z − Y_{k+½}cos z]. **[VERIFIED 3.1e−14; derivation in note §1]**
- **6.4** V2 derivative law at atoms (second-kind Y enters). **[VERIFIED 1.8e−6 FD floor;
  derivation in note §1, hand-checked k=1 exact]**
- **6.5** V3 kernel closed form K_j(n) = 2πμJ_μ²/z − (π/2)z²[W_j − W_{j−1}], and the
  RATIONAL form (A_k = R_{k,½}, B_k = R_{k−1,3/2} values; no oscillatory evaluation).
  **[VERIFIED: finite-M deviation halves 64→128 (= 1/M truncation); derivation from
  6.1 + 5.2 in note §1]** The e^{cj} cancellation = J_{μ−1} + Y_μ = O(z^{−3/2}), one line.
- **6.6** Infinite-system profile κ_j = 0.386 + 0.382·log(2+j), j ≤ 192; sup at turning
  point (m* ≈ 0.66j); per-row drift flags ≤ 4e−2; unscanned tail ≈ 0.231 const (away from
  sup). [MEASURED → SUPERSEDED 2026-07-19 (F7/F8): the log fit was pre-asymptotic; the
  certified-row law is κ_j = 1 + E_j, E_j ≈ 0.131·j^{1/3}(ln j)^{1/2} (flat ±2%,
  j = 256–8192, m* = 2j/π exactly); tail constant → 2/π² = 0.2026 exactly; the j ≤ 192
  table VALUES stand, the fit line and the 256–512 hybrid extensions do not (fourth
  float-trap). See D2 note §7 (F7)/(F8) + §9 entries below.]
  [SECOND SUPERSESSION same day, (F9)/(F10): the √log refinement above was ITSELF a
  finite-size mimic (refuted out-of-sample at j = 16384) — the FINAL law is the
  THEOREM κ_j = 1 + a_∞μ^{1/3} + R_j, a_∞ = 2^{2/3}3^{−5/6}/Γ(2/3)² derived,
  −1.1 ≤ R_j ≤ 0.5 explicit (j ≥ 512). No log anywhere, in leading OR subleading
  order. Read (F10); this line is the end of 6.6's chain of corrections.]
- **6.7** Zone-(ii) toolbox, all machine-exact: **Z1** product-comb lemma j_aj_b =
  (±½)∫₀²(P_a∗P_b)·cos/sin(zτ)dτ, {cos(z_nτ)} orthonormal on (0,2) (4.8e−16);
  **Z2** Wronskian telescope cancellation (5e−18); **Z3** Casoratian A_{k+1}B_k − A_kB_{k+1}
  = −1 (2.8e−16 rel); **N0** Y_ν = −J_{−ν} (0.0); **N1/N2** second elementary cancellation
  (1e−18) — Y-content = J_{ν+1}Y_ν, J_νY_ν only; **N3** Neumann reps with FIXED J₀/J₁
  kernels, j-dependence only in cosine frequency (9e−16); **N4** doubled-string Dirichlet
  kernel (1.1e−13). **[VERIFIED; proofs classical/one-line, assembled in note §5–6]**
- **6.8** Z4: the JJ/Y split re-introduces the cancellation (parts ~2485 vs total ~0.5):
  E_ν = J_{ν−1} + Y_ν is ATOMIC. **[REFUTED route — binding constraint on any proof]**
- **6.9** F_j(τ) := Σz²ΔW·cos(z_nτ) reconstructed (j = 4, 8): antisymmetric about τ = 1
  (2e−15); **boundary values vanish** (⇒ boundary-free IBP applies, as in D1); amplitude
  decays in j; NOT low-degree polynomial (fit resid ~0.9). [MEASURED/VERIFIED]
- **6.10** Numerical-stability lemma-of-experience: far-tail trig evaluation accumulates
  ~1e−9·z phase noise (spurious κ ~ 240 caught); the rational form is both the provable
  and the stable representation. [RECORDED]

## 7b. Adjacent evidence lines (feed the chain; not on the pin's critical path)

- **T1 — finite-range positivity** (`t1_hankel_ledger.py`, `t1_li_positivity.py` + note in
  the operator package): Hankel m ≤ 40 all > 0; Li LB(n) > 0 for n ≤ 150, 270× margin.
  [MEASURED] This is what the pin's positivity-transfer (G4, atom map b = 0) would connect
  to in the limit — the REASON identification matters.
- **Completeness/Turing line** (`chi8_certified_zeros_MASTER…`, CHI8_FIRST24 closure,
  rescaled-FFT engine): certified γ1–24, B = 57.89 Turing constant, certified-∫S machinery.
  [CERTIFIED (Ilya's pipeline) / MEASURED] Supplies the unconditional-S inputs for G-C1/C2
  and the future longer-list frontier reruns (2.2b(ii)) — the latter gated UPSTREAM by two
  pending engine items from the turing24 gate response: the (26, 28] amplitude-guard patch
  and the second-η channel. 2.2b(ii) does not open until those land.
- **Resonance spectrum** (`Operator_program_addendum/resonance_spectrum_2026-07-18/`;
  moved from `unbounded/` in the 2026-07-19 reorganize): overtone lines resolve at
  production scale, Frobenius coefficients at ~1%. [MEASURED] Independent evidence the
  production list carries the genome's arithmetic — same role as 1.5, from the spectral
  side.
- **Margin/Li-fluctuation identity** (`unbounded/MARGIN_curve_geometry_vs_primes_2026-07-17.md`
  + `MARGIN_curve_UPDATE_40zeros_tailcorrected_2026-07-17.md`; copies in the operator
  package): the exact split ∫w_n dΦ = λ_n^arch ⇒ λ_n^fin = ∫w_n dS, with the 21-vs-140
  internal cross-validation (0.00–0.07%) and the n²-artifact resolution. [PROVEN identity
  + MEASURED margins] **The conceptual bridge between the completeness machinery and
  V-as-fluctuation — the motivating result for why the pin targets S-transport at all.**
- **Structural/exploratory notes** (`unbounded/` — octonion frame, doubling test, J₃(𝕆)
  motivation for the w ≈ 3 question): motivation layer; feeds G-E's question, carries no
  tags in this chain.

## 8. THE GAPS (all of them, precisely; owner lanes per the K1K2/P1 package menu)

- **G-D2a [GAP → DONE 2026-07-19]** Closed form of F_j(τ): DERIVED AND VERIFIED (parts
  8.6e−10, TOTAL 8e−13; JJ comb collapse certified EXACT in rational arithmetic).
  → `D2_progress` §7 (F1)/(F2). Unblocked G-D2b.
- **G-D2b [GAP → THEOREM 2026-07-19 (F10)]** κ_j = 1 + a_∞μ^{1/3} + R_j,
  −1.1 ≤ R_j ≤ 0.5 explicit (j ≥ 512), lemmas (L-a)/(L-b) closed with graded
  ingredients; caustic lower bound E_j ≥ 0.3466μ^{1/3} − 1.1 (exact constant).
  Historical text below stands as the day's record:
  *(old)* The zone-(ii) estimate. Old target
  κ_j ≤ c₀ + c₁log(2+j) is FALSE (measured law: κ_j = 1 + E_j, E_j ≈ 0.131·j^{1/3}·
  (ln j)^{1/2}, certified rows to j = 8192; log/√j/pure-power all rejected). NEW target:
  **κ_j ≤ C·j^{1/3}(log j)^{1/2}** (+ caustic lower bound ≥ c·j^{1/3}, which refutes
  log-K1 permanently) via Olver/Airy at the caustic n/j = 2/π, σ-calculus remainders.
  The naive IBP+L¹ routes are REFUTED (D2 note §7 (F4)). WITH zones (i)/(iii) (G-D2c)
  ⇒ **companion-K1 proven at the j^{1/3}√log growth class** (program-safe per
  `CONSUMER_CHECK_j13_2026-07-19.md`). → staged: `NEXT_SESSION_TASK_caustic_profile.md`.
- **G-D2c [GAP → DONE 2026-07-19 (F10)]** Zones (i)/(iii): zone (iii) closes
  via the exact σ-calculus (C_m = −(1/π)Σg_kρ_k(m), alternating-dominated, r ≤ 0.04,
  g₁/μ² → −8/π) — lemma written into (F10) (S_m = −(π/2)C_m exact; far partial sums
  pinned ≤ 0.211); zone (i) closed as lemma (L-b) (fixed x₀ = 1/2 split, envelope 8×
  slack, C_b = 0.066).
- **G-M1 [GAP → CLOSED 2026-07-21: THEOREM-M1 ASSEMBLED (derivation+verification
  grade; two classical write-ups pending, no research content)]** →
  `T2_M1_weight_transfer_2026-07-19/M1_THEOREM_note_2026-07-21.md` (8 parts,
  grades itemized). Historical record: Weight transfer
  companion → uniform: the λ-side Lambert route CONFIRMED and the inverse telescope
  BYPASSED. **J_N(uniform) = head row (α₁ = m₁/N exact, β₁ ≈ √(m₂/N)) ⊕ ODD-Lambert
  block (closed form: α^O_j = 1/((4j−3)(4j−1)) + 1/((4j−1)(4j+1)), β^O_j =
  1/((4j+1)√((4j−1)(4j+3)))) + O(1/N) FLAT in j** (measured ratios 1.999/1.999 over
  two octaves; ODD form = x²-system at 7.7e−10). Moments m_k = (2^{2k}−1)ζ(2k)/π^{2k}
  = tan-series EXACT (the (F5) rationals); CF-contraction = EVEN(companion-x) block
  exact; all N-dependence isolated in m₀ = N (renormalized-transform identity). The
  Q2-audit's α₁(N) ~ c/N is now c = m₁ = 1/2 identified. REMAINING: (a) the
  bordered-perturbation lemma (O(1/N) flat — perturbative, same genus as G-M3, likely
  close together); (b) the K1-kernel consequence through the bordering (next session).
  → `T2_M1_weight_transfer_2026-07-19/M1_lambert_pattern_note_2026-07-19.md`.
  Historical route text: telescope cancellation-laden (|r_i| ≈ 1.15) — now bypassed;
  CD-kernel Christoffel / uniform V-transform routes no longer needed.
- **G-M3 [GAP → CLOSED at lemma grade 2026-07-21 (THEOREM-M1 part IV)]** the unified
  tail-measure-removal lemma: |Δα_j|+|Δβ_j| ≤ C_GS(j)·‖τ_N‖·B_j², rates EXACT
  (‖τ_ODD‖ = 1/(3π⁴N³) — M⁻³ scaling confirmed over a decade, constant 3.5e3
  stable; ‖τ_comp‖ = 2/(π²N) — the 0.33k/2M drift's shape); edge values geometric
  (rate → 1). Also answers the Q2-audit Task-1 residue (sections → canonical
  completions at explicit rates). GS-stability write-up pending (mechanical).
  Historical: Finite-M truncation lemma (drift ≈ 0.33k/2M measured; residuals
  halve M→2M).
- **G-P2 [GAP]** Second-order kernel identity (differentiate Theorem 1′ along the
  transport flow) — upgrades K2 from stencil-verified to identity-verified.
- **G-HROT [GAP, composed; constants improved 2026-07-19 (F11)]** The rotation-bound
  packaging (LEMMA note §8): ‖J(μ′) − J(μ)‖ ≤ C·max_n|x′_n − x_n| for quantile-type
  configurations, fixed weights; measured C_rot = 1.04–1.18, flat in N (item 2.2's ‖R‖).
  NOT independently attacked: it is COMPOSED from model-K1 + K2 via the Abel/row
  assembly (item 3.8). Constants: the raw-Abel route was 5–26× vs truth; **the (F11)
  profile-pairing accounting delivers 4.8× (0.0622 vs 0.0129·C_rot-truth on the actual
  drop-4 field), with NO j^{1/3} anywhere** — the remaining ~4.5× is in-window sign
  cancellation, i.e. exactly G-E's window norm. The j^{1/3} tolerance question is
  ANSWERED (F11); G-E's window norm is now DERIVED [2026-07-19: ‖S‖*_3 signed, the
  caustic scale of the j = 2–3 rows]; the field-side lemma is NUMERICS-STAGED
  [2026-07-19 (F12): τ ≤ u_n(sup|ΔS| + (q/n)sup|S|), u_n ≤ C_geo n⁻² geometric
  (exponents measured 2.36/2.05); window term ≤ 0.044 at every j]. What remains for
  the sharp C ≈ 1.1: the classical u-decay write-up (quantile-class, ρ increasing —
  IB lane) + the certified S scalars (sup|S| = 0.862, sup|ΔS| = 0.676, ‖S‖*_3 =
  0.6295 measured at production spec; certification = G-C1/G-C2).
  Any spine reference to "H-ROT" resolves HERE.
- **G-E [GAP → DERIVED 2026-07-19]** The w ≈ 3 elbow IS the caustic scale of the
  maximizing kernel rows: w*_j = 2j/π + μ_j^{1/3} = 2.9/3.8 at j = 2/3 (where |dα|
  peaks, structurally by the (F11) runaway); sign-change clusters match in model AND
  production; the operational tolerance curve (window-averaged dx vs fixed kernels)
  reproduces the empirical C_needed knee interval [2,3] exactly. Precise norm:
  **‖S‖*_w = max over windows of w spacings of |signed avg S|, w = 3** ("w ≤ 2 safe,
  w = 3 marginal, w ≥ 4 dead"). → `ELBOW_kernel_scale_note_2026-07-19.md`. Feeds G4;
  the field-side lemma is numerics-staged [(F12) 2026-07-19; ‖S‖*_3 = 0.6295 measured
  at production spec]; remaining = classical u-decay write-up + certified S scalars.
- **G-C1 (= G2) [LANE:IB → SPLIT 2026-07-21: mechanical core taken into our lane
  (Selina's decision), θ-module remains offerable]** Session 1 delivered
  (`T2a_pencil_certification_2026-07-21/`): **CERTIFIED sup|S_P| ≤ 0.901946 and
  sup|S_P′| ≤ 188.804** (interval, explicit budgets); **all four PSD certificates
  aJ_D + bI ∓ V ⪰ 0 CERTIFIED-as-computed with margins** (drop-1: 5.5e−3/6.9e−4;
  drop-4: 5.0e−5/4.0e−4; interval Cholesky, dps 40; cross-checks vs frozen CSV
  3.6e−15 and frozen npz 8.3e−17). Remaining = ONE module: rigorous θ/θ′ enclosure
  (Stirling-remainder iv or arb port) → γ-enclosures; ~25 orders of headroom
  (tolerated |dγ| ≈ 1.1e−5 vs mp residuals ~1e−30). When it lands: the first
  rigorous finite-range self-adjointness certificate for χ8. Original statement:
  Interval certification: sup|S_P| on tail range, quantile
  enclosures, the two PSD checks for (0.3, 0.011) at N = 149 ⇒ first rigorous finite-range
  self-adjointness certificate for χ₈. Hypotheses frozen at item 0.1.
- **G-C2 (= G3) [LANE:IB]** Palojärvi–Zhao pointwise-S constants c₁, c₂ for χ₈ (Selberg
  data as in the B = 57.89 script) ⇒ Theorem A unconditional in true S.
  **Rounding discipline for BOTH C-items:** ceil-to-12dp-BEFORE-inequality (adopted in the
  turing24 exchange after the stored B = 56.94 was found rounded the unsafe way) — every
  constant entering a certified inequality in G-C1/G-C2 must follow it.
- **G4 [PROGRAM QUESTION, LANE:IB]** Which identification does the m→∞ limit need: atom map
  (b = 0, transfers positivity — proven) vs pencil map (all measurements; b ~ D_min)?
- **G5 [standing]** All production constants float64-grade, P = 2×10⁵ (upgrade via G-C1).

**Dependency spine:** T2a certificate ⇐ G-C1 (+frozen 0.1). Companion-K1 ⇐ G-D2a→b→c
**[ALL THREE CLOSED 2026-07-19 — companion-K1 is a THEOREM, (F10)]**.
Uniform/model-K1 ⇐ companion-K1 + G-M1 + G-M3 **[BOTH CLOSED 2026-07-21 —
THEOREM-M1 assembled; the caustic theorem transfers to the uniform normalization at
the kappa-level; remaining polish is classical write-ups only]**.
G-HROT (the rotation bound, defined above)
⇐ model-K1 + K2 (3.7) [G-E window DERIVED 2026-07-19; + G-P2 for elegance; j^{1/3}
tolerance answered (F11); field-side lemma numerics-staged (F12) 2026-07-19; remaining
input = classical u-decay write-up + certified S scalars ⇐ G-C1/G-C2].
Pin-in-the-limit ⇐ uniform KLMN pair (1.3, supported) + G4 decision. The ‖S‖*-question to
IB is now POSED PRECISELY [2026-07-19: ‖S‖*_3 = max |signed 3-spacing window avg of S|,
from `ELBOW_kernel_scale_note_2026-07-19.md`] ⇐ Turing/PZ inputs (G-C2) for the certified
evaluation.

## 9. Status updates (era 3 appends here; newest last)

- 2026-07-19 (ledger opened, middle Claude): chain current through item 6.10 / gaps as
  listed. Era-3 session active on G-D2a.
- 2026-07-19 (audit by era-3 Claude; fixes applied by middle Claude): both package SHAs
  re-verified ✓; five findings fixed — G-HROT defined with its own gap entry (spine
  reference resolved); margin/Li-fluctuation identity added to §7b; ceil-to-12dp-before-
  inequality rounding discipline recorded on G-C1/C2; 2.2b(ii) upstream gates named
  (amplitude-guard patch + second-η channel); era-1 attribution corrected (skeleton =
  completeness-engine session).

- 2026-07-19 (G-D2a closed-form session): F_j(τ) closed form DERIVED+VERIFIED (parts
  8.6e−10, total 8e−13; JJ comb collapse certified EXACT in rational arithmetic — Lidstone
  resummation ≡ δ-form); C_m = ∫F_jD_m verified; naive one-IBP L¹ REFUTED (~j, Z4 recurs
  at kernel level); Γ_j = ∫|F|g ≈ 0.47√j; S_true = −0.174+0.216log(2+j) (j ≤ 64). Two new
  float-trap lessons (sub-turning-point Lommel recurrence; mpmath-lambdify float args).
  D2 note §7; commit fb54e9b.
- 2026-07-19 (G-D2a σ-calculus session): C_m now EXACT per m — πc_n = even rational
  Laurent (A·B/A·A Lommel products ≡ T/U calculus, cross-checked exactly); g₋₁ = g₀ = 0
  and the row-sum C_∞ = 0 all EXACT-RATIONAL identities (j = 2,3,4,8); zone (iii) closes
  numerics-first (alternating domination r ≤ 0.04, g₁/μ² → ≈ −8/π) [G-D2c: GAP → 
  VERIFIED-shape 2026-07-19]; log localized AT the turning point (envelope peak O(1) at
  n/j = 2/π; m*/j → 2/π); Y-side finite-m double-integral rep verified (stationary-phase
  object). Third float-trap lesson: sympy nsimplify truncates unevaluated exact Adds
  through float64 (phantom 7/(μ+1)z^{−(4j−2)}). **OPEN FLAG: §2 κ-table not reproduced at
  j ≥ 8 from verified rows — κ-slope 0.382 is fit-range-only until resolved vs
  `t2_d2_kappa_infinite.csv`; all variants stay polylog (program-safe).** D2 note §7
  (F5)/(F6).

- 2026-07-19 (G-D2a κ-resolution session): OPEN FLAG resolved — no bug; §2's κ =
  max(fwd, rev-tail-branch), CSV reproduced to all digits on verified rows. Extension to
  j = 512: **κ_j ≈ 0.46·j^{1/3} (flat ±3% over j = 64–512); the §2 log fit was
  pre-asymptotic — K1-as-log is FALSE for the companion model** [companion-K1 target:
  log → C·j^{1/3}, 2026-07-19]. Mechanism = Airy caustic window (~μ^{1/3} atoms, O(1)
  amplitude) at the turning point n/j = 2/π. Universal-tail constant corrected:
  (π/2)|C_cap| → 2/π² = 0.2026 exactly (0.231 was pre-asymptotic). NEW GATE for G-D2b/c:
  consumer check — does the K1K2 tail assembly tolerate κ_j ~ j^{1/3}? (If not:
  program-level question for IB.) Finite-range κ̂ = 5.60 (N ≤ 149) unaffected. D2 note
  §7 (F7); RESULTS entry.

- 2026-07-19 (consumer-check session): **j^{1/3} does not break the chain** — verdict note
  `CONSUMER_CHECK_j13_2026-07-19.md`. Production bulk κ_j refit from the frozen certified
  kernels: c·j^{1/3} fits with c ≈ 0.52 (≈ model's 0.46; N = 149 is pre-asymptotic, model
  arbitrates). Per consumer: finite chain (N ≤ 149) UNAFFECTED; **P1 RESTATED [log target
  → C·j^{1/3}, 2026-07-19]** (log-P1 was unprovable — explains the D2 estimate failures);
  H-ROT unchanged (raw Abel was already the gap; NEW IB-menu question: windowed-S pairing
  with j^{1/3} row constants); KLMN/G4 unchanged. D2 proof goal now: κ_j ≤ Cj^{1/3} upper
  + caustic lower bound (lower bound kills log-K1 permanently).

- 2026-07-19 (caustic-ladder session): ladder to j = 8192 on CERTIFIED pure-rational rows
  (backward-Miller A + forward B, log-mantissa; mp/ktop/scipy triple-checked). **Law
  refines: κ_j = 1 + E_j, E_j ≈ 0.131·j^{1/3}(ln j)^{1/2}, flat ±2% over five octaves;
  m*_E/j = 2/π at every j** [companion-K1 target: C·j^{1/3} → C·j^{1/3}(log j)^{1/2},
  2026-07-19]. FOURTH float-trap: garbage-FINITE rows at the scipy underflow boundary (no
  NaN; one row carried 0.085 at j = 512) — (F7)'s κ(256–512) corrected (κ(512) = 3.6159);
  j ≤ 192 CSV values clean. Consumer verdicts unchanged. IB side-note draft updated.
  D2 note §7 (F8).


- 2026-07-19 (caustic-profile derivation session): **the zone-(ii) law is now CLOSED
  FORM: kappa_j = 1 + E_j, E_j = a_inf mu^(1/3) + O(1), a_inf = 2^(2/3) 3^(-5/6) /
  Gamma(2/3)^2 = 0.34656 (i.e. 0.43663 j^(1/3))** [companion-K1 target:
  C j^(1/3)(log j)^(1/2) -> 1 + a_inf mu^(1/3) + O(1), DERIVED constant, 2026-07-19].
  (F8)'s sqrt(log) refinement is REFUTED by an out-of-sample test at j = 16384 (sqrt(ln)
  law misses by +2.06%, the offset law by -0.18%) - it was a finite-size mimic of the
  additive O(1) constant. Mechanism derived via the Olver/Airy telescope:
  Phi_inf(s) = -4(AiBi)'(-2^(1/3)s), verified 8.0e-5 (Richardson) with the first
  correction confirmed (0.998); oscillatory envelope (4/pi)(1-sin theta) at 1.8e-3; the
  excursion is the CONVERGENT integral of Phi_inf (B(S) saturates; osc side DC ~ 0).
  Caustic lower bound E_j >= 0.1212 mu^(1/3) - O(1) on a fixed verified window -
  **log-K1 refuted permanently** (theorem-grade modulo (L-a) Olver-remainder
  accumulation + (L-b) zone-(i) Debye lemma, both classical machinery). Full-kappa
  ladder corrected on Miller rows (far block bitwise = rows()): kappa(384) = 3.2393,
  kappa(512) = 3.6159 (F7 values contaminated), extended kappa(768/1024) =
  4.1141/4.5116; sup = rev = 1 + E_j exactly. Authoritative table
  `t2_d2_kappa_full_ladder.csv`. D2 note section 7 (F9); RESULTS entry; IB side-note
  draft updated to the closed-form law (still DRAFT/unsent).
- 2026-07-19 (zone-(ii) closure session, sixth of the day): **THE ZONE-(ii) THEOREM
  CLOSES — kappa_j = 1 + E_j, E_j = a_inf mu^(1/3) + R_j, -1.1 <= R_j <= 0.5 explicit,
  j >= 512** [G-D2b: GAP -> THEOREM; G-D2c: -> DONE]. Lemma (L-a): fixed split
  x0 = 1/2; two-piece residual envelope vs certified rows (C2 = 5.5 caustic piece,
  C3 = 2.7 deep piece; j-stable 256/1024/4096, 50% headroom); the pure-Airy model
  constant closes: C_model_inf = -D_inf + 2Ai(0)Ai'(0) + Jac_inf = -0.5770 (D_inf =
  2^(2/3)/(2 pi (3W0/2)^(1/3)) EXACT, j-independent to 6 digits). Lemma (L-b): zone-(i)
  envelope |c_n| <= 1.2 * 2/(3 pi mu W(x)), sup ratio 0.130 (8x slack), C_b = 0.066;
  gamma >= arccosh 2 on the whole zone so the u1-warning never bites. Zone-(iii) lemma
  written (S_m = -(pi/2)C_m exact, far tails pinned <= 0.211). NEGATIVE result
  recorded: proj-drop fails beyond the caustic (c-only drift ~0.5 mu^(1/3)) — theorem
  uses measured sup-at-m* + P* = sum proj below m* <= 0.02 (prop. to eps) instead.
  Ledger-balance check E - E_W = zone-i - P* closes to 1e-4 at three j. **Caustic
  lower bound with the exact constant: E_j >= 0.3466 mu^(1/3) - 1.1 — log-K1 refuted
  at a_inf itself.** Subleading drift resolved structurally (every component
  convergent; no genuine ln mu; -0.934 limit matches the 16384 residual to 0.001;
  32768 test considered and rejected — separation inside EM jitter). Grades per (F10):
  classical-cited / exact / quadrature / finite-numeric-with-margins, itemized.
  Scripts `t2_d2_lemma_La.py`, `t2_d2_lemma_Lb.py` + logs; D2 note (F10); RESULTS
  entry; IB side-note draft updated to theorem-grade (still DRAFT/unsent). Folder
  ready to cut into a dated send (Selina decides).
- 2026-07-19 (windowed-S pairing session, seventh of the day): **THE MENU QUESTION
  ANSWERED — the windowed-S pairing TOLERATES j^(1/3) row constants** (model +
  production, note (F11)). Mechanism 1, localization: explicit majorant Psi_j =
  min(1.10 kappa_j, 1 + 0.50 mu^(1/3)|shat|^(-1/2)) >= |ps_m| pointwise (0 violations,
  margin +0.178, three octaves); equidistributed-TV pairing 0.66*TV CONSTANT in j
  (kappa 2.9 -> 7.1); oscillating fields <= 0.014*TV; SHARP at a caustic step (= E_j).
  Mechanism 2, runaway (frozen production kernels, cross-checks exact; kappa-hat
  convention identified = worst-step 5.5956): the actual dx has TV density ~ n^(-3/2)
  and the caustic window n* = 0.64j runs past it — kappa_j*TV_window peaks 0.054 at
  j ~ 10 and falls two orders; the dangerous corner is empty for quantile fields.
  Actual-field accountings: TRUE 0.0106 / pairing 0.0622 / Abel 0.2847; H-ROT budget
  4.8x truth vs Abel 22x. RETARGET for the IB menu: only the FIELD-side TV-density
  bound remains to formalize (kernel side is (F10)-grade). Scripts
  `t2_d2_pairing_windowedS.py`, `t2_d2_pairing_production.py`; RESULTS entry; frozen
  folders read-only, untouched.
- 2026-07-19 (Stage-E elbow session, eighth of the day): **G-E DERIVED — the w ~ 3
  window elbow IS the caustic scale of the maximizing kernel rows**: w*_j = 2j/pi +
  mu^(1/3) = 2.9/3.8 at j = 2/3 (where |dalpha| peaks; structural via the F11
  runaway); production first sign change at n = 4 matches the model's near-caustic
  cluster; operational tolerance (window-averaged dx vs fixed kernels) loses
  0/76/101% of the aggregate pairing at w = 1/2/3, reproducing the frozen empirical
  C_needed knee interval [2,3]. Deliverable norm: ||S||*_w = max over w-spacing
  windows of |SIGNED avg S|, w = 3; honest reading "w <= 2 safe, w = 3 marginal,
  w >= 4 dead". The J3(O)-nominated w = 3 = the caustic scale of the j = 2-3 rows.
  Note `ELBOW_kernel_scale_note_2026-07-19.md`; script + log; G-E flipped in §8;
  RESULTS entry. Feeds G-HROT sharp constant and G4.
- 2026-07-19 (field-side TV-density session, ninth of the day): **the pairing story's
  last piece STAGED (F12)** — tau(n) = |Ddx| decays at p = 2.36 (envelope 2.60), the
  S-part dominates the split, and the provable shape is tau <= u_n(sup|DS| +
  (q/n)sup|S|) with u_n <= C_geo n^-2 GEOMETRIC (u-exponent measured 2.05; classical
  quantile-class lemma, IB-lane write-up). Composed: **the window term
  1.10 a_inf mu^(1/3) TV_Wj <= 0.044 at every j** (peak j = 10, decay j^(-1.69);
  separated-regime law TV_Wj <= 78 mu^(1/3) n*^(-2.36) TV for j >~ 40, full-TV
  fallback below — mu^(1/3) small there). Matches (F11)/X4's independent 0.054: the
  runaway is now an inequality. Certified-side scalars measured at production spec
  (Euler-product S_P, P = 2e5, zeros nowhere): sup|S| = 0.862, per-spacing sup|DS| =
  0.676, ||S||*_3 = 0.6295 (signed = abs at the maximizing window — sign-pure run).
  Linearization honesty: dx = -u*S only median-22% at product level; all tau
  measurements on the actual field. Script `t2_f_field_tv_density.py` + log; note
  (F12); RESULTS entry. Remaining in the whole pairing story: the classical u-decay
  write-up + the certified S scalars (G-C1/G-C2 lane).
- 2026-07-19 (send): **package CUT AND SEALED: `to_Ilya_CAUSTIC_THEOREM_2026-07-19`**
  (COVER + promoted orientation note + evidence/ = the full working-folder record:
  notes F1–F12, ledger snapshot, all scripts + logs + the authoritative κ CSV;
  62-file SHA256SUMS manifest inside). Zip SHA256 =
  284d21b50996dc76bf74e86567c7c53c6ef5ef78f344860ba90fa440769326b7.
  Lineage pinned to the two 2026-07-18 packages (SHAs in the COVER). The sent folder
  is FROZEN from this commit; continuation work goes to a NEW dated folder per
  standing hygiene. This working folder remains the era-3 home for the ledger only.
- 2026-07-19 (received): **IB's Q2 ↔ operator-bridge audit package filed:**
  `Q2_OPERATOR_BRIDGE_received_2026-07-19/` (zip SHA 0e9a35ed…1688 verified OK;
  extracted alongside the sealed original; his prompt preserved as-received). Ten
  input files incl. his six exact-QQ Q2/T50019 certificates and snapshots of our two
  07-18 packages (byte-verify before citing). Audit STAGED, not run:
  `NEXT_SESSION_TASK_Q2_operator_bridge_audit.md` (our holdings pre-answering his
  Tasks 1/3/4/9: companion Carleman exact ⟹ e.s.a.; production atoms bounded;
  sections NOT nested per G-M3; non-circularity receipts incl. (F12) zeros-nowhere;
  m₀ = ∞ moment caveat). Expected Gate A: boundary-extension route refuted for the
  class ⟹ pivot to his Tasks 5–8 (derive Q2 as dark-channel/rank-drop). Audit
  outputs → new folder `Q2_OPERATOR_BRIDGE_audit_<date>/` when run. Adjacent stream
  (§7b), not on the pin's critical path.
- 2026-07-19 (G-M1 pattern-check session, new folder `T2_M1_weight_transfer_2026-07-19/`):
  **G-M1 PATTERN CONFIRMED — the λ-side Lambert route works and the inverse telescope
  is BYPASSED.** Renormalized-transform identity (exact): all N-dependence of the
  uniform-N system sits in m₀ = N; higher moments = (2^{2k}−1)ζ(2k)/π^{2k} EXACT
  (= tan(√λ)/(2√λ) Taylor = Lambert 1,3,5,7 = the (F5) rationals). Squared Lambert
  splits: EVEN block = companion-x (= the CF contraction, sympy-exact), ODD block =
  x²-weighted system in closed form (α^O_j = 1/((4j−3)(4j−1)) + 1/((4j−1)(4j+1)),
  β^O_j = 1/((4j+1)√((4j−1)(4j+3))); verified 7.7e−10 vs M = 20000 truncation).
  **J_N(uniform) = head(m₀ = N) ⊕ ODD block + O(1/N) FLAT in j** (dev ratios
  1.999/1.999 over N = 200/400/800; head identities at 1e−18; head laws α₁ = m₁/N,
  β₁ = √(m₂/N) — the Q2-audit's c/N constant identified as m₁ = 1/2). G-M1 tag
  flipped + spine updated; remaining = bordered-perturbation lemma (genus of G-M3)
  + the K1-kernel consequence. Note `M1_lambert_pattern_note_2026-07-19.md`, script
  + log in the new folder.
- 2026-07-19 (M1 Stage-B session, same folder): **kappa-level kernel transfer
  CONFIRMED — matched rows (unif j+1 <-> ODD j) agree to 0.9-2.6% at N = 400,
  improving in j; the caustic window is CLEAN (PS-diff decays ~N^(-1/2) there:
  0.31/0.20/0.14 at j = 16)** — the head coupling does not reach the caustic, so the
  (F10) constant transfers where it matters. HONEST SURPRISE recorded: an O(0.7),
  N-stable PS-difference component localized mid/deep (the head-projector mass
  redistribution; n_sup = 25/82/255 at j = 8/16/32, N = 400) — never moves the
  kappa-sup, but the row-uniform O(N^(-1/2)) transfer statement is TOO STRONG;
  Stage-A lemma must carry the split (caustic + sup-location transfer, O(1) smooth
  redistribution elsewhere). **SIXTH FLOAT-TRAP recorded (recurrence genus):**
  forward-recurrence OP evaluation explodes in float64 at the spectrum edge/deep
  cluster (1e26+ vs the provable sqrt(N) bound from Lanczos orthogonality) and the
  first FD spot-checks missed it by probing only the safe zone — spot-checks must
  cover the EDGES; fix = kernels as centered FD of the Lanczos map (two-h verified
  4e-5; true kernels O(1), max 1.41). Scripts + RESULTS in the campaign folder.
- 2026-07-19 (M1 Stage-A session, same folder): **THE ARROWHEAD IDENTITY IS EXACT —
  J_N(uniform) = tri(Q^T diag(x) Q) over the frame [e0 | V2] (e0 = 1/sqrt(N), V2 =
  ODD Lanczos basis), verified MACHINE ZERO (3.3e-16) at N = 100/200/400; proof =
  degree filtration, two lines.** The bordered-perturbation lemma is now explicit
  algebra on a proven finite-N identity. Coupling profile g_j = <e0, V2_j>: sum = 1
  exactly, mass at j ~ 0.8 sqrt(N), tail ~ j^(-3) — item 1b ANSWERED (the Stage-B
  O(0.7) redistribution = the head state's Fourier profile in the ODD basis; its
  sqrt(N) mass location explains the kernel PS-diff localization). J(N) breakdown
  measured: 1/N plateau for j <~ sqrt(N), rise past (2-5) sqrt(N); two separated
  deviation sources (ODD-truncation moment tails = the G-M3 twin; g-coupling at
  sqrt(N)). SPLIT LEMMA statement fixed by the data; remaining proof work:
  (a) downdate algebra (mechanical), (b) g_j closed form (Bessel-summable
  candidate), (c) the ODD-truncation moment lemma = G-M3 precisely twinned.
  Script `t2_m1_stageA_arrowhead.py` + log; RESULTS session-3 entry.
- 2026-07-19 (M1 session 4 — item (a) DONE): **the downdate algebra is WRITTEN OUT
  and machine-verified (1e-13, three N, all pre-horizon rows).** Exact structure:
  GS = two-term (w_j, ehat_j) recursion driven by s_{j+1}^2 = s_j^2 - g_j^2, with
  the collapse X e0 = sqrt(m2/N) w0; exact entries alpha^U_1 = m1/N, beta^U_1 =
  sqrt(m2/N) s_1, alpha/beta^U_{j+2} explicit in {g, a, b, m1, m2}. **The transfer
  horizon is SHARP: s^2-floor at j = 3.2/3.25/3.3 sqrt(N) — J(N) = 3.2 sqrt(N).**
  Deviation identity verified per-point: alpha^U_{j+2} - a_j = [g_j^2(a_j + eta_j)
  + 2 g_j g_{j-1} b_{j-1}]/s_{j+1}^2; crude absolute-value bound explicit with
  measured 9-27x slack = the alternating-sign cancellation (g_j alternate:
  sign = (-1)^j measured everywhere). **The sharp bound is reduced to ONE fact —
  the g-alternation lemma (Chebyshev-like positivity of sum x_n p^O_j(x_n) in the
  elementary ODD system) = item (b), which now carries both the decay law and the
  cancellation.** One transcription sign error caught by per-point verification.
  Script `t2_m1_stageA2_downdate_algebra.py` + log; RESULTS session-4 entry.

- 2026-07-19 (Q2 operator-bridge AUDIT RUN, tenth session of the day; adjacent
  stream §7b): IB's 18-deliverable audit executed →
  `Q2_OPERATOR_BRIDGE_audit_2026-07-19/` (14 notes + RESULT.json + scripts/logs +
  SHA256SUMS). **Gate A fired both ways as staged:** boundary-extension route
  REFUTED for the class (every canonical completion bounded/compact, deficiency
  (0,0); companion e.s.a. PROVEN twice over) + uniform-normalization infinite
  operator OPEN (nestedness REFUTED with six-N drift table; α₁(N) ~ c/N — G-M3
  quantified). **Pivot substance: Q2 DERIVED, never inserted** — Lemma S:
  scar = maximal F-invariant subspace of Row(B) (2-line proof); Q2 divides the
  ω-dark-channel determinant det(B(F−ωI)X) SYMBOLICALLY over ℚ(ω) (cofactor =
  rank-B cubic); drop-exactly-1 verified mod two primes at all four strata;
  σ_min ≈ 4.19|Q2| linear opening. Negatives recorded: no b-space F-action
  (span{B5..B8} not F-stable); F not orthogonal; canonical couplings W_sym and
  G⁻¹W_sym do NOT reduce on the scar ([H,P]=0 refuted for these). New structure
  flagged to IB: ordinary pairwise intersections all = scar; dim(R0+R1+R2) =
  13/8/5/8. b_χ8: centralizer no-go (character-level data GL₂-invariant) —
  missing datum = canonical marking of the 2χ8 multiplicity plane. His
  certificates independently reproduced (rule 10, incl. A-identities as
  polynomial identities over ℚ[a,c,p,q]). His snapshot of our operator package =
  deliberate zero-strip (2 CSVs + 1 COVER ¶; 57/57 rest byte-identical) — cite
  sealed originals. Non-circularity: operator_uses_zero_locations = false, with
  receipts. Variable-discipline note: item 5.2's exact β-law lives in the
  SYMMETRIZED ξ = 1/z frame (x-frame impossible: supp 0.405 < β₁ = 0.577);
  companion β-truncation rate 0.008·k/2M (≠ 5.2's value-law 0.33·k/2M — two
  observables, recorded to prevent misreading). String-weighted production tails
  β_n ~ 1.48n^{−1.49} (D) / 1.78n^{−1.54} (F). T2 pin critical path unaffected.
- 2026-07-19 (send): **audit package CUT: `to_Ilya_Q2_OPERATOR_BRIDGE_audit_2026-07-19`**
  (38 members: 15 notes incl. the reply + RESULT.json + all scripts/logs/tables +
  SHA256SUMS; `extracted/` excluded — byte-identical copies of IB's own certified
  packages, covered by his manifests). Zip SHA256 =
  930b3315c7dcd5a86db5f7dd3eebd36ada93fb6718603b92c3be9212d982ccd8.
  The audit folder is FROZEN from the send per standing hygiene; continuation work
  (2×2 Gram realization, all-b drop-1 identity, canonical-coupling search,
  multiplicity-marking datum) goes to a NEW dated folder.

- 2026-07-21 (T2a certification session 1, new folder
  `T2a_pencil_certification_2026-07-21/`): **THE CHAIN'S FIRST [CERTIFIED] ENTRIES.**
  CERTIFIED sup|S_P| <= 0.901946 on [0.5, 27.79] (dense scan + interval Lipschitz
  sup|S_P'| <= 188.804 + explicit float budget 4.3e-11 — every step rigorous; Euler
  side = finite explicit sum). All FOUR PSD certificates aJ_D + bI -+ V >= 0
  CERTIFIED-as-computed by interval Cholesky (dps 40, construction allowance 1e-30)
  at the frozen pairs: drop-1 margins 5.5e-3/6.9e-4, drop-4 margins 5.0e-5/4.0e-4.
  Cross-checks: dps-40 ladders vs frozen quantiles CSV at 3.6e-15; mp-built drop-4
  J_D vs the FROZEN npz at 8.3e-17. ONE pending module, exactly specified:
  rigorous theta/theta' interval enclosure (8 loggamma terms; Stirling-remainder in
  iv, or the arb port on the box) delivering both the Newton residual AND the local
  f' lower bound; headroom ~25 orders (tolerated |dgamma| ~ 1.1e-5 vs mp residuals
  ~1e-30). G-C1 split: mechanical core in our lane (done), theta-module offerable to
  IB. When it lands: the first rigorous finite-range self-adjointness certificate
  for chi8. Note `T2a_CERTIFICATE_note_2026-07-21.md`; script + log; tag-conventions
  line updated (CERTIFIED no longer 'none yet').

- 2026-07-21 (T2a session 2, same folder): **T2a COMPLETE — the full finite-range
  KLMN certificate at ball grade, end to end, delivered LOCALLY** (python-flint/arb
  was already installed; the theta-module = 8 ball lgammas + digamma, no AWS, no
  FFT engine needed). [CERTIFIED] 298/298 quantile enclosures at 1e-10 (interval
  Newton; ball theta/theta'/S_P/S_P'; prec 4096). [CERTIFIED] the COMPLETE frozen
  matrices at full dimension (prec 16384 ball Lanczos, all 148/145 rows, radii
  below 1e-308-display) and ALL FOUR PSD statements with margins drop-1
  5.500e-3/6.875e-4, drop-4 5.000e-5/4.000e-4. **THE KLMN FORM BOUND FOR THE
  FROZEN PRODUCTION PAIR IS NOW A CERTIFICATE — the first rigorous finite-range
  self-adjointness statement for the chi8 operator family (G-C1's deliverable,
  mechanical core + theta-module both closed in our lane).** AUDIT FINDINGS:
  (i) Krylov-conditioning wall ~10^13/step — prior float64/dps-40 values of rows
  j >~ 94 were below their own noise floors; chain consumers all live in the easy
  region; **kappa-hat = 5.5956 (attained j = 145) FLAGGED for re-grading** [bracket
  added at item 3.5]; (ii) prec-16384 wide-ball quirk recorded (M2 regresses to
  66/149 at 16k while clean at 4096; mechanism unresolved, certificates taken at
  4096 — equally valid). Remaining OPTIONAL polish: certified sensitivity bound
  (needs <= 5e5; measured 0.76-50) to transfer margins from the frozen-as-computed
  object to the true-quantile object — astronomic slack, staged.
  Note `T2a_CERTIFICATE_note_2026-07-21.md` session-2 section; scripts + logs.

- 2026-07-21 (T2a session 3, kappa-hat re-grade): **the audit flag RESOLVES —
  kappa-hat = 5.5956 CONFIRMED at certified ball grade** (prec-16384 ball Lanczos
  with basis; ball derivative recurrence — the e^cj growth, max |p'| = 2.9e+291,
  now RESOLVED rigorously; Theorem-1 kernel rows; PROVEN sum rule = ball-zero
  per-row certificate on all rows; boundary row via the exact trace identity
  K_M = 1 - sum_{j<M} K_j after the naive truncated formula produced a 144.0
  artifact — caught by the M-1 signature and fixed same run). Deep rows 135..144
  match the frozen npz to 4 decimals; kappa-hat attained at j = 145 exactly as
  recorded. NEW certified fact: the production boundary layer (5.60 at l = 1) is
  ~8x MILDER than generic Chebyshev (M/pi = 46.15) — the quantile-structure
  mildness claim upgrades to certified. Item 3.5: kappa-hat [MEASURED ->
  CERTIFIED]. Script + log in the T2a folder.

- 2026-07-21 (M1 session 5, V-head-free + production arrowhead): **(i) the
  arrowhead identity CONFIRMED VERBATIM on production atoms** (machine zero for
  mu_D and mu_F — the measure-agnostic claim holds; all M1 structural results
  apply to the production operator directly). **(ii) V = J(muF) - J(muD) is
  HEAD-SUPPRESSED, not head-free** (the flagged conjecture refined): head entries
  5-9% of ||V||-scale, V_11 = (m1F - m1D)/N exact identity (~1/N); deep block =
  shifted ODD-difference at leading order with 15-30% median corrections, all
  given exactly by the downdate algebra. The escaping-state pathology does NOT
  dominate the pin's object. G4 guidance recorded: build the V-limit on the
  ODD-difference principal term. Script + RESULTS session-5 entry in the M1
  campaign folder.

- 2026-07-21 (M1 session 6 — THE g-LEMMA): **item (b) of THEOREM-M1 closes at
  derivation+verification grade.** THE IDENTITY: sum_{n>=1}(-1)^{n+1} j_{2j+1}(z_n)
  = (-1)^j/2 for every j (deviations = computable tails at every j tested; j = 0
  case exactly proven: = m_1 = 1/2). THE MAP: g_j(N) = sqrt(2(4j+3)/N) x truncated
  sum — six decimals at low j; residue = ODD-Lanczos truncation (SAME genus as
  G-M3: the two remainders are one object). CONSEQUENCES: g_j ~ (-1)^j
  sqrt((4j+3)/2N) closed form; ALTERNATION sign(g_j) = (-1)^j over the whole clean
  range; the sqrt(N) mass hump DERIVED (predicted 50% at j = 20 vs measured 23,
  N = 800). Formal write-up = two classical steps (Poisson sign; pointwise endpoint
  convergence of the Neumann-at-1 sine series for C^1) — no research content left.
  Remaining for THEOREM-M1: the unified truncation lemma (item c = G-M3) +
  assembly. Script `t2_m1_glemma.py` + log; RESULTS session-6 entry.

- 2026-07-21 (M1 session 7 — THE ASSEMBLY): **THEOREM-M1 ASSEMBLED — G-M1 CLOSED,
  G-M3 CLOSED at lemma grade** (`M1_THEOREM_note_2026-07-21.md`, 8 parts, grades
  itemized). New in this session: (IV) the unified truncation lemma — tail masses
  exact to 4 digits (ODD 1/(3 pi^4 N^3); companion 2/(pi^2 N) = the 0.33k/2M
  shape), M^-3 deviation scaling confirmed over a decade with the effective
  constant 3.5e3 STABLE across M; edge-value growth geometric with rate -> 1.
  (V) the deviation law in closed form: alternation cancellation leaves
  ~1/(4jN)-class residual predicting the true uniform-vs-ODD deviations at 8-30%
  from PURE closed forms (one indexing bug in the cross-check caught by the
  per-point discipline, fixed same run) — session 1's "flat 1.2e-3 rel dev"
  DERIVED. Remaining polish (no research content): two classical write-ups
  (g-lemma steps) + the GS-stability constant + the production-constants ball run.
  Scripts `t2_m1_truncation_lemma.py` + log; RESULTS session-7 entry; spine
  updated.

- 2026-07-21 (M1 session 8 — write-up 1 of 3): **g-lemma step (a), the Poisson
  sign, WRITTEN AND LINE-VERIFIED** (`M1_glemma_stepA_Poisson_sign_2026-07-21.md`):
  Poisson rep 1.4e-16 (zero imaginary leak), parity reduction + sign bookkeeping
  ((-i)^{2j+1} i = (-1)^j — where the alternation is minted) verified 1.25e-15,
  sympy-EXACT anchors at j = 0, 1, and the finite-N assembly IDENTITY at 1.1e-14
  (machine; no convergence). Part (III)'s pending list shrinks to step (b) alone
  (endpoint convergence, classical). Remaining THEOREM-M1 polish: step (b),
  GS-stability write-out, optional production ball run.

- 2026-07-21 (M1 session 9 — write-up 2 of 3): **g-lemma step (b) WRITTEN —
  THEOREM-M1 PART (III) IS PROVEN.** Reflection construction (half-range string
  series = period-4 odd-harmonic Fourier series of the odd/even extension; machine
  identity 4.4e-15; even harmonics vanish); regularity inputs sympy-exact
  (P_(2j+1)(0) = 0, P'_k(1) = k(k+1)/2); Dirichlet-Jordan cited; quantitative rate
  k(k+1)/(pi^2 N) matches measurement to 4 significant figures. **The identity
  sum(-1)^{n+1} j_{2j+1}(z_n) = (-1)^j/2 is PROVEN with explicit finite-N rate;
  the alternation and closed form of the g-profile hold at PROVEN grade.**
  Remaining THEOREM-M1 polish: the GS-stability write-out (part IV) + the optional
  production ball run. Notes + scripts + logs in the campaign folder.

- 2026-07-21 (M1 session 10 — write-up 3 of 3): **GS-stability WRITTEN — THEOREM-M1
  PART (IV) PROVEN; NO PENDING WRITE-UPS REMAIN.** Lemma: |Delta alpha|+|Delta beta|
  <= 6 x1 (j+2) ||tau|| B_j^2 (Gram/Cholesky chain; two-line fixed point ||S|| <=
  2||E|| verified at 0.944 max ratio; ODD instantiation covered with 6.5e5 STABLE
  headroom across a decade of M). G-M3's grade: CLOSED at lemma grade -> PROVEN
  (crude explicit constants). THEOREM-M1 parts (I)-(VI) proven/exact; only the
  OPTIONAL production ball run remains (grade upgrade). The M-lane's mathematical
  content is COMPLETE. Note + script + log in the campaign folder.

*Update discipline: flip tags in place with a date suffix (e.g. "[GAP → PROVEN 2026-07-20]"),
append one dated line here per session, keep frozen packages untouched, and record negative
results as results — they are load-bearing (see 1.1, 2.3, 3.2, 3.4, 6.2, 6.8).*
