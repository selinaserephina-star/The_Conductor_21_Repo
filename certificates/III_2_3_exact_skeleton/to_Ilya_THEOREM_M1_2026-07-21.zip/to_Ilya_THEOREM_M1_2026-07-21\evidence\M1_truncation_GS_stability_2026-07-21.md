# Truncation lemma, GS-stability step — written out (THEOREM-M1 part IV, last pending write-up)

**Merkabit · Stenberg + Claude · 2026-07-21 (session 10). Verified line-by-line in
`t2_m1_GS_stability_check.py`. With this, THEOREM-M1 has no pending write-ups; the
production ball run remains an optional grade upgrade. Not RH/GRH.**

## Statement

Let μ be a measure on [0, x₁], μ̃ = μ − τ with τ ≥ 0 supported in [0, x*] ⊆ supp-hull,
and let {p_i} be the μ-orthonormal polynomials. Fix j and set

  E_{ik} := ⟨p_i, p_k⟩_τ  (i, k ≤ j+1),   B_j := max_{i≤j+1} sup_{[0,x*]} |p_i|,

so |E_{ik}| ≤ ‖τ‖·B_j² and ‖E‖_op ≤ (j+2)‖τ‖B_j². **If ‖E‖_op ≤ ¼, then the Jacobi
entries of μ̃ satisfy, for all i ≤ j:**

  **|Δα_i| + |Δβ_i| ≤ 6·x₁·(j+2)·‖τ‖·B_j²  =: C_GS(j)·‖τ‖·B_j².**

## Proof

**(S1) Gram and X-pairings perturb by τ-pairings.** ⟨p_i,p_k⟩_{μ̃} = δ_{ik} − E_{ik};
⟨xp_i,p_k⟩_{μ̃} = X_{ik} − F_{ik} with |F_{ik}| = |⟨xp_i,p_k⟩_τ| ≤ x*·‖τ‖B_j² ≤
x₁·‖τ‖B_j² (so ‖F‖_op ≤ (j+2)x₁‖τ‖B_j²).

**(S2) Cholesky/GS correction (two-line fixed point).** The ordered orthonormalization
of {p_i} under μ̃ is p̃ = R^{−T}p with RᵀR = I − E, R upper triangular. Writing
R = I + S: Sᵀ + S + SᵀS = −E; the triangular-split fixed-point map S ↦
−up(E + SᵀS) (up = strictly-upper + half-diagonal, a norm-nonexpansive projection on
symmetric arguments) is a contraction on {‖S‖ ≤ ‖E‖} whenever ‖E‖ ≤ ¼:
‖up(E + SᵀS)‖ ≤ ‖E‖ + ‖S‖² ≤ ‖E‖(1 + ‖E‖) and the iteration contracts with factor
2‖S‖ ≤ ½. Hence **‖S‖ ≤ (4/3)‖E‖ ≤ 2‖E‖** and ‖R^{−1} − I‖ ≤ ‖S‖/(1−‖S‖) ≤ 2‖E‖.
[Verified numerically on random E at three scales.]

**(S3) Assembly.** J̃ = tri(R^{−T}(X − F)R^{−1}) in the p-coordinates; with
‖X‖ ≤ x₁ (multiplication by x on [0, x₁]),

  ‖J̃ − J‖ ≤ 2‖R^{−1} − I‖·‖X‖ + ‖F‖·(1 + O(‖E‖)) ≤ 4‖E‖x₁ + (j+2)x₁‖τ‖B² + h.o.
          ≤ 6x₁(j+2)‖τ‖B_j²   (using ‖E‖ ≤ (j+2)‖τ‖B², ‖E‖ ≤ ¼ for the h.o. slack).

Entrywise |Δα_i|, |Δβ_i| ≤ ‖J̃ − J‖. ∎

## Instantiation (the rates of part IV, now with proven constants)

- **ODD system:** ‖τ_N‖ = Σ_{n>N}z_n^{−4} = 1/(3π⁴N³)(1+O(1/N)) (exact scale,
  verified to 4 digits); supp τ ⊂ [0, x_{N+1}], where B_j is controlled by the
  near-zero values |p_i(0)| (geometric with rate → 1; |p_{13}(0)|-class ~ 10–10²
  for the lemma range j ≤ 12). The proven bound covers the measured effective
  constant C·B² ≈ 3.5×10³ with explicit headroom [measured below].
- **Companion:** ‖τ_M‖ = 2Σ_{n>M}z_n^{−2} = 2/(π²M)(1+O(1/M)) — the k-growth of the
  measured 0.33k/2M drift enters through B_k (edge values grow with k).

## Status

Part (IV)'s write-up is DONE: the lemma is PROVEN with crude explicit constants
(C_GS(j) = 6x₁(j+2)), and the measured stable constant (3.5e3 across a decade of M)
sits inside the proven envelope with quantified headroom. THEOREM-M1 has NO pending
write-ups. Optional remaining: the production-constants ball run (grade upgrade only).
