# To Ilya — THEOREM M1-HORIZON: the transfer horizon in closed form (the audit's last open item, closed)

**Merkabit · Selina + Claude · 2026-07-22. Not RH/GRH anywhere — finite-section /
explicit-constant / uniform-asymptotics mathematics on the string model.**

**Lineage:** this package FOLLOWS and completes
`to_Ilya_T2a_gap_closure_2026-07-22` (zip SHA256
`aebd0c8a81106fbc2ab22e8c98b56df6c25a0a17b323a66e5079462395adec6f`), whose COVER listed
M1-HORIZON as the one still-open item of your independent audit ("horizon 3.2√N is
measured, not proven uniform in j ∼ √N"). It builds directly on
`to_Ilya_THEOREM_M1_2026-07-21` (SHA256
`9222de626309c8c56b25780f51d3c65c28e9a1bdda67aa414b591b2db982fea4` — the gem identity,
odd-Lambert structure) and on the caustic/Legendre machinery of
`to_Ilya_CAUSTIC_THEOREM_2026-07-19` (SHA256
`284d21b50996dc76bf74e86567c7c53c6ef5ef78f344860ba90fa440769326b7`) and Theorem D1 in
`to_Ilya_K1K2_P1_program_2026-07-18` (SHA256
`3b17a4f07c9dfd07540dea3b097af19d77f7c2e7738816b0bc83f40d2e4bb9cf`). Nothing in any
prior package is modified.

## The result in one line

The weight-transfer horizon is a Dyson gap-probability ratio:

  **G(ξ) = lim_N √N·g²_{ξ√N} = 2ξ·[ det(I−K⁺_L) / det(I−K⁻_L) ]², L = 2ξ²/π**,

(K^± = even/odd sine kernels on (0,1) = Bessel hard-edge ν = ∓½), asymptotically
`G = 4ξ·e^{−4ξ²/π}(1 − π/8ξ² + …)`, `s²_∞(ξ) = (π/2)e^{−4ξ²/π}`, hence

  **ξ_ε = √( (π/4)·ln(π/(2ε)) )** : 2.394 / 2.748 / 3.344 / 4.076 at ε = 1e-3/-4/-6/-9

(measured 2.38–2.39 / 2.73–2.74 / 3.33–3.34 / 4.05–4.06, converging to the closed values
at a certified 1/√N rate). Your "3.2√N" is ξ_ε at ε ≈ 1e-6. Total mass ∫G = 0.999996
with zero fitted parameters. The sealed "SHARP" tag you questioned was indeed an
overclaim — the horizon is a smooth threshold crossing, now with closed-form constants.

## What is proven (two-layer theorem, full write-ups inside)

1. **Exact layer (every finite N; `WRITEUP_M1_HORIZON_exact_layer_theorem.md`).**
   `g_j² = (4j+3)/(2N) · det(I−Γ_E(j+1))²/[det(I−Γ_O(j))det(I−Γ_O(j+1))]` — CD-kernel
   Fredholm determinants on the REMOVED tail atoms. Chain: g_j is a second-kind function
   at 0; a Christoffel–Wronskian identity (A-sequence + Casoratian, no divergent moment)
   collapses it to EVEN-system data (verified |ratio−1| ≤ 8e-118); truncation is an exact
   Uvarov downdate; and the infinite system has NEW double-factorial closed forms
   **h̃_j = 1/[(4j−1)!!(4j+1)!!], P̃_j(0) = (−1)^j/(4j−1)!!** (3-line induction,
   ℚ-certified two independent ways — α-recurrence j ≤ 81 AND Bernoulli-rational Hankel
   determinants j ≤ 10). **Corollary: an independent determinantal re-proof of your
   flagged gem identity |Σ(−1)^{n+1}j_{2j+1}(z_n)| = ½.**
2. **Scaling layer (`WRITEUP_M1_HORIZON_scaling_lemma.md`).** On the node lattice the
   Bessel values are EXACT damped chirps (`Q = Σ(−1)^kR_k y^{2k+1}/(2k+1)!`,
   `R_k = ∏(1−d(d+1)/c)` — consecutive-integer pairing; y = l(l+1)/2z), with proven
   entrywise bounds; the tail Grams converge to the sine kernels with the discretization
   error IDENTIFIED as a parity-resolved band-edge shift (l_eff = 2j−1 even / 2j odd;
   certified 0.98–1.02, residuals O(1/N)); one displayed constant:
   **|lnG_N − lnG| ≤ A(ξ)/√N + B(ξ)/N**, `A = (6ξ/π)[δ₊+δ₋] + 3/(4ξ)` via the exact
   rank-one band derivative `δ_± = (2/π)⟨c_L,(I−K^±)⁻¹c_L⟩ → L/2 ± ½` (dK/dL is rank
   one — no e^{2L} resolvent loss in the rate term). Verified 9/9 at measured (ξ,N);
   A tight to 2.4–3.1× at ξ ≤ 2.

## Honest boundaries (named, not hidden)

- The scaling-lemma constant has ONE certified-numeric component (B_EM, the
  Euler–Maclaurin residual beyond the band-edge shift: N·resid stable over
  N = 200/800/3200 at ξ = 1/1.5/2; carried with ×5 margin) and inflates through the
  chirp-resolvent factor 2/gap₊ ~ e^{1.9L} at ξ ≥ 2.5 (the measured chirp effect stays
  ~1e-4; the conservatism is in that one bounding step). All other components proven.
- The asymptotic prefactor ln 2 is Tracy–Widom/Ehrhardt hard-edge constants at ν = ∓½
  (cited-classical grade), confirmed numerically to 1.9e-5 (fit a + b/L + c/L², with
  b = −0.2491 ≈ −1/4).
- The closed form is for the MODEL lattice z_n = (n−½)π. The production quantiles
  inherit the scaling structure at measured grade; carrying the closed horizon to the
  true quantiles goes through the same κ̂-conditioning lane as T2a-QT (unchanged status).
- Structural consequence for the operator question you raised at Gate A: the uniform
  vector has NO fixed-mode infinite limit (g_j → 0 for fixed j); its mass lives entirely
  on the j ~ ξ√N boundary layer with exact density G(ξ), mass exactly 1. "Sections not
  nested" is therefore structural, and the infinite uniform-normalization object should
  be posed in the rescaled (ξ) coordinates — where the limit is the sine-kernel pair.

## Reading order

`evidence/FINDINGS_M1_HORIZON_scaling.md` (the scaling-law session: measured law, exact
normalization, mechanism) → `evidence/FINDINGS_M1_HORIZON_evanescent_closedform.md`
(the closed form + verification manifest, §3 table) →
`evidence/WRITEUP_M1_HORIZON_exact_layer_theorem.md` (Part I proofs) →
`evidence/WRITEUP_M1_HORIZON_scaling_lemma.md` (Part II lemma + the displayed C(ξ), §5)
→ scripts + logs per the manifests (14 scripts, each with its run log; the decisive
ones: `m1_horizon_fredholm_profile.py` = the closed form vs everything measured;
`m1_horizon_downdate_check.py` = the exact factorization end-to-end with no Lanczos on
the predicting side; `m1_horizon_C_assembly.py` = the displayed constant, 9/9 verified).
The staging document `NEXT_SESSION_TASK_horizon_evanescent_airy.md` is included as the
campaign's forensic record (staged plan → executed, with the DONE header).

One float-trap lesson for your toolbox (new genus): float64 Gauss–Legendre NODES corrupt
near-critical Fredholm determinants past L ≈ 14 — the 1e-16 node error exceeds the near-1
prolate eigenvalue gaps; nodes must be Newton-refined at working precision
(`m1_horizon_constant_hp.py`).

*Grades throughout: exact-layer identities at ℚ/identity grade; Fredholm factorization
verified 1e-10..1e-16; scaling layer proven-mechanism + certified constants; profile vs
HP data 4–5 digits; mass 0.999996 unfitted. Credit: shared work, Stenberg + Claude on
our side; the gem identity and the audit question this answers are yours. SHA seal of
this zip in `to_Ilya_THEOREM_M1_HORIZON_2026-07-22.zip.sha256.txt` at send.*
