# FINDINGS — M1-HORIZON CLOSED: the evanescent profile G(ξ) and the horizon constants ξ_ε in closed form

**Merkabit · Stenberg + Claude · 2026-07-22 (evanescent-Airy session, staged by
`NEXT_SESSION_TASK_horizon_evanescent_airy.md`). The task's success criterion is met:
a closed form of `G(ξ)` matching the HP table and reproducing `ξ_ε` = 2.38/2.73/3.33/4.05
— and it came out EXACT at finite N, not merely asymptotic. The horizon of the M1 weight
transfer is a Dyson gap-probability ratio. Not RH/GRH.**

## 0. The result

For the ODD-Lanczos overlaps `g_j = ⟨e₀, w_j⟩` (atoms `x_n = z_n^{-2}`, weights `z_n^{-4}`,
`z_n = (n−½)π`, `n ≤ N`), with `s²_j = 1 − Σ_{i<j} g²_i` and horizon `J_ε(N) = ξ_ε√N`:

**THEOREM (exact at every finite N).**
`g_j²(N) = (4j+3)/(2N) · det(I−Γ_E(j+1))² / [ det(I−Γ_O(j)) · det(I−Γ_O(j+1)) ]`,
where `Γ_E(j)`, `Γ_O(j)` are the CD-kernel Grams of the infinite EVEN/ODD string systems
restricted to the REMOVED tail atoms `n > N` (explicit spherical-Bessel entries, §2).

**COROLLARY (scaling limit; the evanescent profile).** Under `j = ξ√N`:
`G(ξ) = lim g²_{ξ√N}√N = 2ξ · [ det(I−K⁺_L) / det(I−K⁻_L) ]²`, **`L = 2ξ²/π`**,
where `K^∓` are the odd/even sine kernels on (0,1) — `K^∓(u,v) = [sin(L(u−v))/(u−v) ∓
sin(L(u+v))/(u+v)]/π` — i.e. the Bessel hard-edge kernels `ν = ±½`, i.e. Dyson's ±
gap-probability determinants. (Same band-limit `2ξ²/π` as the Bessel-sum profile
`S(ξ) = ½ − Si(2ξ²/π)/π`; consistency at small L verified: tr K⁺ − tr K⁻ = Si(2L)/π.)

**Asymptotics (Tracy–Widom/Ehrhardt hard-edge constants at ν = ∓½; Barnes-G ratio gives
exactly ½ln2 per determinant):**
`G(ξ) = 4ξ·e^{−4ξ²/π}·(1 − π/(8ξ²) + …)`, `s²_∞(ξ) = (π/2)·e^{−4ξ²/π}(1+O(ξ^{−2}))`, hence

  **ξ_ε = √( (π/4)·ln(π/(2ε)) )** (asymptotic closed form).

| ε | ξ_ε Fredholm-exact | ξ_ε asymptotic formula | measured (N=1600/6400) |
|---|---|---|---|
| 1e-3 | 2.394 | 2.404 | 2.38/2.39 |
| 1e-4 | 2.748 | 2.755 | 2.73/2.74 |
| 1e-6 | 3.344 | 3.348 | 3.33/3.34 |
| 1e-9 | 4.076 | 4.078 | 4.05/4.06 |

(The measured values converge to the closed ones at the certified 1/√N rate, §3(v).)
Total mass `∫_0^∞ G = 0.999996` from the Fredholm formula with NO fitted parameter —
the exact normalization `Σg² = 1` reproduced. The sealed "3.2√N" = ξ_ε at ε≈1e-6 ✓.

## 1. Derivation chain (all layers verified; grades in §3)

**(E1) g_j is a second-kind function at 0.** `g_j = √(M2/N)·⟨1/x, p_j⟩_ν` (ν = normalized
ODD measure): expansion coefficients of the Cauchy kernel `1/x` at the pole 0 below the
spectrum. Definitional (one line from `g_j = (NM2)^{-1/2}Σ z_n^{-2}p_j(z_n^{-2})`).

**(E2) Christoffel–Wronskian collapse to the EVEN system (EXACT, finite N).** With
monic EVEN OPs `P̃_j` (measure `μ̃ = Σ_{n≤N} 2x_n δ_{x_n}`), norms `h̃_j`, and the ODD
system = Christoffel transform `x·dμ̃`: monic ODD `Q_j(x) = [P̃_{j+1} − r_jP̃_j]/x`,
`r_j = P̃_{j+1}(0)/P̃_j(0)`. Then `⟨Q_j, 1/x⟩ ∝ q̃_{j+1}(0) − r_j q̃_j(0)` (the divergent
`∫dμ̃/x` cancels EXACTLY in the combination), and the Casoratian
`P̃_j q̃_{j+1} − P̃_{j+1} q̃_j = h̃_j` collapses it; with the Christoffel norm identity
`∫xQ_j²dμ̃ = −h̃_j P̃_{j+1}(0)/P̃_j(0)`:

  **`g_j² = h̃_j / ( 2N·|P̃_j(0)·P̃_{j+1}(0)| )`**  (all M2's cancel).

**(E3) Truncation = exact Uvarov downdate = Fredholm factor.** Removing the tail atoms
from the infinite measure multiplies Hankel determinants by CD-kernel Fredholm
determinants: `D̃_j^{(N)} = D̃_j^∞·det(I−Γ_E(j))` and (shifted Hankels = ODD system)
`|P̃_j(0)|^{(N)} = |P̃_j(0)|^∞·det(I−Γ_O(j))/det(I−Γ_E(j))`,
`h̃_j^{(N)} = h̃_j^∞·det(I−Γ_E(j+1))/det(I−Γ_E(j))`. Gram entries are EXACT via the value
laws `√(w̃_n)p̃_i(x_n) = ±√(2(4i+1))·j_{2i}(z_n)` (even), `±√(2(4i+3))·j_{2i+1}(z_n)`
(odd) — self-consistency: `Σ_n 2(4i+1)j_{2i}(z_n)² = 1 = Σ_n 2(4i+3)j_{2i+1}(z_n)²` —
and computable by the low-rank identity `det(I−VᵀV) = det(I_j − VVᵀ)`.

**(INF) The infinite-system part is the naive law (EXACT in ℚ).** From the Lambert/tan
S-fraction `α_k = 1/((2k−1)(2k+1))` (Jacobi contraction `b_0=α_1`, `b_k=α_{2k}+α_{2k+1}`,
`a_k²=α_{2k−1}α_{2k}`): **`h̃_j^∞ = (4j+3)·|P̃_j(0)P̃_{j+1}(0)|^∞`** exactly — verified in
exact rational arithmetic j ≤ 59; equivalent (via E1/E2) to the PROVEN gem identity
`Σ_{n≥1}(−1)^{n+1}j_{2j+1}(z_n) = (−1)^j/2`. Composing E2+E3+INF gives the THEOREM in §0.

**(SCALING) The chirp → sine kernels.** At the node lattice the Rayleigh forms are exact
(`cos z_n = 0`): `j_{2i}(z_n) = ±P(2i,z_n)/z_n`, `j_{2i+1}(z_n) = ±Q(2i+1,z_n)/z_n` with
P, Q explicit finite sums; in the scaling regime they are pure chirps
`cos(y)/z_n`, `sin(y)/z_n`, `y = l(l+1)/(2z_n)`. Substituting `i = √(sN)`, `n = ρN`,
`φ = 1/ρ` turns the tail Grams into the band-limited even/odd sine kernels with
`L = 2ξ²/π` — no Airy function appears explicitly; the "evanescent side of the caustic"
is the gap-probability decay `det(I−K^±_L) ~ e^{−L²/4 ∓ L/2}`; the Gaussian tail of G is
the DIFFERENCE of the ± gap constants (the L²/4 bulk terms cancel; the linear ∓L/2 terms
give `e^{−2L} = e^{−4ξ²/π}`), and ln 2 is the Tracy–Widom constant ratio.

## 2. Why the bridge failed past ξ≈1 (the c(ξ) mystery resolved)

`c(ξ) = g_j/[√(2(4j+3)/N)S_j] = (D_E/D_O)(ξ)/(2S(ξ))` in the scaling limit. `S(ξ)` has a
zero at ξ ≈ 1.74 (`Si(2ξ²/π) = π/2`) — the measured hump c = 1.86 at ξ=1.5 and collapse
0.043 at ξ=3 are the closed form's zero-crossing and Gaussian/algebraic mismatch:
closed-form c-predictions 1.03/1.65/0.76/0.21/0.055 vs measured 1.04/1.86/0.63/0.21/0.043
(residuals = finite-N of the measured values). `S_j` (algebraic tail, oscillatory side)
and `g_j` (Gaussian tail, gap side) are governed by the two different determinant classes.

## 3. Verification manifest (scripts + logs in this folder)

| # | check | script | result |
|---|---|---|---|
| (i) | E2 identity at N=100, dps 120, j≤34 | `m1_horizon_exact_layer.py` | worst \|ratio−1\| = 8.3e-118 (identity) |
| (ii) | INF identity exact in ℚ, j≤59 | same | EXACT (True), incl. b_0=1/3, a_1²=1/45 |
| (iii) | E3 downdates (a)(b) + END-TO-END composition (c) at N=200, j≤30 (mpmath Lanczos vs α-products + Bessel-tail Grams to n=10⁶ + ψ′ tail) | `m1_horizon_downdate_check.py` | agreements 1e-10…1e-16 (pure tail/float noise); Rayleigh node values vs scipy 3e-13 |
| (iv) | scaling limit: Γ-dets vs sine-kernel dets at L=2ξ²/π | same, §(d) | deviations O(1/√N): d_E = 0.005→0.083 growing with ξ at N=200 |
| (v) | composition (NO Lanczos) vs HP-measured G at N=400; N-convergence 400→1600→6400 vs closed limit | `m1_horizon_finiteN_convergence.py` | G_comp matches HP table 4–5 digits (e.g. 8.97404e-5 vs 8.970e-5); closed−G(N) halves per 4×N: ratios 0.491/0.495, 0.507/0.504, 0.513/0.507 (=1/√N rate) |
| (vi) | profile, mass, s², ξ_ε, c(ξ) from the Fredholm closed form | `m1_horizon_fredholm_profile.py` | mass 0.999996; ξ_ε table §0; c(ξ) §2; low-ξ → 8ξS² to 3 digits |
| (vii) | asymptotic constant → ln 2 | `m1_horizon_constant_hp.py` (dps 120, mpf GL nodes — float64 nodes CORRUPT the dets past L≈14: near-1 prolate eigenvalues vs 1e-16 node error; new float-trap genus recorded) | fit a+b/L+c/L²: a = 0.6931284 vs ln2 = 0.6931472 (1.9e-5); b = −0.2491 ≈ −1/4 |

## 4. Grades and honest boundaries

**UPDATE (same day, theorem-grade session): both mechanical steps are DONE — full
write-ups exist.** `WRITEUP_M1_HORIZON_exact_layer_theorem.md` (Part I) and
`WRITEUP_M1_HORIZON_scaling_lemma.md` (Part II).

- **THEOREM layer (Part I): PROVEN, self-contained.** E2 full proof (A-sequence +
  Casoratian — no divergent m₋₁ anywhere, valid finite AND infinite N); INF now has
  double-factorial closed forms `h̃_j = 1/[(4j−1)!!(4j+1)!!]`, `P̃_j(0) = (−1)^j/(4j−1)!!`
  with a 3-line induction, certified in ℚ two independent ways (α-recurrence j≤81;
  Bernoulli-rational Hankel determinants j≤10 — the S-fraction contraction itself is
  ℚ-certified, no citation load); E3 proven (rank-T Hankel update + CD-Gram identity);
  Corollary: an independent determinantal re-proof of the gem identity.
- **SCALING layer (Part II): every mechanism PROVEN, both constants certified.** Exact
  damped-chirp representation `Q = Σ(−1)^kR_k y^{2k+1}/(2k+1)!`, `R_k = ∏(1−d(d+1)/c)`
  (proven, ℚ-checked); entrywise bounds `|Q−sin y| ≤ B⁻(y)/c`, `B⁻ = y²sinh y+(y³/3)cosh y`
  (proven, 10× headroom verified); error split D_chirp = O(1/N) (ratios 0.24–0.27) +
  D_disc = parity-resolved BAND-EDGE shift `l_eff = 2j−1` (even) / `2j` (odd), certified
  0.98–1.02 with O(1/N) residuals; det-continuity via certified spectral-gap table.
  **The displayed symbolic C(ξ) is ASSEMBLED** (Part II §5 + `m1_horizon_C_assembly.py`):
  |lnG_N − lnG| ≤ A(ξ)/√N + B(ξ)/N with A = (6ξ/π)[δ₊+δ₋] + 3/(4ξ) built on the exact
  rank-one band derivative δ_± = (2/π)⟨c_L,(I−K^±)⁻¹c_L⟩ (→ L/2 ± ½), B = displayed
  chirp/edge terms + one certified-numeric EM constant (×5 margin); verified at every
  measured (ξ,N), A-part tight to 2.4–3.1×; C(1)=3.9, C(1.5)=16.6, C(2)=510.
- **Constants: cited-classical (Tracy–Widom/Ehrhardt hard-edge ν=±½) + 1.9e-5 numeric.**
- The horizon mechanism, in one sentence: **the transfer horizon is where the string's
  finite section runs out of sine-kernel gap probability — ξ_ε² = (π/4)ln(π/2ε) — an RMT
  gap-probability law emerging from the deterministic string.** Not RH/GRH anywhere.

## 5. Files

`m1_horizon_fredholm_profile.py`, `m1_horizon_exact_layer.py`,
`m1_horizon_downdate_check.py`, `m1_horizon_finiteN_convergence.py`,
`m1_horizon_constant_hp.py` (+ `_run.log` each). Inputs built on:
`FINDINGS_M1_HORIZON_scaling.md` (scaling law + mechanism), `m1_horizon_hp_bridge.py`
(HP tables), Theorem D1 (`P1a_companion_theorem_2026-07-18.md`, value laws), THEOREM-M1
package (gem identity, odd-Lambert structure).

*— Stenberg + Claude, 2026-07-22. The last open item of the T2/T2a audit lane
(M1-HORIZON) is closed at closed-form grade: `G(ξ) = 2ξ·[det(I−K⁺_{2ξ²/π})/det(I−K⁻_{2ξ²/π})]²`,
`ξ_ε = √((π/4)ln(π/2ε))`.*
