# WRITE-UP — THEOREM M1-HORIZON, Part I (exact layer): full proofs

**Merkabit · Stenberg + Claude · 2026-07-22. The finite-N exact layer of the horizon
closed form, at write-up grade: every identity proven, every proof verified by machine
(manifest §6). Companion: `WRITEUP_M1_HORIZON_scaling_lemma.md` (Part II, the scaling
limit). Results announced in `FINDINGS_M1_HORIZON_evanescent_closedform.md`. Not RH/GRH.**

## 0. Setting and statement

Atoms `x_n = z_n^{-2}`, `z_n = (n−½)π`, `n = 1..N`. Systems:
- **ODD**: `ν` = normalized measure with weights `u_n = x_n²/M2`, `M2 = Σ_{n≤N} x_n²`;
  orthonormal OPs `p_j`; the overlaps are `g_j = ⟨e₀, w_j⟩`, `w_j[n] = √(u_n)p_j(x_n)`,
  `e₀ = 𝟙/√N` (THEOREM-M1 part I objects).
- **EVEN**: `μ̃ = Σ_{n≤N} 2x_n δ_{x_n}`; monic OPs `P̃_j`, norms `h̃_j = ∫P̃_j²dμ̃`,
  Jacobi recurrence `P̃_{j+1}(x) = (x−b_j)P̃_j(x) − a_j²P̃_{j−1}(x)`.
- Superscript ∞ = the same with `n` ranging over all of ℕ (all moments finite).

**THEOREM 1 (Christoffel–Wronskian collapse; exact for every N ≥ 1, 0 ≤ j < N).**
  `g_j² = h̃_j / ( 2N · |P̃_j(0) P̃_{j+1}(0)| )`.

**THEOREM 2 (infinite system; double-factorial closed forms).**
  `P̃_j^∞(0) = (−1)^j/(4j−1)!!`, `h̃_j^∞ = 1/[(4j−1)!!(4j+1)!!]`, hence
  `h̃_j^∞ = (4j+3)·|P̃_j^∞(0) P̃_{j+1}^∞(0)|` for all j ≥ 0.

**THEOREM 3 (truncation = Uvarov downdate = Fredholm factor).** For the tail
`τ = Σ_{n>N} 2x_n δ_{x_n}` and the CD kernels `K̃_j(x,y) = Σ_{i<j} p̃^∞_i(x)p̃^∞_i(y)`
(EVEN orthonormal) resp. `K_j` (ODD of `x·dμ̃^∞`):
  `D̃_j^{(N)} = D̃_j^∞ · det(I − Γ_E(j))`, `D_j^{(1),(N)} = D_j^{(1),∞} · det(I − Γ_O(j))`,
with `Γ_E(j) = [√(w_nw_m) K̃_j(x_n,x_m)]_{n,m>N}`, `w_n = 2x_n` (resp. `Γ_O`, weights
`2x_n²`), Fredholm determinants of trace-class PSD contractions. Consequently
(`h̃_j = D̃_{j+1}/D̃_j`, `|P̃_j(0)| = D_j^{(1)}/D̃_j`):

**COROLLARY 1 (master formula, exact at every finite N).**
  `g_j² = (4j+3)/(2N) · det(I−Γ_E(j+1))² / [ det(I−Γ_O(j)) · det(I−Γ_O(j+1)) ]`.

**COROLLARY 2 (independent proof of the gem identity).**
  `|Σ_{n≥1} (−1)^{n+1} j_{2j+1}(z_n)| = ½` for every j ≥ 0.

## 1. Proof of Theorem 1

*Step 1 (coefficients of the Cauchy kernel).* `g_j = (NM2)^{-1/2} Σ_n z_n^{-2}p_j(x_n)
= √(M2/N)·Σ_n u_n p_j(x_n)/x_n = √(M2/N)·⟨1/x, p_j⟩_ν`. (Algebra; `u_n/x_n·M2 = x_n`.)

*Step 2 (Christoffel transform).* `dν = x dμ̃/(2M2)` on the atoms (check: `x_n·2x_n/(2M2)
= u_n`). Since `μ̃` is positive on `(0,∞)`, `P̃_j(0) ≠ 0`; set `r_j = P̃_{j+1}(0)/P̃_j(0)`
and `Q_j(x) = [P̃_{j+1}(x) − r_jP̃_j(x)]/x` — a monic polynomial of degree j (numerator
vanishes at 0). For any `π` with deg π < j: `∫Q_j π dν = (2M2)^{-1}∫(P̃_{j+1}−r_jP̃_j)π dμ̃
= 0`, so `Q_j` is the monic ODD OP.

*Step 3 (the A-sequence).* Define `A_0 = 0`, `A_1 = m̃_0 (= μ̃-mass)`, and
`A_{k+1} = −b_kA_k − a_k²A_{k−1} + [the x-recurrence at 0]` — precisely, `A_k` solves the
SAME three-term recurrence as `P̃_k(0)` for k ≥ 1. Then
  `A_k = ∫ [P̃_k(x) − P̃_k(0)]/x dμ̃(x)`.
*Proof:* the integral is finite (integrand → P̃_k′(0)), equals 0 at k=0 and m̃_0 at k=1
(`P̃_1 = x−b_0`), and for k ≥ 1 satisfies the recurrence because `x⁻¹[P̃_{k+1}(x) −
P̃_{k+1}(0)] = (x−b_k)x⁻¹[P̃_k−P̃_k(0)] − a_k²x⁻¹[P̃_{k−1}−P̃_{k−1}(0)] + P̃_k(x) −
[P̃_k(0) + b_k(...)−...]`-bookkeeping: integrate the recurrence `P̃_{k+1} = (x−b_k)P̃_k −
a_k²P̃_{k−1}` minus its value at 0, divided by x; the leftover term is `∫P̃_k dμ̃ = 0`
for k ≥ 1. ∎ (For finite N one may equivalently write `A_k = q̃_k(0) − P̃_k(0)·∫dμ̃/x`;
the A-form needs no `∫dμ̃/x` and survives the N→∞ limit, where `∫dμ̃^∞/x = Σ2 = ∞`.)

*Step 4 (Casoratian).* `C_j := P̃_{j+1}(0)A_j − P̃_j(0)A_{j+1}` satisfies `C_0 = −m̃_0 =
−h̃_0` and `C_j = a_j²C_{j−1}` (both sequences solve the same recurrence for j ≥ 1),
hence `C_j = −h̃_0∏_{k≤j}a_k² = −h̃_j`:
  **`P̃_j(0)A_{j+1} − P̃_{j+1}(0)A_j = h̃_j`.**

*Step 5 (numerator).* `⟨1/x, Q_j⟩_ν = (2M2)^{-1}∫Q_j dμ̃ = (2M2)^{-1}[A_{j+1} − r_jA_j]`
(the `P̃(0)`-terms cancel exactly by the definition of `r_j`) `= h̃_j/(2M2·P̃_j(0))` by
Step 4.

*Step 6 (norm).* `‖Q_j‖²_ν = (2M2)^{-1}⟨xQ_j, Q_j⟩_μ̃ = (2M2)^{-1}⟨P̃_{j+1}−r_jP̃_j,
Q_j⟩_μ̃ = −r_j h̃_j/(2M2)` (monicity: `⟨P̃_j, Q_j⟩_μ̃ = h̃_j`; orthogonality kills
`P̃_{j+1}`). Positive since the `P̃_j(0)` alternate in sign.

*Assembly.* `g_j² = (M2/N)·⟨1/x,Q_j⟩²_ν/‖Q_j‖²_ν = (M2/N)·[h̃_j/(2M2P̃_j(0))]²·
(2M2)/(−r_jh̃_j) = h̃_j/(2N·(−P̃_j(0)P̃_{j+1}(0)))`. ∎
(Machine check: |ratio−1| ≤ 8.3e-118 at N=100, dps 120, j ≤ 34 — an identity.)

## 2. Proof of Theorem 2

The Stieltjes transform of `μ̃^∞` is elementary: `Σ_n 2x_n/(1−sx_n) = Σ_n 2/(z_n²−s·z_n²x_n)`
… = `tan(√s)/√s` (partial fractions of tan). Its Stieltjes/Lambert S-fraction has
coefficients `α_m = 1/((2m−1)(2m+1))`, and the standard contraction gives the Jacobi
data `b_0 = α_1 = 1/3`, `b_j = α_{2j}+α_{2j+1}`, `a_j² = α_{2j−1}α_{2j}` (j ≥ 1).
**Self-contained certification (no citation load):** the moments of `μ̃^∞` are RATIONAL
(`m̃_k = 2(2^{2k+2}−1)ζ(2k+2)/π^{2k+2}`, Bernoulli), and the Hankel determinants
`D̃_j = det[m̃_{a+b}]`, `D_j^{(1)} = det[m̃_{a+b+1}]` computed EXACTLY in ℚ match
`∏_{i<j} 1/[(4i−1)!!(4i+1)!!]` and `D̃_j/(4j−1)!!` for j ≤ 10; the α-recurrences
reproduce `P̃_j(0)`, `h̃_j` in ℚ for j ≤ 81.

*Closed forms.* `h̃_j = m̃_0·∏_{k≤j}a_k² = ∏_{m=1}^{2j}α_m = 1/[∏(2m−1)·∏(2m+1)]
= 1/[(4j−1)!!(4j+1)!!]`. For `P̃_j(0) = (−1)^j/(4j−1)!!`, induct: base `P̃_0 = 1`,
`P̃_1(0) = −1/3`. Step: it suffices that
  `1/(4j+3)!! = b_j/(4j−1)!! − a_j²/(4j−5)!!`.
Indeed `a_j²·(4j−1)(4j−3) = α_{2j−1}α_{2j}(4j−1)(4j−3) = 1/((4j−1)(4j+1)) = α_{2j}`,
so the RHS `= (b_j − α_{2j})/(4j−1)!! = α_{2j+1}/(4j−1)!! = 1/((4j+1)(4j+3)(4j−1)!!)
= 1/(4j+3)!!`. ∎ Then `(4j+3)|P̃_jP̃_{j+1}(0)| = (4j+3)/[(4j−1)!!(4j+3)!!] =
1/[(4j−1)!!(4j+1)!!] = h̃_j`. ∎ (ℚ-verified j ≤ 80, incl. the induction identity.)

## 3. Proof of Theorem 3

Hankel matrices: `H_j(μ) = [m_{a+b}(μ)]_{a,b<j}`. Removing the tail is a rank-T update:
`H_j(μ̃^{(N)}) = H_j(μ̃^∞) − M W Mᵀ`, `M = [x_n^a]_{a<j, n>N}`, `W = diag(2x_n)`. By the
determinant lemma, `det H_j(μ̃^{(N)}) = det H_j(μ̃^∞)·det(I − W^{1/2}MᵀH_j^{-1}MW^{1/2})`,
and `MᵀH_j^{-1}M = [K̃_j(x_n,x_m)]` is the CD-kernel Gram (`K̃_j(x,y) = m(x)ᵀH_j^{-1}m(y)`
— the change to the orthonormal basis diagonalizes `H_j`). The tail Gram is PSD and
trace-class: `tr = Σ_{n>N} 2x_nK̃_j(x_n,x_n) < ∞` (value laws below), so the infinite-T
determinant is a convergent Fredholm determinant; `I − Γ ≻ 0` because `μ̃^{(N)}` still has
≥ j atoms (its Hankel is PD). The same argument with weights `2x_n²` and the ODD CD
kernel gives the shifted-Hankel (`D^{(1)}` = Hankel of `x·dμ̃`) factorization. The Gram
entries are EXACT Bessel values by the value laws (Theorem B1/D1 lineage, self-consistency
`Σ_n 2(4i+1)j_{2i}(z_n)² = 1 = Σ_n 2(4i+3)j_{2i+1}(z_n)²`):
`√(2x_n)p̃^∞_i(x_n) = ±√(2(4i+1))·j_{2i}(z_n)`, `√(2x_n²)p^∞_i(x_n) = ±√(2(4i+3))·j_{2i+1}(z_n)`.
∎ (Machine check: downdates (a),(b) and the end-to-end composition (c) agree to
1e-10…1e-16 at N=200, j ≤ 30, with NO Lanczos on the predicting side.)

## 4. Proof of Corollary 2 (gem identity re-derived)

Run Theorem 1's proof verbatim for the INFINITE system (`N` and `e₀` drop out; use the
A-sequence, which is finite in the limit): the orthonormal-coefficient of `1/x` is
`⟨1/x, p_j⟩_{ν^∞} = √( h̃_j^∞ / (2M2^∞·|P̃_j^∞(0)P̃_{j+1}^∞(0)|) ) = √((4j+3)/(2M2^∞))`
by Theorem 2, with `M2^∞ = Σz_n^{-4} = 1/6`, i.e. `= √(3(4j+3))`. On the other hand, by
the ODD value law, `⟨1/x, p_j⟩_{ν^∞} = M2^{-1}Σ_n x_np_j(x_n)` `= ±√(2(4j+3)M2)/M2·
Σ_n(−1)^{n+1}j_{2j+1}(z_n)`. Equating: `|Σ(−1)^{n+1}j_{2j+1}(z_n)| = √(3(4j+3))·
√(M2)/√(2(4j+3)) = √(3M2/2) = ½`. ∎ (The sign `(−1)^j` follows from the value law's
`(−1)^i` factor; THEOREM-M1's Poisson-sign write-up already fixes it.)

## 5. Remarks

- Theorem 1 + 2 make the infinite-system part of the horizon profile EXACTLY the naive
  law `(4j+3)/(2N)`; ALL deviation is the two Fredholm factors — the content of Part II.
- The `(4j−1)!!` law is the ODD-string face of the Lambert/tan structure already used in
  THEOREM-M1 ("bordered odd-Lambert"); Theorem 2 is its closed determinant form.
- Everything here is finite-N exact; no asymptotics enter until Part II.

## 6. Verification manifest

- `m1_horizon_exact_layer.py` (+log): Theorem 1 as identity (8.3e-118, N=100 dps 120);
  α-recurrence ℚ-check of Theorem 2 (j ≤ 59 there, extended to 80/81 below).
- `m1_horizon_writeup_ingredients.py` (+log): closed forms `P̃_j(0)`, `h̃_j` exact in ℚ
  (j ≤ 81); induction identity exact in ℚ (j = 1..80).
- `m1_horizon_lemma_addendum.py` (+log) §(3): Bernoulli-rational moments → Hankel dets
  in ℚ == closed forms (j ≤ 10) — the contraction certified without citation.
- `m1_horizon_downdate_check.py` (+log): Theorem 3 downdates + Corollary 1 end-to-end
  (1e-10…1e-16); value-law normalization self-checks; Rayleigh node forms vs scipy 3e-13.

*— Stenberg + Claude, 2026-07-22.*
