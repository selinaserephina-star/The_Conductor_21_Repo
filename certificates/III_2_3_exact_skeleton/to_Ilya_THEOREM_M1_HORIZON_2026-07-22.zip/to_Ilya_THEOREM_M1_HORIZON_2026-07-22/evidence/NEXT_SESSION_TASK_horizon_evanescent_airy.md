# NEXT-SESSION TASK — M1-HORIZON: the evanescent-Airy profile of g_j → closed ξ_ε

> **STATUS 2026-07-22: DONE — CLOSED FORM DELIVERED.** See
> `FINDINGS_M1_HORIZON_evanescent_closedform.md`: G(ξ) = 2ξ·[det(I−K⁺_L)/det(I−K⁻_L)]²,
> L = 2ξ²/π (Dyson gap-probability ratio), ξ_ε = √((π/4)ln(π/2ε)); exact finite-N theorem
> via second-kind/Christoffel–Wronskian/Uvarov; all success criteria met (G table 4–5
> digits, ξ_ε 2.394/2.748/3.344/4.076, mass 0.999996). Route taken = route 1 (Theorem-D1
> shape) but the integral rep became an EXACT determinant identity; no Airy function was
> needed — the evanescent side is sine-kernel gap decay.

**Staged 2026-07-22 (Stenberg + Claude). Goal: pin the transfer-horizon constant in closed
form by deriving the beyond-turning-point (evanescent) uniform Airy asymptotics of the
ODD-Lanczos overlap g_j. This is the ONE remaining ingredient; everything else is done.
Not RH/GRH.**

## The object

The weight-transfer downdate (THEOREM-M1 part I): `s²_0 = 1`, `s²_{j+1} = s²_j − g²_j`,
with `g_j = ⟨e₀, w_j⟩`, `e₀ = 𝟙/√N`, and `w_j` the ODD-Lanczos basis of the measure with
atoms `x_n = z_n^{−2}`, weights `z_n^{−4}`, `z_n = (n−½)π`. Explicitly
`g_j = (1/√(N·M₂)) Σ_n z_n^{−2} p_j^{ODD}(z_n^{−2})`, `M₂ = Σ z_n^{−4}`. The transfer holds
while `s²_j` is not tiny; the horizon `J_ε(N) = ξ_ε√N` is where `s²_j ≤ ε`.

## What is ALREADY established (do NOT re-derive)

- **Scaling law:** under `j = ξ√N`, `g_j²·√N → G(ξ)` (N-stable, verified N=400…6400),
  `s²_{ξ√N} → s²_∞(ξ) = ∫_ξ^∞ G`, with **`∫_0^∞ G = 1` EXACT** (from `s²_0=1`, `s²→0`).
- **Horizon is a threshold-crossing, not a sharp cutoff** — and it is REAL (high-precision
  mpmath dps 220 confirms, NOT a float64 artifact): `ξ_ε` = 2.38(1e-3)/2.73(1e-4)/
  3.33(1e-6)/4.05(1e-9), N-stable. `m1_horizon_scaling.py`, `m1_horizon_hp_bridge.py`.
- **Bessel-sum profile in closed form** (this is NOT the horizon profile):
  `S(ξ) = ½ − (1/π)Si(2ξ²/π)`, the caustic limit of `S_j = Σ_{n≤N}(−1)^{n+1}j_{2j+1}(z_n)`.
  Derived via Poisson rep `j_{2i+1}=(−1)^i∫_0^1 sin(zt)P_{2i+1}dt` + the companion identity
  `Σ(−1)^{n+1}sin(z_n t) = (−1)^{N+1}sin(Nπt)/(2cos(πt/2))`, the `t=1` singularity, and
  Mehler–Heine `P_ν(1−u)≈J_0((2i+1)√(2u))`. `m1_horizon_closedform.py`. Confirmed + `∫8ξS²=1`.
- **The bridge `g_j = √(2(4j+3)/N)·S_j` is LOW-j ONLY** (HP-verified): `c = g/bridge` =
  1.04(ξ=1), 1.86(1.5), 0.63(2), 0.21(2.5), 0.043(3). So `8ξS²` is NOT `G(ξ)` in the tail —
  they share total mass 1 but `8ξS²` is heavy-tailed (would give ξ_ε≈21, wrong).

## THE TASK — the evanescent regime

The true `G(ξ) = g_j²√N` decays **super-exponentially** (HP-reliable data):

| ξ | 1.0 | 1.5 | 2.0 | 2.5 | 3.0 |
|---|---|---|---|---|---|
| G(ξ) | 0.743 | 0.253 | 0.0372 | 0.00260 | 8.97e−5 |
| ln G | −0.30 | −1.37 | −3.29 | −5.95 | −9.32 |

Empirically `−ln G ~ c·ξ^p` with `p ≈ 2.5–2.7`, `c = O(1)` (`d(lnG)/dξ ≈ −3.0ξ + 1.6`),
i.e. the **evanescent (beyond-turning-point) Airy regime** — exponential decay, the OTHER
side of the caustic from the algebraic `S(ξ)` tail. `⟨e₀, w_j⟩` selects this evanescent tail.

**Derive the closed form of `G(ξ)` in the evanescent regime, hence `s²_∞(ξ) = ∫_ξ^∞ G` and
each `ξ_ε` in closed form.** Success = a closed `G(ξ)` matching the table above and
reproducing `ξ_ε` = 2.38/2.73/3.33/4.05 (and `∫_0^∞ G = 1`).

## Attack routes (in order of promise)

1. **g_j is a first-column projector element — reuse Theorem D1 (P1a-companion).** The
   `P1a_companion_theorem_2026-07-18.md` (in the sent K1K2_P1 package) derived exactly this
   kind of object `ĉ^L_i(m) = ⟨1_{A_m}, p^L_i⟩` via an EXACT Legendre integral representation
   `∫_0^1 [sin(mπt)/cos(πt/2)] (P_{2i+1}−P_{2i−1})(t) dt`. `g_j = ⟨e₀, w_j⟩` is the same
   shape (fixed vector projected onto the ODD polynomial). Get g_j's exact integral rep; the
   bridge `√(2(4j+3)/N)S_j` is its LEADING (fixed-j) form — the evanescent decay is the
   large-j (i = ξ√N) asymptotics of that integral where the Airy turning point moves.
2. **Olver/Airy at the caustic — reuse the caustic theorem (G-D2b/F10) machinery.** That
   proof did Olver uniform asymptotics at the turning point `n/j = 2/π` for the κ_j law
   (`Φ_∞ = −4(AiBi)′`, `a_∞ = 2^{2/3}3^{−5/6}/Γ(2/3)²`). The horizon g_j needs the
   EVANESCENT side (Ai(+large) ~ exp(−(2/3)ζ^{3/2})). Get ζ(ξ) from the turning-point map;
   the `p≈2.5–3` power should be `ζ^{3/2}` with `ζ ~ (ξ² − ξ_c²)` or similar.
3. **The bridge correction directly.** `c(ξ) = g_j/[√(2(4j+3)/N)S_j]` is the j-dependent
   normalization the fixed-j string relation drops. Find `c(ξ)` (measured 1.04/1.86/0.63/…)
   in closed form; then `G = 8ξ S² c²`. NB `c` oscillates then decays — likely `c` carries
   the Airy factor while `S` carries the algebraic part.

## Files to build on (all in `T2_gap_closure_2026-07-22/`)
`m1_horizon_probe.py`, `m1_horizon_scaling.py`, `m1_horizon_caustic.py`,
`m1_horizon_closedform.py`, `m1_horizon_hp_bridge.py` (+ run logs), and
`FINDINGS_M1_HORIZON_scaling.md`. External input: `P1a_companion_theorem_2026-07-18.md`
(Theorem D1) and the caustic-theorem package (`to_Ilya_CAUSTIC_THEOREM_2026-07-19`).

## Grade target
`M1-HORIZON`: SCALING LAW + mechanism (done) → **closed-form ξ_ε** via the evanescent-Airy
`G(ξ)`. Lane: ours (caustic). Offerable to IB if the Airy calculation is where his method
is strongest — but do NOT pre-assign (see [[collaboration-credit-principle]]).
