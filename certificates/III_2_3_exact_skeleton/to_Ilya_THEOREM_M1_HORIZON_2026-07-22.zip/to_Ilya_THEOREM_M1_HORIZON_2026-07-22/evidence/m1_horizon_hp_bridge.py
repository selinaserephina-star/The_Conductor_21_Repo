# m1_horizon_hp_bridge.py — M1-HORIZON, 2026-07-22. Decisive high-precision test:
# is the g_j <-> S_j bridge exact (so G=8xi S^2 and horizon ~ 21 sqrt(N)), or does the
# true g_j genuinely deviate (so the bridge needs a correction)? AND is the float64
# ODD-Lanczos g_j reliable at large j (the ODD polys grow ~e^{cj})? Recompute BOTH g_j
# (mpmath ODD Lanczos, high dps) and S_j (mpmath spherical Bessel sum) at N=400 to j~3.5 sqrt N.
import mpmath as mp

mp.mp.dps = 220
N = 400
z = [ (mp.mpf(2*n-1)/2) * mp.pi for n in range(1, N+1) ]   # z_n = (n-1/2) pi
x = [ zz**-2 for zz in z ]                                  # atoms
wt = [ zz**-4 for zz in z ]                                 # ODD weights x^2
M2 = mp.fsum(wt)
e0 = [ mp.mpf(1)/mp.sqrt(N) for _ in range(N) ]

def sph_j(n, zz):   # spherical Bessel j_n(z) = sqrt(pi/2z) J_{n+1/2}(z)
    return mp.sqrt(mp.pi/(2*zz)) * mp.besselj(n + mp.mpf(1)/2, zz)

# ODD Lanczos (mpmath, full reorth) -> orthonormal vectors w_j (weighted), g_j=<e0,w_j>
J = int(3.6*mp.sqrt(N)) + 1
sw = [ mp.sqrt(wt[n]/M2) for n in range(N) ]                # sqrt normalized weight
v = sw[:]                                                    # w_0 = normalized weight vector
Vs = [v]; g = [ mp.fsum(e0[n]*v[n] for n in range(N)) ]
w = [ x[n]*v[n] for n in range(N) ]
a0 = mp.fsum(v[n]*w[n] for n in range(N)); w = [ w[n]-a0*v[n] for n in range(N) ]
for j in range(1, J):
    b = mp.sqrt(mp.fsum(t*t for t in w))
    vn = [ t/b for t in w ]
    for u in Vs:
        c = mp.fsum(u[n]*vn[n] for n in range(N)); vn = [ vn[n]-c*u[n] for n in range(N) ]
    nv = mp.sqrt(mp.fsum(t*t for t in vn)); vn = [ t/nv for t in vn ]
    Vs.append(vn); g.append(mp.fsum(e0[n]*vn[n] for n in range(N)))
    w = [ x[n]*vn[n] - b*Vs[-2][n] for n in range(N) ]
    aj = mp.fsum(vn[n]*w[n] for n in range(N)); w = [ w[n]-aj*vn[n] for n in range(N) ]

sq = mp.sqrt(N)
print(f"N={N}, dps={mp.mp.dps}, sqrt(N)={float(sq):.2f}")
print(" j   xi     g_j(HP)       bridge sqrt(2(4j+3)/N)S_j    c=g/bridge   |S_j|")
for j in [5, 10, 20, 30, 40, 50, 60]:
    if j >= len(g): continue
    S = mp.fsum(((-1)**(n+1)) * sph_j(2*j+1, z[n-1]) for n in range(1, N+1))
    bridge = mp.sqrt(2*(4*j+3)/mp.mpf(N)) * abs(S)
    print(f"{j:3d} {float(j/sq):.2f}  {float(abs(g[j])):.6e}   {float(bridge):.6e}          "
          f"{float(abs(g[j])/bridge):.4f}     {float(abs(S)):.4f}")

# horizon from HP g_j
s2 = mp.mpf(1); hor = None
for j in range(len(g)):
    s2 = s2 - g[j]**2
    if s2 <= mp.mpf('1e-6') and hor is None: hor = j
print(f"\nHP horizon (s^2<=1e-6): j*={hor} = {float(hor/sq):.2f} sqrt(N)   "
      f"[float64 gave 3.2-3.3; closed-form 8xi S^2 gives ~21]")
print("done.")
