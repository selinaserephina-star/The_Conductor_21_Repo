# m1_horizon_probe.py — M1-HORIZON, 2026-07-22. Locate exactly where the true g_i departs
# from the fixed-j closed form g_i^2 ~ (4i+3)/2N, and thereby why the s^2-floor horizon sits
# at 3.2 sqrt(N) not sqrt(N). g_i = <e0, w_i>, w_i = ODD Lanczos basis; s^2_{j+1}=s^2_j-g_j^2,
# s^2_0=1; horizon = argmin_j s^2_j <= 0. Not RH/GRH.
import numpy as np

def lanczos_basis(x, wts, m):
    v = np.sqrt(wts / np.sum(wts)); Vs = [v]; w = x * v; a0 = v @ w; w = w - a0 * v
    for j in range(1, m):
        b = np.linalg.norm(w)
        if b < 1e-14: break
        vn = w / b
        for u in Vs: vn = vn - (u @ vn) * u
        vn /= np.linalg.norm(vn); Vs.append(vn); w = x * vn - b * Vs[-2]
        aj = vn @ w; w = w - aj * vn
    return np.column_stack(Vs)

for N in [200, 400, 800, 1600]:
    z = (np.arange(1, N + 1) - 0.5) * np.pi
    x = 1.0 / z ** 2
    J = int(5 * np.sqrt(N))
    V2 = lanczos_basis(x, x ** 2, J + 2)          # ODD (x^2-weighted) Lanczos
    g = V2.T @ (np.ones(N) / np.sqrt(N))          # g_i = <e0, w_i>
    g2 = g ** 2
    naive = np.array([(4 * i + 3) / (2 * N) for i in range(len(g))])
    s2 = np.concatenate([[1.0], 1.0 - np.cumsum(g2)])
    hor = int(np.searchsorted(-s2, 1e-9))         # first j with s^2 <= ~0
    sq = np.sqrt(N)
    print(f"\nN={N} (sqrt N={sq:.1f}): horizon j*={hor} = {hor/sq:.2f} sqrt(N);  "
          f"naive Sum g2 to sqrt(N) = {np.sum(naive[:int(sq)]):.3f}")
    print("   i/sqrtN :  g_i^2(true)   (4i+3)/2N     ratio true/naive")
    for frac in [0.25, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0]:
        i = int(frac * sq)
        if i < len(g2):
            print(f"   {frac:4.2f}    : {g2[i]:.4e}   {naive[i]:.4e}    {g2[i]/naive[i]:.3f}")
print("\ndone.")
