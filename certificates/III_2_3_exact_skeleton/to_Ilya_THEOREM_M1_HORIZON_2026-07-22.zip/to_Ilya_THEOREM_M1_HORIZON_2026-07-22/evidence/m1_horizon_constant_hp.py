# m1_horizon_constant_hp.py — M1-HORIZON, 2026-07-22. Pin the asymptotic constant of the
# evanescent profile: claim  2[lndet(I-K^+_L) - lndet(I-K^-_L)] + 2L  ->  ln 2  (L->inf),
# i.e. G(xi) ~ 4 xi exp(-4 xi^2/pi). The Tracy-Widom/Ehrhardt hard-edge constants at
# nu = -+1/2 give exactly (1/2)ln2 per determinant (Barnes-G ratio G(1/2)/G(3/2)=1/sqrt(pi)
# and the (2pi)^{nu/2} factor). float64 Nystrom dies past L~14 (det ~ e^{-L^2/4} below
# eigenvalue resolution); here mpmath dps 90, Gauss-Legendre M=120 (kernel entries built
# in mpf). Fit a + b/L over L=12/16/20. Not RH/GRH.
import numpy as np
import mpmath as mp
from numpy.polynomial.legendre import leggauss

mp.mp.dps = 120
M = 120
xg, _ = leggauss(M)

def legP(n, x):          # (P_n(x), P_n'(x)) by recurrence, mpf
    p0, p1 = mp.mpf(1), x
    for k in range(2, n + 1):
        p0, p1 = p1, ((2 * k - 1) * x * p1 - (k - 1) * p0) / k
    dp = n * (x * p1 - p0) / (x * x - 1)
    return p1, dp

xs, ws = [], []
for xv in xg:            # Newton-refine float64 nodes to mpf precision
    x = mp.mpf(xv)
    for _ in range(6):
        p, dp = legP(M, x)
        x = x - p / dp
    p, dp = legP(M, x)
    xs.append(x)
    ws.append(2 / ((1 - x * x) * dp * dp))
t = [mp.mpf(0.5) * (x + 1) for x in xs]
sw = [mp.sqrt(mp.mpf(0.5) * w) for w in ws]

def val(Lf):
    L = mp.mpf(Lf)
    Ap = mp.zeros(M); Am = mp.zeros(M)
    for i in range(M):
        for j in range(i, M):
            tv = t[i] - t[j]; tu = t[i] + t[j]
            Sd = L if i == j else mp.sin(L * tv) / tv
            Ss = mp.sin(L * tu) / tu
            f = sw[i] * sw[j] / mp.pi
            kp = f * (Sd + Ss); km = f * (Sd - Ss)
            Ap[i, j] = Ap[j, i] = kp
            Am[i, j] = Am[j, i] = km
    Ip = mp.eye(M) - Ap; Im = mp.eye(M) - Am
    lp = mp.log(mp.det(Ip)); lm = mp.log(mp.det(Im))
    return lp, lm, 2 * (lp - lm) + 2 * L

rows = {}
for Lf in (12, 16, 20):
    lp, lm, v = val(Lf)
    rows[Lf] = v
    print(f"L={Lf}: lndetE={mp.nstr(lp,8)}  lndetO={mp.nstr(lm,8)}  const-probe={mp.nstr(v,8)}")
# fit a + b/L + c/L^2 through the three points
import itertools
Ls = list(rows)
A = mp.matrix([[1, mp.mpf(1)/L, mp.mpf(1)/L**2] for L in Ls])
y = mp.matrix([rows[L] for L in Ls])
coef = mp.lu_solve(A, y)
print(f"\nfit a+b/L+c/L^2: a = {mp.nstr(coef[0],8)}   (ln2 = {mp.nstr(mp.log(2),8)})")
print(f"                 b = {mp.nstr(coef[1],6)}, c = {mp.nstr(coef[2],6)}")
print(f"a - ln2 = {mp.nstr(coef[0]-mp.log(2),4)}")
print("done.")
