# m1_horizon_lemma_addendum.py — M1-HORIZON theorem-grade write-up, 2026-07-22. Three
# addenda for the scaling-lemma / INF write-ups:
# (1) CORRECTED effective band edges (midpoint quadrature): l_eff = 2j-1 (EVEN),
#     l_eff = 2j (ODD); s_eff = l_eff(l_eff+1)/(4N). Prediction D_disc =
#     lndet(K_{L_eff}) - lndet(K_L) should now match BOTH parities, residual O(1/N).
# (2) Spectral gaps 1 - lambda_max(K^pm_L) at the working L's (det-continuity constant).
# (3) INF fully self-contained in Q: the mu_L moments are RATIONAL
#     (m_k = 2(2^{2k+2}-1) zeta(2k+2)/pi^{2k+2}, Bernoulli), so the Hankel determinants
#     D~_j = prod h~_i and D_j^(1) = D~_j |P~_j(0)| are checked EXACTLY in Q against the
#     double-factorial closed forms — certifying the alpha-contraction without citation.
# Not RH/GRH.
import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.special import polygamma
from fractions import Fraction
import mpmath as mp

XI = 1.5
MTAIL = 1_000_000
x_, w_ = leggauss(300)
t_ = 0.5 * (x_ + 1); wt_ = 0.5 * w_
def sine_mats(L):
    tu = t_[:, None] + t_[None, :]; tv = t_[:, None] - t_[None, :]
    Sd = np.where(np.abs(tv) < 1e-14, L, np.sin(L * tv) / np.where(np.abs(tv) < 1e-14, 1.0, tv))
    Ss = np.sin(L * tu) / tu
    A = np.sqrt(wt_)[:, None] * np.sqrt(wt_)[None, :] / np.pi
    return A * (Sd + Ss), A * (Sd - Ss)
def sine_dets(L):
    Kp, Km = sine_mats(L)
    return (np.linalg.slogdet(np.eye(300) - Kp)[1], np.linalg.slogdet(np.eye(300) - Km)[1])

def P_node(l, z):
    t = np.ones_like(z); s = t.copy(); k = 0
    while 2 * (k + 1) <= l:
        t = t * (-((l + 2*k + 1) * (l + 2*k + 2) * (l - 2*k) * (l - 2*k - 1)) / ((2*k + 1) * (2*k + 2))) / (4 * z * z)
        s = s + t; k += 1
    return s
def Q_node(l, z):
    t = np.full_like(z, l * (l + 1.0)); s = t.copy(); k = 0
    while 2 * (k + 1) + 1 <= l:
        t = t * (-((l + 2*k + 2) * (l + 2*k + 3) * (l - 2*k - 1) * (l - 2*k - 2)) / ((2*k + 2) * (2*k + 3))) / (4 * z * z)
        s = s + t; k += 1
    return s / (2 * z)

L0 = 2 * XI * XI / np.pi
lpK, lmK = sine_dets(L0)
print(f"=== (1) corrected band edges: l_eff = 2j-1 (even) / 2j (odd), xi={XI} ===")
print("   N     parity  D_disc(meas)  edge pred   ratio    resid       N*resid")
for N in (200, 800, 3200):
    j = int(round(XI * np.sqrt(N)))
    n_tail = np.arange(N + 1, MTAIL + 1, dtype=np.float64)
    z_tail = (n_tail - 0.5) * np.pi
    psi = polygamma(1, MTAIL + 0.5) / np.pi ** 2
    for parity, name, lK in ((0, 'even', lpK), (1, 'odd', lmK)):
        Vc = []
        for i in range(j):
            l = 2 * i + parity
            cn = np.sqrt(2 * (4 * i + 1)) if parity == 0 else np.sqrt(2 * (4 * i + 3))
            y = l * (l + 1.0) / (2 * z_tail)
            Vc.append(cn * (np.cos(y) if parity == 0 else np.sin(y)) / z_tail)
        Vc = np.array(Vc); Wc = Vc @ Vc.T
        if parity == 0:
            ce = np.array([np.sqrt(2 * (4 * i + 1)) for i in range(j)])
            Wc += np.outer(ce, ce) * psi
        ldC = np.linalg.slogdet(np.eye(j) - Wc)[1]
        d_disc = ldC - lK
        l_eff = 2 * j - 1 if parity == 0 else 2 * j
        Leff = 2 * (l_eff * (l_eff + 1) / (4.0 * N)) / np.pi
        lpE, lmE = sine_dets(Leff)
        pred = (lpE if parity == 0 else lmE) - lK
        resid = d_disc - pred
        print(f"  {N:5d}  {name:5s}  {d_disc:+.5f}     {pred:+.5f}    {d_disc/pred:+.3f}   {resid:+.2e}   {N*resid:+.3f}")

print("\n=== (2) spectral gaps 1 - lambda_max(K^pm_L) (det-continuity constants) ===")
for xi in (1.0, 1.5, 2.0, 2.5, 3.0, 3.35):
    L = 2 * xi * xi / np.pi
    Kp, Km = sine_mats(L)
    lp = np.linalg.eigvalsh(Kp)[-1]; lm = np.linalg.eigvalsh(Km)[-1]
    print(f"   xi={xi:4.2f} L={L:6.3f}: 1-lam_max(even)={1-lp:.3e}   1-lam_max(odd)={1-lm:.3e}")

print("\n=== (3) INF self-contained: Hankel dets from Bernoulli-rational moments, exact in Q ===")
JH = 10
mom = {}
for k in range(0, 2 * JH + 2):
    p, q = mp.bernfrac(2 * k + 2)
    B = Fraction(int(p), int(q))
    import math
    zr = (-1) ** k * B * Fraction(2) ** (2 * k + 1) / Fraction(math.factorial(2 * k + 2))  # zeta(2k+2)/pi^(2k+2)
    zr = Fraction(zr.numerator, zr.denominator)
    mom[k] = 2 * (Fraction(2) ** (2 * k + 2) - 1) * zr
print(f"   m_0={mom[0]}, m_1={mom[1]}  (want 1, 1/3)")
def detQ(M):
    M = [row[:] for row in M]; n = len(M); d = Fraction(1)
    for c in range(n):
        piv = next((r for r in range(c, n) if M[r][c] != 0), None)
        if piv is None: return Fraction(0)
        if piv != c: M[c], M[piv] = M[piv], M[c]; d = -d
        d *= M[c][c]
        for r in range(c + 1, n):
            f = M[r][c] / M[c][c]
            for cc in range(c, n): M[r][cc] -= f * M[c][cc]
    return d
def dfact(n):
    r = 1
    while n > 1: r *= n; n -= 2
    return r
okD = okS = True
for jj in range(1, JH + 1):
    D = detQ([[mom[a + b] for b in range(jj)] for a in range(jj)])
    D1 = detQ([[mom[a + b + 1] for b in range(jj)] for a in range(jj)])
    Dc = Fraction(1)
    for i in range(jj): Dc *= Fraction(1, dfact(4 * i - 1) * dfact(4 * i + 1))
    if D != Dc: okD = False
    if D1 != D * Fraction(1, dfact(4 * jj - 1)): okS = False
print(f"   D~_j == prod_(i<j) 1/[(4i-1)!!(4i+1)!!]  for j=1..{JH}: {okD}")
print(f"   D_j^(1) == D~_j / (4j-1)!!  (i.e. |P~_j(0)| = 1/(4j-1)!!) for j=1..{JH}: {okS}")
print("done.")
