# WRITE-UP — THEOREM M1-HORIZON, Part II: the scaling lemma (chirp → sine kernels)

**Merkabit · Stenberg + Claude · 2026-07-22. The uniform-in-j scaling limit turning
Part I's exact finite-N formula into the closed form `G(ξ) = 2ξ·[det(I−K⁺_L)/det(I−K⁻_L)]²`,
`L = 2ξ²/π`. Structure: every mechanism PROVEN with explicit bounds; the two lemma
constants are certified numerically with stable N-scaling (grades itemized in §5).
Companion: `WRITEUP_M1_HORIZON_exact_layer_theorem.md`. Not RH/GRH.**

## 0. Statement

Let `Γ_E(j)`, `Γ_O(j)` be Part I's tail Grams (atoms n > N), `K^±_L` the even/odd sine
kernels on (0,1) — `K^±(u,v) = [sin(L(u−v))/(u−v) ± sin(L(u+v))/(u+v)]/π` — and
`G_N(ξ) = √N·g²_{ξ√N}` (j = ξ√N ∈ ℕ).

**LEMMA (scaling limit with rate).** For every ξ_max there is C(ξ_max) < ∞ with
  `| ln G_N(ξ) − ln G(ξ) | ≤ C(ξ_max)/√N`, `G(ξ) = 2ξ·[det(I−K⁺_L)/det(I−K⁻_L)]²`,
uniformly in ξ ≤ ξ_max, decomposed as (chirp) + (discretization) + (edge), §§2–4, each
with proven shape; C grows like the inverse spectral gap `(1−λ_max(K⁺_L))^{-1} ~ e^{2L}`
(gap table §4), so the statement is uniform on compacts — exactly the regime of the
horizon constants ξ_ε ≤ 4.1.

## 1. Exact damped-chirp representation (PROVEN)

At the nodes, `cos z_n = 0` makes the Rayleigh forms exact:
`j_{2i}(z_n) = ±P(2i,z_n)/z_n`, `j_{2i+1}(z_n) = ±Q(2i+1,z_n)/z_n`. Writing `c = l(l+1)`
and `y = c/(2z)`:

**Proposition 1.** `Q(l,z) = Σ_k (−1)^k R_k y^{2k+1}/(2k+1)!` and
`P(l,z) = Σ_k (−1)^k R'_k y^{2k}/(2k)!` with
  `R_k = ∏_{d=0}^{2k} (1 − d(d+1)/c)`, `R'_k = ∏_{d=1}^{2k} (1 − d(d−1)/c)` ∈ (0,1].
*Proof.* The Rayleigh coefficient `(l+2k+1)!/(l−2k−1)!` is a product of 4k+2 consecutive
integers; pairing s with 2l+1−s gives factors `(l−d)(l+1+d) = c − d(d+1)`, d = 0..2k;
dividing by `c^{2k+1}` yields `R_k`. Even case identically with `(l+d)(l+1−d) = c−d(d−1)`. ∎
(ℚ-verified against the factorial ratios on a (l,k) grid.)

**Proposition 2 (entrywise chirp bounds).** With `B⁻(y) = y²sinh y + (y³/3)cosh y` and
`B⁺(y) = y²cosh y + (y³/3)sinh y`:
  `|Q(l,z) − sin y| ≤ B⁻(y)/c`, `|P(l,z) − cos y| ≤ B⁺(y)/c`.
*Proof.* `1−R_k ≤ Σ_d d(d+1)/c = (2k)(2k+1)(2k+2)/(3c)` (and similarly `1−R'_k ≤
(2k−1)(2k)(2k+1)/(3c)`); then `Σ_k [(2k+1)³−(2k+1)] y^{2k+1}/(2k+1)! = (v³−v)sinh y =
3y²sinh y + y³cosh y` with `v = y d/dy` (resp. `(v³−v)cosh y = 3y²cosh y + y³sinh y`);
divide by 3c. ∎ (Verified: bounds hold with ~10× headroom over y ∈ {0.5, 2, 5},
l ∈ {41, 81, 161}, and the deviations scale as 1/c exactly.)

## 2. Component 1 — chirp substitution: O(1/N) (proven shape, certified constant)

Replace the exact node values in `Γ` by the pure chirps (`Γ^chirp`). Both Grams are sums
of rank-one terms `v_iv_iᵀ`; `‖Γ−Γ^chirp‖_tr ≤ Σ_{i<j} ‖v_i−v_i^c‖(‖v_i‖+‖v_i^c‖)`, and
by Proposition 2 `‖v_i−v_i^c‖² ≤ Σ_{n>N} 2(4i+3)B(y_{in})²/(c_i²z_n²)` with `y_{in} ≤
y_{i,N+1} ≍ L`: every factor explicit. Since `c_i ≍ 4i²` and the n-sums converge, the
total is O(1/N) at fixed ξ. **Certified:** `D_chirp = lndet(I−Γ) − lndet(I−Γ^chirp)`
has ratios 0.24–0.27 per 4×N (= 1/N rate) with N·D_chirp = −0.110/−0.113/−0.121 (even),
−0.046/−0.044/−0.047 (odd) at ξ = 1.5, N = 200/800/3200.

## 3. Component 2 — discretization = a band-edge shift: O(1/√N) (identified exactly)

`Γ^chirp` is the midpoint-type discretization of `K^±_L`: the i-sum has effective
s-lattice `s̃_i = l(l+1)/(4N)`, `l = 2i+parity`, and the n-lattice `ρ_n = (n−½)/N` is the
exact midpoint lattice of `(1,∞)` (the map `z_n = πρ_nN` is exact — no error from this
variable). The leading error is the BAND EDGE: midpoint quadrature integrates the s-band
up to the half-cell beyond the top chirp, i.e. effective edge
  `s_eff = l_eff(l_eff+1)/(4N)`, **`l_eff = 2j−1` (even parity), `l_eff = 2j` (odd)**,
so `L_eff = 2s_eff/π = L − O(ξ/√N)`. **Certified:** the prediction
`D_disc ≈ lndet(I−K^±_{L_eff}) − lndet(I−K^±_L)` matches at ratios 0.986/0.995/0.983
(even) and 0.814/1.019/0.996 (odd) across N = 200/800/3200 at ξ=1.5, with residuals
O(1/N), N·resid = −0.21/−0.22/−0.24 (even), +0.061/+0.061/+0.061 (odd) — the remaining
Euler–Maclaurin terms are one order down, as they should be. Thus the 1/√N rate seen in
the global convergence (Part I finite-N check: ratios 0.49–0.51) is fully accounted for
by `|s_eff − ξ²| ≤ (2ξ+1)/(2√N)`-scale edge displacement times `|d lndet/dL|`.

## 4. Component 3 — determinant continuity and the spectral gap

For PSD trace-class contractions A, B:
`|lndet(I−A) − lndet(I−B)| ≤ ‖A−B‖_tr · max((1−λ_max(A))^{-1}, (1−λ_max(B))^{-1})`.
The gaps (Nyström, GL-300; the classical prolate gap `1−λ_max ~ e^{−cL}`):

| ξ | L | 1−λ_max(K⁺) | 1−λ_max(K⁻) |
|---|---|---|---|
| 1.0 | 0.637 | 6.12e-1 | 9.83e-1 |
| 1.5 | 1.432 | 2.59e-1 | 8.37e-1 |
| 2.0 | 2.546 | 5.14e-2 | 4.39e-1 |
| 2.5 | 3.979 | 4.28e-3 | 9.04e-2 |
| 3.0 | 5.730 | 1.64e-4 | 6.19e-3 |
| 3.35 | 7.144 | 1.10e-5 | 5.50e-4 |

The even gap decays ≈ e^{−1.9L}, so C(ξ_max) inflates like e^{2L} = e^{4ξ_max²/π}; at the
deepest horizon constant in use (ξ = 4.08, ε = 1e-9) this is ~e^{21} against errors
~1/√N — finite-N experiments at N ≥ 3200 (Part I: convergence certified through ξ = 2,
and the composition reproduces HP data through ξ = 3 at N = 400) sit safely inside.
(Float-trap note: computing these dets needs the GL NODES at working precision —
float64 nodes corrupt them past L ≈ 14; `m1_horizon_constant_hp.py`.)

## 5. THE ASSEMBLED CONSTANT (`m1_horizon_C_assembly.py` + log)

With `j = ξ√N`, `L = 2ξ²/π`, `L̂ = (2j+2)(2j+3)/(2πN)` (largest effective edge),
`Ŷ = (2j+1)(2j+2)/((2N+1)π)` (largest chirp argument), the **displayed constant**:

  **`|ln G_N(ξ) − ln G(ξ)| ≤ A(ξ)/√N + B(ξ)/N`  for `N ≥ N₀(ξ)`, hence `C(ξ) = A(ξ)+B(ξ)`:**

  `A(ξ) = (6ξ/π)·[δ₊(L̂) + δ₋(L̂)] + 3/(4ξ)`,
  `B(ξ) = (2/π)[δ₊ + (3/2)δ₋] + N·{ 2T_E(j+1)·(2/gap₊(L̂)) + [T_O(j)+T_O(j+1)]·(2/gap₋(L̂)) } + B_EM(ξ)`,

where **δ_±(L') = (2/π)⟨c_{L'}, (I−K^±_{L'})^{-1}c_{L'}⟩** is the EXACT band derivative —
`dK^±_L/dL` is RANK ONE (`= (2/π)·cos(Lu)cos(Lv)` resp. `sin·sin`) so `|d lndet/dL| = δ_±`,
a certified O(L) quantity (`δ_± → L/2 ± ½`; measured 4.089 vs 4.072 at L = 7.14) — NOT a
resolvent-gap estimate; the edge displacements are exact (`Δs = 3ξ/(2√N)+1/(2N)` for
`Γ_E(j+1)`, `ξ/(2√N)` and `5ξ/(2√N)+3/(2N)` for `Γ_O(j)`, `Γ_O(j+1)`); and the proven
chirp trace-norm bounds (§§1–2) are

  `T_E(k) = 6φ₊(Ŷ)k²(k+1)²/(√5π⁴(N−½)³) + (2/3)φ₊(Ŷ)²(k+1)⁶/(5π⁶(N−½)⁵)`,
  `T_O(k) = 8φ₋(Ŷ)(k+1)⁶/(√7π⁵(N−½)⁴) + (4/21)φ₋(Ŷ)²(k+1)⁸/(π⁸(N−½)⁷)`,
  `φ₊(y) = cosh y + (y/3)sinh y`, `φ₋(y) = sinh(y)/y + (cosh y)/3`,

(hold vs measured `D_chirp` with 3–20× headroom at ξ = 1, 2 × N = 200..3200). `B_EM` is
the ONE certified-numeric component (Euler–Maclaurin residual beyond the edge shift):
measured `N·resid` stable over N = 200/800/3200 — ξ=1: |−0.03|+|0.02|, ξ=1.5:
0.21+0.06, ξ=2: 1.25+0.03 — taken with ×5 margin. Validity `N ≥ N₀(ξ)`: T-norms
≤ half-gaps (then every resolvent along the interpolation ≤ 2/gap).

| ξ | A(ξ) | B(ξ) (N=6400 T-terms) | C(ξ) | N₀(ξ) | measured √N·\|Δln G\| (N=400/1600/6400) |
|---|---|---|---|---|---|
| 1.0 | 2.67 | 1.27 | 3.9 | 1 | 0.88 / 0.86 / 0.85 |
| 1.5 | 5.22 | 11.4 | 16.6 | 4 | 2.23 / 2.20 / 2.19 |
| 2.0 | 10.6 | 500 | 510 | 203 | 3.47 / 3.42 / 3.39 |
| 2.5 | 19.8 | 7.5e4 | 7.5e4 | 3.1e4 | — (B_EM extrapolated ∝ξ²) |
| 3.0 | 33.7 | 3.0e7 | 3.0e7 | 1.2e7 | — |
| 3.35 | 46.6 | 3.4e9 | 3.4e9 | 1.3e9 | — |

Verification (§ (5) of the log): `√N·|ln G_N − ln G| ≤ A + B/√N` holds at every
measured (ξ, N) — and the A-part alone is tight to a factor 2.4–3.1 at ξ ≤ 2. Honest
accounting of the conservatism: at ξ ≥ 2.5 the constant is dominated by the chirp
resolvent factor `2/gap₊ ~ e^{1.9L}` — the MEASURED chirp effect stays ~1e-4 (the
inflation is in the resolvent step, not in reality), and the A-part (which carries the
1/√N rate) stays O(ξ²) throughout. Uniformity on compacts is as stated in §0.

**Net grade: the scaling lemma now carries one displayed symbolic constant, every
component proven except B_EM (certified-numeric, stable, ×5 margin).** Combined with
Part I (exact layer, fully proven), THEOREM M1-HORIZON stands:

  `G(ξ) = 2ξ·[det(I−K⁺_{2ξ²/π})/det(I−K⁻_{2ξ²/π})]²`, `ξ_ε = √((π/4)ln(π/2ε))·(1+o(1))`,

with the finite-N approach controlled at rate 1/√N — the uniform-in-`j ∼ √N` statement
the audit asked for, now with closed-form constants.

## 6. Verification manifest

- `m1_horizon_writeup_ingredients.py` (+log): Prop. 1 exact in ℚ; Prop. 2 bounds sweep.
- `m1_horizon_scaling_lemma_components.py` (+log): D_chirp/D_disc split, rates, first
  edge fits (even).
- `m1_horizon_lemma_addendum.py` (+log): corrected parity edges (§3 table), gap table
  (§4), Bernoulli–Hankel ℚ certification (used in Part I §2).
- `m1_horizon_C_assembly.py` (+log): δ_± certification (rank-one derivative), EM
  residuals + D_chirp at ξ = 1, 2, T-bound validation, the C(ξ) table, and the final
  `√N|Δ| ≤ A + B/√N` verification at all measured (ξ, N).
- Global rate: `m1_horizon_finiteN_convergence.py` (Part I) — closed−G(N) halves per
  4×N at ξ = 1, 1.5, 2.

*— Stenberg + Claude, 2026-07-22.*
