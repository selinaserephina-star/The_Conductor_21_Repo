# FINDINGS — M1-HORIZON: the "3.2√N horizon" is a scaling law, not a sharp cutoff

**Merkabit · Stenberg + Claude · 2026-07-22.** A real advance on the audit's item
("horizon 3.2√N is measured, not proven — needs estimates uniform in j∼√N"). The eyeball
"J(N)=3.2√N SHARP" is replaced by a precise **scaling law** with exact normalization, the
mechanism identified as the caustic non-uniformity of the g-lemma, and the remaining work
posed as a well-defined caustic-profile calculation. Scripts `m1_horizon_probe.py`,
`m1_horizon_scaling.py`, `m1_horizon_caustic.py` (+ run logs). Not RH/GRH.

## Setup (exact)

The weight-transfer downdate (THEOREM-M1 part I) is `s²_0 = 1`, `s²_{j+1} = s²_j − g²_j`,
with `g_j = ⟨e₀, w_j⟩` the ODD-Lanczos overlaps. So `s²_j = 1 − Σ_{i<j}g²_i`, and since
`s²_j → 0`, **`Σ_{i≥0} g²_i = 1` exactly**. The transfer degrades where `s²_j` gets small
(the downdate divides by `s_{j+1}`). The g-lemma (PROVEN, fixed j) gives
`g_j = √(2(4j+3)/N)·S_j`, `S_j = Σ_{n≤N}(−1)^{n+1}j_{2j+1}(z_n) → (−1)^j/2`, hence the naive
`g²_j ≈ (4j+3)/2N`. Naively `Σ_{i<j}g²_i ≈ j²/N` hits 1 at `j=√N` — but the measured
horizon is `3.2√N`. This note explains and quantifies the gap.

## The scaling law (numerically solid; normalization EXACT)

Under `j = ξ√N`:

- **`g²_{ξ√N}·√N → G(ξ)`**, a fixed profile (collapse verified N=400/1600/6400; e.g. ξ=0.75:
  0.9007→0.9046→0.9061; peaks ≈0.91 at ξ≈0.75, decays). Equivalently
  **`G(ξ) = 8ξ·S(ξ)²`** with `S(ξ) = lim_N S_{ξ√N}(N)` the caustic-limit of the alternating
  spherical-Bessel sum (bridge `g_i=√(2(4i+3)/N)|S_i|` verified to 5 digits).
- **`s²_{ξ√N} → s²_∞(ξ) = ∫_ξ^∞ G(η)dη`**, with **`∫_0^∞ G = 1` EXACT** (algebraic, from
  `s²_0=1`, `s²→0` — measured 1.00000 at every N). `s²_∞(ξ)` is N-stable to 3 digits
  (ξ=1: 0.293/0.316/0.328; ξ=2: 6.4/7.5/8.2×10⁻³; ξ=3: 0.95/1.24/1.41×10⁻⁵).

## The horizon is a THRESHOLD crossing, not a cutoff

`J_ε(N) = ξ_ε·√N` where `s²_∞(ξ_ε) = ε`. The map ε ↦ ξ_ε is precise and N-stable
(N=1600 vs 6400):

| threshold ε | ξ_ε (=J/√N) |
|---|---|
| 1e-3 | 2.38 / 2.39 |
| 1e-4 | 2.73 / 2.74 |
| 1e-6 | 3.33 / 3.34 |
| 1e-9 | 4.05 / 4.06 |

The sealed "3.2√N" is `ξ_ε` at ε≈1e-6. **There is no single sharp constant** — `s²_∞(ξ)`
is a smooth decaying tail; the "horizon" depends on the working threshold. This is exactly
the audit's point, now made precise.

## Mechanism: the caustic non-uniformity of the g-lemma

`S(ξ) < ½` for ξ≳0 (0.486, 0.448, 0.384, 0.298, 0.196, 0.089 at ξ=0.25…1.5; converged).
The g-lemma `S_i(N)→(−1)^i/2` holds for **fixed i**, but the double limit along `i=ξ√N`
gives the smaller `S(ξ)` — the convergence is not uniform in i. The turning point
`n* = (2i+1)/π ~ (2ξ/π)√N` has `n*/N → 0` (verified 0.033→0.016→0.008 at ξ=1), so the
deficit is a genuine **large-order (caustic) effect**, not a truncation artifact. The far
oscillatory tail vanishes at the nodes (`sin((n−i−1)π)=0`); the value comes from the
turning-point/Airy region — the same caustic structure the caustic theorem (G-D2b/F10) and
the P1a-companion Theorem D1 (Legendre-integral rep of exactly this kind of sum) handle.

## Grade and what remains

`M1-HORIZON`: **MEASURED "3.2√N SHARP" → SCALING LAW** — `s²_{ξ√N} → ∫_ξ^∞ 8ηS(η)²dη`,
total mass 1 (exact), threshold→constant map precise and N-stable, mechanism = caustic
non-uniformity. This is the uniform-in-j statement the audit asked for, at
numerically-solid + exact-normalization grade.

Remaining (well-posed, our caustic lane): the **closed form of `S(ξ)`** via the
Legendre-integral / Airy machinery (Theorem D1 gives the integral representation of the
alternating Bessel sum; the caustic theorem gives the Airy turning-point asymptotics) —
which would deliver `G(ξ)`, `s²_∞(ξ)`, and each `ξ_ε` in closed form. Offerable; it is a
genuine caustic calculation, not an eyeball.

## UPDATE 2026-07-22 — the caustic profile S(ξ) IN CLOSED FORM (`m1_horizon_closedform.py`)

Derivation (Theorem-D1 machinery): Poisson rep `j_{2i+1}(z)=(−1)^i∫_0^1 sin(zt)P_{2i+1}(t)dt`
+ the companion identity `Σ_{n≤N}(−1)^{n+1}sin(z_n t)=(−1)^{N+1}sin(Nπt)/(2cos(πt/2))`; the
`1/cos(πt/2)` singularity at `t=1` dominates, and Mehler–Heine `P_ν(1−u)≈J_0((2i+1)√(2u))`
with `i=ξ√N` collapses the sum to `S(ξ)=(1/π)∫_0^∞[sin(πv)/v]J_0(2ξ√(2v))dv`. The series
`Σ(−1)^m y^{2m+1}/((2m+1)(2m+1)!)=Si(y)` gives the closed form

  **S(ξ) = ½ − (1/π)·Si(2ξ²/π)**,  Si = sine integral.

CONFIRMED: matches the directly-summed profile across ξ (0.4873/0.4494/0.3868/0.3019/
0.2003/0.0929 vs measured 0.4864/0.4475/0.3840/0.2983/0.1963/0.0890); `S(0)=½` (Dirichlet);
`S(ξ)→0` as ξ→∞; and **∫_0^∞ 8ξS² dξ = 0.9998 ≈ 1** (the exact normalization). This is a
genuine closed-form caustic result — the uniform-in-j deviation of the g-lemma sum.

**Honest boundary (why this does NOT yet pin ξ_ε):** the horizon uses g²_j, and the bridge
`g_j=√(2(4j+3)/N)S_j` is only a LOW-j approximation — at ξ=2 the true |g_j| is ~0.6× the
bridge value (checked: |g|=0.043 vs 0.068 at i=40=2√400). So `8ξS(ξ)²` and the true `G(ξ)`
share the total mass (both →1) but the closed form has a heavier tail; `s²_∞(ξ)` from
`8ξS²` (0.128 at ξ=2) is far above the measured (8e-3), and solving `∫_ξ^∞8ηS²=ε` gives
ξ_ε≈21, not the measured 2.4–4. **So: S(ξ) is closed; the horizon constant additionally
needs the true g_j asymptotics past the low-j bridge** (the remaining, now sharply-posed,
caustic ingredient). Grade: caustic profile S(ξ) CLOSED; horizon ξ_ε still SCALING-LAW
(measured), reduced to the g_j-vs-S_j correction.

## UPDATE 2026-07-22 — high-precision settles it (`m1_horizon_hp_bridge.py`, mpmath dps 220)

Recomputed BOTH g_j (mpmath ODD-Lanczos) and S_j (mpmath spherical Bessel) — no float64 /
scipy artifacts. Two facts nailed:

1. **The 3.3√N horizon is REAL, not numerical.** HP g_j gives horizon j*=66=3.30√N,
   identical to float64. So the float64 ODD-Lanczos was NOT corrupted, and the closed-form
   `8ξS²` route (ξ_ε≈21) is the one that does not describe the horizon.
2. **The bridge g_j=√(2(4j+3)/N)S_j genuinely fails past ξ≈1** (HP, so real): c=g/bridge =
   1.04 (ξ=1), 1.86 (1.5), 0.63 (2), 0.21 (2.5), 0.043 (3). The true g_j decays FAR faster
   than S_j.

**Mechanism identified:** the true profile G(ξ)=g_j²√N (HP-reliable) decays like
**G(ξ) ~ exp(−≈1.45 ξ²)** (d(lnG)/dξ ≈ −2.9(ξ−ξ₀), linear ⇒ Gaussian). So the horizon g_j
sits in the **evanescent, beyond-the-caustic (Airy) regime** — exponential decay — whereas
the Bessel sum S(ξ) has a slow 1/ξ² algebraic tail. The projection ⟨e₀, w_j⟩ selects the
evanescent tail, and THAT sets the horizon. `S(ξ)` (the Bessel-sum profile) and the horizon
`g_j` profile are governed by DIFFERENT sides of the caustic.

**Net grade:** horizon 3.3√N REAL (HP-confirmed); S(ξ) Bessel-sum profile CLOSED; horizon
ξ_ε reduced to the g_j **evanescent Airy** profile G(ξ)~exp(−cξ²) — a fresh Airy calculation
(beyond-turning-point uniform asymptotics of the ODD-polynomial projection), now precisely
posed. The scaling law + exact normalization + this mechanism are the established advance.
