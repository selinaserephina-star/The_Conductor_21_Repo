# m1_horizon_scaling_lemma_components.py — M1-HORIZON theorem-grade write-up, 2026-07-22.
# Decompose the scaling-limit error  lndet(I-Gamma(j)) - lndet(I-K^pm_L)  into the two
# lemma components and certify each one's rate:
#   D_chirp = lndet(I-Gamma) - lndet(I-Gamma^chirp)
#             [replace exact Rayleigh node values by pure chirps sin/cos(y), y=l(l+1)/2z;
#              PROVEN entrywise <= Benv(y)/c, c=l(l+1) — expect O(1/N) total]
#   D_disc  = lndet(I-Gamma^chirp) - lndet(I-K^pm_L)
#             [i-sum -> s-integral + n-lattice -> rho-integral; Euler-Maclaurin;
#              expect O(1/sqrtN), dominated by the BAND-EDGE shift: the top chirp order
#              l = 2j-1 has l(l+1)/(4N) = xi^2 - xi/(2 sqrtN) + O(1/N), i.e.
#              L_eff = L - xi/( sqrtN) * (1/1) * (2/pi)*(xi/2)... measured against the
#              band-edge prediction lndet(K_{L_eff}) - lndet(K_L) below]
# at xi = 1.5, N = 200 / 800 / 3200, both parities. Not RH/GRH.
import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.special import polygamma

XI = 1.5
MTAIL = 1_000_000

def P_node(l, z):
    t = np.ones_like(z); s = t.copy(); k = 0
    while 2 * (k + 1) <= l:
        t = t * (-((l + 2*k + 1) * (l + 2*k + 2) * (l - 2*k) * (l - 2*k - 1)) / ((2*k + 1) * (2*k + 2))) / (4 * z * z)
        s = s + t; k += 1
    return s

def Q_node(l, z):
    t = np.full_like(z, l * (l + 1.0)); s = t.copy(); k = 0
    while 2 * (k + 1) + 1 <= l:
        t = t * (-((l + 2*k + 2) * (l + 2*k + 3) * (l - 2*k - 1) * (l - 2*k - 2)) / ((2*k + 2) * (2*k + 3))) / (4 * z * z)
        s = s + t; k += 1
    return s / (2 * z)

x_, w_ = leggauss(300)
t_ = 0.5 * (x_ + 1); wt_ = 0.5 * w_
def sine_dets(L):
    tu = t_[:, None] + t_[None, :]; tv = t_[:, None] - t_[None, :]
    Sd = np.where(np.abs(tv) < 1e-14, L, np.sin(L * tv) / np.where(np.abs(tv) < 1e-14, 1.0, tv))
    Ss = np.sin(L * tu) / tu
    A = np.sqrt(wt_)[:, None] * np.sqrt(wt_)[None, :] / np.pi
    lp = np.linalg.slogdet(np.eye(300) - A * (Sd + Ss))[1]
    lm = np.linalg.slogdet(np.eye(300) - A * (Sd - Ss))[1]
    return lp, lm

L0 = 2 * XI * XI / np.pi
lpK, lmK = sine_dets(L0)
print(f"xi={XI}, L=2xi^2/pi={L0:.6f}: continuum lndet even={lpK:.6f}, odd={lmK:.6f}")
print("\n   N     parity  lndetGamma   D_chirp      D_disc       sqrtN*D_disc   N*D_chirp")
res = {}
for N in (200, 800, 3200):
    j = int(round(XI * np.sqrt(N)))
    n_tail = np.arange(N + 1, MTAIL + 1, dtype=np.float64)
    z_tail = (n_tail - 0.5) * np.pi
    psi = polygamma(1, MTAIL + 0.5) / np.pi ** 2
    for parity, name, lK in ((0, 'even', lpK), (1, 'odd', lmK)):
        V, Vc = [], []
        for i in range(j):
            l = 2 * i + parity
            cnorm = np.sqrt(2 * (4 * i + 1)) if parity == 0 else np.sqrt(2 * (4 * i + 3))
            y = l * (l + 1.0) / (2 * z_tail)
            if parity == 0:
                V.append(cnorm * P_node(l, z_tail) / z_tail)
                Vc.append(cnorm * np.cos(y) / z_tail)
            else:
                V.append(cnorm * Q_node(l, z_tail) / z_tail)
                Vc.append(cnorm * np.sin(y) / z_tail)
        V = np.array(V); Vc = np.array(Vc)
        W = V @ V.T; Wc = Vc @ Vc.T
        if parity == 0:
            ce = np.array([np.sqrt(2 * (4 * i + 1)) for i in range(j)])
            W += np.outer(ce, ce) * psi; Wc += np.outer(ce, ce) * psi
        ldG = np.linalg.slogdet(np.eye(j) - W)[1]
        ldC = np.linalg.slogdet(np.eye(j) - Wc)[1]
        d_chirp = ldG - ldC
        d_disc = ldC - lK
        res[(N, parity)] = (d_chirp, d_disc)
        print(f"  {N:5d}  {name:5s}   {ldG:+.6f}   {d_chirp:+.2e}   {d_disc:+.2e}   {np.sqrt(N)*d_disc:+.4f}        {N*d_chirp:+.4f}")

print("\n=== rate check (ratios per 4x N; 0.50 = 1/sqrtN, 0.25 = 1/N) ===")
for parity, name in ((0, 'even'), (1, 'odd')):
    dc = [res[(N, parity)][0] for N in (200, 800, 3200)]
    dd = [res[(N, parity)][1] for N in (200, 800, 3200)]
    print(f"   {name}: D_chirp ratios {dc[1]/dc[0]:+.3f}, {dc[2]/dc[1]:+.3f}   D_disc ratios {dd[1]/dd[0]:+.3f}, {dd[2]/dd[1]:+.3f}")

print("\n=== band-edge prediction for D_disc: L_eff(N) with s-edge = (2j-1)2j/(4N) ===")
for N in (200, 800, 3200):
    j = int(round(XI * np.sqrt(N)))
    s_edge = (2 * j - 1) * (2 * j) / (4.0 * N)
    Leff = 2 * s_edge / np.pi
    lpE, lmE = sine_dets(Leff)
    for parity, name, lK, lE in ((0, 'even', lpK, lpE), (1, 'odd', lmK, lmE)):
        pred = lE - lK
        meas = res[(N, parity)][1]
        print(f"   N={N:5d} {name:5s}: D_disc={meas:+.5f}   edge-shift pred={pred:+.5f}   ratio={meas/pred:+.3f}")
print("done.")
