# m1_horizon_scaling.py — M1-HORIZON, 2026-07-22. The scaling limit of the s^2-floor.
# Claim: g_i^2 = 2(4i+3)/N * S_i(N)^2 with S_i(N)=sum_{n<=N}(-1)^{n+1} j_{2i+1}(z_n); under
# i = xi*sqrt(N), g_i^2 * sqrt(N) -> G(xi) = 8 xi S(xi)^2, a fixed profile, and
#   s^2(xi) = 1 - int_0^xi G = int_xi^infty G,   with int_0^infty G = 1 (total mass).
# So the "3.2 sqrt(N) horizon" is the THRESHOLD crossing of the scaling tail s^2(xi), NOT a
# sharp cutoff. This script demonstrates the scaling collapse + total mass 1 + the s^2(xi)
# profile + threshold-vs-constant table. Not RH/GRH.
import numpy as np

def g_profile(N, xi_max=6.0):
    z = (np.arange(1, N + 1) - 0.5) * np.pi
    x = 1.0 / z ** 2
    J = int(xi_max * np.sqrt(N)) + 2
    v = np.sqrt(x ** 2 / np.sum(x ** 2)); Vs = [v]; w = x * v; a0 = v @ w; w = w - a0 * v
    for j in range(1, J):
        b = np.linalg.norm(w)
        if b < 1e-14: break
        vn = w / b
        for u in Vs: vn = vn - (u @ vn) * u
        vn /= np.linalg.norm(vn); Vs.append(vn); w = x * vn - b * Vs[-2]
        aj = vn @ w; w = w - aj * vn
    V2 = np.column_stack(Vs)
    g = V2.T @ (np.ones(N) / np.sqrt(N))
    return g ** 2

print("=== scaling collapse: G(xi)=g^2_{xi sqrt N} * sqrt(N) converges ===")
XI = [0.25, 0.5, 0.75, 1.0, 1.5, 2.0, 2.5, 3.0]
prof = {}
for N in [400, 1600, 6400]:
    g2 = g_profile(N); sq = np.sqrt(N); prof[N] = (g2, sq)
    vals = []
    for xi in XI:
        i = int(round(xi * sq)); vals.append(g2[i] * sq if i < len(g2) else np.nan)
    print(f"  N={N:5d}: " + "  ".join(f"{xi}:{v:.4f}" for xi, v in zip(XI, vals)))

print("\n=== total mass int_0^inf G  (= sum_i g_i^2, must -> 1) and s^2(xi) profile ===")
for N in [400, 1600, 6400]:
    g2, sq = prof[N]
    mass = np.sum(g2)
    s2 = 1.0 - np.cumsum(g2)
    # s^2 at fixed xi
    row = []
    for xi in [1.0, 2.0, 3.0, 3.2, 4.0, 5.0]:
        j = int(round(xi * sq)); row.append(s2[j] if j < len(s2) else 0.0)
    print(f"  N={N:5d}: total mass={mass:.5f};  s^2 at xi=" +
          " ".join(f"{xi}:{v:.2e}" for xi, v in zip([1.0,2.0,3.0,3.2,4.0,5.0], row)))

print("\n=== horizon constant vs threshold (why 3.2 is not fundamental) ===")
for N in [1600, 6400]:
    g2, sq = prof[N]; s2 = 1.0 - np.cumsum(g2)
    for thr in [1e-3, 1e-4, 1e-6, 1e-9]:
        j = int(np.searchsorted(-s2, -(-thr)))   # first j with s2<=thr
        j = int(np.argmax(s2 <= thr))
        print(f"  N={N}: s^2<={thr:.0e} at j={j} = {j/sq:.2f} sqrt(N)")
    print()
print("done.")
