# m1_horizon_fredholm_profile.py — M1-HORIZON, 2026-07-22 (evanescent-Airy session).
# DECISIVE TEST of the candidate closed form of the horizon profile:
#
#   G(xi) = 2 xi * [ det(I - K^+_L) / det(I - K^-_L) ]^2 ,   L = 2 xi^2 / pi,
#
# where K^-/K^+ are the ODD/EVEN sine kernels on (0,1) with band-limit L:
#   K^-(u,v) = (1/pi)[ sin(L(u-v))/(u-v) - sin(L(u+v))/(u+v) ]   (sin*sin, odd)
#   K^+(u,v) = (1/pi)[ sin(L(u-v))/(u-v) + sin(L(u+v))/(u+v) ]   (cos*cos, even)
# (Dyson gap-probability objects; Bessel hard-edge kernels nu = +-1/2.)
#
# Derivation chain (this session): g_j = second-kind function at 0 of the finite-N ODD
# system; Christoffel-Wronskian: g_j^2 = h~_j/(2N |P~_j(0) P~_{j+1}(0)|) (EVEN-system
# monic data, EXACT); truncation at N = exact Uvarov downdate D_j^(N) = D_j^inf *
# det(I - CD-Gram on tail atoms); on the node lattice j_l(z_n) is an exact chirp
# (Rayleigh: cos z_n = 0), giving sin((2i+1)(2i+2)/2z_n) resp cos(...) profiles whose
# scaled tail Gram -> the odd/even sine kernels with L = 2 xi^2/pi. The infinite-system
# algebraic part is the naive law 2*xi (equivalent to the PROVEN gem identity).
# Predictions tested against the HP-reliable measured tables (m1_horizon_hp_bridge /
# m1_horizon_scaling). Not RH/GRH.
import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.special import sici
from scipy.optimize import brentq

def dets_pm(L, M=240):
    """Fredholm dets det(I-K^+), det(I-K^-) on (0,1), band L, Gauss-Legendre Nystrom."""
    x, w = leggauss(M)
    t = 0.5 * (x + 1.0); wt = 0.5 * w
    tu = t[:, None] + t[None, :]
    tv = t[:, None] - t[None, :]
    Sd = np.where(np.abs(tv) < 1e-14, L, np.sin(L * tv) / np.where(np.abs(tv) < 1e-14, 1.0, tv))
    Ss = np.sin(L * tu) / tu
    sw = np.sqrt(wt)
    A = sw[:, None] * sw[None, :] / np.pi
    Kp = A * (Sd + Ss)
    Km = A * (Sd - Ss)
    sp = np.linalg.slogdet(np.eye(M) - Kp)
    sm = np.linalg.slogdet(np.eye(M) - Km)
    return sp[1], sm[1]          # log dets (signs must be +1)

def logG(xi, M=240):
    if xi <= 0: return -np.inf
    L = 2.0 * xi * xi / np.pi
    lp, lm = dets_pm(L, M)
    return np.log(2.0 * xi) + 2.0 * (lp - lm)

print("=== convergence check (M=160 vs 320) at xi=3.5 ===")
print(f"   logG M=160: {logG(3.5,160):.10f}   M=320: {logG(3.5,320):.10f}")

print("\n=== G(xi): Fredholm closed form vs HP-measured ===")
meas = {1.0: 0.743, 1.5: 0.253, 2.0: 0.0372, 2.5: 0.00260, 3.0: 8.97e-5}
print("   xi    G_closed      G_measured(HP)   ratio")
for xi, m in meas.items():
    g = np.exp(logG(xi))
    print(f"   {xi:4}  {g:.4e}    {m:.3e}       {g/m:.4f}")

print("\n=== low-xi sanity (should track 8 xi S(xi)^2, S=1/2-Si(2xi^2/pi)/pi) ===")
for xi in (0.25, 0.5, 0.75):
    g = np.exp(logG(xi))
    si, _ = sici(2 * xi ** 2 / np.pi)
    print(f"   xi={xi}: G_closed={g:.4f}   8xiS^2={8*xi*(0.5-si/np.pi)**2:.4f}")

print("\n=== total mass int_0^inf G (must be 1) and s^2_inf(xi) ===")
xs = np.linspace(1e-4, 6.0, 1201)
Gs = np.array([np.exp(logG(x)) for x in xs])
mass = np.trapezoid(Gs, xs)
print(f"   mass to xi=6: {mass:.6f}")
meas_s2 = {1.0: 3.28e-1, 2.0: 8.17e-3, 3.0: 1.41e-5, 3.2: 2.90e-6}
cum = np.concatenate([[0], np.cumsum(0.5 * (Gs[1:] + Gs[:-1]) * np.diff(xs))])
def s2inf(xi):
    return mass - np.interp(xi, xs, cum)
for xi, m in meas_s2.items():
    print(f"   xi={xi}: s2_closed={s2inf(xi):.3e}   measured={m:.2e}")

print("\n=== horizon constants xi_eps vs measured ===")
meas_xi = {1e-3: 2.38, 1e-4: 2.73, 1e-6: 3.33, 1e-9: 4.05}
for eps, m in meas_xi.items():
    xe = brentq(lambda x: s2inf(x) - eps, 0.3, 5.9, xtol=1e-10)
    print(f"   eps={eps:.0e}: xi_eps(closed)={xe:.3f}   measured={m:.2f}")

print("\n=== asymptotic constant: ln[G/(2xi)] + 2L -> 2(c_E - c_O)? ===")
for xi in (2.0, 2.5, 3.0, 3.5, 4.0, 4.5):
    L = 2 * xi * xi / np.pi
    lp, lm = dets_pm(L, 320)
    val = 2 * (lp - lm) + 2 * L
    print(f"   xi={xi}: L={L:6.3f}   ln[G/(2xi)]+2L = {val:.5f}")
print(f"   candidates: ln2={np.log(2):.5f}, (1/2)ln2={0.5*np.log(2):.5f}, ln(pi/2)={np.log(np.pi/2):.5f}")

print("\n=== bridge correction c(xi) = sqrt(G/(8 xi S^2)) vs HP-measured c ===")
meas_c = {1.0: 1.04, 1.5: 1.86, 2.0: 0.63, 2.5: 0.21, 3.0: 0.043}
for xi, m in meas_c.items():
    si, _ = sici(2 * xi ** 2 / np.pi)
    S = 0.5 - si / np.pi
    c = np.sqrt(np.exp(logG(xi)) / (8 * xi * S * S))
    print(f"   xi={xi}: c_closed={c:.3f}   c_measured(HP)={m}")
print("   (S(xi) has a zero at xi~1.74 -> c hump then collapse; the measured 1.86@1.5 is that)")
print("\ndone.")
