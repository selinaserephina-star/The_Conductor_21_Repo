# m1_horizon_caustic.py — M1-HORIZON, 2026-07-22. Bridge g_i to the alternating Bessel sum
# and characterize the caustic-limit profile S(xi) = lim S_{xi sqrt N}(N),
# S_i(N)=sum_{n=1}^N (-1)^{n+1} j_{2i+1}(z_n), z_n=(n-1/2)pi. Then G(xi)=8 xi S(xi)^2.
# Also test the leading caustic scale: the turning point n*=(2i+1)/pi ~ (2 xi/pi) sqrt(N),
# i.e. n*/N -> 0, so the deficit S<1/2 is a genuine large-order (not truncation) effect.
# Not RH/GRH.
import numpy as np
from scipy.special import spherical_jn

def S_i(i, N):
    n = np.arange(1, N + 1); z = (n - 0.5) * np.pi
    return np.sum((-1.0) ** (n + 1) * spherical_jn(2 * i + 1, z))

def g_from_lanczos(N, imax):
    z = (np.arange(1, N + 1) - 0.5) * np.pi; x = 1.0 / z ** 2
    v = np.sqrt(x ** 2 / np.sum(x ** 2)); Vs = [v]; w = x * v; a0 = v @ w; w = w - a0 * v
    for j in range(1, imax + 2):
        b = np.linalg.norm(w)
        if b < 1e-14: break
        vn = w / b
        for u in Vs: vn = vn - (u @ vn) * u
        vn /= np.linalg.norm(vn); Vs.append(vn); w = x * vn - b * Vs[-2]
        aj = vn @ w; w = w - aj * vn
    return np.column_stack(Vs).T @ (np.ones(N) / np.sqrt(N))

print("=== bridge: g_i =? sqrt(2(4i+3)/N) * S_i(N)  (sign folded) ===")
N = 400; g = g_from_lanczos(N, 60)
for i in [2, 5, 10, 20, 40]:
    S = S_i(i, N); pred = np.sqrt(2 * (4 * i + 3) / N) * abs(S)
    print(f"  i={i:3d}: |g_i|={abs(g[i]):.5e}  sqrt(2(4i+3)/N)|S_i|={pred:.5e}  S_i={S:+.4f}  (naive S=+/-0.5)")

print("\n=== caustic-limit profile S(xi) = lim_N S_{xi sqrt N}(N) ===")
XI = [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0]
for N in [400, 1600, 6400]:
    sq = np.sqrt(N)
    row = [abs(S_i(int(round(xi * sq)), N)) for xi in XI]
    print(f"  N={N:5d}: " + "  ".join(f"{xi}:{v:.4f}" for xi, v in zip(XI, row)))
print("  (S(0+) -> 1/2 = naive; decays through the caustic. G(xi)=8 xi S(xi)^2.)")

print("\n=== turning point n*/N -> 0 (deficit is a large-order effect, not truncation) ===")
for N in [400, 1600, 6400]:
    sq = np.sqrt(N)
    for xi in [1.0, 2.0]:
        i = int(round(xi * sq)); nstar = (2 * i + 1) / np.pi
        print(f"  N={N}, xi={xi}: i={i}, turning n*={nstar:.1f}, n*/N={nstar/N:.3f}, "
              f"tail terms n>N are past-node (sin~0)")
print("done.")
