# m1_horizon_downdate_check.py — M1-HORIZON, 2026-07-22 (evanescent session). Certify the
# MECHANISM layer (E3): truncation of the measure at N acts on the Hankel determinants as
# an EXACT Uvarov downdate by the CD-kernel Gram on the removed tail atoms:
#
#   D_j(mu - tail) = D_j(mu) * det(I - Gram_j),   Gram_j = [sqrt(w_n w_m) K_j(x_n,x_m)]_{n,m>N}
#
# evaluated by the low-rank identity det(I - V^T V) = det(I_j - V V^T), with
# V_{i,n} = sqrt(w_n) p_i^inf(x_n) EXACT at the node lattice via the Rayleigh forms
# (cos z_n = 0):  j_{2i}(z_n)  = (-1)^{n+1+i} P(2i, z_n)/z_n,
#                 j_{2i+1}(z_n)= (-1)^{n+j+1} Q(2i+1, z_n)/z_n   (finite exact sums), and
#   sqrt(w~_n) p~_i(x_n)   = sqrt(2(4i+1)) * (+-) j_{2i}(z_n)     [EVEN system, w~=2x_n]
#   sqrt(w'_n) p'_i(x_n)   = sqrt(2(4i+3)) * (+-) j_{2i+1}(z_n)   [ODD system,  w'=2x_n^2]
# (normalization self-check: sum_n 2(4i+1) j_{2i}(z_n)^2 = 1 = sum_n 2(4i+3) j_{2i+1}^2).
#
# CHECKS at N=200 (mpmath dps 60 Lanczos for the finite side, exact-Q alpha-products for
# the infinite side):
#  (a) EVEN downdate:  ln h~_j^(N) - ln h~_j^inf        =  F_E(j+1) - F_E(j)
#  (b) ODD/EVEN mix:   ln|P~_j(0)|^(N) - ln|P~_j(0)|^inf =  F_O(j) - F_E(j)
#  (c) END-TO-END:     ln g_j^2 = ln((4j+3)/(2N)) + 2F_E(j+1) - F_O(j) - F_O(j+1)
#  (d) scaling limit:  F_O(j), F_E(j)  vs  ln det(I - K^-/+_L) on (0,1), L = 2 xi^2/pi
# where F_E/O(j) = ln det(I - Gram_j) for the respective parity. Not RH/GRH.
import numpy as np
import mpmath as mp
from fractions import Fraction
from numpy.polynomial.legendre import leggauss
from scipy.special import polygamma, spherical_jn

N = 200
JMAX = 30          # xi up to 2.12
MTAIL = 1_000_000  # explicit tail atoms N+1..MTAIL, then analytic psi' remainder

# ---------- exact Rayleigh node values (vectorized, ratio recursion; no overflow) ----------
def P_node(l, z):   # P(l,z) = sum_k (-1)^k (l+2k)!/((2k)!(l-2k)!(2z)^{2k}), l even
    t = np.ones_like(z); s = t.copy(); k = 0
    while 2 * (k + 1) <= l:
        fac = -( (l + 2*k + 1) * (l + 2*k + 2) * (l - 2*k) * (l - 2*k - 1) ) / ((2*k + 1) * (2*k + 2))
        t = t * fac / (4 * z * z); s = s + t; k += 1
    return s

def Q_node(l, z):   # Q(l,z) = sum_k (-1)^k (l+2k+1)!/((2k+1)!(l-2k-1)!(2z)^{2k+1}), l odd
    t = np.full_like(z, l * (l + 1.0)); s = t.copy(); k = 0
    while 2 * (k + 1) + 1 <= l:
        fac = -( (l + 2*k + 2) * (l + 2*k + 3) * (l - 2*k - 1) * (l - 2*k - 2) ) / ((2*k + 2) * (2*k + 3))
        t = t * fac / (4 * z * z); s = s + t; k += 1
    return s / (2 * z)

n_tail = np.arange(N + 1, MTAIL + 1, dtype=np.float64)
z_tail = (n_tail - 0.5) * np.pi
print("=== sanity: Rayleigh node values vs scipy spherical_jn (n=N+1..N+3, orders 40,61) ===")
for l in (40, 61):
    zs = z_tail[:3]
    ray = (P_node(l, zs) / zs) if l % 2 == 0 else (Q_node(l, zs) / zs)
    scp = np.array([abs(spherical_jn(l, zz)) for zz in zs])
    print(f"   l={l}: max rel diff = {np.max(np.abs(np.abs(ray)-scp)/scp):.2e}")

# ---------- Fredholm factors F_E(j), F_O(j) via low-rank Gram ----------
def build_V(parity):   # parity 0: even orders 2i; 1: odd orders 2i+1 ; rows i=0..JMAX
    rows = []
    for i in range(JMAX + 1):
        l = 2 * i + parity
        if parity == 0:
            vals = np.sqrt(2 * (4 * i + 1)) * P_node(l, z_tail) / z_tail
        else:
            vals = np.sqrt(2 * (4 * i + 3)) * Q_node(l, z_tail) / z_tail
        rows.append(vals)
    return np.array(rows)

VE = build_V(0); VO = build_V(1)
# analytic far tail (n > MTAIL): even values -> sqrt(2(4i+1))/z_n (P->1); odd negligible
psi_tail = polygamma(1, MTAIL + 0.5) / np.pi ** 2   # sum_{n>MTAIL} z_n^-2
WE = VE @ VE.T
ce = np.sqrt(2 * (4 * np.arange(JMAX + 1) + 1))
WE += np.outer(ce, ce) * psi_tail
WO = VO @ VO.T   # far tail ~ 1e-14, negligible
def F_of(W, j):
    sgn, ld = np.linalg.slogdet(np.eye(j) - W[:j, :j])
    return ld if sgn > 0 else np.nan
FE = {j: F_of(WE, j) for j in range(1, JMAX + 2)}
FO = {j: F_of(WO, j) for j in range(1, JMAX + 2)}

# ---------- finite-N side: mpmath Lanczos both parities ----------
mp.mp.dps = 60
zm = [(mp.mpf(2 * n - 1) / 2) * mp.pi for n in range(1, N + 1)]
xm = [zz ** -2 for zz in zm]
def lanczos(wts, J):
    mass = mp.fsum(wts)
    v = [mp.sqrt(w / mass) for w in wts]
    Vs = [v]; alphas = []; betas = []
    wv = [xm[n] * v[n] for n in range(N)]
    a0 = mp.fsum(v[n] * wv[n] for n in range(N)); alphas.append(a0)
    wv = [wv[n] - a0 * v[n] for n in range(N)]
    for j in range(1, J + 1):
        bj = mp.sqrt(mp.fsum(t * t for t in wv)); betas.append(bj)
        vn = [t / bj for t in wv]
        for u in Vs:
            c = mp.fsum(u[n] * vn[n] for n in range(N)); vn = [vn[n] - c * u[n] for n in range(N)]
        nv = mp.sqrt(mp.fsum(t * t for t in vn)); vn = [t / nv for t in vn]
        Vs.append(vn)
        wv = [xm[n] * vn[n] - bj * Vs[-2][n] for n in range(N)]
        aj = mp.fsum(vn[n] * wv[n] for n in range(N)); alphas.append(aj)
        wv = [wv[n] - aj * vn[n] for n in range(N)]
    return alphas, betas, Vs, mass

alE, beE, _, massE = lanczos([2 * xx for xx in xm], JMAX + 2)
Pm = {0: mp.mpf(1), 1: -alE[0]}; hm = {0: massE}
for k in range(1, JMAX + 2):
    Pm[k + 1] = -alE[k] * Pm[k] - (beE[k - 1] ** 2) * Pm[k - 1]
    hm[k] = hm[k - 1] * beE[k - 1] ** 2
_, _, VsO, _ = lanczos([xx ** 2 for xx in xm], JMAX + 1)
e0 = mp.mpf(1) / mp.sqrt(N)
g = [mp.fsum(e0 * V[n] for n in range(N)) for V in VsO]

# ---------- infinite side: exact alpha-products ----------
JQ = JMAX + 2
al = {m: Fraction(1, (2 * m - 1) * (2 * m + 1)) for m in range(1, 2 * JQ + 4)}
bq = {0: al[1]}; a2q = {}
for k in range(1, JQ + 2):
    bq[k] = al[2 * k] + al[2 * k + 1]; a2q[k] = al[2 * k - 1] * al[2 * k]
Pq = {0: Fraction(1), 1: -bq[0]}
for k in range(1, JQ + 1):
    Pq[k + 1] = -bq[k] * Pq[k] - a2q[k] * Pq[k - 1]
def lnF(fr):
    return mp.log(mp.mpf(abs(fr.numerator))) - mp.log(mp.mpf(fr.denominator))
lnh_inf = {0: mp.mpf(0)}
for k in range(1, JQ + 1):
    lnh_inf[k] = lnh_inf[k - 1] + lnF(a2q[k])
lnP_inf = {k: lnF(Pq[k]) for k in range(JQ + 2)}

# ---------- the checks ----------
print("\n=== (a) EVEN downdate: ln h~^(N)/h~^inf vs F_E(j+1)-F_E(j) ===")
print("   j   xi     lhs           rhs           diff")
for j in (2, 5, 10, 15, 20, 25, 30):
    lhs = float(mp.log(hm[j]) - lnh_inf[j])
    rhs = FE[j + 1] - FE[j]
    print(f"  {j:3d} {j/np.sqrt(N):5.2f}  {lhs:+.6e}  {rhs:+.6e}  {abs(lhs-rhs):.1e}")

print("\n=== (b) ln|P~_j(0)|^(N)/inf vs F_O(j)-F_E(j) ===")
for j in (2, 5, 10, 15, 20, 25, 30):
    lhs = float(mp.log(abs(Pm[j])) - lnP_inf[j])
    rhs = FO[j] - FE[j]
    print(f"  {j:3d} {j/np.sqrt(N):5.2f}  {lhs:+.6e}  {rhs:+.6e}  {abs(lhs-rhs):.1e}")

print("\n=== (c) END-TO-END: ln g_j^2 vs ln((4j+3)/2N) + 2F_E(j+1) - F_O(j) - F_O(j+1) ===")
for j in (2, 5, 10, 15, 20, 25, 29):
    lhs = float(2 * mp.log(abs(g[j])))
    rhs = np.log((4 * j + 3) / (2 * N)) + 2 * FE[j + 1] - FO[j] - FO[j + 1]
    print(f"  {j:3d} {j/np.sqrt(N):5.2f}  {lhs:+.8f}  {rhs:+.8f}  {abs(lhs-rhs):.1e}")

print("\n=== (d) scaling limit: F_O/F_E(j) vs ln det(I-K^-/+_L)|_(0,1), L=2xi^2/pi ===")
x_, w_ = leggauss(240)
t_ = 0.5 * (x_ + 1); wt_ = 0.5 * w_
def sine_dets(L):
    tu = t_[:, None] + t_[None, :]; tv = t_[:, None] - t_[None, :]
    Sd = np.where(np.abs(tv) < 1e-14, L, np.sin(L * tv) / np.where(np.abs(tv) < 1e-14, 1.0, tv))
    Ss = np.sin(L * tu) / tu
    A = np.sqrt(wt_)[:, None] * np.sqrt(wt_)[None, :] / np.pi
    return (np.linalg.slogdet(np.eye(240) - A * (Sd + Ss))[1],
            np.linalg.slogdet(np.eye(240) - A * (Sd - Ss))[1])
for j in (5, 10, 15, 20, 25, 30):
    xi = j / np.sqrt(N); L = 2 * xi * xi / np.pi
    lp, lm = sine_dets(L)
    print(f"  j={j:3d} xi={xi:5.2f}  F_O={FO[j]:+.5f} vs sine-odd {lm:+.5f} (d={FO[j]-lm:+.4f})"
          f"   F_E={FE[j]:+.5f} vs sine-even {lp:+.5f} (d={FE[j]-lp:+.4f})")
print("done.")
