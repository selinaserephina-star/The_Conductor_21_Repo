# STEP 2 — the composition check run against the record: VERDICT NEGATIVE-AS-STATED, remaining object named, partial closure identified

**Stenberg + Claude (Fable). 2026-08-15, same session as step 1. This is the
"one check owed" of FINDINGS §3b, executed against the certificates of record.
One lock. Not RH/GRH.**

## 1. The question

Does the Part II completeness machinery, as certified, exclude a real
(exceptional/Siegel) zero β₀ ∈ (0,1) of L(s,χ₈) — i.e., an off-line pair
(β₀, 1−β₀) at height t = 0?

## 2. The convention, read from the certificates of record — NO

- **IB's Turing gate theorem**
  (`CHI8_TURING_gate_received_2026-07-18/TURING_COMPLETENESS_THEOREM_AND_GATE.md`,
  lines 13–17) defines the certified count with **strict** inequality:
  N⁺(6.55) = #{ρ : **0 < Im ρ ≤ 6.55**, 0 ≤ Re ρ ≤ 1} = 24. The real axis is
  **outside the certified scope as stated**; "no additional or off-line zeros
  below 6.55" (line 31) is scoped to 0 < Im ρ.
- **Palojärvi–Zhao** (arXiv:2508.03023, the Turing-constant source) define
  N(t₁,t₂) as zeros with Im ρ ∈ (t₁, t₂] — intervals bounded away from the
  real axis; their Thm 2.2 hypothesis list includes L(1) ≠ 0 but no real-zero
  clause (checked against the arXiv HTML, this session).
- `turing_count.py`'s one-sided contradiction argument runs on (T*, t₂] with
  `n_below` **assumed** from the low-height anchor; the anchor (§II.2,
  N(3) = 8.000 by argument principle) is [C]/tracking grade, and full-ball
  completeness of the first 24 is itself the standing open M-102.

**Conclusion: FINDINGS §3b's route (i) closes NEGATIVE. The composition
cannot be closed by reading the record; the certified counting convention
does not cover t = 0.**

## 3. Three routes to closure, graded, in order of cheapness

**(a) The half-weight identity (derivation, classical, one page).** The
classical counting identity behind N(T) = Φ(T) + S(T) counts real zeros at
half weight: for the full rectangle |Im| ≤ T, total = 2N⁺(T) + N_real, and the
boundary integral gives 2(M+S), so M(T) + S(T) = N⁺(T) + N_real/2. Under it,
§II.2's measured **N(3) = 8.000 exactly** with 8 found on-line zeros is
*already tracking-grade evidence against any real pair* (a pair would read
9.000; the measured slack is 0.000 at three decimals). Promoting this to
certificate grade = state and prove the identity for this Λ (entire, ε = +1,
Λ real and nonvanishing at the contour's real-axis crossings) + rerun the
M(3)+S(3) computation at ball grade. **New derivation work — small, but not a
read of the record.**

**(b) The Q(0) partial exclusion (certifiable now, with a named gap).** With
Ξ(t) = Λ(½+it) and zeros z of Ξ, Q(t) = Ξ(t)²·Σ_z 1/(t−z)². A real zero pair
β₀ = ½ ± y (y ∈ (0,½)) appears as z = ±iy and contributes **−2/y²** at t = 0,
against the real zeros' +2Σ_{γ>0} 1/γ². The certified **Q(0) > 0** (Theorem
II.4) therefore *contradicts* any pair with y ≤ 1/√Σ_upper, where Σ_upper is a
certified upper bound on Σ 1/γ² (certified 153 brackets + a tail bound above
27.92 from Φ + the S-integral control). Rough size: first-8 partial sum 2.99,
full sum ≈ 4.5–5 ⟹ exclusion of roughly **β₀ ∈ [0.05, 0.95]**. **The gap is
structural: y → ½ (β₀ → 1) is exactly the classical exceptional regime, and
Q(0) > 0 cannot reach it** — the −2/y² term saturates at −8 while the
real-zero sum plausibly exceeds it. A certified Σ_upper is a bounded new
artifact (one session); it closes MOST of the interval, never all.

**(c) The arb real-segment certificate (closes it completely).** Certify no
sign change of Λ(σ,χ₈) on σ ∈ [½, 1): Λ real there, Λ(σ) > 0 for σ ≥ 1
(Euler product + L(1,ψ) ≠ 0, Hecke, classical), symmetry covers (0,½]. With
(b) in hand only the short segment σ ∈ (0.95, 1) is left. Needs the
production engine (§II.5, validated at the central point to 5×10⁻¹⁴)
evaluated at real s — **a bounded production run on owned machinery; the one
route that fully closes the caveat.**

## 4. A scope question flagged for R-312/R-313 (question, not an assertion)

Paper §II.4's reading — "No real zero of Q — hence no off-line zero pair or
degeneracy signature of Ξ — exists at derivative level in [0,3.2]" — is exact
for near-line pairs (small displacement ⟹ locally dominant negative term ⟹
Q < 0 near the projection). The §3(b) analysis shows the **pure-imaginary
pair (the real zero, projection t = 0, displacement up to ½)** is the
implication's weak corner: Q(0) > 0 coexists with a hypothetical β₀ near 1
unless Σ 1/γ² is certified small enough. **Ask with the package: does the
R-312/R-313 off-line-exclusion derivation quantify displacement, or is the
sentence's intended scope near-line?** If the latter, one hedge word in a
future revision makes it exact; the certificate itself (Q > 0) is untouched
either way.

## 5. Net

The "which check" question FINDINGS §3b left for Ilya is **answered by us**:
the record does not cover t = 0 (this step), and the remaining object is
route (c) — the arb real-segment certificate — with (b) available as a
same-machinery partial and (a) as the cheapest derivation route. The DLVP
statement of record continues to ship WITH the caveat until one of (a)/(c)
runs. Nothing here changes step 1's certified algebra or the classical
citations.

*Not RH/GRH. The exceptional-zero question is exactly the classical one; no
claim is made that any route crosses anything beyond it.*
