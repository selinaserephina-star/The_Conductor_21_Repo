# FINDINGS — DLVP audit: the sphinx zero-free-region chain, verified at its earned grade

**Stenberg + Claude (Fable). 2026-08-15. The bounded audit session named as the
precondition in the 08-15 revision plan (memory:
`final-mechanism-sweep-before-submission`). ONE LOCK — this session only;
nothing sealed, nothing sent, no SHA; the live paper untouched. Not RH/GRH.**

## 0. What was audited, and the verdict

The sphinx note (`to_Ilya_WALL_STATE_2026-07-29/NOTE_sphinx_compliant_plan.md`
§1, SENT 07-29, reading grade) claims: with M the fixed field of a Sylow C₇ in
the PSL(2,7)-closure, ζ_M = ζ_K · L(s,χ₈)², and hence (Hecke–Landau) the
classical De la Vallée-Poussin zero-free region for L(s,χ₈), unconditionally.

**Verdict: the chain is SOUND, with one caveat the sphinx note under-stated
(the possible exceptional real zero — §3). The algebraic core is now
machine-certified exactly; the analytic layer is classical and cited. The
factorization needs strictly LESS than the note assumed: entirety of L(χ₇) /
Aramata–Brauer is NOT required (§2, remark).**

## 1. The algebraic core — CERTIFIED (exact, mutation-tested)

`step_1_verify_factorization.py` (log: `step_1_verify_factorization.log`)
builds G = PSL(2,7) from its action on P¹(F₇) — **no character-table value is
typed as a literal anywhere** — and verifies in exact integer/rational
arithmetic:

| check | statement | result |
|---|---|---|
| A1 | |G| = 168; 6 classes, sizes {1,21,24,24,42,56}; orders {1,2,3,4,7}; 7A/7B split 24/24 | PASS |
| A2 | H = N_G(C₇), |H| = 21, Frobenius 7:3, C₇ ◁ H, H/C₇ ≅ C₃, n₇ = [G:H] = 8 ⟹ K = fix(H) deg 8, M = fix(C₇) deg 24, K ⊂ M, **M/K Galois cyclic cubic** | PASS |
| A3 | χ₈ := Ind_H^G λ (λ a nontrivial linear of H, kernel C₇): degree 8, **irreducible** (⟨χ,χ⟩ = 1), integer-valued (**self-dual**), and **Ind λ = Ind λ² exactly** — the "ψ² = ψ̄" step | PASS |
| A4 | **π_M = π_K + 2·χ₈ pointwise on all 6 classes**; degrees 24 = 8 + 2·8 ⟹ (Artin formalism) **ζ_M = ζ_K · L(s,χ₈)²** | PASS |
| A5 | π_K − 1 irreducible of degree 7 ⟹ ζ_K = ζ·L(χ₇) (context only — see §2 remark) | PASS |

**Gate calibration:** the script was mutation-tested with three independent
perturbations (identity coefficient 2 → 1; the λ-coset exponent map scrambled;
a fixed-point count off by one) — **3/3 KILLED**, original restored and passing.

Consistency with the registry: A3's Ind λ irreducible of degree 8 is the
character-level face of the M-105 bridge L_ℚ(χ₈) = L_K(ψ) (CERTIFIED), and A2's
cyclic-cubic M/K is the field-level home of ψ. No conflict, no new object.

## 2. The analytic layer — classical, by citation

Each step named, none re-proved here:

1. **Artin formalism** (character identity ⟹ L-function identity):
   ζ_{fix(U)} = ∏_χ L(s,χ)^{⟨χ, Ind_U^G 1⟩}, applied to U = C₇ and U = H.
   Classical (Artin); needs only meromorphy, which Brauer supplies
   unconditionally.
2. **Entirety of L(s,χ₈)**: χ₈ monomial ⟹ Hecke (registry M-105 CERTIFIED;
   paper §I.2). Needed so a zero of L(χ₈) cannot be masked by a pole.
3. **ζ_K, ζ_M** are Dedekind zetas: meromorphic, single simple pole at s = 1
   (Hecke).
4. **Landau's zero-free region for Dedekind zetas** (Landau 1918; effective
   modern form Lagarias–Odlyzko 1977, Lemma 8.1–8.2): ζ_M ≠ 0 on Re(s) = 1,
   and there is an effective c > 0 with ζ_M(σ+it) ≠ 0 in
   σ ≥ 1 − c/(log d_M + n_M log(|t|+3)), n_M = 24, **except possibly one
   simple real zero β₀** (the exceptional/Landau–Siegel zero).

**The inheritance argument, one line.** In the region, ζ_K is finite and
nonzero-pole-free away from s = 1 and L(χ₈) is entire, so a zero of L(χ₈)
inside the region would force ζ_M = 0 there — contradiction; at s = 1 the
simple poles of ζ_M and ζ_K cancel, giving **L(1,χ₈) ≠ 0**.

**Remark (a strengthening of the sphinx note's bookkeeping).** The argument
never needs L(χ₇) to be entire (Artin conjecture for χ₇ / Aramata–Brauer does
not apply — K/ℚ is not Galois): only ζ_K as a Dedekind zeta enters. A5 is
recorded as context, not load.

## 3. The statement at its earned grade, caveat displayed

> **(DLVP for the genome; classical inputs, algebraic core machine-certified;
> CAVEAT-FREE by M-328.)** L(s,χ₈) is nonvanishing on Re(s) = 1, L(1,χ₈) ≠ 0,
> and there is an effective c > 0 such that L(s,χ₈) ≠ 0 in
> σ ≥ 1 − c/(log d_M + 24·log(|t|+3)) — **with NO exceptional-zero caveat on
> the genome factor**: Landau/Lagarias–Odlyzko allow at most one zero in the
> region counted with multiplicity, and a real zero of L(χ₈) would be a zero
> of ζ_M = ζ_K·L(χ₈)² of multiplicity ≥ 2 — contradiction (registry **M-328**,
> Siegel-allowance repair of 2026-08-02, PROVEN; `step_3_m328_closure.md`).
> The possible exceptional zero of ζ_M is thereby confined to the ζ·L(χ₇)
> factors — and ζ has none in (0,1) classically, so only L(χ₇) could carry it.

**The caveat is the audit's one correction to the sphinx note**, which stated
"the De la Vallée-Poussin zero-free region for every factor" without the
exceptional-zero clause. Direction of the correction: the note claimed slightly
too much; the Re(s) = 1 statement and L(1,χ₈) ≠ 0 are clean and unqualified.

### 3b. COMPOSITION OBSERVATION (added 2026-08-15, same session, before seal-for-send): the caveat is expected to be dischargeable by the paper's OWN Part II — one check owed

A possible exceptional zero of L(χ₈) is **real**: β₀ ∈ (0,1), i.e. height
t = 0 — inside the certified completeness box (T = 6.55 ≫ 0). By ε = +1
self-duality it would come paired (β₀, 1−β₀): two strip zeros below the Turing
heights not among the ball-certified on-line zeros, contradicting the Part II
completeness certificate. **If this composition holds as implemented, the
region of §3 becomes CAVEAT-FREE for L(χ₈)** — the exceptional zero of ζ_M, if
any, is forced into the ζ·L(χ₇) factors — and the genome gets a clean,
unconditional, all-heights zero-free region certified partly by the paper's own
computations.

**The check RAN, same session — see `step_2_composition_check.md`.** Its
narrow findings stand: the gate theorem of record counts **0 < Im ρ strictly**
and Palojärvi–Zhao count on (t₁, t₂], so the certified counting convention
does not cover t = 0; three counting-side closure routes were graded there.
**Its conclusion is SUPERSEDED by `step_3_m328_closure.md`:** the caveat was
already discharged on 2026-08-02 by a fourth route none of step 2 named —
registry **M-328**'s multiplicity argument (a real χ₈-zero would be a
multiplicity-≥2 zero of ζ_M = ζ_K·L(χ₈)², against Landau's
at-most-one-with-multiplicity), located by Selina's recall of the AWS-era
work. §3 above now displays the caveat-free form. No counting route, arb run,
or new derivation is needed for the genome statement.

**Leverage verdict — unchanged.** This is exactly ζ's 3–4–1 mechanism realized
through the 1/ψ/ψ̄ factorization: ζ-level leverage, and provably no more
(sphinx §2; R-013). No known method widens a DLVP region to Re = ½ for any
characteristic-0 L-function. Not a step toward the wall; a floor the structure
supplies for free.

## 4. Proposed registry row (number assigned at entry — collision discipline)

> **Addendum to M-328 (DLVP audit, 2026-08-15) — not a new row.** The
> factorization behind M-328 (Ind_{C₇} 1 = 1 + χ₇ + 2χ₈ ⟹ ζ_M = ζ_K·L(χ₈)²,
> M = fix(C₇) = K₂₄) gains a THIRD independent verification: exact
> permutation-character machine certificate from the group action, no typed
> table values, mutation-tested 3/3 (`DLVP_AUDIT_2026-08-15/step_1`).
> Displayed consequence consolidated (classical, cited: Artin formalism +
> Hecke + Landau/Lagarias–Odlyzko + M-328's multiplicity repair): L(χ₈) ≠ 0 on
> Re(s) = 1, L(1,χ₈) ≠ 0, and an effective DLVP region **caveat-free on the
> genome factor** (the ζ_M exceptional zero, if any, confined to L(χ₇)).
> Aramata–Brauer dependency removed from the chain (K/ℚ non-Galois; not
> needed). Sphinx-note correction recorded: its unqualified "region for every
> factor" needed M-328 to be true for the χ₈ factor. Leverage: ζ-level, no
> more (R-013). Not RH/GRH.

## 5. Proposed paper paragraph — **E6, revision-gated** (joins the proposal folder's E-series; NOT for the release)

Natural home: end of §I.4 (after the de Bruijn–Newman paragraph), or §IV.10.3
beside the no-lever steps.

> **The unconditional zero-free region.** The group structure supplies,
> unconditionally, the classical zero-free region for the genome. Let M be the
> fixed field of a Sylow C₇ in the PSL(2,7)-closure ([M:ℚ] = 24), the cyclic
> cubic extension of K cut out by ψ; at the character level
> π_{G/C₇} = π_{G/H} + 2χ₈ exactly, so ζ_M = ζ_K·L(s,χ₈)² by Artin formalism.
> Since ζ_M is a Dedekind zeta — nonnegative log-coefficients, simple pole at
> s = 1 — Landau's method gives ζ_M ≠ 0 on Re(s) = 1 and an effective De la
> Vallée-Poussin region with at most one real zero counted with multiplicity;
> and because L(χ₈) enters ζ_M **squared**, a real zero of L(χ₈) would have
> multiplicity ≥ 2 there — so the exceptional allowance can never fall on the
> genome factor (M-328). Hence L(s,χ₈), entire by §I.2, is zero-free in the
> full region at every height, with no caveat, and L(1,χ₈) ≠ 0. This is
> exactly ζ's own 3–4–1 positivity realized through the 1/ψ/ψ̄ factorization —
> and it is all the structure buys: the leverage is ζ-level, and provably no
> more (R-013, §IV.10.3). [Algebraic identity machine-certified
> (`DLVP_AUDIT_2026-08-15`, third leg after M-328's two); analytic steps
> classical, cited.]

## 6. Honest boundaries

- **One lock.** Everything here is this session's; nothing enters a
  certificate, a lemma grade, or a sent document until audited from another
  session (closeout §6.4 discipline).
- The machine check certifies the **character identity**; the field-level
  reading (fixed fields, Galois cyclic cubic) is standard Galois
  correspondence, and the L-function reading is Artin formalism — cited, not
  re-proved.
- d_M is not computed here; the region is stated with effective constants by
  citation only.
- **Adoption remains revision-gated with Ilya's markup** (the 08-15 plan,
  order: E6/DLVP first, then step (5), then the mechanism framing). The
  release ships untouched.
- Registry entry: proposed text in §4, number to be assigned at entry-time
  after a collision scan — not written by this session.

*Not RH/GRH. Nothing here is evidence for or against (SA); the region stops at
the classical line, as it must.*
