# COVER — DLVP audit package: the sphinx zero-free-region chain, verified and corrected; your audit requested

**To Ilya, from Selina + Claude (Fable). 2026-08-15. AUDIT-REQUEST package.
Status at build time: SEALED, NOT SENT — send is Selina's act and her record.
Everything here is ONE LOCK on our side; your audit is the second lock it
needs before anything enters the registry or the paper. Not RH/GRH.**

---

## 1. What this is

Your copy of the WALL_STATE package (2026-07-29) contains
`NOTE_sphinx_compliant_plan.md`, whose §1 claims, at reading grade:

> M := L^{C₇} (fixed field of the Singer C₇), [M:ℚ] = 24, is a cyclic cubic
> extension of K with group ⟨ψ⟩, hence ζ_M = ζ_K·L_K(ψ)·L_K(ψ²) =
> ζ_K·L(s,χ₈)², and so (Hecke–Landau) the De la Vallée-Poussin zero-free
> region for every factor, including L(χ₈).

This package upgrades that chain from reading grade to its earned grade:

- **The algebraic core is machine-CERTIFIED** (`step_1_verify_factorization.py`
  + log): G = PSL(2,7) is built from its action on P¹(F₇) — no character-table
  value is typed anywhere — and exact integer/rational arithmetic verifies:
  H = N_G(C₇) is the Frobenius 7:3 (so M/K is Galois cyclic cubic);
  χ₈ = Ind_H^G λ is irreducible, integer-valued (self-dual), with
  Ind λ = Ind λ² exactly (the ψ² = ψ̄ step); and the load-bearing identity
  **π_M = π_K + 2χ₈ pointwise on all six classes** (degrees 24 = 8 + 2·8).
  The gate was mutation-tested (three independent perturbations, 3/3 killed,
  original restored and passing).
- **The analytic layer enters by citation only** (Artin formalism; Hecke
  entirety of the monomial χ₈ = your/our M-105; Landau's Dedekind-zeta
  zero-free region, effective form Lagarias–Odlyzko 1977).

## 2. The two corrections the audit made to our own sent note

1. **The sphinx note claimed slightly too much.** Landau's region for ζ_M
   carries the classical caveat: **at most one simple real exceptional zero**.
   If it exists it lies in exactly one of ζ, L(χ₇), L(χ₈) — and χ₈ is real
   orthogonal, the hard case, so nothing unconditional excludes the third.
   The clean unqualified parts survive: L(χ₈) ≠ 0 on Re(s) = 1, and
   L(1,χ₈) ≠ 0. All displayed statements now carry the caveat.
2. **The chain needs less than the note assumed.** L(χ₇)-entirety
   (Aramata–Brauer) is never used and would not even apply (K/ℚ is not
   Galois); only ζ_K as a Dedekind zeta and the entirety of L(χ₈) enter.
   The argument got simpler under audit.

Full statements, grades, and boundaries: `FINDINGS_dlvp_audit.md` (§3 for the
theorem-shaped display with the caveat, §6 for the honest boundaries).

## 3. What we ask of you (three items, in order)

1. **Audit the algebraic core independently.** The Python script is
   self-contained (stdlib only, ~1s). A GAP crosscheck on your tooling should
   be a few lines — *suggested shape only, not run on our side; the executed
   verification is the Python*:

   ```gap
   G := PSL(2,7);; C7 := SylowSubgroup(G,7);; H := Normalizer(G,C7);;
   piM := PermutationCharacter(G, C7);; piK := PermutationCharacter(G, H);;
   d := (piM - piK)/2;;   # expect: irreducible of degree 8 (the Steinberg)
   ```

2. **The exceptional-zero question — CLOSED, by your own M-328 repair; the
   paper trail is steps 2–3.** We first asked whether the completeness
   certificate discharges the DLVP caveat at t = 0; `step_2` found the
   counting conventions don't cover the real axis (your gate's strict
   0 < Im ρ — correct and nothing wrong; PZ on (t₁,t₂]) and graded three
   closure routes. Then Selina's recall located the fourth, already-run
   route: **your Siegel-allowance repair of 2026-08-02 (M-328)** — L(χ₈)
   enters ζ_{K₂₄} squared, so a real χ₈-zero would have multiplicity ≥ 2
   against Landau's at-most-one — which transfers verbatim to this audit's
   region (same field, same factorization). `step_3` records the closure;
   §3's display is now **caveat-free on the genome factor**, resting on
   M-328 + the classical citations. **Remaining ask here is small:** confirm
   the M-328 transfer reads as we state it, and — a minor scope question
   surviving from step 2 §4, not load-bearing — whether §II.4's "no off-line
   zero pair" reading is intended near-line (the pure-imaginary pair is its
   weak corner; one hedge word in a revision would make it exact).

3. **The disposition question — the reason this package exists.** Upon your
   agreement, and not before:
   - a **registry row** enters (proposed text in FINDINGS §4; number assigned
     at entry after a collision scan, per the standing discipline), and
   - a **paragraph enters the paper in the next revision** (proposed text in
     FINDINGS §5 — "E6"; natural home end of §I.4 or §IV.10.3 beside the
     no-lever steps). The released paper is untouched until then, and your
     markup of the paragraph governs.

## 4. Scope, stated so it cannot be over-read

This is a **floor, not a step**: the region is exactly ζ's 3–4–1 mechanism
realized through the 1/ψ/ψ̄ factorization — ζ-level leverage, and provably no
more (R-013; sphinx §2). It says nothing about the wall (SA)/R-209 in either
direction. Its value to the paper is completeness: the strongest unconditional
statement the structure supplies about the zeros' real parts, currently absent
from the release.

## 5. Package contents

| file | what |
|---|---|
| `COVER_NOTE_to_IB.md` | this |
| `FINDINGS_dlvp_audit.md` | the audit of record: checks, corrections, caveat-free graded statement, proposed M-328 addendum + paper paragraph |
| `step_1_verify_factorization.py` | the executed verification (stdlib Python, exact arithmetic, assertion-gated) |
| `step_1_verify_factorization.log` | its run log (all five checks PASS) |
| `step_2_composition_check.md` | the counting-convention check (narrow findings stand; conclusion superseded by step 3) |
| `step_3_m328_closure.md` | the closure: M-328's multiplicity repair transfers; provenance corrections incl. step 1 = third leg |
| `SHA256SUMS` | per-file hashes |

*— Selina + Claude (Fable), 2026-08-15. One chain, two corrections, three
asks; nothing claimed past its grade, nothing enters anything without your
second lock. Not RH/GRH.*
