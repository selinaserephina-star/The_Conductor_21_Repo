# DLVP_AUDIT_2026-08-15 / step 1 — machine-verify the algebraic core of the
# sphinx chain (NOTE_sphinx_compliant_plan.md §1, sent 07-29):
#
#   zeta_M = zeta_K * L(chi8)^2
#
# at the level of characters of G = PSL(2,7), with EVERYTHING computed from the
# group itself (permutation action on P^1(F_7)) in exact integer/rational
# arithmetic. No character-table values are typed as literals anywhere.
#
# What is verified here (the algebraic layer):
#   [A1] G = PSL(2,7): order 168, 6 conjugacy classes, element orders {1,2,3,4,7}.
#   [A2] C7 = a Sylow-7 subgroup; H = N_G(C7) has order 21, is Frobenius 7:3
#        (C7 normal, H/C7 cyclic of order 3, H nonabelian); n_7 = [G:H] = 8.
#        Field translation: K = fixed field of H (degree 8), M = fixed field of
#        C7 (degree 24), K subset M, M/K Galois with group H/C7 = C3 (cyclic cubic).
#   [A3] lambda = a nontrivial linear character of H with kernel C7 (values in
#        mu_3, tracked exactly as coset counts). chi8 := Ind_H^G lambda is
#        irreducible of degree 8, real-valued (self-dual), and
#        Ind lambda = Ind lambda^2  (the "psi^2 = psi-bar / chi8 self-dual" step).
#   [A4] THE IDENTITY: pi_M = pi_K + 2*chi8 pointwise on every class, where
#        pi_M, pi_K are the permutation characters of G on G/C7, G/H.
#        Equivalently pi_M - pi_K = Ind lambda + Ind lambda^2 with both summands
#        equal. Degree check 24 = 8 + 2*8.
#   [A5] pi_K = 1 + chi7 with chi7 irreducible (2-transitivity), so
#        zeta_K = zeta * L(chi7) — the companion fact used in the FINDINGS.
#
# What is NOT verified here and enters by citation (the analytic layer — see
# FINDINGS_dlvp_audit.md): Artin formalism (character identity => L-function
# identity), Hecke entirety of the monomial chi8 (M-105 CERTIFIED), Aramata-
# Brauer entirety of zeta_K/zeta, and Landau's zero-free region for Dedekind
# zetas WITH the possible-exceptional-real-zero caveat.
#
# Exit 0 with "ALL CHECKS PASS" or raises AssertionError. One lock, this session.

from fractions import Fraction
from itertools import product

# ---------- [A1] build G = PSL(2,7) on P^1(F_7): points 0..6, 7 = infinity ----------
INF = 7
PTS = list(range(8))

def mob_s(z):   # z -> z+1
    return INF if z == INF else (z + 1) % 7

def mob_t(z):   # z -> -1/z
    if z == INF: return 0
    if z == 0:  return INF
    return (-pow(z, 5, 7)) % 7   # z^5 = z^{-1} mod 7

def to_perm(f):
    return tuple(f(z) for z in PTS)

def compose(p, q):               # (p*q)(z) = p(q(z))
    return tuple(p[q[z]] for z in PTS)

def inverse(p):
    inv = [0] * 8
    for i, v in enumerate(p): inv[v] = i
    return tuple(inv)

ID = tuple(PTS)
gen_s, gen_t = to_perm(mob_s), to_perm(mob_t)

G = {ID}
frontier = [ID]
while frontier:
    nxt = []
    for p in frontier:
        for g in (gen_s, gen_t):
            q = compose(g, p)
            if q not in G:
                G.add(q); nxt.append(q)
    frontier = nxt
G = sorted(G)
assert len(G) == 168, f"|G| = {len(G)} != 168"

def order(p):
    q, n = p, 1
    while q != ID:
        q = compose(q, p); n += 1
    return n

orders = {p: order(p) for p in G}
assert set(orders.values()) == {1, 2, 3, 4, 7}, sorted(set(orders.values()))

# conjugacy classes
unassigned = set(G)
classes = []           # list of (representative, frozenset of elements)
while unassigned:
    g = next(iter(unassigned))
    cl = frozenset(compose(compose(x, g), inverse(x)) for x in G)
    classes.append((g, cl))
    unassigned -= cl
assert len(classes) == 6, f"{len(classes)} classes != 6"
class_sizes = sorted(len(c) for _, c in classes)
assert sum(class_sizes) == 168
# two distinct classes of order-7 elements (7A/7B), sizes 24+24
sevens = [c for _, c in classes if orders[next(iter(c))] == 7]
assert len(sevens) == 2 and all(len(c) == 24 for c in sevens), \
    [len(c) for c in sevens]
print(f"[A1] PASS  |G|=168, 6 classes, sizes {class_sizes}, orders 1,2,3,4,7 (7A,7B split 24/24)")

# ---------- [A2] C7, its normalizer H, and the field dictionary ----------
g7 = next(p for p in G if orders[p] == 7)
C7 = set()
q = ID
for _ in range(7):
    C7.add(q); q = compose(q, g7)
assert len(C7) == 7

H = {x for x in G if all(compose(compose(x, c), inverse(x)) in C7 for c in C7)}
assert len(H) == 21, f"|N_G(C7)| = {len(H)} != 21"
assert C7 <= H
# C7 normal in H (it is, by construction of the normalizer); H/C7 cyclic of order 3
h3 = next(x for x in H if orders[x] == 3)
# coset decomposition H = C7 u C7*h3 u C7*h3^2, i.e. every x in H has unique
# k in {0,1,2} with x*h3^{-k} in C7
h3i = inverse(h3)
def coset_exponent(x):
    ks = [k for k in range(3)
          if compose(x, [ID, h3i, compose(h3i, h3i)][k]) in C7]
    assert len(ks) == 1, "coset decomposition failed"
    return ks[0]
for x in H: coset_exponent(x)
# H nonabelian (Frobenius 7:3), and n_7 = index of the normalizer = 8
assert any(compose(a, b) != compose(b, a) for a in H for b in H)
assert 168 // len(H) == 8
print("[A2] PASS  H=N_G(C7), |H|=21, Frobenius 7:3, C7 normal, H/C7=C3, n_7=[G:H]=8")
print("           => K=fix(H) deg 8, M=fix(C7) deg 24, K c M, M/K Galois cyclic cubic (group H/C7)")

# ---------- [A3] chi8 = Ind_H^G lambda: irreducible, degree 8, self-dual ----------
# lambda(x) = omega^{coset_exponent(x)}. Induced character value at g:
#   chi(g) = (1/|H|) * sum_{x in G, x^{-1} g x in H} lambda(x^{-1} g x)
# tracked exactly as integer coset counts (n0, n1, n2); value = (n0 + n1 w + n2 w^2)/21.
Ginv = {p: inverse(p) for p in G}

def induced_counts(g, expo_fn):
    n = [0, 0, 0]
    for x in G:
        y = compose(compose(Ginv[x], g), x)
        if y in H:
            n[expo_fn(y)] += 1
    return n

def ind_char(expo_fn):
    vals = {}
    for rep, cl in classes:
        n0, n1, n2 = induced_counts(rep, expo_fn)
        # real  <=>  n1 == n2, then value = (n0 - n1)/21 exactly (w + w^2 = -1)
        vals[rep] = (n0, n1, n2)
    return vals

lam_vals  = ind_char(coset_exponent)                       # Ind lambda
lam2_vals = ind_char(lambda y: (2 * coset_exponent(y)) % 3)  # Ind lambda^2

chi8 = {}
for rep, cl in classes:
    n0, n1, n2 = lam_vals[rep]
    assert n1 == n2, f"Ind lambda not real-valued at class of order {orders[rep]}"
    v = Fraction(n0 - n1, 21)
    assert v.denominator == 1, "non-integral character value"
    chi8[rep] = int(v)
# Ind lambda == Ind lambda^2  (psi^2 = psi-bar at the character level)
for rep, _ in classes:
    a0, a1, a2 = lam_vals[rep]; b0, b1, b2 = lam2_vals[rep]
    assert (a0, a1, a2) == (b0, b2, b1) and a1 == a2, "Ind lambda != Ind lambda^2"
# degree 8, irreducible (<chi,chi> = 1), values integral
assert chi8[ID] == 8
norm = sum(Fraction(len(cl)) * chi8[rep] ** 2 for rep, cl in classes) / 168
assert norm == 1, f"<chi8,chi8> = {norm} != 1  (Ind lambda not irreducible)"
# value 1 on both order-7 classes (recorded, used in the FINDINGS display)
for rep, cl in classes:
    if orders[rep] == 7:
        assert chi8[rep] == 1
print("[A3] PASS  chi8 := Ind_H^G lambda: degree 8, irreducible (<chi,chi>=1), integer-valued")
print("           (self-dual), and Ind lambda = Ind lambda^2 exactly  [psi^2 = psi-bar step]")

# ---------- [A4] the identity  pi_M = pi_K + 2*chi8  pointwise ----------
def pi_K(g):   # fixed points on the 8 points  (G/H  ~ P^1(F_7) action)
    return sum(1 for z in PTS if g[z] == z)

def pi_M(g):   # fixed cosets of C7 in G:  (1/7) #{x : x^{-1} g x in C7}
    cnt = sum(1 for x in G if compose(compose(Ginv[x], g), x) in C7)
    v = Fraction(cnt, 7)
    assert v.denominator == 1
    return int(v)

for rep, cl in classes:
    lhs, rhs = pi_M(rep), pi_K(rep) + 2 * chi8[rep]
    assert lhs == rhs, \
        f"pi_M != pi_K + 2*chi8 at class order {orders[rep]}: {lhs} vs {rhs}"
assert pi_M(ID) == 24 and pi_K(ID) == 8 and 24 == 8 + 2 * 8
print("[A4] PASS  pi_M = pi_K + 2*chi8 on ALL 6 classes; degrees 24 = 8 + 2*8")
print("           => (Artin formalism) zeta_M = zeta_K * L(chi8)^2")

# ---------- [A5] companion: pi_K = 1 + chi7 with chi7 irreducible ----------
chi7 = {rep: pi_K(rep) - 1 for rep, _ in classes}
norm7 = sum(Fraction(len(cl)) * chi7[rep] ** 2 for rep, cl in classes) / 168
assert norm7 == 1 and chi7[ID] == 7
print("[A5] PASS  pi_K - 1 irreducible of degree 7  => zeta_K = zeta * L(chi7)")

print()
print("ALL CHECKS PASS — the algebraic core of  zeta_M = zeta_K * L(chi8)^2  is exact.")
print("Analytic layer (Artin formalism, Hecke/Aramata-Brauer entirety, Landau region")
print("with the exceptional-zero caveat) enters by citation: see FINDINGS_dlvp_audit.md.")
