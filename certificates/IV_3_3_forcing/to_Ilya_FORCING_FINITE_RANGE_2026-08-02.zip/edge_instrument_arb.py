r"""
FORCING campaign 2026-08-02 — ADDENDUM: THE EDGE INSTRUMENT (arb-grade rerun).

SUPERSEDES edge_instrument.py (float64), whose own trace ledger REFUTED it:
tr J(300) = 62.6 vs sum(atoms) = 4.51 for F — the float64 no-reorth Lanczos
ghost-duplicates converged Ritz values at m=300 on these clustered atoms.
RECORDED TRAP: the M-233 float64-agreement note applies to the certified-cache
coefficients (production range); at m=300 nested-section depth float64 is
invalid — the plain 3-term recursion needs high precision (the arb-jet
discipline: no reorth, high prec, radii self-certify).

Here: Lanczos in arb at prec 6000 (M-233 setting; coefficient ball radii
printed — the recursion certifies its own coefficients), sections + eigensolves
in float64 FROM the exact coefficients (tridiagonal eigensolve is backward
stable; MEASURED grade overall).

Measurements (see edge_instrument.py header for full rationale):
 (1) string taper a_k, b_k -> the descent law to the accumulation edge at 0;
 (2) trace ledger T(k) = sum_(i>k) a_i (verified: sum a_i == sum x_n in arb);
 (3) edge resolution: which atoms a k-section actually captures (atom->Ritz
     matching), the unresolved-edge count + displacement profile;
 (4) F (primes) vs D (geometry) comparison.
Not RH/GRH.
"""
import json, math, time
import numpy as np
from flint import arb, ctx

MAIN = r"C:\Users\selin\OneDrive\Desktop\Ilya Riemanns"
ROWS = json.load(open(MAIN + r"\WALL_KLMN_ARB_CERT_2026-07-31\quantiles_certified.json"))["rows"]
M = 300
PREC = 6000

def jacobi_arb(atoms):
    m = len(atoms)
    v = [arb(m).rsqrt()] * m
    a = []; b = []
    w = [atoms[i] * v[i] for i in range(m)]
    a0 = sum((v[i] * w[i] for i in range(m)), arb(0)); a.append(a0)
    w = [w[i] - a0 * v[i] for i in range(m)]
    vprev = v
    for j in range(1, m):
        be = sum((x * x for x in w), arb(0)).sqrt()
        b.append(be)
        vn = [w[i] / be for i in range(m)]
        w = [atoms[i] * vn[i] - be * vprev[i] for i in range(m)]
        al = sum((vn[i] * w[i] for i in range(m)), arb(0)); a.append(al)
        w = [w[i] - al * vn[i] for i in range(m)]
        vprev = vn
    return a, b

def build(tag, g_strs):
    ctx.prec = PREC
    atoms = [arb(1) / arb(s) ** 2 for s in g_strs]
    t0 = time.time()
    a, b = jacobi_arb(atoms)
    dt = time.time() - t0
    maxrad = max(float(x.rad()) for x in a + b)
    tr = sum(a, arb(0)); sx = sum(atoms, arb(0))
    diff = float(abs(tr - sx).upper())
    print(f"[{tag}] Lanczos m={M} prec={PREC}: {dt:.1f}s; max coeff radius = {maxrad:.2e}; "
          f"|tr J - sum x| <= {diff:.2e}  (trace identity {'OK' if diff < 1e-50 else 'FAIL'})")
    assert diff < 1e-50, "trace identity must hold at arb grade"
    return np.array([float(x) for x in a]), np.array([float(x) for x in b]), \
           np.array([float(x) for x in atoms])

def eig_section(a, b, k):
    return np.linalg.eigvalsh(np.diag(a[:k]) + np.diag(b[:k - 1], 1) + np.diag(b[:k - 1], -1))

def analyze(tag, a, b, x):
    print(f"\n========== {tag}-ladder string (exact coefficients, m={M}) ==========")
    print("(1) string taper (descent to the accumulation edge at 0):")
    for k in (1, 10, 25, 50, 100, 150, 200, 250, 290):
        bb = b[k - 1] if k - 1 < len(b) else float('nan')
        print(f"    k={k:3d}  a_k={a[k-1]:.6e}  b_k={bb:.6e}")
    import numpy.polynomial.polynomial as P
    for name, arr in (("a", a), ("b", b)):
        for (k1, k2) in ((10, 60), (60, 290)):
            kk = np.arange(k1, min(k2, len(arr)) + 1)
            s = np.polyfit(np.log(kk), np.log(arr[k1 - 1:min(k2, len(arr))]), 1)[0]
            print(f"    fitted slope log {name}_k / log k on [{k1},{k2}] = {s:+.3f}")
    sref = np.polyfit(np.log(np.arange(10, 101)), np.log(np.sort(x)[::-1][9:100]), 1)[0]
    print(f"    reference atom-decay slope (sorted desc, [10,100]): {sref:+.3f}")

    print("(2) trace ledger T(k) = sum_(i>k) a_i:")
    kgrid = [25, 50, 75, 100, 150, 200, 250, 275]
    T = {k: a[k:].sum() for k in kgrid}
    for k in kgrid:
        print(f"    k={k:3d}  T(k) = {T[k]:.6e}   atom-tail sum_(n>k) x_(n) sorted = "
              f"{np.sort(x)[:M - k].sum():.6e}")
    for (k1, k2) in ((25, 100), (100, 275)):
        s = (math.log(T[k2]) - math.log(T[k1])) / (math.log(k2) - math.log(k1))
        print(f"    measured trace-tail exponent on [{k1},{k2}]: T(k) ~ k^{s:+.3f}")

    print("(3) edge resolution (atom -> nearest Ritz matching):")
    xs = np.sort(x)                                   # ascending, edge cluster first
    gaps = np.diff(xs); locgap = np.empty(M)
    locgap[1:-1] = np.minimum(gaps[:-1], gaps[1:]); locgap[0] = gaps[0]; locgap[-1] = gaps[-1]
    prof = {}
    for k in (50, 100, 150, 200, 250):
        lam = eig_section(a, b, k)
        d = np.abs(xs[:, None] - lam[None, :]).min(axis=1)
        missed = d > 0.5 * locgap
        nmiss = int(missed.sum())
        # deepest resolved atom index from the edge (0 = smallest atom = highest zero)
        first_resolved = int(np.argmax(~missed)) if (~missed).any() else M
        prof[k] = (nmiss, first_resolved, d / locgap)
        print(f"    k={k:3d}: atoms missed {nmiss}/300; edge boundary: first resolved atom "
              f"index-from-edge = {first_resolved}")
    print("    relative displacement (d/local-gap) of the first 8 atoms from the edge:")
    for k in (100, 200, 250):
        d8 = ", ".join(f"{v:.2f}" for v in prof[k][2][:8])
        print(f"      k={k:3d}: [{d8}]")
    for (k1, k2) in ((50, 250),):
        n1, n2 = prof[k1][0], prof[k2][0]
        if n1 > 0 and n2 > 0:
            s = (math.log(n2) - math.log(n1)) / (math.log(k2) - math.log(k1))
            print(f"    missed-atom-count scaling on [{k1},{k2}]: ~ k^{s:+.3f}  ({n1} -> {n2})")
    return T, prof

gF = [r["gF_mid"] for r in ROWS]
gD = [r["gD_mid"] for r in ROWS]
aF, bF, xF = build("F", gF)
aD, bD, xD = build("D", gD)
TF, pF = analyze("F", aF, bF, xF)
TD, pD = analyze("D", aD, bD, xD)

print("\n========== (4) prime dressing at the edge: F vs D ==========")
print("    trace-tail ratio T_F(k)/T_D(k):")
for k in sorted(TF):
    print(f"      k={k:3d}: {TF[k]/TD[k]:.6f}")
print("    missed-atom counts (F vs D):")
for k in (50, 100, 150, 200, 250):
    print(f"      k={k:3d}: F {pF[k][0]:3d}   D {pD[k][0]:3d}")
print("\nEdge instrument (arb coefficients + float sections) complete — MEASURED grade.")
print("Not RH/GRH.")
