r"""
FORCING campaign 2026-08-02 — TAX CONTROL, FULL BATCH (50 seeds):
is the S_P correlation structure protective, or was the ~20th-percentile
placement of the real string a 10-seed fluke?

Null model: synthetic strings with the ACTUAL gap-modulation sequence randomly
permuted (marginal distribution kept exactly, correlation structure destroyed),
M = 600, cells k = 450 / 500 / 550.  Statistic per string: net tax vs D per
cell, and the 3-cell sum.  The real F string's values are located within the
null distribution; one-sided p reported (H1: real < null median = coherence
protects placement).

Seeds 1..50 (supersedes the 10-seed reads in tax_control*.log — those seeds are
re-run here inside one consistent batch).  Grade: MEASURED.  Not RH/GRH.
"""
import json, time
import numpy as np
from flint import arb, ctx

HERE = r"C:\Users\selin\OneDrive\Desktop\Ilya Riemanns\.claude\worktrees\suspicious-lumiere-dbbf9e\FORCING_EXECUTION_2026-08-02"
ROWS = json.load(open(HERE + r"\quantiles_certified_600.json"))["rows"]
M = 600
PREC = 14000
KS = (450, 500, 550)
NSEEDS = 50

gF = np.array([float(arb(r["gF_mid"])) for r in ROWS])[:M]
gD = np.array([float(arb(r["gD_mid"])) for r in ROWS])[:M]
gapD = np.diff(gD)
ratio = np.diff(gF) / gapD

def jacobi_arb(atoms):
    m = len(atoms)
    v = [arb(m).rsqrt()] * m
    a = []; b = []
    w = [atoms[i] * v[i] for i in range(m)]
    a0 = sum((v[i] * w[i] for i in range(m)), arb(0)); a.append(a0)
    w = [w[i] - a0 * v[i] for i in range(m)]
    vprev = v
    for j in range(1, m):
        be = sum((x * x for x in w), arb(0)).sqrt()
        b.append(be)
        vn = [w[i] / be for i in range(m)]
        w = [atoms[i] * vn[i] - be * vprev[i] for i in range(m)]
        al = sum((vn[i] * w[i] for i in range(m)), arb(0)); a.append(al)
        w = [w[i] - al * vn[i] for i in range(m)]
        vprev = vn
    return a, b

def build(g):
    ctx.prec = PREC
    atoms = [arb(1) / arb(f"{v:.17e}") ** 2 for v in g]
    a, b = jacobi_arb(atoms)
    diff = float(abs(sum(a, arb(0)) - sum(atoms, arb(0))).upper())
    assert diff < 1e-40, "trace gate"
    return (np.array([float(v) for v in a]), np.array([float(v) for v in b]),
            np.array([float(v) for v in atoms]))

def eig_section(a, b, k):
    return np.linalg.eigvalsh(np.diag(a[:k]) + np.diag(b[:k - 1], 1) + np.diag(b[:k - 1], -1))

def missed_count(a, b, x, k):
    xs = np.sort(x)
    gaps = np.diff(xs); locgap = np.empty(M)
    locgap[1:-1] = np.minimum(gaps[:-1], gaps[1:]); locgap[0] = gaps[0]; locgap[-1] = gaps[-1]
    lam = eig_section(a, b, k)
    d = np.abs(xs[:, None] - lam[None, :]).min(axis=1)
    return int((d > 0.5 * locgap).sum())

print("references ...", flush=True)
t0 = time.time()
SD = build(gD); SF = build(gF)
base = {k: missed_count(*SD, k) for k in KS}
freal = {k: missed_count(*SF, k) - base[k] for k in KS}
print(f"  D missed {[base[k] for k in KS]}  F net tax {[freal[k] for k in KS]}  "
      f"sum {sum(freal.values())}   ({time.time()-t0:.0f}s)", flush=True)

nets = {k: [] for k in KS}
sums = []
for seed in range(1, NSEEDS + 1):
    rng = np.random.default_rng(seed)
    rp = ratio[rng.permutation(len(ratio))]
    gaps_syn = gapD * rp
    gaps_syn *= gapD.sum() / gaps_syn.sum()
    g_syn = np.concatenate([[gF[0]], gF[0] + np.cumsum(gaps_syn)])
    Ssyn = build(g_syn)
    row = []
    for k in KS:
        n = missed_count(*Ssyn, k) - base[k]
        nets[k].append(n); row.append(n)
    sums.append(sum(row))
    print(f"  seed {seed:2d}: nets {row}  sum {sum(row)}   ({time.time()-t0:.0f}s)", flush=True)

print("\n=== NULL DISTRIBUTION vs REAL ===")
fsum = sum(freal.values())
for k in KS:
    arr = np.array(nets[k])
    pct = 100.0 * np.mean(arr < freal[k]) + 50.0 * np.mean(arr == freal[k])
    p = np.mean(arr <= freal[k])
    print(f"  k={k}: null {arr.mean():+.2f} ± {arr.std(ddof=1):.2f} "
          f"(range {arr.min():+d}..{arr.max():+d})   real {freal[k]:+d}   "
          f"percentile {pct:.0f}%   one-sided p(null<=real) = {p:.3f}")
arr = np.array(sums)
pct = 100.0 * np.mean(arr < fsum) + 50.0 * np.mean(arr == fsum)
p = np.mean(arr <= fsum)
print(f"  3-cell SUM: null {arr.mean():+.2f} ± {arr.std(ddof=1):.2f} "
      f"(range {arr.min():+d}..{arr.max():+d})   real {fsum:+d}   "
      f"percentile {pct:.0f}%   one-sided p = {p:.3f}")
print("\nverdict: p <~ 0.05 on the SUM => coherence protection real at this instrument;")
print("p >~ 0.15 => 10-seed hint was a fluke; between => still unresolved, say so.")
print("Not RH/GRH.")
