# THE FINITE-RANGE FORCING THEOREM — the string built from geometry and primes alone provably sounds the first 153 zeros

**Merkabit · Stenberg + Claude · 2026-08-02. FORCING campaign (staged 2026-07-21,
registry seam 9), execution session 1: stages 1 + 1b/1c certified, stage 2 (light)
measured. Folder `FORCING_EXECUTION_2026-08-02/`. Not RH/GRH — finite-range only;
the n → ∞ statement is the wall (R-209) and is deliberately not claimed.**

## The objects (zeros used nowhere in the construction)

- **θ(t)**: the completed-L phase of χ₈ — pure conductor/geometry data
  (Q = 21¹⁰, μ = (0,0,0,0,½,½,½,½)). No arithmetic beyond the functional equation.
- **S_P(t)**: the truncated Euler fluctuation — pure prime data
  (P = 2×10⁵; 18,120 prime-power terms; traces from LOC8/Frobenius classes).
- **The F-ladder (the string)**: γ_F(n) := the crossing of θ/π + S_P = n − ½.
  The construction inputs are the conductor and the primes ONLY; the certified
  zero list enters solely as the measuring stick (non-circularity audit:
  release paper §IV.2.2).
- **The truth**: the 07-19 certified production run — 153 zero brackets on
  [0, 27.92], all 153 ball-certified (#144 closed 2026-08-02 by targeted endpoint refinement,
  `BRACKET144_CERT_2026-08-02/`, sent).

## THEOREM (finite-range forcing, unconditional; grades marked)

Let γ_F(n) be the certified F-ladder crossings (arb-IVT root balls, max relative
radius 2.6×10⁻¹¹ — M-233 provenance **plus this session's independent full
re-certification, own code path, 153/153 PASSED**). Let γ_n be the certified
zeros. Then, with every numbered constant displayed from exact rational interval
arithmetic over the two certified input sets:

**(i) [CERTIFIED] The gap table.** For every n = 1…153 (all rows, #144 included after its 2026-08-02 ball-certification):

  |γ_F(n) − γ_n| ∈ [gap_lo(n), gap_hi(n)]   (per-row table, `forcing_gap_table.csv`)

with max gap_hi = **0.061263** (n = 147), median **0.016535**, quartiles
[0.007530, 0.026081], min **0.000342** (n = 18). Every row has gap_lo > 0
(153/153: the physical gap is resolved, not noise-limited; max enclosure slack
7.8×10⁻³, dominated by bracket widths). Against the mean certified spacing
0.177136 on the range: **max detune 34.6 %, median detune 9.3 % of a mean gap**.

**(ii) [CERTIFIED] Unambiguous note assignment.** For every n (all 153 rows,
exact interval arithmetic): the certified upper gap to the OWN zero is strictly
smaller than the certified lower distance to EITHER neighboring zero's bracket.
Worst margin: n = 126, own 0.052166 vs neighbor 0.094646 (ratio 0.551).
**Each of the 153 notes identifies its zero uniquely** — the string does not
merely land near zeros, it plays the score in order, one note per zero.

**(iii) [PROVEN, definitional identity] The mechanism.** With
F_n(t) = θ(t)/π + S_P(t) − (n−½) and S*(γ_n) := n − ½ − θ(γ_n)/π,

  F_n(γ_n) = S_P(γ_n) − S*(γ_n) =: D_n   (the truncated-Euler fluctuation deficit),

so γ_F(n) = γ_n exactly iff D_n = 0, and by the mean value theorem
|γ_F(n) − γ_n| = |D_n| / F_n′(ξ_n). **The entire gap between the prime-built
instrument and the zero-score is the truncated Euler sum** — the structural fact
the campaign rests on, now with both sides of the identity certified:

**(iv) [CERTIFIED] The deficit is small.** Subdivided arb ball enclosures over
every bracket (cells ≤ 2×10⁻⁴): **max_n |D_n| ≤ 0.411432** (n = 118), median
|D_n| ≈ 0.0921, mean D_n = +0.0004 (centered — no convention offset). For
comparison the a-priori, zero-free bound is |D_n| ≤ 15.9 + 0.90 ≈ **16.8**
(G-C2/PZ unconditional pointwise |S| ≤ 15.899 on [7,30], M-215 + the recorded
|S_P| ≤ 0.901946): the realized deficit is **41× below the logical envelope**.

**(v) [CERTIFIED] Transversality at the crossings.** F′(γ_F(n)) arb-certified
positive over every root ball, range **[2.2734, 10.5979]** across n = 1…153
(θ′ via arb digamma; S_P′ via the certified term sum; the global Lipschitz
constant sup|S_P′| ≤ 188.8038 was re-derived, independently reproducing the
recorded 188.804).

**(vi) [displayed] The first-order law closes.** pred(n) = |D_n| / F′(γ_F(n))
against the actual gap: **ratio median 1.000, quartiles [0.991, 1.013]**,
extremes [0.737, 1.136], 153/153 within a factor 2 (slack = the variation of F′
between γ_n and γ_F(n), bounded by (v) at the roots). The mechanism (iii)–(iv)
quantitatively accounts for the whole table (i).

**(vii) [MEASURED] Euler depth saturates (stage 2, light).** Rebuilt ladders at
P = 10⁶ and 10⁷ (float witness, monotone, seeded from the certified roots):
median gap 0.01631 → 0.01299 → 0.01203; **effective law gap ~ P^−0.078**;
55/152 rows get individually worse from 2×10⁵ → 10⁷. Deepening the Euler
product is NOT the lever at fixed range — independently consistent with the
anatomy-ladder saturation (CHI8_ANATOMY_LADDER_2026-07-26: the residual leak is
the phase/placement layer, not removable Euler depth). The finite-range theorem
is sharp as stated; the infinite-P convergence at the crossings is exactly the
wall and stays open by design.

## In one sentence

**The operator's spectrum data — conductor geometry plus primes to 2×10⁵ and
nothing else — provably sounds all 153 certified zeros of L(s, χ₈) on [0, 27.92],
each note assigned to its zero unambiguously (certified), to median precision
9.3 % and worst-case 35 % of a mean zero spacing (certified), the entire residual
being the truncated-Euler fluctuation deficit (exact identity), which is
certified ≤ 0.4114 against an unconditional a-priori envelope of 16.8.**

## Honest scope (the qualifiers travel with the grades)

1. **Indexing above #24**: bracket-to-index alignment rests on the production
   run's counting (completeness ball-certified only to T = 6.55 / first 24 —
   M-102/M-103 scope note). Statement (ii) certifies *internal* unambiguity of
   the assignment; if the truth list ever gained a missed zero above T = 6.55,
   indices would shift accordingly. The certified-completeness extension is the
   staged AWS step-4 run (ON HOLD per Selina).
2. **#144**: RESOLVED — ball-certified 2026-08-02 (bracket [26.454857, 26.457314],
   margins 6.6×/5.6×); the tables shipped here are the v3 re-run on the certified
   set: row 144 CERTIFIED, gap ∈ [0.0174, 0.0198]. No numerical-grade rows remain.
3. **Stage 2 grade**: float witness (no arb); certification of spot rows at
   P = 10⁶/10⁷ is a continuation item.
4. **(vi) is displayed**, not certified: the MVT point ξ_n is not localized;
   a certified two-sided version needs F′ enclosures on the whole gap interval
   (subdivision would do it; the swing of S_P′ makes it laborious, not deep).
5. **Nothing here approaches the wall**: the n → ∞ / P → ∞ statement
   (deficiency (0,0) ⟺ GRH(χ₈), R-209) is untouched; R-013's "no lever" stands —
   (vii) is fresh evidence FOR it at the practical level.

Not RH/GRH.
