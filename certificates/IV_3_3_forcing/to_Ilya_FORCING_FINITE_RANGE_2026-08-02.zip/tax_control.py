r"""
FORCING campaign 2026-08-02 — TAX CONTROL: amplitude or correlation?

The naive squeezed-pair mechanism is REFUTED (tax_derivation.py): no adjacent
pair anywhere has gap ratio < 0.5 (min 0.571), and the "+7" is a NET imbalance
of a ~30-each-way exchange zone at the resolution boundary, not 7 broken pairs.

This control asks what the net imbalance is a function of.  Build SYNTHETIC
strings: D-gaps modulated by a random PERMUTATION of the actual F/D gap-ratio
sequence — same modulation distribution (rms 22.6%), correlation structure
destroyed.  Measure each synthetic string's net tax vs D at (M=600, k=500/550).

  - synthetic net ≈ F's net (+6..+7)  => the tax is an AMPLITUDE (disorder)
    penalty, derivable from the fluctuation distribution alone; arithmetic-blind.
  - synthetic net systematically different => the S_P CORRELATION structure
    (the coherent oscillation layer) is load-bearing in the placement tax.

Grade: MEASURED.  Not RH/GRH.
"""
import json, time
import numpy as np
from flint import arb, ctx

HERE = r"C:\Users\selin\OneDrive\Desktop\Ilya Riemanns\.claude\worktrees\suspicious-lumiere-dbbf9e\FORCING_EXECUTION_2026-08-02"
ROWS = json.load(open(HERE + r"\quantiles_certified_600.json"))["rows"]
M = 600
PREC = 14000
KS = (500, 550)
SEEDS = (1, 2, 3, 4)

gF = np.array([float(arb(r["gF_mid"])) for r in ROWS])[:M]
gD = np.array([float(arb(r["gD_mid"])) for r in ROWS])[:M]
gapD = np.diff(gD)
ratio = np.diff(gF) / gapD

def jacobi_arb(atoms):
    m = len(atoms)
    v = [arb(m).rsqrt()] * m
    a = []; b = []
    w = [atoms[i] * v[i] for i in range(m)]
    a0 = sum((v[i] * w[i] for i in range(m)), arb(0)); a.append(a0)
    w = [w[i] - a0 * v[i] for i in range(m)]
    vprev = v
    for j in range(1, m):
        be = sum((x * x for x in w), arb(0)).sqrt()
        b.append(be)
        vn = [w[i] / be for i in range(m)]
        w = [atoms[i] * vn[i] - be * vprev[i] for i in range(m)]
        al = sum((vn[i] * w[i] for i in range(m)), arb(0)); a.append(al)
        w = [w[i] - al * vn[i] for i in range(m)]
        vprev = vn
    return a, b

def build(g):
    ctx.prec = PREC
    atoms = [arb(1) / arb(f"{v:.17e}") ** 2 for v in g]
    a, b = jacobi_arb(atoms)
    diff = float(abs(sum(a, arb(0)) - sum(atoms, arb(0))).upper())
    assert diff < 1e-40, "trace gate"
    return (np.array([float(v) for v in a]), np.array([float(v) for v in b]),
            np.array([float(v) for v in atoms]))

def eig_section(a, b, k):
    return np.linalg.eigvalsh(np.diag(a[:k]) + np.diag(b[:k - 1], 1) + np.diag(b[:k - 1], -1))

def missed_count(a, b, x, k):
    xs = np.sort(x)
    gaps = np.diff(xs); locgap = np.empty(M)
    locgap[1:-1] = np.minimum(gaps[:-1], gaps[1:]); locgap[0] = gaps[0]; locgap[-1] = gaps[-1]
    lam = eig_section(a, b, k)
    d = np.abs(xs[:, None] - lam[None, :]).min(axis=1)
    return int((d > 0.5 * locgap).sum())

print("building D and F reference strings ...", flush=True)
t0 = time.time()
SD = build(gD); SF = build(gF)
print(f"  ({time.time()-t0:.0f}s)")
base = {k: missed_count(*SD, k) for k in KS}
fmiss = {k: missed_count(*SF, k) for k in KS}
for k in KS:
    print(f"  k={k}: D missed {base[k]}   F missed {fmiss[k]}   F net tax {fmiss[k]-base[k]:+d}")

print("\nsynthetic permuted-modulation strings:")
for seed in SEEDS:
    rng = np.random.default_rng(seed)
    rp = ratio[rng.permutation(len(ratio))]
    gaps_syn = gapD * rp
    gaps_syn *= gapD.sum() / gaps_syn.sum()          # preserve total span
    g_syn = np.concatenate([[gF[0]], gF[0] + np.cumsum(gaps_syn)])
    Ssyn = build(g_syn)
    nets = []
    for k in KS:
        msyn = missed_count(*Ssyn, k)
        nets.append(msyn - base[k])
        print(f"  seed {seed} k={k}: synthetic missed {msyn}   net vs D {msyn-base[k]:+d}"
              f"   (F reference {fmiss[k]-base[k]:+d})")
print("\nverdict criteria: synthetic nets clustering at the F values (+6..+9) => amplitude-only;")
print("systematically above/below => correlation structure load-bearing.")
print("Not RH/GRH.")
