r"""
FORCING campaign 2026-08-02 — M-SCALING prerequisite: extend the certified
quantile ladders (gamma_D, gamma_F) from n = 300 to n = 600.

Same construction and certification standard as M-233 step 1
(klmn_arb_quantiles.py): frozen theta (Q = 21^10) + S_P (P = 2e5, 18,120 terms);
mpmath witness root (bisection + secant polish, extrapolated seeds, monotone +
spacing guards); arb IVT sign-check certification of EVERY root (prec 200).
Rows 1..300 are recomputed and validated against the existing certified JSON
(agreement gate <= 1e-11) — a full independent re-derivation, not a copy.

Output: quantiles_certified_600.json (same schema, nmax = 600).
Not RH/GRH.
"""
import sys, json, time
import numpy as np, mpmath as mp
from flint import arb, acb, ctx

MAIN = r"C:\Users\selin\OneDrive\Desktop\Ilya Riemanns"
HERE = r"C:\Users\selin\OneDrive\Desktop\Ilya Riemanns\.claude\worktrees\suspicious-lumiere-dbbf9e\FORCING_EXECUTION_2026-08-02"
sys.path.insert(0, MAIN + r"\Operator_program_addendum")
from gen_an_chi8 import LOC8, frob_class

NMAX = 600
mp.mp.dps = 45
ctx.prec = 200
MU = [0, 0, 0, 0, 1, 1, 1, 1]
LOGQ = mp.log(mp.mpf(21) ** 10)
PI = mp.pi

def theta_mp(t):
    v = (t / 2) * LOGQ
    for m_ in MU:
        v += -(t / 2) * mp.log(mp.pi)
        v += mp.im(mp.loggamma(mp.mpf(1 + 2 * m_) / 4 + 1j * t / 2))
    return v

def newton_ps(loc, kmax):
    deg = len(loc) - 1
    e = [((-1) ** i) * loc[i] for i in range(len(loc))]
    p = [0] * (kmax + 1)
    for k in range(1, kmax + 1):
        s = ((-1) ** (k - 1)) * k * e[k] if k <= deg else 0
        for i in range(1, min(k - 1, deg) + 1):
            s += ((-1) ** (i - 1)) * e[i] * p[k - i]
        p[k] = s
    return p[1:]

print("building S_P (P=2e5)...", flush=True)
P_MAX = 200000
isp = np.ones(P_MAX + 1, bool); isp[:2] = False
for q in range(2, int(P_MAX ** .5) + 1):
    if isp[q]: isp[q * q::q] = False
TERMS = []
for p in np.nonzero(isp)[0]:
    p = int(p); kmax = 1
    while p ** (kmax + 1) <= P_MAX: kmax += 1
    tr = newton_ps(LOC8[frob_class(p)], kmax)
    for k in range(1, kmax + 1):
        TERMS.append((int(tr[k - 1]), k, p))
assert len(TERMS) == 18120
_co_np = np.array([float(mp.mpf(tr) / k * mp.mpf(p) ** (mp.mpf(-k) / 2)) for (tr, k, p) in TERMS])
_lg_np = np.array([float(k * mp.log(p)) for (tr, k, p) in TERMS])
def SP_wit(t):
    return float(-(1.0 / np.pi) * np.sum(_co_np * np.sin(float(t) * _lg_np)))

def f_wit(t, n, fwd):
    v = float(theta_mp(mp.mpf(t))) / float(PI) - (n - 0.5)
    if fwd: v += SP_wit(t)
    return v

# ---------------- witness ladders (bisection + guards) ----------------
def solve_ladder(fwd, label):
    roots = []
    t0 = time.time()
    for n in range(1, NMAX + 1):
        if n == 1: g0 = 0.99
        elif n == 2: g0 = roots[0] + 0.28
        else: g0 = 2 * roots[-1] - roots[-2]          # linear extrapolation
        h = 0.06
        a, b = g0 - h, g0 + h
        fa, fb = f_wit(a, n, fwd), f_wit(b, n, fwd)
        tries = 0
        while fa > 0 or fb < 0:
            h *= 1.7; a, b = g0 - h, g0 + h
            fa, fb = f_wit(a, n, fwd), f_wit(b, n, fwd)
            tries += 1
            if tries > 12: raise SystemExit(f"no bracket n={n} {label}")
        for _ in range(52):
            mmid = 0.5 * (a + b); fm = f_wit(mmid, n, fwd)
            if fm < 0: a = mmid
            else: b = mmid
            if b - a < 1e-13: break
        g = 0.5 * (a + b)
        if roots and g <= roots[-1]:
            raise SystemExit(f"monotonicity violated at n={n} {label}")
        roots.append(g)
        if n % 100 == 0:
            print(f"  [{label}] n={n} gamma={g:.4f}  ({time.time()-t0:.0f}s)", flush=True)
    return roots

print("solving witness ladders to n=600...", flush=True)
gD = solve_ladder(False, "D")
gF = solve_ladder(True, "F")

# spacing sanity: no gap more than 3x local median
for lab, g in (("D", gD), ("F", gF)):
    sp = np.diff(g)
    med = np.median(sp)
    assert sp.max() < 5 * med and sp.min() > 0, f"spacing anomaly {lab}"
    print(f"  [{lab}] spacing: min {sp.min():.4f} med {med:.4f} max {sp.max():.4f}")

# ---------------- validate n<=300 against the existing certified JSON ----------------
OLD = json.load(open(MAIN + r"\WALL_KLMN_ARB_CERT_2026-07-31\quantiles_certified.json"))["rows"]
dD = max(abs(gD[r["n"] - 1] - float(mp.mpf(r["gD_mid"]))) for r in OLD)
dF = max(abs(gF[r["n"] - 1] - float(mp.mpf(r["gF_mid"]))) for r in OLD)
print(f"validation vs certified n<=300: max|dgD|={dD:.2e}  max|dgF|={dF:.2e}")
assert dD < 1e-11 and dF < 1e-11, "disagreement with certified rows"

# ---------------- arb IVT certification (all 600 x 2) ----------------
ARB_PI = arb.pi()
ARB_LOGPI = ARB_PI.log()
ARB_LOGQ = (arb(21) ** 10).log()
def theta_arb(t):
    v_im = (t / 2) * ARB_LOGQ
    for m_ in MU:
        v_im += -(t / 2) * ARB_LOGPI
        z = acb(arb(1 + 2 * m_) / 4, t / 2)
        v_im += z.lgamma().imag
    return v_im
_co_arb = [arb(tr) / arb(k) / (arb(p) ** k).sqrt() for (tr, k, p) in TERMS]
_lg_arb = [arb(k) * arb(p).log() for (tr, k, p) in TERMS]
def SP_arb(t):
    acc = arb(0)
    for c, l in zip(_co_arb, _lg_arb):
        acc += c * (t * l).sin()
    return -(arb(1) / ARB_PI) * acc
def f_arb(g, n, fwd):
    val = theta_arb(g) / ARB_PI - arb(2 * n - 1) / 2
    if fwd: val += SP_arb(g)
    return val

def certify(g0, n, fwd):
    g0 = mp.mpf(g0)
    for rexp in range(11, 4, -1):
        r = mp.mpf(10) ** (-rexp) * (abs(g0) + 1)
        flo = f_arb(arb(mp.nstr(g0 - r, 42)), n, fwd)
        fhi = f_arb(arb(mp.nstr(g0 + r, 42)), n, fwd)
        if flo.upper() < 0 and fhi.lower() > 0:
            return mp.nstr(g0, 42), float(r)
    raise SystemExit(f"IVT undecided n={n} fwd={fwd}")

print("arb-IVT certifying 600 x 2 roots...", flush=True)
t0 = time.time()
out = []
maxrel = 0.0
for n in range(1, NMAX + 1):
    mD, rD = certify(gD[n - 1], n, False)
    mF, rF = certify(gF[n - 1], n, True)
    out.append({"n": n, "gD_mid": mD, "gD_rad": rD, "gF_mid": mF, "gF_rad": rF})
    maxrel = max(maxrel, rD / gD[n - 1], rF / gF[n - 1])
    if n % 100 == 0:
        print(f"  n={n} certified ({time.time()-t0:.0f}s)", flush=True)
print(f"ALL {NMAX} x 2 roots certified; max relative radius = {maxrel:.2e}")

outp = HERE + r"\quantiles_certified_600.json"
json.dump({"nmax": NMAX, "prec_bits": 200, "validate_vs_300_dgD": dD, "validate_vs_300_dgF": dF,
           "max_rel_radius": maxrel, "rows": out}, open(outp, "w"))
print(f"wrote {outp}")
print(f"range: gamma_D(600) = {gD[-1]:.4f}, gamma_F(600) = {gF[-1]:.4f}")
print("Not RH/GRH.")
