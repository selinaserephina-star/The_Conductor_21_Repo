# Upgrade note — this package is the 153/153 state

The execution session sealed against the 07-19 bracket set (152 certified,
#144 numerical). Before sending, the tables were re-run on the v3 bracket set =
the frozen 07-19 CSV + the ball-certified #144 of `to_Ilya_BRACKET144_CERT_2026-08-02`
(bracket [26.454857, 26.457314], margins 6.63x/5.64x, same frozen chain; the frozen
07-19 package itself is untouched; `certified_run_brackets_v3_153.csv` enclosed).
All headline constants are stable: max gap 0.061263 (n = 147), median 0.016535,
assignment unambiguous x153 (worst ratio 0.551 at n = 126), max |D_n| <= 0.411432,
F' in [2.2734, 10.5979], first-order-law ratio median 1.000. Row 144 is now
CERTIFIED with gap in [0.017389, 0.019846]. The re-run lives in
`FORCING_INTEGRATION_2026-08-02/` (main tree); scripts here are the repointed
copies. The release paper states this theorem as SIV.3.3 at exactly these numbers.
Not RH/GRH.
