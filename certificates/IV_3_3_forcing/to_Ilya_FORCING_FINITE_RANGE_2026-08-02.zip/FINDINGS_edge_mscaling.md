# FINDINGS — THE M-SCALING RUN: the edge laws separated from the endpoint (M = 300/450/600)

**Merkabit · Stenberg + Claude · 2026-08-02 (third act of the session). Scripts:
`extend_quantiles_600.py` (ladder extension n → 600, BOTH ladders arb-IVT-certified,
1200/1200 roots, max rel radius 2.6e-11, range to γ ≈ 86.72; rows ≤ 300 re-derived
independently and validated vs the M-233 set to 5e-14) and `edge_mscaling.py` + logs.
Strings J(M), M = 300/450/600 × {D, F}, arb Lanczos with M-SCALED precision
(6000/9000/14000 bits — NEW TRAP RECORDED: prec 6000, the M-233 m=300 tuning, blows
up (radii → ∞) at M = 600; the recursion's precision demand grows with depth; the
trace-identity gate caught it exactly as designed). All six strings: coefficient
radii 0.0, trace identity exact. Grade: MEASURED. Not RH/GRH.**

## The four questions, answered

**(Q1) The taper: the "decoupling" was mostly the endpoint — CORRECTION to the
M=300 addendum.** On the fixed bulk window [60, 250], the diagonal slope is stable
(a: −1.53/−1.57/−1.59 across M — the DOS law, intrinsic), but the coupling slope
RELAXES as the endpoint recedes: b: −2.07 → −1.79 → −1.71. The dramatic b-steepening
read at M = 300 was largely the endpoint zone, not the bulk law. What IS intrinsic:
(i) a small residual excess of the coupling decay over the diagonal (−1.71 vs −1.59
at M = 600, still relaxing — the infinite-string bulk values are not yet separable);
(ii) a sharp endpoint zone whose fixed-width-window slope STEEPENS with M
(b on [M−100, M−10]: −4.3 → −5.9 → −7.7) — the string's end is a real, sharpening
boundary layer. The previous addendum's "string decouples descending to the edge"
is hereby corrected to: **the string's bulk taper is DOS-like in both coefficients;
the decoupling is the endpoint boundary layer.**

**(Q2) The trace ledger: mass conservation down the string; the N⁻³ proximity was
the endpoint, confirmed and dismissed.** At fixed k, T_M(k) grows with M by
1.10–1.13× exactly the added atom mass (added Σx: 0.0452 (301–450), 0.0253
(451–600); measured increments at k = 100: 0.0512, 0.0277) — **new edge atoms pass
essentially their full trace mass down past any fixed depth**; nothing is absorbed
mid-string. The steep tail exponent slides with the endpoint (−2.77 → −2.54 → −2.43
on [100, M−25]) while the endpoint-free window [100, 400] at M = 600 reads −1.38 —
the intrinsic trace-tail follows the (log-corrected) atom-tail/DOS law. **The
M = 300 near-coincidence with M-210's ‖τ_ODD‖ ~ N⁻³ was the endpoint constraint,
now measured and dismissed** (the no-forced-fit discipline paid out).

**(Q3) The counting law and the prime tax are ROBUST.** The geometry string is
rank-perfect to ±2 at every (M, k) tested (missed = M − k exactly in 11 of 15
cells, off by 1–2 in four cells deep in the cluster, within the matching metric's
resolution). The prime placement tax stays a k- and M-independent constant:
+2…+12, mean ≈ +7, no trend from M = 300 to 600. **The edge drop is perfect
counting; the primes pay a small constant placement tax; neither changes with
depth.**

**(Q4) The transit shape: NOT the Airy soft edge — a different morphology, with a
different scaling variable.** The displacement profile collapses in the FILL
FRACTION k/M, not in the endpoint distance M − k: at fixed M − k = 100 the first-12
profile goes from visibly in-transit (M = 300, k/M = 0.67) to fully locked
(M = 450/600, k/M ≥ 0.78); at fixed k = 250 it degrades monotonically as M grows
(k/M: 0.83 locked → 0.56 partial → 0.42 unresolved). And the deficiency zone is an
**interior annulus of the edge cluster** — the extreme tip (smallest atom) locks
FIRST at every (M, k) (transit-boundary index 0 throughout), with the displacement
rising behind it and falling into the bulk. That is Krylov/extreme-first
morphology, not the Airy soft-edge picture (where the extreme edge is the least
resolved). **Verdict: M-216's Airy transit does NOT transfer to the genome
nested-section edge — the two live in different universality classes** (M-216's is
the companion/Bessel section in its own variable; the genome string's edge deficit
is a fill-fraction annulus). Honest negative, full value: the staged "compare
against the Airy transit" comparison is now ANSWERED (no), not skipped.

## Consolidated picture (three sessions of instruments, one story)

What is missing at the edge, at every depth measured: **never mass, always
placement** — (a) the trace ledger conserves and passes all mass down; (b) the
section resolves the maximum possible number of notes (rank-perfect counting);
(c) the deficit is WHERE inside the cluster the unresolved notes sit (a k/M
annulus), plus a constant ~7-note prime placement tax; (d) the forcing gap on the
resolved notes is entirely the fluctuation deficit |S_P − S| (the certified
theorem); (e) neither Euler depth (P-scaling) nor section depth (M-scaling) shrinks
the placement layer. The placement/phase layer is the single residual in every
coordinate system tried — which is the practical face of R-013/R-209: that layer
IS the wall's data.

## Traps recorded this run

1. Lanczos precision demand grows with M: prec 6000 (fine at m = 300, radii 0.0)
   → radii ∞ at M = 600; scaled 6000/9000/14000 restores radii 0.0. Gate on the
   trace identity ALWAYS.
2. (Recorded in the prior addendum, reinforced): float64 nested-section Lanczos is
   invalid at these depths — ghost duplication, caught by the same gate.

## Files

`extend_quantiles_600.py` + run log + `quantiles_certified_600.json` (1200
certified roots — reusable: doubles the certified atom range for ANY future
instrument); `edge_mscaling.py` + run log. Continuation candidates (not staged as
debts): a finer k/M grid to pin the annulus onset curve; the same instrument on
the twin (χ₋₇) atoms for a fourth blindness cross-check.

Not RH/GRH — the section edge is now mapped at three depths; the n → ∞ statement
(R-209) stays the wall.
