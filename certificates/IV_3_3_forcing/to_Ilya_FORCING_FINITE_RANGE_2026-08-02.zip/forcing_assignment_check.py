r"""
FORCING campaign 2026-08-02 — the unambiguous-assignment check (certified).
For each n: certified UPPER gap to own zero vs certified LOWER distance to the
neighboring zeros' brackets, in exact rational interval arithmetic.
Assignment unambiguous iff gap_hi(n) < dist_lo(gammaF(n), bracket n-1 and n+1).
Result (run log forcing_assignment_check.log): 0 ambiguous rows / 153;
worst margin n=126, own gap_hi 0.052166 vs neighbor dist_lo 0.094646 (ratio 0.551).
Not RH/GRH.
"""
import csv, json
from fractions import Fraction as F
MAIN = r"C:\Users\selin\OneDrive\Desktop\Ilya Riemanns"
QC = json.load(open(MAIN + r"\WALL_KLMN_ARB_CERT_2026-07-31\quantiles_certified.json"))
rows_F = {r["n"]: r for r in QC["rows"]}
br = []
for r in csv.DictReader(open(MAIN + r"\to_Ilya_CERTIFIED_spectrum_2026-07-19\results\certified_run_brackets.csv")):
    br.append((int(r["j"]), F(r["lo"]), F(r["hi"]), r["certified"] == "True"))
def fball(n):
    r = rows_F[n]; m = F(r["gF_mid"]); rad = F(repr(r["gF_rad"])) * F(1000000000001, 1000000000000) + F(1, 10**30)
    return m - rad, m + rad
def dlo(flo, fhi, blo, bhi):
    return max(F(0), blo - fhi, flo - bhi)
def dhi(flo, fhi, blo, bhi):
    return max(bhi - flo, fhi - blo)
amb = []
worst_margin = None
for i, (j, blo, bhi, cert) in enumerate(br):
    flo, fhi = fball(j)
    own_hi = dhi(flo, fhi, blo, bhi)
    margins = [dlo(flo, fhi, br[k][1], br[k][2]) for k in (i - 1, i + 1) if 0 <= k < len(br)]
    m = min(margins)
    ratio = float(own_hi / m) if m > 0 else float('inf')
    if worst_margin is None or ratio > worst_margin[1]:
        worst_margin = (j, ratio, float(own_hi), float(m))
    if not (own_hi < m):
        amb.append((j, float(own_hi), float(m)))
print(f"rows checked: {len(br)}")
print(f"ambiguous rows: {len(amb)}  {amb if amb else ''}")
j, rr, oh, mm = worst_margin
print(f"worst margin: n={j}  own gap_hi={oh:.6f}  vs neighbor dist_lo={mm:.6f}  (ratio {rr:.3f})")
print("UNAMBIGUOUS ASSIGNMENT CERTIFIED for all rows" if not amb else "ambiguity present")
