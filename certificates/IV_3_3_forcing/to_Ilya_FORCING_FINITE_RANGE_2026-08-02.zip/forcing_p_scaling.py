r"""
FORCING campaign, EXECUTION session 2026-08-02 — STAGE 2 (light, MEASURED):
P-SCALING of the forcing gap.  Rebuild the F-ladder at P = 1e6 and 1e7
(float witness grade; the P = 2e5 ladder is the certified reference) and
measure gap(P) = |gamma_F(P, n) - gamma_true(n)| per zero.

Question: does deepening the Euler product shrink the forcing gap at the
|S_P - S|-predicted rate?  A measured convergence LAW turns agreement into
mechanism.  (The infinite-P limit is the wall and is NOT claimed.)

Method: sieve to P; trace coefficients from LOC8[frob_class(p)] Newton power
sums; S_P via numpy; roots of theta/pi + S_P = n - 1/2 by guarded bisection
seeded at the certified P=2e5 root (bracket +-0.12, expanded on demand);
theta via mpmath (dps 30) at each bisection point, cached on a fine local
Chebyshev-free grid — instead we simply evaluate theta directly (fast enough).
Grade: MEASURED (float64 witness; arb spot-certification = continuation item).
Not RH/GRH.
"""
import sys, csv, json, time, statistics
import numpy as np, mpmath as mp

MAIN = r"C:\Users\selin\OneDrive\Desktop\Ilya Riemanns"
HERE = r"C:\Users\selin\OneDrive\Desktop\Ilya Riemanns\.claude\worktrees\suspicious-lumiere-dbbf9e\FORCING_EXECUTION_2026-08-02"
sys.path.insert(0, MAIN + r"\Operator_program_addendum")
from gen_an_chi8 import LOC8, frob_class

mp.mp.dps = 30
MU = [0, 0, 0, 0, 1, 1, 1, 1]
LOGQ = mp.log(mp.mpf(21) ** 10)
PI = mp.pi

def theta_f(t):
    t = mp.mpf(t)
    v = (t / 2) * LOGQ
    for m_ in MU:
        v += -(t / 2) * mp.log(mp.pi)
        v += mp.im(mp.loggamma(mp.mpf(1 + 2 * m_) / 4 + 1j * t / 2))
    return float(v)

def newton_ps(loc, kmax):
    deg = len(loc) - 1
    e = [((-1) ** i) * loc[i] for i in range(len(loc))]
    p = [0] * (kmax + 1)
    for k in range(1, kmax + 1):
        s = ((-1) ** (k - 1)) * k * e[k] if k <= deg else 0
        for i in range(1, min(k - 1, deg) + 1):
            s += ((-1) ** (i - 1)) * e[i] * p[k - i]
        p[k] = s
    return p[1:]

def build_terms(P_MAX):
    isp = np.ones(P_MAX + 1, bool); isp[:2] = False
    for q in range(2, int(P_MAX ** .5) + 1):
        if isp[q]: isp[q * q::q] = False
    primes = np.nonzero(isp)[0]
    co, lg = [], []
    for p in primes:
        p = int(p); kmax = 1
        while p ** (kmax + 1) <= P_MAX: kmax += 1
        tr = newton_ps(LOC8[frob_class(p)], kmax)
        for k in range(1, kmax + 1):
            co.append(tr[k - 1] / k * p ** (-k / 2))
            lg.append(k * np.log(p))
    return np.array(co), np.array(lg)

# certified P=2e5 F-roots (seeds) and truth brackets
with open(MAIN + r"\WALL_KLMN_ARB_CERT_2026-07-31\quantiles_certified.json") as f:
    rows_F = {r["n"]: float(mp.mpf(r["gF_mid"])) for r in json.load(f)["rows"]}
br = []
with open(MAIN + r"\to_Ilya_CERTIFIED_spectrum_2026-07-19\results\certified_run_brackets.csv") as f:
    for r in csv.DictReader(f):
        br.append((int(r["j"]), (float(r["lo"]) + float(r["hi"])) / 2, r["certified"] == "True"))

def ladder(P_MAX, label):
    t0 = time.time()
    co, lg = build_terms(P_MAX)
    print(f"[{label}] {len(co)} prime-power terms ({time.time()-t0:.1f}s)", flush=True)
    def SP(t): return float(-(1.0 / np.pi) * np.dot(co, np.sin(t * lg)))
    def f(t, n): return theta_f(t) / np.pi + SP(t) - (n - 0.5)
    roots = {}
    t0 = time.time()
    for n in range(1, 154):
        seed = rows_F[n]
        a, b = seed - 0.12, seed + 0.12
        fa, fb = f(a, n), f(b, n)
        w = 0.12
        while fa > 0 or fb < 0:      # expand until sign change (f increasing globally in trend)
            w *= 1.6; a, b = seed - w, seed + w; fa, fb = f(a, n), f(b, n)
            if w > 1.5: raise SystemExit(f"no bracket at n={n} P={P_MAX}")
        for _ in range(60):
            m = 0.5 * (a + b); fm = f(m, n)
            if fm < 0: a = m
            else: b = m
            if b - a < 1e-11: break
        roots[n] = 0.5 * (a + b)
    print(f"[{label}] 153 roots ({time.time()-t0:.1f}s)", flush=True)
    mono = all(roots[n + 1] > roots[n] for n in range(1, 153))
    print(f"[{label}] ladder monotone: {mono}")
    return roots

print("building ladders...", flush=True)
R = {"2e5": {n: rows_F[n] for n in range(1, 154)}}
R["1e6"] = ladder(1000000, "P=1e6")
R["1e7"] = ladder(10000000, "P=1e7")

# gaps vs truth (bracket mids; float witness grade)
print("\n=== gap(P) per zero (float witness; certified reference = P=2e5 stage-1 table) ===")
stats = {}
rows_csv = []
for key in ("2e5", "1e6", "1e7"):
    gaps = []
    for (j, bmid, cert) in br:
        g = abs(R[key][j] - bmid)
        gaps.append((j, g, cert))
    cg = [g for (_, g, c) in gaps if c]
    stats[key] = cg
    print(f"  P={key:>4}: median {statistics.median(cg):.5f}   mean {statistics.mean(cg):.5f}   "
          f"max {max(cg):.5f}   (152 certified rows)")
for (j, bmid, cert) in br:
    rows_csv.append([j, f"{abs(R['2e5'][j]-bmid):.6f}", f"{abs(R['1e6'][j]-bmid):.6f}",
                     f"{abs(R['1e7'][j]-bmid):.6f}", "CERTIFIED_REF" if cert else "NUMERICAL(#144)"])

m5, m6, m7 = (statistics.median(stats[k]) for k in ("2e5", "1e6", "1e7"))
print(f"\n  shrink factors (medians): 2e5->1e6: x{m5/m6:.2f}   1e6->1e7: x{m6/m7:.2f}   2e5->1e7: x{m5/m7:.2f}")
import math
if m5 > m7 > 0:
    alpha = math.log(m5 / m7) / math.log(10000000 / 200000)
    print(f"  effective power law (median): gap ~ P^(-{alpha:.3f})")
per_zero_improve = [abs(R['2e5'][j]-bmid) / max(abs(R['1e7'][j]-bmid), 1e-9) for (j, bmid, c) in br if c]
print(f"  per-zero improvement 2e5->1e7: median x{statistics.median(per_zero_improve):.2f}, "
      f"worse-than-1 rows: {sum(1 for r in per_zero_improve if r < 1)}/152")

csvp = HERE + r"\forcing_p_scaling.csv"
with open(csvp, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["n", "gap_P2e5", "gap_P1e6", "gap_P1e7", "grade"])
    w.writerows(rows_csv)
print(f"wrote {csvp}")
print("\nStage 2 (light) complete — MEASURED grade. Not RH/GRH.")
