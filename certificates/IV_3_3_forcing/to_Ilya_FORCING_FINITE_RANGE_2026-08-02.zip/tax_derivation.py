r"""
FORCING campaign 2026-08-02 — DERIVING THE ~7 PRIME PLACEMENT TAX.

Hypothesis (mechanical): the k-section eigenvalues are the k-point GAUSS
QUADRATURE NODES of the M-atom measure; quadrature merges near-degenerate
atoms longest.  The prime fluctuation S_P displaces neighboring atoms
differentially, SQUEEZING some adjacent gaps; pairs squeezed below the
splitting resolution get one node instead of two -> exactly the extra misses
the F-string shows over the D-string.  Prediction:

    tax(M, k)  ~=  #{ adjacent pairs (n, n+1) with squeeze ratio
                      r_n = gap_F(n) / gap_D(n) below a threshold c*,
                      lying inside the section's RESOLVED zone }

with ONE global c* (not tuned per cell).  If the tax atoms coincide with the
squeezed pairs across all (M, k) cells, the constant ~7 is DERIVED from the
fluctuation statistics, not observed.

Also measured here:
  (i)  the squeeze-ratio distribution: rms modulation, tail shape — is the
       ~7-count a heavy tail (mechanical near-degeneracies) or the tail of a
       ~7%-Gaussian (which would give ZERO such pairs)?  This settles the
       "same 7 as the genome-oscillation 7% δA/δB layer?" question honestly.
  (ii) metric control: misses recomputed with the D-string's local gap as the
       resolution scale for BOTH strings — does the tax survive a common
       measuring stick (genuine merging) or vanish (definitional artifact)?

Inputs: quantiles_certified_600.json (1200 certified roots).  Strings via arb
Lanczos (M-scaled precision, trace gate).  Grade: MEASURED + derivation.
Not RH/GRH.
"""
import json, math, time
import numpy as np
from flint import arb, ctx

HERE = r"C:\Users\selin\OneDrive\Desktop\Ilya Riemanns\.claude\worktrees\suspicious-lumiere-dbbf9e\FORCING_EXECUTION_2026-08-02"
ROWS = json.load(open(HERE + r"\quantiles_certified_600.json"))["rows"]
PREC_BY_M = {300: 6000, 450: 9000, 600: 14000}

gF = np.array([float(arb(r["gF_mid"])) for r in ROWS])
gD = np.array([float(arb(r["gD_mid"])) for r in ROWS])

# ---------------- squeeze statistics (pure atom-set property) ----------------
print("=== squeeze-ratio statistics (gamma-space adjacent gaps, n = 1..599) ===")
gapF = np.diff(gF); gapD = np.diff(gD)
r = gapF / gapD
print(f"  rms(r - 1)      = {np.sqrt(np.mean((r - 1) ** 2)):.4f}")
print(f"  min r           = {r.min():.4f}  at pair n = {int(np.argmin(r)) + 1}")
print(f"  excess kurtosis = {float(((r - r.mean()) ** 4).mean() / ((r - r.mean()) ** 2).mean() ** 2 - 3):.2f}")
for c in (0.4, 0.5, 0.6, 0.7):
    idx = np.nonzero(r < c)[0] + 1
    print(f"  #pairs r < {c}: {len(idx):3d}   at n = {list(idx[:20])}{' ...' if len(idx) > 20 else ''}")
sig = np.sqrt(np.mean((r - 1) ** 2))
from math import erf
p_gauss = 0.5 * (1 + erf((0.5 - 1) / (sig * math.sqrt(2))))
print(f"  Gaussian(σ={sig:.3f}) would give #(r<0.5) ≈ {599 * p_gauss:.2e}  "
      f"-> the r<0.5 pairs are a HEAVY TAIL, not the σ-level layer" if 599 * p_gauss < 0.5 else "")
# windows: are squeezed pairs stationary in n?
for (a, b) in ((1, 150), (151, 300), (301, 450), (451, 599)):
    cnt = int(((r[a - 1:b] < 0.5)).sum())
    print(f"  window n in [{a},{b}]: #(r<0.5) = {cnt}")

# ---------------- strings + missed sets ----------------
def jacobi_arb(atoms):
    m = len(atoms)
    v = [arb(m).rsqrt()] * m
    a = []; b = []
    w = [atoms[i] * v[i] for i in range(m)]
    a0 = sum((v[i] * w[i] for i in range(m)), arb(0)); a.append(a0)
    w = [w[i] - a0 * v[i] for i in range(m)]
    vprev = v
    for j in range(1, m):
        be = sum((x * x for x in w), arb(0)).sqrt()
        b.append(be)
        vn = [w[i] / be for i in range(m)]
        w = [atoms[i] * vn[i] - be * vprev[i] for i in range(m)]
        al = sum((vn[i] * w[i] for i in range(m)), arb(0)); a.append(al)
        w = [w[i] - al * vn[i] for i in range(m)]
        vprev = vn
    return a, b

def build(g, M):
    ctx.prec = PREC_BY_M[M]
    atoms = [arb(1) / arb(f"{v:.17e}") ** 2 for v in g[:M]]  # float mids, exact-decimal cast
    a, b = jacobi_arb(atoms)
    diff = float(abs(sum(a, arb(0)) - sum(atoms, arb(0))).upper())
    assert diff < 1e-40, "trace gate"
    return (np.array([float(v) for v in a]), np.array([float(v) for v in b]),
            np.array([float(v) for v in atoms]))

def eig_section(a, b, k):
    return np.linalg.eigvalsh(np.diag(a[:k]) + np.diag(b[:k - 1], 1) + np.diag(b[:k - 1], -1))

def missed_ns(a, b, x, k, scale_gaps=None):
    """return set of atom labels n (1-based) missed by the k-section.
    scale_gaps: optional common resolution scale per sorted index (else own local gap)."""
    M = len(x)
    xs = np.sort(x)
    gaps = np.diff(xs); locgap = np.empty(M)
    locgap[1:-1] = np.minimum(gaps[:-1], gaps[1:]); locgap[0] = gaps[0]; locgap[-1] = gaps[-1]
    scale = locgap if scale_gaps is None else scale_gaps
    lam = eig_section(a, b, k)
    d = np.abs(xs[:, None] - lam[None, :]).min(axis=1)
    miss_sorted = np.nonzero(d > 0.5 * scale)[0]
    return set(int(M - i) for i in miss_sorted)      # sorted index i <-> n = M - i

print("\nbuilding strings (trace gate each) ...", flush=True)
t0 = time.time()
S = {}
for M in (300, 600):
    S[("F", M)] = build(gF, M)
    S[("D", M)] = build(gD, M)
print(f"  ({time.time()-t0:.0f}s)")

# common measuring stick: D-string local gaps (by sorted index) for the control
def d_scale(M):
    xD = np.sort(S[("D", M)][2])
    gaps = np.diff(xD); loc = np.empty(M)
    loc[1:-1] = np.minimum(gaps[:-1], gaps[1:]); loc[0] = gaps[0]; loc[-1] = gaps[-1]
    return loc

# ---------------- the tax, localized and predicted ----------------
print("\n=== tax localization + prediction per (M, k) cell ===")
CSTAR = 0.5                      # one global threshold, set ONCE from the merge criterion
sq_pairs = np.nonzero(r < CSTAR)[0] + 1          # pair label n (members n, n+1)
sq_members = sorted(set(list(sq_pairs) + list(sq_pairs + 1)))
print(f"  global squeezed-pair set (r < {CSTAR}): pairs at n = {list(sq_pairs)}")
print(f"  (members: {sq_members})\n")

hdr = "  M    k   | tax | tax atoms n (F-missed \\ D-missed)          | in squeezed pairs | predicted"
print(hdr); print("  " + "-" * (len(hdr) - 2))
results = []
for M in (300, 600):
    ks = (200, 250) if M == 300 else (400, 450, 500, 550)
    for k in ks:
        mD = missed_ns(*S[("D", M)], k)
        mF = missed_ns(*S[("F", M)], k)
        tax_set = sorted(mF - mD)
        # resolved zone of the D section = atoms NOT missed by D
        resolved = set(range(1, M + 1)) - mD
        pred_pairs = [int(n) for n in sq_pairs if n <= M - 1 and
                      (n in resolved or (n + 1) in resolved)]
        pred = sum(1 for n in pred_pairs)          # one extra miss expected per merged pair
        in_sq = sum(1 for n in tax_set if n in sq_members)
        results.append((M, k, len(tax_set), in_sq, pred))
        show = ",".join(str(n) for n in tax_set[:14]) + ("..." if len(tax_set) > 14 else "")
        print(f"  {M:3d} {k:4d} | {len(tax_set):3d} | {show:42s} | {in_sq:3d}/{len(tax_set):<3d}"
              f"          | {pred}")

print("\n  summary: measured tax vs predicted (= #squeezed pairs touching the resolved zone):")
for (M, k, tax, in_sq, pred) in results:
    print(f"    M={M} k={k}: tax {tax:3d}   predicted {pred:3d}   overlap-with-squeezed {in_sq}/{tax}")

# ---------------- metric control: common measuring stick ----------------
print("\n=== control: misses under the COMMON (D-string) resolution scale ===")
for M in (300, 600):
    ks = (250,) if M == 300 else (500, 550)
    sc = d_scale(M)
    for k in ks:
        mDc = missed_ns(*S[("D", M)], k, scale_gaps=sc)
        mFc = missed_ns(*S[("F", M)], k, scale_gaps=sc)
        taxc = sorted(mFc - mDc)
        in_sq = sum(1 for n in taxc if n in sq_members)
        print(f"  M={M} k={k}: common-stick tax {len(taxc)}  atoms {taxc[:14]}"
              f"{'...' if len(taxc) > 14 else ''}   in squeezed pairs {in_sq}/{len(taxc)}")

print("\nTax derivation run complete.  Not RH/GRH.")
