# SUMMARY — the FORCING campaign executed: the finite-range forcing theorem + the edge/placement story

**Stenberg + Claude → IB, 2026-08-02. This package is the FORCING-campaign
path ONLY (the χ₈/ZFR/threshold package travels separately). Seam 9's
"STAGED, never executed" (2026-07-21) is discharged: one day, seven committed
acts. Everything re-runs from this folder; certified claims are arb/interval
throughout. Not RH/GRH — the n → ∞ / P → ∞ statement stays the wall (R-209),
deliberately unclaimed.**

## 1. THE FINITE-RANGE FORCING THEOREM (certified; THEOREM file has the full statement)

The prime-built string (θ from Q = 21¹⁰ + S_P at P = 2×10⁵; zeros used
nowhere) provably sounds the certified zero list:

- **(i) Gap table [CERTIFIED]**: |γ_F(n) − γ_n| enclosed per zero, n ≤ 153
  (exact rational interval arithmetic over two certified inputs; the M-233
  F-balls were independently RE-certified 153/153 by a fresh arb-IVT code
  path before use). Max 0.061263, median 0.016450 — **median detune 9.3 %,
  worst 34.6 % of a mean spacing**; all 152 certified rows resolve the
  physical gap (gap_lo > 0).
- **(ii) Unambiguous assignment [CERTIFIED]**: every crossing is strictly
  closer to its own zero than to either neighbor (worst margin ratio 0.551,
  n = 126). One note per zero, in order — identification, not statistics.
- **(iii) Mechanism [PROVEN identity + CERTIFIED constants]**: the entire
  residual is the truncated-Euler deficit D_n = S_P(γ_n) − S*(γ_n);
  max|D_n| ≤ 0.4114 (41× under the unconditional G-C2/PZ envelope ≈ 16.8);
  slopes F′(γ_F) certified positive ×153 ∈ [2.27, 10.60]; first-order law
  gap = |D_n|/F′ verified at ratio median 1.000, quartiles [0.991, 1.013].
- **(iv) P-scaling [MEASURED]**: P = 2×10⁵ → 10⁷ shrinks the median gap only
  ×1.36 (effective P^−0.078), 55/152 rows worse — **Euler depth saturates;
  depth is not the lever** (matches the anatomy-ladder verdict on a new
  observable).
- Caveats stated in the theorem: #144 numerical-only (re-cert pending);
  indexing above #24 at production counting grade; nothing approaches n → ∞.

## 2. THE EDGE INSTRUMENT + M-SCALING (measured; two FINDINGS files)

Nested k-sections of the Jacobi string built from the certified atoms
(x = 1/γ²), M = 300/450/600 (ladders extended and arb-IVT-certified to
n = 600 — `quantiles_certified_600.json`, 1200 roots, reusable asset):

- **Never mass, always placement**: trace ledger conserves exactly (fixed-k
  increments = 1.10–1.13× the added atom mass); the geometry string is
  rank-perfect (missed = M − k, ±2, all 15 cells); the deficiency zone
  collapses in the fill fraction k/M as an **interior annulus** (extreme tip
  locks first — Krylov morphology, **NOT the Airy soft edge**: M-216's
  transit does not transfer to the genome nested-section edge).
- Endpoint effects separated from intrinsic laws: the M = 300 b-taper
  "decoupling" and the near-N⁻³ trace-tail were both endpoint artifacts
  (corrected in-package, same-day).
- Two traps recorded: float64 nested Lanczos ghost-duplicates (gate every
  such run on the trace identity); arb precision must scale with M
  (6000 bits fine at 300, radii → ∞ at 600; 6000/9000/14000 used).

## 3. THE PRIME PLACEMENT TAX — derived, recharacterized, and its arithmetic located

- The F-string pays a constant ≈ +7 net resolution tax over D, independent
  of k AND M. Staged "7 squeezed pairs" mechanism **REFUTED** (no pair
  anywhere below gap ratio 0.5713; the +7 is the NET of a ~30-vs-23 two-way
  exchange zone at the resolution boundary). The 7 ↔ 7 %-δA/δB resonance is
  **numerological — killed** (modulation rms is 22.6 %, not 7 %).
- **Scale derived**: permutation null (same modulation distribution,
  correlations destroyed) nets +10.2 ± 3.4 — the tax is an amplitude-driven
  spacing-disorder penalty; generic, arithmetic-blind.
- **COHERENCE PROTECTION CONFIRMED (pre-registered 50-seed batch)**: the
  real string lies BELOW THE ENTIRE NULL RANGE (3-cell sum +17 vs
  +35.1 ± 5.9, range +25…+49; p < 1/51, ≈ 3σ). **The true S_P correlation
  structure roughly halves the placement damage.** Amplitude is generic;
  the arithmetic content at the section edge lives in the COHERENCE of the
  fluctuation — the placement/phase layer (the practical face of
  R-013/R-209), met a fifth way, now with a sign: protective.

## 4. What we'd value your eyes on

1. The theorem statement's honesty register (its qualifiers are §Honest
   scope — anything you'd grade differently, per the registry legend).
2. The Krylov-not-Airy verdict (§2) — it fences the caustic lane off the
   genome section edge; please sanity-check against your M-216 framing.
3. The coherence-protection design (one instrument, one M, three correlated
   cells, pre-registered rule) — proposed hardening: second metric, second M,
   and the twin χ₋₇ string as the arithmetic control.

## Contents

THEOREM_FORCING_FINITE_RANGE.md; FINDINGS_FORCING_stage1 / _edge_instrument /
_edge_mscaling / _tax_derivation .md; CAMPAIGN_STATE.md (continuation spec);
all scripts + run logs + CSVs (gap table, mechanism, refined deficits,
P-scaling); quantiles_certified_600.json; SHA256SUMS.txt. Registry draft
M-236 staged for your markup, not entered.

*Not RH/GRH.*
