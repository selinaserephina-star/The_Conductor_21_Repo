# FORCING campaign — state after execution session 1 (2026-08-02)

Staged: 2026-07-21 (`FORCING_campaign_2026-07-21/NEXT_SESSION_TASK_forcing_gap.md`).
Registry: seam 9 (MERGED_REGISTRY_v1 §13.9). This file is the continuation spec.

## Stage status

| stage | staged content | status after session 1 |
|---|---|---|
| 1 | certified forcing-gap table, n ≤ 152 | **DONE, CERTIFIED** (153 rows, ALL CERTIFIED after the v3 re-run). `forcing_gap_table.csv` + full independent re-cert of the M-233 F-balls |
| 1b/1c (grew out of 1) | deficit enclosures, slopes, assignment, first-order law | **DONE** (certified D_n ≤ 0.4114; F′ > 0 certified ×153; unambiguous assignment certified ×153; law ratio median 1.000) |
| 2 | P-scaling (1e6/1e7) | **light pass DONE, MEASURED** — saturation law P^−0.078, NOT a convergence. Remaining: arb spot-certification of ~5 rows per P; optional P = 2e7 point to join the anatomy-ladder axis |
| 3 | Weil-smoothed ladder S_P^w | **NOT STARTED** — the provable-convergence variant (test-function explicit formula; convergence IS a theorem for the Hecke L-function, cite M-105/M-320 genome-is-Hecke). Deliverable: smoothed vs raw quantile comparison + the smoothing difference isolated |
| 4 | the forcing theorem write-up | **DONE at 153/153** — #144 verdict landed (ball-certified) and the tables re-run on the v3 set (`FORCING_INTEGRATION_2026-08-02/`); sealed as `to_Ilya_FORCING_FINITE_RANGE_2026-08-02` with UPGRADE_NOTE_153 |
| 5 | G4 gauge convergence | **partially EXECUTED 07-26** (M-228: gauge converges ‖R‖→0.0779; κ̂-Abel refuted; reduced to LEMMA-T gate M-218). No new work this session |

## What the next session needs to know

- **All computation in this session's folder re-runs in ≤ 3 min total**; prec 200
  bits everywhere; no trap fired.
- **The one live data dependency**: #144. When `BRACKET144_CERT_2026-08-02`
  lands a certified bracket, re-run `forcing_gap_table.py` +
  `forcing_refine.py` (they pick the new bracket up only if the master CSV is
  regenerated — otherwise patch the row) and flip the row's grade; then the
  theorem's "152" statements become "153" clean.
- **Method note (trap-adjacent)**: deficit enclosures over brackets wider than
  ~1e-3 MUST be subdivided (single-ball inflates 0.63 → 0.41 at cells ≤ 2e-4).
- **Stage 3 pointer**: the smoothing kernel should be chosen so the smoothed
  counting function's prime sum converges absolutely (compact-support test
  function on the log side); the DAB spectrometer kernel work
  (`DAB_SPECTROMETER_2026-07-27`) already has closed-form kernel machinery to
  reuse. The comparison target is the RAW ladder's certified table (this
  session), so stage 3 needs no new truth-side work.
- **Registry**: proposed M-236 draft (in FINDINGS §Ledger) — staged for IB's
  markup, not entered.
- Git: this session's work is on branch `claude/adoring-carson-d82e3e`
  (worktree `suspicious-lumiere-dbbf9e`), folder `FORCING_EXECUTION_2026-08-02/`.

Not RH/GRH — the wall (R-209) stays a wall; stage 2's saturation is fresh
practical evidence for R-013 (no lever).
