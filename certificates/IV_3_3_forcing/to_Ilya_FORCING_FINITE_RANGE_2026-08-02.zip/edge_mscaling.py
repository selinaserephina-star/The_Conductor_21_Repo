r"""
FORCING campaign 2026-08-02 — THE M-SCALING RUN (edge-instrument continuation).

Strings J(M) for M = 300 / 450 / 600 (both ladders; uniform measure 1/M on the
first M certified atoms; arb prec-6000 Lanczos, trace-identity gate per run),
sections in float from the exact coefficients.  The M-comparison separates the
intrinsic edge laws from the M = 300 endpoint artifacts:

 (Q1) TAPER: is the bulk law a_k ~ k^-1.5 / b_k steepening intrinsic or an
      end effect?  Fit a_k, b_k on the SAME fixed window [60, 250] for every M
      (away from all ends), and on the sliding end window [M-100, M-10].
 (Q2) TRACE LEDGER: T_M(k) at FIXED k across M — convergent (intrinsic) or
      M-dependent?  And the tail exponent measured per M on [100, M-25]:
      does the steep zone slide with the endpoint?
 (Q3) EDGE RESOLUTION: is the D-string rank-perfect (missed = M-k) at every M?
      Is the F prime placement tax still constant ~7-9, independent of BOTH
      k and M?
 (Q4) TRANSIT SHAPE: displacement profile (units of local gap) vs atom
      index-from-edge, compared at FIXED M-k across M (e.g. M-k = 50, 100):
      does the profile depend only on M-k (endpoint variable), only on k, or
      on k/M?  Report the collapse that holds; only if one does, compare its
      shape qualitatively against the Airy transit (no forced fit).

Grade: MEASURED (exact-coefficient strings, self-certified radii; float
sections).  Not RH/GRH.
"""
import json, math, time
import numpy as np
from flint import arb, ctx

HERE = r"C:\Users\selin\OneDrive\Desktop\Ilya Riemanns\.claude\worktrees\suspicious-lumiere-dbbf9e\FORCING_EXECUTION_2026-08-02"
ROWS = json.load(open(HERE + r"\quantiles_certified_600.json"))["rows"]
MS = (300, 450, 600)
PREC_BY_M = {300: 6000, 450: 9000, 600: 14000}   # the recursion's conditioning deepens with M:
                                                  # prec 6000 (M-233's m=300 tuning) blows up at
                                                  # M=600 (radii -> inf, trace gate FAILED) — scale it

def jacobi_arb(atoms):
    m = len(atoms)
    v = [arb(m).rsqrt()] * m
    a = []; b = []
    w = [atoms[i] * v[i] for i in range(m)]
    a0 = sum((v[i] * w[i] for i in range(m)), arb(0)); a.append(a0)
    w = [w[i] - a0 * v[i] for i in range(m)]
    vprev = v
    for j in range(1, m):
        be = sum((x * x for x in w), arb(0)).sqrt()
        b.append(be)
        vn = [w[i] / be for i in range(m)]
        w = [atoms[i] * vn[i] - be * vprev[i] for i in range(m)]
        al = sum((vn[i] * w[i] for i in range(m)), arb(0)); a.append(al)
        w = [w[i] - al * vn[i] for i in range(m)]
        vprev = vn
    return a, b

def build(tag, strs, M):
    ctx.prec = PREC_BY_M[M]
    atoms = [arb(1) / arb(s) ** 2 for s in strs[:M]]
    t0 = time.time()
    a, b = jacobi_arb(atoms)
    maxrad = max(float(x.rad()) for x in a + b)
    diff = float(abs(sum(a, arb(0)) - sum(atoms, arb(0))).upper())
    print(f"  [{tag} M={M}] {time.time()-t0:.1f}s  maxrad={maxrad:.1e}  |trJ-sumx|<={diff:.1e} "
          f"{'OK' if diff < 1e-50 else 'FAIL'}", flush=True)
    assert diff < 1e-50
    return (np.array([float(v) for v in a]), np.array([float(v) for v in b]),
            np.array([float(v) for v in atoms]))

def eig_section(a, b, k):
    return np.linalg.eigvalsh(np.diag(a[:k]) + np.diag(b[:k - 1], 1) + np.diag(b[:k - 1], -1))

def slope(vals, k1, k2):
    kk = np.arange(k1, k2 + 1)
    return np.polyfit(np.log(kk), np.log(vals[k1 - 1:k2]), 1)[0]

gF = [r["gF_mid"] for r in ROWS]
gD = [r["gD_mid"] for r in ROWS]

print("building strings (arb prec 6000, trace gate each)...")
S = {}
for M in MS:
    S[("F", M)] = build("F", gF, M)
    S[("D", M)] = build("D", gD, M)

# ---------------- Q1: taper — fixed bulk window vs sliding end window ----------
print("\n(Q1) taper slopes:")
print("      fixed bulk window [60,250]              sliding end window [M-100,M-10]")
for lad in ("F", "D"):
    for M in MS:
        a, b, x = S[(lad, M)]
        sa_b = slope(a, 60, 250); sb_b = slope(b, 60, 250)
        sa_e = slope(a, M - 100, M - 10); sb_e = slope(b, M - 100, M - 10)
        print(f"  {lad} M={M}:  a {sa_b:+.3f}  b {sb_b:+.3f}        a {sa_e:+.3f}  b {sb_e:+.3f}")

# ---------------- Q2: trace ledger across M ----------------
print("\n(Q2) trace ledger T_M(k) at fixed k across M:")
kfix = (100, 150, 200, 250)
for lad in ("F", "D"):
    print(f"  {lad}:   k      M=300         M=450         M=600")
    for k in kfix:
        vals = [S[(lad, M)][0][k:].sum() for M in MS]
        print(f"      {k:4d}  " + "  ".join(f"{v:.6e}" for v in vals))
print("  tail exponent of T_M(k) on [100, M-25] per M:")
for lad in ("F", "D"):
    for M in MS:
        a = S[(lad, M)][0]
        T = np.array([a[k:].sum() for k in range(1, M)])
        k1, k2 = 100, M - 25
        s = (math.log(T[k2 - 1]) - math.log(T[k1 - 1])) / (math.log(k2) - math.log(k1))
        # also a mid window clear of the end for M=600
        smid = None
        if M >= 600:
            smid = (math.log(T[400 - 1]) - math.log(T[100 - 1])) / (math.log(400) - math.log(100))
        print(f"    {lad} M={M}: exponent[100,{k2}] = {s:+.3f}" +
              (f"   exponent[100,400] = {smid:+.3f}" if smid is not None else ""))

# ---------------- Q3: rank-perfection + prime tax across M ----------------
print("\n(Q3) edge resolution across M (missed atoms vs M-k):")
def missed_count(a, b, x, k):
    xs = np.sort(x)
    M = len(xs)
    gaps = np.diff(xs); locgap = np.empty(M)
    locgap[1:-1] = np.minimum(gaps[:-1], gaps[1:]); locgap[0] = gaps[0]; locgap[-1] = gaps[-1]
    lam = eig_section(a, b, k)
    d = np.abs(xs[:, None] - lam[None, :]).min(axis=1)
    return int((d > 0.5 * locgap).sum()), (d / locgap)

tax_rows = []
for M in MS:
    for k in (M - 250, M - 200, M - 150, M - 100, M - 50):
        if k < 50: continue
        mD, _ = missed_count(*S[("D", M)], k)
        mF, _ = missed_count(*S[("F", M)], k)
        tax_rows.append((M, k, M - k, mD, mF, mF - mD))
        print(f"    M={M} k={k:3d} (M-k={M-k:3d}):  D missed {mD:3d} (rank-perfect: {mD == M - k})   "
              f"F missed {mF:3d}   prime tax {mF - mD:+d}")

# ---------------- Q4: transit profile collapse ----------------
print("\n(Q4) transit profile (displacement/local-gap, atoms 0..11 from the edge):")
print("  at FIXED M-k = 50:")
for M in MS:
    k = M - 50
    _, prof = missed_count(*S[("F", M)], k)
    print(f"    F M={M} k={k}: [" + ", ".join(f"{v:.2f}" for v in prof[:12]) + "]")
print("  at FIXED M-k = 100:")
for M in MS:
    k = M - 100
    _, prof = missed_count(*S[("F", M)], k)
    print(f"    F M={M} k={k}: [" + ", ".join(f"{v:.2f}" for v in prof[:12]) + "]")
print("  at FIXED k = 250:")
for M in MS:
    _, prof = missed_count(*S[("F", M)], 250)
    print(f"    F M={M} k=250: [" + ", ".join(f"{v:.2f}" for v in prof[:12]) + "]")

# transit boundary: index-from-edge of the first atom with displacement < 0.05
print("  transit boundary (first index-from-edge with d/gap < 0.05):")
for M in MS:
    for dk in (50, 100):
        k = M - dk
        _, prof = missed_count(*S[("F", M)], k)
        idx = next((i for i, v in enumerate(prof) if v < 0.05), -1)
        print(f"    F M={M} M-k={dk}: boundary index = {idx}")

print("\nM-scaling run complete — MEASURED grade.  Not RH/GRH.")
