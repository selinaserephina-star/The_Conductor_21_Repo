# FINDINGS — THE EDGE INSTRUMENT: how the trace and the string are missing at the edge (measured on the certified genome atoms)

**Merkabit · Stenberg + Claude · 2026-08-02 (same session as the FORCING execution).
Scripts: `edge_instrument.py` (float64 — SELF-REFUTED, kept as trap witness) and
`edge_instrument_arb.py` + logs (authoritative). Data: the 300 arb-IVT-certified
quantile atoms (M-233), x_n = 1/γ_n². Object: the nested k×k sections of the
m = 300 Jacobi/string matrix (uniform measure) — the classical finite-section
edge, where the spectrum accumulates at 0 = the high-zero end = the wall's
direction. Deliberately NOT the production non-nested convention (whose
eigenvalues are the atoms exactly); the nesting/non-nesting gap is G-M3.
Grade: MEASURED (arb prec-6000 coefficients, radii = 0.0 verified, trace
identity exact; float64 only in the backward-stable tridiagonal eigensolves).
Not RH/GRH.**

## 0. Trap recorded (full-value negative)

The first (float64) run refuted itself by its own trace ledger:
tr J(300) = 62.6 vs Σx = 4.51 (F) — plain no-reorth Lanczos in float64
ghost-duplicates converged Ritz values at this depth on these clustered atoms.
The arb-jet discipline (no reorth + high precision, radii self-certify) is
REQUIRED here, not optional: at prec 6000 the radii are 0.0 and tr J = Σx
exactly. Method note for the registry: **any nested-section instrument on the
genome string must carry the trace-identity check as a gate.**

## 1. The string's descent to the edge (the taper law)

- a_k ~ k^−1.52…−1.59 across both windows — **identical to the atom-decay slope
  (−1.545)**: the diagonal taper IS the density of states transmuted
  (x_n ~ (log n / 2πn)², slope −2 + log corrections ≈ −1.55 on this range).
- b_k ~ k^−1.59 in the bulk but **steepens to k^−2.31 in the tail**: the
  coupling dies a full power faster than the diagonal, b_k/a_k → 0 like ~k^−0.8.
  **Toward its edge the string asymptotically decouples into near-independent
  beads** — the finite-range face of the limit-point (no-finite-obstruction)
  picture; consistent with the leading-order (0,0) reading of the wall reviews,
  and with F and D agreeing on every taper number to ~2%.

## 2. The trace ledger: what mass the k-section is missing

T(k) = Σ_{i>k} a_i (exact, since tr J = Σx at arb grade):
- bulk law T(k) ~ k^−0.90, tracking the atom-tail Σ_{n>k} x_(n) ~ k^−1 log²
  with a measured redistribution factor ≈ 1.25–1.40 (the string holds slightly
  more trace at high index than the sorted atom tail — Lanczos ordering);
- near the string's end the exponent steepens to −2.77 (F) / −2.76 (D).
  **Caveat stated plainly:** this window conflates the intrinsic tail law with
  the k → M endpoint constraint (T(300) = 0 by construction); its closeness to
  the M-210 model law ‖τ_ODD‖ ~ N^−3 is NOTED, NOT claimed — separating
  intrinsic from end effect needs the M-scaling run (continuation item below;
  the withdrawn-Airy-crosscheck lesson applies verbatim).

## 3. The edge resolution — the sharp finding

Atom→nearest-Ritz matching (missed = no Ritz value within half the local gap):

| k | D missed | M − k | F missed | prime cost |
|---|---|---|---|---|
| 50 | 250 | 250 | 257 | +7 |
| 100 | 200 | 200 | 202 | +2 |
| 150 | 150 | 150 | 157 | +7 |
| 200 | 100 | 100 | 111 | +11 |
| 250 | 50 | 50 | 59 | +9 |

- **The geometry string (D) is rank-perfect: a k-section resolves EXACTLY k
  atoms at every k tested** — no smearing waste; the k Ritz values distribute
  so that precisely M − k atoms (spread through the edge cluster) go
  unresolved. The "drop" at the edge is pure counting, executed perfectly.
- **The prime dressing (F) costs a roughly constant ~7–9 extra unresolved
  atoms, k-independent from 50 to 250.** The prime fluctuation locally shuffles
  near-degenerate pairs, and the section pays a small fixed resolution tax at
  the edge — it does not grow with depth.
- The displacement transit has the expected shape: at k = 200 the first-8
  profile [0.00, 0.00, 0.01, 0.06, 0.13, 0.52, 0.50, 0.32] shows the
  locked→transit→interior sigmoid; at k = 250 the first 8 are all 0.00. The
  functional form of this transit (Airy or not) is deliberately left unmeasured
  pending the scaling collapse across M (no forced fit).

## 4. The verdict on "what is missing at the edge"

**Not trace mass — placement.** The F/D trace-tail ratio is 1.000 ± 0.004 at
every k: the prime data moves NO trace mass at the edge. What the section
misses is *which* atom is where inside the edge cluster (resolution/placement),
and the prime dressing makes that placement slightly harder (the constant
~8-note tax). This is the third independent instrument to land on the same
verdict — the anatomy ladder (leak = phase/placement layer), the P-scaling
saturation (depth ≠ lever), and now the section edge (mass invariant,
placement pays). The "shape" of the edge drop on the real genome string is:
**a perfect-counting drop (M − k), decorated by a constant prime placement tax,
on a string that decouples (b/a → 0) as it descends.**

## 5. Continuation (one item, well-posed)

**The M-scaling run:** extend the certified quantile ladder to n = 600 (same
M-233 machinery, one session), rebuild J(M) for M = 300/450/600, and measure
T(k) at fixed k and the transit profile vs (M − k) across M — this separates
the intrinsic tail law from the endpoint constraint and gives the transit its
scaling variable honestly (then, and only then, compare against the Airy
transit and the M-210 N^−3 law). Cheap: the Lanczos is 2 s per ladder at
prec 6000.

Not RH/GRH — the section edge is instrumented, the n → ∞ statement (R-209)
stays the wall.
