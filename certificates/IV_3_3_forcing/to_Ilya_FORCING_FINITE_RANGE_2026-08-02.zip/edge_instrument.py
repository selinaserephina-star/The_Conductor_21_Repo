r"""
FORCING campaign 2026-08-02 — ADDENDUM: THE EDGE INSTRUMENT.
"How are the trace and the string missing at the edge, and with what shape?"

Objects (certified atoms x_n = 1/gamma_n^2 from quantiles_certified.json, n<=300;
the spectrum accumulates at 0 — the high-zero end, the wall's direction):

  J(300)  = the full Jacobi/string matrix of the uniform measure on the first
            300 atoms (plain 3-term Lanczos, no reorth — the M-233 discipline;
            float64 here [MEASURED], M-233 proved float64 matches the arb
            recursion to 8e-17 on these atoms).
  J_k     = the leading k x k SECTION of J(300) (the classical finite-section
            object: nested truncation of ONE string).  NOTE this is deliberately
            NOT the production non-nested convention (Lanczos of the first m
            atoms per m, whose eigenvalues are the atoms exactly); the nested
            section is where the soft-edge deficiency lives, and the non-nesting
            gap between the two conventions IS G-M3.

Measurements:
  (1) THE STRING TAPER: a_k, b_k vs k — how the string coordinates descend to
      the accumulation edge; fitted local power law (log-corrected expected from
      the density of states gamma_n ~ 2 pi n / log n  =>  x_n ~ (log n / 2 pi n)^2).
  (2) THE TRACE LEDGER: T(k) = tr J(300) - tr J_k = sum_{i>k} a_i — the trace
      mass the k-section is missing; measured decay law, compared against the
      PROVEN model tail law ||tau_ODD|| = 1/(3 pi^4 N^3) (M-210) — report the
      measured exponent, do NOT assume it.
  (3) THE EDGE DISPLACEMENT SHAPE: eigenvalues of J_k vs the true atoms — how
      many atoms near the edge are unresolved, and the displacement profile of
      the last resolved ones vs distance-from-edge, with a cross-k scaling
      collapse; measured exponent reported (the Airy/(AiBi)' nu^{-1/3} transit is
      the MODEL-side result M-216 — whether the genome string shows the same
      shape is exactly what is measured here; no forced fit, per the withdrawn
      Weyl/Airy cross-check lesson).
  (4) D vs F: the same for the geometry-only ladder — does the prime dressing
      change how the string goes to the edge?

Grade: MEASURED (float64 witness on certified atom mids).  Not RH/GRH.
"""
import json, math
import numpy as np

MAIN = r"C:\Users\selin\OneDrive\Desktop\Ilya Riemanns"
HERE = r"C:\Users\selin\OneDrive\Desktop\Ilya Riemanns\.claude\worktrees\suspicious-lumiere-dbbf9e\FORCING_EXECUTION_2026-08-02"
ROWS = json.load(open(MAIN + r"\WALL_KLMN_ARB_CERT_2026-07-31\quantiles_certified.json"))["rows"]
M = 300

def lanczos(x):
    m = len(x)
    v = np.full(m, 1.0 / math.sqrt(m))
    a = np.empty(m); b = np.empty(m - 1)
    w = x * v
    a[0] = v @ w
    w -= a[0] * v
    vp = v
    for j in range(1, m):
        be = math.sqrt(w @ w)
        b[j - 1] = be
        vn = w / be
        w = x * vn - be * vp
        a[j] = vn @ w
        w -= a[j] * vn
        vp = vn
    return a, b

def eig_section(a, b, k):
    return np.linalg.eigvalsh(np.diag(a[:k]) + np.diag(b[:k - 1], 1) + np.diag(b[:k - 1], -1))

def analyze(tag, gammas):
    x = 1.0 / gammas ** 2
    a, b = lanczos(x)
    print(f"\n========== {tag}-ladder string (atoms x_n = 1/gamma_n^2, m={M}) ==========")

    # (1) the taper
    print("(1) string taper a_k, b_k (descent to the edge at 0):")
    ks = [1, 5, 10, 25, 50, 100, 150, 200, 250, 290, 299]
    for k in ks:
        bb = b[k - 1] if k - 1 < len(b) else float('nan')
        print(f"    k={k:3d}  a_k={a[k-1]:.6e}  b_k={bb:.6e}")
    # local log-log slope of a_k over decades
    for (k1, k2) in ((10, 30), (30, 100), (100, 290)):
        s = (math.log(a[k2 - 1]) - math.log(a[k1 - 1])) / (math.log(k2) - math.log(k1))
        print(f"    local slope d(log a)/d(log k) on [{k1},{k2}] = {s:+.3f}")
    for (k1, k2) in ((10, 30), (30, 100), (100, 290)):
        s = (math.log(b[k2 - 1]) - math.log(b[k1 - 1])) / (math.log(k2) - math.log(k1))
        print(f"    local slope d(log b)/d(log k) on [{k1},{k2}] = {s:+.3f}")
    # DOS reference: x_n ~ (log n / (2 pi n))^2 * (logQ-ish scale) — pure shape ref
    sref = (math.log(x[99]) - math.log(x[9])) / (math.log(100) - math.log(10))
    print(f"    reference: atom decay d(log x_n)/d(log n) on [10,100] = {sref:+.3f}  "
          f"(DOS ~ -2 with log correction)")

    # (2) the trace ledger
    print("(2) trace ledger: T(k) = sum_(i>k) a_i  (the k-section's missing trace):")
    tr_full = a.sum()
    print(f"    tr J(300) = {tr_full:.9f}   vs   sum atoms = {x.sum():.9f}   "
          f"(agree to {abs(tr_full - x.sum()):.1e})")
    kgrid = [25, 50, 75, 100, 150, 200, 250, 275]
    T = {k: a[k:].sum() for k in kgrid}
    for k in kgrid:
        print(f"    k={k:3d}  T(k) = {T[k]:.6e}")
    for (k1, k2) in ((25, 100), (100, 275)):
        s = (math.log(T[k2]) - math.log(T[k1])) / (math.log(k2) - math.log(k1))
        print(f"    measured trace-tail exponent on [{k1},{k2}]: T(k) ~ k^{s:+.3f}")
    print(f"    [model reference, NOT assumed: M-210 ||tau_ODD|| = 1/(3 pi^4 N^3) ~ N^-3;")
    print(f"     atom-sum tail sum_(n>k) x_n ~ (log k)^2/k ~ k^-1 log-corrected]")

    # (3) the edge displacement shape
    print("(3) edge displacement: eigenvalues of the k-section vs the true atoms:")
    x_sorted = np.sort(x)                    # ascending: edge cluster at 0 first
    prof = {}
    for k in (50, 100, 150, 200, 250):
        lam = eig_section(a, b, k)           # ascending
        # match interior: an eigenvalue is LOCKED if within half local atom gap
        # count from the TOP (large atoms lock first — Lanczos resolves extremes)
        locked = 0
        dis = []
        # match each of the k eigenvalues to nearest atom (all 300)
        for l in lam:
            i = np.searchsorted(x_sorted, l)
            cand = []
            if i < M: cand.append(abs(x_sorted[i] - l))
            if i > 0: cand.append(abs(x_sorted[i - 1] - l))
            d = min(cand)
            # local gap scale at that atom
            j = min(max(i, 1), M - 1)
            gap_loc = x_sorted[j] - x_sorted[j - 1]
            dis.append(d / gap_loc if gap_loc > 0 else float('inf'))
        dis = np.array(dis)                   # ascending eigenvalue order = edge first
        nlock = int((dis < 0.5).sum())
        prof[k] = dis
        # how deep into the edge cluster does resolution reach?
        # smallest locked eigenvalue index among atoms:
        locked_mask = dis < 0.5
        print(f"    k={k:3d}: locked (within half local gap) {nlock}/{k}; "
              f"unresolved at the 0-edge: {k - nlock}")
    # displacement profile shape: relative displacement vs index-from-edge for each k
    print("    displacement (in local-gap units) vs index-from-edge (first 8 eigenvalues):")
    for k in (100, 200, 250):
        d8 = ", ".join(f"{v:.2f}" for v in prof[k][:8])
        print(f"      k={k:3d}: [{d8}]")
    # scaling: number of unresolved edge states vs k
    un = {k: int((prof[k] >= 0.5).sum()) for k in prof}
    ks_ = sorted(un)
    for (k1, k2) in ((50, 250),):
        if un[k1] > 0 and un[k2] > 0:
            s = (math.log(un[k2]) - math.log(un[k1])) / (math.log(k2) - math.log(k1))
            print(f"    unresolved-edge-count scaling on [{k1},{k2}]: ~ k^{s:+.3f}  "
                  f"({un[k1]} -> {un[k2]})")
    return a, b, T, un

gF = np.array([float(r["gF_mid"]) for r in ROWS])
gD = np.array([float(r["gD_mid"]) for r in ROWS])
aF, bF, TF, unF = analyze("F", gF)
aD, bD, TD, unD = analyze("D", gD)

print("\n========== (4) prime dressing at the edge: F vs D ==========")
print("    relative string difference |a_F - a_D| / a_D:")
for k in (1, 10, 50, 100, 200, 290):
    print(f"      k={k:3d}: {abs(aF[k-1]-aD[k-1])/aD[k-1]:.3e}")
print("    trace-tail ratio T_F(k)/T_D(k):")
for k in sorted(TF):
    print(f"      k={k:3d}: {TF[k]/TD[k]:.6f}")
print("\nEdge instrument complete — MEASURED grade (float64 witness; M-233 established")
print("float64/arb agreement 8e-17 on this recursion).  Not RH/GRH.")
