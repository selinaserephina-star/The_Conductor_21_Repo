r"""
FORCING campaign, EXECUTION session 2026-08-02 — STAGE 1c (refinement):
  (A) SUBDIVIDED deficit enclosures: D_n over each bracket re-enclosed as the
      union over cells of width <= 2e-4 (the ball width of S_P over a cell
      scales with the cell width * L1; subdivision tightens the wide brackets
      #125/#143/#150/#153 and hence the global max |D_n|).
  (B) CERTIFIED ladder slope at the roots: F'(t) = theta'(t)/pi + S_P'(t)
      arb-evaluated over each (tiny) certified F-root ball -> proven
      F'(gamma_F(n)) > 0 for all n (the local transversality of the forcing).
      theta'(t) = logQ/2 - 4 log pi + (1/2) sum_m Re psi((1/2+m)/2 + i t/2).
Outputs: forcing_deficit_refined.csv + printed global constants.
Not RH/GRH.
"""
import sys, csv, json, math, statistics, time
import numpy as np, mpmath as mp
from flint import arb, acb, ctx

MAIN = r"C:\Users\selin\OneDrive\Desktop\Ilya Riemanns"
HERE = r"C:\Users\selin\OneDrive\Desktop\Ilya Riemanns\.claude\worktrees\suspicious-lumiere-dbbf9e\FORCING_EXECUTION_2026-08-02"
QCJSON = MAIN + r"\WALL_KLMN_ARB_CERT_2026-07-31\quantiles_certified.json"
BRACKS = MAIN + r"\to_Ilya_CERTIFIED_spectrum_2026-07-19\results\certified_run_brackets.csv"
sys.path.insert(0, MAIN + r"\Operator_program_addendum")
from gen_an_chi8 import LOC8, frob_class

mp.mp.dps = 45
ctx.prec = 200
MU = [0, 0, 0, 0, 1, 1, 1, 1]
ARB_PI = arb.pi()
ARB_LOGPI = ARB_PI.log()
ARB_LOGQ = (arb(21) ** 10).log()
CELL = 2e-4

def theta_arb(t):
    v_im = (t / 2) * ARB_LOGQ
    for m_ in MU:
        v_im += -(t / 2) * ARB_LOGPI
        z = acb(arb(1 + 2 * m_) / 4, t / 2)
        v_im += z.lgamma().imag
    return v_im

def thetap_arb(t):
    # derivative of theta: logQ/2 - 4 log pi + (1/2) sum Re psi((1+2m)/4 + it/2)
    v = ARB_LOGQ / 2 - 4 * ARB_LOGPI
    for m_ in MU:
        z = acb(arb(1 + 2 * m_) / 4, t / 2)
        v += z.digamma().real / 2
    return v

def newton_ps(loc, kmax):
    deg = len(loc) - 1
    e = [((-1) ** i) * loc[i] for i in range(len(loc))]
    p = [0] * (kmax + 1)
    for k in range(1, kmax + 1):
        s = ((-1) ** (k - 1)) * k * e[k] if k <= deg else 0
        for i in range(1, min(k - 1, deg) + 1):
            s += ((-1) ** (i - 1)) * e[i] * p[k - i]
        p[k] = s
    return p[1:]

print("building S_P terms + arb coefficients (P=2e5)...", flush=True)
P_MAX = 200000
isp = np.ones(P_MAX + 1, bool); isp[:2] = False
for q in range(2, int(P_MAX ** .5) + 1):
    if isp[q]: isp[q * q::q] = False
TERMS = []
for p in np.nonzero(isp)[0]:
    p = int(p); kmax = 1
    while p ** (kmax + 1) <= P_MAX: kmax += 1
    tr = newton_ps(LOC8[frob_class(p)], kmax)
    for k in range(1, kmax + 1):
        TERMS.append((int(tr[k - 1]), k, p))
assert len(TERMS) == 18120
_co = [arb(tr) / arb(k) / (arb(p) ** k).sqrt() for (tr, k, p) in TERMS]
_lg = [arb(k) * arb(p).log() for (tr, k, p) in TERMS]
_colg = [c * l for c, l in zip(_co, _lg)]

def SP_arb(t):
    acc = arb(0)
    for c, l in zip(_co, _lg):
        acc += c * (t * l).sin()
    return -(arb(1) / ARB_PI) * acc

def SPp_arb(t):
    acc = arb(0)
    for cl, l in zip(_colg, _lg):
        acc += cl * (t * l).cos()
    return -(arb(1) / ARB_PI) * acc

with open(QCJSON) as f:
    rows_F = {r["n"]: r for r in json.load(f)["rows"]}
br = []
with open(BRACKS) as f:
    for r in csv.DictReader(f):
        br.append((int(r["j"]), r["lo"], r["hi"], r["certified"] == "True"))

# ---------------- (A) subdivided D_n enclosures ----------------
print("\n(A) subdivided deficit enclosures (cell <= 2e-4)...", flush=True)
t0 = time.time()
refined = []
for (j, lo_s, hi_s, cert) in br:
    lo, hi = mp.mpf(lo_s), mp.mpf(hi_s)
    ncell = max(1, int(mp.ceil((hi - lo) / mp.mpf(CELL))))
    U = None
    for i in range(ncell):
        a = lo + (hi - lo) * i / ncell
        b = lo + (hi - lo) * (i + 1) / ncell
        B = arb(mp.nstr(a, 42)).union(arb(mp.nstr(b, 42)))
        Sstar = arb(2 * j - 1) / 2 - theta_arb(B) / ARB_PI
        D = SP_arb(B) - Sstar
        U = D if U is None else U.union(D)
    refined.append((j, U, cert, ncell))
    if j % 25 == 0 or j in (1, 125, 143, 144, 150, 153):
        print(f"  n={j:3d} ({ncell:2d} cells)  D_n in [{float(U.lower()):+.6f}, {float(U.upper()):+.6f}]"
              f"{'' if cert else '  [NUMERICAL]'}", flush=True)
print(f"  ({time.time()-t0:.1f}s)")

certD = [(j, D) for (j, D, cert, _) in refined if cert]
absU = [(j, max(abs(float(D.lower())), abs(float(D.upper())))) for (j, D) in certD]
jworst, worst = max(absU, key=lambda z: z[1])
print(f"\n  REFINED: max_n |D_n| <= {worst:.6f}  (attained at n = {jworst})")
print(f"  max certified radius of D_n (certified rows) = "
      f"{max(float(D.rad()) for (_, D) in certD):.3e}")
print(f"  median |D_n| (mids) = {statistics.median(abs(float(D.mid())) for (_, D) in certD):.6f}")

# ---------------- (B) certified slope at the F-roots ----------------
print("\n(B) certified F'(gamma_F(n)) over each certified root ball...", flush=True)
t0 = time.time()
slopes = []
allpos = True
for j in range(1, 154):
    r = rows_F[j]
    mid = mp.mpf(r["gF_mid"]); rad = mp.mpf(repr(r["gF_rad"]))
    B = arb(mp.nstr(mid - rad, 42)).union(arb(mp.nstr(mid + rad, 42)))
    Fp = thetap_arb(B) / ARB_PI + SPp_arb(B)
    pos = Fp.lower() > 0
    allpos = allpos and pos
    slopes.append((j, Fp))
    if j % 25 == 0 or j in (1, 144, 153) or not pos:
        print(f"  n={j:3d}  F'(gamma_F) in [{float(Fp.lower()):.4f}, {float(Fp.upper()):.4f}]"
              f"  > 0: {pos}", flush=True)
print(f"  all 153 slopes certified positive: {allpos}   ({time.time()-t0:.1f}s)")
smin = min(float(Fp.lower()) for (_, Fp) in slopes)
smax = max(float(Fp.upper()) for (_, Fp) in slopes)
print(f"  slope range over the roots: [{smin:.4f}, {smax:.4f}]")

csvp = HERE + r"\forcing_deficit_refined.csv"
with open(csvp, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["n", "D_lo", "D_hi", "Fprime_lo", "Fprime_hi", "grade"])
    for ((j, D, cert, _), (j2, Fp)) in zip(refined, slopes):
        assert j == j2
        w.writerow([j, f"{float(D.lower()):.9f}", f"{float(D.upper()):.9f}",
                    f"{float(Fp.lower()):.6f}", f"{float(Fp.upper()):.6f}",
                    "CERTIFIED" if cert else "NUMERICAL(#144)"])
print(f"wrote {csvp}")
print("\nStage 1c complete. Not RH/GRH.")
