r"""
FORCING campaign, EXECUTION session 2026-08-02 — STAGE 1:
THE CERTIFIED FORCING-GAP TABLE.

Object: per-zero certified enclosures of |gamma_F(n) - gamma_true(n)|, n = 1..153,
where
  gamma_F(n) = the n-th crossing of theta/pi + S_P = n - 1/2
               (the prime-built F-ladder: theta = pure conductor/geometry data
               Q = 21^10, mu = (0,0,0,0,1/2,1/2,1/2,1/2); S_P = Euler-product
               prime data, P = 2e5, 18,120 prime-power terms; ZEROS USED NOWHERE),
  gamma_true(n) = the n-th certified zero of L(s, chi8)
               (07-19 production run: 153 brackets, 152 ball-certified,
               #144 numerical-only pending BRACKET144_CERT).

Certified inputs (read-only):
  (F)  WALL_KLMN_ARB_CERT_2026-07-31/quantiles_certified.json — M-233 arb-IVT
       root balls for the F-ladder, n = 1..300, max rel radius 2.6e-11.
       SPOT RE-VERIFIED here (own arb IVT sign check, independent code path
       rebuilt from the same frozen definitions) at n in SPOT_NS before use.
  (T)  to_Ilya_CERTIFIED_spectrum_2026-07-19/results/certified_run_brackets.csv —
       the certified truth brackets [lo, hi] + certified flag.

Arithmetic: the gap enclosure is EXACT rational interval arithmetic
(fractions.Fraction on the decimal strings; all inputs are exact decimals /
binary floats, so NO rounding enters; final display rounded OUTWARD to 12 dp).
For gamma in [blo, bhi] and phi in [flo, fhi]:
  |phi - gamma| in [max(0, blo - fhi, flo - bhi), max(bhi - flo, fhi - blo)].

Grade per row: CERTIFIED if bracket certified AND F-ball certified (M-233 +
spot re-verification); NUMERICAL for n = 144 (bracket not ball-certified).

Not RH/GRH — finite-range only; the n -> infinity statement is the wall (R-209)
and is not claimed.
"""
import sys, csv, json, time
from fractions import Fraction

MAIN = r"C:\Users\selin\OneDrive\Desktop\Ilya Riemanns"
HERE = r"C:\Users\selin\OneDrive\Desktop\Ilya Riemanns\.claude\worktrees\suspicious-lumiere-dbbf9e\FORCING_EXECUTION_2026-08-02"
QCJSON = MAIN + r"\WALL_KLMN_ARB_CERT_2026-07-31\quantiles_certified.json"
BRACKS = MAIN + r"\to_Ilya_CERTIFIED_spectrum_2026-07-19\results\certified_run_brackets.csv"

SPOT_NS = list(range(1, 154))   # FULL re-verification of every row used (own arb IVT)

# ---------------------------------------------------------------- load inputs
with open(QCJSON) as f:
    QC = json.load(f)
assert QC["nmax"] >= 153 and QC["monotone_F"], "F-ladder input sanity"
rows_F = {r["n"]: r for r in QC["rows"]}

br = []
with open(BRACKS) as f:
    for r in csv.DictReader(f):
        br.append((int(r["j"]), r["lo"], r["hi"], r["certified"] == "True"))
assert len(br) == 153 and sum(1 for b in br if b[3]) == 152, "bracket input sanity"

# ------------------------------------------------- spot arb IVT re-verification
# Independent re-check of the M-233 F-ball certification at SPOT_NS: rebuild
# theta and S_P from the frozen definitions and prove f(mid-rad) < 0 < f(mid+rad)
# in arb interval arithmetic (f = theta/pi + S_P - (n - 1/2), increasing at the
# selected crossing).  This is the verify-before-use gate for input (F).
import numpy as np, mpmath as mp
from flint import arb, acb, ctx
sys.path.insert(0, MAIN + r"\Operator_program_addendum")
from gen_an_chi8 import LOC8, frob_class

mp.mp.dps = 45
ctx.prec = 200
MU = [0, 0, 0, 0, 1, 1, 1, 1]
ARB_PI = arb.pi()
ARB_LOGPI = ARB_PI.log()
ARB_LOGQ = (arb(21) ** 10).log()

def theta_arb(t):
    v_im = (t / 2) * ARB_LOGQ
    for m_ in MU:
        v_im += -(t / 2) * ARB_LOGPI
        z = acb(arb(1 + 2 * m_) / 4, t / 2)
        v_im += z.lgamma().imag
    return v_im

def newton_ps(loc, kmax):
    deg = len(loc) - 1
    e = [((-1) ** i) * loc[i] for i in range(len(loc))]
    p = [0] * (kmax + 1)
    for k in range(1, kmax + 1):
        s = ((-1) ** (k - 1)) * k * e[k] if k <= deg else 0
        for i in range(1, min(k - 1, deg) + 1):
            s += ((-1) ** (i - 1)) * e[i] * p[k - i]
        p[k] = s
    return p[1:]

print("building S_P term list (P=2e5)...", flush=True)
P_MAX = 200000
isp = np.ones(P_MAX + 1, bool); isp[:2] = False
for q in range(2, int(P_MAX ** .5) + 1):
    if isp[q]: isp[q * q::q] = False
TERMS = []
for p in np.nonzero(isp)[0]:
    p = int(p); kmax = 1
    while p ** (kmax + 1) <= P_MAX: kmax += 1
    tr = newton_ps(LOC8[frob_class(p)], kmax)
    for k in range(1, kmax + 1):
        TERMS.append((int(tr[k - 1]), k, p))
print(f"  {len(TERMS)} prime-power terms", flush=True)
assert len(TERMS) == 18120, "frozen S_P definition: 18,120 terms expected"

print("building arb S_P coefficients...", flush=True)
_co_arb = [arb(tr) / arb(k) / (arb(p) ** k).sqrt() for (tr, k, p) in TERMS]
_lg_arb = [arb(k) * arb(p).log() for (tr, k, p) in TERMS]

def SP_arb(t):
    acc = arb(0)
    for c, l in zip(_co_arb, _lg_arb):
        acc += c * (t * l).sin()
    return -(arb(1) / ARB_PI) * acc

def f_arb(g_arb, n):
    return theta_arb(g_arb) / ARB_PI + SP_arb(g_arb) - arb(2 * n - 1) / 2

print("spot re-verifying M-233 F-balls (own arb IVT sign check)...", flush=True)
t0 = time.time()
for n in SPOT_NS:
    r = rows_F[n]
    mid = mp.mpf(r["gF_mid"]); rad = mp.mpf(repr(r["gF_rad"]))
    flo = f_arb(arb(mp.nstr(mid - rad, 42)), n)
    fhi = f_arb(arb(mp.nstr(mid + rad, 42)), n)
    ok = (flo.upper() < 0) and (fhi.lower() > 0)
    if (n % 25 == 0) or (n in (1, 144, 153)) or not ok:
        print(f"  n={n:3d}  f(mid-rad)<0: {flo.upper() < 0}   f(mid+rad)>0: {fhi.lower() > 0}"
              f"   -> {'VERIFIED' if ok else 'FAILED'}", flush=True)
    if not ok:
        raise SystemExit(f"SPOT RE-VERIFICATION FAILED at n={n} — do not use input (F).")
print(f"  spot re-verification: {len(SPOT_NS)}/{len(SPOT_NS)} PASSED ({time.time()-t0:.1f}s)")

# ------------------------------------------------------- exact gap enclosures
def frac(s):
    return Fraction(s)

def ceil12(x):   # outward (away from zero is not needed: gaps are >= 0)
    q = Fraction(10) ** 12
    return float(-((-x) * q // 1) / q) if x >= 0 else float((x * q // 1) / q)

def floor12(x):
    q = Fraction(10) ** 12
    return float((x * q // 1) / q)

out = []
for (j, lo_s, hi_s, cert) in br:
    blo, bhi = frac(lo_s), frac(hi_s)
    rF = rows_F[j]
    fm = frac(rF["gF_mid"]); frad = Fraction(repr(rF["gF_rad"]))  # decimal repr of float, exact enough (outward below)
    # widen the F radius outward by 2 ulp-scale margin to keep the enclosure safe
    frad = frad * Fraction(1000000000001, 1000000000000) + Fraction(1, 10**30)
    flo, fhi = fm - frad, fm + frad
    glo = max(Fraction(0), blo - fhi, flo - bhi)
    ghi = max(bhi - flo, fhi - blo)
    assert ghi >= glo >= 0
    out.append((j, floor12(glo), ceil12(ghi), cert,
                float(fm), float((blo + bhi) / 2)))

# --------------------------------------------------------------- write + stats
csvp = HERE + r"\forcing_gap_table.csv"
with open(csvp, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["n", "gap_lo", "gap_hi", "grade", "gammaF_mid", "bracket_mid"])
    for (j, glo, ghi, cert, fmid, bmid) in out:
        w.writerow([j, f"{glo:.12f}", f"{ghi:.12f}",
                    "CERTIFIED" if cert else "NUMERICAL(#144)", f"{fmid:.12f}", f"{bmid:.12f}"])
print(f"wrote {csvp}")

certified = [(j, glo, ghi) for (j, glo, ghi, cert, *_ ) in out if cert]
ghis = sorted(g for (_, _, g) in certified)
import statistics
print("\n=== THE CERTIFIED FORCING-GAP TABLE — n-profile (152 certified rows) ===")
print(f"  max  gap_hi = {max(ghis):.6f}   (at n = {max(certified, key=lambda r: r[2])[0]})")
print(f"  min  gap_hi = {min(ghis):.6f}   (at n = {min(certified, key=lambda r: r[2])[0]})")
print(f"  median gap_hi = {statistics.median(ghis):.6f}")
print(f"  mean   gap_hi = {statistics.mean(ghis):.6f}")
q = lambda p: ghis[int(p * (len(ghis) - 1))]
print(f"  quartiles: 25% {q(.25):.6f}  50% {q(.5):.6f}  75% {q(.75):.6f}  90% {q(.9):.6f}")
n144 = [r for r in out if r[0] == 144][0]
print(f"  n=144 (NUMERICAL): gap in [{n144[1]:.6f}, {n144[2]:.6f}]")
# resolution: enclosure slack vs physical gap
slack = max(ghi - glo for (_, glo, ghi) in certified)
print(f"  max enclosure slack (gap_hi - gap_lo) over certified rows = {slack:.3e}")
print(f"  -> the physical gap is resolved wherever gap_lo > 0: "
      f"{sum(1 for (_, glo, _) in certified if glo > 0)}/152 rows")

# per-decade profile
print("\n  n-profile (mean gap_hi per block of 25):")
for a in range(0, 150, 25):
    blk = [g for (j, _, g) in certified if a < j <= a + 25]
    if blk:
        print(f"    n {a+1:3d}-{a+25:3d}: mean {statistics.mean(blk):.5f}  max {max(blk):.5f}")

print("\nStage 1 complete. Not RH/GRH.")
