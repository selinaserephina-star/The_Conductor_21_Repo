r"""
FORCING campaign, EXECUTION session 2026-08-02 — STAGE 1b:
THE MECHANISM — certified fluctuation-deficit enclosures + the first-order law.

The exact identity (definitional, convention-free):
  Let F_n(t) = theta(t)/pi + S_P(t) - (n - 1/2)  (the ladder residual).
  F_n(gamma_F(n)) = 0 by construction.  Define at the TRUE zero
     S*(gamma_n) := n - 1/2 - theta(gamma_n)/pi        (the crossing value the
                                                        true fluctuation takes),
     D_n        := S_P(gamma_n) - S*(gamma_n)  =  F_n(gamma_n).
  Then the ENTIRE forcing gap is the truncated-Euler fluctuation deficit:
     gamma_F(n) = gamma_n  <=>  D_n = 0,  and by the MVT
     |gamma_F(n) - gamma_n| = |D_n| / F_n'(xi_n),   xi_n between the two.

This script:
  (1) CERTIFIED: arb enclosures of D_n for every bracket (ball evaluation of
      theta and S_P over the certified bracket interval) -> max_n |D_n| upper.
  (2) CERTIFIED: L1 = sum |co * lg| (arb upper) -> sup_t |S_P'| <= L1/pi.
  (3) displayed: the first-order prediction pred_n = |D_n| / F'(gamma_F(n))
      against the actual gap (float; MVT point unknown, so ratio ~ 1 up to the
      variation of F' on the gap interval — that variation is the honest slack).
  (4) The a-priori vs realized comparison: G-C2 unconditional |S| <= 15.899 on
      [7,30] (+ |S_P| <= 0.901946 recorded) vs the realized max |D_n|.

Inputs read-only; brackets = certified truth; #144 numerical.  Not RH/GRH.
"""
import sys, csv, json, statistics
import numpy as np, mpmath as mp
from flint import arb, acb, ctx

MAIN = r"C:\Users\selin\OneDrive\Desktop\Ilya Riemanns"
HERE = r"C:\Users\selin\OneDrive\Desktop\Ilya Riemanns\.claude\worktrees\suspicious-lumiere-dbbf9e\FORCING_EXECUTION_2026-08-02"
QCJSON = MAIN + r"\WALL_KLMN_ARB_CERT_2026-07-31\quantiles_certified.json"
BRACKS = MAIN + r"\to_Ilya_CERTIFIED_spectrum_2026-07-19\results\certified_run_brackets.csv"
sys.path.insert(0, MAIN + r"\Operator_program_addendum")
from gen_an_chi8 import LOC8, frob_class

mp.mp.dps = 45
ctx.prec = 200
MU = [0, 0, 0, 0, 1, 1, 1, 1]
ARB_PI = arb.pi()
ARB_LOGPI = ARB_PI.log()
ARB_LOGQ = (arb(21) ** 10).log()

def theta_arb(t):
    v_im = (t / 2) * ARB_LOGQ
    for m_ in MU:
        v_im += -(t / 2) * ARB_LOGPI
        z = acb(arb(1 + 2 * m_) / 4, t / 2)
        v_im += z.lgamma().imag
    return v_im

def newton_ps(loc, kmax):
    deg = len(loc) - 1
    e = [((-1) ** i) * loc[i] for i in range(len(loc))]
    p = [0] * (kmax + 1)
    for k in range(1, kmax + 1):
        s = ((-1) ** (k - 1)) * k * e[k] if k <= deg else 0
        for i in range(1, min(k - 1, deg) + 1):
            s += ((-1) ** (i - 1)) * e[i] * p[k - i]
        p[k] = s
    return p[1:]

print("building S_P term list (P=2e5)...", flush=True)
P_MAX = 200000
isp = np.ones(P_MAX + 1, bool); isp[:2] = False
for q in range(2, int(P_MAX ** .5) + 1):
    if isp[q]: isp[q * q::q] = False
TERMS = []
for p in np.nonzero(isp)[0]:
    p = int(p); kmax = 1
    while p ** (kmax + 1) <= P_MAX: kmax += 1
    tr = newton_ps(LOC8[frob_class(p)], kmax)
    for k in range(1, kmax + 1):
        TERMS.append((int(tr[k - 1]), k, p))
assert len(TERMS) == 18120
_co_arb = [arb(tr) / arb(k) / (arb(p) ** k).sqrt() for (tr, k, p) in TERMS]
_lg_arb = [arb(k) * arb(p).log() for (tr, k, p) in TERMS]

def SP_arb(t):
    acc = arb(0)
    for c, l in zip(_co_arb, _lg_arb):
        acc += c * (t * l).sin()
    return -(arb(1) / ARB_PI) * acc

# (2) certified Lipschitz constant of S_P:  sup |S_P'| <= (1/pi) sum |co|*lg
L1 = arb(0)
for c, l in zip(_co_arb, _lg_arb):
    L1 += abs(c) * l
LIP = L1 / ARB_PI
print(f"certified: sum|co*lg| = {L1}  ->  sup|S_P'| <= {LIP.upper()} (upper)")

# float S_P' for the displayed F' (analytic derivative, numpy)
_co_np = np.array([float(mp.mpf(tr) / k * mp.mpf(p) ** (mp.mpf(-k) / 2)) for (tr, k, p) in TERMS])
_lg_np = np.array([float(k * mp.log(p)) for (tr, k, p) in TERMS])
def SPp_np(t):
    return float(-(1.0 / np.pi) * np.sum(_co_np * _lg_np * np.cos(float(t) * _lg_np)))
def SP_np(t):
    return float(-(1.0 / np.pi) * np.sum(_co_np * np.sin(float(t) * _lg_np)))

LOGQ_F = float(mp.log(mp.mpf(21) ** 10))
def thetap_np(t):
    # theta'(t) = logQ/2 - 4 log pi + (1/2) sum Re psi((1/2+m)/2 + it/2)
    s = LOGQ_F / 2 - 4 * float(mp.log(mp.pi))
    for m_ in MU:
        s += 0.5 * float(mp.re(mp.digamma(mp.mpf(1 + 2 * m_) / 4 + 1j * mp.mpf(t) / 2)))
    return s

# ---------------------------------------------------------------- load inputs
with open(QCJSON) as f:
    rows_F = {r["n"]: r for r in json.load(f)["rows"]}
br = []
with open(BRACKS) as f:
    for r in csv.DictReader(f):
        br.append((int(r["j"]), r["lo"], r["hi"], r["certified"] == "True"))

# --------------------------------------------- (1) certified D_n enclosures
print("\ncertifying deficit enclosures D_n = S_P(gamma_n) - S*(gamma_n) ...", flush=True)
out = []
for (j, lo_s, hi_s, cert) in br:
    B = arb(lo_s).union(arb(hi_s))          # ball covering the whole bracket
    Sstar = arb(2 * j - 1) / 2 - theta_arb(B) / ARB_PI
    D = SP_arb(B) - Sstar
    out.append((j, D, cert, lo_s, hi_s))
    if j % 25 == 0 or j in (1, 144, 153):
        print(f"  n={j:3d}  D_n in [{float(D.lower()):+.6f}, {float(D.upper()):+.6f}]"
              f"  (rad {float(D.rad()):.2e}){'' if cert else '  [NUMERICAL]'}", flush=True)

certD = [(j, D) for (j, D, cert, *_ ) in out if cert]
absU = [max(abs(float(D.lower())), abs(float(D.upper()))) for (_, D) in certD]
mids = [float(D.mid()) for (_, D) in certD]
jmax, _ = max(zip([j for (j, _) in certD], absU), key=lambda z: z[1])
print(f"\n  max_n |D_n| <= {max(absU):.6f}   (attained near n = {jmax})")
print(f"  mean D_n (mids) = {statistics.mean(mids):+.6f}   (convention check: ~0, no off-by-one)")
print(f"  median |D_n| (mids) = {statistics.median(abs(m) for m in mids):.6f}")
print(f"  max certified radius of D_n = {max(float(D.rad()) for (_, D) in certD):.3e}")

# ------------------------------- (3) displayed first-order prediction check
print("\nfirst-order law: pred = |D_n| / F'(gamma_F)   vs   actual gap (displayed)")
ratios = []
rows_out = []
for (j, D, cert, lo_s, hi_s) in out:
    gF = float(mp.mpf(rows_F[j]["gF_mid"]))
    bmid = (float(mp.mpf(lo_s)) + float(mp.mpf(hi_s))) / 2
    actual = abs(gF - bmid)
    Fp = thetap_np(gF) / np.pi + SPp_np(gF)
    Dm = float(D.mid())
    pred = abs(Dm) / Fp if Fp > 0 else float("nan")
    ratio = pred / actual if actual > 1e-12 and Fp > 0 else float("nan")
    if cert and Fp > 0:
        ratios.append(ratio)
    rows_out.append((j, float(D.lower()), float(D.upper()), Fp, pred, actual, ratio, cert))

good = [r for r in ratios if not np.isnan(r)]
print(f"  rows with F'(gamma_F) > 0: {sum(1 for r in rows_out if r[3] > 0)}/153")
print(f"  ratio pred/actual over certified rows: median {statistics.median(good):.3f}, "
      f"quartiles [{sorted(good)[len(good)//4]:.3f}, {sorted(good)[3*len(good)//4]:.3f}], "
      f"min {min(good):.3f}, max {max(good):.3f}")
within2 = sum(1 for r in good if 0.5 <= r <= 2.0)
print(f"  within a factor 2: {within2}/{len(good)}  "
      f"(slack source: F' varies on the gap interval; sup|S_P'| <= {float(LIP.upper()):.1f})")

# ------------------------------------------------- (4) a-priori vs realized
print("\na-priori vs realized (the logical-vs-sharp comparison):")
print("  G-C2 unconditional pointwise |S| <= 15.899 on [7,30]  (PZ-derived, no zero input)")
print("  |S_P| <= 0.901946 (recorded, dense-scan+Lipschitz grade)")
print(f"  => a-priori |D_n| <= ~16.8 unconditional;   realized (certified): max |D_n| <= {max(absU):.4f}")
print("  the certified table is the sharp instrument; the a-priori bound is the logical one.")

csvp = HERE + r"\forcing_mechanism_table.csv"
with open(csvp, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["n", "D_lo", "D_hi", "Fprime_at_gammaF", "pred_gap", "actual_gap_mid",
                "ratio_pred_over_actual", "grade"])
    for (j, dlo, dhi, Fp, pred, actual, ratio, cert) in rows_out:
        w.writerow([j, f"{dlo:.9f}", f"{dhi:.9f}", f"{Fp:.6f}", f"{pred:.6f}",
                    f"{actual:.6f}", f"{ratio:.4f}" if not np.isnan(ratio) else "n/a",
                    "CERTIFIED" if cert else "NUMERICAL(#144)"])
print(f"\nwrote {csvp}")
print("\nStage 1b complete. Not RH/GRH.")
