# FINDINGS — FORCING campaign execution session 1 (2026-08-02)

**The campaign staged 2026-07-21 (registry seam 9, "STAGED, never executed"),
now executed: stage 1 (certified forcing-gap table) COMPLETE at certified grade,
stages 1b/1c (mechanism + refinements) COMPLETE, stage 2 (P-scaling) light pass
MEASURED. The theorem statement with all displayed constants:
`THEOREM_FORCING_FINITE_RANGE.md` (this folder). Not RH/GRH.**

## What ran (scripts + logs, this folder)

| script | what | grade | runtime |
|---|---|---|---|
| `forcing_gap_table.py` | full independent arb-IVT re-certification of all 153 M-233 F-root balls (own code path) + exact rational interval gap table vs the certified brackets | CERTIFIED | ~10 s |
| `forcing_mechanism.py` | certified deficit enclosures D_n = S_P(γ_n) − S*(γ_n) (arb ball over each bracket); certified sup|S_P′| ≤ 188.8038; first-order law check | CERTIFIED + displayed | ~40 s |
| `forcing_refine.py` | subdivided D_n enclosures (cells ≤ 2e-4; tightens wide brackets); arb-certified F′(γ_F(n)) > 0 all 153 | CERTIFIED | ~5 s |
| `forcing_assignment_check.py` | unambiguous-assignment: own-gap upper < neighbor-distance lower, exact rationals | CERTIFIED | <1 s |
| `forcing_p_scaling.py` | F-ladders rebuilt at P = 1e6, 1e7 (float witness, seeded from certified roots) | MEASURED | ~2 min |

Inputs (read-only): M-233 `quantiles_certified.json` (F-side; **re-verified here
153/153 before use** — the verify-before-use gate), the 07-19
`certified_run_brackets.csv` (truth side), `gen_an_chi8.py` (LOC8/frob_class,
frozen). No sent folder touched.

## Headline results

1. **The certified forcing-gap table exists** (deliverable of stage 1 as staged):
   152 certified rows + #144 numerical; max 0.061263, median 0.016450; every
   physical gap resolved (gap_lo > 0, 152/152). Median detune = 9.3 % of the mean
   zero spacing, worst = 34.6 %.
2. **Unambiguous assignment (new, beyond the staged spec)**: each of the 153
   crossings is certified strictly closer to its own zero than to either
   neighbor (worst ratio 0.551 at n = 126). "Sounds the first ~150 zeros" is now
   a per-note identification, not a statistical fit.
3. **The mechanism closes quantitatively**: D_n enclosures certified
   (max ≤ 0.4114, 41× under the unconditional G-C2 envelope 16.8); slopes
   certified positive [2.27, 10.60]; first-order law |γ_F − γ| = |D|/F′ verified
   at ratio median 1.000, quartiles [0.991, 1.013]. The staged prediction
   "gap ~ |S_P − S|(γ_n)/ρ_n" is CONFIRMED in its exact form.
4. **Stage-2 measured law is a saturation, not a convergence** (full-value
   honest result): median gap shrinks only ×1.36 across P = 2e5 → 1e7
   (effective P^−0.078), 55/152 rows individually worse. Matches the
   anatomy-ladder Euler-depth saturation (2026-07-26) on a new observable (the
   forcing gap itself). Practical consequence: the P = 2e5 finite-range theorem
   is essentially as good as this instrument gets at fixed range; the residual
   is the phase/placement layer = wall territory (R-013 upheld again).
5. **Independent reproduction en route**: sup|S_P′| ≤ 188.8038 re-derived
   (recorded value 188.804, T2a audit); M-233 ball radii confirmed by full
   re-certification.

## Corrections / traps encountered

- None of the seven standing traps fired; prec 200 bits sufficed everywhere
  (no 16k wide-ball regime approached).
- The naive single-ball D_n enclosure over wide brackets (#125/#143/#144/#153)
  inflates max|D_n| to 0.63; subdivision (cells ≤ 2e-4) brings it to 0.4114.
  Recorded as method note: deficit enclosures over brackets must be subdivided
  at width ≳ 1e-3.

## Ledger / registry

- Ledger: dated section-9 entry appended (this session).
- Registry: seam 9's "STAGED, never executed" is now stale → flip staged for
  IB's markup pass (per §14 discipline, not entered unilaterally): proposed row
  draft M-236 (finite-range forcing theorem, constants as in the THEOREM file).

## Continuation (see CAMPAIGN_STATE.md)

Stage 2 certification upgrade (spot arb rows at P = 1e6/1e7), stage 3 (the
Weil-smoothed ladder — the provable-convergence variant), stage 4 packaging
(seal `to_Ilya_FORCING_FINITE_RANGE` once #144 verdict lands), stage 5 = G4
already partially executed (M-228). #144 row upgrade pending
`BRACKET144_CERT_2026-08-02` (parallel session).

Not RH/GRH.
