# FINDINGS — THE PRIME PLACEMENT TAX, DERIVED AND RECHARACTERIZED (and one resonance killed)

**Merkabit · Stenberg + Claude · 2026-08-02 (fourth act). Scripts:
`tax_derivation.py` + `tax_control.py` + logs (incl. `tax_control_seeds5to10.log`).
Inputs: `quantiles_certified_600.json` (1200 certified roots); strings via arb
Lanczos (M-scaled precision, trace gate every build). Grade: MEASURED, with one
decisive REFUTATION and one scale-level derivation. Fail-first honored — the
staged hypothesis died and something better replaced it. Not RH/GRH.**

## 1. The staged hypothesis is REFUTED (decisively)

Hypothesis (from the M-scaling session): tax ≈ #{adjacent pairs squeezed by S_P
below half the local gap} ≈ 7 merged quadrature pairs.

**Both legs fail:**
- There are NO squeezed pairs. Min gap ratio r_n = gap_F(n)/gap_D(n) over all
  599 pairs = **0.5713** (at n = 4); #(r < 0.5) = **0** in every window of n.
  Predicted tax under the mechanism: **0**, at every (M, k) cell. Measured: +6/+7.
- The tax is not pair-localized. The set difference (F-missed \ D-missed) is
  **23–42 atoms per cell**, spread across the resolution boundary zone (e.g.
  n ≈ 340–500 at M=600, k=500), with ZERO overlap with even the r < 0.6 pairs.
  The "+7" is the **NET of a broad two-way exchange**: F misses ~30 atoms that D
  resolves, D misses ~23 that F resolves. There are no "7 casualties" — there is
  a wide margin where the two strings resolve different atoms, imbalanced by ~7
  against the prime-dressed one. (Verified under a common-measuring-stick
  control: the exchange and its sign survive when both strings are scored
  against the D-gap scale — not a metric artifact.)

## 2. The resonance with the ~7% δA/δB layer is DEAD

The S_P gap modulation has **rms 22.6%** (excess kurtosis 1.0) — not 7%; and a
7%-Gaussian layer would produce exactly zero sub-half-gap pairs (7σ event), so
the two sevens share no mechanism even numerically. **Coincidence; do not
romanticize.** (Also consistent with the DAB spectrometer verdict: per-prime
structure refuted there; the placement tax is likewise not a per-prime or
per-pair object.)

## 3. What the tax IS (the positive derivation, scale grade)

Permutation control: synthetic strings with the SAME gap-modulation
distribution (the actual r_n sequence, randomly permuted — amplitude kept,
correlation structure destroyed), 10 seeds × 2 cells (M=600, k=500/550):

- synthetic net tax = **+10.2 ± 3.4** (range +4…+17)
- real F net tax    = **+6 / +7**

**Verdict: the placement tax is an amplitude-driven spacing-disorder penalty at
the quadrature resolution boundary.** Its scale (~+10 for 22.6% rms modulation
at these fill fractions) follows from the fluctuation DISTRIBUTION alone — no
arithmetic ordering needed. That derives the constant's order and its k/M-
independence (the boundary zone width, not the string depth, sets it).

**Open tail — RESOLVED same session (50-seed batch, `tax_control_50.py` +
`tax_control_50_run.log`; decision rule pre-registered in the script header
before the run):** cells k = 450/500/550 at M = 600, statistic = net tax vs D
per cell and the 3-cell sum. **The real string lies BELOW THE ENTIRE 50-SEED
NULL RANGE on the sum: real +17 vs null +35.10 ± 5.94 (range +25…+49);
percentile 0, one-sided p < 1/51; effect ≈ 3.0σ.** Per cell: +4 vs 13.64 ± 3.39
(k = 450, below the null's minimum +6), +6 vs 11.26 ± 4.23, +7 vs 10.20 ± 2.53.
**COHERENCE PROTECTION IS REAL at this instrument: the true S_P correlation
structure roughly HALVES the placement damage (protection factor ≈ 17/35 ≈
0.48) relative to equal-amplitude decorrelated disorder.** The primes are
structured roughness, not noise — the quadrature partially accommodates their
coherent component. Echo of the bounded-disorder family (M-228: bounded
disorder reinforces limit-point) with the arithmetic now located WHERE the
placement layer said it lives: in the coherence of the fluctuation, not its
amplitude. Honest scope: one instrument (missed-count metric), one M, three
correlated cells; k = 450 carries the strongest single-cell signal; grade
MEASURED with pre-registered decision rule.

## 4. Net effect on the ledger of claims

- "Constant ~7 prime placement tax" (M-scaling FINDINGS §Q3): stands as
  measured, now RECHARACTERIZED — net imbalance of a broad exchange zone;
  scale derived from the modulation amplitude; NOT a count of 7 objects.
- The 7↔7% numerology: killed before anyone welded it.
- The placement-layer story is strengthened in the direction that matters: the
  tax is generic disorder mechanics driven by the S_P amplitude — the
  *specific* arithmetic information lives, if anywhere, in the sub-null
  protective margin, which is exactly the coherent-layer question again
  (readout-level coherence, ρ_s work) — the same residual, met a fifth way.

Not RH/GRH — instruments and controls at finite range; the wall (R-209) is
untouched.
