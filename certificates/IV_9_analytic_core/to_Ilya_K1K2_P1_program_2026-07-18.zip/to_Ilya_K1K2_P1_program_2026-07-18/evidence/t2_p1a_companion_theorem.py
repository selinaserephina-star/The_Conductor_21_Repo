# t2_p1a_companion_theorem.py — (P1a) FOR THE COMPANION: the exact integral representation
# and the proven 1/(1+i) bound, verified end to end.
#
# Chain (all exact for the INFINITE companion system):
#  (1) chat^L_i(m) = 2 sqrt(4i+1) sum_{n<=m} (-1)^{n+1} J_{2i+1/2}(z_n) / z_n^{3/2},
#      z_n = (n-1/2)pi   [value law, Theorem B1]
#  (2) Poisson + Parseval turn to the string side: chat = sqrt(4i+1) int_0^1 Gt_m P_2i dt,
#      Gt_m(t) = sum_{n<=m} (-1)^{n+1}(2/z_n)cos(z_n t);  Gt_inf = 1 in L^2(0,1)
#  (3) elementary identity: sum_{n<=m}(-1)^{n+1} sin(z_n t) = (-1)^{m+1} sin(m pi t)/(2 cos(pi t/2))
#  (4) IBP with (4i+1)P_2i = P'_{2i+1} - P'_{2i-1} (boundary terms VANISH: odd Legendre at 0,
#      P_{2i+1}(1)=P_{2i-1}(1)):
#      chat^L_i(m) = (-1)^m/sqrt(4i+1) * int_0^1 [sin(m pi t)/cos(pi t/2)] (P_{2i+1}-P_{2i-1}) dt
#  (5) |chat| <= L(i)/sqrt(4i+1),  L(i) := int_0^1 |P_{2i+1}-P_{2i-1}|/cos(pi t/2) dt <= C/sqrt(i)
#      [difference identity -> sin(theta) P^1_{2i}; Bernstein envelope (1-t)^{-3/4};
#       cap |F| <= 4i+1 near t=1 via cos(pi t/2) >= 1-t]  ==> sup_m |chat^L_i(m)| <= C'/(1+i).
import numpy as np
from scipy.special import jv, eval_legendre
from scipy.integrate import quad

# ---------- (3) elementary identity ----------
rng = np.random.default_rng(0)
err3 = 0.0
for m in [1, 2, 3, 7, 20]:
    t = rng.uniform(0.01, 0.99, 200)
    zn = (np.arange(1, m + 1) - 0.5) * np.pi
    lhs = np.array([np.sum((-1.0) ** np.arange(2, m + 2) * np.sin(zn * tt)) for tt in t])
    rhs = (-1.0) ** (m + 1) * np.sin(m * np.pi * t) / (2 * np.cos(np.pi * t / 2))
    err3 = max(err3, float(np.max(np.abs(lhs - rhs))))
print(f"(3) alternating-sin identity: max abs err = {err3:.2e}")

# ---------- (1) vs (4): value-law sum vs integral representation ----------
def chat_bessel(i, m):
    n = np.arange(1, m + 1, dtype=float)
    zn = (n - 0.5) * np.pi
    return np.sqrt(2.0 * np.pi * (4 * i + 1)) * np.sum((-1.0) ** (n + 1) * jv(2 * i + 0.5, zn) / zn ** 1.5)

def chat_integral(i, m):
    def f(t):
        return (np.sin(m * np.pi * t) / np.cos(np.pi * t / 2)
                * (eval_legendre(2 * i + 1, t) - eval_legendre(2 * i - 1, t)))
    val, err = quad(f, 0.0, 1.0, limit=400)
    return (-1.0) ** (m + i + 1) * val / np.sqrt(4 * i + 1), err

print("(1)=(4) integral representation check:")
worst = 0.0
for i in [1, 2, 5, 10, 30]:
    for m in [1, 2, 5, 20, 100]:
        a = chat_bessel(i, m)
        b, qe = chat_integral(i, m)
        worst = max(worst, abs(a - b))
        if i in (1, 10) and m in (1, 20):
            print(f"  i={i:>2} m={m:>3}: bessel-sum {a:+.10e}  integral {b:+.10e}  diff {abs(a-b):.1e}")
print(f"  max |diff| over grid = {worst:.2e}")

# ---------- (5) L^1 norms and the final constant ----------
print("(5) L(i) = int |P_(2i+1)-P_(2i-1)|/cos(pi t/2) dt  and the theorem constant:")
print("   i      L(i)     sqrt(2i)L(i)   (1+i)L(i)/sqrt(4i+1)")
Lsup = 0.0; TH = 0.0
for i in [1, 2, 4, 8, 16, 32, 64, 128, 256]:
    def g(t):
        return abs(eval_legendre(2 * i + 1, t) - eval_legendre(2 * i - 1, t)) / np.cos(np.pi * t / 2)
    # integrable (1-t)^{-3/4}-type envelope; split for quad robustness
    val = 0.0
    for a, b in [(0.0, 0.5), (0.5, 0.9), (0.9, 1.0 - 1e-12)]:
        v, _ = quad(g, a, b, limit=800)
        val += v
    s = np.sqrt(2.0 * i) * val
    th = (1.0 + i) * val / np.sqrt(4 * i + 1)
    Lsup = max(Lsup, s); TH = max(TH, th)
    print(f"  {i:>4}  {val:8.5f}  {s:10.5f}  {th:12.5f}")
print(f"  sup sqrt(2i)L(i) = {Lsup:.4f}  ->  proven-form bound sup_m (1+i)|chat| <= {TH:.4f} on the grid")

# ---------- direct sup over m of (1+i)|chat| (the P1a constant itself) ----------
print("direct scan: a3_L(i) := sup_m (1+i)|chat^L_i(m)|")
A3 = 0.0
for i in [1, 2, 3, 5, 8, 12, 20, 32, 50, 80, 120, 200]:
    mcap = max(1000, 6 * (2 * i) ** 2 // max(1, int(np.pi ** 2)) + 200)
    n = np.arange(1, mcap + 1, dtype=float)
    zn = (n - 0.5) * np.pi
    terms = np.sqrt(2.0 * np.pi * (4 * i + 1)) * (-1.0) ** (n + 1) * jv(2 * i + 0.5, zn) / zn ** 1.5
    ps = np.cumsum(terms)
    a3i = (1.0 + i) * np.max(np.abs(ps))
    A3 = max(A3, a3i)
    mstar = int(np.argmax(np.abs(ps))) + 1
    print(f"  i={i:>4}: sup_m (1+i)|chat| = {a3i:.5f} (at m={mstar}, scan to {mcap}); "
          f"full-sum residual (orthogonality to 1) = {abs(ps[-1]):.1e}")
print(f"  A3_companion (measured over grid) = {A3:.5f}   [(P1a)-companion PROVEN <= C/(1+i); this is the constant]")
print("done.")
