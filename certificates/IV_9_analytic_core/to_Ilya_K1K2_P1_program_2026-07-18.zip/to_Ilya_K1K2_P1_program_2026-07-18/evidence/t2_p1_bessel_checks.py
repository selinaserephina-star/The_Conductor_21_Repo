# t2_p1_bessel_checks.py — P1 dent 2, closing checks:
#  (C1) the Parseval/Dini norm identity  sum_n J_{k+1/2}(z_n)^2 / z_n = 1/((2k+1) pi),
#       z_n = (n-1/2)pi  — the constant behind C_k = sqrt((2k+1)pi/2) in the value law
#       (proof: Poisson representation j_k(z) = ((-i)^k/2) int_{-1}^1 e^{izt} P_k(t) dt +
#        Parseval in the string ONBs {sqrt2 cos(z_n t)} (k even) / {sqrt2 sin(z_n t)} (k odd);
#        cross terms vanish: same parity -> int_0^1 P_k P_l = delta/(2k+1), opposite parity
#        -> y-side symmetry).  Numerical check with explicit tail bound.
#  (C2) truncation scaling of the finite-M companion: the S2 value-law residual at k = 10
#       halves when M doubles (128 -> 256), confirming the ~k/M truncation law, i.e. the
#       infinite system is the right limit object.
import os
import numpy as np
from scipy.special import jv
import importlib.util

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('sb', os.path.join(HERE, 't2_p1_string_bessel.py'))

print("=== (C1) Dini/Parseval norm: (2k+1) pi sum_n J_{k+1/2}(z_n)^2/z_n -> 1 ===")
NBIG = 200000
n = np.arange(1, NBIG + 1, dtype=float)
zn = (n - 0.5) * np.pi
for k in range(0, 9):
    s = np.sum(jv(k + 0.5, zn) ** 2 / zn)
    # tail: J^2/z ~ (2/(pi z))cos^2(...)/z -> mean 1/(pi z^2); tail sum < 1/(pi^3 (N-1/2)) approx
    tail = 1.0 / (np.pi ** 3 * (NBIG - 0.5))
    val = (2 * k + 1) * np.pi * s
    print(f"  k={k}: (2k+1) pi S = {val:.10f}   (tail correction < {(2*k+1)*np.pi*tail:.1e})")

print()
print("=== (C2) truncation scaling of the value-law residual at k=10 ===")
# reuse the reorthogonalized Lanczos from the string_bessel script without executing its main
import types
sb_src = open(os.path.join(HERE, 't2_p1_string_bessel.py')).read()
head = sb_src.split("M = 128")[0]
mod = types.ModuleType('sbfun')
mod.__dict__['__file__'] = os.path.join(HERE, 't2_p1_string_bessel.py')
exec(head, mod.__dict__)
for M in (128, 256):
    nn = np.arange(1, M + 1, dtype=float)
    znM = (nn - 0.5) * np.pi
    y_atoms = np.concatenate([1.0 / znM, -1.0 / znM])
    y_w = np.concatenate([1.0 / znM ** 2, 1.0 / znM ** 2])
    alY, beY, PY, drift = mod.mp_lanczos_w(y_atoms, y_w, 700, 14)
    k = 10
    o = k + 0.5
    Jv = jv(o, znM) * np.sqrt(znM)
    # oscillatory-region mask: past the turning point z > o + 2 o^{1/3}
    mask = znM > (o + 2.0 * o ** (1.0 / 3.0))
    r = PY[k, :M][mask] / Jv[mask] * (-1.0) ** np.arange(1, M + 1)[mask]
    sd = np.std(r) / abs(np.mean(r))
    cn = np.mean(r) ** 2 * 2.0 / (np.pi * (2 * k + 1))
    print(f"  M={M}: drift {drift:.1e}; k=10 ratio rel std = {sd:.3e}; C_k^2/((2k+1)pi/2) = {cn:.6f}")
print("done.")
