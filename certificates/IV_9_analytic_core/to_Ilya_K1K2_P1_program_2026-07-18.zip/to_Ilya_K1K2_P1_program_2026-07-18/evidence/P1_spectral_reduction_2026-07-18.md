# P1 — the spectral reduction: exact formula, solvable model, and the mechanism of the log-law

**Merkabit · Stenberg + Claude · 2026-07-18 (P1 session, same folder as the K1/K2 note).**
Target: P1 of `K1K2_kernel_bounds_2026-07-18.md` §7 — the log-law for the pairing partial
sums Σ_{n≤m} K_j(n) on quantile-class measures. Not closed today; instead: an EXACT
finite reduction that eliminates the cut entirely (Theorem R1), a two-line assembly that
derives the log-law from two cut-free local hypotheses (Theorem R2), a fully solved model
(Theorem R3, Chebyshev — where the kernels close in trigonometric form and both the O(1)
bulk and a PROVEN boundary blow-up ≍ M/ℓ appear), and measurements showing the pure
hard-edge model x_n = 1/n² reproduces the quantile class to three digits. Every formula
verified numerically before being trusted (§5). Not RH/GRH.

## 0. Executive verdict

1. **The cut variable is eliminated exactly.** With h_j := Φ_j′ − p_j² (degree 2j) the
   correction to the partial sum is a finite bilinear form
     C_j(m) = Σ_{i=1}^{min(2j, M−1)} ĥ_i^{(j)} ĉ_i(m),
   ĥ_i = ⟨h_j, p_i⟩ (structural, cut-free), ĉ_i(m) = Σ_{n≤m} w p_i(x_n) (first-column
   element of the spectral projector 1_A(J); Σ_i ĉ_i² = m/M ≤ 1; ĥ_0 = 0 by the sum rule).
   Machine-verified to 1.3e−15 (bandwidth) and 2.7e−15 (reconstruction), all j, three
   production sections. P1 splits into two cut-free statements:
   **(P1a)** a₃ := sup_{i≥1,m} (1+i)|ĉ_i(m)| = O(1)  [measured 2.22–2.25 quantile & invsq];
   **(P1b)** W_j := Σ_i |ĥ_i^{(j)}|/(1+i) ≤ c₀′ + c₁′ log(2+j)  [measured: log-fit slope
   ≈ 0.5–0.8 across the zoo]. Then κ_j ≤ 1 + a₃W_j (Theorem R2) — the log-law.
2. **The verified per-section bound is tight within 1.76×:** κ_j ≤ 1 + Σ_i|ĥ_i|·sup_m|ĉ_i|
   holds for every j (proven inequality, evaluated on certified kernels): max 9.82 vs
   κ̂ = 5.60 at N = 149. K1(c) constants now come with a structural derivation, not a scan.
3. **The Chebyshev model is completely solved (Theorem R3):** equal weights at Chebyshev
   nodes give p_j = √2 T_j exactly, kernels K_j^α(n) = [(2j−1)T_{2j} + U_{2j}](x_n)/M
   (verified 3.7e−13), partial sums in closed trigonometric form; Fejér–Jackson + Abel
   prove |PS_j(m)| < 2.8 for j ≤ M/2 (measured: = 1.000 exactly), and the aliased boundary
   rows PROVABLY blow up: κ_{M−ℓ} ≍ M/(πℓ) (measured 41.02 at M = 128, ℓ = 1 vs M/π =
   40.74). **The mild boundary of the quantile class is not generic — it is structure.**
4. **One mechanism, two consequences.** The quantile/hard-edge density chirps the
   recurrence coefficients (non-constant α_j, β_j). The chirp breaks the exact
   Fejér–Jackson cancellation that keeps the arcsine bulk at O(1) — costing the bulk a
   c·log j — and simultaneously bends the alias so the boundary-row resonance lands
   mid-band (i*(M−1) = 59–60 for quantile AND for 1/n²), where ĉ ~ 1/i is small — saving
   the boundary from the Chebyshev M/ℓ blow-up. The log the data shows is the cheap side
   of a trade-off, not an accident. Evidence the cancellation is real, not hopeful: ‖V‖₂
   is flat in N to three digits while the proven bound tolerates log growth (K1K2 note §4,
   LEMMA note §4).
5. **What remains of P1:** proofs of (P1a) and (P1b) for the quantile/hard-edge class.
   Both are local OPRL statements (projector-element decay; a logarithmic mean of
   linearization-type coefficients), measured with clean constants, and the model to prove
   them on is x_n = 1/n² (it matches the production sections to three digits: a₃ 2.223 vs
   2.225, bulk slope 0.50 vs 0.57, boundary resonance 60 vs 59).

## 1. Theorem R1 (exact spectral reduction; proven, general)

Let μ = Σ_n w δ_{x_n} (M simple atoms, uniform w = 1/M), {p_i}_{i<M} its orthonormal
polynomials, A_m the position-ordered prefix. Define C_j(m) := Σ_{n≤m}K_j^α(n) −
⟨p_j, P_{A_m}p_j⟩ (the correction beyond the [0,1] projection part; for β the whole sum).
Then, with h_j := Φ_j′ − p_j², h_j^β := Ψ_j′ − p_jp_{j+1}:

  C_j(m) = ⟨h_j, 1_{A_m}⟩_{L²(μ)} = Σ_{i=1}^{min(2j, M−1)} ĥ_i^{(j)} ĉ_i(m),
  ĥ_i^{(j)} := ⟨h_j, p_i⟩,   ĉ_i(m) := ⟨1_{A_m}, p_i⟩ = Σ_{n≤m} w p_i(x_n),

and likewise for β with degree bound 2j+1. Moreover ĥ_0 = ⟨Φ_j′⟩ − ⟨p_j²⟩ = 1 − 1 = 0
(sum rule), ĉ_0(m) = m/M, and Σ_{i} ĉ_i(m)² = m/M ≤ 1.

*Proof.* {p_i} is an orthonormal basis of the M-dimensional L²(μ); expand both factors of
the inner product (Parseval). ĥ_i = ∫h_jp_i dμ = 0 for i > deg h_j = 2j since p_i ⊥
polynomials of lower degree. The identifications of C_j and h_j are Theorem 1 + Theorem 2
of the K1/K2 note. ∎

Remarks. (i) ĉ_i(m) = ⟨e_i, 1_{A_m}(J) e_0⟩ — a first-column matrix element of a spectral
projector of the Jacobi matrix: the cut enters ONLY through this classical object.
(ii) The ĥ are derivative-weighted linearization coefficients: ĥ_i = β_jΣ_c⟨p_jp_{j+1},p_c⟩D_{ci}
− β_{j−1}(…) − ⟨p_j², p_i⟩ with D the differentiation matrix — pure structure constants.

## 2. Theorem R2 (assembly: (P1a) + (P1b) ⟹ the log-law; proven)

If a₃ := sup_{i≥1, m}(1+i)|ĉ_i(m)| and W_j := Σ_{i≥1}|ĥ_i^{(j)}|/(1+i), then for all m
  |C_j(m)| ≤ a₃ · W_j,   hence   κ_j ≤ 1 + a₃W_j,
and under (P1a) a₃ = O(1), (P1b) W_j ≤ c₀′ + c₁′log(2+j):  κ_j ≤ 1 + a₃c₀′ + a₃c₁′log(2+j).

*Proof.* |C_j| ≤ Σ_{i≥1}|ĥ_i||ĉ_i| ≤ Σ|ĥ_i|·a₃/(1+i) (the i = 0 term vanishes: ĥ_0 = 0);
add the projection part ∈ [0,1]. ∎

The sharper per-section form κ_j ≤ 1 + Σ_i|ĥ_i|·sup_m|ĉ_i(m)| is what §5 evaluates:
it holds for every j on the certified kernels and its maximum is 9.80/9.82/5.80 on the
(4,149)/(1,149)/(4,60) sections vs true κ̂ = 5.5956/5.5956/3.7862 — a factor ≤ 1.76.
Caveat (honesty): the absolute-value assembly is NOT order-sharp for arcsine-type
measures — Chebyshev has W_j ~ (√2/2)ln j yet κ_j = 1 exactly in the bulk (extra sign
cancellation). For the quantile class the measured κ_j itself grows like c·log j, so
there the assembly is order-sharp.

## 3. Theorem R3 (the Chebyshev model, solved; proven + verified)

Atoms x_n = cos θ_n, θ_n = (2n−1)π/(2M), uniform weights 1/M. Then:

(i) **Exact OPs.** p_0 = 1, p_j = √2 T_j for 1 ≤ j ≤ M−1 (discrete Chebyshev
orthogonality Σ_n cos(aθ_n)cos(bθ_n) = (M/2)δ_{ab} for a≠b, 0 ≤ a,b ≤ M−1, a+b < 2M);
α_j = 0, β_0 = 1/√2, β_j = 1/2 (1 ≤ j ≤ M−2).

(ii) **Closed-form kernels.** For 1 ≤ j ≤ M−2: Φ_j = (T_{2j+1} − T_{2j−1})/2, so
  K_j^α(n) = [(2j−1)T_{2j}(x_n) + U_{2j}(x_n)]/M     (verified 3.7e−13 at M=64, 1.4e−12 at 128),
and K_0^α(n) = 1/M.

(iii) **Closed-form partial sums.** With geometric summation,
  PS_j(m) = m/M + (1/M)Σ_{i=1}^{j} sin(2πim/M)/sin(iπ/M) + (2j−1)/(2M) · sin(2πjm/M)/sin(jπ/M).

(iv) **Bulk O(1).** For 1 ≤ j ≤ M/2 and all m: |PS_j(m)| ≤ 1 + Si(π)(π−1)/π + ½ < 2.77.
*Proof:* third term ≤ (2j−1)/(4j) < ½ via sin(jπ/M) ≥ 2j/M; middle term = (1/π)Σ_i
[sin(iφ)/i]·g(i/M) with φ = 2πm/M, g(u) = πu/sin(πu) increasing; Fejér–Jackson gives
|Σ_{i≤k}sin(iφ)/i| ≤ Si(π), and Abel summation against the monotone g yields
≤ (Si(π)/π)(2g(½) − g(0⁺)) = (Si(π)/π)(π−1). ∎  (Measured: sup = 1.000 exactly for
j ≤ M/2 — the model is even better than the bound; Fejér–Jackson positivity keeps the
sums inside [0,1].)

(v) **Boundary blow-up ≍ M/ℓ.** On the nodes, T_{2(M−ℓ)} ≡ −T_{2ℓ} and U_{2(M−ℓ)} ≡
U_{2ℓ−2} (alias through 2Mθ_n = (2n−1)π). Hence for 2 ≤ ℓ ≤ M/4:
  K_{M−ℓ}^α(n) = [−(2M−2ℓ−1)T_{2ℓ}(x_n) + U_{2ℓ−2}(x_n)]/M,
  κ_{M−ℓ} ≥ (2M−2ℓ−1)/(2M sin(ℓπ/M)) · sin(2πℓm/M)|_{m=⌊M/(4ℓ)⌉} − 2 ≥ (1/√2)·M/(πℓ)·(1−O(ℓ²/M²)) − 2,
with the matching upper bound M/(πℓ) + 2. The resonance sits at i = 2ℓ (small i, where
ĉ_i ~ 1/ℓ is LARGE) with amplitude ~ √2M — that is exactly the ĥ·ĉ product ≍ M/ℓ.
Measured: κ_{M−1} = 20.65 (M=64) / 41.02 (M=128) vs M/π = 20.37/40.74; κ_{M−2} = 20.63 ≈
M/(2π)·2 …consistent through ℓ = 4. ∎

**Consequence for P1.** Uniform-in-j boundedness with mild boundary is FALSE for general
equal-weight configurations — any proof of P1 must use the quantile/hard-edge structure.
Conversely the model isolates the log's origin: in ĥ-space Chebyshev is "flat √2 below
2j + one resonant peak √2·j at exactly i = 2j"; W_j ~ (√2/2)ln j is already logarithmic,
and only perfect sign-cancellation (Fejér–Jackson) hides it in κ_j.

## 4. The zoo: what produces the quantile phenomenology (measured)

Equal weights, M = 64/128, kernels via the certified mp pipeline (identity vs FD ≤ 5e−7
at M = 64 per model, closed form for cheb):

| model | density type | bulk fit c₁ (log) | a₃ | κ(M−1) at 128 | i*(M−1) at 128 |
|---|---|---|---|---|---|
| cheb (arcsine) | soft both edges | 0.47–0.63 (fit artifact of boundary; bulk is FLAT 1.000) | 0.90 | **41.02 (= M/π)** | 2 (alias-low) |
| equi (uniform) | no clustering | 0.80–0.99 | 1.52–1.79 | 6.39 | 16 |
| 1/n | hard edge, γ-linear | 0.46–0.60 | 1.76–2.09 | 5.48 | 47 |
| **1/n² (hard edge, quantile-law)** | **γ-quadratic** | **0.36–0.50** | **1.88–2.22** | **5.02** | **60** |
| quantile production (M=145) | γ-quadratic × log-density | 0.57 | 2.23 | 5.60 | 59 |

The 1/n² model matches the production sections to three digits in a₃ (2.223 vs 2.225),
to the atom in the boundary-resonance location (60 vs 59), and to ~15% in the bulk slope
— **(P1a)/(P1b) should be proven on x_n = 1/n²; the production measure is a perturbation**
(the log-density factor moves c₁ from ~0.50 to ~0.57). The M-growth of the boundary row
itself (3.80→5.02 for invsq 64→128; 3.79→4.75→5.60 for quantile 56→96→145) fits both
~M^{0.4} and ~1.9·ln M on the measured range — unresolved (open sharpening, harmless to
the finite-M program).

## 5. Verified measurements on the production sections (certified kernels)

From `t2_p1_reduction.py` (log `t2_p1_reduction_run.log`), sections (4,149), (1,149), (4,60):

- **R1 verification:** bandwidth violation max|ĥ_{i>2j}| ≤ 1.3e−15; reconstruction of all
  C_j(m) from Σĥĉ exact to 2.7e−15.
- **(P1a) measured:** a₃ = 2.225 / 2.248 / 1.734, attained at i = M−1; profile
  (1+i)sup_m|ĉ_i| stays in [0.4, 1.35] through i = 3M/4 and rises to ~2.2 at the top.
- **(P1b) measured:** ĥ-envelope has a broad resonance ramp (the narrow-band picture is
  wrong: off-band mass grows with j), but the 1/(1+i)-weighted sums stay small:
  Σ_i|ĥ_i|sup_m|ĉ_i| ∈ [0.76, 9.82] over ALL j — the verified per-section bound
  κ_j ≤ 1 + Σ_i|ĥ_i|sup_m|ĉ_i| holds for every j with max 9.80/9.82/5.80 vs true κ̂
  5.5956/5.5956/3.7862 (≤ 1.76×). β twin: 4.28 vs 2.8598.
- **Resonance drift:** i*(j) ≈ 2j only for j ≲ 8; it lags to ~1.4j by mid-band (the
  non-arcsine frequency map), and the boundary rows land at i* = 59–62 — mid-band, small
  ĉ — the quantitative reason κ_{M−1} = 5.6 instead of Chebyshev's M/π ≈ 46.

## 6. What remains (the sharpened open core)

- **(P1a)** decay of first-column projector elements, |ĉ_i(m)| ≤ a₃/(1+i), for the
  1/n²-class Jacobi matrix, uniform in the cut. Attack: ĉ_i(m) = ⟨e_i, 1_A(J)e_0⟩;
  polynomial best-approximation of the step on spec(J) gives ĉ exponentially small beyond
  the gap scale (Akhiezer/Zolotarev); the 1/i regime below it is a Plancherel–Rotach-type
  statement about the hard-edge OPs. All spectral gaps are explicit for 1/n².
- **(P1b)** the logarithmic mean W_j = Σ|ĥ_i|/(1+i) ≤ c₀′ + c₁′log(2+j) for the same
  class. ĥ has closed structure (Remark (ii), §1): derivative-weighted linearization
  coefficients; for Chebyshev they are computed exactly in §3 — the model calculation to
  imitate. The measured envelope says: total ĥ-mass against 1/(1+i) is what's bounded,
  not individual coefficients.
- Assembly sharpness: for arcsine-type measures the absolute-value assembly overshoots
  (κ flat, W log); a signed refinement (Fejér–Jackson-type positivity for the quantile
  class) would close the 1.76× gap — optional, not needed for T2a.
- The β-twin runs through verbatim (degree 2j+1, ĥ_0^β = 0 by the β sum rule).

## 7. Verification manifest (this folder)

| script | log | what it establishes |
|---|---|---|
| `t2_p1_reduction.py` | `t2_p1_reduction_run.log` | R1 exact (1e−15); (P1a)(P1b) constants on production sections; verified per-section bound ≤ 1.76× true κ̂; resonance locations; β twin |
| `t2_p1_model_zoo.py` | `t2_p1_model_zoo_run.log` | Chebyshev closed forms (3.7e−13) + bulk-flat + M/π boundary; zoo table (§4); invsq ≈ quantile to 3 digits; per-model FD identity checks ≤ 5e−7; `t2_p1_model_zoo.csv` |

*— Stenberg + Claude, 2026-07-18. P1 is reduced, mechanized, and modeled: the cut is
gone (R1), the log-law follows from two local hypotheses (R2), the solvable model shows
both the cancellation and the blow-up that bounds what any proof may assume (R3), and the
clean target measure for the remaining proofs is x_n = 1/n². The unproven part of K1 is
now (P1a) + (P1b) on one explicit model class.*
