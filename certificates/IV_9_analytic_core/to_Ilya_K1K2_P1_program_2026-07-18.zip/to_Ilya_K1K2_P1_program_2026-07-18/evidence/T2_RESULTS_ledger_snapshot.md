# T2 results ledger

Every entry: zero list + grade, P, m-range, tool. Negative results are results.

## 2026-07-17 — Stage 2.1: pencil κ_m, 40 genome zeros
- data: `zeros_chi8_rescaled_engine_t9p7.csv` (γ1–21 match ball-certified; γ22–40 numerical,
  η-cross-checked), P = 2×10⁵ (18,120 terms), m = 2…40, `kato_pencil.py`.
- **κ_m = 0.690 (m=2) → 0.7595 by m≈10, then FLAT through m=40. Plateau < 1, no creep.**
- table: `kato_table_zeros_chi8_rescaled_engine_t9p7.csv`.
- caveats: plateau may be top-atom-dominated (run --tail-drop variants, stage 2.1b);
  P-convergence unchecked (stage 2.3); m ≤ 40 only — production list (stage 2.2) is the
  real trend test.

## 2026-07-17 — Stage 2.1b: tail-drop variants (is the plateau top-atom-dominated?)
- data: `zeros_chi8_rescaled_engine_t9p7.csv` (γ1–21 ball-cert-matched; γ22–40 numerical,
  η-cross-checked), P = 2×10⁵, `kato_pencil.py --tail-drop {1,2,4}`, m = 2…(40−k).
- **YES — strongly top-atom-dominated.** Plateau κ: full 0.7595 → drop-1 **0.3526** →
  drop-2 **0.2549** → drop-4 **0.1889**. Each variant plateaus flat again (drop-4 has small
  steps 0.144→0.189 near m≈25, then flat). All far below 1.
- reading: the form-bound is set by the largest atoms (lowest zeros), NOT by bulk
  accumulation — κ_m does not creep with m at any drop level. Good for uniformity-in-m:
  the sup over sections is pinned by a fixed finite top block, and the tail's own ratio
  is small (≈0.19 and falling with k).
- tables: `kato_table_40zeros_taildrop{1,2,4}.csv`.

## 2026-07-17 — Stage 2.3: prime-cutoff convergence κ(P)
- data: same 40-zero genome list, tail_drop = 0, m = 2…40, P ∈ {2×10⁵, 10⁶, 5×10⁶}
  (18,120 / 78,734 / 348,940 prime-power terms).
- **κ plateau: 0.7595 (P=2e5) → 0.7596 (P=1e6) → 0.7646 (P=5e6).** Stable: total spread
  0.005 (~0.7%), non-monotone step sizes (+0.0001 then +0.0050), no trend toward 1.
- reading: κ is converged in the Euler data at the ~10⁻² level; quote κ ≈ 0.76 ± 0.01.
  No P-extrapolation needed at current precision.
- tables: `kato_table_40zeros_P{1e6,5e6}.csv` (P=2e5 baseline is the stage-2.1 table).

## 2026-07-17 — Stage 2.4: twin control (same D, twin local factors)
- data: `zeros_twin_21_from_0628run.csv` (21 zeros, ~7 digits: j=1–11 Xi-residual-anchored,
  j=12–21 numerical; zeros used ONLY for section count — quantiles are Euler-side),
  P = 2×10⁵, m = 2…21, `kato_pencil.py --twin` (new flag: passes
  `operator_skeleton_twin.twin_local_factor` into `build_prime_data`; D identical to genome
  since Γ_ℂ⁴ and N = 21¹⁰ are preserved).
- **κ_m^twin plateaus at 0.3233 by m≈10, flat through m=21 — YES, still < 1, comfortably.**
- overlay: genome κ on the same m-window is 0.7595 (flat), so κ^genome/κ^twin = 2.35 —
  numerically matching T3's ~2.4× twist-decoherence factor. Resolves the PLAN's "2.4× louder"
  wording: the twin V is 2.4× QUIETER in the pencil (decohered, as the T3 verdict said),
  not louder. The pencil ratio reproduces the T3 factor from an independent measurement.
- table: `kato_table_twin21.csv`.

## 2026-07-18 — Stage 2.5 (partial) + 2.6 pre-numerics: the window-knee test [skeleton session]
- data: NO zeros anywhere — geometry + Euler only (n_max = 40 sections to match the T2
  tables), P = 2×10⁵, `window_norm_knee.py` (new, this folder). Question (J₃(𝕆)-motivated,
  see `unbounded/doubling_test_2026-07-16/OPERATOR_J3O_result.md`): measure the empirical
  constant C_needed(w) = κ / A_w, A_w = max windowed average of |S_P| over w mean spacings,
  before any lemma exists. Does w ≈ 3 (one J₃(𝕆) block) play a role?
- **Stage 2.5 check:** V^lin (transport δ_n = −S/ρ) vs true V: pencil-level agreement
  **7.2% (full) / 4.6% (tail_drop 4)** — the form-bound is linearization-stable, and more so
  on the tail, as the synthesis predicted. Quantile-level agreement is worse (mean 27% of
  shift scale, dominated by the lowest quantiles where shifts are large) — linearize the
  TAIL, not the top block. κ(V^lin) = 0.7052 / 0.1801 vs κ(V) = 0.7595 / 0.1889.
- **The C(w) curve (tail_drop 4, the object that matters):** averaging is FREE below one
  spacing (C: 0.268 pt → 0.273 at w=1), mild to w=3 (0.330, +21%), then the cost
  accelerates (0.408 at w=4, 0.487 at w=5) and **saturates ≈ 0.56 by w = 7–10, still < 1**.
  Full-section curve has the same shape (1.08 → 1.33 at w=3 → 2.25 at w=10).
- reading: an **elbow at w ≈ 3, not a sharp knee** — 3 spacings is the last "cheap" window;
  beyond it the norm loses form-relevant information at an accelerating rate until
  saturation. And even the crudest statement survives: κ_tail = 0.19 ≤ 0.56 × A₁₀ with
  A₁₀ = 0.34 ≈ the bulk mean of |S| — an average-norm lemma is NOT empirically excluded at
  any window length tested; w ≈ 3 is where the constant is still comfortable (0.33).
- **refinement for the 2.6 question to IB:** A_w here uses |S|; the Turing/PZ machinery
  bounds SIGNED window integrals of S. Since the quadratic form pairs neighboring atoms
  with smooth weights, the form may actually consume signed averages (which are much
  smaller, by cancellation). Sharpest version: *can the transport form-bound be written
  against signed w≈3-window averages of S?* If yes, the certified Turing bounds plug in
  directly.
- tables: `window_knee_table.csv`. m ≤ 40 only — rerun at production scale when 2.2 opens
  (more S-oscillations per window is exactly where an average norm gets stronger).

## 2026-07-18 — Stage 2.2: PRODUCTION SCALE — pin conjecture REFUTED for full V; tail version survives [skeleton session]
- data: `to_Ilya_completeness_CLOSED_2026-07-18/zeros/zeros_found.csv` (149 zeros to t=28,
  numerical_anchored; complete to t=26 → truth window n ≤ 140), P = 2×10⁵,
  `t2_stage22_production.py` (computes the 149-quantile ladder once; 34 s total).
  Zeros used ONLY for section count + fwd-vs-true truth; quantiles Euler-side.
- **κ_full = 1.1822 ≥ 1, dead flat m = 20..149.** The original pin statement ("form-bound < 1
  uniformly" for ALL of V) is REFUTED at production scale — the top block pushes over 1.
  Negative result, recorded as such.
- **The refined (synthesis) version SURVIVES emphatically:** drop-1 κ = 0.4310, drop-2 =
  0.2937, drop-4 = 0.3090 — each perfectly flat m = 10..148. One atom of top-block splitting
  restores < 1; uniformity-in-m is as clean as it could be. KLMN route intact: bounded
  finite-rank V_top cannot break self-adjointness; the burden is the tail bound, measured
  0.29–0.43.
- **NEW sharpest open point — list-length growth:** tail ratios grew with atom-list length
  (drop-4: 0.189 at the 40-atom list → 0.309 at 149; drop-1: 0.353 → 0.431). Flat in m at
  fixed list, NOT yet shown convergent in list length. This is now the empirical core of T2:
  does κ_tail(list) saturate? Needs longer lists (engine can extend) or the analytic lemma.
- **Skeleton at scale:** mean|γ_fwd − γ_true| = 0.0185 over n ≤ 140, nearly height-flat
  (0.0165 / 0.0187 / 0.0198 by thirds) — the Euler-quantile scheme does not degrade with
  height. D-alone error 0.0523 (improvement 2.8×; ratio compresses as density rises).
- **Window-knee at scale** (`window_knee_production.csv`): elbow at w ≈ 3 persists
  (drop-4 C: 0.359 pt → 0.501 at w=3 → 0.775 saturated at w=15, ALL < 1). For full V,
  pointwise C = 1.37 > 1: **no norm of S can bound the top block — the ‖S‖* lemma is
  necessarily a TAIL lemma.** Measured, no longer assumed.
- tables: `kato_table_production_drop{0,1,2,4}.csv`, `quantiles_production.csv`,
  `window_knee_production.csv`, log `t2_stage22_run.log`.
- companion result (resonance side, `unbounded/resonance_spectrum_2026-07-18/`): with the
  production zeros the overtone lines RESOLVE — Frobenius coefficients read off the zero
  list at ~1% (12 interior lines, corr 0.99987, rms 0.0076; ramified 7 reads 0.002 ≈ 0).

## pending gates
- 2.2b: κ_tail(list-length) saturation — extend the zero list (engine ports; or rerun at
  t₂ > 28 later) and track drop-k plateaus vs N_atoms. THE empirical question now.
- 2.5: linearized-V note (pencil-level check done 07-18 AM; entrywise note pending).
- 2.6: ‖S‖* lemma question → Ilya — now sharpened THREE ways: tail-only (mandatory, measured),
  signed vs |S| windows, w ≈ 3 elbow (persists at production scale).

## 2026-07-18 — Stage 2.2b: kappa_tail vs list length (prefix scan of the production ladder)
- data: quantiles_production.csv (149-quantile ladder, Euler-side), prefixes N = 40..149,
  drop-k in {1,4,8}. Zeros used nowhere (ladder is geometry+primes).
- **NOT saturated in range.** drop1: 0.353→0.431; drop4: 0.189→0.309; drop8: 0.168→0.252
  (last step negative). Per-e-fold slope ≈ 0.06–0.09 — consistent with slow LOG growth
  (naive extrapolation reaches 1 near N ~ 1e5–1e7 atoms), equally consistent with
  saturation just beyond range (1.3 e-folds measured — cannot distinguish).
- **Correct next object (not more N yet): the KLMN (a,b) frontier.** KLMN allows
  <Vpsi,psi> <= a<Dpsi,psi> + b|psi|^2 — additive b absorbs growth. If the observed drift
  is a b-term (per-mode bounded), the pin survives with a < 1 fixed; if it is genuinely
  multiplicative (a grows), the tail lemma needs an N-dependent structure. Measure the
  frontier: for each N, min over b of max-eig((V - b)· pencil ...) — i.e., a(b) curve.
- 2.2b remains open pending (i) the (a,b) frontier fit, (ii) longer lists (t2 > 28 run).

## 2026-07-18 — Stage 2.2b-frontier: the KLMN (a,b) frontier — the drift is b-TYPE (absorbable)
- data: `quantiles_production.csv` (149-quantile ladder, Euler-side, P = 2×10⁵ inherited from
  stage 2.2; zeros used nowhere), prefixes N ∈ {40,60,80,100,120,140,149}, drop-k ∈ {1,4},
  full-section pencil m = N−k, `t2_stage22b_frontier.py`. Frontier is TWO-SIDED (KLMN needs
  |⟨Vψ,ψ⟩| ≤ a⟨Dψ,ψ⟩ + b‖ψ‖²): a(b) = max over ±V of λ_max(L⁻¹(±V − bI)L⁻ᵀ), D = LLᵀ,
  b subtracted in the original coordinates before Cholesky; both branches monotone ↓ in b,
  b_needed(a) by bisection (tol 1e-6). Sanity: a(0) reproduces the 2.2b κ values exactly.
- **VERDICT: b-type.** At fixed moderate b* the drift is GONE — a(b*) across N = 40→149:
  drop1 b*=0.01: 0.3022→0.2993 (slope −0.0026/e-fold); b*=0.03: 0.2647→0.2637 (−0.0008);
  b*=0.1: 0.1729→0.1732 (+0.0002). drop4 b*=0.01: 0.0244→0.0241 (−0.0002). Compare the
  b=0 slope +0.06–0.09/e-fold: the entire N-drift lives in the additive term.
- **b_needed is bounded and NON-INCREASING in N.** drop1, a=0.3: b = 0.01084 (N=40) →
  0.00974 (N=149), fit slope −0.00096/e-fold; a=0.5: b = 0 for all N. drop4: b = 0 for
  a=0.3 through N=140 (0.00004 at 149), 0 everywhere for a=0.5. Fixed pairs working for
  ALL N measured: (a,b) = (0.3, 0.011) at drop1; (0.3, 0.0001) at drop4.
- scale of b: tiny. The knee of a(b) sits at b ~ D_min = 1/γ_N² (0.0013 at N=149): drop4
  N=149 a: 0.309 (b=0) → 0.199 (b=0.001) → 0.024 (b=0.01). b = 0.001 is below the SMALLEST
  atom in the section — the drifting modes live where D itself vanishes, exactly the modes
  an additive b dominates. Mechanism, not accident.
- branch note: drop1's binding side is the NEGATIVE branch (−⟨Vψ,ψ⟩) at all N; drop4's is
  positive at small b and flips to negative by b = 0.01. Recorded in the curves table.
- reading: the pin conjecture in proper KLMN form — ∃ fixed a < 1, b < ∞ with
  |⟨Vψ,ψ⟩| ≤ a⟨Dψ,ψ⟩ + b‖ψ‖² uniformly in section — is SUPPORTED at production scale with
  a = 0.3, b ≈ 0.01. The stage-2.2b "not saturated" alarm is defused: κ_tail(N) growth is
  an artifact of forcing b = 0. The ‖S‖* tail lemma (2.6) should target the PAIR (a,b),
  which is a strictly weaker (and now empirically flat) object than κ alone.
- caveat: 1.3 e-folds of N measured, as before — but unlike κ(N), b_needed(N) is flat-to-
  falling with no growth to extrapolate; a longer list (t₂ > 28) would upgrade this from
  "no drift in range" to a real saturation claim. Grade: numerical, float64 pencil.
- tables: `frontier_ab_curves.csv` (full a(b) grid, 16 b-values × 14 sections),
  `frontier_b_needed.csv`; log `t2_stage22b_frontier_run.log`.

## 2026-07-18 — Stage 2.6 ATTEMPT: tail KLMN lemma — one theorem, one reduction, one refutation [worktree agitated-volhard]
[context: the 2.2b + 2.2b-frontier entries above (κ_tail(N) drift is b-TYPE; fixed pairs
(a,b) = (0.3, 0.011) work for all N) were uncommitted in the main checkout at this branch
point; this stage builds on them and confirms their mechanism.]
- deliverable: `unbounded/LEMMA_tail_KLMN_attempt_2026-07-18.md`; scripts
  `t2_stage26{,b,c,d}_*.py` + logs/tables (this folder). Data: quantiles_production.csv
  (Euler side, P = 2e5, zeros nowhere), float64. Every intermediate inequality verified
  per-n before use (149/149 for the δ- and ε-bounds; ρ > 0 increasing, γρ increasing).
- **The form-bound is identification-dependent** — "|⟨Vψ,ψ⟩| ≤ a⟨Dψ,ψ⟩ + b‖ψ‖²" means three
  different things depending on the unitary identification of H with D's space:
  (I) atom map: V = diag(x^F − x^D) → **PROVEN KLMN, a = ε_k, b = 0** (ε₄ = 0.0569,
  ε₁ = 0.274; coefficient = the decaying 2|S|/(γρ) of the plan's step 3;
  positivity-transferring since b = 0).
  (II) Jacobi/pencil map (where ALL T2 measurements live): exact factorization
  (machine-checked 1e-15) V = Wᵀ(T(J_D) − J_D)W + R; ‖T(J_D) − J_D‖ = max|x^F − x^D| PROVEN
  (functional calculus; commutes with J_D); rotation ‖R‖ measured 0.009 (drop-4), flat in N.
  **‖V‖₂ FLAT in N to 3 digits** (drop-1: 0.2436; drop-4: 0.0152, N = 60/100/149) →
  κ_tail(N) growth is purely D_min → 0 — the frontier's b-type verdict now has its
  mechanism. **(a,b) = (0.3, 0.011) verified as a PSD certificate** at N = 149, both drops
  (aJ_D + bI ∓ V ⪰ 0, margins ≥ +1.3e-3) — T2a-certifiable shape.
  (III) basis-free/polynomial map (the five-step plan's step-1 route): **REFUTED** —
  κ_Q(d) crosses 1 at degree 3 (drop-1) / 5 (drop-4), ~1e31 at full degree (Lagrange
  operator ‖E‖ ≈ 2e15, mpmath dps-80-validated); quantile atoms are far from the
  equilibrium distribution of their support. The stage-2.5 "5–7%" figure was V^lin-vs-V
  (both pencil objects), not this. Negative result, recorded as such.
- **Open core reduced to the sensitivity kernels** K_j(n) = ∂(α_j,β_j)/∂x_n at fixed
  weights: sum rules PROVEN + verified (ΣK^α = 1, ΣK^β = 0; x-weighted = α_j, β_j); ℓ¹
  norms grow ~ j (worst-case route insufficient) but **partial sums measured bounded
  1.0–1.4, M-independent** → Abel pairing against TV(transport field) gives j- and
  N-uniform first-order row bounds (TV(dx) = 0.049, a-priori bounded via convergent Σγ⁻³).
  Open: (K1) kernel partial-sum bound, (K2) second order (first order reproduces dα, dβ to
  8–24%). The ‖S‖* question for IB is reborn HERE: signed S-averages pair against kernel
  oscillations (~j sign changes), not against test-function transport. Negative check:
  Avdonin/Kadec ¼-in-the-mean does NOT apply (signed A_w ≥ 0.41 up to w = 10; max at the
  low-t end) — the w ≈ 3 elbow is not a ¼-threshold effect.
- tables: `t2_stage26_lemma_table.csv`, `t2_stage26b_{identifications,degree_table}.csv`,
  `t2_stage26c_rotation.csv`; logs `t2_stage26{,b,c,d}_run.log`.

## 2026-07-18 — K1/K2 kernel session: exact identities PROVEN, K1 reduced to one cancellation law, K2 closed on range [worktree agitated-robinson]
- data: `quantiles_production.csv` only (zeros used nowhere), sections (k,N) ∈
  {(4,60),(1,60),(4,100),(1,149),(4,149)}. Session folder (self-contained):
  `T2_K1K2_kernel_bounds_2026-07-18/` — scripts `t2_k1_kernel_identity.py`,
  `t2_k1_partial_sums.py`, `t2_k1_profile_shape.py`, `t2_k2_transport_remainder.py`,
  logs/tables/kernel caches, and the full note `K1K2_kernel_bounds_2026-07-18.md`.
- **Theorem 1 (proven + verified): exact closed forms** K_j^α(n) = w·Φ_j′(x_n),
  K_j^β(n) = w·Ψ_j′(x_n), Φ_j = β_jp_jp_{j+1} − β_{j−1}p_{j−1}p_j, Ψ_j = (β_j/2)(p_{j+1}²−p_j²).
  Verified vs central FD to 5e−9…1e−7 (FD floor) for ALL j ≤ M−1, five sections; sum rules
  3e−15; dual column rule 4e−15. The naive conjecture K^α = q² is FALSE pointwise (dev up
  to 1.72) — it satisfies all four sum rules, so only partial sums could catch it (they do:
  κ̂₁ = 1.077 > 1). mp pipeline with 4 exact a-posteriori checks at ≤ 1e−25 (float64
  recurrences for p′ explode > 1e300 by M ≈ 145 — same Runge mechanism as ‖E‖ ≈ 1.8e15).
- **Theorem 2 (proven): partial sums = spectral-projection part ∈ [0,1] + derivative
  pairings.** Cauchy–Schwarz on the pairings is REFUTED as a route: ν_j = β_j‖p_j′‖ grows
  e^{cj} (9e73 at j = 54) while partial sums stay ≤ 4.7 — K1 is pure oscillation cancellation.
- **K1 measured verdict:** per-j constants flat in M at fixed j (matches 1.0–1.4 for
  j ≤ 12) but grow ≈ 0.5–0.6·log(2+j) in the bulk + boundary layer (last ≤ 5 Lanczos rows):
  **κ̂ = 5.5956 (α) / 2.8598 (β) over ALL j, m, both drops, N ≤ 149** — the T2a-range
  certificate constants. K1 with an absolute constant is REFUTED beyond j ≈ 12; open core
  is now the log-law (P1): sup_m of the pairing correction ≤ c₀ + c₁log(2+j), measured
  c₀ ≈ 0.3, c₁ ≈ 0.5–0.6, boundary ≤ 4.7.
- **K2 closed at finite range:** the |S| < 1 safety condition is REPLACED by proven
  (L-ORD): linear segments between like-ordered configs stay ordered, gap_n(s) ≥
  min(gap_n^D, gap_n^F) — endpoint order is data-verified 149/149 (γ-cell margin 0.847 =
  the note's sup|S| 0.846). J(s) analytic ⇒ ‖V − V^lin‖ ≤ ½sup_s|J″| entrywise: verified
  per entry with ≥ 2× margin; sup|α″| = 1.06e−2 (drop-4, at j = 23 — Hessian localizes at
  the top block like V); first-order quality 8–25% (note's 8–24%, now all j). Mid-segment
  identity spot check 2.7e−9.
- **Assembled explicit chain verified all j:** |dα_j| ≤ κ_j^α(TV(dx)+|dx_M|) + ½sup|α_j″|.
  Loss vs truth: 5× at the peak rows j = 1–2, 26× uniform (drop-4); row-assembly for ‖V‖
  0.472 vs measured 0.0198. Honest: H-ROT with C ≈ 1.1 still needs P1 + the oscillation-
  scale/windowed-S pairing; every ingredient is now proven or a finite certifiable constant.
- grade: float64/FD-floor + mp(1e−25) internal; K2 stencil consistency 1e−3; P = 2×10⁵.
- tables: `t2_k1_partial_sums.csv`; kernels cached in `k1_kernels_k{k}_N{N}.npz` (regenerable).

## 2026-07-18 — P1 session: cut eliminated exactly, log-law mechanized, Chebyshev model SOLVED [same folder]
- data: certified kernels from the K1/K2 session (`T2_K1K2_kernel_bounds_2026-07-18/`);
  scripts `t2_p1_reduction.py`, `t2_p1_model_zoo.py`; full note
  `P1_spectral_reduction_2026-07-18.md` (same folder).
- **Theorem R1 (proven + verified 1e−15): exact spectral reduction.** With h_j = Φ_j′ − p_j²
  (degree 2j), C_j(m) = Σ_{i≤min(2j,M−1)} ĥ_i ĉ_i(m), ĥ_i = ⟨h_j,p_i⟩ cut-free, ĉ_i(m) =
  ⟨1_A, p_i⟩ = first-column spectral-projector element; ĥ_0 = 0 by the sum rule. P1 splits
  into (P1a) a₃ = sup(1+i)|ĉ_i| = O(1) [measured 2.22–2.25] and (P1b) W_j = Σ|ĥ_i|/(1+i) ≤
  c₀′+c₁′log(2+j); Theorem R2: κ_j ≤ 1 + a₃W_j — the log-law, two-line proof.
- **Verified per-section bound within 1.76×:** κ_j ≤ 1 + Σ_i|ĥ_i|sup_m|ĉ_i| holds for ALL j
  (max 9.82 vs κ̂ = 5.5956 at N=149; β twin 4.28 vs 2.8598).
- **Theorem R3 (proven + verified 3.7e−13): Chebyshev model solved.** p_j = √2T_j exactly;
  K_j^α = [(2j−1)T_{2j} + U_{2j}]/M; bulk |PS| < 2.77 proven (Fejér–Jackson + Abel; measured
  = 1.000 exactly for j ≤ M/2); boundary rows PROVABLY blow up κ_{M−ℓ} ≍ M/(πℓ) (measured
  41.02 at M=128 vs M/π = 40.74). **Mild boundary is NOT generic — quantile structure is
  load-bearing**; any P1 proof must use it.
- **Mechanism (zoo, measured):** non-arcsine density chirps α_j, β_j → breaks Fejér–Jackson
  cancellation (bulk pays c·log j) AND bends the alias so boundary resonance lands mid-band
  where ĉ ~ 1/i is small (boundary saved). One mechanism, two consequences. The **1/n²
  hard-edge model reproduces the production sections to 3 digits** (a₃ 2.223 vs 2.225,
  boundary resonance i* 60 vs 59, bulk slope 0.50 vs 0.57) — (P1a)/(P1b) should be proven
  on x_n = 1/n²; production is a perturbation.
- grade: reduction/reconstruction exact (float64 on certified kernels); zoo kernels
  mp-certified + FD-checked ≤ 5e−7; Chebyshev closed forms analytic.
- tables: `t2_p1_model_zoo.csv`; logs `t2_p1_reduction_run.log`, `t2_p1_model_zoo_run.log`.

## 2026-07-18 — P1 session 2: the string/Bessel identification — companion model EXACTLY SOLVED [same folder]
- scripts `t2_p1_string_bessel.py`, `t2_p1_bessel_checks.py`; note
  `P1_string_bessel_2026-07-18.md` (in `T2_K1K2_kernel_bounds_2026-07-18/`).
- **The pure model is the uniform string:** D-ladder quantization θ/π = n−½ ⇒ atoms
  x_n = 1/z_n², z_n = (n−½)π = Neumann–Dirichlet string spectrum. Sharpened model matches
  production at M=128: a₃ 2.221 (prod 2.225), i*(M−1) 60 (59), bulk slope 0.503 (0.57).
- **Theorem B1 (proven + verified): companion solved.** μ_L = Σ2x_nδ (mass 1 exactly):
  G_L(y) = tan(1/y) (Mittag-Leffler, 3 lines) ⇒ Lambert CF ⇒ β_k = 1/√((2k−1)(2k+1)) exact
  (b₁√3 = 1.00000000 measured; finite-M drift ≈ 0.33k/2M); OP atom values CLOSED FORM
  ŝ_k(1/z_n) = √((2k+1)π/2)(−1)^{n+1}√z_n J_{k+½}(z_n) — elementary (Riccati–Bessel);
  verified rel std 9.5e−7 + constant 1.000010 (k=5); normalization PROVEN via Poisson
  representation + Parseval in the string eigenbases: Σ_nJ_{k+½}(z_n)²/z_n = 1/((2k+1)π)
  (verified 1e−10 odd k).
- **Theorem B2 (proven + verified 2.6e−14): exact Christoffel transfer** x·μ_U ∝ μ_L:
  p^L_i = c_i[p^U_{i+1} − r_ip^U_i]/x; uniform values = telescoped Bessel sums; r_i, c_i
  measured (r → −1.15…−1.19, c_i ≈ 0.013/i).
- **(P1a)-companion reduced to ONE explicit sum:** ĉ^L_i(m) = 2√(4i+1)Σ_{n≤m}A_{2i}(1/z_n)/z_n²
  [exponent erratum fixed by the D1 session], chirp phase ≈ 2i²/z_n (Bessel phase
  correction), sign changes at n ~ i²/(π²t) — a z^{−2}-damped chirped sum, no OP content
  left. Lemma A (proven):
  |ĉ_i(m)| ≤ min(√(m/M),√(1−m/M)) + super-polynomial tail for i ≳ Cm² (Jackson through the
  cut gap). Open: the chirped-sum estimate (P1a midrange) + transfer resummation + (P1b).
- grade: identities proven; numerics mp with full reorthogonalization (drift ≤ 1e−22);
  Dini sums scipy float64 with explicit tail bounds.

## 2026-07-18 — P1 session 3: THEOREM D1 — (P1a) for the companion PROVEN [same folder]
- script `t2_p1a_companion_theorem.py`; note `P1a_companion_theorem_2026-07-18.md`.
- **The chirped sum is evaluated exactly:** ĉ^L_i(m) = (−1)^{m+i+1}/√(4i+1) ·
  ∫₀¹ [sin(mπt)/cos(πt/2)]·(P_{2i+1}−P_{2i−1})(t)dt — EXACT (Poisson → string side; G̃_∞ = 1;
  elementary geometric identity Σ_{n≤m}(−1)^{n+1}sin(z_nt) = (−1)^{m+1}sin(mπt)/(2cos(πt/2));
  IBP with (4i+1)P_{2i} = P′_{2i+1}−P′_{2i−1}, BOTH boundary terms vanish). Verified vs
  value-law Bessel sums to 2.3e−15; identity 4.5e−14.
- **The trivial L¹ Fourier bound closes it** — no van der Corput, m-oscillation unused:
  sup_m|ĉ^L_i(m)| ≤ L(2i)/√(4i+1), L(k) = ∫|P_{k+1}−P_{k−1}|/cos(πt/2) ≤ 3/k + 10c₁/√k
  (difference identity → sinθ·P¹_k; cap 2k+1 near t=1 via cos(πt/2) ≥ 1−t; Bernstein
  envelope (1−t)^{−3/4}). Numerically √k·L(k) ≤ 3.065 ⇒ **sup_m(1+i)|ĉ^L_i| ≤ 1.263
  PROVEN** (true measured constant 0.783; not sharp — truth decays ~(1+i)^{−1.45}).
- remaining for full P1a: companion → uniform weight transfer (telescope cancellation-laden;
  routes flagged: CD-kernel Christoffel / λ-side Laurent OPs / uniform V-transform) +
  finite-M truncation lemma (~k/M, measured). (P1b): companion ĥ = triple-Legendre
  integrals — next object.
- erratum applied to session-2 note: chirp damping z^{−2} (not z^{−5/2}).

## pending gates (updated after 2.2b-frontier + K1/K2 session)
- 2.2b(ii) longer lists: still worthwhile but DOWNGRADED from "THE empirical question" —
  the frontier answer removes the urgency; rerun the frontier (not bare κ) when a t₂ > 28
  list exists.
- 2.5: linearized-V entrywise note (pencil-level check done 07-18 AM; kernel-level closed
  forms now PROVEN in the K1/K2 note — supersedes the planned entrywise numerics).
- 2.6: ‖S‖* lemma question → Ilya — sharpened FIVE ways: tail-only, signed vs |S| windows,
  w ≈ 3 elbow, target the (a,b) PAIR with b ~ D_min, and now stated against EXACT kernels:
  the pairing dα_j = Σ dx_n K_j^α(n) has K in closed form (Theorem 1), so the window is set
  by the oscillation scale of Φ_j′ at j = 1–2. Open mathematical core after the P1 session:
  **(P1a)** projector-column decay + **(P1b)** logarithmic mean of ĥ, both cut-free, both
  to be proven on the model x_n = 1/n² (`T2_K1K2_kernel_bounds_2026-07-18/
  P1_spectral_reduction_2026-07-18.md` §6) + P2 (second-order kernel identity, K1K2 note §8).
- 2.6-cert (T2a): interval-arithmetic certification of sup|S_P| on the tail range, quantile
  enclosures, and the two PSD checks for (a,b) = (0.3, 0.011) — mechanical, high value.
- G4 (program-level, → IB): WHICH identification does the m→∞ limit need? Atom map gives
  a = ε, b = 0 and transfers positivity (proven); the pencil map is where the measurements
  live but pure-a there is doubtful (κ grows as D_min → 0).
