# t2_p1_model_zoo.py — P1 step 2: the Chebyshev model (solvable, closed forms) and a zoo of
# equal-weight atom configurations, to localize which features of the quantile class produce
# (i) the ~0.5 log j bulk growth and (ii) the mild boundary layer.
#
# Chebyshev model (Theorem R3): atoms x_n = cos((2n-1)pi/(2M)), uniform weights. Then
# p_0 = 1, p_j = sqrt(2) T_j (j = 1..M-1) EXACTLY, and for 1 <= j <= M-2
#     K_j^alpha(n) = [ (2j-1) T_{2j}(x_n) + U_{2j}(x_n) ] / M,
#     PS_j(m) = m/M + (1/M) sum_{i=1}^{j} sin(2pi i m/M)/sin(i pi/M)
#             + (2j-1)/(2M) * sin(2pi j m/M)/sin(j pi/M),
# whence (Fejer-Jackson + Abel) |PS_j(m)| <= 1 + Si(pi)(pi-1)/pi + 1/2 < 2.8 for j <= M/2,
# while the aliased rows j = M-l blow up like ~ M/(pi l): the mild boundary of the quantile
# class is NOT generic.  This script verifies the closed forms against the mp pipeline and
# measures the zoo profiles + the P1 diagnostics (a3, W_j = sum_i |hhat_i|/(1+i)).
import os, csv
import importlib.util
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('k1id', os.path.join(HERE, 't2_k1_kernel_identity.py'))
k1id = importlib.util.module_from_spec(spec)
spec.loader.exec_module(k1id)


def atoms(model, M):
    n = np.arange(1, M + 1, dtype=float)
    if model == 'cheb':
        return np.cos((2 * n - 1) * np.pi / (2 * M))          # descending
    if model == 'equi':
        return (M - n + 1) / M
    if model == 'inv':
        return 1.0 / n
    if model == 'invsq':
        return 1.0 / n ** 2
    raise ValueError(model)


def diagnostics(Ka, P, M, label):
    PSa = np.cumsum(Ka, axis=1)
    tails = 1.0 - np.concatenate([np.zeros((M, 1)), PSa[:, :-1]], axis=1)
    prof = np.maximum(np.max(np.abs(PSa), axis=1), np.max(np.abs(tails), axis=1))
    corr = Ka - P ** 2 / M
    H = corr @ P.T
    chat = np.cumsum(P, axis=1) / M
    csup = np.max(np.abs(chat), axis=1)
    ii = np.arange(M)
    a3 = float(np.max(((1.0 + ii) * csup)[1:]))
    W = np.abs(H) @ (1.0 / (1.0 + ii))
    istars = np.array([int(np.argmax(np.abs(H[j, :]))) for j in range(M)])
    # bulk log fit of prof on 2..M-6
    jj = np.arange(2, M - 5)
    A = np.vstack([np.ones(len(jj)), np.log(2.0 + jj)]).T
    c, *_ = np.linalg.lstsq(A, prof[jj], rcond=None)
    js = [j for j in [1, 2, 4, 8, 16, 32, 64, 96, 120] if j < M - 5]
    print(f"  [{label}] kappa_j at j={js}: " + " ".join(f"{prof[j]:.3f}" for j in js))
    print(f"  [{label}] boundary rows j=M-4..M-1: " + " ".join(f"{prof[j]:.3f}" for j in range(M - 4, M))
          + f";  bulk fit {c[0]:.3f} + {c[1]:.3f} log(2+j); kappa-hat = {prof.max():.3f}")
    print(f"  [{label}] a3 = {a3:.3f}; W_j at j={js}: " + " ".join(f"{W[j]:.2f}" for j in js)
          + f"; W max = {W.max():.2f}; i*(M-1) = {istars[M-1]} (alias-low would be ~0)")
    return dict(prof=prof, a3=a3, W=W, c0=c[0], c1=c[1])


rows = []
for model in ['cheb', 'equi', 'inv', 'invsq']:
    for M in [64, 128]:
        x = atoms(model, M)
        pipe = None
        for dps in (120, 300, 700, 1500, 3200, 6400):
            cand = k1id.mp_pipeline(x, dps)
            if cand['diag']['ok']:
                pipe = cand
                break
        if pipe is None:
            print(f"=== {model} M={M}: pipeline FAILED at dps<=6400, skipped ===")
            continue
        Ka, Kb = k1id.mp_kernels(pipe)
        P = np.array([[float(pipe['P'][j][n]) for n in range(M)] for j in range(M)])
        print(f"=== {model} M={M} (dps {pipe['diag']['dps']}) ===")
        # FD validation at M=64
        if M == 64:
            KaF, KbF = k1id.fd_kernels(x)
            print(f"  identity vs FD: alpha {np.max(np.abs(Ka-KaF))/np.max(np.abs(KaF)):.2e}, "
                  f"beta {np.max(np.abs(Kb-KbF))/np.max(np.abs(KbF)):.2e}")
        # Chebyshev closed form
        if model == 'cheb':
            th = np.arccos(x)
            err = 0.0
            for j in range(1, M - 1):
                closed = ((2 * j - 1) * np.cos(2 * j * th) + np.sin((2 * j + 1) * th) / np.sin(th)) / M
                err = max(err, float(np.max(np.abs(Ka[j, :] - closed))))
            print(f"  CLOSED FORM K_j = [(2j-1)T_2j + U_2j]/M: max abs dev (1<=j<=M-2) = {err:.2e}")
        d = diagnostics(Ka, P, M, f"{model} M={M}")
        rows.append(dict(model=model, M=M, khat=float(d['prof'].max()), c0=d['c0'], c1=d['c1'],
                         a3=d['a3'], Wmax=float(d['W'].max()),
                         kap_bdry=float(d['prof'][M - 1]), kap_bulkmax=float(d['prof'][:M - 5].max())))
        print()

print("=== zoo summary ===")
print(f"{'model':>6} {'M':>4} {'khat':>8} {'bulk c1(log)':>12} {'a3':>6} {'Wmax':>7} {'kappa(M-1)':>10} {'bulk max':>9}")
for r in rows:
    print(f"{r['model']:>6} {r['M']:>4} {r['khat']:>8.3f} {r['c1']:>12.3f} {r['a3']:>6.2f} "
          f"{r['Wmax']:>7.2f} {r['kap_bdry']:>10.3f} {r['kap_bulkmax']:>9.3f}")
with open(os.path.join(HERE, 't2_p1_model_zoo.csv'), 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader()
    for r in rows: w.writerow(r)
print("saved t2_p1_model_zoo.csv")
print("done.")
