# t2_k1_kernel_identity.py — K1 step 1: EXACT closed forms for the sensitivity kernels
# of the Jacobi/Lanczos map at fixed (uniform) weights, verified against finite differences.
#
# Claimed identities (derived 2026-07-18 by differentiating orthonormality under an atom
# shift at fixed weights; p_j = orthonormal polys of mu = sum_n w_n delta_{x_n}, w_n = 1/M):
#
#   K_j^alpha(n) := d alpha_j / d x_n = w_n * Phi_j'(x_n),
#         Phi_j := beta_j p_j p_{j+1} - beta_{j-1} p_{j-1} p_j        (beta_{-1} := 0),
#   K_j^beta(n)  := d beta_j  / d x_n = w_n * Psi_j'(x_n),
#         Psi_j := (beta_j / 2) (p_{j+1}^2 - p_j^2).
#
# Equivalent split (Christoffel-Darboux telescoping):
#   K_j^alpha(n) = q_{jn}^2 + [G_{j+1}(n) - G_j(n)],  q_{jn} := sqrt(w_n) p_j(x_n),
#         G_j(n) := 2 w_n beta_{j-1} p_{j-1}'(x_n) p_j(x_n).
#
# The NAIVE conjecture K_j^alpha = q_{jn}^2, K_j^beta = q_{jn} q_{j+1,n} satisfies all four
# proven sum rules (the corrections are exactly annihilated by them) but is FALSE pointwise
# for j >= 1 — this script measures both facts.
#
# j = M-1 boundary: r(x) := (x - alpha_{M-1}) p_{M-1}(x) - beta_{M-2} p_{M-2}(x)
# (= "beta_{M-1} p_M" with the convention beta_{M-1} := 1) vanishes at every atom, and the
# solvability identity r'(x_n) = M / p_{M-1}(x_n) holds EXACTLY (project the differentiated
# eigen-relation (J - lambda) p'(lambda) = p(lambda) - r'(lambda) e_{M-1} onto the kernel).
#
# Numerics: the forward recurrences for p_j(x_n) and p_j'(x_n) amplify errors through the
# second-kind (dominant) solution — growth reaches ~1e300+ by M ~ 145 in float64 (measured:
# overflow). So the analytic kernels are computed in mpmath at ADAPTIVE precision, with
# a-posteriori exact checks; float64 central finite differences are the independent
# comparison. Plain Lanczos (no reorthogonalization) in mp is O(M^2) because multiplication
# by x is diagonal, and its vectors ARE v_j(n) = sqrt(w_n) p_j(x_n).
#
# Outputs: per-section .npz with kernels (float64, rounded from mp), al, be, P, DP,
# plus a printed verification report.
import os, csv
import numpy as np
from mpmath import mp, mpf

HERE = os.path.dirname(os.path.abspath(__file__))
gD_all, gF_all = [], []
with open(os.path.join(HERE, 'quantiles_production.csv')) as fh:
    for row in csv.DictReader(fh):
        gD_all.append(float(row['gamma_D'])); gF_all.append(float(row['gamma_fwd']))
gD_all = np.array(gD_all); gF_all = np.array(gF_all)


def jacobi(x):
    """float64 Lanczos with full reorthogonalization (26d convention)."""
    x = np.asarray(x, float); M = len(x)
    v = np.ones(M) / np.sqrt(M)
    al, be, Vs = [], [], [v]
    w = x * v; a0 = v @ w; al.append(a0); w = w - a0 * v
    for j in range(1, M):
        b = np.linalg.norm(w)
        if b < 1e-14: break
        be.append(b)
        vn = w / b
        for u in Vs: vn = vn - (u @ vn) * u
        vn /= np.linalg.norm(vn)
        Vs.append(vn)
        w = x * vn - b * Vs[-2]
        a = vn @ w; al.append(a); w = w - a * vn
    return np.array(al), np.array(be)


def fd_kernels(x, rel_h=1e-6):
    """float64 central-difference kernels, ALL j."""
    M = len(x)
    Ka = np.zeros((M, M)); Kb = np.zeros((M - 1, M))
    for n in range(M):
        h = rel_h * x[n]
        xp = x.copy(); xp[n] += h
        xm = x.copy(); xm[n] -= h
        alp, bep = jacobi(xp); alm, bem = jacobi(xm)
        Ka[:, n] = (alp - alm) / (2 * h)
        Kb[:, n] = (bep - bem) / (2 * h)
    return Ka, Kb


def mp_pipeline(x64, dps):
    """Plain Lanczos + derivative recurrence in mp at given dps.

    Returns dict with al, be (lists of mpf), P ((M+1) x M nested lists, row M = r values),
    DP ((M+1) x M), and diagnostics; or None if the a-posteriori checks fail."""
    M = len(x64)
    mp.dps = dps
    x = [mpf(float(t)) for t in x64]
    # plain Lanczos on diag(x), v0 = uniform: v_j(n) = sqrt(w) p_j(x_n)
    s0 = mp.one / mp.sqrt(M)
    v_prev = None
    v = [s0] * M
    al, be = [], []
    V = [v]
    w = [x[n] * v[n] for n in range(M)]
    a = mp.fsum(v[n] * w[n] for n in range(M)); al.append(a)
    w = [w[n] - a * v[n] for n in range(M)]
    for j in range(1, M):
        b = mp.sqrt(mp.fsum(t * t for t in w))
        be.append(b)
        v_prev, v = v, [t / b for t in w]
        V.append(v)
        w = [x[n] * v[n] - b * v_prev[n] for n in range(M)]
        a = mp.fsum(v[n] * w[n] for n in range(M)); al.append(a)
        w = [w[n] - a * v[n] for n in range(M)]
    sqM = mp.sqrt(M)
    P = [[V[j][n] * sqM for n in range(M)] for j in range(M)]
    # pseudo row: r(x_n) = (x - al_{M-1}) p_{M-1} - be_{M-2} p_{M-2}  (should be ~0)
    r = [ (x[n] - al[M - 1]) * P[M - 1][n] - be[M - 2] * P[M - 2][n] for n in range(M)]
    P.append(r)
    # derivative recurrence
    DP = [[mp.zero] * M, [mp.one / be[0]] * M]
    for j in range(1, M):
        bj = be[j] if j < M - 1 else mp.one
        DP.append([(P[j][n] + (x[n] - al[j]) * DP[j][n] - be[j - 1] * DP[j - 1][n]) / bj
                   for n in range(M)])
    # ---- a-posteriori exact checks ----
    tol = mpf(10) ** (-25)
    # (1) r ~ 0 relative to the size of p_{M-1}
    rmax = max(abs(t) for t in r) / max(abs(t) for t in P[M - 1])
    # (2) column normalization sum_j p_j(x_n)^2 = M
    colerr = mpf(0)
    for n in range(M):
        s = mp.fsum(P[j][n] ** 2 for j in range(M))
        colerr = max(colerr, abs(s - M) / M)
    # (3) CD identity Lambda_j = be_{j-1}(p_j' p_{j-1} - p_{j-1}' p_j) = sum_{i<j} p_i^2
    cderr = mpf(0)
    run = [mpf(0)] * M
    for j in range(1, M):
        for n in range(M):
            run[n] += P[j - 1][n] ** 2
            rhs = be[j - 1] * (DP[j][n] * P[j - 1][n] - DP[j - 1][n] * P[j][n])
            cderr = max(cderr, abs(rhs - run[n]) / run[n])
    # (4) boundary solvability: DP[M] (= r') vs M / p_{M-1}
    bnderr = mpf(0)
    for n in range(M):
        bnderr = max(bnderr, abs(DP[M][n] - M / P[M - 1][n]) / abs(DP[M][n]))
    ok = (rmax < tol) and (colerr < tol) and (cderr < tol) and (bnderr < tol)
    diag = dict(rmax=float(rmax), colerr=float(colerr), cderr=float(cderr),
                bnderr=float(bnderr), dps=dps, ok=ok)
    return dict(al=al, be=be, P=P, DP=DP, x=x, diag=diag)


def mp_kernels(pipe):
    """Analytic kernels from the mp pipeline, returned as float64 arrays."""
    al, be, P, DP = pipe['al'], pipe['be'], pipe['P'], pipe['DP']
    M = len(al)
    w = mp.one / M
    Ka = np.zeros((M, M)); Kb = np.zeros((M - 1, M))
    for j in range(M):
        bj = be[j] if j < M - 1 else mp.one
        for n in range(M):
            t1 = bj * (DP[j][n] * P[j + 1][n] + P[j][n] * DP[j + 1][n])
            t0 = be[j - 1] * (DP[j - 1][n] * P[j][n] + P[j - 1][n] * DP[j][n]) if j >= 1 else mp.zero
            Ka[j, n] = float(w * (t1 - t0))
            if j < M - 1:
                Kb[j, n] = float(w * be[j] * (P[j + 1][n] * DP[j + 1][n] - P[j][n] * DP[j][n]))
    return Ka, Kb


def run_section(k, N):
    gD = gD_all[k:N]; xD = 1.0 / gD ** 2
    M = N - k
    print(f"--- section k={k} N={N} (M={M}) ---")
    # float64 reference objects
    al64, be64 = jacobi(xD)
    KaF, KbF = fd_kernels(xD)
    # mp pipeline, adaptive dps
    pipe = None
    for dps in (120, 300, 700, 1500):
        cand = mp_pipeline(xD, dps)
        d = cand['diag']
        print(f"  mp dps={dps}: r/pM-1 {d['rmax']:.1e}, colnorm {d['colerr']:.1e}, "
              f"CD {d['cderr']:.1e}, boundary {d['bnderr']:.1e} -> {'OK' if d['ok'] else 'retry'}")
        if d['ok']:
            pipe = cand; break
    if pipe is None:
        print("  !! mp pipeline failed at dps<=1500 — section skipped"); return
    # mp al,be vs float64 Lanczos
    ea = max(abs(float(pipe['al'][j]) - al64[j]) for j in range(M))
    eb = max(abs(float(pipe['be'][j]) - be64[j]) for j in range(M - 1))
    print(f"  al,be mp vs float64 Lanczos: {ea:.2e} / {eb:.2e}")
    Ka, Kb = mp_kernels(pipe)
    # identity vs FD
    scl_a = np.max(np.abs(KaF)); scl_b = np.max(np.abs(KbF))
    ia = np.max(np.abs(Ka - KaF)) / scl_a; ib = np.max(np.abs(Kb - KbF)) / scl_b
    print(f"  IDENTITY vs FD (rel to max|K| = {scl_a:.3f}/{scl_b:.3f}): alpha {ia:.2e}, beta {ib:.2e}")
    # sum rules on analytic kernels
    sr = (np.max(np.abs(Ka.sum(axis=1) - 1.0)), np.max(np.abs(Ka @ xD - al64)),
          np.max(np.abs(Kb.sum(axis=1))), np.max(np.abs(Kb @ xD - be64)))
    print(f"  sum rules (analytic): |sum Ka - 1| {sr[0]:.1e}, |sum x Ka - al| {sr[1]:.1e}, "
          f"|sum Kb| {sr[2]:.1e}, |sum x Kb - be| {sr[3]:.1e}")
    # naive conjecture: pointwise deviation (vs exact kernels)
    Pf = np.array([[float(pipe['P'][j][n]) for n in range(M)] for j in range(M)])
    Q2 = Pf ** 2 / M
    QQ = Pf[:M - 1, :] * Pf[1:M, :] / M
    dev_a = np.max(np.abs(Ka - Q2)); dev_b = np.max(np.abs(Kb - QQ))
    # where does the naive conjecture first fail badly? per-j max deviation
    devj = np.max(np.abs(Ka - Q2), axis=1)
    print(f"  naive q^2 conjecture: max pointwise |K - q^2| = {dev_a:.4f} (alpha), "
          f"{dev_b:.4f} (beta); per-j dev j=0..5: " + " ".join(f"{t:.4f}" for t in devj[:6]))
    # save
    out = os.path.join(HERE, f'k1_kernels_k{k}_N{N}.npz')
    DPf = np.array([[float(pipe['DP'][j][n]) for n in range(M)] for j in range(M + 1)])
    np.savez_compressed(out, Ka=Ka, Kb=Kb, KaFD=KaF, KbFD=KbF, P=Pf, DP=DPf,
                        al=al64, be=be64, x=xD, k=k, N=N)
    print(f"  saved {os.path.basename(out)}")
    print()


if __name__ == '__main__':
    for (k, N) in [(4, 60), (1, 60), (4, 100), (1, 149), (4, 149)]:
        run_section(k, N)
    print("done.")
