# t2_k1_profile_shape.py — diagnostic: shape of the per-j partial-sum profile
# kappa_j := sup_m |PS_j(m)| (both directions), where the max sits in m, and the
# boundary-row closed form K_{M-1}^alpha(n) = 1 - w_n be_{M-2} (p_{M-2} p_{M-1})'(x_n).
import os
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
for (k, N) in [(4, 149), (4, 100), (4, 60)]:
    z = np.load(os.path.join(HERE, f'k1_kernels_k{k}_N{N}.npz'))
    Ka, Kb, x = z['Ka'], z['Kb'], z['x']
    M = len(x)
    PSa = np.cumsum(Ka, axis=1)
    tail = 1.0 - np.concatenate([np.zeros((M, 1)), PSa[:, :-1]], axis=1)
    prof = np.maximum(np.max(np.abs(PSa), axis=1), np.max(np.abs(tail), axis=1))
    mstar = np.argmax(np.maximum(np.abs(PSa), np.abs(tail)), axis=1)
    js = [j for j in [0, 1, 2, 4, 8, 16, 32, 64, 96, 128, M - 16, M - 8, M - 4, M - 3, M - 2, M - 1] if 0 <= j < M]
    js = sorted(set(js))
    print(f"=== k={k} N={N} (M={M}) ===")
    print("   j      kappa_j   m*/M")
    for j in js:
        print(f"  {j:>4}   {prof[j]:8.4f}   {mstar[j]/M:5.2f}")
    # bulk vs boundary: max over j <= M-6 vs full
    print(f"  max over j <= M-6: {prof[:M-5].max():.4f} (at j={int(np.argmax(prof[:M-5]))}); "
          f"full max: {prof.max():.4f} (at j={int(np.argmax(prof))})")
    # log fit on the bulk only (2 <= j <= M-6)
    jj = np.arange(2, M - 5)
    A = np.vstack([np.ones(len(jj)), np.log(2.0 + jj)]).T
    c, *_ = np.linalg.lstsq(A, prof[2:M - 5], rcond=None)
    resid = prof[2:M - 5] - A @ c
    print(f"  bulk fit kappa_j ~ {c[0]:.3f} + {c[1]:.3f} log(2+j), max residual {np.max(np.abs(resid)):.3f}")
    print()
print("done.")
