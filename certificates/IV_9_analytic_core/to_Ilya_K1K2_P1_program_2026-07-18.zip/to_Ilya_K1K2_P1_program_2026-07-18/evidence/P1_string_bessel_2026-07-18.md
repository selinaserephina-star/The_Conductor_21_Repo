# P1 dent 2 — the string/Bessel identification: the companion model is EXACTLY SOLVED

**Merkabit · Stenberg + Claude · 2026-07-18 (P1 session 2, same folder).** Target: (P1a)/(P1b)
of `P1_spectral_reduction_2026-07-18.md` §6 on the model class. Result: the model measure is
one exact Christoffel step away from a measure whose orthogonal polynomials, Jacobi
coefficients, AND atom values are classical and ELEMENTARY (Lambert's continued fraction /
Lommel polynomials / half-integer Bessel = trigonometric). The open (P1a) becomes an
explicit chirped oscillatory sum. Every identity below is proven and verified numerically
(manifest §7). Not RH/GRH.

## 0. Executive verdict

1. **The right pure model is the string.** The D-ladder solves θ(γ)/π = n − ½; the points
   z_n² = ((n−½)π)² are exactly the Neumann–Dirichlet spectrum of the uniform unit string.
   The sharpened model U (atoms x_n = 1/z_n², uniform weights) reproduces the production
   diagnostics at M = 128: bulk slope 0.503 (prod 0.57), a₃ = 2.221 (2.225), boundary
   resonance i* = 60 (59), κ̂ = 5.03 (5.60 at M = 145).
2. **Theorem B1 (proven + verified): the companion is exactly solvable.** The companion
   measure μ_L := Σ_n 2x_n δ_{±1/z_n} (y-side; total mass Σ 2/z_n² = 1 exactly) has
   Stieltjes transform **G_L(y) = tan(1/y)** (three-line Mittag-Leffler computation), hence
   by Lambert's continued fraction tan(1/y) = 1/(y − 1/(3y − 1/(5y − ···))):
     α_k ≡ 0,  β_k = 1/√((2k−1)(2k+1))   (exact, all k — verified: b₁√3 = 1.00000000,
     finite-M truncation drift |b_k√(4k²−1) − 1| ≈ 0.33·k/(2M), measured),
   and its orthonormal OPs have CLOSED-FORM atom values
     ŝ_k(±1/z_n) = (±1)^k √((2k+1)π/2) · (−1)^{n+1} √z_n · J_{k+½}(z_n),
   verified to rel std 9.5e−7 with normalization ratio 1.000010 at k = 5 (truncation-limited
   at higher k: residual 0.136 → 0.048 as M 128 → 256). Since √z J_{k+½}(z) = √(2/π)·S_k(z)
   (Riccati–Bessel = pure trigonometric-rational), the companion OP values are ELEMENTARY.
3. **The normalization constant is proven, not fitted:** Poisson's representation
   j_k(z) = ((−i)^k/2)∫_{−1}^1 e^{izt}P_k(t)dt identifies the atom values as Fourier
   coefficients of Legendre polynomials in the string eigenbases {√2 cos(z_nt)} (k even) /
   {√2 sin(z_nt)} (k odd) of L²(0,1); Parseval gives
     Σ_n J_{k+½}(z_n)²/z_n = 1/((2k+1)π)   (verified: (2k+1)πS = 1.0000000000 for odd k,
     1 − O(tail) for even k, with the parity of the tail explained by cos²(z_n−(k+1)π/2)
     being exactly 0/1), and cross-orthogonality by the same Parseval + parity. This yields
   a complete self-contained proof that the ŝ_k above ARE the orthonormal OPs of μ_L.
4. **Theorem B2 (exact transfer, verified 2.6e−14):** x·μ_U = const·μ_L (Christoffel step
   at 0), so p^L_i(x) = c_i[p^U_{i+1}(x) − r_i p^U_i(x)]/x with r_i = p^U_{i+1}(0)/p^U_i(0);
   verified at the atoms to 1.6e−16…2.6e−14 for i ≤ 45 (M = 128). The uniform-model OP
   values are explicit telescoped combinations of Bessel values; the transfer data (r_i, c_i)
   is measured (r_i → ≈ −1.15…−1.19; c_i ≈ 0.013/i on range).
5. **(P1a) for the companion is now ONE explicit sum.** Substituting the value law,
     ĉ^L_i(m) = 2√(4i+1) · Σ_{n≤m} A_{2i}(1/z_n)/z_n²,
   [erratum 2026-07-18 late: exponent corrected z^{5/2} → z²; J-form:
   √(2π(4i+1))·Σ(−1)^{n+1}J_{2i+½}(z_n)/z_n^{3/2} — see the D1 note],
   where S_{2i}(z_n) = (−1)^{n+1}A_{2i}(1/z_n), A_{2i} = the (Lommel) sin-coefficient
   polynomial of the Riccati–Bessel function. The (−1)^{n+1} strip makes the summand slowly
   varying: the surviving oscillation is the hard-edge CHIRP, phase ≈ (2i)²/(2z_n) (from the
   Bessel phase correction (4ν²−1)/(8z)), so A_{2i}(1/z_n) has its ~2i sign changes at
   n_t ≈ (2i)²/(2π²t) — the dyadic-in-t oscillation scale that replaces Chebyshev's linear
   phase. (P1a)-companion = partial-sum bounds for an EXPLICIT z^{−5/2}-damped chirped sum —
   classical van-der-Corput territory, no OP theory left in it.
6. **Lemma A (proven): the easy cut regimes.** For any equal-weight configuration and i ≥ 1:
   |ĉ_i(m)| ≤ min(√(m/M), √(1−m/M)) (project 1_A or 1_{A^c} against p_i ⊥ 1); and beyond
   the oscillatory band, |ĉ_i(m)| ≤ E^∞_{i−1}(1_A; spec(J)) — with a smoothed step agreeing
   with 1_A at every atom (transition inside the cut gap), Jackson–Timan gives
   super-polynomial decay for i ≳ C·m² (model scaling; the transition width in the
   y = 1/γ variable is ~1/m² at a central point, local Timan scale 1/degree). The open
   region of (P1a) is exactly the oscillatory midrange — the chirped sum of §5.

## 1. Theorem B1 with proof

**Setting.** z_n := (n−½)π; y-side companion μ_L := Σ_{n≥1} z_n^{-2}(δ_{1/z_n} + δ_{−1/z_n});
mass Σ 2/z_n² = 1 (Mittag-Leffler at 0 for tan). x-side: even part, atoms x_n = 1/z_n²,
masses 2x_n.

**(i) Stieltjes transform.** G(y) := ∫ dμ_L(s)/(y−s) = Σ_n z_n^{-2}·2y/(y² − z_n^{-2})
= 2y^{-1}Σ_n 1/(z_n² − y^{-2})·... = tan(1/y): from tan w = Σ_n 2w/(z_n² − w²) at w = 1/y,
term-by-term identical. ∎

**(ii) Jacobi coefficients.** Lambert (1761)/Stieltjes: tan(1/y) = 1/(y − 1/(3y − 1/(5y −
···))). Rescaling each partial denominator to monic-J form 1/((2k−1)y − u) =
(2k−1)^{-1}/(y − u/(2k−1)) gives the J-fraction with α ≡ 0, β_k² = 1/((2k−1)(2k+1)).
The measure is compactly supported (⊂ [−2/π, 2/π]), hence determinate, hence these ARE its
Jacobi coefficients. ∎ (Verified: b₁ = 1/√3 to 1e−8; drift at k ≤ 64 matches the finite-M
truncation law, not the formula.)

**(iii) Atom values + normalization.** Define φ_k(n) := √((2k+1)π/2)(−1)^{n+1}√z_n J_{k+½}(z_n).
(a) φ_k is a polynomial in y = 1/z_n of degree k times the alternating sign: √z J_{k+½}(z) =
√(2/π)S_k(z), and S_k(z) = A_k(1/z)sin(z − kπ/2·...) collapses at z = z_n (cos z_n = 0,
sin z_n = (−1)^{n+1}) to (−1)^{n+1}·(polynomial of degree k in 1/z_n) with the parity of k.
(b) Orthonormality: by Poisson, for k even j_k(z_n) = (−1)^{k/2}∫_0^1 cos(z_nt)P_k(t)dt and
for k odd j_k(z_n) = (−1)^{(k−1)/2}∫_0^1 sin(z_nt)P_k(t)dt. The systems {√2cos(z_nt)},
{√2sin(z_nt)} are ONBs of L²(0,1) (Sturm–Liouville for the uniform string). Parseval:
Σ_n j_k(z_n)j_l(z_n) = ½∫_0^1 P_kP_l dt = δ_{kl}/(2(2k+1)) for k ≡ l (mod 2); for k ≢ l the
y-side pairing vanishes by parity of the measure. Converting j to J: Σ_n J_{k+½}J_{l+½}/z_n
= δ_{kl}/((2k+1)π), which is exactly ⟨φ_k, φ_l⟩_{μ_L} = δ_{kl}. Since deg φ_k = k with the
right sign convention, φ_k = ŝ_k. ∎ (Verified: value law rel std 9.5e−7 and constant
1.000010 at k = 5; Dini sums (2k+1)πΣ = 1.0000000000 (odd k) / 1 − 1.6e−5 (even k, tail).)

## 2. Theorem B2 (transfer) with proof

x·dμ_U = (1/M)Σ x_nδ_{x_n} = (Σ_n x_n/M)·dμ̂_L^{(M)} where μ̂_L^{(M)} is the normalized
finite-M companion. The Christoffel transform formula for OPs of x·dμ (supp > 0) gives
p^L_i(x) = c_i[p^U_{i+1}(x) − r_ip^U_i(x)]/x, r_i = p^U_{i+1}(0)/p^U_i(0) (the bracket
vanishes at 0 by construction; degree and orthogonality standard). Verified at all atoms,
i ∈ {1,3,7,15,30,45}, rel residual ≤ 2.6e−14. Inverting the telescope,
  p^U_{i+1}(x_n) = (∏_{t≤i}r_t)·[1 + Σ_{t≤i} x_n p^L_t(x_n)/(c_t ∏_{s≤t}r_s)],
so the uniform-model values are explicit weighted sums of the Bessel values of Theorem B1
with the (measured, structured) transfer sequences r, c. ∎

## 3. What this buys for (P1a)/(P1b), honestly

- (P1a)-companion is now the explicit chirped sum of §0.5 — provable-shape (van der Corput
  / exponential-sum bounds on a z^{−5/2}-damped chirp with phase 2i²/z), no orthogonal-
  polynomial content remaining. NOT yet done — the estimate itself is the next session.
- (P1a)-uniform then follows through the transfer telescope IF the r,c-weighted resummation
  preserves the 1/i law — the telescope has |r_i| ≈ 1.15 growth against oscillating signs;
  this is the second open estimate. Alternative: run the spectral reduction (Theorem R1)
  directly on the companion weights — the R1 proof is weight-agnostic; T2's kernels live at
  uniform weights, but a companion-weighted K1 + transfer at the KERNEL level may be
  cleaner. Program choice left open.
- (P1b): the ĥ are derivative-weighted linearization coefficients; for the companion all
  ingredients (values, derivatives via Bessel recurrences) are now elementary — the W_j
  log-law becomes a statement about products of three Bessel functions summed over the
  cos-zero lattice. Concrete, classical, unproven today.
- Truncation control (infinite model vs finite-M section): measured b-drift ≈ 0.33k/(2M)
  and value-residual halving M 128→256 — the perturbation is ~k/M-smooth, the right shape
  for a perturbative transfer to finite sections (and the production measure is itself a
  log-density perturbation of the string model, slope 0.57 vs 0.50).

## 4. Verification manifest (this folder)

| script | log | what it establishes |
|---|---|---|
| `t2_p1_string_bessel.py` | `t2_p1_string_bessel_run.log` | (S0) string-model diagnostics ≈ production (a₃ 2.221/2.225, i* 60/59); (S1) Lambert law (b₁√3 = 1.00000000; drift = truncation); (S2) value law k=5: rel std 9.5e−7, constant 1.000010; (S3) Christoffel transfer ≤ 2.6e−14, r/c sequences |
| `t2_p1_bessel_checks.py` | `t2_p1_bessel_checks_run.log` | (C1) Dini/Parseval norm (2k+1)πΣJ²/z = 1 (odd k exact to 1e−10; even-k tail parity explained); (C2) truncation scaling: k=10 residual 0.136 → 0.048 as M 128 → 256 |

*— Stenberg + Claude, 2026-07-18. The model behind T2's quantile sections is the uniform
string; its x-weighted companion is the Lambert–Lommel system with elementary atom values,
proven and verified; the uniform system is one exact Christoffel step away. (P1a) is now a
single explicit chirped sum, and the chirp exponent (phase ~ 2i²/z, oscillations at
n ~ i²/t) is the hard-edge signature that separates this class from Chebyshev.*
