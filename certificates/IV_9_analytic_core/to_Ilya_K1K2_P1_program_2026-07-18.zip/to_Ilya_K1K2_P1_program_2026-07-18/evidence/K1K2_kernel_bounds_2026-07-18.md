# K1/K2 — exact kernel identities, partial-sum constants, and the transport remainder

**Merkabit · Stenberg + Claude · 2026-07-18 (K1/K2 session).** Target: the two open gaps
K1 (kernel partial-sum bound) and K2 (second-order transport control) isolated in §8 of
`unbounded/LEMMA_tail_KLMN_attempt_2026-07-18.md` (branch `claude/agitated-volhard-baab40`).
Data: `quantiles_production.csv` (149-quantile ladder, Euler side, P = 2×10⁵; zeros used
nowhere). Every inequality below was verified numerically before being trusted; scripts and
logs in §9. Not RH/GRH — finite-section, explicit-constant mathematics.

## 0. Executive verdict

1. **The conjectured identity K_j^α(n) = q_{jn}² is FALSE pointwise** (max deviation 1.72 on
   the production sections, growing with j) — it satisfies all four proven sum rules, which
   is exactly why the sum rules could not falsify it. But the kernels DO close in an exact
   **derivative form** (Theorem 1): K_j^α = w·Φ_j′(x_n), K_j^β = w·Ψ_j′(x_n) with explicit
   polynomials Φ_j, Ψ_j of degree 2j+1, 2j+2. Proven in general (any simple-atom measure,
   fixed uniform weights); machine-verified to 1e−8 (the finite-difference floor) for **all
   j up to M−1 = 147** on five sections; sum rules at 1e−15; dual (column) sum rule at 4e−15.
2. **K1 with an absolute constant is REFUTED beyond j ≈ 12.** The partial sums decompose
   exactly (Theorem 2) into a projection part in [0,1] (proven, every j, m, any atomic
   measure) plus a derivative-pairing correction. The measured per-j profile is
   section-size-free at fixed j and grows like ≈ 0.5–0.6·log(2+j) in the bulk, with a
   boundary layer in the last ≤ 5 Lanczos rows. Verified constants on the full range
   (N ≤ 149, both drops, ALL j): **κ̂^α = 5.60, κ̂^β = 2.86**; restricted to j ≤ 12:
   1.40 / 0.90 (matches the LEMMA note's 1.0–1.4). Graded outcome: (a) identity + reduction
   proven; (c) explicit range constants delivered; (b) reduced to ONE cancellation statement
   (P1, §7) — and the Cauchy–Schwarz route to (b) is refuted: ν_j = β_j‖p_j′‖ grows like
   e^{cj} (reaches 1e74 by j = 54) while the kernels stay O(log j). The boundedness is
   100% oscillation cancellation; no norm bound on p_j′ can see it.
3. **K2 closes at finite range, with the safety condition upgraded to a lemma.** The
   |S| < 1 atom-ordering condition is REPLACED by (L-ORD): along the LINEAR transport
   segment, gap_n(s) = (1−s)gap_n^D + s·gap_n^F ≥ min(gap_n^D, gap_n^F) — order at the two
   endpoints (data-verified 149/149) already forces order along the whole segment; no
   intermediate hypothesis. Hence J(s) is real-analytic and ‖V − V^lin‖ ≤ ½ sup_s|J″(s)|
   entrywise (Theorem 3). Measured: remainder inequality holds per entry with ≥ 2× margin;
   first-order quality 8–25% (the note's 8–24%, now over all j); sup_s|α_j″| ≤ 1.07e−2
   (drop-4, N=149), attained at j = 23 — the Hessian localizes near the top block like V.
4. **Assembly (toward H-ROT):** the fully explicit chain
   |dα_j| ≤ κ̂_j^α(TV(dx)+|dx_M|) + ½·sup_s|α_j″| holds for every j (verified, three
   sections) — every ingredient is now either proven (Theorems 1–3) or a finite verified
   constant. Loss vs truth: ~5× at the peak rows j = 1–2, ~26× at the uniform level.

## 1. Setting

Tail section: quantile indices n = k+1..N (γ ascending), atoms x_n = 1/γ_n² DESCENDING in
n, uniform weights w = 1/M, M = N−k. μ = Σ_n w δ_{x_n}; p_0,…,p_{M−1} its orthonormal
polynomials (positive leading coefficients); three-term recurrence
x p_j = β_{j−1}p_{j−1} + α_j p_j + β_j p_{j+1} (p_{−1} := 0), and for j = M−1

  r(x) := (x − α_{M−1}) p_{M−1}(x) − β_{M−2} p_{M−2}(x)   ("β_{M−1}p_M", convention β_{M−1} := 1),

a degree-M polynomial vanishing at every atom. q_{jn} := √w·p_j(x_n) is the orthogonal
eigenvector matrix of J = J(μ): Σ_n q_{jn}q_{in} = δ_{ji}, Σ_j q_{jn}q_{jm} = δ_{nm}.
Sensitivity kernels at fixed weights: K_j^α(n) := ∂α_j/∂x_n, K_j^β(n) := ∂β_j/∂x_n.
Partial sums are position-ordered in the quantile index: PS_j(m) := Σ_{n≤m} K_j(n)
(= the top-atom prefix; the complementary sums Σ_{n≥m} follow from the sum rules and both
directions are included in every sup below).

## 2. Theorem 1 (exact kernel identities)

**Theorem.** For every simple-atom configuration and every ν, with all polynomials
evaluated at x_ν:

  K_j^α(ν) = w·[ p_j² + 2β_j p_j′p_{j+1} − 2β_{j−1} p_{j−1}′p_j ] = w·Φ_j′(x_ν),
      Φ_j := β_j p_j p_{j+1} − β_{j−1} p_{j−1} p_j                     (j = 0..M−1),
  K_j^β(ν) = w·β_j( p_{j+1}p_{j+1}′ − p_j p_j′ ) = w·Ψ_j′(x_ν),
      Ψ_j := (β_j/2)(p_{j+1}² − p_j²)                                  (j = 0..M−2),

where for j = M−1 the products β_{M−1}p_M, β_{M−1}p_M′ mean r, r′ (and r(x_ν) = 0).

*Proof.* Write ⟨F⟩ := ∫F dμ and differentiate in the single atom position x_ν at fixed
weights; for any polynomial family F depending on μ, ∂⟨F⟩ = w F′(x_ν) + ⟨∂F⟩ where ∂F is
the coefficient variation.

(i) *Coefficient-variation lemma.* ∂p_j = Σ_{i≤j} c_i p_i with
c_i = −w(p_j′p_i + p_j p_i′)(x_ν) for i < j and c_j = −w(p_j p_j′)(x_ν).
Indeed, differentiating ⟨p_j p_i⟩ = δ_{ij}: w(p_j p_i)′(x_ν) + ⟨∂p_j·p_i⟩ + ⟨p_j·∂p_i⟩ = 0;
for i < j the last term vanishes (deg ∂p_i ≤ i < j), giving c_i; for i = j it doubles.

(ii) *α.* α_j = ⟨x p_j²⟩, so ∂α_j = w(x p_j²)′(x_ν) + 2⟨x p_j ∂p_j⟩. By (i) and
⟨x p_j p_i⟩ = J_{ji} (only i = j, j−1 survive for i ≤ j):
2⟨x p_j ∂p_j⟩ = −2w[ α_j p_j p_j′ + β_{j−1}(p_j′p_{j−1} + p_j p_{j−1}′) ](x_ν). Collecting,

  ∂α_j/w = p_j² + 2p_j′·( x p_j − α_j p_j − β_{j−1}p_{j−1} ) − 2β_{j−1} p_{j−1}′ p_j
         = p_j² + 2β_j p_j′ p_{j+1} − 2β_{j−1} p_{j−1}′ p_j            (recurrence),

which is the first display; for j = M−1 the middle term is 2p_{M−1}′·r(x_ν) = 0.
The Φ′-form follows from the confluent Christoffel–Darboux identity
Λ_j := Σ_{i<j} p_i² = β_{j−1}(p_j′p_{j−1} − p_{j−1}′p_j): a two-line computation gives
Φ_j′ − [p_j² + 2β_j p_j′p_{j+1} − 2β_{j−1}p_{j−1}′p_j] = Λ_{j+1} − Λ_j − p_j² = 0.

(iii) *β.* β_j = ⟨x p_j p_{j+1}⟩; the same computation, using additionally the derivative
of the recurrence β_j p_{j+1}′ = p_j + (x−α_j)p_j′ − β_{j−1}p_{j−1}′ to eliminate
(x−α_j)p_j′, collapses all cross terms to β_j(p_{j+1}p_{j+1}′ − p_j p_j′) = Ψ_j′. ∎

**Corollary 1 (sum rules, recovered).** ⟨Φ_j′⟩ = 1, ⟨xΦ_j′⟩ = α_j, ⟨Ψ_j′⟩ = 0,
⟨xΨ_j′⟩ = β_j — the four proven rules of the LEMMA note — and the dual (trace) rule
Σ_j K_j^α(n) = 1. All hold for the naive q²-kernels too: the corrections are annihilated
by every moment the sum rules test. **The sum-rule check cannot separate the conjecture
from the truth; the partial sums can** (κ̂_1 = 1.077 > 1 already refutes the naive form,
whose partial sums are trapped in [0,1] by Theorem 2).

**Corollary 2 (CD split / telescope).** K_j^α(n) = q_{jn}² + G_{j+1}(n) − G_j(n) with
G_j(n) := 2w β_{j−1} p_{j−1}′(x_n) p_j(x_n); K_j^β(n) = q_{jn}q_{j+1,n} + (analogous
derivative corrections). The naive conjecture is the G ≡ 0 truncation.

**Boundary row.** K_{M−1}^α(n) = 1 − w·β_{M−2}(p_{M−2}p_{M−1})′(x_n), using the exact
solvability identity r′(x_n) = M / p_{M−1}(x_n) (project the differentiated eigen-relation
(J−λ)p′(λ) = p(λ) − r′(λ)e_{M−1} onto the null vector at λ = x_n; ‖p(x_n)‖² = M).

**Verification** (`t2_k1_kernel_identity.py`, log `t2_k1_identity_run.log`): five sections
(k,N) ∈ {(4,60),(1,60),(4,100),(1,149),(4,149)}. The forward recurrences for p, p′ at the
atoms amplify roundoff through the second-kind solution (measured growth > 1e300 by
M ≈ 145 — the same Runge mechanism as ‖E‖ ≈ 1.8e15 in the LEMMA note), so the analytic
kernels are computed in mpmath at adaptive precision (dps 300–1500) with four EXACT
a-posteriori checks (r ≈ 0 at atoms; Σ_j p_j(x_n)² = M; CD identity; r′ = M/p_{M−1}), all
passed at ≤ 1e−25. Against independent float64 central finite differences of the Lanczos
map: max deviation 5e−9…1e−7 relative to max|K| ≈ 1.8 (the FD floor), over ALL j, both
kernel families, all five sections. Sum rules on the analytic kernels ≤ 3e−15; column rule
≤ 4.4e−15. Naive-conjecture pointwise deviation: 1.55 → 1.72 (α), 0.78 → 0.87 (β), growing
with section size; j = 0 row exact (Φ_0′ ≡ 1), as the measured maxPS(j=0) = 1.000 predicted.

## 3. Theorem 2 (partial sums: projection + derivative pairings)

**Theorem.** For ANY subset A of atoms, with P_A the orthogonal projection onto
span{δ_n : n ∈ A} in L²(μ):

  Σ_{n∈A} K_j^α(n) = ⟨p_j, P_A p_j⟩ + 2β_j⟨p_j′, P_A p_{j+1}⟩ − 2β_{j−1}⟨p_{j−1}′, P_A p_j⟩,
  Σ_{n∈A} K_j^β(n) = β_j·[ ⟨p_{j+1}′, P_A p_{j+1}⟩ − ⟨p_j′, P_A p_j⟩ ],

and **0 ≤ ⟨p_j, P_A p_j⟩ ≤ 1 always** (it equals ⟨e_j, 𝟙_A(J) e_j⟩, a diagonal matrix
element of a spectral projector of J). *Proof:* sum the collected form of Theorem 1 over
A; the projector bound is immediate. ∎

Consequences:
- Had the naive identity been true, K1 would be trivial with κ̂ = 1. The measured excess
  over 1 is carried entirely by the derivative pairings.
- **Cauchy–Schwarz is refuted as a route to (b):** |2β_j⟨p_j′,P_Ap_{j+1}⟩| ≤ 2ν_j with
  ν_j := β_j‖p_j′‖_{L²(μ)}, but measured ν_j grows exponentially — at (4,60):
  ν_1..ν_12 = 1.5, 3.0, 4.4, 6.0, 8.3, 15, 42, 159, 744, 4.1e3, 2.6e4, 1.9e5, reaching
  9.0e73 at j = 54 (and overflowing float64 by j ≈ 90 at N = 149) — while the pairings'
  partial sums stay ≤ 4.7. The kernels are O(1) differences of e^{cj}-sized objects,
  pointwise AND at partial-sum level: the content of K1 is pure oscillation cancellation,
  invisible to any norm of p_j′.

## 4. Measured K1 constants (the T2a-range certificate numbers)

κ̂ := sup over all j, all m, both sum directions of |PS_j(m)| (`t2_k1_partial_sums.py`,
`t2_k1_profile_shape.py`; kernels are the mp-certified analytic ones):

| k | N | M | κ̂^α | κ̂^β | attained at | j≤12: κ̂^α / κ̂^β |
|---|---|---|------|------|---|---|
| 4 | 60 | 56 | 3.7862 | 1.8234 | j = M−1 | 1.397 / 0.580 |
| 1 | 60 | 59 | 3.7858 | 1.8270 | j = M−1 | 1.340 / 0.748 |
| 4 | 100 | 96 | 4.7533 | 2.3471 | j = M−1 | 1.405 / 0.588 |
| 1 | 149 | 148 | 5.5956 | 2.8598 | j = M−1 | 1.346 / 0.895 |
| 4 | 149 | 145 | 5.5956 | 2.8598 | j = M−1 | 1.403 / 0.634 |

Structure of the per-j profile κ_j (drop-4, N=149 shown; all sections agree at fixed j to
≤ 0.02 for j ≤ 64):

- j = 0..3: 1.000, 1.077, 1.000, 1.000 — essentially the projection part alone.
- bulk: 1.16 (j=4), 1.28 (8), 1.45 (16), 1.69 (32), 2.04 (64), 2.25 (96), 2.71 (128),
  ≤ 3.65 for all j ≤ M−6 — consistent with ≈ 0.5–0.6·log(2+j) (a least-squares fit gives
  slope 0.50–0.61 across sections, max residual ~1.0 — quote the envelopes, not the fit).
- boundary layer (last ≤ 5 rows, the Lanczos-termination region): 3.99, 4.20, 4.64,
  **5.60** at j = M−1 — where the closed boundary form of §2 lives. The two N = 149
  sections give IDENTICAL κ̂ to 4 digits: the sup is set by the small-atom (high-γ) end
  and is insensitive to the dropped top block.
- the maximizing prefix m* migrates with j: m*/M ≈ 0.01–0.4 in the bulk (the partial sum
  peaks where the polynomial's oscillation front sits among the top atoms), ≈ 0.83–0.93 in
  the boundary layer.
- the projection part is confirmed in [0,1] to 2e−15 at every (j,m); the correction part
  reaches 2.85 (M=56) → 4.67 (M=145–148).

**Verdicts for K1.** (a) exact identity + reduction: PROVEN (Theorems 1–2). (c) explicit
verified constants on the full measured range: κ̂^α = 5.60, κ̂^β = 2.86 (all j); 1.41/0.90
(j ≤ 12); per-j profile in `t2_k1_partial_sums.csv`. (b) boundedness for the measure
class: OPEN as originally stated and **false with an absolute constant** — the correct
target is the log-law (P1, §7). Uniformity in M at fixed j is clean (≤ 0.02 drift); the
sup over j grows only because M−1 grows.

## 5. Theorem 3 (K2: ordering lemma, analyticity, remainder)

**(L-ORD).** If x^D and x^F are both strictly descending, then every
x(s) = (1−s)x^D + s x^F, s ∈ [0,1], is strictly descending, with
gap_n(s) = (1−s)gap_n^D + s·gap_n^F ≥ min(gap_n^D, gap_n^F) > 0. *Proof:* gaps are linear
in s. ∎ — The |S| < 1 "atom-ordering safety condition" of the K2 prompt is thereby
DISCHARGED into an endpoint statement: order of the D-ladder (geometry: θ strictly
increasing) and of the F-ladder (data-verified 149/149; guaranteed a priori wherever
cell-confinement |S| < ½ holds, measured sup|S| = 0.846, so the direct check is the
binding certificate). No condition on intermediate configurations is needed, and the
γ-cell margin max_n|δγ_n|/min-adjacent-gap = 0.847 (measured) ties exactly to the note's
sup ρ|δ| = |S| = 0.846.

**Theorem (remainder).** Under (L-ORD)'s hypothesis, s ↦ J(x(s)) (fixed uniform weights)
is real-analytic on [0,1] (the Lanczos/Jacobi map is analytic wherever atoms are simple),
V := J(1) − J(0) satisfies the entrywise Taylor bound

  | V_entry − V^lin_entry | ≤ ½ · sup_{s∈[0,1]} | (d²/ds²) J(x(s))_entry |,
  V^lin_entry = Σ_n dx_n K_entry(n; x^D)   (Theorem-1 kernels at s = 0),

and the first derivative along the segment is Σ_n dx_n K(n; x(s)) with the SAME closed
forms at every s (identity spot-checked mid-segment: 2.7e−9 vs FD at s = ½, dps 300). ∎

**Measured constants** (`t2_k2_transport_remainder.py`, log `t2_k2_run.log`; s-grid of 33
points, central second-difference stencils, h vs 2h consistency 1.0–2.4e−3):

| k | N | sup_{j,s}|α_j″| (at j) | sup|β_j″| | max\|rem_α\| vs ½sup|α″| | quality max\|rem\|/max\|dJ\| |
|---|---|---|---|---|---|
| 4 | 149 | 1.063e−2 (23) | 4.07e−3 | 1.84e−3 ≤ 5.32e−3 ✓ | 17.4% (α), 25.3% (β) |
| 1 | 149 | 8.46e−2 (3) | 3.46e−2 | 1.60e−2 ≤ 4.23e−2 ✓ | 8.1% (α), 10.6% (β) |
| 4 | 60 | 1.12e−2 (22) | 4.29e−3 | 2.58e−3 ≤ 5.62e−3 ✓ | 24.2% (α), 18.5% (β) |

The remainder inequality holds per ENTRY (all j, both families, all three sections), with
≥ 2× margin. First-order quality 8–25% reproduces the LEMMA note's 8–24% (theirs was
j ≤ 12; ours is all j). The Hessian localizes near the top block (maximizing j = 3–23,
where dx is largest) — same localization as V itself. Normalization note: sup|J″| scales
between max|dx|·TV(dx) and (TV+sup|dx|)² across sections (ratios 1.2–17); we deliberately
quote the RAW sup|J″|, which is what the bound consumes — a clean second-order scaling
law is not yet established (part of P1's second-order twin, §8).

## 6. Assembly: the explicit chain and what it costs

Discrete Abel summation (exact): for any field b_n, Σ_n K_j(n)b_n = Σ_{m<M} PS_j(m)(b_m −
b_{m+1}) + PS_j(M)b_M, hence |Σ_n K_j(n) dx_n| ≤ κ_j·(TV(dx) + |dx_M|). Combining with
Theorem 3:

  |dα_j| ≤ κ_j^α·(TV(dx) + |dx_M|) + ½·sup_s|α_j″(s)|      (and likewise dβ_j),

**verified for every j on all three K2 sections.** Numbers (N = 149): TV(dx) = 0.0490 /
0.2695, max|dx| = 0.0129 / 0.2330 (drop-4 / drop-1 — the LEMMA note's TV = 0.0488 is the
N = 100 value 0.0488 ✓, and max|dx| = δx₄ = 0.0129 ✓). Resulting uniform bounds vs truth:

- drop-4: sup_j bound = 0.274 vs sup_j|dα_j| = 0.0106 (26×); at the peak rows j = 1–2
  (where |dα| actually sits and κ_j ≤ 1.08): bound 0.053 vs 0.0106 — **5×**.
- drop-1: sup_j bound = 1.508 vs 0.196 (7.7×).
- row-bound assembly for ‖V‖ (row_j = |dα_j| + |dβ_{j−1}| + |dβ_j|): drop-4 bound 0.472 vs
  measured 0.0198; drop-1 2.59 vs 0.2915.

The loss factors are honest and the shape is right: every constant in the chain is flat or
log in section size, and every ingredient is certifiable (mp/interval evaluation of
finite recurrences — the G2-style upgrade is mechanical). What the chain does NOT yet give
is ‖R‖ ≤ C·δx_k with small C (H-ROT): the Abel route pays κ̂·TV(dx)/δx_k ≈ 5–20 where the
truth is C_rot ≈ 1.04–1.18. Closing that factor is exactly P1 + the oscillation-scale
pairing of §8 of the LEMMA note (kernel sign changes vs windowed averages of S).

## 7. The reduced open statement (P1)

Everything unproven in K1 is now the single statement about the correction functional
C_j(A) := 2β_j⟨p_j′, P_A p_{j+1}⟩ − 2β_{j−1}⟨p_{j−1}′, P_A p_j⟩ (and its β twin):

**(P1)** For quantile-class configurations (atoms x_n = γ_n^{−2}, γ_n the quantiles of an
increasing log-type density ρ with γρ(γ) increasing; uniform weights), position-ordered
prefixes A_m satisfy
  sup_m |C_j(A_m)| ≤ c₀ + c₁·log(2+j)  uniformly in M,  plus a boundary layer of ≤ 5 rows
  (j > M−6) bounded by an absolute c₂.
Measured on the range: c₀ ≈ 0.3, c₁ ≈ 0.5–0.6, bulk envelope 3.65, boundary total 4.68;
flat in M at fixed j.

Attack notes (for IB and future sessions):
- C_j is a difference of two consecutive terms of the sequence t_j := 2β_{j−1}⟨p_{j−1}′,
  P_A p_j⟩ — the measured log-law says t_j itself telescopes to log growth even though
  each pairing is individually e^{cj}-large. The object t_j is a matrix element of the
  commutator structure [D, J] = I (D = d/dx in the p-basis, strictly lower triangular):
  the derivative pairings are the sub-diagonal transport of that identity, and P_A cuts it
  spectrally. This is a concrete OPRL/Toda question: t_j = 2⟨e_{j−1}, D 𝟙_A(J) e_j⟩·β_{j−1}.
- The flows behind the kernels are the "master-symmetry" eigenvalue flows ẋ_n = g(x_n) at
  fixed weights, J̇ = tridiagonal part of g(J) via J̇ = g(J) + [B(g,J), J]; the sum rules
  are g = 1, x. P1 is a bound on the tridiagonal-projection defect of 𝟙-cut flows.
- The w ≈ 3 elbow question (LEMMA §8) plugs in here: the kernels' oscillation scale at the
  maximizing j = 1–2 sets the window; the certified Turing/PZ bound enters through
  TV/window-averages of dx = S·u exactly as before. Nothing in today's results moves that
  pairing — but the kernels it pairs against are now exact closed forms, not measurements.

## 8. Honest gap list

- **P1** (§7) — the only new mathematical gap; K1(b) reduces to it. Note K1 as literally
  posed ("≤ C uniformly in j") is FALSE-as-measured beyond j ≈ 12; the program impact is
  benign because V localizes at j = 1–2 (per-j Abel loses only ~5× there) and the sup over
  a section grows only like log M.
- **P2** (K2's structural twin): a closed second-order kernel identity exists in principle
  (differentiate Theorem 1 along the flow; the Hessian is expressible in p, p′, p″ and the
  first-order kernels) but was not derived today; K2 is closed on the range by measured
  sup|J″| with stencil consistency 1e−3 — numerical grade, interval-upgradeable by
  evaluating J″ certified rather than by stencil.
- Theorem 1 is proven for fixed UNIFORM weights (the T2 ledger convention). The general
  fixed-weights case adds w_ν-dependence in the lemma only; not written out.
- All constants float64/FD-floor grade: identity 1e−7 worst, partial sums exact to ~1e−13
  given kernels, K2 stencils 1e−3 relative. mp internal checks at 1e−25. Production ladder
  P = 2×10⁵ inherited (G5 of the LEMMA note stands).
- The identity verification at s ∈ (0,1) is a single mid-segment spot check plus the
  endpoint verifications; the theorem needs no more (it is measure-generic), but a
  certified sweep would evaluate the kernels on an s-grid in interval arithmetic.

## 9. Verification manifest (all in this folder, `T2_K1K2_kernel_bounds_2026-07-18/`)

Data snapshot: `quantiles_production.csv` here is a verbatim copy of
`T2_pin_conjecture_2026-07-17/quantiles_production.csv` (the stage-2.2 production ladder),
so the folder is self-contained and the scripts run in place.

| script | log | what it establishes |
|---|---|---|
| `t2_k1_kernel_identity.py` | `t2_k1_identity_run.log` | Theorem-1 identities vs central FD, all j, 5 sections (5e−9…1e−7); mp pipeline with 4 exact a-posteriori checks ≤ 1e−25; sum rules ≤ 3e−15; naive-conjecture pointwise refutation (dev up to 1.72); saves `k1_kernels_k{k}_N{N}.npz` (mp-certified kernels; regenerable) |
| `t2_k1_partial_sums.py` | `t2_k1_partial_sums_run.log` | κ̂ table + per-j profiles + projection-in-[0,1] confirmation (2e−15) + ν_j explosion + Abel first-order bound verified all j; `t2_k1_partial_sums.csv` |
| `t2_k1_profile_shape.py` | (stdout in session log) | bulk-vs-boundary split, m* migration, log-fit envelopes |
| `t2_k2_transport_remainder.py` | `t2_k2_run.log` | (L-ORD) exact on 65-grid; J″ scan (h vs 2h 1e−3); remainder ≤ ½sup|J″| per entry; quality 8–25%; assembled per-j chain verified; mid-segment identity 2.7e−9 |

*— Stenberg + Claude, 2026-07-18, worktree agitated-robinson (branch
claude/agitated-robinson-17c422); no SHA (working folder). The unproven part of K1 is now
one cancellation law (P1) with its first two moments proven, its exact integrand in closed
form, and its constants measured to three digits; K2 is a theorem plus finite verified
constants on the whole production range.*
