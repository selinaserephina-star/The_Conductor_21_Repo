# t2_k1_partial_sums.py — K1 step 2: the partial-sum constants kappa-hat, their exact
# decomposition, and the Abel assembly, on the kernels certified by t2_k1_kernel_identity.py.
#
# Exact decomposition of the position-ordered partial sums (A_m = atoms n <= m, quantile
# order = descending atom values; P_A = orthogonal projection onto span{delta_n : n in A}):
#
#   sum_{n<=m} K_j^alpha(n) = <p_j, P_A p_j>  +  2 be_j <p_j', P_A p_{j+1}>
#                                             -  2 be_{j-1} <p_{j-1}', P_A p_j>,
#   sum_{n<=m} K_j^beta(n)  = be_j [ <p_{j+1}', P_A p_{j+1}> - <p_j', P_A p_j> ],
#
# with 0 <= <p_j, P_A p_j> <= 1 ALWAYS (projection).  Hence
#   |PS_j^alpha(m)| <= 1 + 2(nu_j + nu_{j-1}),   |PS_j^beta(m)| <= nu_{j+1}+nu_j... see note;
#   nu_j := be_j ||p_j'||_{L2(mu)}   (Cauchy-Schwarz, worst case).
#
# This script measures: kappa-hat per section (sup over ALL j and m), per-j profiles,
# the projection/correction split, nu_j (how lossy Cauchy-Schwarz is), growth-in-j fit,
# and the first-order Abel assembly |dal_j| <= kappa_j (TV(dx)+|dx_last|) vs truth.
import os, csv
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
gD_all, gF_all = [], []
with open(os.path.join(HERE, 'quantiles_production.csv')) as fh:
    for row in csv.DictReader(fh):
        gD_all.append(float(row['gamma_D'])); gF_all.append(float(row['gamma_fwd']))
gD_all = np.array(gD_all); gF_all = np.array(gF_all)


def jacobi(x):
    x = np.asarray(x, float); M = len(x)
    v = np.ones(M) / np.sqrt(M)
    al, be, Vs = [], [], [v]
    w = x * v; a0 = v @ w; al.append(a0); w = w - a0 * v
    for j in range(1, M):
        b = np.linalg.norm(w)
        if b < 1e-14: break
        be.append(b)
        vn = w / b
        for u in Vs: vn = vn - (u @ vn) * u
        vn /= np.linalg.norm(vn)
        Vs.append(vn)
        w = x * vn - b * Vs[-2]
        a = vn @ w; al.append(a); w = w - a * vn
    return np.array(al), np.array(be)


rows = []
for (k, N) in [(4, 60), (1, 60), (4, 100), (1, 149), (4, 149)]:
    z = np.load(os.path.join(HERE, f'k1_kernels_k{k}_N{N}.npz'))
    Ka, Kb, P, DP, al, be, x = z['Ka'], z['Kb'], z['P'], z['DP'], z['al'], z['be'], z['x']
    M = len(x); w = 1.0 / M
    print(f"=== section k={k} N={N} (M={M}) ===")
    # ---- partial sums, both directions ----
    PSa = np.cumsum(Ka, axis=1)               # PS_j^alpha(m), m = 1..M (n<=m, quantile order)
    PSb = np.cumsum(Kb, axis=1)
    # from-below sums sum_{n>=m} = rowsum - PS(m-1); rowsums are 1 (alpha) / 0 (beta)
    kap_a_j = np.max(np.abs(PSa), axis=1)     # per-j sup_m |PS|
    kap_b_j = np.max(np.abs(PSb), axis=1)
    tail_a_j = np.max(np.abs(1.0 - np.concatenate([np.zeros((M, 1)), PSa[:, :-1]], axis=1)), axis=1)
    tail_b_j = np.max(np.abs(0.0 - np.concatenate([np.zeros((M - 1, 1)), PSb[:, :-1]], axis=1)), axis=1)
    khat_a = max(kap_a_j.max(), tail_a_j.max())
    khat_b = max(kap_b_j.max(), tail_b_j.max())
    ja = int(np.argmax(np.maximum(kap_a_j, tail_a_j)))
    jb = int(np.argmax(np.maximum(kap_b_j, tail_b_j)))
    print(f"  KAPPA-HAT alpha = {khat_a:.4f} (at j={ja}), beta = {khat_b:.4f} (at j={jb})   [sup over ALL j,m, both directions]")
    print("  per-j sup_m|PS^alpha|, j=0..12: " + " ".join(f"{v:.3f}" for v in np.maximum(kap_a_j, tail_a_j)[:13]))
    print("  per-j sup_m|PS^beta| , j=0..12: " + " ".join(f"{v:.3f}" for v in np.maximum(kap_b_j, tail_b_j)[:13]))
    # growth fit vs log(2+j)
    jj = np.arange(M)
    prof = np.maximum(kap_a_j, tail_a_j)
    Afit = np.vstack([np.ones(M), np.log(2.0 + jj)]).T
    coef, *_ = np.linalg.lstsq(Afit, prof, rcond=None)
    print(f"  growth fit sup_m|PS^alpha_j| ~ {coef[0]:.3f} + {coef[1]:.3f} log(2+j)  "
          f"(profile at j=M-1: {prof[-1]:.3f}, max: {prof.max():.3f})")
    # ---- projection / correction split ----
    Q2 = P ** 2 / M                            # q_{jn}^2 rows j=0..M-1
    PSq = np.cumsum(Q2, axis=1)
    viol = max(float(PSq.min()), float((PSq - 1.0).max()))
    corr = PSa - PSq                           # partial sums of the derivative correction
    print(f"  projection part in [0,1]: min {PSq.min():.2e}, max-1 {(PSq.max()-1):.2e}; "
          f"correction part sup |.| = {np.max(np.abs(corr)):.4f}")
    # ---- nu_j = be_j ||p_j'|| and the Cauchy-Schwarz envelope ----
    nu = np.zeros(M)                           # index j = 0..M-1; nu_{M-1} uses pseudo be=1? no:
    for j in range(M - 1):
        nu[j] = be[j] * np.sqrt(np.sum(DP[j, :] ** 2) / M)
    # envelope for alpha: 1 + 2(nu_j + nu_{j-1}) (nu_{-1}=0); j=M-1 needs pseudo term: skip in envelope stats
    env = 1.0 + 2.0 * (nu + np.concatenate([[0.0], nu[:-1]]))
    print("  nu_j = be_j||p_j'||, j=0..12: " + " ".join(f"{v:.3f}" for v in nu[:13]))
    print(f"  nu_j: max over j<=M-2 = {nu[:M-1].max():.3f} at j={int(np.argmax(nu[:M-1]))}; "
          f"envelope 1+2(nu_j+nu_(j-1)): max = {env[:M-1].max():.3f} "
          f"(lossiness vs kappa-hat: {env[:M-1].max()/khat_a:.1f}x)")
    # actual pairing partial sums (the two correction terms separately, alpha)
    pair1 = np.zeros((M, M)); pair2 = np.zeros((M, M))  # 2be_j<p_j',P_A p_{j+1}>, 2be_{j-1}<p_{j-1}',P_A p_j>
    for j in range(M - 1):
        pair1[j, :] = 2 * be[j] * np.cumsum(DP[j, :] * P[j + 1, :]) / M
        if j >= 1:
            pair2[j, :] = 2 * be[j - 1] * np.cumsum(DP[j - 1, :] * P[j, :]) / M
    print(f"  pairing sups: max_j sup_m |2be_j<p_j',P_A p_j+1>| = {np.max(np.abs(pair1)):.4f}, "
          f"|2be_j-1<p_j-1',P_A p_j>| = {np.max(np.abs(pair2)):.4f}")
    # ---- Abel assembly at first order ----
    gD = gD_all[k:N]; gF = gF_all[k:N]
    xF = 1.0 / gF ** 2
    dx = xF - x
    TV = float(np.sum(np.abs(np.diff(dx)))); mx = float(np.max(np.abs(dx))); last = abs(dx[-1])
    alF, beF = jacobi(xF)
    da_true = alF - al; db_true = beF - be
    da_lin = Ka @ dx; db_lin = Kb @ dx
    abel_a = np.maximum(kap_a_j, tail_a_j) * (TV + last)
    abel_b = np.maximum(kap_b_j, tail_b_j) * (TV + last)
    ok_a = np.all(np.abs(da_lin) <= abel_a + 1e-12)
    ok_b = np.all(np.abs(db_lin) <= abel_b + 1e-12)
    print(f"  transport field: max|dx| = {mx:.4f}, TV(dx) = {TV:.4f}, |dx_last| = {last:.2e}")
    print(f"  Abel bound holds for ALL j at first order: alpha {ok_a}, beta {ok_b}; "
          f"uniform bound kappa-hat*(TV+|dx_last|) = {khat_a*(TV+last):.4f} vs max|dal^lin| = {np.max(np.abs(da_lin)):.4f} "
          f"vs max|dal_true| = {np.max(np.abs(da_true)):.4f}")
    rows.append(dict(k=k, N=N, M=M, khat_a=khat_a, khat_b=khat_b, ja=ja, jb=jb,
                     fit0=coef[0], fit1=coef[1], numax=float(nu[:M-1].max()),
                     TV=TV, maxdx=mx, abel=khat_a * (TV + last),
                     maxdalin=float(np.max(np.abs(da_lin))), maxdatrue=float(np.max(np.abs(da_true)))))
    print()

print("=== summary (kappa-hat vs section size: is K1 constant section-free?) ===")
print(f"{'k':>3} {'N':>4} {'M':>4} {'khat_a':>8} {'khat_b':>8} {'j*':>4} {'log-fit b':>10} {'max nu_j':>9}")
for r in rows:
    print(f"{r['k']:>3} {r['N']:>4} {r['M']:>4} {r['khat_a']:>8.4f} {r['khat_b']:>8.4f} "
          f"{r['ja']:>4} {r['fit1']:>10.4f} {r['numax']:>9.3f}")
with open(os.path.join(HERE, 't2_k1_partial_sums.csv'), 'w', newline='') as fh:
    wcsv = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); wcsv.writeheader()
    for r in rows: wcsv.writerow(r)
print("saved t2_k1_partial_sums.csv")
print("done.")
