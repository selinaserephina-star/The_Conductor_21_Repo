# Theorem D1 — (P1a) for the companion system is PROVEN

**Merkabit · Stenberg + Claude · 2026-07-18 (P1 session 3, same folder).** The chirped sum
isolated in `P1_string_bessel_2026-07-18.md` §0.5 is evaluated: it has an EXACT integral
representation against Legendre polynomials, and the trivial L¹ Fourier bound already
yields the 1/(1+i) law — uniformly in the cut, with explicit constants. No van der Corput,
no stationary phase: the oscillation in the cut variable m is never used. Every step
verified numerically (§3). Not RH/GRH.

## 1. Theorem D1

**Theorem.** Let μ_L = Σ_{n≥1} 2x_n δ_{x_n}, x_n = 1/z_n², z_n = (n−½)π (the infinite
companion of the string model; Theorem B1 of the session-2 note), with orthonormal OPs
p^L_i. Then for every i ≥ 1 and every prefix cut m ≥ 1:

  ĉ^L_i(m) := ⟨1_{A_m}, p^L_i⟩_{L²(μ_L)}
            = (−1)^{m+i+1}/√(4i+1) · ∫_0^1 [sin(mπt)/cos(πt/2)] · (P_{2i+1} − P_{2i−1})(t) dt,

(exact; P = Legendre), and consequently

  sup_m |ĉ^L_i(m)| ≤ L(2i)/√(4i+1),   L(k) := ∫_0^1 |P_{k+1} − P_{k−1}|(t)/cos(πt/2) dt ≤ C/√k,

so that  **sup_m (1+i)|ĉ^L_i(m)| ≤ 1.263**  (numerically evaluated L; the measured true
constant is 0.783, attained at i = 1, m = 1). This is (P1a) for the companion system.

## 2. Proof

*Step 1 (value law → string side).* By Theorem B1 and Poisson's representation
j_{2i}(z) = (−1)^i∫_0^1 cos(zt)P_{2i}(t)dt (even order),
  2x_n p^L_i(x_n) = (2/z_n)√(4i+1)·(−1)^{n+1+i}∫_0^1 cos(z_n t)P_{2i}(t)dt,
hence, summing the finite prefix,
  ĉ^L_i(m) = (−1)^i √(4i+1) ∫_0^1 G̃_m(t) P_{2i}(t) dt,
  G̃_m(t) := Σ_{n≤m} (−1)^{n+1}(2/z_n)cos(z_n t)   (a finite trigonometric sum).

*Step 2 (the full series is the constant 1).* ⟨1, √2cos(z_n·)⟩_{L²(0,1)} = √2(−1)^{n+1}/z_n,
so G̃_∞ = 1 in L²(0,1). Since ∫_0^1 P_{2i} = ½∫_{−1}^1 P_{2i} = 0 for i ≥ 1, we may replace
G̃_m by −R̃_m, R̃_m := 1 − G̃_m (smooth on (0,1): 1 minus a finite sum).

*Step 3 (closed form for the derivative).* The geometric sum
  Σ_{n≤m}(−1)^{n+1} sin(z_n t) = (−1)^{m+1} sin(mπt)/(2cos(πt/2))
(elementary; verified 4.5e−14) gives R̃_m′(t) = −G̃_m′(t) = (−1)^{m+1} sin(mπt)/cos(πt/2).

*Step 4 (integration by parts, boundary-free).* With (4i+1)P_{2i} = P_{2i+1}′ − P_{2i−1}′
and ΔP := P_{2i+1} − P_{2i−1}: the boundary terms vanish at BOTH ends — ΔP(0) = 0 (odd
Legendre polynomials) and ΔP(1) = 0 — so
  ∫_0^1 R̃_m P_{2i} = −(1/(4i+1))∫_0^1 R̃_m′ ΔP,
which is the displayed representation. (Verified against the direct Bessel value-law sums
to 2.3e−15 over a (i,m) grid.)

*Step 5 (L¹ bound, no oscillation needed).* |ĉ| ≤ L(2i)/√(4i+1) trivially. For L(k):
- (difference identity) ΔP = (2k+1)/(k(k+1))·(t²−1)P_k′(t) = −(2k+1)/(k(k+1))·sinθ·P_k¹(cosθ),
  t = cosθ;
- (edge cap) |ΔP(t)| = (2k+1)|∫_t^1 P_k| ≤ (2k+1)(1−t), and cos(πt/2) ≥ 1−t on [0,1]
  (elementary), so the integrand is ≤ 2k+1 everywhere; over 1−t ≤ k^{-2} this contributes
  ≤ (2k+1)/k² ≤ 3/k;
- (Bernstein envelope) |P_k¹(cosθ)| ≤ c₁√(k/sinθ) uniformly; for 1−t ≥ k^{-2} (so
  sinθ ≥ √(1−t) ≥ 1/k) the integrand is ≤ 2c₁·2^{1/4}·k^{-1/2}(1−t)^{-3/4}, whose integral
  is ≤ 8·2^{1/4}c₁/√k.
Hence L(k) ≤ 3/k + 10c₁/√k ≤ C/√k, and sup_m|ĉ^L_i(m)| ≤ C/(√(2i)·√(4i+1)) ≤ C′/(1+i). ∎

Numerically √k·L(k) increases to ≈ 3.065 by k = 512 (so effective C ≈ 3.07), and the
theorem-form constant (1+i)L(2i)/√(4i+1) ≤ 1.263 (max at i = 1, decreasing to ≈ 1.087).

## 3. Verification manifest

`t2_p1a_companion_theorem.py`, log `t2_p1a_companion_run.log`:
- alternating-sin closed form: 4.5e−14;
- integral representation ≡ value-law Bessel sums: max diff 2.3e−15 over
  i ∈ {1,2,5,10,30} × m ∈ {1,2,5,20,100} (sign (−1)^{m+i+1} confirmed);
- L(i)-table and constants (above);
- direct scan of sup_m(1+i)|ĉ^L_i(m)| over i ≤ 200 with m scanned past the resonance
  m* ≈ 0.65i: true constant 0.783; full-sum orthogonality residuals → 0 with the scan cap.

## 4. Remarks and what remains

- **The theorem is not sharp** — the measured sup_m(1+i)|ĉ| decays like ~i^{-0.45}
  (0.78 at i=1 → 0.08 at i=200), i.e. the true law looks like |ĉ| ~ (1+i)^{-1.45}. The L¹
  step discards the m-oscillation; a stationary-phase refinement would recover the extra
  ~√i. Not needed for (P1a).
- **Finite-M truncation**: D1 is for the infinite companion. The finite-M companion's
  coefficients deviate by the measured ~k/(2M) law (session-2 note); a rigorous
  finite-section perturbation lemma is the remaining mechanical step.
- **Transfer to uniform weights (full P1a)**: still the open core. The raw Christoffel
  telescope is cancellation-laden (|r_i| ≈ 1.15 growth); flagged routes: Christoffel at
  the CD-kernel level, λ-side orthogonal Laurent polynomials (the uniform measure in
  λ = 1/x is the Lambert S-fraction system 1,3,5,7,… directly), or a uniform-measure
  analogue of the V-transform (obstruction: √(1/M) coefficients replace 2/z_n — no closed
  antiderivative found yet).
- **(P1b) input**: the same machinery expresses the companion's ĥ-coefficients as
  integrals of triple products of Legendre-type functions — the W_j log-law for the
  companion is now a classical-integral estimate; next session's object.
- Erratum applied to session-2 note: the chirped-sum damping is z_n^{-2} (A-form), not
  z_n^{-5/2}; equivalently √(2π(4i+1))·J_{2i+½}(z_n)/z_n^{3/2} in the J-form.

*— Stenberg + Claude, 2026-07-18. The "single remaining analytic object" of the session-2
note is DONE for the companion: an exact Legendre integral representation plus a one-page
L¹ estimate give (P1a)-companion with constant 1.263 (true 0.783). What separates this
from full P1a is the weight transfer (companion → uniform) and the finite-section lemma —
structural, not oscillatory, problems.*
