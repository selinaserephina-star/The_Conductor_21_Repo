# t2_k2_transport_remainder.py — K2: second-order control of the Lanczos map along the
# linear transport segment x(s) = (1-s) x^D + s x^F, fixed uniform weights.
#
# Structure proved in the note (K1K2_kernel_bounds_2026-07-18.md):
#   (L-ORD)  gap_n(s) = (1-s) gap_n^D + s gap_n^F >= min(gap_n^D, gap_n^F) > 0 per n
#            — the linear segment between two like-ordered configurations stays ordered;
#            no |S| < 1 hypothesis needed (that condition is only about the ENDPOINT order,
#            which is data-verified).  Hence s -> J(x(s)) is real-analytic on [0,1] and
#              V - V^lin = int_0^1 (1-s) J''(s) ds,   ||V - V^lin||_entry <= 1/2 sup_s |J''(s)|.
#
# This script measures: the gap lemma numerically; alpha_j(s), beta_j(s) on an s-grid;
# J'' by central stencils at two resolutions (Richardson consistency); the remainder
# inequality per entry; the normalized Hessian constant C2 := sup_{j,s} |J''| / max|dx|^2;
# first-order quality (vs the note's 8-24%); and the assembled explicit bound
#   |dal_j| <= kappa_j^alpha (TV(dx) + |dx_last|) + 1/2 C2_j max|dx|^2
# against the true dal_j, plus the row-bound assembly for ||V||.
# Spot check: the kernel identity holds mid-segment (mp pipeline at s = 1/2, k=4 N=60).
import os, csv
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
gD_all, gF_all = [], []
with open(os.path.join(HERE, 'quantiles_production.csv')) as fh:
    for row in csv.DictReader(fh):
        gD_all.append(float(row['gamma_D'])); gF_all.append(float(row['gamma_fwd']))
gD_all = np.array(gD_all); gF_all = np.array(gF_all)


def jacobi(x):
    x = np.asarray(x, float); M = len(x)
    v = np.ones(M) / np.sqrt(M)
    al, be, Vs = [], [], [v]
    w = x * v; a0 = v @ w; al.append(a0); w = w - a0 * v
    for j in range(1, M):
        b = np.linalg.norm(w)
        if b < 1e-14: break
        be.append(b)
        vn = w / b
        for u in Vs: vn = vn - (u @ vn) * u
        vn /= np.linalg.norm(vn)
        Vs.append(vn)
        w = x * vn - b * Vs[-2]
        a = vn @ w; al.append(a); w = w - a * vn
    return np.array(al), np.array(be)


def second_deriv_scan(xD, xF, ns):
    """alpha, beta on the s-grid s_i = i/ns, i=0..ns; returns (S, AL, BE)."""
    M = len(xD)
    AL = np.zeros((ns + 1, M)); BE = np.zeros((ns + 1, M - 1))
    for i in range(ns + 1):
        s = i / ns
        al, be = jacobi((1 - s) * xD + s * xF)
        AL[i, :] = al; BE[i, :] = be
    return AL, BE


for (k, N) in [(4, 149), (1, 149), (4, 60)]:
    gD = gD_all[k:N]; gF = gF_all[k:N]
    xD = 1.0 / gD ** 2; xF = 1.0 / gF ** 2
    M = N - k
    dx = xF - xD
    print(f"=== section k={k} N={N} (M={M}) ===")
    # ---- (L-ORD) gap lemma ----
    for lbl, xx in (('D', xD), ('F', xF)):
        g = xx[:-1] - xx[1:]
        print(f"  order at {lbl}: strictly descending = {bool(np.all(g > 0))}, min gap = {g.min():.3e}")
    gDp = xD[:-1] - xD[1:]; gFp = xF[:-1] - xF[1:]
    smin = np.minimum(gDp, gFp)
    ns_chk = 64
    worst = np.inf
    for i in range(ns_chk + 1):
        s = i / ns_chk
        g = (1 - s) * gDp + s * gFp
        worst = min(worst, float(np.min(g - smin) / np.min(smin)))
    print(f"  gap lemma on 65-point grid: min_s,n (gap_n(s) - min(gapD,gapF))/min gap = {worst:.2e}  (>= 0 required)")
    # gamma-cell safety margin for the record (shift vs neighbor gap, both ladders)
    dgam = np.abs(gF - gD)
    cell = np.minimum.reduce([np.concatenate([[np.inf], gD[1:] - gD[:-1]]),
                              np.concatenate([gD[1:] - gD[:-1], [np.inf]])])
    print(f"  gamma-cell margin: max_n |dgamma_n| / min adjacent D-gap = {np.max(dgam / cell):.3f}")
    # ---- second derivative along the segment ----
    ns = 32
    AL, BE = second_deriv_scan(xD, xF, ns)
    h = 1.0 / ns
    d2a = (AL[2:, :] - 2 * AL[1:-1, :] + AL[:-2, :]) / h ** 2   # at interior grid points
    d2b = (BE[2:, :] - 2 * BE[1:-1, :] + BE[:-2, :]) / h ** 2
    # Richardson consistency at half resolution
    AL2, BE2 = AL[::2, :], BE[::2, :]
    h2 = 2.0 / ns
    d2a_c = (AL2[2:, :] - 2 * AL2[1:-1, :] + AL2[:-2, :]) / h2 ** 2
    cons = np.max(np.abs(d2a_c - d2a[1::2, :][:d2a_c.shape[0], :])) / max(np.max(np.abs(d2a)), 1e-30)
    C2a_j = np.max(np.abs(d2a), axis=0); C2b_j = np.max(np.abs(d2b), axis=0)
    mx = float(np.max(np.abs(dx)))
    print(f"  sup_s |alpha_j''|: max over j = {C2a_j.max():.4e} (at j={int(np.argmax(C2a_j))}); "
          f"beta: {C2b_j.max():.4e}; stencil consistency (h vs 2h) = {cons:.1e}")
    print(f"  normalized Hessian constant C2 = sup|J''| / max|dx|^2: alpha {C2a_j.max()/mx**2:.3f}, "
          f"beta {C2b_j.max()/mx**2:.3f}   (max|dx| = {mx:.4f})")
    # ---- remainder inequality ----
    z = np.load(os.path.join(HERE, f'k1_kernels_k{k}_N{N}.npz'))
    Ka, Kb = z['Ka'], z['Kb']
    da_lin = Ka @ dx; db_lin = Kb @ dx
    da_true = AL[-1, :] - AL[0, :]; db_true = BE[-1, :] - BE[0, :]
    rem_a = da_true - da_lin; rem_b = db_true - db_lin
    bnd_a = 0.5 * C2a_j; bnd_b = 0.5 * C2b_j
    ok_a = bool(np.all(np.abs(rem_a) <= bnd_a * 1.02 + 1e-12))
    ok_b = bool(np.all(np.abs(rem_b) <= bnd_b * 1.02 + 1e-12))
    print(f"  remainder inequality |dal - dal_lin| <= 1/2 sup_s|al''| per j: alpha {ok_a}, beta {ok_b}")
    print(f"  max|rem_a| = {np.max(np.abs(rem_a)):.4e} vs bound {np.max(bnd_a):.4e}; "
          f"max|rem_b| = {np.max(np.abs(rem_b)):.4e} vs bound {np.max(bnd_b):.4e}")
    qa = np.max(np.abs(rem_a)) / np.max(np.abs(da_true)); qb = np.max(np.abs(rem_b)) / np.max(np.abs(db_true))
    print(f"  first-order quality: max|rem|/max|d.| = {qa:.1%} (alpha), {qb:.1%} (beta)   [note: 8-24%]")
    # ---- assembled explicit bound vs truth ----
    PSa = np.cumsum(Ka, axis=1); PSb = np.cumsum(Kb, axis=1)
    kap_a = np.maximum(np.max(np.abs(PSa), axis=1),
                       np.max(np.abs(1.0 - np.concatenate([np.zeros((M, 1)), PSa[:, :-1]], axis=1)), axis=1))
    kap_b = np.maximum(np.max(np.abs(PSb), axis=1),
                       np.max(np.abs(np.concatenate([np.zeros((M - 1, 1)), PSb[:, :-1]], axis=1)), axis=1))
    TV = float(np.sum(np.abs(np.diff(dx)))); last = abs(dx[-1])
    bound_a = kap_a * (TV + last) + 0.5 * C2a_j
    bound_b = kap_b * (TV + last) + 0.5 * C2b_j
    ok = bool(np.all(np.abs(da_true) <= bound_a)) and bool(np.all(np.abs(db_true) <= bound_b))
    print(f"  ASSEMBLED |dal_j| <= kappa_j(TV+|dx_last|) + C2_j/2: holds all j = {ok}; "
          f"sup_j bound alpha = {bound_a.max():.4f} vs sup_j|dal| = {np.max(np.abs(da_true)):.4f}")
    # row bound for ||V||: row_j = |dal_j| + |dbe_{j-1}| + |dbe_j|
    row_bound = bound_a.copy()
    row_bound[:-1] += bound_b; row_bound[1:] += bound_b
    dbe_pad = np.abs(db_true)
    row_true = np.abs(da_true).copy(); row_true[:-1] += dbe_pad; row_true[1:] += dbe_pad
    print(f"  row-bound assembly: sup_j row_bound = {row_bound.max():.4f} vs measured sup_j row = {row_true.max():.4f} "
          f"(||V||_2 measured elsewhere: drop4 0.0153 / drop1 0.2436)")
    print()

# ---- mid-segment identity spot check (k=4, N=60, s=1/2) ----
print("=== mid-segment kernel-identity spot check: k=4 N=60, s=0.5 ===")
import importlib.util
spec = importlib.util.spec_from_file_location('k1id', os.path.join(HERE, 't2_k1_kernel_identity.py'))
k1id = importlib.util.module_from_spec(spec)
spec.loader.exec_module(k1id)
k, N = 4, 60
gD = gD_all[k:N]; gF = gF_all[k:N]
xs = 0.5 * (1.0 / gD ** 2) + 0.5 * (1.0 / gF ** 2)
KaF, KbF = k1id.fd_kernels(xs)
pipe = None
for dps in (300, 700):
    cand = k1id.mp_pipeline(xs, dps)
    if cand['diag']['ok']:
        pipe = cand; break
Ka, Kb = k1id.mp_kernels(pipe)
ia = np.max(np.abs(Ka - KaF)) / np.max(np.abs(KaF))
ib = np.max(np.abs(Kb - KbF)) / np.max(np.abs(KbF))
print(f"  identity vs FD at s=0.5 (dps={pipe['diag']['dps']}): alpha {ia:.2e}, beta {ib:.2e}")
print("done.")
