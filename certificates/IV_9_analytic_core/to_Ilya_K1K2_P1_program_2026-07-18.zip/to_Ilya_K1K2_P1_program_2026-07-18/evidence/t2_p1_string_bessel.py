# t2_p1_string_bessel.py — P1 dent 2: the string/Lambert/Bessel identification of the model.
#
# Claims tested:
#  (S0) the sharpened model x_n = 1/(n-1/2)^2 (the true D-ladder quantization theta/pi = n-1/2;
#       points (n-1/2)^2 pi^2 = spectrum of the uniform Neumann-Dirichlet string) reproduces
#       the production diagnostics at least as well as 1/n^2.
#  (S1) the COMPANION measure mu_L := sum_n 2 x_n delta_{x_n}, x_n = 1/z_n^2, z_n = (n-1/2)pi
#       (total mass sum 2/z_n^2 = 1 EXACTLY, Mittag-Leffler for tan) is the classical
#       Stieltjes-Lambert system: its symmetric y-side Jacobi coefficients obey
#            b_k = 1/sqrt((2k-1)(2k+1))      (Lambert's continued fraction 1,3,5,7,...),
#       up to truncation effects at finite M.
#  (S2) the companion's y-side orthonormal OP values at the atoms are ELEMENTARY:
#            s_k(1/z_n) = C_k * sqrt(z_n) * J_{k+1/2}(z_n)   (half-integer Bessel = trig),
#       tested by constancy of the ratio over n (orders k-1/2, k+1/2, k+3/2 raced).
#  (S3) Christoffel transfer, EXACT at finite M: x * mu_U(x) = (1/(2M)) mu_L, hence
#            p^L_i(x) = c_i [ p^U_{i+1}(x) - r_i p^U_i(x) ] / x,  r_i = p^U_{i+1}(0)/p^U_i(0),
#       verified at the atoms; the r_i sequence is measured (the transfer data).
#
# mp pipelines throughout (plain Lanczos at high dps, diagonal multiplication, O(K*M)).
import os
import numpy as np
from mpmath import mp, mpf
from scipy.special import jv

HERE = os.path.dirname(os.path.abspath(__file__))
import importlib.util
spec = importlib.util.spec_from_file_location('k1id', os.path.join(HERE, 't2_k1_kernel_identity.py'))
k1id = importlib.util.module_from_spec(spec)
spec.loader.exec_module(k1id)


def mp_lanczos_w(x64, w64, dps0, steps):
    """Lanczos WITH FULL REORTHOGONALIZATION in mp for the measure sum w_n delta_{x_n};
    adaptive dps until the orthogonality drift is < 1e-40. Returns al, be, P, drift."""
    M = len(x64)
    for dps in (dps0, 2 * dps0, 4 * dps0):
        mp.dps = dps
        x = [mpf(float(t)) for t in x64]
        sw = [mp.sqrt(mpf(float(t))) for t in w64]
        v = sw[:]                      # v0(n) = sqrt(w_n) (p_0 = 1, measure normalized)
        V = [v]
        al, be = [], []
        w = [x[n] * v[n] for n in range(M)]
        a = mp.fsum(v[n] * w[n] for n in range(M)); al.append(a)
        w = [w[n] - a * v[n] for n in range(M)]
        for j in range(1, steps + 1):
            b = mp.sqrt(mp.fsum(t * t for t in w))
            if b == 0: break
            be.append(b)
            vn = [t / b for t in w]
            for u in V:                # full reorthogonalization
                c = mp.fsum(u[n] * vn[n] for n in range(M))
                vn = [vn[n] - c * u[n] for n in range(M)]
            nrm = mp.sqrt(mp.fsum(t * t for t in vn))
            vn = [t / nrm for t in vn]
            V.append(vn)
            w = [x[n] * vn[n] - b * V[-2][n] for n in range(M)]
            a = mp.fsum(vn[n] * w[n] for n in range(M)); al.append(a)
            w = [w[n] - a * vn[n] for n in range(M)]
        K = len(V)
        def dot(a_, b_): return mp.fsum(a_[n] * b_[n] for n in range(M))
        drift = max(abs(dot(V[0], V[-1])), abs(dot(V[1], V[-1])) if K > 2 else mpf(0),
                    abs(dot(V[K // 2], V[-1])) if K > 3 else mpf(0))
        if drift < mpf(10) ** (-40):
            P = np.array([[float(V[j][n] / sw[n]) for n in range(M)] for j in range(K)])
            return ([float(t) for t in al], [float(t) for t in be], P, float(drift))
    P = np.array([[float(V[j][n] / sw[n]) for n in range(M)] for j in range(K)])
    return ([float(t) for t in al], [float(t) for t in be], P, float(drift))


M = 128
n = np.arange(1, M + 1, dtype=float)
zn = (n - 0.5) * np.pi
xU = 1.0 / (n - 0.5) ** 2          # uniform model atoms (scale-free version of 1/z^2)

# ---------- (S0) sharpened uniform model diagnostics ----------
print(f"=== (S0) uniform model x_n = 1/(n-1/2)^2, M={M} ===")
pipe = None
for dps in (300, 700, 1500, 3200):
    cand = k1id.mp_pipeline(xU, dps)
    if cand['diag']['ok']:
        pipe = cand; break
Ka, Kb = k1id.mp_kernels(pipe)
P = np.array([[float(pipe['P'][j][nn]) for nn in range(M)] for j in range(M)])
PSa = np.cumsum(Ka, axis=1)
tails = 1.0 - np.concatenate([np.zeros((M, 1)), PSa[:, :-1]], axis=1)
prof = np.maximum(np.max(np.abs(PSa), axis=1), np.max(np.abs(tails), axis=1))
corr = Ka - P ** 2 / M
H = corr @ P.T
chat = np.cumsum(P, axis=1) / M
csup = np.max(np.abs(chat), axis=1)
ii = np.arange(M)
a3 = float(np.max(((1.0 + ii) * csup)[1:]))
istar_last = int(np.argmax(np.abs(H[M - 1, :])))
jj = np.arange(2, M - 5)
A = np.vstack([np.ones(len(jj)), np.log(2.0 + jj)]).T
cfit, *_ = np.linalg.lstsq(A, prof[jj], rcond=None)
print(f"  dps={pipe['diag']['dps']}; kappa at j=1,4,16,64,120: "
      + " ".join(f"{prof[j]:.3f}" for j in [1, 4, 16, 64, 120]))
print(f"  bulk fit {cfit[0]:.3f} + {cfit[1]:.3f} log(2+j); kappa-hat = {prof.max():.3f}; "
      f"a3 = {a3:.3f}; i*(M-1) = {istar_last}   [production: 0.57 slope, a3 2.225, i* 59]")
alU64, beU64 = np.array([float(t) for t in pipe['al']]), np.array([float(t) for t in pipe['be']])

# ---------- (S1) companion measure: Lambert law for b_k ----------
print(f"=== (S1) companion mu_L (masses 2 x_n, atoms 1/z_n^2): y-side b_k vs 1/sqrt(4k^2-1) ===")
# symmetric y-side: 2M atoms +-1/z_n, masses x_n each (total 2*sum x_n = 2*sum 1/z_n^2 = 1)
xn_str = 1.0 / zn ** 2                                   # string-scaled atoms
y_atoms = np.concatenate([1.0 / zn, -1.0 / zn])
y_w = np.concatenate([xn_str, xn_str])
KSTEPS = 80
alY, beY, PY, orthY = mp_lanczos_w(y_atoms, y_w, 700, KSTEPS)
print(f"  orthogonality drift (plain Lanczos, dps 700): {orthY:.1e}; max|alpha_y| = {max(abs(t) for t in alY):.1e} (should be ~0, symmetric)")
print("   k    b_k          b_k*sqrt(4k^2-1)   (Lambert law PROVEN for the infinite system:")
print("                                        G_L(y) = tan(1/y) = 1/(y-1/(3y-1/(5y-...))))")
for kk in [1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64]:
    if kk <= len(beY):
        val = beY[kk - 1] * np.sqrt(4.0 * kk * kk - 1.0)
        print(f"  {kk:>4} {beY[kk-1]:.8f}  {val:.8f}")
dev = [abs(beY[kk - 1] * np.sqrt(4.0 * kk * kk - 1.0) - 1.0) for kk in range(1, min(65, len(beY)))]
print(f"  max |b_k sqrt(4k^2-1) - 1| over k<=64: {max(dev):.2e}  (finite-M truncation ~ 1/M expected)")

# ---------- (S2) Bessel values ----------
print(f"=== (S2) companion y-side OP values vs sqrt(z) J_o(z) at z_n = (n-1/2)pi ===")
for kk in [2, 5, 10, 20, 40]:
    if kk >= len(PY): continue
    s_vals = PY[kk, :M] # values at +1/z_n (first M atoms)
    best = None
    for o in [kk - 0.5, kk + 0.5, kk + 1.5]:
        Jv = jv(o, zn) * np.sqrt(zn)
        mask = np.abs(Jv) > 1e-6 * np.max(np.abs(Jv))
        r = s_vals[mask] / Jv[mask]
        # allow (-1)^n alternation
        for lbl, rr in [('+', r), ('(-1)^n', r * (-1.0) ** np.arange(1, M + 1)[mask])]:
            sd = np.std(rr) / max(abs(np.mean(rr)), 1e-30)
            if best is None or sd < best[0]:
                best = (sd, o, lbl, np.mean(rr))
    sd, o, lbl, mu = best
    cnorm = mu * mu * 2.0 / (np.pi * (2 * kk + 1))
    print(f"  k={kk:>3}: best order o = {o:+.1f} [{lbl}]: ratio mean {mu:+.4e}, rel std {sd:.2e}; "
          f"C_k^2/((2k+1)pi/2) = {cnorm:.6f}")

# ---------- (S3) Christoffel transfer, exact at finite M ----------
print(f"=== (S3) Christoffel transfer p^L_i = c_i [p^U_(i+1) - r_i p^U_i]/x at the atoms ===")
# companion on x-side (M atoms, masses prop to x_n, normalized)
wL = xn_str / xn_str.sum()
alL, beL, PL, orthL = mp_lanczos_w(xn_str, wL, 700, 60)
# uniform-model P on the SAME scale: xU_str = xn_str; the pipe above used xU = pi^2 * xn_str.
# p-values are scale-invariant under x -> c x up to the SAME polynomial evaluated at scaled
# atoms; safest: rerun uniform on string scale for the transfer test.
alUs, beUs, PUs, orthUs = mp_lanczos_w(xn_str, np.full(M, 1.0 / M), 1500, 60)
print(f"  orthogonality drift: companion {orthL:.1e}, uniform {orthUs:.1e}")
# r_i from p^U at 0 via recurrence in mp
mp.dps = 60
alm = [mpf(a) for a in alUs]; bem = [mpf(b) for b in beUs]
p0_prev, p0 = mpf(1), (mpf(0) - alm[0]) / bem[0]
r_seq = [float(p0 / p0_prev)]
for j in range(1, 55):
    p0_next = ((mpf(0) - alm[j]) * p0 - bem[j - 1] * p0_prev) / bem[j]
    p0_prev, p0 = p0, p0_next
    r_seq.append(float(p0 / p0_prev))
resid_max = 0.0
for i in [1, 3, 7, 15, 30, 45]:
    lhs = PL[i, :]
    rhs = (PUs[i + 1, :] - r_seq[i] * PUs[i, :]) / xn_str
    c = np.dot(lhs, rhs) / np.dot(rhs, rhs)
    resid = np.max(np.abs(lhs - c * rhs)) / np.max(np.abs(lhs))
    resid_max = max(resid_max, resid)
    print(f"  i={i:>3}: c_i = {c:+.6e}, rel residual = {resid:.2e}")
print(f"  transfer identity max rel residual = {resid_max:.2e}  (0 expected up to dps/orth drift)")
print("  r_i sequence (i=0..14): " + " ".join(f"{r_seq[i]:+.4f}" for i in range(15)))
print("  r_i * (i+1)... scaling probe: " + " ".join(f"{r_seq[i]*(i+1):+.3f}" for i in range(15)))
print("done.")
