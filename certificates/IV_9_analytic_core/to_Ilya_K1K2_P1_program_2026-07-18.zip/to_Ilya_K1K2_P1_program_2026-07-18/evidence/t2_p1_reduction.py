# t2_p1_reduction.py — P1 step 1: the EXACT spectral reduction of the pairing partial sums,
# verified and measured on the certified production kernels.
#
# Reduction (Theorem R1, proof = Parseval in L^2(mu) + degree count):
#   correction row      h_j := Phi_j' - p_j^2            (degree 2j; beta twin deg 2j+1)
#   C_j(m) := PS_j^alpha(m) - <p_j, P_A p_j> = <h_j, 1_{A_m}>_mu
#           = sum_{i=0}^{min(2j, M-1)}  hhat_i^{(j)} chat_i(m),
#   hhat_i^{(j)} = <h_j, p_i>_mu   (cut-free, structural),
#   chat_i(m)    = <1_{A_m}, p_i>_mu = sum_{n<=m} w p_i(x_n)   (first-column projector element
#                  <e_i, 1_A(J) e_0>; sum_i chat_i^2 = m/M <= 1).
#
# Log-law mechanism (Theorem R2): if |hhat_i| <= a1 off a band |i-i*(j)| <= b with peak <= a2*j,
# and |chat_i| <= a3/(1+i), then |C_j| <= a1*a3*(1+ln(2j)) + a2*a3*j*(2b+1)/(i*(j)-b) + ...
# = c0 + c1 log(2+j).  This script MEASURES a1, a2, b, a3 and the resonance location i*(j)
# on the certified kernels, checks the reconstruction to float64, and evaluates the assembled
# per-section bound  kappa_j <= 1 + sum_i |hhat_i| sup_m |chat_i(m)|  against the true kappa_j.
#
# Everything here is float64 on BOUNDED objects: corrections K - q^2 are the mp-certified
# kernels minus squares of orthogonal-matrix entries; P rows are bounded by sqrt(M).
import os
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))

for (k, N) in [(4, 149), (1, 149), (4, 60)]:
    z = np.load(os.path.join(HERE, f'k1_kernels_k{k}_N{N}.npz'))
    Ka, Kb, P, x, al, be = z['Ka'], z['Kb'], z['P'][:len(z['x']), :], z['x'], z['al'], z['be']
    M = len(x)
    print(f"=== section k={k} N={N} (M={M}) ===")
    corrA = Ka - P ** 2 / M                       # w * h_j at the atoms, rows j=0..M-1
    corrB = Kb - P[:M - 1, :] * P[1:M, :] / M
    # hhat matrix: H[j,i] = sum_n corrA[j,n] P[i,n]  (= <h_j, p_i>_mu)
    H = corrA @ P.T
    HB = corrB @ P.T
    # chat: C[i,m] = cumsum_n P[i,n]/M
    chat = np.cumsum(P, axis=1) / M
    # ---- T1: bandwidth + reconstruction ----
    bw_viol = 0.0
    for j in range(M):
        hi = min(2 * j, M - 1)
        if hi + 1 <= M - 1:
            bw_viol = max(bw_viol, float(np.max(np.abs(H[j, hi + 1:]))))
    rec = H @ chat                                 # rows j, cols m: reconstructed C_j(m)
    Cdir = np.cumsum(corrA, axis=1)
    rec_err = float(np.max(np.abs(rec - Cdir)))
    print(f"  T1: bandwidth violation max|hhat_i>2j| = {bw_viol:.2e}; reconstruction max err = {rec_err:.2e}")
    # ---- H2: chat decay ----
    csup = np.max(np.abs(chat), axis=1)            # sup_m |chat_i(m)| per i
    ii = np.arange(M)
    a3_profile = (1.0 + ii) * csup
    a3 = float(np.max(a3_profile[1:]))
    i_at = int(np.argmax(a3_profile[1:])) + 1
    print(f"  H2: a3 = max_i>=1 (1+i) sup_m|chat_i| = {a3:.3f} (at i={i_at}); "
          f"profile quartiles (i=1,M/4,M/2,3M/4,M-1): " +
          " ".join(f"{a3_profile[q]:.2f}" for q in [1, M // 4, M // 2, 3 * M // 4, M - 1]))
    # ---- H1: hhat envelope per j ----
    print("   j    i*(peak)  |hhat|peak  peak/(2j)   off-band max (|i-i*|>4)   sum_i|hhat chat-sup|")
    grid = [j for j in [1, 2, 4, 8, 16, 32, 64, 96, 128, M - 8, M - 4, M - 2, M - 1] if 1 <= j < M]
    kapbound = np.zeros(M); kaptrue = np.zeros(M)
    PSa = np.cumsum(Ka, axis=1)
    tails = 1.0 - np.concatenate([np.zeros((M, 1)), PSa[:, :-1]], axis=1)
    for j in range(M):
        kapbound[j] = 1.0 + float(np.sum(np.abs(H[j, :]) * csup))
        kaptrue[j] = max(float(np.max(np.abs(PSa[j]))), float(np.max(np.abs(tails[j]))))
    ok = bool(np.all(kaptrue <= kapbound + 1e-9))
    for j in sorted(set(grid)):
        istar = int(np.argmax(np.abs(H[j, :])))
        pk = float(np.abs(H[j, istar]))
        mask = np.abs(np.arange(M) - istar) > 4
        offb = float(np.max(np.abs(H[j, mask]))) if mask.any() else 0.0
        print(f"  {j:>4} {istar:>8} {pk:>11.3f} {pk/(2*j):>10.3f} {offb:>18.3f} "
              f"{np.sum(np.abs(H[j,:])*csup):>18.3f}   (kappa_j true {kaptrue[j]:.3f} <= bound {kapbound[j]:.3f})")
    print(f"  assembled bound kappa_j <= 1 + sum_i |hhat_i| sup_m|chat_i| holds for ALL j: {ok}; "
          f"max bound = {kapbound.max():.2f} (at j={int(np.argmax(kapbound))}) vs kappa-hat true = {kaptrue.max():.4f}")
    # resonance location law: is i* ~ 2j in the bulk, and aliased at the boundary?
    istars = np.array([int(np.argmax(np.abs(H[j, :]))) for j in range(M)])
    bulk = np.arange(1, M // 2)
    print(f"  resonance law: max_j<M/2 |i*(j) - 2j| = {int(np.max(np.abs(istars[bulk] - 2 * bulk)))}; "
          f"boundary i* (j=M-4..M-1): {istars[M-4:].tolist()}  [alias 2(M-1-j)+lowband expected]")
    # beta twin: same measurements condensed
    HBsup = np.zeros(M - 1)
    for j in range(M - 1):
        HBsup[j] = float(np.sum(np.abs(HB[j, :]) * csup))
    PSb = np.cumsum(Kb, axis=1)
    tb = np.concatenate([np.zeros((M - 1, 1)), PSb[:, :-1]], axis=1)
    ktb = np.maximum(np.max(np.abs(PSb), axis=1), np.max(np.abs(tb), axis=1))
    # note: beta partial sums ARE the correction (projection part is qq, included in corrB def)
    print(f"  beta twin: max_j sum_i|hhatB chat-sup| = {HBsup.max():.2f} vs kappa-hat_beta true = {ktb.max():.4f}")
    print()
print("done.")
