# The tail KLMN lemma — attempt, verdict, and the correct open core

**Merkabit · Stenberg + Claude · 2026-07-18 (stage 2.6 session).** Goal (from
`T2_pin_conjecture_2026-07-17/PLAN.md`, five-step plan): prove the tail form-bound
|⟨Vψ,ψ⟩| ≤ a⟨Dψ,ψ⟩ + b‖ψ‖² with explicit a < 1, b, matching the measured targets
(a, b) = (0.3, ~0.01 ~ D_min) on drop-k tail sections. Data: `quantiles_production.csv`
(149-quantile ladder, Euler side, P = 2×10⁵; zeros used nowhere), float64. Every inequality
below was verified numerically before being trusted; scripts and logs listed in §10.
Not RH/GRH — finite-section, explicit-constant mathematics; the wall is not crossed,
it is *relocated* (§8 says exactly to where).

## 0. Executive verdict

The attempt did not produce the lemma as planned — it produced something better-shaped:

1. **A proven KLMN lemma with a = ε_k, b = 0** — but in the *atom identification* of H with
   D (Theorem A). ε₄ = 0.0569 measured; per-n analytic bound verified 149/149; fully
   explicit constants; positivity-transferring (b = 0).
2. **An exact factorization of the pencil V** (Theorem B, machine-verified to 1e-15) that
   splits ‖V‖ into a proven functional-calculus part (= max|x^F − x^D|, bounded by the
   Theorem-A machinery) plus a Lanczos-rotation part R — measured ‖R‖ ≈ 0.009 (drop-4),
   flat in N. Corollary: KLMN with (a, b) = (0, ‖V‖), ‖V‖ = 0.0152 flat in N (drop-4).
   The prompt's target pair **(a, b) = (0.3, 0.011) is verified as a PSD certificate**
   on the production sections (both drops, N = 149) — a T2a-grade certifiable computation.
3. **The planned route is refuted** (Theorem C, measured): the basis-free / test-function
   formulation ("transport of f = x·p² over polynomials") is NOT equivalent to the pencil —
   its form-ratio κ_Q(d) crosses 1 already at polynomial degree 3 (drop-1) / 5 (drop-4)
   and reaches ~10³¹ at full degree. Steps (1), and with them the Christoffel/MZ "hard core"
   as originally posed, are dead ends — *measured, with mechanism*. The five-step plan's
   premise that stage 2.5 had placed the basis-free form within 5–7% of the pencil was a
   misreading: stage 2.5 compared V^lin to V, both pencil objects.
4. **The open core is now one sharp question** (§8): an ℓ¹/Abel bound on the sensitivity
   kernels of the Jacobi map at fixed weights — with exact sum rules proven and verified,
   partial-sum constants measured ≈ 1.0–1.4, and the windowed-signed-S norm re-entering
   exactly there (the reborn, corrected ‖S‖* question for IB).

## 1. Setup

Tail section: drop k top atoms from the first N quantiles, M = N − k. Two atom families on
(0, x_max], x_max = x_{k+1}^D:

- γ_n^D solves θ(γ)/π = n − ½ (geometry only); x_n^D = 1/(γ_n^D)².
- γ_n^F solves θ(γ)/π + S_P(γ) = n − ½ (geometry + Euler primes); x_n^F = 1/(γ_n^F)².

Both measures get uniform masses 1/M (ledger convention). ρ := θ′/π. Verified on [0.5, 30]:
ρ > 0 (min 1.4001), ρ increasing, γρ(γ) increasing (`t2_stage26_lemma_verify.py` §0).
Transport shift δ_n := γ_n^F − γ_n^D obeys, exactly (quantile equations + MVT),

  δ_n = −S_P(γ_n^F)/ρ(ξ_n), ξ_n between γ_n^D and γ_n^F  ⇒  |δ_n| ≤ |S_P(γ_n^F)|/ρ(min(γ_n^D, γ_n^F)).

Verified per-n, 149/149, no violations. Relative shift in cell units ρ|δ| = |S| (max 0.846,
mean 0.274 on the ladder).

## 2. The three identifications (the ambiguity the plan's step 1 was meant to kill)

"⟨Vψ,ψ⟩ vs ⟨Dψ,ψ⟩" is not well-posed until H's Hilbert space is identified with D's. Three
natural unitary identifications; **the form-bound constants differ wildly between them**:

| identification | V becomes | measured tail bound (k=4, N=149) |
|---|---|---|
| **I. atom map** (δ_{x_n^D} ↦ δ_{x_n^F}) | diag(x_n^F − x_n^D) | a = ε₄ = 0.0569, b = 0 (proven, §3) |
| **II. Jacobi/Lanczos map** (the pencil) | J(μ_F) − J(μ_D) | κ = 0.309 (grows with N); ‖V‖ = 0.0152 (flat) |
| **III. polynomial map** (same p in both forms) | transport of f = x·p² | κ_Q ≥ 1 from degree 5; ~10³¹ at full degree |

All three H's are unitarily equivalent *as operators* (same spectrum {x_n^F}); the pin
conjecture is a statement about a *pair* (D, V), and the pair is identification-dependent.
The T2 measurements (stages 2.1–2.2b) are all in identification II.

## 3. Theorem A (proven) — transport KLMN in the atom identification

**Theorem.** Let T: x_n^D ↦ x_n^F (monotone on the tail; order preserved, verified). On
L²(μ_D^tail) define H := T(M_x) (= M_x∘T, the multiplication operator by the transported
atom values) and D := M_x. Then for every ψ,

  |⟨(H − D)ψ, ψ⟩| ≤ ε_k ⟨Dψ, ψ⟩,  ε_k := max_{n>k} |x_n^F − x_n^D| / x_n^D ,

i.e. KLMN with a = ε_k, **b = 0**, uniformly in the section (the bound is per-atom, so it
survives every truncation and the limit trivially). Moreover, with s := sup|S| on the tail
range and using ρ > 0 increasing, γρ increasing:

  ε_k ≤ max_{n>k} |S(γ_n^F)| (γ_n^F + γ_n^D) / ((γ_n^F)² ρ(min(γ_n^D, γ_n^F)))
      ≤ (2 s_k)/(γ_{k+1}^D · ρ(t_k)) · (1 + O(s_k/(γ_{k+1}ρ))),   t_k := γ_{k+1}^D − s_k/ρ(t_k).

*Proof.* |⟨(H−D)ψ,ψ⟩| = |Σ_n (x_n^F − x_n^D)|ψ_n|²/M| ≤ max_n |x_n^F/x_n^D − 1| · Σ x_n^D|ψ_n|²/M.
The ε-bound chains |x^F − x^D| = |δ|(γ^F+γ^D)/(γ^Fγ^D)²·(γ^D)² through the δ-bound of §1;
the uniform version uses monotonicity of γρ(γ) so the max sits at n = k+1. ∎

Numbers (measured / per-n analytic bound): ε₁ = 0.2740, ε₄ = **0.0569** (bound 0.0591 in the
F-normalized variant, verified 149/149; uniform crude version 0.273 for k = 4 with
s = 0.863). The natural coefficient is exactly the plan's step-3 object 2|S(γ)|/(γρ(γ)),
and it **decays like 1/γ**: for the true S, the unconditional pointwise bounds
|S(t)| ≤ c₁ + c₂ log t of Palojärvi–Zhao (arXiv:2508.03023, Thms 2.1–2.2 with our Selberg
data λ_j = ½, N = 21⁵/π⁴, ℓ = 8, k_L = 0 — same data as the B = 57.89 Turing constant in
`to_Ilya_completeness_analysis_2026-07-17/turing_constant_chi8.py`) give ε_k finite and
explicit unconditionally, with the sup attained at the first tail cell. For S_P (finite
trigonometric sum, 18 120 terms) s_k is certifiable by interval arithmetic on a grid plus a
Bernstein derivative bound — mechanical, not done today (gap G2).

Because b = 0, this bound *transfers positivity*: q_H ≥ (1 − ε_k) q_D ≥ 0. It is the only
one of the three identifications that does.

## 4. Theorem B — the pencil V: exact factorization, and what remains

**Theorem (factorization; proven, and machine-verified to 1.1e-15).** Let J_D = J(μ_D),
J_F = J(μ_F) be the tail Jacobi matrices (uniform weights), V := J_F − J_D the pencil
perturbation (the T2 instrument). Then, with T(J_D) := Q diag(x^F) Qᵀ (functional calculus,
J_D = Q diag(x^D) Qᵀ) and W the Lanczos unitary of T(J_D) w.r.t. e₀ (W e₀ = e₀):

  J_F = Tri_{e₀}(T(J_D)) = Wᵀ T(J_D) W   (exact; unitary equivalence via the atom map),
  V = Wᵀ (T(J_D) − J_D) W + (Wᵀ J_D W − J_D) =: (transport part) + R (rotation part).

Key structure: **T(J_D) − J_D commutes with J_D** (functional calculus of one operator), and

  ‖T(J_D) − J_D‖ = max_n |x_n^F − x_n^D| =: δx_k   (exactly, spectral calculus) — proven,

with δx_k ≤ ε_k x_{k+1}^D bounded by Theorem A's machinery. Measured (N = 60/100/149):

| k | δx_k | ‖R‖ | ‖V‖₂ | C_rot = ‖V‖/δx_k | tridiag row bound |
|---|---|---|---|---|---|
| 1 | 0.2330 | 0.0744→0.0766 | 0.2434→**0.2436** | 1.044–1.045 | 0.2915–0.3006 |
| 4 | 0.0129 | 0.0090–0.0096 | 0.0152–**0.0153** | 1.175–1.179 | 0.0195–0.0198 |

**‖V‖ is flat in N to three digits** while κ_pencil grows (0.19→0.31 at drop-4) — because
D_min = 1/γ_N² → 0. This *proves at the mechanism level* what stage 2.2b-frontier measured:
the κ_tail(N) drift is entirely b-type. The Jacobi-coefficient perturbations localize:
|dα_j|, |dβ_j| peak at j = 1–2 (0.0106/0.0050 at drop-4) and fall to ~10⁻⁴ by mid-section —
V sits exactly on the coefficients where J_D itself is largest, which is why a small b
suffices at a = 0.3.

**Corollary (KLMN in identification II, one measured constant from proven).**
|⟨Vψ,ψ⟩| ≤ ‖V‖‖ψ‖² gives the pair (a, b) = (0, δx_k + ‖R‖); everything is proven except
the rotation bound ‖R‖ ≤ C·δx_k (measured C_rot − 1 ≈ 0.05–0.18, flat in N) — isolated
as (H-ROT), §8.

**PSD certificates (the T2a-grade route, demonstrated).** aJ_D + bI ∓ V ⪰ 0 checked directly
at N = 149 (`t2_stage26c_rotation.py`):

- k=1: **(0.3, 0.011) PSD OK** (margins +1.1e-2 / +1.3e-3); (0.3, 0.0001) fails; (0, 0.2436) OK.
- k=4: **(0.3, 0.011) OK**; (0.3, 0.0001) OK; (0, 0.0152) OK; (0.2, 0.02) OK; (0.1, 0.02) OK.

The prompt's target pair (0.3, 0.011) is thus a *finite, certifiable* statement per section
(interval arithmetic on two eigenvalue problems); matches the 2.2b-frontier fixed pairs.

## 5. Theorem C (obstruction, measured) — the basis-free route is refuted

Define the same-polynomial forms q_D(p) = Σ x^D p(x^D)²/M, q_H(p) = Σ x^F p(x^F)²/M and
κ_Q(d) := sup over deg p ≤ d of |q_H − q_D|/q_D. With stable (recurrence-validated)
evaluation, at N = 149 (`t2_stage26b_identifications.py` §C, b̃ = 0):

- k=1: κ_Q = 0.095 (d=0), 0.62 (1), 0.93 (2), **1.70 (3)**, 147 (5), 3.7e11 (10).
- k=4: κ_Q = 0.0033 (0), 0.096 (1), 0.336 (2), 0.591 (3), **2.40 (5)**, 1.7e6 (10), 2.4e11 (13).

At full degree the exact Lagrange evaluation operator D-atoms → F-atoms has ‖E‖₂ ≈ 1.8e15
(rows validated against mpmath dps-80 to 1e-7 relative), so κ_Q(full) ~ 10³⁰⁺ is *real*, not
roundoff. Mechanism: the quantile atom distribution (density ∝ x^{−3/2}-type near 0, no
edge clustering) is far from the arcsine/equilibrium distribution of its support, so
polynomial identification suffers exponential Runge-type amplification; adding b̃‖p‖² does
not save it (measured at b̃ up to 0.1). Consequences:

- The plan's step (1) — "basis-free formulation, no Lanczos-basis ambiguity" — is not a
  reformulation of the pencil; it is a *different and unbounded* object. The Lanczos basis
  is not an ambiguity to remove; the unitary Jacobi identification is load-bearing.
- The anticipated "hard core" (Christoffel-function control of p² on atom-spacing scale)
  was the correct diagnosis of *why route III fails* — Gauss-exactness cannot substitute,
  because the failure is already present at degree 3–5, far below section size.
- The window-knee C(w) curves of stages 2.5/2.6-pre keep their empirical meaning (they were
  computed on the pencil), but any lemma of the form "form-bound ≤ C·‖S‖*" must be stated
  in identification II.

Negative side-check (Avdonin/Kadec): the relative shifts are |S| per cell (sup 0.85 > ¼),
and the *signed* window averages of S_P along the ladder do not fall below ¼ either
(max|avg| = 0.83 / 0.62 / 0.53 / 0.41 at w = 1/3/5/10, identical for k = 1 and 4 — the max
sits at the low-t end of the tail). So no ¼-in-the-mean theorem applies at these heights,
and the w ≈ 3 elbow is *not* a ¼-threshold phenomenon.

## 6. The counting-function transport identity (kept for the record; proven + verified)

For any C¹ test h and the tail ladders, with N_X(t) := #{n ∈ tail: γ_n^X ≤ t}:

  Σ_{n∈tail} [h(γ_n^F) − h(γ_n^D)] = −∫ h′(t) [N_F(t) − N_D(t)] dt   (exact),

and for the true ladder N_F − N_D = S(t) + σ(θ/π + ½) with σ the centered sawtooth, so
partial integration consumes the *signed primitive* ∫S — where the unconditional Turing/PZ
bound π|∫S| ≤ B = 57.89 plugs in. Verified numerically to 1.1e-16 relative
(`t2_stage26b_identifications.py` §D). This was step (2)'s engine; after Theorem C it no
longer carries the main lemma (its test functions were route-III objects), but it remains
the correct bridge from certified ∫S bounds to *smoothed* ladder statistics, and the same
Abel mechanism reappears at the kernel level in §8.

## 7. What became of the five steps

1. Basis-free formulation → **refuted** (Theorem C); replaced by the identification
   trichotomy (§2) and the exact factorization (Theorem B).
2. Abel/Turing machinery → survives twice: the counting identity (§6), and — where it now
   matters — the kernel partial-sum pairing (§8).
3. Explicit a via 2|S|/(γρ) decay → **realized and proven** as ε_k (Theorem A) and δx_k
   (Theorem B), including the unconditional-S version via PZ pointwise bounds.
4. b-term below a spectral cutoff ~ D_min → **explained structurally**: ‖V‖ flat + D_min → 0
   forces the drift into b; V localizes on the top Jacobi coefficients where D is large;
   target pair (0.3, 0.011) certified as PSD (§4).
5. Second-order/remainder → measured: first-order (in atom shifts) Jacobi perturbation
   reproduces dα_j, dβ_j to 8–24% (`t2_stage26d_sensitivity.py`); the remainder is gap K2.

## 8. The reduced open core — where the wall now stands

Everything unproven is now inside one object: the **sensitivity kernels of the Jacobi map at
fixed weights**, K_j^α(n) := ∂α_j/∂x_n, K_j^β(n) := ∂β_j/∂x_n (uniform weights 1/M).

Proven and verified (finite differences, 1e-6):
- **Sum rules** (exact; shift x→x+c gives J→J+cI, scale x→(1+s)x gives J→(1+s)J):
  Σ_n K_j^α = 1, Σ_n K_j^β = 0, Σ_n x_n K_j^α = α_j, Σ_n x_n K_j^β = β_j.

Measured (k=4; M = 56 and 96 agree — the constants are section-size-free):
- ℓ¹ norms grow ~linearly in j: Σ_n|K_j^α| ≈ 1, 3.8, 5.4, 6.8, 8.0, 8.5, 9.1 (j = 0,2,…,12);
  so the worst-case route gives only |dα_j| ≤ κ_j·max|dx| with κ_j ~ j — insufficient.
- **Partial sums stay bounded**: max_m |Σ_{n≥m} K_j^α(n)| ≈ 1.000 → 1.405 (j = 0 → 12),
  while the kernel oscillates (~j sign changes). Abel summation against the transport field
  dx (TV(dx) = 0.0488, max|dx| = 0.0129 at drop-4) then gives, at first order,
  |dα_j| ≤ maxPS(K_j)·(TV(dx) + |dx|_∞) ≈ 0.069 — uniform in j and N, an order above the
  true 0.0106 but *finite and structurally right*. TV(dx) is bounded a priori:
  dx_n = S(γ_n^F)·u_n with u_n ≍ 2x_n^{3/2}/ρ_n, and Σ_n u_n ≲ Σ γ_n^{−3} converges by the
  density law — so TV(dx) ≤ 2s·Σu_n + s·TV(u) is explicit and N-uniform.

**The open statements:**
- **(K1) kernel partial-sum bound:** sup_j max_m |Σ_{n≥m} K_j^{α,β}(n)| ≤ κ̂ with κ̂
  explicit (measured ≤ 1.41 for j ≤ 12; growth looks ≤ log j). This is a concrete OPRL
  question — the kernels come from the inverse spectral map (eigenvalue motion at fixed
  norming constants, Toda-transversal flows); the sum rules are its first two moments.
- **(K2) second-order control:** the Jacobi map's modulus of continuity beyond first order
  (measured remainder 8–24% at the actual shift size).
- **(H-ROT) equivalent packaging:** ‖J(μ′) − J(μ)‖ ≤ C·max_n|x′_n − x_n| for atomic
  measures differing only in atom positions (same weights), for quantile-type
  configurations. Measured C = 1.04–1.18, flat in N. (False for adversarial configurations
  near Lanczos breakdown? — the quantile structure must enter; K1+K2 is the proof shape.)

**The reborn ‖S‖* question for IB (corrected form).** The old form ("form-bound of V ≤
C·windowed-average norm of S") was posed on route III and is dead. The correct form:
*the pairing dα_j = Σ_n dx_n K_j^α(n) consumes signed local averages of the transport field
dx ∝ S/γ³ρ against oscillating kernels of ~j sign changes; bound it by a windowed norm of S
with the window set by the kernel's oscillation scale.* The w ≈ 3 elbow should be re-derived
(or refuted) from the measured oscillation scale of K_j at the maximizing j (j = 1–2, where
dα peaks — coarse kernels, consistent with short windows being the cheap ones). The
Turing/PZ signed-integral bound B = 57.89 enters through TV/window-averages of dx exactly
here.

## 9. Honest gap list

- **G1 = K1/K2/H-ROT** (§8) — the only *mathematical* gap between here and a fully proven
  uniform pin in identification II with (a,b) = (0, C·δx_k).
- **G2**: certified sup|S_P| on the tail range + certified quantile enclosures (interval
  arithmetic on an 18 120-term trig polynomial; mechanical; needed to upgrade "measured
  ε_k, δx_k" to "certified").
- **G3**: numeric instantiation of the PZ pointwise-S constants c₁, c₂ for χ₈ (same data as
  the B-constant script; mechanical) — for the unconditional-in-S version of Theorem A.
- **G4**: identification semantics in the m→∞ limit: identification I gives a = ε, b = 0
  and transfers positivity; identification II is where all T2 measurements live and where
  b > 0 only gives semiboundedness (q_H ≥ −b). Which pair does the limit program actually
  need? This is a program-level question for IB, now stated cleanly — with the warning that
  a pure-a bound (b = 0) in identification II is empirically doubtful (κ grows with N as
  D_min → 0), while in identification I it is a theorem.
- **G5**: all measured constants are float64, P = 2×10⁵ (κ(P) stability was checked at
  stage 2.3 to ~1%); production ladder is numerical grade.

## 10. Verification manifest (all in `T2_pin_conjecture_2026-07-17/`)

| script | log | what it establishes |
|---|---|---|
| `t2_stage26_lemma_verify.py` | `t2_stage26_run.log` | geometry hypotheses; per-n δ- and ε-bounds (149/149); window averages; ‖E‖ ≈ 1.8e15 with mpmath dps-80 row validation; full-degree explosion of route III (its low-degree numbers superseded by 26b) |
| `t2_stage26b_identifications.py` | `t2_stage26b_run.log` | ε_atom, ‖V‖, row bounds, dα/dβ profiles vs N; stable-degree κ_Q(d), η(d) tables (`t2_stage26b_degree_table.csv`, `t2_stage26b_identifications.csv`); counting identity 1.1e-16 |
| `t2_stage26c_rotation.py` | `t2_stage26c_run.log` | factorization theorem check (1e-15); δx_k, ‖R‖, C_rot vs N (`t2_stage26c_rotation.csv`); PSD certificates incl. (0.3, 0.011) |
| `t2_stage26d_sensitivity.py` | `t2_stage26d_run.log` | kernel ℓ¹/partial-sum constants, M-independence, first-order quality; sum rules (inline runs, printed in session log) |

*— Stenberg + Claude, 2026-07-18. Working folder, no SHA. The unproven part of T2 is now
one inequality about orthogonal-polynomial sensitivity kernels, with its first two moments
proven and its constants measured.*
