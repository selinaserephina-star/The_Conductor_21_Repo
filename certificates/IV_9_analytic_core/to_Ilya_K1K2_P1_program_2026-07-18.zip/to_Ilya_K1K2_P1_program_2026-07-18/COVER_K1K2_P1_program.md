# To Ilya — the kernel program: five theorem groups, one sharpened question, and a menu

**Merkabit · Selina + Claude · 2026-07-18 (working folder; SHA seal only at send).**

**Lineage:** this package FOLLOWS `to_Ilya_operator_program_2026-07-18` (the operator-
program snapshot with the stage-2.6 LEMMA note, stage-26/kato scripts and tables) and is
deliberately self-contained: the LEMMA note and `quantiles_production.csv` appear in both
(byte-identical), and `evidence/T2_RESULTS_ledger_snapshot.md` SUPERSEDES the RESULTS
snapshot in the operator package (three new sessions appended). Nothing in the operator
package is modified by this one; treat them as two immutable units. Operator zip, as sent
and byte-verified against our tree:
SHA256 = 16cd0374457d60235aef01736e0fec6f40d63026f8697cb4894d6c4439521944.

This package closes most of what the T2 pin conjecture left open after the stage-2.6
session, and reduces the rest to problems that sit squarely in your territory —
continued fractions, Lommel polynomials, string spectral theory, and interval
certification. Everything below is proven + machine-verified unless explicitly marked
open; scripts, logs and notes are in `evidence/` (the kernel caches `k1_kernels_*.npz`
are regenerable by `t2_k1_kernel_identity.py` in ~minutes; excluded to keep the package
light). Not RH/GRH anywhere — finite-section, explicit-constant mathematics.

## 1. Where T2 now stands (one day's chain, newest last)

1. **Exact kernel closed forms** (`K1K2_kernel_bounds_2026-07-18.md`, Thm 1–2): the
   sensitivity kernels of the Jacobi map at fixed uniform weights are derivatives of
   explicit polynomials: K_j^α = w·(β_jp_jp_{j+1} − β_{j−1}p_{j−1}p_j)′(x_n),
   K_j^β = w·((β_j/2)(p_{j+1}²−p_j²))′(x_n). Verified vs FD to 1e−8, ALL j, five
   sections; the naive q²-guess is false pointwise but sum-rule-invisible. Partial sums
   = spectral projection ∈ [0,1] + derivative pairings; Cauchy–Schwarz refuted
   (ν_j ~ e^{cj} vs partial sums ≤ 4.7 — pure oscillation cancellation).
2. **K2 closed on the range** (ibid., Thm 3): the |S| < 1 ordering condition is replaced
   by a proven lemma (linear transport segments preserve ordering), and the second-order
   remainder is verified per entry with ≥ 2× margin. The assembled explicit chain
   |dα_j| ≤ κ_j(TV(dx)+|dx_M|) + ½sup|α_j″| holds for every j.
3. **The cut eliminated exactly** (`P1_spectral_reduction_2026-07-18.md`, R1–R3):
   C_j(m) = Σ_{i≤2j}ĥ_i ĉ_i(m) with ĥ cut-free and ĉ = projector first-column elements;
   the log-law follows from (P1a) a₃ = sup(1+i)|ĉ_i| = O(1) and (P1b) Σ|ĥ_i|/(1+i) ≲ log j.
   The Chebyshev model is solved exactly and PROVES the boundary can blow up ≍ M/(πℓ) —
   the mild boundary of our quantile class is structure, not genericity.
4. **The model is the uniform string** (`P1_string_bessel_2026-07-18.md`, B1–B2): the
   D-ladder quantization θ/π = n−½ makes the pure model atoms 1/z_n², z_n = (n−½)π. The
   companion measure (masses 2x_n, total mass exactly 1) has G(y) = tan(1/y), hence
   Lambert's CF: β_k = 1/√((2k−1)(2k+1)) exactly, and elementary OP atom values
   √((2k+1)π/2)(−1)^{n+1}√z_n J_{k+½}(z_n) — normalization PROVEN by Poisson + Parseval
   in the string eigenbasis. The uniform model is ONE exact Christoffel step away
   (verified 2.6e−14). The production quantile measure is a log-density perturbation of
   this (diagnostics agree to three digits: a₃ 2.225/2.221, boundary resonance 59/60).
5. **Theorem D1** (`P1a_companion_theorem_2026-07-18.md`): (P1a) for the companion is
   PROVEN: sup_m(1+i)|ĉ^L_i(m)| ≤ 1.263 (true 0.783), via the exact representation
   ĉ^L_i(m) = ±(1/√(4i+1))∫₀¹[sin(mπt)/cos(πt/2)](P_{2i+1}−P_{2i−1})dt and a one-page L¹
   estimate. The m-oscillation is never used; the theorem is not sharp (data ~ i^{−1.45}).

## 2. The ‖S‖* question, sharpest form yet

The pairing dα_j = Σ_n dx_n K_j^α(n) now has K in closed form, the transport field is
dx ∝ S/γ³ρ, and Abel summation is exact: |dα_j| ≤ κ_j·(TV(dx) + |dx_M|). The windowed-S
norm enters through TV/window-averages of dx, and the window is set by the oscillation
scale of Φ_j′ at the maximizing rows j = 1–2 — now computable, not just measurable.
The w ≈ 3 elbow should be derivable (or refutable) from the exact kernels; nothing is
conjectural in the chain except the two P1 halves below.

## 3. The menu (pick your priorities; everything shared by default)

**Mathematics lane:**
- **(M1) Weight transfer** (the full P1a): companion → uniform masses. The raw Christoffel
  telescope is cancellation-laden (|r_i| ≈ 1.15). Flagged routes: Christoffel at the
  CD-kernel level; λ-side orthogonal Laurent polynomials — note the uniform measure in
  λ = 1/x IS the Lambert S-fraction system 1,3,5,7,… directly; or a uniform-measure
  analogue of the string V-transform. This is the piece we'd most value your instinct on.
- **(M2) (P1b)**: the log-law for W_j = Σ|ĥ_i|/(1+i). For the companion, the same string
  transform turns ĥ into triple-Legendre integrals; if a boundary-free IBP exists as in
  D1, this falls the same way. We may attempt this next — tell us if you want it.
- **(M3) Finite-M truncation lemma**: infinite string system → finite-M section;
  coefficient drift measured ≈ 0.33k/(2M), value residuals halve as M doubles. Perturbative
  in shape.
- **(M4) P2**: closed second-order kernel identity (differentiate Theorem 1 along the
  transport flow) — would upgrade K2 from stencil-verified to identity-verified.

**Certification lane (your pipeline's style; our measured targets attached):**
- **(C1 = G2)** Certified sup|S_P| on the tail range + quantile enclosures (interval
  arithmetic on the 18,120-term trig polynomial) + the two PSD checks for
  (a,b) = (0.3, 0.011) at N = 149, both drops (margins ≥ +1.3e−3 measured). This alone
  makes the T2a finite-range self-adjointness certificate rigorous.
- **(C2 = G3)** Numeric instantiation of the Palojärvi–Zhao pointwise-S constants c₁, c₂
  for χ₈ (same Selberg data as the B = 57.89 Turing constant) — makes Theorem A of the
  stage-2.6 note unconditional in S.
- **(C3)** Independent re-verification of today's chain at your leisure: every note in
  `evidence/` lists its scripts, logs, and tolerances; the kernel identity check
  (`t2_k1_kernel_identity.py`) is the load-bearing one.

## 4. Reading order

1. `evidence/LEMMA_tail_KLMN_attempt_2026-07-18.md` (stage 2.6 — the setting, Theorems A/B/C)
2. `evidence/K1K2_kernel_bounds_2026-07-18.md` (kernel closed forms, K1 constants, K2)
3. `evidence/P1_spectral_reduction_2026-07-18.md` (the cut-free reduction + Chebyshev)
4. `evidence/P1_string_bessel_2026-07-18.md` (string/Lambert/Lommel identification)
5. `evidence/P1a_companion_theorem_2026-07-18.md` (Theorem D1)
6. `evidence/T2_RESULTS_ledger_snapshot.md` (the full T2 ledger as of tonight)

G4 remains the program-level question for you: WHICH identification does the m→∞ limit
need — the atom map (a = ε, b = 0, positivity-transferring, proven) or the pencil map
(where all measurements live, b ~ D_min)? Today's work is all in the pencil map's
service, but the question stands.

*— Selina + Claude, 2026-07-18. Working folder; no SHA until send. Negative results are
results; the constants are honest; the wall is where §3 says it is.*
