# D2 progress — the companion kernel rows in closed Bessel form; companion-K1 is one sum

**Merkabit · Stenberg + Claude · 2026-07-19 (D2 session, this folder).** Following the
step-2 refutation of the W-route (RESULTS.md), the direct attack: exact elementary closed
forms for the companion kernel rows, verified, with the j-telescope and the pointwise
cancellation now manifest. Companion-K1 is reduced to one explicit Bessel-pair sum with a
three-zone proof plan. Not RH/GRH.

## 1. Three verified identities (z = z_n = (n−½)π, ε = (−1)^{n+1}, μ = 2j+½)

**(V1) Global value law.** ŝ_k(y) = √(2k+1)·R_{k,½}(1/y) (Lommel polynomial), with the
global Bessel form R_{k,½}(z) = √(πz/2)[J_{k+½}(z)sin z − Y_{k+½}(z)cos z].
Verified three ways (orthonormal recurrence with the Lambert b_k, Lommel recurrence,
Bessel form) to 3.1e−14, k ≤ 20, off-atom. [Hand checks: k=1 gives 1/z exactly.]

**(V2) Derivative law at atoms.** ŝ_k′(y_n) = −z²√((2k+1)πz/2)·ε·[J′_ν + J_ν/(2z) + Y_ν](z_n),
ν = k+½ — the second-kind function enters exactly as OPRL theory demands. Verified vs FD
of V1 to 1.8e−6 (FD floor), k ≤ 24. [Hand check: k=1 reproduces ŝ₁′ = √3 exactly.]

**(V3) Kernel closed form + telescope.** For the companion system (Theorem 1′ weights
w_n = 2x_n), the α-kernel row is
  K_j(n) = 2πμ·J_μ(z_n)²/z_n − (π/2)·z_n²·[W_j − W_{j−1}](z_n),
  W_j := [J_{μ−1} − (2μ−1)J_μ/(2z) + Y_μ]·J_{μ+2}/(μ+1),   W_{−1} := 0,
where the first piece is exactly the projection part w_n p_j(x_n)² (its partial sums lie
in [0,1] PROVABLY, by the Dini identity of the D1 note), and the correction telescopes in
j. Verified against the finite-M mp-certified kernels: deviation 9.2e−2 (M=64) → 3.8e−2
(M=128), halving with M — i.e. the formula is the M = ∞ kernel and the finite-M deviation
is the known ~1/M truncation. j = 0 degenerates correctly (W_0 ≡ 0 at atoms, K_0 = w_n).

**The pointwise cancellation is now elementary and manifest:** J_{μ−1} + Y_μ = O(z^{−3/2})
(the two asymptotic phases cancel identically at leading order) — this is the e^{cj}-vs-O(1)
cancellation of the K1K2 note, reduced to one line of Bessel asymptotics. Moreover at the
atoms every factor is ε·(rational in 1/z): J_{k+½}(z_n) = √(2/πz)ε·A_k, Y_{k+½}(z_n) =
−√(2/πz)ε·B_k with A_k = R_{k,½}(z_n), B_k = R_{k−1,3/2}(z_n) — so ε² = 1 and
  **K_j(n) = (4μ/z²)A_{2j}² − z·{[A_{2j−1} − (2μ−1)A_{2j}/(2z) − B_{2j}]A_{2j+2}/(μ+1)
             − [A_{2j−3} − (2μ−5)A_{2j−2}/(2z) − B_{2j−2}]A_{2j}/(μ−1)}**
is an explicit RATIONAL function of z_n — no oscillatory evaluation anywhere. This is the
provable representation (and the numerically stable one, see §3).

## 2. The infinite-system profile (measured from the formula)

Scanning partial sums of K_j directly (no finite section, no OP computation) with cap
z ≤ 2μ² (the sup sits just above the turning point: m* ≈ 0.66j throughout):

  j:      1      2      4      8      16     32     64     128    192
  κ_j:  1.000  1.005  1.041  1.178  1.336  1.539  1.909  2.274  2.640

  **κ_j ≈ 0.386 + 0.382·log(2+j)** — clean logarithm through j = 192; drift flags ≤ 4e−2
  (float64 phase noise, §3); projection partial sums ≤ 0.9998 (< 1 required, proven).

The row-sum residual saturates at ≈ 0.231 for large j — the unscanned tail mass beyond
z = 2μ², constant in j (a universal tail worth computing exactly via §4's zone (iii);
it sits far from the sup and does not affect κ_j).

## 3. A numerical lesson worth recording

The trig/Bessel form of K_j is UNSTABLE in the far tail under float64: at z ~ 10⁷ each
Bessel evaluation carries ~1e−9 argument-reduction phase noise, and Σ z·(noise) across
10⁷ lattice points swamps the true partial sums (first runs showed spurious κ ~ 240 at
j = 256 with m* at scan end). The rational A/B form has no trig arguments and is stable;
the capped scan + flags above is the honest float64 compromise. The PROOF naturally uses
the rational form, where this issue does not exist.

## 4. Companion-K1, reduced: one sum, three zones

Target: sup_m |Σ_{n≤m} z_n²·ΔW_j(z_n)| ≤ (2/π)(c₀ + c₁ log(2+j)), ΔW_j := W_j − W_{j−1}.
Proof plan by zones (all machinery already exists in this program):
- **(i) below the turning point, z ≲ μ:** every term is super-exponentially small (Debye
  regime; mpmath spot checks here: |K| ≤ 2.5e−6 already at the worst sampled points, far
  smaller deeper in) — Debye bounds close this zone.
- **(ii) oscillatory zone μ ≲ z ≲ 2μ²:** the D1 machinery — products of two Bessel
  functions → Poisson double integrals → string-comb collapse → boundary-free IBP against
  Legendre-type kernels. This is where the log must come from (the measured sup sits at
  z ≈ μ, the zone's edge).
- **(iii) far zone z ≳ 2μ²:** K_j is an explicit rational function; its 1/z-expansion has
  alternating-dominated coefficients there (the D1 regime analysis verbatim), and the
  lattice sums are exact partial Hurwitz zetas — closed-form tail control.

## 5. Zone (ii) toolbox (verified; `t2_d2_zone2_products.py`)

**(Z1) Product-comb lemma (machine-exact, 4.8e−16).** For spherical Bessel functions,
  j_a(z)j_b(z) = (s_ab/2)∫_0^2 (P_a∗P_b)(τ)·trig(zτ)dτ,
trig = cos, s = (−1)^{(a+b)/2} for a+b even; trig = sin, s = (−1)^{(a+b−1)/2} for a+b odd;
P_a∗P_b = the Legendre convolution (support [0,2]). And {cos(z_nτ)} is ORTHONORMAL on
(0,2) (verified 1.2e−16) — the doubled string. Hand check a=b=0: (½)∫(2−τ)cos(zτ) =
sin²z/z² exact. **This lifts the entire D1 machinery to products of two Bessel values.**

**(Z2) Wronskian cancellation in the telescope (5e−18).** With Σ_ν := J_{ν+2}Y_ν + J_νY_{ν+2}:
  Y_μJ_{μ+2}/(μ+1) − Y_{μ−2}J_μ/(μ−1) = Σ_μ/(2(μ+1)) − Σ_{μ−2}/(2(μ−1))   (exact),
since the antisymmetric parts J_{ν+2}Y_ν − J_νY_{ν+2} = 4(ν+1)/(πz²) cancel identically
between the j and j−1 terms. Only symmetric cross-products survive the telescope.

**(Z3) Casoratian (2.8e−16 relative).** A_{k+1}B_k − A_kB_{k+1} = −1 exactly: A_k = R_{k,½},
B_k = R_{k−1,3/2} are the two solutions of the SAME recurrence u_{k+1} = ((2k+1)/z)u_k − u_{k−1}
with initials (1, 1/z) and (0, 1) — the Wronskian in rational clothes.

**(Z4) NEGATIVE (decisive): the JJ/Y split re-introduces the cancellation.** Partial sums
of the JJ-part and the Y-part separately reach ~2485 while the total stays 0.23–0.77
(j = 4…64). **E_ν := J_{ν−1} + Y_ν is the ATOMIC object of zone (ii)** — any decomposition
separating J from Y is fatal; the O(z^{−3/2}) pointwise cancellation must be kept inside
every factor that meets the lattice sum.

## 6. Handoff — zone-(ii) state and next actions (updated end of 2026-07-19)

**DONE this session (`t2_d2_neumann_reduction.py`, all machine-exact):**
- **(N0)** Y_ν = −J_{−ν} at our half-integers (0.0).
- **(N1)** Σ_ν = (4(ν+1)/z)J_{ν+1}Y_ν − 2J_νY_ν − 4(ν+1)/(πz²)  (3.5e−18).
- **(N2)** the elementary parts cancel in the j-telescope A SECOND TIME (1.1e−18): the
  full Y-content of z²ΔW_j reduces to the two products J_{ν+1}Y_ν and J_νY_ν at ν = μ, μ−2.
- **(N3)** Neumann reps with FIXED low-order kernels (9.0e−16):
    J_{ν+1}Y_ν = −(2/π)∫_0^{π/2}J_1(2z cos t)cos((2ν+1)t)dt,
    J_νY_ν = −(2/π)∫_0^{π/2}J_0(2z cos t)cos(2νt)dt
  — the j-dependence rides ONLY in the cosine frequency; the stationary point z sin t ≈ μ
  is exactly the measured sup location. The Y-content of the kernel is Fourier data of two
  fixed profiles.
- **(N4)** doubled-string Dirichlet kernel Σ_{n≤m}cos(z_nτ) = sin(mπτ)/(2sin(πτ/2)) (1.1e−13).
- **(F) reconstruction done:** F_j(τ) := Σ_n z_n²ΔW_j(z_n)cos(z_nτ) computed (j = 4, 8):
  antisymmetric about τ = 1 to 2e−15; **boundary values F(0⁺), F(2⁻) vanish** (at the
  truncation floor) — the boundary-free IBP precondition holds exactly as in D1; amplitude
  decays with j (max 0.34 at j=4, 0.13 at j=8); NOT a low-degree polynomial (fit residual
  ~0.9) — genuinely oscillatory. Partial-sum target = ∫_0^2 F_j(τ)·sin(mπτ)/(2sin(πτ/2))dτ.

**DONE (session of 2026-07-19, closed-form block — see §8):** items 1–2 of the old list
executed; closed form of F_j DERIVED AND VERIFIED (parts 8.6e−10, total 8e−13; the
JJ-collapse certified EXACT in rational arithmetic); IBP/L¹ block run with two honest
negatives and the log localized. Old items 3–4 remain (renumbered in §7's next-actions).

## 7. Zone (ii): closed form of F_j — DERIVED, VERIFIED; the estimate block localizes the log

**(F1) The closed form** (`t2_d2_Fj_closed_form.py`; μ = 2j+½, τ ∈ (0,2)): F_j = F_JJ + F_Y.
(Section written as §7; F-labels continue §6's.)

*JJ-part is LOCAL polynomial data.* With Φ_{ab} = the Z1 Legendre convolution and
  Ψ_s = Φ_{2j−1,2j+2}/(μ+1) − Φ_{2j−3,2j}/(μ−1),
  Ψ_c = (2μ−1)Φ_{2j,2j+2}/(μ+1) − (2μ−5)Φ_{2j−2,2j}/(μ−1):
  **F_JJ(τ) = (1/2π)[Ψ_s‴(2−τ) − Ψ_s‴(τ)] − (1/4π)[Ψ_c″(τ) − Ψ_c″(2−τ)]**
(the z³-sin and z²-cos combs are δ‴/δ″ combs; only the interior points σ = τ, 2−τ hit).

*Y-part is two Schlömilch-type integrals of the fixed N3 profiles.* Per-n EXACT
boundary-free IBP in t (z J₁(2z cos t) = (1/2sin t)·d/dt J₀(2z cos t); g₁ = Δc₁/(2 sin t)
= −2 sin((2μ−1)t)cos t vanishes at BOTH ends) kills the J₁ kernel; the comb then collapses
by the classical Schlömilch closed form (verified 4.2e−12, incl. the a < min(τ,2−τ) ⇒ 0 zone)
  S₀(a,τ) := Σ_n J₀(a z_n)cos(z_nτ) = (1/π)[𝟙(a>τ)/√(a²−τ²) − 𝟙(a>2−τ)/√(a²−(2−τ)²)],
giving, with Q[h](x) := ½∫₀^{π/2} h(arcsin(β(x)sinψ))/√(1−β(x)²sin²ψ)dψ, β(x) = √(1−x²/4),
Δc₀(t) = cos(2μt)/(μ+1) − cos((2μ−4)t)/(μ−1):
  **F_Y(τ) = (4/π²)[Q[g₁′](τ) − Q[g₁′](2−τ)] − (2/π²)·d²/dτ²[Q[Δc₀](τ) − Q[Δc₀](2−τ)]**
(the d²/dτ² taken by Cauchy-circle differentiation; Q is analytic in x off {0, ±2}).
The moving √-singularity 2cos t = τ is exactly the stationary point z sin t ≈ μ of N3.

**Verification (tapered lattice sums as reference, self-validated by N-doubling):** parts
match at 8.6e−10 (the taper floor), **the TOTAL at 8e−13** (the parts' equal-and-opposite
non-decaying tails cancel), j = 2, 4, 8. Both F_JJ and F_Y are manifestly antisymmetric
about τ = 1; F(0⁺) = 0 is inherited (F is EVEN — see F′-jump below).

**(F2) Exact collapse certificate** (`t2_d2_diag_jj8d.py`): in exact rational arithmetic,
the per-n IBP Laurent series at the atoms (sin 2z_n = 0, cos 2z_n = −1; T[p] = z²(p(0)+p(2))
− z⁻²T[p″], analog U for cos), resummed through the Euler-type functions S_{2m}(τ) =
Σ_n z_n^{−2m}cos(z_nτ) (S₂ = (1−τ)/2, S″_{2m} = −S_{2m−2}, S_{2m}(0) = (2^{2m}−1)ζ(2m)/π^{2m}),
is IDENTICALLY the δ-form — sympy difference = 0 at j = 4, 8. The JJ comb collapse is a
finite exact polynomial identity (Lidstone-type two-point resummation), not an asymptotic
statement. Only the Abel step Σcos = 0, Σz²cos = 0 (interior τ) is analytic input.

**(F3) Two numerical lessons** (recorded next to §3's):
- *Small-z edition of §3:* the forward Lommel recurrence for A_k is catastrophically
  unstable BELOW the turning point (A is the minimal solution for k > z; error grows along
  B ~ 1e13 by j = 8). Hybrid evaluation: jv/yv with the prefactor stripped for z < 3k_max+20,
  rational recurrence beyond. Poisoned rows are invisible to N-doubling checks — they are
  fixed contributions; always cross-check the small-n block against mp/jv separately.
- *mpmath-lambdify float trap:* passing a float τ into a lambdified high-degree polynomial
  computes s**31 in FLOAT64 before touching the exact mpf coefficients — a 1e−5-level,
  edge-concentrated, j-growing poisoning of F_JJ at j = 8 that perfectly mimicked a missing
  analytic term. Convert arguments to mpf first. (Cost of the hunt: one exact-arithmetic
  certificate (F2) — kept, since it upgrades the proof status of the collapse.)

**(F4) Estimate block** (`t2_d2_Fj_ibp_log.py`; F on 2¹⁸-point grids via FFT fold of the
tapered coefficients — verified against direct sums at 4.8e−16):
- **Exactness:** C_m := Σ_{n≤m} z²ΔW_j = ∫₀²F_j(τ)D_m(τ)dτ, D_m = sin(mπτ)/(2sin(πτ/2)) —
  verified to 8e−8 (trapezoid floor), j = 4.
- **Boundary-free IBP:** C_m = 2F_j′(0⁺)/(mπ²) + (1/mπ)∫₀²(F_jg)′cos(mπτ)dτ, g = 1/(2sin(πτ/2)).
  F is even, so F′(0⁺) is the emergent JUMP of F′ (fully formed only for τ ≫ 1/z_N — fit
  above the truncation scale). Verified to the discrete-edge floor (residual ≈ 0.084/m,
  0.3% of C_m·m).
- **NEGATIVE (structural):** the naive L¹ bound after one IBP fails — ‖(F_jg)′‖₁ ≈ 4.5 → 7445
  (j = 2 → 64), ~j², so S_bound ~ j: the absolute value destroys the high-frequency
  cancellation. **Z4 recurs at the kernel level: never separate F from the signed pairing
  against D_m** (equivalently: the JJ/Y parts must stay recombined under ∫·D_m).
- **Uniform bound (partial win):** |D_m| ≤ g pointwise ⇒ sup_m|C_m| ≤ Γ_j := ∫₀²|F_j|g dτ =
  0.37 → 3.76 ≈ 0.47·√j. Kills the naive j but not yet log. The √j is real: sup|F_j| ≈
  0.43√j and ‖F_j‖₂ = √(Σc_n²) ≈ 0.26√j (Parseval; the O(1)-amplitude oscillation zone has
  n-width ~ j).
- **The log localized:** S_true := sup_m|C_m| = **−0.174 + 0.216·log(2+j)** (j = 2..64, max
  resid 0.064), and κ_j ≤ 1 + (π/2)S_true gives c₁ = (π/2)·0.216 = **0.34** — consistent
  with the directly measured κ_j slope 0.382 (§2). The log therefore lives ENTIRELY in the
  m-signed cancellation of ∫F_jD_m near m* ≈ 0.66j (the moving-singularity/stationary
  region 2cos t = τ ↔ z sin t ≈ μ), not in any absolute-value norm of F_j.

**(F5) The exact σ-calculus of C_m** (`t2_d2_sigma_calculus.py`, session 2 of 2026-07-19).
Both halves of πc_n = πz²ΔW_j(z_n) are EVEN Laurent polynomials in 1/z at the atoms with
exact rational coefficients: the Y half from Lommel A·B products, the JJ half from A·A
products (and, cross-checked EXACTLY, from the T/U atom-IBP calculus of the Z1 integrals:
T[p] = z²(p(0)+p(2)) − z⁻²T[p″], U[p] = −(p′(0)+p′(2)) − z⁻²U[p″]). With σ_k(m) = partial
tail-zetas and ρ_k(m) = π^{−2k}ζ_H(2k, m+½), per j EXACT in rational arithmetic:
- **g₋₁ = 0 and g₀ = 0** — the z²- and constant-sectors of JJ and Y cancel identically
  (JJ constant = −Y constant → 2⁻ as j → ∞);
- **the row-sum identity: Σ_{k≥1} g_k(2^{2k}−1)ζ(2k)/π^{2k} = 0 EXACTLY** (ζ(2k)/π^{2k}
  is rational — C_∞ = 0 is a pure rational identity), j = 2, 3, 4, 8;
- hence **C_m = −(1/π)Σ_{k≥1}g_kρ_k(m)** — an exact finite formula for EVERY partial sum
  (verified vs direct sums 4e−14; per-atom Laurent exact at all n, 1e−15 floor).
- **Zone (iii) closes:** beyond z = 2μ² the ρ-series is alternating-dominated with
  r = |Σ_{k≥2}|/|g₁ρ₁| ≤ 0.04 (decreasing in j) ⇒ |C_m| = |g₁|ρ₁(m)(1 ± 0.04); the §2
  universal tail is g₁-leading with g₁/μ² → ≈ −8/π. The same machinery is the zone-(iii)
  proof skeleton. Casoratian assert (A_{k+1}B_k − A_kB_{k+1} = −1 identically) wired in.
- **Third float-trap lesson (F3 genus):** sympy nsimplify on unevaluated exact Adds
  round-trips through float64 — it silently truncated a fractional part 14/19 sitting at
  the 17th significant digit of one deep T-coefficient, producing a phantom exact-looking
  TU-vs-AA mismatch of 14/19·z⁻¹⁴ = 7/(μ+1)·z^{−(4j−2)}. Never nsimplify exact data;
  convert via cancel + numer/denom. (The F2 certificate is unaffected — its inline
  laurent() never left sympy objects.)

**(F6) Log localization measured** (`t2_d2_log_localization.py`): envelope of c_n peaks at
**x = n/j = 2/π exactly** (the turning point z = μ in atom units), peak amplitude O(1)
CONSTANT in j; far envelope j-collapses to ≈ (x_t/x)² (matching |g₁|/(πz²)); m*/j → 2/π
from above (0.688 → 0.637, j = 32 → 512). The turning-window (0.55j, 0.8j] contribution
grows then saturates (−0.19 → −0.54); S_true = sup_m|C_m| grows ~0.5–0.7·log per octave at
j = 256–512 — STEEPER than the j ≤ 64 fit (0.216 log): the j ≤ 64 regime is pre-asymptotic
for the correction sup. Rows verified vs mpmath at 3e−13 (incl. deep-zone rows patched for
scipy under/overflow at order ≳ 250 — NaN from 0·∞ products, `c_total()` wrapper).
**Y-side analytic handle verified** (exact finite-m, no Abel step, dev = quadrature floor):
  C_m^Y = (8/π²)∬ g₁′(t)D_m(2cos t sinφ)dφdt − (4/π²)∬ Δc₀(t)D_m″(2cos t sinφ)dφdt —
the stationary-phase object for the sup zone (critical manifold 2cos t sinφ at the
D_m-frequency; the measured sup at the turning point is its caustic).

**OPEN FLAG (must be resolved before trusting the κ-asymptote):** reproducing κ_j from
tonight's verified rational rows (proj = 4μA_{2j}²/z², K = proj − (π/2)c_n, mp-patched)
gives κ = 1.041 at j = 4 (= §2's table) but FLATTER-then-steepening values beyond
(1.06, 1.14, 1.08, 1.43, 1.40, 1.73, 1.91, 2.29, 2.70 at j = 8..512, non-monotone at
32–128) vs §2's table (1.178, 1.336, 1.539, 1.909 at j = 8..64); the opposite correction
sign also fails to reproduce §2. Either §2's scan protocol differs (drift-flag handling /
row assembly) or its large-j values carry residual float noise. RESOLVE by diffing K rows
against the committed `t2_d2_kappa_infinite.csv` + rerunning `t2_d2_bessel_kernels.py`'s
scan block against tonight's rows. The 0.382-log headline slope is UNCONFIRMED beyond the
fit range until this closes; the program only needs polylog, which all variants satisfy.
**[RESOLVED same day — see (F7) below.]**

**(F7) κ-protocol flag RESOLVED — and the §2 log law is SUPERSEDED**
(`t2_d2_kappa_protocol_resolution.py`, third session of 2026-07-19). No bug on either
side: §2's κ is **max(sup_fwd, sup_rev)** with sup_rev = sup_m|1 − ps_{m−1}| (the
tail-sum branch via row-sum = 1, initialized at 1.0); the flag-raising reconstruction
measured only sup_fwd. Rerunning max(fwd, rev) on the verified rational rows reproduces
`t2_d2_kappa_infinite.csv` to ALL displayed digits at every overlapping j (8..192), same
m*. At large j the sup is always the rev branch = 1 + |negative excursion|, the negative
excursion being the (π/2)-correction dip at the turning point.
**Extension to j = 256, 384, 512 (verified rows): κ = 2.9103, 3.2891, 3.7008** — far
above the §2 fit (2.51, 2.66, 2.77). Growth-law discrimination over j = 64–512:
κ/j^{1/3} = 0.477, 0.451, 0.458, 0.458, 0.453, 0.463 (FLAT ± 3%); κ/log and κ/log^{3/2}
rise monotonically (rejected); local exponent d ln κ/d ln j = 0.30 → 0.35.
**REVISED HEADLINE: κ_j ≈ 0.46·j^{1/3} (measured 64 ≤ j ≤ 512), NOT c₀ + c₁log(2+j)** —
the §2 fit over j ≤ 192 was a pre-asymptotic misfit of slow power growth. The mechanism
matches (F6): coherent same-sign accumulation over the Airy caustic window of width
~μ^{1/3} atoms at the turning point n/j = 2/π (O(1) amplitude there ⇒ excursion ~ j^{1/3}).
§2's table stands as data; its FIT LINE is superseded by this dated note (no silent edit).
Likewise §2's "universal tail ≈ 0.231 constant" is pre-asymptotic — the exact σ-calculus
gives (π/2)|C_{cap}| → 2/π² = 0.2026 at cap z = 2μ² (the j ≥ 384 scan's larger residuals
0.28–0.32 carry far-tail float drift over ~10⁵–10⁶ rows; the sup region m ≲ few·j is
clean, so the κ values are unaffected).
**PROGRAM IMPLICATION (flag for the T2 chain + IB):** the K1-model target "κ_j ≤ c₀ +
c₁log(2+j)" is FALSE for the companion model as stated; the true target is κ_j ≤ C·j^{1/3}
(C ≈ 0.46 measured). Whether j^{1/3} (vs polylog) is tolerable must be checked at the
consumer — the tail assembly's j-weights in the K1K2 chain. The finite-range certificate
κ̂ = 5.60 (all j, N ≤ 149) is untouched: at j ≤ 149, 0.46j^{1/3} ≤ 2.45.

**(F8) The caustic ladder to j = 8192 on certified Miller rows — the law refines to
j^{1/3}·√log, and (F7)'s large-j values are corrected**
(`t2_d2_caustic_exponent.py`, fourth session of 2026-07-19; consumer check in
`CONSUMER_CHECK_j13_2026-07-19.md` ran between F7 and F8).
- **Fourth float-trap lesson (the family grows):** at the scipy underflow boundary
  (jv → 0/denormal while yv is huge-but-FINITE) the hybrid rows contain GARBAGE-FINITE
  values — no NaN, so invisible to non-finite patches and to spot checks that miss the
  exact boundary row. At j = 512 a single such row (n = 127, z/μ = 0.388) carried 0.0849
  and contaminated every scipy-hybrid excursion at j ≥ 512 (including (F7)'s κ at
  256–512, by ≤ 0.085; corrected κ(512) = 3.6159). CERTIFIED replacement: pure-rational
  rows everywhere — backward Miller for A (minimal solution; free exact normalization
  A₀ = 1) and forward B, both in log-mantissa form; verified vs mp at ≤ 2e−13 (j ≤ 1024,
  where mp converges), ktop-stability ≤ 2e−14 at all j, and vs scipy/mp per-row 4e−16 in
  the clean zone.
- **The ladder (E_j = |min_m ps_m|, m*_E/j = 0.637 = 2/π at EVERY j):**
    j:      256     512     1024    2048    4096    8192
    E_j:    1.9103  2.6159  3.5116  4.6432  6.0641  7.8836
  local exponent 0.454 → 0.379 (still falling — pure powers rejected);
  E/j^{1/3} rises 0.30 → 0.39; E/√j falls 0.119 → 0.087; but
  **E_j/(j^{1/3}√ln j) = 0.128, 0.131, 0.133, 0.133, 0.131, 0.131 — FLAT ± 2% over five
  octaves. REVISED LAW: κ_j = 1 + E_j, E_j ≈ 0.131·j^{1/3}(ln j)^{1/2}** — the Airy
  caustic window (μ^{1/3} atoms at n/j = 2/π) with a half-log enhancement. ((F7)'s pure
  0.46j^{1/3} was itself a two-octave artifact of contaminated 256–512 values — the flag
  discipline caught it one session later; honest statement: best-fit composite law above,
  with a slowly-drifting pure power j^{0.35±0.02} not fully excluded even at 8192.)
- Olver collapse table (c_n at s = (z_n−μ)/μ^{1/3}): profile values O(1) at fixed s with
  no systematic amplitude growth visible through the coarse-s phase sampling; the s < 0
  side is j-stable (+0.08 at s = −2, +0.2 at s = −1); profile extraction needs
  phase-aligned sampling (next session, the Olver derivation).
- CONSUMER CHECK unchanged in verdict (√log j × j^{1/3} still ≪ the per-row window gain
  ~j; P1 restated target becomes κ_j ≤ C·j^{1/3}(log j)^{1/2}, or conservatively
  C·j^{1/3+ε}).

**(F9) The caustic profile DERIVED — the law closes in closed form, and the √log of (F8)
is refuted by an out-of-sample test** (`t2_d2_caustic_profile.py`,
`t2_d2_law_decision.py`, `t2_d2_olver_profile.py`, `t2_d2_kappa_full_ladder.py`;
fifth session of 2026-07-19).

- **Phase-aligned profile (the (F8) pending item).** Sampling coordinate = the EXACT
  Olver variable: σ = μ^{2/3}ζ(z/μ) from the Airy phase χ = μ(√(x²−1) − arccos(1/x))
  (x>1) resp. μ(arccosh(1/x) − √(1−x²)) (x<1); ŝ := −σ/2^{1/3} (ŝ ≈ s near the
  caustic). At fixed ŝ the fast phase 2χ is j-independent, so profiles collapse
  pointwise; the oscillatory side is demodulated against {1, cos 2χ, sin 2χ} with the
  exactly known per-atom phases (LSQ — no Nyquist requirement). Measured: smooth-side
  collapse 1024→4096 at 9.0e−3 max (converging ~μ^{−2/3}: 2.4e−3 at 4096→8192);
  smooth-side tail same-sign, ≈ 0.267·|ŝ|^{−1.6} on [−60,−2] (→ −3/2 asymptotically,
  see derivation); oscillatory-side DC ≈ 0 (|P| ≤ 2.5e−3 for ŝ ≥ 4 at j = 8192 — the
  s > 0 side nets nothing into E); B(S) := −Σ_{−S≤ŝ≤ŝ*}K SATURATES (85–93% of E from
  |ŝ| ≤ 10). A convergent profile integral leaves NO ROOM for a √log window mechanism.
- **Law decision — (F8)'s residual ambiguity settled, against (F8)'s composite law.**
  E = a·μ^{1/3} + c fits the six-point ladder at 0.41% max residual (a = 0.3432,
  c = −0.844, LSQ) vs 2.6%/2.8% for b·j^{1/3}√ln j with/without offset. OUT-OF-SAMPLE
  at j = 16384 (fits frozen on j ≤ 8192; rows ktop-certified 1.5e−11):
  measured E = 10.1571 at m*/j = 0.6366; offset model predicts 10.1390 (−0.18%),
  √ln law 10.3662 (+2.06%). And with zero fitted parameters: E(16384) − E(8192) =
  2.2735 vs a_∞·Δμ^{1/3} = 2.2875 (0.6%). **The (F8) √ln enhancement is REFUTED — it
  was a two-parameter mimic of the additive constant** (E/μ^{1/3} = a − 0.86μ^{−1/3}
  reproduces every point; the falling local exponent 0.454 → 0.379 is exactly the
  constant-offset signature). ((F8)'s honest hedge "drifting pure power not fully
  excluded" was the right instinct — the truth is the drifting-effective-power family,
  asymptote pure 1/3.)
- **The Olver derivation (numerics-first, every stage verified).** Uniform asymptotics
  J_ν(z) ≈ φ_ν Ai(σ_ν), Y_ν ≈ −φ_ν Bi(σ_ν), σ_ν = ν^{2/3}ζ(z/ν): per-function vs mp at
  j = 256: ≤ 3.3e−4 (O(ν^{−4/3}) as expected); the exact-σ four-product assembly vs
  certified rows: 6.6e−7 rel at j = 1024, 7.2e−8 at 4096 (the dropped-B₀ errors largely
  cancel in the telescope too). Order shifts: σ_{μ+r} = σ + rΔ + O(ε²), Δ = α/√σ →
  2^{1/3}ε, ε = μ^{−1/3}; the telescope kills the AB-order (the 1/(μ±1) split leaves
  −2/(μ²−1)·AB = O(ε⁶)) and the leading survivor is the Δ-block:
    **dW = −(2Δφ²/μ)[(AiBi)′(σ) + Δ·(AiAi′)′(σ) + O(ε²)]**
    ⟹ **Φ_∞(ŝ) = −4·(AiBi)′(σ), σ = −2^{1/3}ŝ**  (the task-file's predicted
    Airy-pair structure, with the AiAi′-type term as the first CORRECTION Ψ₁, not a
    leading co-term).
  Verified: Richardson extrapolation (4096/8192/16384 in powers of ε, killing ε and ε²)
  of the measured profile vs Φ_∞: **max dev 8.0e−5** on ŝ ∈ [−18, −0.12] (target 1e−3);
  Ψ₁ = −4·2^{1/3}(AiAi′)′ confirmed: median(meas/derived) = 0.998, spread ±0.01 — the
  hand algebra is verified through TWO orders. Oscillatory side (trig/Debye telescope):
    **c_osc = −(4/π)(1 − sin θ)cos 2ψ, θ = arccos(μ/z)** — envelope verified 1.8e−3 rel
  at j = 8192 (1.4e−2 at 1024, the O(ε²) drift); (F8)/(step-1)'s apparent envelope decay
  "ŝ^{−0.15}" is this uniform θ-shape, not a power law; A → 4/π at fixed ŝ, matching
  Φ_∞'s envelope. Tails of Φ_∞: smooth side (1/(π√2))|ŝ|^{−3/2} (the measured −1.6 over
  a finite range); oscillatory envelope 4/π·(1+o(1)) with DC O(ε²) — both as measured.
- **The integral and the closed-form law.** ∫₀^∞(AiBi)′ = −Ai(0)Bi(0) (calculus;
  finite-T identity verified to dps, AiBi(T) ~ 1/(2π√T) → 0), so
    I_∞ = ∫_{−∞}^0 Φ_∞ dŝ = 4·2^{−1/3}Ai(0)Bi(0),  E_j = (μ^{1/3}/2)I_c + O(1):
    **E_j = a_∞·μ^{1/3} + O(1),  a_∞ = 2·2^{−1/3}Ai(0)Bi(0) = 2^{2/3}·3^{−5/6}/Γ(2/3)²
    = 0.346555…**  (curiosity: numerically 5e−5 from (ln 2)/2 — NOT equal).
    **κ_j = 1 + E_j = a_∞μ^{1/3} + O(1) = 0.43663·j^{1/3}·(1 + o(1)).**
  Ladder residuals E_j − a_∞μ^{1/3}: −0.863 → −0.933 (j = 256 → 16384), slow drift
  ≈ −0.762 − 0.0166 ln μ empirically (max resid 0.010) — an O(1)-with-slow-drift
  subleading term (Euler–Maclaurin/core discreteness + the ∫Ψ₁ constant + zone-(i)
  block); NOT resolved into a closed form, recorded empirically. |c_j| < 1 on the
  whole measured range.
- **Bounds (the (F8) targets, upgraded — no log needed).** Upper, derivation-grade:
  E_j ≤ (μ^{1/3}/2)∫|Φ_∞| + R_j with ∫|Φ_∞|dŝ = I_∞ (positivity below) and R_j = O(1)
  from: Olver remainders over the uniform window (Olver's explicit error bounds;
  per-row O(ε)·Ψ₁ integrates to O(1), B₀-order terms to O(μ^{−1/3})), zone-(i) Debye
  block x < x₀ (measured ≤ 0.02 beyond |ŝ| = 128; lemma pending), zone (iii) exact via
  σ-calculus (F5). Target statement: **κ_j ≤ 1 + a_∞μ^{1/3} + C₀, absolute C₀** —
  STRONGER than the (F8) target C·j^{1/3}(log j)^{1/2} (no log). Pending to make it
  theorem-grade: (L-a) quantified Olver-remainder accumulation, (L-b) zone-(i) lemma.
  Lower, kills log-K1: Φ_∞ > 0 on the whole smooth side ((AiBi)′ < 0 on (0,∞):
  verified on (0,40] with margin, asymptotic −(1/4π)σ^{−3/2} rigorous beyond; for the
  bound only the compact window ŝ ∈ [−4,−1] is needed, where |(AiBi)′| ≥ 7.1e−3):
    **E_j ≥ (1/2)∫_{−4}^{−1}Φ_∞ dŝ · μ^{1/3} − O(1) = 0.1212·μ^{1/3} − O(1)** —
  log-K1 is refuted PERMANENTLY (theorem-grade modulo the same two lemmas, which for a
  fixed compact window reduce to classical Olver error bounds + finite Airy checks).
  [Recorded lesson: a tempting slick proof of (AiBi)′ < 0 by integrating the product
  ODE W″′ = 4xW′ + 2W over (x,∞) is WRONG — ∫^∞AiBi diverges (~√T/π) and AiBi is not
  convex (W″(0.5) < 0); caught numerically before use. Compact-check + asymptotics is
  the honest route.]
- **Corrected FULL κ ladder** (`t2_d2_kappa_full_ladder.py`, protocol identical to (F7):
  max(fwd, rev), cap 2μ²/π; near block = certified Miller rows, far block bitwise-equal
  to rows()'s far branch — asserted exact at j = 8, 64; NO scipy jv/yv anywhere).
  Authoritative table now in `t2_d2_kappa_full_ladder.csv`:
    j ≤ 256: reproduces §2-CSV/(F7) to all digits (256 = 2.9103 was clean);
    **κ(384) = 3.2393 (F7 had 3.2891), κ(512) = 3.6159 (F7 had 3.7008)** — the
    garbage-finite corrections, matching (F8)'s prediction ≤ 0.085;
    NEW: κ(768) = 4.1141, κ(1024) = 4.5116. At every j ≥ 64 the sup is the rev branch
    and equals 1 + E_j EXACTLY (the 6j-window E-ladder and the full-cap scan agree —
    the excursion window is justified); rowsum at cap = 0.76891 stable (= 1 − 0.231,
    the pre-asymptotic universal-tail constant of §2, → 1 − 2/π² at larger caps per F7).
    Fit column: 1 + a_∞μ^{1/3} − 0.85 tracks the ladder within ±0.08 for j ≥ 64.

**NEXT SESSION, in order:** *[executed same day — see (F10)]*
1. Write the two pending lemmas to make the bounds theorem-grade: (L-a) Olver-remainder
   accumulation over the uniform window (explicit constants from Olver's error bounds;
   the machinery is standard), (L-b) zone-(i) Debye block (the telescope in the
   hyperbolic regime — NOTE: the naive leading Debye term is NOT dominant, the u₁-order
   Debye corrections carry the |ŝ|^{−3/2} matching tail; measured total ≤ 0.02).
2. Zone-(iii) lemma write-up from (F5) (machinery ready).
3. Then assemble the D2 zone-(ii) statement: κ_j = 1 + a_∞μ^{1/3} + O(1), upper + lower,
   as the companion-K1 replacement for P1 — and sync with IB (the draft side note now
   carries the closed-form law).

**(F10) THE ZONE-(ii) THEOREM — lemmas (L-a)/(L-b) closed, explicit constants, the
subleading drift resolved structurally** (`t2_d2_lemma_La.py`, `t2_d2_lemma_Lb.py`
+ logs; sixth session of 2026-07-19).

- **The fixed split (chosen here, used throughout):** x₀ = 1/2 in x = z/μ. Zone (i) =
  atoms with x_n < 1/2; window W_j = atoms with 1/2 ≤ x_n ≤ 1 (n₀..n*, and n* = m*:
  the last atom below z = μ IS the measured excursion argmin at every ladder j — the
  split boundary and the sup location coincide); oscillatory side + zone (iii) beyond.
  Because x₀ is FIXED, γ ≥ arccosh(2) = 1.3170 on all of zone (i) and the u₁/γ→0 trap
  flagged in the task file never arises.

- **(L-a) CLOSED — Olver-remainder accumulation** (`t2_d2_lemma_La.py`). With
  ĉ(z) := Φ_∞(ŝ(z)) + εΨ₁(ŝ(z)) (pure Airy model row), E_W := (π/2)Σ_{W_j}c_n, and
  r_n := c_n − ĉ(z_n):
  - *Two-piece envelope, verified j = 256/1024/4096 (50% headroom), j-stable:*
    |r_n| ≤ C₂ε²/(1+|ŝ_n|) on ŝ ≥ −40 (C₂ = 5.5, measured sup 3.65; ε²-order collapse
    ratios 0.83/0.93 → 1); |r_n| ≤ C₃ε³ on ŝ < −40 (C₃ = 2.7, measured 1.80). The
    single p = 1 envelope is NOT j-uniform — the deep edge is a different regime: the
    σ-linearized model is only O(1)-relative there, but the rows are O(ε³) absolute
    (Debye order-splitting suppression: the true rows fall to ≈ 0.13 of the Φ_∞ tail
    at x₀ — measured, = the one-signed deep residual). Budget: (π/2)Σ|r_n| ≤
    (C₂ε/2)ln 41 + C₃/4 — measured 0.310/0.329/0.341, all ≤ budget with ≥ 3× slack.
  - *The model constant is pure Airy and closes in closed form:*
    C_model(j) := (π/2)Σĉ(z_n) − (μ^{1/3}/2)I_∞ is computable to quadrature accuracy
    (no Bessel, no asymptotics); C_model(2²⁰) = −0.5761 vs the decomposition
    **C_model_∞ = −D_∞ + (1/2)∫Ψ₁ + Jac_∞ = −0.2878 − 0.1838 − 0.1054 = −0.5770**:
    D_∞ = 2^{2/3}/(2π(3W₀/2)^{1/3}) EXACT (W₀ = arccosh 2 − √3/2; window-edge tail
    deficit, j-independent to 6 digits via ∫_{s₀}^∞(AiBi)′ = −AiBi(s₀) — trap-5
    checked: this integral DOES converge); (1/2)∫Ψ₁ = 2Ai(0)Ai′(0) EXACT; Jac_∞ =
    (2^{−1/3}/2π)∫₀^{ζ₀}(g−1)ζ^{−3/2}dζ quadrature (g = 2^{1/3}x√ζ/√(1−x²), the
    atom-density Jacobian). Residual EM jitter ±0.01 (caustic-edge phase sampling).
  - *Deliverable:* |E_W(j) − (μ^{1/3}/2)I_∞| ≤ |C_model|_sup + |R|_bound ≤ 0.60 + 0.40
    = **C_La = 1.05 for all j ≥ 256** (R(j) = (π/2)Σr_n measured −0.310 → −0.344,
    increments falling ∝ ε ⟹ Cauchy; bound 0.40).
- **(L-b) CLOSED — zone-(i) Debye envelope** (`t2_d2_lemma_Lb.py`). Master envelope
  |c_n| ≤ C_env·2/(3πμW(x_n)) with C_env = 1.2: measured sup of the ratio is 0.130,
  j-stable (512/1024/4096), attained AT the x₀ boundary, falling to 1e−10 at the deep
  end (J_aY_b cross-products ~ ν^{−3}) — 8× slack everywhere. Hence
  (π/2)Σ_{zone i}|c_n| ≤ C_env(1/3π)∫₀^{1/2}dx/W = **C_b = 0.066** (∫dx/W = 0.5058
  exact quadrature; measured zone total 0.0027 — the bound is 24× the measured value,
  deliberately crude and safe). All zone-(i) rows measured positive.
- **Oscillatory side: one NEGATIVE result + the two constants that replace it.**
  The proj-drop trick (−ps_m ≤ (π/2)Σc_n, valid below the caustic since proj ≥ 0)
  FAILS beyond it: the c-only partial sums keep running to ≈ 0.47–0.51·μ^{1/3} past m*
  before proj turns them (measured 512/2048/8192) — no O(1) osc-variation constant
  exists for the c-sums. The theorem instead uses: (a) the measured sup location
  (max(−ps) beyond m* minus E is −0.30/−0.25/−0.06 at 512/2048/8192 — sup at m*;
  full-cap certified scans at j ≤ 1024 in `t2_d2_kappa_full_ladder.csv`); (b)
  **P*(j) := Σ_{n≤m*}proj_n = 0.0152/0.0107/0.0060 — the below-caustic projection
  mass is ∝ ε** (Airy ramp): the lower-bound cost of proj is ≤ 0.02, not the crude 1.
- **Ledger-balance cross-check (three j, closes to 1e−4):** E − E_W = (zone-i signed
  sum) − P*: at 512: −0.0126 vs +0.0027 − 0.0152 = −0.0125; at 2048: −0.0080 vs
  −0.0080; at 8192: −0.0032 vs −0.0033. The full excursion, the window object, the
  Debye block and the projection mass are one consistent account.
- **THEOREM (companion model, zone (ii); grades below).** For j ≥ 512:
    **κ_j = 1 + E_j, E_j = a_∞μ^{1/3} + R_j, −1.1 ≤ R_j ≤ 0.5**,
    a_∞ = 2^{2/3}3^{−5/6}Γ(2/3)^{−2} = 0.346555…
  Upper (R_j ≤ 0.5): for every m ≤ m*: −ps_m ≤ C_b + (π/2)Σ_{n₀≤n≤m}c_n; model partial
  sums never exceed the main term because Ψ₁ ≤ 0 pointwise (exact) and Φ_∞ > 0 (O6)
  while C_modelΦ := C_model − Ψ₁part = −D − |Jac| + EM ≤ −0.36 < 0 at every j (A3
  table) ⟹ −ps_m ≤ (μ^{1/3}/2)I_∞ + C_b + Σ|r| ≤ main + 0.47; beyond m* the sup
  does not move (measured, (a) above). Lower (R_j ≥ −1.1): E_j ≥ −ps_{m*} ≥
  main − |C_model|_sup − |R|_bound − C_b − P* ≥ main − 1.09. Both attained constants
  bracket the measured R_j ∈ [−0.93, −0.86] with real headroom.
  **Caustic lower bound stands in the strongest form: E_j ≥ 0.3466·μ^{1/3} − 1.1 —
  log-K1 is refuted with the EXACT constant** (the compact-window fallback
  E_j ≥ 0.1212μ^{1/3} − O(1) of (F9) is now strictly weaker but has the smaller
  ingredient surface; both stand).
- **Ingredient grading (honest):** *classical-cited:* Olver uniform asymptotics and
  the O(ν^{−4/3}) error-bound structure (DLMF 10.20, Olver 1997 Ch. 11) — gives the
  ORDERS in the envelopes. *Exact/closed-form:* a_∞, I_∞, D_∞, (1/2)∫Ψ₁ = 2Ai(0)Ai′(0),
  Ψ₁ ≤ 0, ∫_{s₀}^∞(AiBi)′ = −AiBi(s₀), Σc = 0 and Σproj = 1 (σ-calculus/row-sum,
  (F5)), proj ≥ 0. *Quadrature-exact:* C_model(j), Jac_∞, ∫dx/W. *Finite-numeric,
  margins quoted:* envelope constants C₂/C₃/C_env (three-j verification, 50%
  headroom, ε-order collapse shown), Φ_∞ > 0 on (0,40] compact check (+ rigorous
  asymptotics beyond), sup-at-m* (certified full-cap scans j ≤ 1024, window scans to
  16384, (F5) domination beyond z = 2μ²), P* ≤ 0.02, |R|_bound = 0.40.
- **Zone-(iii) lemma (write-up of (F5), machinery already verified):** for z_m ≥ 2μ²,
  C_m = −(1/π)Σ_{k≥1}g_kρ_k(m) EXACTLY (rational identity per j; ρ_k(m) =
  π^{−2k}ζ_H(2k, m+½)) and the series is g₁-dominated: |Σ_{k≥2}g_kρ_k| ≤ 0.04|g₁|ρ₁
  (decreasing in j; exact-rational at j = 2,3,4,8, float-scanned beyond) ⟹
  |C_m| = |g₁|ρ₁(m)(1 ± 0.04), so (π/2)|C_m| ≤ 1.04·(π/2)|g₁|ρ₁(m) ≤ 0.211 at the
  cap (→ 2/π² asymptote) and decays ~1/m beyond: since S_m = −(π/2)C_m exactly
  (Σc = 0), the far tail's partial sums are pinned to ≤ 0.211 — the far zone can
  never compete with 1 + E_j. Grade: exact-rational skeleton + finite-numeric ratio.
- **Subleading drift RESOLVED structurally (staged item 5):** the measured
  "−0.762 − 0.0166 ln μ" drift is NOT a genuine log. Decomposition: R_j →
  C_model_∞ + R_∞ ≈ −0.577 − 0.357 = **−0.934**, matching the j = 16384 residual
  (−0.933) to 0.001; every component is individually convergent (D_∞ exact constant,
  Ψ₁-part closed form, Jac_∞ quadrature, R(j) Cauchy with increments ∝ ε, zone-i
  constant, P* → 0), so no ln μ survives — the "drift" is the ε-convergence of R(j)
  plus EM jitter ±0.01. (A j = 32768 out-of-sample test was CONSIDERED AND REJECTED:
  the model separation there (0.008–0.016) is inside the observed EM jitter — the
  test cannot decide; the structural argument is the honest close.) The remaining
  open sliver: R_∞ ≈ −0.357 (the accumulated Olver ε²-remainder) has no closed form —
  it is measured-convergent, NOT load-bearing.

**(F11) THE MENU QUESTION ANSWERED — the windowed-S pairing TOLERATES j^{1/3} row
constants, measured in the model AND in production** (`t2_d2_pairing_windowedS.py`,
`t2_d2_pairing_production.py` + logs; seventh session of 2026-07-19). The question
(CONSUMER_CHECK / K1K2 §6 / LEMMA §8): raw Abel pays κ_j·TV(dx) ~ 0.44j^{1/3}·TV,
unbounded over j; does the oscillation-window pairing close H-ROT anyway?

- **Mechanism 1 — LOCALIZATION (the (F10) dividend).** The partial-sum profile ps_m is
  a localized caustic dip: |ps_m| ≥ tE_j only on ~μ^{1/3}/t² atoms around m* = 2j/π,
  with |ŝ|^{−1/2} wings and an O(1) far field. Summation by parts ⟹ the pairing pays
  the field's LOCAL variation at the dip, not κ_j·TV. **Explicit majorant, verified
  pointwise (0 violations, min margin +0.178, j = 256/1024/4096, N = 6j):**
    Ψ_j(m) = min(1.10·κ_j, 1 + 0.50·μ^{1/3}|ŝ_m|^{−1/2}),  |ΣK_nb_n| ≤ ⟨Ψ_j, |Δb|⟩.
  Model measurements (TV = 1 fields): ramp (equidistributed) |P| = 0.660/0.661/0.660 —
  CONSTANT in j while κ_j = 2.9 → 7.1; tapered sines |P|/TV ≤ 0.014 at every
  wavelength (S-like oscillating fields are essentially free); Σ_m|ps_m| = 2.048·μ at
  all three j (exactly linear — the ℓ¹ of the profile; 0.683·N_sec, far-field
  dominated). **SHARPNESS: a step AT m* pays exactly E_j** — the j^{1/3} is real for
  fields whose variation concentrates in the moving μ^{1/3}-window; the tolerance is a
  property of the transport fields, not of the kernels alone.
- **Mechanism 2 — THE RUNAWAY (production).** Frozen `k1_kernels_k4_N149.npz` +
  `quantiles_production.csv` (READ only; all cross-checks pass: atoms bitwise, max|dx|
  = 0.012934 exact, TV = 0.04901, sup_j|Ka·dx| = 0.010586 vs csv 0.010624 (linear);
  worst-step sup = 5.5956 = the csv κ̂ EXACTLY — convention identified: κ̂ = worst
  step over both branches; tail-branch alone gives 4.5956, argmax at the boundary row).
  The caustic window sits at n*(j) ≈ 0.64j and MOVES with j, while the actual
  transport field dx = x_fwd − x_D has TV density decaying ~ n^{−3/2}: TV fraction in
  the moving window (hw 3μ^{1/3}): 0.66–0.85 for j ≤ 10 (where κ_j = O(1)) but
  0.038 → 0.008 for j ≥ 80 (where κ_j is largest). **The dangerous product
  κ_j·TV_window(dx) peaks at 0.054 (j ≈ 10) and falls two orders by j = 139 — the
  corner (large j AND local concentration) is structurally empty for quantile-class
  fields.**
- **The three accountings on the actual field (drop-4, N = 149):** TRUE sup_j|dα_j| =
  0.0106; profile-pairing ⟨|PS_j|, |Δdx|⟩ = 0.0622 (5.9×, uniform in j — the O(1)
  far-field floor; the window term is dead by the runaway); raw Abel = 0.2847 (27×).
  The pairing accounting recovers 4.6× of the Abel slack a priori; the remaining 5.9×
  is in-window sign cancellation (the sine-gain regime — S oscillates). Production
  ramp gain matches the model: 0.679·TV vs model 0.660·TV.
- **H-ROT arithmetic:** ‖row‖-budget/δx_k = 0.0622/0.0129 ≈ 4.8 (vs raw-Abel route
  ≈ 22, vs truth C_rot ≈ 1.04–1.18). The pairing route closes H-ROT to within ~4.5× —
  with NO j^{1/3} anywhere and every ingredient explicit.
- **The formalizable lemma for the chain (IB menu, retargeted from "does it
  tolerate?" to "prove the field condition"):** for quantile-class transport fields
  (dx ∝ S/γ³ρ, γρ increasing), TV_{W_j}(dx) ≤ c·TV·(μ^{1/3}·n*(j)^{−3/2})-class
  [measured: 0.038·TV at j = 80 falling to 0.008·TV] ⟹ sup_j|dα_j| ≤ C₁·TV + 1.10·
  a_∞·sup_j[μ^{1/3}·TV_{W_j}] ≤ C·TV uniformly in j, M. The kernel side (majorant Ψ)
  is (F10)-grade; only the field-side TV-density bound needs a proof — S enters
  through certified windowed averages exactly as the LEMMA-§8 statement anticipated.
- Grades: model float64 on certified rational rows (families exact vector algebra;
  majorant checked pointwise); production float64 on FROZEN certified kernels (npz
  read-only, four cross-checks against the committed CSV pass, incl. two exact).

**(F12) THE FIELD-SIDE TV-DENSITY BOUND — numerics staged; the (F11)/G-E remainder is
now one classical lemma plus certified S-inputs** (`t2_f_field_tv_density.py` + log;
ninth session of 2026-07-19; production quantiles + pure Euler-product S_P at P = 2×10⁵,
zeros nowhere; frozen folders read-only).

- **The split is as predicted, and the provable part is geometric.** On the actual
  drop-4 field, τ(n) := |Δdx_n| decays with LSQ exponent p = 2.36 (block-maxima
  envelope 2.60); the u-profile u_n = 2/(γ³ρ) has exponent q = 2.05; the split
  Σ|Δu||S| = 0.0129 vs Σu|ΔS| = 0.0460 (TV = 0.0490) — **the S-part dominates, so
  τ(n) ≤ u_n·(sup|ΔS| + (q/n)sup|S|) with u_n ≲ C_geo n⁻² is the lemma shape**:
  u-decay is classical (ρ increasing, quantile-class — the IB-lane write-up), and S
  enters only through two certified scalars.
- **Composed moving-window law (the (F11) runaway as an inequality):** in the
  separated regime (window clear of the S-mass, j ≳ 40): TV_{W_j} ≤ C·μ^{1/3}
  n*^{−2.36}·TV with C ≈ 78 (ratio stable 45–78); for j ≲ 30 the window overlaps the
  S-mass and the crude fallback TV_{W_j} ≤ TV is used — μ^{1/3} is small there, so
  the window term stays uniform. **The theorem-relevant object,
  1.10·a_∞μ^{1/3}·TV_{W_j}, is ≤ 0.044 at every j (peak at j = 10, decay j^{−1.69}
  beyond)** — matching (F11)/X4's independently measured κ·TV_window peak 0.054.
- **Linearization honesty:** dx = −u·S holds at median 22% (90th pct 51%) — S moves
  a lot over the quantile shift itself (per-spacing |ΔS| mean 0.219); the γ-level
  check is good (max|dγ + S/ρ| = 4.9e−2 on ~0.3-scale shifts). The τ-measurements
  above are on the ACTUAL field, not the linearization.
- **The certified-side scalars (what the Turing/PZ lane must bound; measured here at
  production spec):** sup_n|S| = 0.862; per-spacing sup|ΔS| = 0.676 (mean 0.219);
  **‖S‖*₃ (signed, the G-E norm) = 0.6295** — equal to the abs-proxy A₃ at the
  maximizing window (n = 66; a sign-pure S run — the norm's max is one-signed).
  Knee-script A₃ = 0.6164 (drop-0, moving γ-windows) — consistent within convention.
- **State of the lemma after this session:** kernel side theorem-grade ((F10) + G-E);
  field side = [u_n ≤ C_geo n⁻²: classical, unwritten] + [certified sup|S|, sup|ΔS|
  or ‖S‖*₃: G-C1/G-C2 lane] + [this session's composed-law numerics with the regime
  split]. Nothing else remains in the pairing story.

## 8. Verification manifest (this folder)

| script | log | what it establishes |
|---|---|---|
| `t2_d2_companion_kernels.py` | `t2_d2_companion_kernels_run.log` | Theorem 1′ (general weights) verified; R1 exact on companion; W-route refuted (RESULTS.md) |
| `t2_d2_bessel_kernels.py` | `t2_d2_bessel_kernels_run.log` | V1 (3.1e−14), V2 (1.8e−6 FD floor), V3 (finite-M deviation halves 64→128); infinite κ_j profile to j = 192 (`t2_d2_kappa_infinite.csv`); mpmath spot checks of the Debye zone |
| `t2_d2_zone2_products.py` | `t2_d2_zone2_products_run.log` | Z1 product-comb lemma (4.8e−16) + doubled-string orthonormality; Z2 Wronskian cancellation (5e−18); Z3 Casoratian (2.8e−16 rel); Z4 JJ/Y-split refutation (parts ~2485 vs total ~0.5) |
| `t2_d2_neumann_reduction.py` | `t2_d2_neumann_reduction_run.log` | N0–N4 (Neumann reduction, fixed J₀/J₁ kernels, Dirichlet kernel); first F_j reconstruction (§6) |
| `t2_d2_Fj_closed_form.py` | `t2_d2_Fj_closed_form_run.log` | §7 closed form of F_j: hybrid A/B atoms (4.2e−16), Schlömilch S₀ (4.2e−12), sympy Φ vs Z1 (3.2e−15), F_JJ & F_Y vs tapered lattice 8.6e−10 each, TOTAL 8e−13, j = 2,4,8 |
| `t2_d2_diag_jj8d.py` | `t2_d2_Fj_exact_collapse_run.log` | (F2) EXACT rational-arithmetic certificate: per-atom IBP Laurent series resummed through S_{2m} ≡ δ-collapse form, difference = 0, j = 4, 8 |
| `t2_d2_diag_jj8*.py` (a–c,e) | — | forensic record of the two F3 numerical lessons (recurrence instability; lambdify float trap) |
| `t2_d2_Fj_ibp_log.py` | `t2_d2_Fj_ibp_log_run.log` | (F4): C_m = ∫F D_m (8e−8); boundary-free IBP (edge floor 0.084/m); naive-L¹ REFUTED (~j); Γ_j = ∫\|F\|g ≈ 0.47√j; S_true = −0.174 + 0.216 log(2+j) ⇒ κ c₁ = 0.34 |
| `t2_d2_common.py` | — | shared verified machinery (AB hybrid, G_parts, taper, phi_poly), extracted for import hygiene |
| `t2_d2_sigma_calculus.py` | (stdout in RESULTS) | (F5): exact σ-calculus; g₋₁ = g₀ = 0 exact; row-sum identity C_∞ = 0 exact-rational; C_m = ρ-form (4e−14); zone-(iii) domination r ≤ 0.04; TU ≡ AA + Casoratian asserts |
| `t2_d2_diag_sigma*.py` | — | forensic record of the nsimplify float-trap (phantom 14/19·z^{−(4j−2)}) |
| `t2_d2_log_localization.py` | `t2_d2_log_localization_run.log` | (F6): envelope peak O(1) at x = 2/π; m*/j → 2/π; turning-window log accumulation; S_true steepens at j ≥ 256; Y-side finite-m double-integral rep verified; κ-protocol OPEN FLAG measurements |
| `t2_d2_kappa_protocol_resolution.py` | `t2_d2_kappa_protocol_resolution_run.log` | (F7): flag resolved (κ = max(fwd, rev); CSV reproduced to all digits); κ extended to j = 512; **κ_j ≈ 0.46·j^{1/3}** — §2's log fit superseded |
| `t2_d2_caustic_exponent.py` | `t2_d2_caustic_exponent_run.log` | (F8): certified Miller rows (mp ≤ 2e−13, ktop ≤ 2e−14); E-ladder to j = 8192; fourth float-trap (garbage-finite scipy underflow) |
| `t2_d2_caustic_profile.py` | `t2_d2_caustic_profile_run.log` | (F9): phase-aligned profile vs exact Olver σ; smooth-side collapse 9.0e−3 (1024→4096); tail 0.267·\|ŝ\|^{−1.6}; osc-side DC ≈ 0; B(S) saturates; per-octave E-accounting |
| `t2_d2_law_decision.py` | `t2_d2_law_decision_run.log` | (F9): √ln law REFUTED out-of-sample at j = 16384 (+2.06% vs −0.18% for aμ^{1/3}+c); trapezoid I_c ↔ E consistency |
| `t2_d2_olver_profile.py` | `t2_d2_olver_profile_run.log` | (F9): Φ_∞ = −4(AiBi)′ verified 8.0e−5 (Richardson 3-pt); Ψ₁ = −4·2^{1/3}(AiAi′)′ at 0.998; envelope (4/π)(1−sinθ) at 1.8e−3; a_∞ closed form; lower-bound ingredients |
| `t2_d2_kappa_full_ladder.py` | `t2_d2_kappa_full_ladder_run.log` | (F9): corrected full-κ ladder on Miller rows (far block bitwise = rows(); no scipy); κ(384/512) corrected, extended to 1024; authoritative `t2_d2_kappa_full_ladder.csv` |
| `t2_d2_lemma_La.py` | `t2_d2_lemma_La_run.log` | (F10): lemma (L-a) — two-piece residual envelope (C₂ = 5.5, C₃ = 2.7, j-stable), C_model closed-form decomposition (−D_∞ + 2Ai(0)Ai′(0) + Jac_∞ = −0.5770 vs −0.5761 direct at 2²⁰), C_La = 1.05 |
| `t2_d2_lemma_Lb.py` | `t2_d2_lemma_Lb_run.log` | (F10): lemma (L-b) — zone-(i) envelope 8× slack (sup ratio 0.130 at x₀), C_b = 0.066; osc-side negative result (c-only drift ~0.5μ^{1/3}); sup-at-m* margin check; P* = Σproj below m* ∝ ε (≤ 0.02) |
| `t2_d2_pairing_windowedS.py` | `t2_d2_pairing_windowedS_run.log` | (F11): model pairing — majorant Ψ pointwise (0 violations, margin +0.178); ramp gain 0.66·TV constant in j; sines ≤ 0.014·TV; step@m* = E_j (sharp); Σ\|ps\| = 2.048μ |
| `t2_d2_pairing_production.py` | `t2_d2_pairing_production_run.log` | (F11): production pairing on frozen kernels — cross-checks exact; TRUE 0.0106 vs pairing 0.0622 vs Abel 0.2847; runaway table (κ·TVfrac peaks 0.054, falls 2 orders); κ̂ convention identified (worst-step = 5.5956) |
| `t2_e_elbow_kernel_scale.py` | `t2_e_elbow_kernel_scale_run.log` | (G-E/Stage E): the w ≈ 3 elbow derived — w*_j = 2j/π + μ^{1/3} at the maximizing rows j = 2–3; tolerance curves reproduce the empirical knee on [2,3]; → `ELBOW_kernel_scale_note_2026-07-19.md` |
| `t2_f_field_tv_density.py` | `t2_f_field_tv_density_run.log` | (F12): field-side TV-density — τ ~ n^{−2.36}, u ~ n^{−2.05}, S-part dominates; window term ≤ 0.044 all j (decay j^{−1.69}); certified scalars sup\|S\| = 0.862, sup\|ΔS\| = 0.676, ‖S‖*₃ = 0.6295 |

*— Stenberg + Claude, 2026-07-19. The companion kernel is an explicit rational function
of the string spectrum; its partial-sum problem has a measured pure-log answer
(0.386 + 0.382 log(2+j)) and a three-zone proof plan whose hardest zone is exactly D1's
machinery applied to a product of two Bessel functions instead of one.*
*[Closing line superseded by (F7), same day: the "pure-log answer" was a pre-asymptotic
fit; the measured law over j = 64–512 is κ_j ≈ 0.46·j^{1/3} — the Airy-caustic window.
The three-zone plan and everything else stands.]*
