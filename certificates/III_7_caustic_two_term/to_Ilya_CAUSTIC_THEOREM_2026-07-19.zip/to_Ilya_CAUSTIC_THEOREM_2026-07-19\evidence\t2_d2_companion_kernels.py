# t2_d2_companion_kernels.py — Stage D2, step 1-2 (PLAN.md):
#
#  (1) THEOREM 1' (general fixed weights): for mu = sum_n w_n delta_{x_n} (any fixed
#      positive weights, simple atoms), the sensitivity kernels at fixed weights are
#        K_j^alpha(nu) = w_nu * [ p_j^2 + 2 be_j p_j' p_{j+1} - 2 be_{j-1} p_{j-1}' p_j ](x_nu)
#        K_j^beta(nu)  = w_nu * [ p_j p_{j+1} + be_j (p_{j+1} p_{j+1}' - p_j p_j') ... ]
#      -- the uniform-weights proof (K1K2 note, Thm 1) never used uniformity; w_nu is the
#      mass of the moved atom. VERIFIED here against weighted central-FD kernels on the
#      companion system (weights prop. to x_n, string atoms).
#  (2) W_j^companion := sum_i |hhat_i^{(j)}|/(1+i) measured: log-fit, bandwidth check,
#      reconstruction, finite-M a3, and the assembled companion-K1 bound
#      kappa_j <= 1 + a3 * W_j, side by side with the uniform system.
import os
import numpy as np
from mpmath import mp, mpf

HERE = os.path.dirname(os.path.abspath(__file__))


def jacobi_w64(x, w):
    """float64 weighted Lanczos with full reorthogonalization; measure sum w_n delta_{x_n}
    (w need not sum to 1; v0 = sqrt(w)/||sqrt(w)||)."""
    x = np.asarray(x, float); w = np.asarray(w, float); M = len(x)
    v = np.sqrt(w); v /= np.linalg.norm(v)
    al, be, Vs = [], [], [v]
    u = x * v; a0 = v @ u; al.append(a0); u = u - a0 * v
    for j in range(1, M):
        b = np.linalg.norm(u)
        if b < 1e-15: break
        be.append(b)
        vn = u / b
        for q in Vs: vn = vn - (q @ vn) * q
        vn /= np.linalg.norm(vn)
        Vs.append(vn)
        u = x * vn - b * Vs[-2]
        a = vn @ u; al.append(a); u = u - a * vn
    return np.array(al), np.array(be)


def fd_kernels_w(x, w, rel_h=1e-6):
    """Weighted central-FD kernels: move atom nu, FREEZE all weights."""
    M = len(x)
    Ka = np.zeros((M, M)); Kb = np.zeros((M - 1, M))
    for nu in range(M):
        h = rel_h * x[nu]
        xp = x.copy(); xp[nu] += h
        xm = x.copy(); xm[nu] -= h
        alp, bep = jacobi_w64(xp, w); alm, bem = jacobi_w64(xm, w)
        Ka[:, nu] = (alp - alm) / (2 * h)
        Kb[:, nu] = (bep - bem) / (2 * h)
    return Ka, Kb


def mp_pipeline_w(x64, w64, dps0, need_dp=True):
    """Weighted mp Lanczos with full reorth + derivative recurrence; adaptive dps with the
    four exact a-posteriori checks (general-weights versions):
      colnorm: sum_j p_j(x_n)^2 = 1/w_n;  r(x_n) ~ 0;  CD identity;  r'(x_n) = 1/(w_n p_{M-1}(x_n))."""
    M = len(x64)
    for dps in (dps0, 2 * dps0, 4 * dps0):
        mp.dps = dps
        x = [mpf(float(t)) for t in x64]
        wgt = [mpf(float(t)) for t in w64]
        sw = [mp.sqrt(t) for t in wgt]
        nrm0 = mp.sqrt(mp.fsum(t * t for t in sw))
        v = [t / nrm0 for t in sw]
        V = [v]; al, be = [], []
        u = [x[n] * v[n] for n in range(M)]
        a = mp.fsum(v[n] * u[n] for n in range(M)); al.append(a)
        u = [u[n] - a * v[n] for n in range(M)]
        for j in range(1, M):
            b = mp.sqrt(mp.fsum(t * t for t in u))
            be.append(b)
            vn = [t / b for t in u]
            for q in V:
                c = mp.fsum(q[n] * vn[n] for n in range(M))
                vn = [vn[n] - c * q[n] for n in range(M)]
            nn = mp.sqrt(mp.fsum(t * t for t in vn))
            vn = [t / nn for t in vn]
            V.append(vn)
            u = [x[n] * vn[n] - b * V[-2][n] for n in range(M)]
            a = mp.fsum(vn[n] * u[n] for n in range(M)); al.append(a)
            u = [u[n] - a * vn[n] for n in range(M)]
        # p values: p_j(x_n) = V[j][n]/(sw[n]/nrm0)
        P = [[V[j][n] * nrm0 / sw[n] for n in range(M)] for j in range(M)]
        r = [(x[n] - al[M - 1]) * P[M - 1][n] - be[M - 2] * P[M - 2][n] for n in range(M)]
        P.append(r)
        DP = [[mp.zero] * M, [mp.one / be[0]] * M]
        for j in range(1, M):
            bj = be[j] if j < M - 1 else mp.one
            DP.append([(P[j][n] + (x[n] - al[j]) * DP[j][n] - be[j - 1] * DP[j - 1][n]) / bj
                       for n in range(M)])
        tol = mpf(10) ** (-25)
        rmax = max(abs(t) for t in r) / max(abs(t) for t in P[M - 1])
        colerr = mpf(0); cderr = mpf(0); bnderr = mpf(0)
        run = [mpf(0)] * M
        for n in range(M):
            s = mp.fsum(P[j][n] ** 2 for j in range(M))
            colerr = max(colerr, abs(s - 1 / (wgt[n] / nrm0 ** 2 / 1)) * 0 + abs(s * (wgt[n] / nrm0 ** 2) - 1))
        for j in range(1, M):
            for n in range(M):
                run[n] += P[j - 1][n] ** 2
                rhs = be[j - 1] * (DP[j][n] * P[j - 1][n] - DP[j - 1][n] * P[j][n])
                cderr = max(cderr, abs(rhs - run[n]) / run[n])
        for n in range(M):
            wn = wgt[n] / nrm0 ** 2
            bnderr = max(bnderr, abs(DP[M][n] - 1 / (wn * P[M - 1][n])) / abs(DP[M][n]))
        ok = (rmax < tol) and (colerr < tol) and (cderr < tol) and (bnderr < tol)
        if ok:
            Pf = np.array([[float(P[j][n]) for n in range(M)] for j in range(M)])
            albe = (np.array([float(t) for t in al]), np.array([float(t) for t in be]))
            # analytic kernels (Theorem 1'):
            wn_eff = np.array([float(wgt[n] / nrm0 ** 2) for n in range(M)])
            Ka = np.zeros((M, M)); Kb = np.zeros((M - 1, M))
            for j in range(M):
                bj = be[j] if j < M - 1 else mp.one
                b0 = be[j - 1] if j >= 1 else mp.zero
                for n in range(M):
                    t1 = bj * (DP[j][n] * P[j + 1][n] + P[j][n] * DP[j + 1][n])
                    t0 = (b0 * (DP[j - 1][n] * P[j][n] + P[j - 1][n] * DP[j][n])) if j >= 1 else mp.zero
                    Ka[j, n] = float((wgt[n] / nrm0 ** 2) * (t1 - t0))
                    if j < M - 1:
                        Kb[j, n] = float((wgt[n] / nrm0 ** 2) * be[j] * (P[j + 1][n] * DP[j + 1][n] - P[j][n] * DP[j][n]))
            return dict(P=Pf, al=albe[0], be=albe[1], Ka=Ka, Kb=Kb, w=wn_eff, dps=dps,
                        diag=(float(rmax), float(colerr), float(cderr), float(bnderr)))
    raise RuntimeError("mp pipeline failed")


for M in (64, 128):
    n = np.arange(1, M + 1, dtype=float)
    zn = (n - 0.5) * np.pi
    x = 1.0 / zn ** 2
    wL = x / x.sum()                       # companion weights (normalized; prop. to x_n)
    print(f"=== companion (weights prop. x_n), string atoms, M={M} ===")
    pipe = mp_pipeline_w(x, wL, 700 if M <= 64 else 1500)
    print(f"  mp dps={pipe['dps']}; checks (r, colnorm, CD, boundary): "
          + " ".join(f"{t:.1e}" for t in pipe['diag']))
    Ka, Kb, P, w = pipe['Ka'], pipe['Kb'], pipe['P'], pipe['w']
    # ---- Theorem 1' vs weighted FD ----
    KaF, KbF = fd_kernels_w(x, wL)
    ea = np.max(np.abs(Ka - KaF)) / np.max(np.abs(KaF))
    eb = np.max(np.abs(Kb - KbF)) / np.max(np.abs(KbF))
    print(f"  THEOREM 1' vs weighted FD: alpha {ea:.2e}, beta {eb:.2e}")
    # sum rules (weight-agnostic: shift/scale arguments unchanged)
    sr = (np.max(np.abs(Ka.sum(axis=1) - 1.0)), np.max(np.abs(Ka @ x - pipe['al'])),
          np.max(np.abs(Kb.sum(axis=1))), np.max(np.abs(Kb @ x - pipe['be'])))
    print(f"  sum rules: {sr[0]:.1e} {sr[1]:.1e} {sr[2]:.1e} {sr[3]:.1e}")
    # ---- spectral reduction objects ----
    corr = Ka - w[None, :] * P ** 2
    H = corr @ P.T                          # hhat_i^{(j)} (rows j, cols i)... careful:
    # <h_j, p_i> = sum_n w_n h_j(x_n) p_i(x_n) = sum_n corr[j,n] P[i,n]  -> H = corr @ P.T  OK
    chat = np.cumsum(w[None, :] * P, axis=1)
    bw = 0.0
    for j in range(M):
        hi = min(2 * j, M - 1)
        if hi + 1 <= M - 1:
            bw = max(bw, float(np.max(np.abs(H[j, hi + 1:]))))
    rec = float(np.max(np.abs(H @ chat.T[:, :].T - np.cumsum(corr, axis=1))))
    print(f"  R1 on companion: bandwidth {bw:.1e}, reconstruction {rec:.1e}")
    # ---- P1a/P1b measurements ----
    ii = np.arange(M)
    csup = np.max(np.abs(chat), axis=1)
    a3 = float(np.max(((1 + ii) * csup)[1:]))
    Wj = np.abs(H) @ (1.0 / (1.0 + ii))
    PSa = np.cumsum(Ka, axis=1)
    tails = 1.0 - np.concatenate([np.zeros((M, 1)), PSa[:, :-1]], axis=1)
    prof = np.maximum(np.max(np.abs(PSa), axis=1), np.max(np.abs(tails), axis=1))
    jj = np.arange(2, M - 5)
    A = np.vstack([np.ones(len(jj)), np.log(2.0 + jj)]).T
    cW, *_ = np.linalg.lstsq(A, Wj[jj], rcond=None)
    cP, *_ = np.linalg.lstsq(A, prof[jj], rcond=None)
    js = [j for j in [1, 2, 4, 8, 16, 32, 64, 96, 120] if j < M]
    print(f"  a3 (finite-M companion) = {a3:.3f}  [D1 infinite: proven <= 1.263, true 0.783]")
    print("  W_j at j=" + str(js) + ": " + " ".join(f"{Wj[j]:.2f}" for j in js))
    print(f"  W_j bulk fit: {cW[0]:.3f} + {cW[1]:.3f} log(2+j); max W_j = {Wj.max():.2f}")
    print("  kappa_j at same j: " + " ".join(f"{prof[j]:.3f}" for j in js))
    print(f"  kappa bulk fit: {cP[0]:.3f} + {cP[1]:.3f} log(2+j); kappa-hat = {prof.max():.3f}")
    ok = bool(np.all(prof <= 1.0 + a3 * Wj + 1e-9))
    print(f"  assembled companion-K1 bound kappa_j <= 1 + a3 W_j holds all j: {ok}")
    print()
print("done.")
