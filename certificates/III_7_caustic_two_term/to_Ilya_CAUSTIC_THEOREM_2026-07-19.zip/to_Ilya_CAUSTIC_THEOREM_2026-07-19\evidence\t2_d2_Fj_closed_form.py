# t2_d2_Fj_closed_form.py — D2 zone (ii): the CLOSED FORM of F_j(tau), derived by pushing
# the lattice comb through the N3 Neumann representations, verified vs tapered lattice sums.
#
# Derivation being verified (mu = 2j+1/2, z_n = (n-1/2)pi, tau in (0,2)):
#   z^2 dW_j = G_JJ(z) + G_Y(z)        (the N2-reduced split; NOT summed separately vs m —
#                                       here we only need the FULL sums over n, Abel-tapered)
#   G_Y = (4/pi) int_0^{pi/2} g1'(t) J_0(2 z cos t) dt + (2/pi) int_0^{pi/2} dc0(t) z^2 J_0(2 z cos t) dt
#         with dc1(t) = cos((2mu+1)t) - cos((2mu-3)t) = -2 sin((2mu-1)t) sin 2t,
#              g1(t)  = dc1/(2 sin t) = -2 sin((2mu-1)t) cos t     (g1(0)=g1(pi/2)=0:
#              per-n EXACT boundary-free IBP  z J_1(2z cos t) = (1/(2 sin t)) d/dt J_0(2z cos t)),
#              dc0(t) = cos(2mu t)/(mu+1) - cos((2mu-4)t)/(mu-1).
#   Schloemilch collapse (comb C(u) = sum_k (-1)^k delta(u-2k)):
#     S0(a,tau) := sum_n J_0(a z_n) cos(z_n tau)
#               = (1/pi)[ 1(a>tau)/sqrt(a^2-tau^2) - 1(a>2-tau)/sqrt(a^2-(2-tau)^2) ]
#   =>  F_Y(tau) = (4/pi^2)[Q[g1'](tau) - Q[g1'](2-tau)] - (2/pi^2) d^2/dtau^2 [Q[dc0](tau) - Q[dc0](2-tau)]
#       Q[h](x) := (1/2) int_0^{pi/2} h(arcsin(beta(x) sin psi)) / sqrt(1 - beta^2 sin^2 psi) dpsi,
#       beta(x) = sqrt(1-x^2/4)     (smooth-integrand form of int g1' S0 dt).
#   G_JJ = (z^3/pi) int_0^2 Psi_s(s) sin(z s) ds + (z^2/(2 pi)) int_0^2 Psi_c(s) cos(z s) ds,
#       Psi_s = Phi(2j-1,2j+2)/(mu+1) - Phi(2j-3,2j)/(mu-1),
#       Psi_c = (2mu-1) Phi(2j,2j+2)/(mu+1) - (2mu-5) Phi(2j-2,2j)/(mu-1),
#       Phi(a,b)(s) = Legendre convolution (Z1), a polynomial on [0,2].
#   =>  F_JJ(tau) = (1/(2pi))[Psi_s'''(2-tau) - Psi_s'''(tau)] - (1/(4pi))[Psi_c''(tau) - Psi_c''(2-tau)]
#       (z^3 sin / z^2 cos combs = C''' / -C''; only interior comb points s = tau, 2-tau hit).
#   F_j = F_JJ + F_Y  — verify at 1e-8 vs the tapered lattice sum (rational A/B forms at atoms).
import os, time
import numpy as np
from scipy.special import jv, yv
import sympy as sp

HERE = os.path.dirname(os.path.abspath(__file__))
t0 = time.time()

# ---------- rational atom values: J_{k+1/2}(z_n) = sqrt(2/pi z) eps A_k, Y = -sqrt(2/pi z) eps B_k
# STABILITY (the section-3 lesson, small-z edition): forward recurrence is fine in the
# oscillatory zone z >~ kmax, but below the turning point A_k is the MINIMAL solution and
# forward recursion is catastrophically unstable (error grows along B). Hybrid: use jv/yv
# with the prefactor stripped for z < zstar (moderate z: no argument-reduction noise),
# rational recurrence beyond (large z: no trig at all).
def AB(z, kmax, eps=None):
    A = np.empty((kmax + 1,) + z.shape); B = np.empty_like(A)
    A[0] = 1.0; A[1] = 1.0 / z; B[0] = 0.0; B[1] = 1.0
    for k in range(1, kmax):
        A[k + 1] = ((2 * k + 1) / z) * A[k] - A[k - 1]
        B[k + 1] = ((2 * k + 1) / z) * B[k] - B[k - 1]
    zstar = 3.0 * kmax + 20.0
    sm = z < zstar
    if np.any(sm) and eps is not None:
        zs = z[sm]; pref = np.sqrt(np.pi * zs / 2.0) * eps[sm]
        for k in range(kmax + 1):
            A[k][sm] = pref * jv(k + 0.5, zs)
            B[k][sm] = -pref * yv(k + 0.5, zs)
    return A, B

# ---------- C-infinity taper on [0,1]
def taper(y):
    y = np.clip(y, 1e-12, 1 - 1e-12)
    return 1.0 / (1.0 + np.exp(np.clip(1.0 / (1.0 - y) - 1.0 / y, -700, 700)))

def tapered_sum(c, z, taus, N):
    """sum_n c_n cos(z_n tau) with C^inf taper on n in [N/2, N] (Abel limit)."""
    n = np.arange(1, N + 1)
    w = np.ones(N); half = N // 2
    w[half:] = taper((n[half:] - half) / (N - half))
    cw = c[:N] * w
    return np.array([np.sum(cw * np.cos(z[:N] * t)) for t in taus])

# ---------- lattice-side content at atoms (rational; no trig except the final cos(z tau))
def G_parts(j, N):
    mu = 2 * j + 0.5
    n = np.arange(1, N + 1, dtype=float); z = (n - 0.5) * np.pi
    eps = (-1.0) ** (n + 1)
    A, B = AB(z, 2 * j + 2, eps=eps)
    GJJ = ((2 * z / np.pi) * (A[2*j-1] * A[2*j+2] / (mu + 1) - A[2*j-3] * A[2*j] / (mu - 1))
           - (1 / np.pi) * ((2*mu - 1) * A[2*j] * A[2*j+2] / (mu + 1)
                            - (2*mu - 5) * A[2*j-2] * A[2*j] / (mu - 1)))
    GY = (-(4 / np.pi) * A[2*j+1] * B[2*j] + (2 * z / np.pi) * A[2*j] * B[2*j] / (mu + 1)
          + (4 / np.pi) * A[2*j-1] * B[2*j-2] - (2 * z / np.pi) * A[2*j-2] * B[2*j-2] / (mu - 1))
    return z, GJJ, GY

print("=== (C0) rational A/B atom values vs jv/yv, and G_JJ+G_Y = z^2 dW ===")
worst_ab = worst_split = 0.0
for j in [2, 4, 8]:
    mu = 2 * j + 0.5
    z, GJJ, GY = G_parts(j, 120)
    kmax = 2 * j + 2
    for n_idx in [4, 19, 49, 99]:
        zz = z[n_idx]
        if zz < 3.0 * kmax + 20.0: continue          # pure-recurrence rows only
        eps = (-1.0) ** (n_idx + 2)                  # n = n_idx+1, eps = (-1)^{n+1}
        Aex, Bex = AB(np.array([zz]), kmax)
        for k in [0, 1, 2 * j, kmax]:
            worst_ab = max(worst_ab,
                           abs(jv(k + 0.5, zz) - np.sqrt(2 / (np.pi * zz)) * eps * Aex[k][0]),
                           abs(yv(k + 0.5, zz) + np.sqrt(2 / (np.pi * zz)) * eps * Bex[k][0]))
    # total vs the direct trig-Bessel z^2 dW, oscillatory zone only (below the turning
    # point BOTH float64 evaluations lose to catastrophic cancellation; identity is exact)
    osc = z >= mu + 2
    zo = z[osc]
    dW = ((jv(mu-1, zo) - (2*mu-1) * jv(mu, zo) / (2*zo) + yv(mu, zo)) * jv(mu+2, zo) / (mu+1)
          - (jv(mu-3, zo) - (2*mu-5) * jv(mu-2, zo) / (2*zo) + yv(mu-2, zo)) * jv(mu, zo) / (mu-1))
    worst_split = max(worst_split, float(np.max(np.abs(zo**2 * dW - (GJJ + GY)[osc]))))
print(f"  A/B mapping max dev: {worst_ab:.2e};  (G_JJ+G_Y) vs z^2 dW max dev (osc zone): {worst_split:.2e}")

print("=== (C1) Schloemilch closed form S0(a,tau) ===")
def S0_closed(a, tau):
    v = 0.0
    if a > tau: v += 1.0 / np.sqrt(a*a - tau*tau)
    if a > 2 - tau: v -= 1.0 / np.sqrt(a*a - (2-tau)**2)
    return v / np.pi
NS = 400000
nn = np.arange(1, NS + 1, dtype=float); zS = (nn - 0.5) * np.pi
worst = 0.0
for a in [0.3, 0.9, 1.4, 1.9]:
    c = jv(0, a * zS)
    for tau in [0.25, 0.7, 1.3, 1.75]:
        lhs = tapered_sum(c, zS, [tau], NS)[0]
        worst = max(worst, abs(lhs - S0_closed(a, tau)))
print(f"  max abs dev over 16 (a,tau) pairs (N={NS}, tapered): {worst:.2e}")

# ---------- F_JJ: exact Legendre-convolution polynomials via sympy
def phi_poly(a, b, s_sym):
    x = sp.Symbol('x')
    integrand = sp.expand(sp.legendre(a, x) * sp.legendre(b, s_sym - x))
    return sp.expand(sp.integrate(integrand, (x, s_sym - 1, 1)))

def FJJ_maker(j):
    mu = sp.Rational(4 * j + 1, 2); s = sp.Symbol('s')
    Psi_s = phi_poly(2*j-1, 2*j+2, s) / (mu + 1) - phi_poly(2*j-3, 2*j, s) / (mu - 1)
    Psi_c = (2*mu - 1) * phi_poly(2*j, 2*j+2, s) / (mu + 1) - (2*mu - 5) * phi_poly(2*j-2, 2*j, s) / (mu - 1)
    P3 = sp.lambdify(s, sp.diff(Psi_s, s, 3), 'mpmath')
    P2 = sp.lambdify(s, sp.diff(Psi_c, s, 2), 'mpmath')
    import mpmath as mp; mp.mp.dps = 50
    def F(tau):
        # convert to mpf BEFORE the polynomial: a float argument would make s**k float64
        # and the ~1e19 coefficient cancellation then loses to power roundoff (~1e-5 at j=8)
        tt = mp.mpf(tau)
        return float((P3(2 - tt) - P3(tt)) / (2 * mp.pi) - (P2(tt) - P2(2 - tt)) / (4 * mp.pi))
    return F, Psi_s, Psi_c

# spot-check phi_poly against the Z1 numeric leg_conv
from scipy.special import eval_legendre
def leg_conv_num(a, bb, tau):
    lo, hi = max(-1.0, tau - 1.0), min(1.0, tau + 1.0)
    sq, wq = np.polynomial.legendre.leggauss(200)
    sq = 0.5*(hi-lo)*sq + 0.5*(hi+lo); wq = 0.5*(hi-lo)*wq
    return float(np.sum(wq * eval_legendre(a, sq) * eval_legendre(bb, tau - sq)))
s = sp.Symbol('s'); ph = phi_poly(3, 6, s)
dev = max(abs(float(ph.subs(s, t)) - leg_conv_num(3, 6, t)) for t in [0.3, 1.1, 1.7])
print(f"=== (C2) sympy Phi(3,6) vs Z1 leg_conv: {dev:.2e} ===")

# ---------- F_Y: Q-integrals (Gauss-Legendre in psi) + Cauchy-circle d^2/dtau^2
PSI_N, PSI_W = np.polynomial.legendre.leggauss(1200)
PSI = 0.25 * np.pi * (PSI_N + 1.0); PW = 0.25 * np.pi * PSI_W  # nodes on [0, pi/2]
SPSI = np.sin(PSI)

def Q(h, x):
    """Q[h](x), works for complex x (analytic continuation)."""
    beta = np.sqrt(1.0 - x * x / 4.0)
    tt = np.arcsin(beta * SPSI)
    return 0.5 * np.sum(PW * h(tt) / np.sqrt(1.0 - (beta * SPSI) ** 2))

def FY_maker(j):
    mu = 2 * j + 0.5
    g1p = lambda t: -2.0 * ((2*mu - 1) * np.cos((2*mu - 1) * t) * np.cos(t)
                            - np.sin((2*mu - 1) * t) * np.sin(t))
    dc0 = lambda t: np.cos(2*mu*t) / (mu + 1) - np.cos((2*mu - 4)*t) / (mu - 1)
    Qt = lambda x: Q(dc0, x) - Q(dc0, 2 - x)          # antisym part, to be d^2/dtau^2'd
    def d2(f, x, r=0.035, K=32):
        th = 2 * np.pi * np.arange(K) / K
        vals = np.array([f(x + r * np.exp(1j * t)) for t in th])
        return float(np.real(2.0 * np.mean(vals * np.exp(-2j * th)) / r**2))
    def F(tau):
        return (4 / np.pi**2) * (Q(g1p, tau) - Q(g1p, 2 - tau)) - (2 / np.pi**2) * d2(Qt, tau)
    return F

print("=== (C3)+(C4)+(C5) F_JJ, F_Y, F_total closed forms vs tapered lattice sums ===")
TAUS = [0.15, 0.35, 0.6, 0.85, 1.0, 1.25, 1.55, 1.8]
NLAT = 240000
for j in [2, 4, 8]:
    z, GJJ, GY = G_parts(j, NLAT)
    lat_JJ = tapered_sum(GJJ, z, TAUS, NLAT)
    lat_JJ2 = tapered_sum(GJJ, z, TAUS, NLAT // 2)
    lat_Y = tapered_sum(GY, z, TAUS, NLAT)
    lat_Y2 = tapered_sum(GY, z, TAUS, NLAT // 2)
    FJJ, _, _ = FJJ_maker(j)
    FY = FY_maker(j)
    cJJ = np.array([FJJ(t) for t in TAUS])
    cY = np.array([FY(t) for t in TAUS])
    dJJ = np.max(np.abs(cJJ - lat_JJ)); dY = np.max(np.abs(cY - lat_Y))
    dtot = np.max(np.abs((cJJ + cY) - (lat_JJ + lat_Y)))
    stab = max(np.max(np.abs(lat_JJ - lat_JJ2)), np.max(np.abs(lat_Y - lat_Y2)))
    print(f"  j={j}: |F_JJ closed - lattice| = {dJJ:.2e}; |F_Y closed - lattice| = {dY:.2e}; "
          f"total dev = {dtot:.2e}; lattice N-stability = {stab:.2e}")
    print(f"        F_j at tau=0.6, 1.25: closed {cJJ[2]+cY[2]:+.6f}, {cJJ[5]+cY[5]:+.6f}; "
          f"lattice {lat_JJ[2]+lat_Y[2]:+.6f}, {lat_JJ[5]+lat_Y[5]:+.6f}")
print(f"done in {time.time()-t0:.1f}s")
