# NEXT SESSION TASK — close the zone-(ii) theorem: lemmas (L-a), (L-b), zone (iii), then assemble the D2 statement

**[EXECUTED 2026-07-19, sixth session of the day — see D2 note §7 (F10). All four ordered
actions done; item 5 (subleading) resolved structurally in passing; the u₁-warning was
neutralized by choosing a FIXED split x₀ = 1/2 (γ ≥ arccosh 2 on the whole Debye zone).
Kept for the record.]**

**Stage D2, zone (ii) closure · staged 2026-07-19 (end of the five-session day) · not RH/GRH.**

## Read first (in this order)
1. `D2_progress_bessel_kernels_2026-07-19.md` **§7, block (F9)** — the derived profile,
   the closed-form law, the bound structure, and exactly which two lemmas are pending.
   (F9) is the state; (F5) is the σ-calculus you will reuse.
2. `RESULTS.md`, last entry (caustic profile derived / √log refuted / ladder corrected).
3. `EVIDENCE_CHAIN_T2_pin.md` §9, last entry (six dated 2026-07-19 entries total).
4. `t2_d2_olver_profile.py` + its log — the derivation certificate (O1–O6 blocks).
5. `t2_d2_kappa_full_ladder.csv` — the single authoritative κ table.

## Established state (all committed, all verified — do NOT re-derive)
- **The law (closed form, derived):** κ_j = 1 + E_j, E_j = a_∞μ^{1/3} + O(1),
  a_∞ = 2·2^{−1/3}Ai(0)Bi(0) = 2^{2/3}·3^{−5/6}/Γ(2/3)² = 0.346555…
  (= 0.43663·j^{1/3}). Measured subleading ≈ −0.76 − 0.017·ln μ, |const| < 1 on
  j = 256…16384. (F8)'s √ln law is REFUTED (out-of-sample j = 16384: +2.06% vs −0.18%)
  — do not resurrect it; it was the additive constant in disguise.
- **The profile:** Φ_∞(ŝ) = −4(AiBi)′(σ), σ = −2^{1/3}ŝ — verified 8.0e−5 (Richardson
  3-pt over j = 4096/8192/16384); first correction Ψ₁ = −4·2^{1/3}(AiAi′)′ confirmed
  (0.998 ± 0.01). Oscillatory side: c_osc = −(4/π)(1 − sinθ)cos2ψ, θ = arccos(μ/z),
  envelope verified 1.8e−3; DC ≈ 0 (O(ε²)) — the s > 0 side nets nothing into E.
- **Machinery:** rows() in `t2_d2_caustic_exponent.py` (importable — __main__-guarded);
  exact-σ Olver assembly in `t2_d2_olver_profile.py` matches rows at 6.6e−7 (j = 1024);
  chunked far-block in `t2_d2_kappa_full_ladder.py` is bitwise-equal to rows() (asserted).
- **Bounds as stated in (F9):** upper target κ_j ≤ 1 + a_∞μ^{1/3} + C₀ (no log);
  lower E_j ≥ 0.1212·μ^{1/3} − O(1) from ŝ ∈ [−4,−1] where |(AiBi)′| ≥ 7.1e−3.
  Both are theorem-grade MODULO the two lemmas below — that is this session's job.

## The task, in order
1. **(L-a) Olver-remainder accumulation.** Quantify the total error of replacing the
   four Bessel factors by their Olver leading terms, summed over the uniform window
   x ∈ [x₀, 1+η]: per-function relative error is O(ν^{−4/3})·envelope (Olver's explicit
   error bounds — DLMF 10.20 / Olver 1997 Ch. 11 give effective constants; cite and
   instantiate, don't re-prove). Route: (i) write the per-row absolute error budget
   e_n ≤ ε·|Ψ₁(ŝ_n)| + Cε³·(uniform tail weight); (ii) sum: (μ^{1/3}/π)[ε∫|Ψ₁| + …]
   = O(1) explicit. Verify every claimed envelope numerically at j = 256/1024 before
   trusting it (O1/O2 blocks of the olver script are the template). Deliverable: an
   explicit C_{L-a} such that |E_j − (μ^{1/3}/2)I_∞| ≤ C_{L-a} + (L-b) + EM terms.
2. **(L-b) zone-(i) Debye block** (x < x₀ fixed, i.e. n ≲ 0.3j). **WARNING (derived
   F9, do not repeat the mistake): the naive leading Debye term
   c ≈ 2e^{−2γ}/(πμ cosh²γ tanhγ) is NOT the whole story near γ → 0 — after the
   telescope cancellation the u₁-order Debye corrections (~1/(νγ³)) carry the
   |ŝ|^{−3/2}-matching tail.** For the BOUND you do not need the exact constant:
   an upper envelope |c(x)| ≤ (C/μ)·F(γ) with F integrable on [γ₀, ∞) suffices —
   Σ over the zone = O(1)·? — target an explicit O(1) (measured total ≤ 0.02, so
   there is enormous slack; a crude rigorous envelope wins). Verify the envelope
   against rows() at j = 1024/4096 across the zone before using it.
3. **Zone-(iii) lemma write-up** from (F5): |C_m| = |g₁|ρ₁(m)(1 ± 0.04) beyond
   z = 2μ², alternating domination — machinery exists and is verified; write the
   lemma statement + proof sketch with the exact-rational identities cited.
4. **Assemble the D2 zone-(ii) statement** (new note or (F10) block): THEOREM
   (companion model): κ_j = 1 + a_∞μ^{1/3} + R_j, |R_j| ≤ C₀ explicit, with the
   lower bound E_j ≥ 0.1212μ^{1/3} − C₀ (log-K1 refuted). State honestly which
   ingredient is classical-cited (Olver bounds), which exact-rational (σ-calculus),
   which finite-numeric (compact-window Airy checks, margins quoted).
5. If budget remains: resolve the subleading constant (EM + ∫Ψ₁ + zone-(i) sum —
   does −0.017 ln μ survive as a genuine ln, or is it a μ^{−1/3}-family fit
   degeneracy? The Wronskian ε³-term of the telescope is a candidate ln source.)
6. Update `D2_progress` §7 (new block), `RESULTS.md`, ledger §9, PLAN state block;
   refresh the DRAFT IB side note if the theorem closes (it currently says "modulo
   two lemmas"); commit. If the theorem closes → this folder is ready to cut into a
   new dated to_Ilya send (Selina decides the send).

## Float-traps (all live; one new lesson from the F9 session)
1. Far-tail trig-form phase noise — rational forms only.
2. Sub-turning forward Lommel — backward Miller only (use rows(), nothing else).
3. Exactness leaks: mpmath-lambdify float args; sympy nsimplify — cancel+numer/denom.
4. Garbage-FINITE scipy underflow rows — NEVER reintroduce scipy jv/yv into rows.
5. NEW (F9 lesson, analytic genus): a slick proof that (AiBi)′ < 0 by integrating
   W‴ = 4xW′ + 2W over (x, ∞) is WRONG — ∫^∞AiBi DIVERGES (~√T/π) and AiBi is not
   convex (W″(0.5) < 0). Check integrability before integrating identities to ∞;
   verify sign claims numerically before writing "hence".

## Standing rules (unchanged)
Verify every identity numerically before building on it. Negative results are results —
into RESULTS.md. Sent/sealed folders are frozen. No SHA until something ships. Grades on
every entry. Check CPU contention before debugging stalls (parallel sessions).

## Suggested opening prompt for the next context window
> Mathematical proof session — D2 zone (ii) closure. Read first:
> T2_P1_completion_2026-07-19/NEXT_SESSION_TASK_zone2_lemmas.md, then D2 note §7 (F9).
> Task: execute the task file in order — lemma (L-a) Olver-remainder accumulation with
> explicit constants, lemma (L-b) zone-(i) Debye envelope (mind the u₁-order warning),
> zone-(iii) write-up from (F5), then assemble the zone-(ii) theorem statement
> κ_j = 1 + a_∞μ^{1/3} + R_j with explicit R-bound and the caustic lower bound.
> Verify every envelope numerically before use; negative results are results; update
> folder + ledger before ending. Not RH/GRH. Don't touch sealed to_Ilya packages.
