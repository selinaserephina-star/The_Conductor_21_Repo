# t2_d2_pairing_windowedS.py — THE MENU QUESTION: does the windowed-S pairing tolerate
# j^(1/3) row constants? Seventh session of 2026-07-19. Model half (certified rows).
#
# Mechanism under test (the (F9)/(F10) dividend): kappa_j ~ a_inf mu^(1/3) is NOT spread
# over the section — the partial-sum profile ps_m = sum_{n<=m} K_n is a LOCALIZED caustic
# dip: |ps| >= t*E only on ~mu^(1/3)/t^2 atoms around m* = 2j/pi, with |shat|^(-1/2)
# wings and an O(1)-scale far field. Summation by parts then says the pairing
#   P[b] = sum_n K_n b_n = sum_m ps_m (b_m - b_{m+1})   (b_N = 0 fields)
# pays the LOCAL variation of b against the dip, not kappa_j * TV(b):
#   |P[b]| <= <Psi_j, |Db|>,  Psi_j = explicit profile majorant.
# For fields with equidistributed variation (|Db| ~ TV/N_sec): cost ~ (Sig_j/N_sec)*TV
# with Sig_j := sum_m |ps_m| ~ C*mu — i.e. O(1)*TV uniformly in j <= section scale.
# The j^(1/3) bites ONLY fields whose variation concentrates inside the moving caustic
# window (sharpness: step at m*).
import numpy as np
from t2_d2_caustic_exponent import rows

CBRT2 = 2.0 ** (1.0 / 3.0)

def olver_shat(mu, z):
    x = np.asarray(z, dtype=float) / mu
    sig = np.empty_like(x)
    hi = x > 1.0
    if np.any(hi):
        xx = x[hi]
        sig[hi] = -(1.5 * mu * (np.sqrt(xx * xx - 1) - np.arccos(1 / xx))) ** (2 / 3)
    lo = ~hi
    if np.any(lo):
        xx = x[lo]
        sig[lo] = (1.5 * mu * (np.arccosh(1 / xx) - np.sqrt(1 - xx * xx))) ** (2 / 3)
    return -sig / CBRT2

def pair(K, b):
    return float(np.sum(K * b))

print("=== (W1) the partial-sum profile is LOCALIZED: dip width + ell^1 mass ===")
DATA = {}
for j in [256, 1024, 4096]:
    mu = 2 * j + 0.5
    N6 = 6 * j
    z, c, K = rows(j, N6)
    ps = np.cumsum(K)
    shat = olver_shat(mu, z)
    iE = int(np.argmax(-ps)); E = float(-ps[iE])
    DATA[j] = (z, c, K, ps, shat, iE, E, mu, N6)
    Sig = float(np.sum(np.abs(ps)))
    for t in [0.5, 0.25]:
        w = int(np.sum(np.abs(ps) >= t * E))
        print(f"  j = {j}: width(|ps| >= {t:.2f} E) = {w} atoms = {w/mu**(1/3):.2f} mu^(1/3)"
              + (f";  E = {E:.3f}, Sigma|ps| = {Sig:.1f} = {Sig/mu:.3f} mu" if t == 0.5 else ""))

print("=== (W2) pairing families, TV(b) = 1, b_N = 0; raw Abel bound = kappa_j ===")
print("           j    kappa_j    ramp |P|   step@m* |P|  smoothed step |P| by half-width w")
for j in [256, 1024, 4096]:
    z, c, K, ps, shat, iE, E, mu, N6 = DATA[j]
    kap = 1 + E   # rev-branch sup (F7/F10); raw Abel constant
    # ramp: b = 1 -> 0 linearly, TV = 1, equidistributed
    b_ramp = 1.0 - np.arange(N6) / (N6 - 1.0)
    P_ramp = pair(K, b_ramp)
    # sharp step at m* (TV concentrated AT the caustic): P = ps_{m*} exactly = -E
    b_step = (np.arange(1, N6 + 1) <= iE + 1).astype(float)
    P_step = pair(K, b_step)
    # smoothed steps: 1 until m*-w, linear down over 2w+1 rows centered at m*, 0 after
    line = ""
    for w in [4, 16, 64, 256, 1024]:
        lo, hi = max(iE - w, 0), min(iE + w, N6 - 1)
        b = np.ones(N6)
        b[lo:hi + 1] = np.linspace(1, 0, hi - lo + 1)
        b[hi + 1:] = 0.0
        line += f"  w={w}: {abs(pair(K, b)):6.3f}"
    print(f"  j = {j:5d}  {kap:7.3f}   {abs(P_ramp):8.4f}   {abs(P_step):8.4f} (= E)\n"
          f"       {line}")

print("=== (W2b) sine sweep: |P| vs wavelength lambda (TV = 1, tapered) ===")
for j in [1024, 4096]:
    z, c, K, ps, shat, iE, E, mu, N6 = DATA[j]
    n = np.arange(1, N6 + 1, dtype=float)
    out = []
    for lam in [8, 32, 128, 512, 2048, 8192]:
        if lam > N6:
            continue
        a = lam / (4.0 * N6)                     # TV ~ 4a N6/lam = 1
        b = a * np.sin(2 * np.pi * n / lam) * np.hanning(N6)
        tv = float(np.sum(np.abs(np.diff(b)))) + abs(b[-1])
        out.append(f"lam={lam}: {abs(pair(K, b))/tv:7.4f}")
    print(f"  j = {j}: |P|/TV -> " + "  ".join(out) + f"    [raw bound {1+E:.2f}]")

print("=== (W3) explicit profile majorant Psi_j >= |ps_m| pointwise, and the budget ===")
# Psi_j(m) = min( 1.10*(1 + a_inf mu^(1/3)),  1 + 0.50*mu^(1/3)*|shat_m|^(-1/2) )
#   (0.50 = sqrt(2)/pi + headroom on the left-wing constant; 1.10*kappa covers the dip;
#    the right/osc side is covered by the SAME |shat|^(-1/2) form — verified here.)
A_INF = 0.346555372
for j in [256, 1024, 4096]:
    z, c, K, ps, shat, iE, E, mu, N6 = DATA[j]
    Psi = np.minimum(1.10 * (1 + A_INF * mu ** (1 / 3)),
                     1.0 + 0.50 * mu ** (1 / 3) / np.sqrt(np.maximum(np.abs(shat), 1e-9)))
    bad = int(np.sum(np.abs(ps) > Psi))
    marg = float(np.min(Psi - np.abs(ps)))
    print(f"  j = {j}: violations = {bad}/{N6};  min margin = {marg:+.4f};"
          f"  <Psi>/mu = {np.sum(Psi)/mu:.3f}  [budget for equidistributed TV:"
          f" (<Psi>/N6)*TV = {np.sum(Psi)/N6:.3f}*TV]")
print("done.")
