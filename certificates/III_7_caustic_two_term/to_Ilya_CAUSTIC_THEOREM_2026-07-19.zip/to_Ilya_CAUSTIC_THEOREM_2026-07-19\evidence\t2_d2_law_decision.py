# t2_d2_law_decision.py — decide the E_j law: 0.131 j^(1/3) sqrt(ln j)  vs  a mu^(1/3) + c.
# The caustic-profile measurement (t2_d2_caustic_profile.py) showed the smooth-side tail
# is a CONVERGENT power law (~|s|^-1.6, close to (AiBi)'-type |s|^-3/2), and the
# oscillatory side has DC ~ 0 => E_j = (mu^(1/3)/pi) * int_{-inf}^{0} Phi_K + O(1),
# i.e. a PURE mu^(1/3) law with an additive O(1) constant (Euler-Maclaurin + core).
# Three decisive checks, none of which reuse the other's data:
#   (1) LSQ residual comparison of the two laws on the certified F8 ladder (6 points);
#   (2) OUT-OF-SAMPLE: predict E(16384) from both laws fitted on j <= 8192, then measure;
#   (3) INDEPENDENT: a = I_c/2 with I_c = int Phi_c ds read off the collapsed profile
#       (trapezoid on the j=8192 atoms + power-tail completion) -- no ladder fitting.
import numpy as np
from t2_d2_caustic_exponent import rows

E_LADDER = {256: 1.9103, 512: 2.6159, 1024: 3.5116, 2048: 4.6432, 4096: 6.0641, 8192: 7.8836}

print("=== (1) two-parameter fits on the F8 ladder (j = 256..8192) ===")
js = np.array(sorted(E_LADDER)); Es = np.array([E_LADDER[j] for j in js])
mu13 = (2 * js + 0.5) ** (1.0 / 3.0)
# M2: E = a*mu^(1/3) + c
M = np.column_stack([mu13, np.ones_like(mu13)])
(a2, c2), *_ = np.linalg.lstsq(M, Es, rcond=None)
r2 = Es - (a2 * mu13 + c2)
# M1: E = b * j^(1/3) sqrt(ln j)   (1 parameter)
g = js ** (1.0 / 3.0) * np.sqrt(np.log(js))
b1 = float(g @ Es / (g @ g))
r1 = Es - b1 * g
# M1b: E = b * j^(1/3) sqrt(ln j) + c   (2 parameters, same count as M2)
M = np.column_stack([g, np.ones_like(g)])
(b1b, c1b), *_ = np.linalg.lstsq(M, Es, rcond=None)
r1b = Es - (b1b * g + c1b)
print(f"  M1  E = {b1:.4f} j^(1/3) sqrt(ln j)          max rel resid {np.max(np.abs(r1/Es)):.4f}")
print(f"  M1b E = {b1b:.4f} j^(1/3) sqrt(ln j) {c1b:+.4f}  max rel resid {np.max(np.abs(r1b/Es)):.4f}")
print(f"  M2  E = {a2:.4f} mu^(1/3) {c2:+.4f}            max rel resid {np.max(np.abs(r2/Es)):.4f}")
print(f"      per-point resid M2: " + "  ".join(f"{r:+.4f}" for r in r2))

print("=== (2) out-of-sample: predict E(16384), then measure it on certified rows ===")
j = 16384
mu = 2 * j + 0.5
p1 = b1 * j ** (1.0 / 3.0) * np.sqrt(np.log(j))
p1b = b1b * j ** (1.0 / 3.0) * np.sqrt(np.log(j)) + c1b
p2 = a2 * mu ** (1.0 / 3.0) + c2
print(f"  predictions:  M1 {p1:.4f}   M1b {p1b:.4f}   M2 {p2:.4f}")
N = 6 * j
z, c, K = rows(j, N)
ps = np.cumsum(K)
iE = int(np.argmax(-ps)); E16 = float(-ps[iE])
# certification: ktop-stability on the sup-relevant range
z2, c2b, K2 = rows(j, int(1.2 * j), ktop_extra=330)
kdev = float(np.max(np.abs(c[: len(c2b)] - c2b)))
print(f"  MEASURED E(16384) = {E16:.4f}   at n/j = {(iE+1)/j:.4f}   (ktop-stability {kdev:.1e})")
print(f"  errors:  M1 {p1-E16:+.4f} ({(p1-E16)/E16*100:+.2f}%)   M1b {p1b-E16:+.4f} "
      f"({(p1b-E16)/E16*100:+.2f}%)   M2 {p2-E16:+.4f} ({(p2-E16)/E16*100:+.2f}%)")

print("=== (3) independent a from the collapsed profile: a = I_c/2 (no ladder data) ===")
# j = 8192 atoms on the smooth side; I_c = int_{-S}^{0} Phi_c ds (trapezoid) + tail completion
j8 = 8192; mu8 = 2 * j8 + 0.5
N8 = 6 * j8
z8, c8, K8 = rows(j8, N8)
x = z8 / mu8
shat = np.empty_like(x)
hi = x > 1.0
shat[hi] = (1.5 * mu8 * (np.sqrt(x[hi] ** 2 - 1) - np.arccos(1 / x[hi]))) ** (2 / 3) / 2 ** (1 / 3)
shat[~hi] = -(1.5 * mu8 * (np.arccosh(1 / x[~hi]) - np.sqrt(1 - x[~hi] ** 2))) ** (2 / 3) / 2 ** (1 / 3)
for S in [64.0, 128.0, 256.0, 512.0]:
    m = (shat >= -S) & (shat <= 0.0)
    ss = shat[m]; cc = c8[m]
    T = float(np.trapezoid(cc, ss))
    # tail completion using the measured local power law at the cut
    selt = (shat >= -S) & (shat <= -S / 4)
    bb, aa = np.polyfit(np.log(-shat[selt]), np.log(np.abs(c8[selt])), 1)
    p = -bb  # decay exponent
    tail = np.exp(aa) * S ** (1 - p) / (p - 1)
    print(f"  S = {S:5.0f}:  trapz = {T:.4f}  + tail({p:.2f}) = {tail:.4f}  ->  I_c = {T+tail:.4f}"
          f"   a = I_c/2 = {(T+tail)/2:.4f}")
# also the proj correction near the core (should be ~0 as j -> inf): sum proj over shat<0
proj = K8 + (np.pi / 2) * c8
m = shat <= 0
print(f"  proj mass below caustic (atoms, shat<=0): {proj[m].sum():.4f}  (-> 0 as j grows?)")
print(f"  fitted a from ladder (for comparison): {a2:.4f}")
print("done.")
