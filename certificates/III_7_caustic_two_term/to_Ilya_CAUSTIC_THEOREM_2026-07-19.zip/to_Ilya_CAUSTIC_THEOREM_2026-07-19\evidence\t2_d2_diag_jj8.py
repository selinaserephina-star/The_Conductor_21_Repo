# diagnostic: j=8 F_JJ 4e-6 mismatch — which side is wrong?
#  (a) per-n check: rational G_JJ(z_n) vs the Psi-integral form (z^3/pi)int Psi_s sin + (z^2/2pi)int Psi_c cos
#  (b) Psi_s''' evaluation: mpmath lambdify vs exact sympy Rational substitution
#  (c) closed F_JJ vs lattice at one tau with N pushed up and small-z (jv/yv) region widened
import numpy as np, sympy as sp, mpmath as mp
from scipy.special import jv, yv
from t2_d2_Fj_closed_form import AB, G_parts, phi_poly, tapered_sum

j = 8; mu = 2 * j + 0.5
s = sp.Symbol('s')
mus = sp.Rational(4 * j + 1, 2)
Psi_s = sp.expand(phi_poly(2*j-1, 2*j+2, s) / (mus + 1) - phi_poly(2*j-3, 2*j, s) / (mus - 1))
Psi_c = sp.expand((2*mus - 1) * phi_poly(2*j, 2*j+2, s) / (mus + 1) - (2*mus - 5) * phi_poly(2*j-2, 2*j, s) / (mus - 1))

# (a) per-n: quadrature of the Psi-integral form vs rational G_JJ
mp.mp.dps = 50
fs = sp.lambdify(s, Psi_s, 'mpmath'); fc = sp.lambdify(s, Psi_c, 'mpmath')
z_all, GJJ, GY = G_parts(j, 60)
print("n      rational G_JJ        Psi-integral G_JJ      dev")
for n_idx in [24, 39, 59-1]:
    zz = mp.mpf(float(z_all[n_idx]))
    I_s = mp.quad(lambda t: fs(t) * mp.sin(zz * t), [0, 1, 2])
    I_c = mp.quad(lambda t: fc(t) * mp.cos(zz * t), [0, 1, 2])
    G_int = float(zz**3 / mp.pi * I_s + zz**2 / (2 * mp.pi) * I_c)
    print(f"{n_idx+1:3d}  {GJJ[n_idx]:+.12e}  {G_int:+.12e}  {abs(GJJ[n_idx]-G_int):.2e}")

# (b) Psi_s''' at tau = 0.6: mpmath-lambdify (dps 40) vs exact Rational subs
P3 = sp.diff(Psi_s, s, 3)
f3 = sp.lambdify(s, P3, 'mpmath')
mp.mp.dps = 40
v_lam = f3(mp.mpf('0.6'))
v_exact = float(P3.subs(s, sp.Rational(3, 5)))
print(f"Psi_s'''(0.6): lambdify {float(v_lam):+.12e}  exact-subs {v_exact:+.12e}  dev {abs(float(v_lam)-v_exact):.2e}")
cmax = max(abs(float(c)) for c in sp.Poly(P3, s).all_coeffs())
print(f"max |coeff| of Psi_s''' = {cmax:.2e}, degree = {sp.degree(P3, s)}")

# (c) lattice F_JJ at tau=0.6 for N = 240k vs 480k, and with wider jv/yv region
tau = 0.6
for N in [240000, 480000]:
    z, GJJb, GYb = G_parts(j, N)
    v = tapered_sum(GJJb, z, [tau], N)[0]
    print(f"N={N}: lattice F_JJ(0.6) = {v:+.12e}")
