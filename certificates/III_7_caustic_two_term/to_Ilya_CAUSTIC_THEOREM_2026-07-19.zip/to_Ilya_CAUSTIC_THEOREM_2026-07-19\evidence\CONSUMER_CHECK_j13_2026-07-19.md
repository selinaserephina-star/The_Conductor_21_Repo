# Consumer check: does the K1K2 chain tolerate κ_j ~ j^{1/3}? — VERDICT

**Merkabit · Stenberg + Claude · 2026-07-19 (following the (F7) κ-law revision).**
Question (gate raised by `D2_progress` §7 (F7)): the companion-model kernel partial-sum
constant is κ_j ≈ 0.46·j^{1/3} (measured flat ±3% over j = 64–512), not c₀ + c₁log(2+j).
Who consumes κ_j, and does j^{1/3} break them? Not RH/GRH.

## 1. Production profile is CONSISTENT with the same law (new measurement)

Recomputed the per-j production κ profile from the frozen certified kernels
(`T2_K1K2_kernel_bounds_2026-07-18/k1_kernels_{k1,k4}_N149.npz`, both sum directions,
their protocol), bulk = j ≤ M−6 (boundary layer excluded):

| fit (bulk) | drop-1 | drop-4 |
|---|---|---|
| c₀ + c₁log(2+j) | c₁ = 0.590, maxresid 0.937 | c₁ = 0.587, maxresid 0.925 |
| c·j^{1/3} | **c = 0.516, maxresid 0.819** | **c = 0.523, maxresid 0.802** |

At N = 149 the fits are statistically indistinguishable (the pre-asymptotic window —
same trap as the model's §2 fit), but j^{1/3} fits slightly better and its coefficient
(≈ 0.52) sits next to the model's 0.46 (production ≈ 13% above model, consistent with
the known production↔model correspondence). With the model now measured to j = 512,
**the presumption must be: production κ_j ~ c·j^{1/3}, c ≈ 0.5.** The κ̂ = 5.60 sup is a
separate object — it is attained at the boundary rows j = M−1 (quantile boundary layer
κ_{M−ℓ} ≍ M/πℓ, per the K1K2 note), not by the bulk law.

## 2. Consumers, one by one

- **Finite production range (N ≤ 149), the whole certified chain of K1K2 §6:**
  UNAFFECTED. Every constant there is a measured/certified finite-range number
  (κ̂ = 5.60, bulk ≤ 2.74); no asymptotic law is consumed. The j^{1/3} law in fact
  *explains* the range: 0.5·149^{1/3} ≈ 2.7 = the measured bulk ceiling.
- **(P1) as stated (K1K2 note §7): MUST BE RESTATED.** The target
  sup_m|C_j(A_m)| ≤ c₀ + c₁log(2+j) is FALSE in the companion model (an excursion lower
  bound at the caustic will refute it definitively — D2 next-action 2). Correct target:
  **sup_m|C_j(A_m)| ≤ C·j^{1/3}** (model C ≈ 0.46, production ≈ 0.5), boundary layer
  unchanged. This retroactively explains the D2 estimate-block failures: naive-IBP gave
  ~j, the uniform Γ-bound gave ~√j, and no route produced log — because log is not there.
- **H-ROT / the M → ∞ assembly:** qualitatively unchanged. The raw Abel route pays
  sup_{j≤M}κ_j·TV, which grows unboundedly under EITHER law (log M before, now ~0.5M^{1/3}
  — a factor M^{1/3}/log M ≈ 1.9 at M = 149 worse); closing H-ROT was already known to
  require the oscillation-window pairing (LEMMA note §8), not raw Abel. **The genuinely
  new open question (add to the IB menu): does the windowed-S pairing tolerate j^{1/3}
  row constants?** (The pairing gains ~1/j per row from window cancellation; j^{1/3} ≪ j,
  so the naive accounting still closes — but that accounting is unproven.)
- **KLMN / pin-in-the-limit (G4):** unchanged — those consume the identification-II
  form-bound, whose V-side uses per-row |dα_j| with the row-decay of the truth; the
  uniform-in-M b-constant question was already gated on H-ROT, see above.

## 3. Verdict

**j^{1/3} does not break the program.** Finite-range: untouched. P1: restate log → j^{1/3}
(the D2 proof target is now: prove κ_j ≤ C j^{1/3} at the caustic — upper AND lower bound,
the lower bound killing log-K1 permanently). Limit assembly: the burden stays where it
already was (windowed pairing), with one new quantified question for IB. The revision is
a CORRECTION OF TARGET, not a loss of ground — and the caustic mechanism (Airy window
~μ^{1/3} atoms of O(1) amplitude at n/j = 2/π) now gives the first structural explanation
of WHERE the kernel partial-sum growth comes from, unifying bulk (j^{1/3}) and boundary
(M/πℓ) as two faces of the same uniform-asymptotics regime.

*Grade: production refit float64 on frozen certified kernels (both drops); model law per
(F7) (verified rows, j ≤ 512). Frozen folders read, not touched.*
