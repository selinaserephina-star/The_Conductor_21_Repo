# t2_d2_Fj_ibp_log.py — D2 zone (ii), step 2: the boundary-free IBP against the
# doubled-string Dirichlet kernel and the L^1 estimate; where the log lives.
#
#   C_m := sum_{n<=m} z_n^2 dW_j(z_n) = int_0^2 F_j(tau) D_m(tau) dtau,
#   D_m(tau) = sin(m pi tau)/(2 sin(pi tau/2))    (N4).
#   IBP (boundary-free up to the exact O(1/m) edge term):
#   C_m = 2 F_j'(0)/(m pi^2) + (1/(m pi)) int_0^2 (F_j g)'(tau) cos(m pi tau) dtau,
#       g(tau) = 1/(2 sin(pi tau/2));  F_j g extends continuously to [0,2] since
#       F_j(0)=F_j(2)=0 linearly and F_j(2-u) = -F_j(u) (limits ±F_j'(0)/pi).
#   =>  |C_m| <= min( m * ||F_j||_1 ,  2|F_j'(0)|/(m pi^2) + ||(F_j g)'||_1/(m pi) ).
#   Measure A_j = ||F_j||_1, b_j = |F_j'(0)|, B_j = ||(F_j g)'||_1 vs j; assemble
#   S_bound = sup_m min(...), compare with S_true = sup_m |C_m| and the kappa_j log law.
#
# F_j on a uniform tau grid via FFT: tau_k = 2k/M, F(tau_k) = Re[e^{-i pi k/M} S_k],
# S_k = conj(FFT(fold(c*w)))[k]  (fold n mod M) — resolves frequencies z_n ~ 2 mu^2.
import numpy as np
from t2_d2_Fj_closed_form import G_parts, taper

NLAT = 240000
M = 2 ** 18

def F_grid(c, N=NLAT, m=M):
    n = np.arange(1, N + 1)
    w = np.ones(N); half = N // 2
    w[half:] = taper((n[half:] - half) / (N - half))
    chat = np.bincount(n % m, weights=c[:N] * w, minlength=m)
    S = np.conj(np.fft.fft(chat))
    k = np.arange(m)
    F = np.real(np.exp(-1j * np.pi * k / m) * S)
    return 2.0 * k / m, F          # tau_k in [0,2), F values there

print("=== (I0) FFT grid vs direct tapered sum (j=4, spot) ===")
from t2_d2_Fj_closed_form import tapered_sum
z, GJJ, GY = G_parts(4, NLAT)
c4 = GJJ + GY
tg, Fg_ = F_grid(c4)
spots = [M // 8, M // 3, 3 * M // 4]
dev = max(abs(Fg_[k] - tapered_sum(c4, z, [tg[k]], NLAT)[0]) for k in spots)
print(f"  max dev at 3 spot tau's: {dev:.2e}")

print("=== (I1) exactness: C_m = int F_j D_m  (j=4) ===")
tau = tg[1:]; F4 = Fg_[1:]                     # drop tau=0 (F=0 there anyway)
gsin = 1.0 / (2.0 * np.sin(np.pi * tau / 2.0))
for m in [3, 10, 27, 50]:
    Dm = np.sin(m * np.pi * tau) * gsin
    lhs = float(np.sum(c4[:m]))
    rhs = float(np.trapezoid(F4 * Dm, tau))
    print(f"  m={m:3d}: partial sum {lhs:+.8f}   integral {rhs:+.8f}   dev {abs(lhs-rhs):.2e}")

print("=== (I2) boundary-free IBP identity (j=4) ===")
Fg4 = F4 * gsin
dFg = np.gradient(Fg4, tau)
# F is EVEN in tau (cosine series): F'(0+) is the emergent jump of F' = -sum c z sin(z tau),
# fully formed only for tau >> 1/z_N; fit ABOVE the truncation transition (tau in [3e-4, 3e-3])
i0, i1 = 40, 400
Fp0 = float(np.polyfit(tau[i0:i1], F4[i0:i1], 3)[2])
for m in [10, 27, 50]:
    ibp = 2 * Fp0 / (m * np.pi**2) + (1.0 / (m * np.pi)) * float(np.trapezoid(dFg * np.cos(m * np.pi * tau), tau))
    lhs = float(np.sum(c4[:m]))
    print(f"  m={m:3d}: C_m {lhs:+.8f}   IBP form {ibp:+.8f}   dev {abs(lhs-ibp):.2e}")

print("=== (I3) L1 ingredients: naive IBP bound vs the UNIFORM bound G_j = int |F| g ===")
print("   j    A=||F||_1   B=||(Fg)'||_1   S_naiveIBP   Gamma_j    S_true   m*")
rows = []
for j in [2, 4, 8, 16, 32, 64]:
    z, GJJ, GY = G_parts(j, NLAT)
    c = GJJ + GY
    tg, Fv = F_grid(c)
    tau_i = tg[1:]; Fi = Fv[1:]
    gs = 1.0 / (2.0 * np.sin(np.pi * tau_i / 2.0))
    dFg = np.gradient(Fi * gs, tau_i)
    A = float(np.trapezoid(np.abs(Fi), tau_i))
    b = abs(float(np.polyfit(tau_i[40:400], Fi[40:400], 3)[2]))
    B = float(np.trapezoid(np.abs(dFg), tau_i))
    Gam = float(np.trapezoid(np.abs(Fi) * gs, tau_i))     # |D_m| <= g pointwise, all m
    mm = np.arange(1, 200001, dtype=float)
    S_naive = float(np.max(np.minimum(mm * A, 2 * b / (mm * np.pi**2) + B / (mm * np.pi))))
    cs = np.cumsum(c)
    S_true = float(np.max(np.abs(cs)))
    m_star = int(np.argmax(np.abs(cs))) + 1
    Fsup = float(np.max(np.abs(Fi))); tsup = float(tau_i[int(np.argmax(np.abs(Fi)))])
    L2 = float(np.sqrt(np.sum(c ** 2)))          # Parseval: ||F||_2 = sqrt(sum c_n^2)
    rows.append((j, A, b, B, S_naive, Gam, S_true))
    print(f"  {j:4d}   {A:9.5f}   {B:12.4f}   {S_naive:9.4f}   {Gam:8.4f}  {S_true:8.4f}  {m_star:5d}"
          f"   sup|F|={Fsup:.3f}@{tsup:.3f} ||F||_2={L2:.3f}")

print("=== (I4) log fits: c0 + c1 log(2+j) ===")
js = np.array([r[0] for r in rows], dtype=float)
X = np.vstack([np.ones_like(js), np.log(2 + js)]).T
for name, vals in [("S_true          ", np.array([r[6] for r in rows])),
                   ("Gamma_j         ", np.array([r[5] for r in rows])),
                   ("1+(pi/2)Gamma_j ", 1 + np.pi/2 * np.array([r[5] for r in rows])),
                   ("S_naiveIBP      ", np.array([r[4] for r in rows]))]:
    cf, *_ = np.linalg.lstsq(X, vals, rcond=None)
    resid = vals - X @ cf
    print(f"  {name}: c0={cf[0]:+.4f} c1={cf[1]:+.4f}  max resid {np.max(np.abs(resid)):.3f}")
print("reference: measured kappa_j = 0.386 + 0.382 log(2+j) (D2 note sec 2); kappa <= 1 + (pi/2) sup_m|C_m|")
print("done.")
