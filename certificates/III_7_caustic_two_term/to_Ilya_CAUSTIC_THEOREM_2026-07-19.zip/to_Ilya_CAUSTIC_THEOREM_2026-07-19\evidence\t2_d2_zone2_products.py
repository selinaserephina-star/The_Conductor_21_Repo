# t2_d2_zone2_products.py — D2 zone (ii) toolbox: the product-comb lemma, the Wronskian
# cancellation in the j-telescope, the Casoratian, and the JJ/Y split of the log.
#
#  (Z1) product-comb lemma: for spherical Bessel j_a = sqrt(pi/2z) J_{a+1/2},
#         j_a(z) j_b(z) = (s_ab/2) int_0^2 (P_a * P_b)(tau) trig(z tau) dtau,
#       trig = cos, s_ab = (-1)^{(a+b)/2}   for a+b even;
#       trig = sin, s_ab = (-1)^{(a+b-1)/2} for a+b odd;
#       (P_a * P_b)(tau) = int P_a(s) P_b(tau-s) ds over the overlap  (Legendre convolution).
#       {cos(z_n tau)} is ORTHONORMAL on (0,2) (int_0^2 cos(z_n t)cos(z_m t) = delta_nm) —
#       the doubled string. This lifts the D1 machinery to PRODUCTS of two Bessel values.
#  (Z2) Wronskian cancellation: with Sig_nu := J_{nu+2} Y_nu + J_nu Y_{nu+2},
#         Y_mu J_{mu+2}/(mu+1) - Y_{mu-2} J_mu/(mu-1)
#           = Sig_mu/(2(mu+1)) - Sig_{mu-2}/(2(mu-1))          (EXACT),
#       because J_{nu+2}Y_nu - J_nu Y_{nu+2} = 4(nu+1)/(pi z^2) cancels in the telescope.
#  (Z3) Casoratian of the rational forms: A_{k+1}B_k - A_k B_{k+1} = -1 exactly
#       (A_k = R_{k,1/2}, B_k = R_{k-1,3/2}: the two solutions of the same recurrence).
#  (Z4) split z^2 dW_j = z^2 JJpart + z^2 Ypart: partial-sum sups per part over the
#       lattice — WHERE does the log live?
import os
import numpy as np
from scipy.special import jv, yv, eval_legendre, spherical_jn
from scipy.integrate import quad

HERE = os.path.dirname(os.path.abspath(__file__))

print("=== (Z1) product-comb lemma ===")
rng = np.random.default_rng(3)


def leg_conv(a, bb, tau, ngrid=4000):
    """(P_a * P_bb)(tau) by Gauss-grid quadrature over the overlap [max(-1,tau-1), min(1,tau+1)]."""
    lo, hi = max(-1.0, tau - 1.0), min(1.0, tau + 1.0)
    if hi <= lo: return 0.0
    s, w = np.polynomial.legendre.leggauss(200)
    s = 0.5 * (hi - lo) * s + 0.5 * (hi + lo)
    w = 0.5 * (hi - lo) * w
    return float(np.sum(w * eval_legendre(a, s) * eval_legendre(bb, tau - s)))


worst = 0.0
for (a, bb) in [(0, 0), (1, 2), (3, 6), (7, 10), (5, 5)]:
    for z in rng.uniform(3.0, 40.0, 3):
        lhs = spherical_jn(a, z) * spherical_jn(bb, z)
        even = (a + bb) % 2 == 0
        sgn = (-1.0) ** ((a + bb) // 2) if even else (-1.0) ** ((a + bb - 1) // 2)
        f = (lambda t: leg_conv(a, bb, t) * np.cos(z * t)) if even else (lambda t: leg_conv(a, bb, t) * np.sin(z * t))
        val, _ = quad(f, 0.0, 2.0, limit=200)
        rhs = 0.5 * sgn * val
        worst = max(worst, abs(lhs - rhs))
print(f"  max abs dev over (a,b) in {{(0,0),(1,2),(3,6),(7,10),(5,5)}} x 3 z-values: {worst:.2e}")
# orthonormality of the doubled-string basis
t = np.linspace(0, 2, 200001)
g = 0.0
for (n1, n2) in [(1, 1), (1, 2), (3, 7), (5, 5)]:
    v = np.trapezoid(np.cos((n1 - 0.5) * np.pi * t) * np.cos((n2 - 0.5) * np.pi * t), t)
    g = max(g, abs(v - (1.0 if n1 == n2 else 0.0)))
print(f"  doubled-string orthonormality int_0^2 cos cos = delta: max dev {g:.2e}")

print("=== (Z2) Wronskian cancellation in the telescope ===")
worst1 = worst2 = 0.0
for j in [2, 5, 11]:
    mu = 2 * j + 0.5
    for z in rng.uniform(2 * mu, 20 * mu, 4):
        for nu in (mu, mu - 2):
            w1 = jv(nu + 2, z) * yv(nu, z) - jv(nu, z) * yv(nu + 2, z) - 4 * (nu + 1) / (np.pi * z ** 2)
            worst1 = max(worst1, abs(w1))
        Sig = lambda nu: jv(nu + 2, z) * yv(nu, z) + jv(nu, z) * yv(nu + 2, z)
        lhs = yv(mu, z) * jv(mu + 2, z) / (mu + 1) - yv(mu - 2, z) * jv(mu, z) / (mu - 1)
        rhs = Sig(mu) / (2 * (mu + 1)) - Sig(mu - 2) / (2 * (mu - 1))
        worst2 = max(worst2, abs(lhs - rhs))
print(f"  cross-product identity max dev: {worst1:.2e}; telescope cancellation max dev: {worst2:.2e}")

print("=== (Z3) Casoratian A_(k+1) B_k - A_k B_(k+1) = -1 ===")
worst = 0.0
for z in rng.uniform(1.0, 50.0, 5):
    A0, A1 = 1.0, 1.0 / z
    B0, B1 = 0.0, 1.0
    for k in range(1, 30):
        A0, A1 = A1, ((2 * k + 1) / z) * A1 - A0
        B0, B1 = B1, ((2 * k + 1) / z) * B1 - B0
        # RELATIVE deviation: for k >> z both solutions are huge and the exact -1 is below
        # f64 resolution of the products — the identity is exact, the check must be relative
        scale = abs(A1 * B0) + abs(A0 * B1) + 1.0
        worst = max(worst, abs(A1 * B0 - A0 * B1 + 1.0) / scale)
print(f"  max RELATIVE dev over k <= 30, 5 z-values: {worst:.2e}")

print("=== (Z4) JJ vs Y split of z^2 dW: which part carries the log? ===")
print("   j     sup|PS(z^2 dW)|   sup|PS(JJ part)|   sup|PS(Y part)|   (caps z <= 2 mu^2)")
for j in [4, 8, 16, 32, 64]:
    mu = 2 * j + 0.5
    cap = int(max(2 * mu * mu / np.pi, 4000))
    n = np.arange(1, cap + 1, dtype=float)
    z = (n - 0.5) * np.pi
    with np.errstate(all='ignore'):
        JJ = ((jv(mu - 1, z) - (2 * mu - 1) * jv(mu, z) / (2 * z)) * jv(mu + 2, z) / (mu + 1)
              - (jv(mu - 3, z) - (2 * mu - 5) * jv(mu - 2, z) / (2 * z)) * jv(mu, z) / (mu - 1))
        Sig_mu = jv(mu + 2, z) * yv(mu, z) + jv(mu, z) * yv(mu + 2, z)
        Sig_m2 = jv(mu, z) * yv(mu - 2, z) + jv(mu - 2, z) * yv(mu - 4, z)
        # careful: Sig_{mu-2} = J_mu Y_{mu-2} + J_{mu-2} Y_mu  (orders nu=mu-2, nu+2=mu)
        Sig_m2 = jv(mu, z) * yv(mu - 2, z) + jv(mu - 2, z) * yv(mu, z)
        Ypart = Sig_mu / (2 * (mu + 1)) - Sig_m2 / (2 * (mu - 1))
        tJJ = z ** 2 * JJ; tY = z ** 2 * Ypart
        tot = z ** 2 * ((jv(mu - 1, z) - (2 * mu - 1) * jv(mu, z) / (2 * z) + yv(mu, z)) * jv(mu + 2, z) / (mu + 1)
                        - (jv(mu - 3, z) - (2 * mu - 5) * jv(mu - 2, z) / (2 * z) + yv(mu - 2, z)) * jv(mu, z) / (mu - 1))
    for arr in (tJJ, tY, tot):
        arr[~np.isfinite(arr)] = 0.0
    cons = np.max(np.abs(tot - (tJJ + tY)))
    s_t = np.max(np.abs(np.cumsum(tot))); s_jj = np.max(np.abs(np.cumsum(tJJ))); s_y = np.max(np.abs(np.cumsum(tY)))
    print(f"  {j:>4}   {s_t:12.4f}      {s_jj:12.4f}      {s_y:12.4f}     (split consistency {cons:.1e})")
print("done.")
