# ELBOW note — the w ≈ 3 window is the CAUSTIC SCALE of the maximizing kernel rows (G-E: derived, not refuted)

**Merkabit · Stenberg + Claude · 2026-07-19 (eighth session of the day). Stage E deliverable
per PLAN; script `t2_e_elbow_kernel_scale.py` + log this folder; frozen K1K2 npz and the
stage-2.5/2.6-pre knee CSVs read only. Not RH/GRH.**

## The question

The S-norm lemma wants form-bound(V) ≤ C·‖S‖*_w with ‖S‖*_w a windowed-average norm of S
over windows of w mean spacings. The octonion frame nominated w = 3 (one J3(O) block);
the measured C_needed(w) curves (`window_knee_production.csv`, 2026-07-18) knee near
w ≈ 3. G-E asked: derive that scale from the exact kernel oscillation structure at the
maximizing rows — or refute the kernel origin. **Verdict: DERIVED.**

## The derivation (three measurements, one closed-form scale)

1. **Where the form bound lives.** |dα_j| on the actual drop-4 field peaks at j = 3
   (0.01059), with j = 2 fourth (0.00729); the maximizing rows put 87–89% of their
   |K·dx| mass at n ≤ 3. (This localization is structural, not accidental: by the (F11)
   runaway, the pairing peaks where the kernel caustic overlaps the transport field's
   TV mass, i.e. at small j — quantile-class fields concentrate variation at small n.)
2. **The sign structure of those rows is the caustic, and its scale is closed-form.**
   Production first sign changes: j = 2 at n = 4; j = 3 at n = 4 (after the n = 1
   boundary flip). Model closed-form rows (certified rational): near-caustic sign
   cluster ends at n = 4 (j = 2) / 7 (j = 3), against the (F9)/(F10) prediction
     **w*_j = n* + width = 2j/π + μ_j^{1/3}**  (μ = 2j + ½):
   2.9 at j = 2, 3.8 at j = 3, 4.6 at j = 4, 6.1 at j = 6 — matching the measured
   clusters at every j. **At the maximizing rows j = 2–3 this scale is ≈ 3.**
3. **The operational tolerance reproduces the empirical knee.** Replacing dx by its
   w-window block average (kernels fixed — this isolates the kernel side from S's own
   autocorrelation): per-row pairing error at j = 2 is 0.28 at w = 2, 0.55 at w = 3
   (w*(50%) = 3); at j = 3 it is 0.76 at w = 2, 0.91 at w = 3. Aggregate
   sup_j|K(dx − dx_w)|/sup_j|K·dx| = 0.00 / 0.76 / 1.01 at w = 1 / 2 / 3. The frozen
   empirical C_needed(w) has its maximum slope exactly on the interval w ∈ [2, 3].

**Conclusion.** The elbow is kernel-side and closed-form: windows finer than the
maximizing rows' caustic scale w* = 2j_max/π + μ_max^{1/3} ≈ 3 preserve the pairing;
w = 3 is the LAST marginally-usable window (already ~50–90% loss at the two maximizing
rows); w ≥ 4 is dead. The J3(O)-nominated w = 3 coincides with the caustic scale of the
j = 2–3 kernels. Honest sharpening: the elbow is soft on its left edge — j = 3 already
loses most of its pairing at w = 2; "w ≤ 2 safe, w = 3 marginal, w ≥ 4 dead" is the
precise reading of both our tolerance curves and the 2026-07-18 empirical knee.

## The precise ‖S‖* window norm (the G-E deliverable)

For quantile-class configurations (dx_n = u_n·S(γ_n), u_n > 0 smooth decaying):

  **‖S‖*_w := max over aligned windows I of w mean spacings of |avg_I S(γ_n)| — SIGNED
  averages, w = 3 at the form-bound level** (the abs-average A_w of the knee script is a
  valid upper proxy but pays the sign information away; the (F11) sine gains and the
  tolerance curves here both show the pairing consumes signed averages).

Lemma shape now fully posed (kernel side theorem-grade, field side open):
  |dα_j| ≤ w·(Σ_B|K̄_B|u_B)·‖S‖*_w + Osc_j(w),   Osc_j(w) controlled iff w ≤ w*_j,
  form bound ⇒ sup over j sees j_max = 2–3 ⇒ **w = 3**;
the Turing/PZ certified bounds enter through ‖S‖*_3 exactly as LEMMA-§8 anticipated.

## Grades and caveats

- Production measurements float64 on the FROZEN certified kernels (npz read-only; same
  cross-checked objects as (F11)). Model rows certified-rational (rows(), j ≥ 2 — the
  j = 1 row is outside rows()'s order range; j = 1 production row is sign-pure anyway).
- Large-j per-row tolerance ratios are noisy (bases ~1e−4, cancellation-dominated) —
  irrelevant to the form bound; the |dα|-weighted aggregate (E4) is the meaningful object.
- Block windows (aligned) vs moving windows of the knee script: same scale, checked
  against the same empirical curve.
- Feeds G-HROT (the remaining ~4.5× is in-window sign cancellation at w ≤ 3) and G4.
