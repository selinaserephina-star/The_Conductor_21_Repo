# t2_d2_common.py — shared verified machinery for the D2 zone-(ii) scripts (extracted
# verbatim from t2_d2_Fj_closed_form.py, which executes its checks on import).
import numpy as np
from scipy.special import jv, yv

def AB(z, kmax, eps=None):
    """A[k],B[k] over lattice array z (Lommel recurrence; hybrid jv/yv below z*=3kmax+20:
    A is the minimal solution below the turning point — forward recursion unstable there)."""
    A = np.empty((kmax + 1,) + z.shape); B = np.empty_like(A)
    A[0] = 1.0; A[1] = 1.0 / z; B[0] = 0.0; B[1] = 1.0
    for k in range(1, kmax):
        A[k + 1] = ((2 * k + 1) / z) * A[k] - A[k - 1]
        B[k + 1] = ((2 * k + 1) / z) * B[k] - B[k - 1]
    zstar = 3.0 * kmax + 20.0
    sm = z < zstar
    if np.any(sm) and eps is not None:
        zs = z[sm]; pref = np.sqrt(np.pi * zs / 2.0) * eps[sm]
        for k in range(kmax + 1):
            A[k][sm] = pref * jv(k + 0.5, zs)
            B[k][sm] = -pref * yv(k + 0.5, zs)
    return A, B

def G_parts(j, N):
    """(z, G_JJ, G_Y) at atoms z_n = (n-1/2)pi, n = 1..N (rational forms, hybrid small-z)."""
    mu = 2 * j + 0.5
    n = np.arange(1, N + 1, dtype=float); z = (n - 0.5) * np.pi
    eps = (-1.0) ** (n + 1)
    A, B = AB(z, 2 * j + 2, eps=eps)
    GJJ = ((2 * z / np.pi) * (A[2*j-1] * A[2*j+2] / (mu + 1) - A[2*j-3] * A[2*j] / (mu - 1))
           - (1 / np.pi) * ((2*mu - 1) * A[2*j] * A[2*j+2] / (mu + 1)
                            - (2*mu - 5) * A[2*j-2] * A[2*j] / (mu - 1)))
    GY = (-(4 / np.pi) * A[2*j+1] * B[2*j] + (2 * z / np.pi) * A[2*j] * B[2*j] / (mu + 1)
          + (4 / np.pi) * A[2*j-1] * B[2*j-2] - (2 * z / np.pi) * A[2*j-2] * B[2*j-2] / (mu - 1))
    return z, GJJ, GY

def taper(y):
    y = np.clip(y, 1e-12, 1 - 1e-12)
    return 1.0 / (1.0 + np.exp(np.clip(1.0 / (1.0 - y) - 1.0 / y, -700, 700)))

def phi_poly(a, b, s_sym):
    """(P_a * P_b)(s) on [0,2] — exact sympy polynomial (Z1 Legendre convolution)."""
    import sympy as sp
    x = sp.Symbol('x')
    integrand = sp.expand(sp.legendre(a, x) * sp.legendre(b, s_sym - x))
    return sp.expand(sp.integrate(integrand, (x, s_sym - 1, 1)))
