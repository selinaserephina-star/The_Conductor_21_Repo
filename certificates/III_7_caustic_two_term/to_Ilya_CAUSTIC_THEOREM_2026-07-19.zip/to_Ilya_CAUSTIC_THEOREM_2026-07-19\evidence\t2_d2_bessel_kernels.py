# t2_d2_bessel_kernels.py — D2 step 3: EXACT elementary closed form of the companion
# kernel rows, verified, and the infinite-system kappa_j profile from the formula.
#
# Identities (z = z_n = (n-1/2)pi, eps = (-1)^{n+1}, mu = 2j+1/2):
#  (V1) global value law: s_k(y) = sqrt(2k+1) R_{k,1/2}(1/y), and
#       R_{k,1/2}(z) = sqrt(pi z/2) [ J_{k+1/2}(z) sin z - Y_{k+1/2}(z) cos z ]  (global in z)
#  (V2) derivative law at atoms:
#       s_k'(y_n) = -z^2 sqrt((2k+1) pi z/2) eps [ J'_{k+1/2} + J_{k+1/2}/(2z) + Y_{k+1/2} ](z_n)
#  (V3) kernel closed form (x-side, companion weights w_n = 2 x_n; Theorem 1' collected form):
#       K_j(n) = 2 pi mu J_mu(z_n)^2 / z_n  -  (pi/2) z_n^2 [ W_j - W_{j-1} ](z_n),
#       W_j := [ J_{mu-1} - (2mu-1) J_mu/(2z) + Y_mu ] J_{mu+2} / (mu+1),   W_{-1} := 0,
#       (first piece = projection part w_n p_j^2; Dini identity makes its partial sums in [0,1] PROVEN;
#        J_{mu-1} + Y_mu = O(z^{-3/2}) is the pointwise cancellation, now manifest).
#
# Checks: (A) V1 off-atom vs Lambert-coefficient recurrence; (B) V2 vs FD of V1;
# (C) V3 vs finite-M mp-certified kernels (truncation-limited, deviation should ~halve M->2M);
# (D) infinite-system: sum-to-1 per row, kappa_j profile to j = 256, log fit; CSV out.
import os, csv
import numpy as np
from scipy.special import jv, yv

HERE = os.path.dirname(os.path.abspath(__file__))
import importlib.util
spec = importlib.util.spec_from_file_location('d2k', os.path.join(HERE, 't2_d2_companion_kernels.py'))
d2k = importlib.util.module_from_spec(spec)
d2k.__name__ = 'd2k_mod'
import sys
sys.modules['d2k_mod'] = d2k
_src = open(os.path.join(HERE, 't2_d2_companion_kernels.py')).read()
exec(_src.split("for M in (64, 128):")[0], d2k.__dict__)   # import helpers only, skip main loop


def R_lommel(k, z):
    """R_{k,1/2}(z) via the recurrence R_{k+1} = (2(1/2+k)/z) R_k - R_{k-1}."""
    R0 = np.ones_like(z); R1 = 1.0 / z
    if k == 0: return R0
    if k == 1: return R1
    for kk in range(1, k):
        R0, R1 = R1, (2 * (0.5 + kk) / z) * R1 - R0
    return R1


def shat_rec(k, y, b):
    """s_k(y) by the orthonormal three-term recurrence with coefficients b (Lambert law)."""
    s0 = np.ones_like(y); s1 = y / b[0]
    if k == 0: return s0
    for kk in range(1, k):
        s0, s1 = s1, (y * s1 - b[kk - 1] * s0) / b[kk]
    return s1


print("=== (A) V1: s_k = sqrt(2k+1) R_{k,1/2}(1/y), off-atom, k <= 20 ===")
b = np.array([1.0 / np.sqrt(4.0 * k * k - 1.0) for k in range(1, 40)])
rng = np.random.default_rng(1)
z = rng.uniform(2.0, 120.0, 400)
y = 1.0 / z
worst = 0.0
for k in [1, 2, 3, 5, 8, 12, 20]:
    lhs = shat_rec(k, y, b)
    rhs = np.sqrt(2.0 * k + 1.0) * R_lommel(k, z)
    rhsB = np.sqrt(2.0 * k + 1.0) * np.sqrt(np.pi * z / 2) * (jv(k + 0.5, z) * np.sin(z) - yv(k + 0.5, z) * np.cos(z))
    worst = max(worst, np.max(np.abs(lhs - rhs) / np.max(np.abs(rhs))), np.max(np.abs(rhs - rhsB) / np.max(np.abs(rhs))))
print(f"  max rel dev (recurrence vs Lommel vs Bessel form): {worst:.2e}")

print("=== (B) V2 derivative law vs FD of V1, at atoms, k <= 24 ===")
n = np.arange(3, 200, 7, dtype=float)
zn = (n - 0.5) * np.pi
yn = 1.0 / zn
eps = (-1.0) ** (n + 1)
worst = 0.0
for k in [1, 2, 4, 8, 16, 24]:
    h = 1e-6 * yn
    fd = (np.sqrt(2 * k + 1) * (R_lommel(k, 1.0 / (yn + h)) - R_lommel(k, 1.0 / (yn - h)))) / (2 * h)
    nu = k + 0.5
    Jp = jv(nu - 1, zn) - (nu / zn) * jv(nu, zn)
    law = -zn ** 2 * np.sqrt((2 * k + 1) * np.pi * zn / 2) * eps * (Jp + jv(nu, zn) / (2 * zn) + yv(nu, zn))
    worst = max(worst, float(np.max(np.abs(fd - law) / np.maximum(np.abs(law), 1e-12))))
print(f"  max rel dev: {worst:.2e}")


def K_bessel(j, zn):
    """Infinite-companion kernel row K_j at lattice points zn (V3)."""
    mu = 2 * j + 0.5
    proj = 2 * np.pi * mu * jv(mu, zn) ** 2 / zn
    def W(jj):
        if jj < 0: return 0.0 * zn
        m = 2 * jj + 0.5
        return (jv(m - 1, zn) - (2 * m - 1) * jv(m, zn) / (2 * zn) + yv(m, zn)) * jv(m + 2, zn) / (m + 1)
    return proj - (np.pi / 2) * zn ** 2 * (W(j) - W(j - 1))


print("=== (C) V3 vs finite-M mp-certified companion kernels (truncation-limited) ===")
for M in (64, 128):
    nn = np.arange(1, M + 1, dtype=float)
    znM = (nn - 0.5) * np.pi
    xM = 1.0 / znM ** 2
    wLM = xM / xM.sum()
    pipe = d2k.mp_pipeline_w(xM, wLM, 700 if M <= 64 else 1500)
    KaM = pipe['Ka']
    dev = np.zeros(9)
    for j in range(9):
        dev[j] = np.max(np.abs(KaM[j, :M // 2] - K_bessel(j, znM[:M // 2])))
    print(f"  M={M}: max |finite-M kernel - Bessel formula| over j<=8, n<=M/2: {dev.max():.2e} "
          f"(per-j: " + " ".join(f"{t:.1e}" for t in dev) + ")")

print("=== (D) infinite system from the formula: row sums and kappa_j profile ===")
# scipy yv overflows (inf) at large order/small argument where jv underflows (0): the kernel
# there is super-exponentially small — replace non-finite products by 0 and SPOT-VALIDATE
# with mpmath that |K| < 1e-15 in that region. Chunked scan so caps ~ 40 mu^2 stay in memory.
from mpmath import mp as _mp
def K_mpmath(j, z):
    _mp.dps = 40
    mu = 2 * j + 0.5
    def W(jj):
        if jj < 0: return _mp.mpf(0)
        m = 2 * jj + 0.5
        return ((_mp.besselj(m - 1, z) - (2 * m - 1) * _mp.besselj(m, z) / (2 * z)
                 + _mp.bessely(m, z)) * _mp.besselj(m + 2, z) / (m + 1))
    return float(2 * _mp.pi * mu * _mp.besselj(mu, z) ** 2 / z - (_mp.pi / 2) * z ** 2 * (W(j) - W(j - 1)))

rows = []
# scan cap z <= 2 mu^2: the sup sits near the turning point z ~ mu (measured m* ~ mu/pi);
# beyond 2 mu^2 the alternating-domination regime holds (D1 analysis) and float64 phase
# noise (~1e-9 per Bessel eval at large z) would accumulate — flagged per row as
# drift_flag ~ 1e-9 * 2 mu^3/pi, and the unscanned tail mass ~ 2/(pi mu) is reported.
for j in [1, 2, 4, 8, 16, 32, 64, 128, 192]:
    mu = 2 * j + 0.5
    cap = int(max(2 * mu * mu / np.pi, 4000))
    CH = 500000
    ps_run = 0.0
    sup_fwd = 0.0; sup_rev = 1.0   # reverse sup includes m=1 value |1 - 0| = 1
    mstar = 1; nan_zeroed = 0
    proj_max = 0.0; proj_run = 0.0
    lo = 1
    while lo <= cap:
        hi = min(lo + CH - 1, cap)
        nn = np.arange(lo, hi + 1, dtype=float)
        znj = (nn - 0.5) * np.pi
        K = K_bessel(j, znj)
        bad = ~np.isfinite(K)
        nan_zeroed += int(bad.sum())
        K[bad] = 0.0
        ps = ps_run + np.cumsum(K)
        i1 = int(np.argmax(np.abs(ps)))
        if np.abs(ps[i1]) > sup_fwd:
            sup_fwd = float(np.abs(ps[i1])); mstar = lo + i1
        rev = np.abs(1.0 - (np.concatenate([[ps_run], ps[:-1]])))
        sup_rev = max(sup_rev, float(np.max(rev)))
        ps_run = float(ps[-1])
        proj = 2 * np.pi * mu * jv(mu, znj) ** 2 / znj
        proj[~np.isfinite(proj)] = 0.0
        pp = proj_run + np.cumsum(proj)
        proj_max = max(proj_max, float(np.max(pp)))
        proj_run = float(pp[-1])
        lo = hi + 1
    kap = max(sup_fwd, sup_rev)
    resid = abs(ps_run - 1.0)
    # spot-validate the zeroed (overflow) region with mpmath
    spot = 0.0
    if nan_zeroed > 0:
        for zt in [(0.5) * np.pi, (min(nan_zeroed, int(0.3 * mu)) - 0.5) * np.pi]:
            spot = max(spot, abs(K_mpmath(j, _mp.mpf(zt))))
    drift = 1e-9 * 2 * mu ** 3 / np.pi
    tail_est = 2.0 / (np.pi * mu)
    rows.append(dict(j=j, kappa=kap, rowsum_resid=resid, proj_max=proj_max, mstar=mstar,
                     cap=cap, zeroed=nan_zeroed, zeroed_spot=spot,
                     drift_flag=drift, tail_est=tail_est))
    print(f"  j={j:>4}: kappa_j = {kap:.4f} +/- {drift:.0e} (m* = {mstar}), "
          f"row-sum resid = {resid:.2e} vs expected unscanned tail ~ {tail_est:.2e}, "
          f"proj max = {proj_max:.6f} (<=1 req); zeroed {nan_zeroed} pts (mp spot |K| <= {spot:.1e})")
jj = np.array([r['j'] for r in rows], float)
kk = np.array([r['kappa'] for r in rows])
A = np.vstack([np.ones(len(jj)), np.log(2.0 + jj)]).T
c, *_ = np.linalg.lstsq(A, kk, rcond=None)
print(f"  infinite-system fit: kappa_j ~ {c[0]:.3f} + {c[1]:.3f} log(2+j)  over j = 1..256")
with open(os.path.join(HERE, 't2_d2_kappa_infinite.csv'), 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0].keys())); w.writeheader()
    for r in rows: w.writerow(r)
print("saved t2_d2_kappa_infinite.csv")
print("done.")
