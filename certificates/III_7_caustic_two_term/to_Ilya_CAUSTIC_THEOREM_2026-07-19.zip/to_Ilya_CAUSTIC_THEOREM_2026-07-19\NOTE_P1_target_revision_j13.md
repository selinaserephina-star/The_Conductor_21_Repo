# Side note for IB — the P1 target has changed: log(2+j) → 1 + a_∞μ^{1/3} + R_j, |R_j| ≤ 1.1 THEOREM-GRADE   [as sent, 2026-07-19]

**(F10), sixth session of the day — the two pending lemmas are CLOSED and the law is now
a theorem with explicit constants, not just a derived asymptote:**
  **κ_j = 1 + E_j,  E_j = a_∞μ^{1/3} + R_j,  −1.1 ≤ R_j ≤ 0.5  (j ≥ 512)**
  (L-a) Olver-remainder accumulation: two-piece residual envelope verified j-stable at
  256/1024/4096 with 50% headroom; the model constant closes in closed form
  (−D_∞ + 2Ai(0)Ai′(0) + Jac_∞ = −0.5770, vs −0.5761 direct at j = 2²⁰). (L-b) zone-(i)
  Debye block: fixed split x₀ = 1/2 keeps γ ≥ arccosh 2 (no u₁/γ→0 subtlety); envelope
  8× slack; C_b = 0.066. Caustic lower bound now with the EXACT constant:
  **E_j ≥ 0.3466·μ^{1/3} − 1.1 — log-K1 refuted with a_∞ itself.** The measured
  subleading "slow drift" is resolved structurally: every budget component converges
  (no ln μ survives); R_j → ≈ −0.934, matching the j = 16384 residual to 0.001.
  Ingredient grades (honest): Olver error-bound structure classical-cited; a_∞/D_∞/
  Ψ₁-integral/σ-calculus exact; C_model/Jac_∞ quadrature-exact; envelope constants,
  Φ_∞ > 0 compact check, and the sup-at-m* location finite-numeric with margins quoted.
  Read (F10) of the D2 note; details below stand as the day's history.

**Earlier same day (F9) — the law in CLOSED FORM, derived, not fitted:**
  **κ_j = 1 + E_j,  E_j = a_∞·μ^{1/3} + O(1),  a_∞ = 2^{2/3}·3^{−5/6}/Γ(2/3)² = 0.34656**
  (μ = 2j + ½; equivalently 0.43663·j^{1/3}; the measured O(1) constant is ≈ −0.9 with a
  slow drift, |const| < 1 over the whole range). Derivation: Olver/Airy uniform
  asymptotics at the caustic — the four-product telescope collapses to
  **Φ_∞(ŝ) = −4·(AiBi)′(−2^{1/3}ŝ)**, verified at 8.0e−5 against Richardson-extrapolated
  certified rows (and its first correction at 0.998); the law's constant is
  a_∞ = 2·2^{−1/3}Ai(0)Bi(0) by the calculus identity ∫₀^∞(AiBi)′ = −Ai(0)Bi(0).
  An earlier same-day refinement (F8: E ≈ 0.131·j^{1/3}√ln j) is hereby REFUTED by an
  out-of-sample test at j = 16384 (√ln misses by +2.06%; the offset law by −0.18%): the
  √log was a finite-size mimic of the additive constant. There is NO log in the law.
  Also: a caustic lower bound E_j ≥ 0.1212·μ^{1/3} − O(1) holds on a fixed verified
  window (Φ_∞ > 0 with margin) — **log-K1 is refuted permanently**, now theorem-grade
  modulo two classical-machinery lemmas (Olver-remainder accumulation; Debye zone (i)).
  The (F7) κ values at 384/512 quoted below carried the garbage-finite contamination
  (fourth float-trap); corrected: κ(384) = 3.2393, κ(512) = 3.6159; ladder extended on
  certified rows: κ(768) = 4.1141, κ(1024) = 4.5116, E(16384) = 10.1571
  (`t2_d2_kappa_full_ladder.csv` is the single authoritative table).
  Read (F9) of the D2 note first; the below stands as history of the day with
  j^{1/3}-class growth confirmed and the constant now exact.

**Merkabit · Stenberg + Claude · 2026-07-19.** Orientation note to accompany the next
folder update. **The master record is the ledger** (`EVIDENCE_CHAIN_T2_pin.md`, §9 entries
of 2026-07-19); this page is only the fast path into it. Not RH/GRH. Nothing in the sent
packages has been edited — the revision below is recorded in dated notes on top.

## The one-line change

The kernel partial-sum law that P1 was built to prove is not a log. Measured on verified
rows out to j = 512 in the companion string model:

  **κ_j ≈ 0.46 · j^{1/3}**   (κ_j/j^{1/3} flat to ±3% over 64 ≤ j ≤ 512;
                              log and log^{3/2} fits rejected — monotone residual trends)

The 0.386 + 0.382·log(2+j) fit in the K1K2/P1 package (and P1's c₀ + c₁log target) was a
pre-asymptotic misfit: over j ≤ 192 the two laws are numerically indistinguishable, and
every measurement in the package stops there. **P1 restated:** for quantile-class
configurations, sup_m|C_j(A_m)| ≤ C·j^{1/3} (boundary layer unchanged). The log form is
expected to be REFUTABLE by an excursion lower bound — see mechanism.

## The mechanism (why 1/3 — now derived, not inferred)

The full kernel row is now in closed form, and every partial sum C_m is an EXACT finite
expression (rational Laurent coefficients × partial Hurwitz zetas — the "σ-calculus";
three identities, including the row-sum ΣK = 1, hold in exact rational arithmetic).
On these exact rows: the c_n-envelope peaks at n/j = 2/π — the turning point z = μ in
atom units — with O(1) amplitude independent of j, and the sup m*/j → 2/π. The excursion
is coherent accumulation over the **Airy caustic window of ~μ^{1/3} atoms** at that point:
width μ^{1/3} × amplitude O(1) ⟹ κ_j ~ j^{1/3}. This also unifies the bulk law with the
boundary-layer blow-up κ_{M−ℓ} ≍ M/(πℓ) you have in the package — two faces of one
uniform-asymptotics regime.

**(F9) makes this exact.** In the phase-aligned Olver variable ŝ (σ = −2^{1/3}ŝ the Airy
argument at the central order), the row profile collapses to Φ_∞(ŝ) = −4(AiBi)′(σ): the
smooth side (z < μ) is one-signed with a CONVERGENT |ŝ|^{−3/2} tail — the excursion is
literally the integral (μ^{1/3}/2)∫Φ_∞ = 2^{−1/3}·2Ai(0)Bi(0)·μ^{1/3}; the oscillatory
side (z > μ) has envelope (4/π)(1 − sin θ), θ = arccos(μ/z), and no mean — it nets
nothing. Every constant above is verified against the certified rows (profile at 8e−5,
envelope at 2e−3, and the ladder's out-of-sample point at j = 16384 at 0.18%).

Cross-check on YOUR side of the data: refitting the per-j bulk profile from the frozen
certified production kernels (N = 149, both drops, boundary rows excluded) gives
c·j^{1/3} with c ≈ 0.52 — marginally better residuals than the log fit and essentially
the model constant. N = 149 cannot discriminate alone; the model at j = 512 arbitrates.

## What stands, what is superseded

- **Stands:** everything certified at finite range — κ̂ = 5.60 / 2.86 (boundary-row
  object), the §6 assembly chain and all its constants, Theorem D1, the kernel closed
  forms, K2/(L-ORD), the (a,b) = (0.3, 0.011) PSD data. Also new and proof-grade: the
  σ-calculus identities (exact rational), and zone (iii) of the three-zone plan
  effectively closes (alternating domination, ratio ≤ 0.04; the "universal tail 0.231"
  corrects to 2/π² = 0.2026 exactly).
- **Superseded (dated notes, no silent edits):** the κ log-fit line of the D2 progress
  note §2; P1's log target; the D2 proof goal is now κ_j ≤ C·j^{1/3} upper bound + a
  caustic lower bound (Olver/Airy at the turning point, σ-calculus remainders).

## What it changes for the menu

- Finite-range items (C1–C3 certification lane): **no change.**
- M-lane: P1-flavored items should be read with the j^{1/3} target. The chain's known
  H-ROT gap is unchanged in kind (raw Abel was already insufficient under log); the one
  genuinely NEW quantified question, added to your menu: **does the windowed-S /
  oscillation-scale pairing tolerate j^{1/3} row constants?**
  **[ANSWERED same day, (F11): YES — two independent mechanisms, measured in the model
  AND on the frozen production kernels.** (1) *Localization:* the j^{1/3} partial-sum
  mass is the (F10) caustic dip; the explicit majorant Ψ_j = min(1.10κ_j, 1 +
  0.50μ^{1/3}|ŝ|^{−1/2}) holds pointwise, so pairing costs the field's LOCAL variation
  at the dip: equidistributed-TV fields pay 0.66·TV constant in j; oscillating (S-like)
  fields ≤ 0.014·TV. Sharp: a step at m* pays exactly E_j — the condition is on the
  field, not the kernels. (2) *Runaway:* your actual dx has TV density ~ n^{−3/2} while
  the dip sits at n* ≈ 0.64j and moves away with j: κ_j·TV_window peaks at 0.054
  (j ≈ 10, where κ = O(1)) and falls two orders by j = 139. On the actual drop-4 field:
  TRUE sup|dα| = 0.0106, profile-pairing budget 0.0622 (no j^{1/3} anywhere), raw Abel
  0.2847. H-ROT closes to ~4.5× of truth by explicit accounting; the rest is in-window
  sign cancellation. **What remains for the menu is sharper: prove the FIELD-side
  TV-density bound for quantile-class dx** (TV over the moving μ^{1/3}-window ≲
  TV·μ^{1/3}n*^{−3/2}-class; measured 0.038·TV at j = 80 falling to 0.008) — S enters
  through certified windowed averages exactly as your LEMMA-§8 statement anticipated;
  the kernel side is now theorem-grade.]

## Where to look (in the updated folder)

Ledger §9 (master, seven dated entries for 2026-07-19) → `D2_progress_…md` §7, blocks
(F5)–(F10) (σ-calculus; localization; κ-protocol resolution; certified ladder; the
derivation (F9); **the theorem — start here: (F10)**) → `CONSUMER_CHECK_j13_2026-07-19.md`
(per-consumer verdicts) → scripts + logs per the §8 manifest (`t2_d2_olver_profile.py` is
the derivation certificate; `t2_d2_lemma_La.py`/`t2_d2_lemma_Lb.py` the lemma
certificates; `t2_d2_law_decision.py` the out-of-sample refutation;
`t2_d2_kappa_full_ladder.csv` the authoritative table).

*Grades: profile/derivation float64 on certified-rational rows (mp ≤ 2e−13, ktop ≤ 2e−14,
Richardson 3-pt), Φ_∞ verified 8.0e−5; a_∞ exact closed form; law tested over seven
octaves + one out-of-sample point; σ-calculus exact rational; production refit float64 on
the frozen certified kernels. Drafted for the next folder send; no SHA until it ships.*
