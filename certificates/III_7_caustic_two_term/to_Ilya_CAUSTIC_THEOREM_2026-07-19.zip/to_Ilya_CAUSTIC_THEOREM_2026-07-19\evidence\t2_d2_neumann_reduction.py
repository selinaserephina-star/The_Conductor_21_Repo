# t2_d2_neumann_reduction.py — D2 zone (ii), estimate block: the Neumann reduction of the
# Y-content, the doubled-string Dirichlet kernel, and the first reconstruction of the
# zone-(ii) kernel function F_j(tau).
#
#  (N0) half-integer reflection: Y_{2j+1/2} = -J_{-(2j+1/2)}  (sanity)
#  (N1) Sig_nu = (4(nu+1)/z) J_{nu+1}Y_nu - 2 J_nu Y_nu - 4(nu+1)/(pi z^2)   (exact)
#  (N2) the elementary -4(nu+1)/(pi z^2) parts cancel AGAIN in the j-telescope:
#       Sig_mu/(2(mu+1)) - Sig_{mu-2}/(2(mu-1)) = [(2/z)J_{mu+1}Y_mu - J_mu Y_mu/(mu+1)]
#                                               - [(2/z)J_{mu-1}Y_{mu-2} - J_{mu-2}Y_{mu-2}/(mu-1)]
#  (N3) Neumann representations with FIXED low-order kernels (j-dependence only in the
#       cosine frequency; valid since the order sums are 1 and 0 > -1):
#         J_{nu+1}(z) Y_nu(z) = -(2/pi) int_0^{pi/2} J_1(2z cos t) cos((2nu+1)t) dt
#         J_nu(z)   Y_nu(z) = -(2/pi) int_0^{pi/2} J_0(2z cos t) cos(2nu t) dt
#  (N4) doubled-string Dirichlet kernel: sum_{n<=m} cos(z_n tau) = sin(m pi tau)/(2 sin(pi tau/2))
#  (F)  reconstruct F_j(tau) := sum_n z_n^2 dW_j(z_n) cos(z_n tau) on (0,2): antisymmetry
#       about tau = 1, continuity, and a polynomial-shape probe (the "Gtilde = 1 moment"
#       candidate for zone (ii)).
import os
import numpy as np
from scipy.special import jv, yv
from scipy.integrate import quad

HERE = os.path.dirname(os.path.abspath(__file__))
rng = np.random.default_rng(7)

print("=== (N0) half-integer reflection Y_nu = -J_(-nu), nu = 2j+1/2 ===")
worst = 0.0
for j in [1, 3, 8]:
    nu = 2 * j + 0.5
    for z in rng.uniform(nu, 8 * nu, 3):
        worst = max(worst, abs(yv(nu, z) + jv(-nu, z)))
print(f"  max abs dev: {worst:.2e}")

print("=== (N1)+(N2) second elementary cancellation ===")
worst1 = worst2 = 0.0
for j in [2, 5, 11]:
    mu = 2 * j + 0.5
    for z in rng.uniform(2 * mu, 25 * mu, 4):
        for nu in (mu, mu - 2):
            lhs = jv(nu + 2, z) * yv(nu, z) + jv(nu, z) * yv(nu + 2, z)
            rhs = (4 * (nu + 1) / z) * jv(nu + 1, z) * yv(nu, z) - 2 * jv(nu, z) * yv(nu, z) - 4 * (nu + 1) / (np.pi * z * z)
            worst1 = max(worst1, abs(lhs - rhs))
        lhs2 = ((jv(mu + 2, z) * yv(mu, z) + jv(mu, z) * yv(mu + 2, z)) / (2 * (mu + 1))
                - (jv(mu, z) * yv(mu - 2, z) + jv(mu - 2, z) * yv(mu, z)) / (2 * (mu - 1)))
        rhs2 = (((2 / z) * jv(mu + 1, z) * yv(mu, z) - jv(mu, z) * yv(mu, z) / (mu + 1))
                - ((2 / z) * jv(mu - 1, z) * yv(mu - 2, z) - jv(mu - 2, z) * yv(mu - 2, z) / (mu - 1)))
        worst2 = max(worst2, abs(lhs2 - rhs2))
print(f"  (N1) max dev: {worst1:.2e};  (N2) telescope form max dev: {worst2:.2e}")

print("=== (N3) Neumann reps with fixed J_0/J_1 kernels ===")
worst = 0.0
for j in [1, 3, 7]:
    nu = 2 * j + 0.5
    for z in rng.uniform(1.5 * nu, 6 * nu, 2):
        lhs1 = jv(nu + 1, z) * yv(nu, z)
        v1, _ = quad(lambda t: jv(1, 2 * z * np.cos(t)) * np.cos((2 * nu + 1) * t), 0, np.pi / 2, limit=800)
        lhs0 = jv(nu, z) * yv(nu, z)
        v0, _ = quad(lambda t: jv(0, 2 * z * np.cos(t)) * np.cos(2 * nu * t), 0, np.pi / 2, limit=800)
        worst = max(worst, abs(lhs1 + (2 / np.pi) * v1), abs(lhs0 + (2 / np.pi) * v0))
print(f"  max abs dev: {worst:.2e}")

print("=== (N4) doubled-string Dirichlet kernel ===")
worst = 0.0
for m in [1, 3, 9, 24]:
    tau = rng.uniform(0.02, 1.98, 200)
    zn = (np.arange(1, m + 1) - 0.5) * np.pi
    lhs = np.array([np.sum(np.cos(zn * t)) for t in tau])
    rhs = np.sin(m * np.pi * tau) / (2 * np.sin(np.pi * tau / 2))
    worst = max(worst, float(np.max(np.abs(lhs - rhs))))
print(f"  max abs dev: {worst:.2e}")

print("=== (F) reconstruction of F_j(tau) = sum_n z^2 dW_j(z_n) cos(z_n tau) ===")
for j in [4, 8]:
    mu = 2 * j + 0.5
    N = 40000
    n = np.arange(1, N + 1, dtype=float)
    z = (n - 0.5) * np.pi
    with np.errstate(all='ignore'):
        dW = ((jv(mu - 1, z) - (2 * mu - 1) * jv(mu, z) / (2 * z) + yv(mu, z)) * jv(mu + 2, z) / (mu + 1)
              - (jv(mu - 3, z) - (2 * mu - 5) * jv(mu - 2, z) / (2 * z) + yv(mu - 2, z)) * jv(mu, z) / (mu - 1))
    c = z ** 2 * dW
    c[~np.isfinite(c)] = 0.0
    tail = np.sum(np.abs(c[N - 2000:]))
    tau = np.linspace(0.0, 2.0, 81)
    F = np.array([np.sum(c * np.cos(z * t)) for t in tau])
    anti = F + F[::-1]                        # F(tau) + F(2-tau) should vanish
    # polynomial probe on the antisymmetric variable u = tau - 1 (odd polynomial fit)
    u = tau - 1.0
    X = np.vstack([u, u ** 3, u ** 5, u ** 7]).T
    coef, *_ = np.linalg.lstsq(X, F, rcond=None)
    resid = F - X @ coef
    print(f"  j={j}: series tail (last 2000 |c|) = {tail:.2e}; antisymmetry max|F(t)+F(2-t)| = {np.max(np.abs(anti)):.2e}")
    print(f"        F at tau = 0.1,0.5,1.0,1.5,1.9: " + " ".join(f"{np.interp(t, tau, F):+.4f}" for t in [0.1, 0.5, 1.0, 1.5, 1.9]))
    print(f"        odd-poly fit coeffs (u,u^3,u^5,u^7): " + " ".join(f"{t:+.3f}" for t in coef)
          + f"; rel residual = {np.max(np.abs(resid))/np.max(np.abs(F)):.2e}")
    print(f"        F(0+) = {F[0]:+.4f}, F(2-) = {F[-1]:+.4f}  (boundary values for the IBP)")
print("done.")
