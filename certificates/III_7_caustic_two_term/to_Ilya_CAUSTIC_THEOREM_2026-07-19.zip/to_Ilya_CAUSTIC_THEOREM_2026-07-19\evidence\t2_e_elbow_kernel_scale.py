# t2_e_elbow_kernel_scale.py — STAGE E / G-E: derive (or refute) the w ~ 3 elbow of the
# windowed-S norm from the EXACT kernel oscillation scale at the maximizing rows.
# Eighth session of 2026-07-19. Reads the frozen K1K2 npz (never writes).
#
# The elbow question (LEMMA note §8 / window_norm_knee.py, stage 2.5/2.6-pre):
#   the S-norm lemma wants  form-bound(V) <= C * ||S||*_w,  ||S||*_w = windowed-average
#   norm over windows of w mean spacings; the octonion frame nominates w = 3; the
#   measured C_needed(w) curves knee near w ~ 3. WHY 3?
# Hypothesis under test (the (F9)/(F10) mechanism carried to small j): |dalpha_j| peaks
# at j = 2-3, and THERE the kernel's entire sign structure is the caustic — located at
# n* ~ 2j/pi ~ 1-2 atoms with Airy width mu^(1/3) ~ 1.7-1.9 atoms. Windows coarser than
# n* + width ~ 3 average ACROSS the maximizing kernel's sign structure and lose the
# form bound; windows finer lose nothing. Prediction: the pairing tolerance elbow sits
# at w* ~ 3 for j = 2-3, grows slowly (~mu^(1/3)) with j, and the FORM-bound elbow is
# the tolerance at the maximizing j. Refutation branch: if tolerance at j = 2-3 is far
# from 3, the knee belongs to S's own autocorrelation, not the kernels.
import numpy as np
from t2_d2_caustic_exponent import rows

FROZEN = r"..\T2_K1K2_kernel_bounds_2026-07-18"
d = np.load(FROZEN + r"\k1_kernels_k4_N149.npz")
Ka, x = d['Ka'], d['x']
M = Ka.shape[0]
q = np.loadtxt(FROZEN + r"\quantiles_production.csv", delimiter=",", skiprows=1)
gD, gF = q[4:, 1], q[4:, 2]          # drop-4 section
dx = 1.0 / gF ** 2 - 1.0 / gD ** 2
da = Ka @ dx

print("=== (E1) where dalpha lives, and the sign structure of those kernel rows ===")
top = np.argsort(-np.abs(da))[:4]
print(f"  |dalpha_j| top rows: " + ", ".join(f"j={t+1}: {abs(da[t]):.5f}" for t in top))
print("      j   #signchg   sign-change positions n (first 8)        |K| mass: n<=3 / n<=6 (of |K|weighted by |dx|)")
for j in [1, 2, 3, 4, 5, 10, 20, 40]:
    K = Ka[j - 1]
    sc = np.where(np.diff(np.sign(K[K != 0])) != 0)[0]
    idx = np.arange(1, M + 1)[K != 0]
    pos = idx[sc]
    kw = np.abs(K * dx)
    print(f"  {j:5d}   {len(pos):5d}     {str(pos[:8]):40s}  {np.sum(kw[:3])/np.sum(kw):5.2f} / {np.sum(kw[:6])/np.sum(kw):5.2f}")

print("=== (E2) model closed form at j = 2,3,4,6: the caustic IS the sign structure ===")
for j in [2, 3, 4, 6]:      # rows() needs order 2j-3 >= 0, so j >= 2
    mu = 2 * j + 0.5
    z, c, K = rows(j, 60)
    sc = np.where(np.diff(np.sign(K)) != 0)[0] + 1
    print(f"  j = {j}: mu = {mu};  n* = 2j/pi = {2*j/np.pi:.2f};  Airy width mu^(1/3) = "
          f"{mu**(1/3):.2f};  model-row sign changes at n = {sc[:6]}"
          f"  (predicted scale n* + width = {2*j/np.pi + mu**(1/3):.1f})")

print("=== (E3) the operational tolerance curve: pairing error vs window width ===")
# replace dx by its w-window BLOCK average; err_j(w) = |K.(dx - dx_w)| / |K.dx|
# the w where err reaches 50% is the kernel row's tolerance scale w*_j.
def block_avg(v, w):
    out = np.empty_like(v)
    for s in range(0, len(v), w):
        out[s:s + w] = np.mean(v[s:s + w])
    return out
WS = [1, 2, 3, 4, 5, 6, 8, 10, 14, 20]
print("      j   |K.dx|      err(w)/|K.dx| for w = " + str(WS) + "   -> w*(50%)")
for j in [2, 3, 5, 10, 20, 40]:
    K = Ka[j - 1]
    base = abs(float(K @ dx))
    errs = []
    for w in WS:
        e = abs(float(K @ (dx - block_avg(dx, w)))) / base
        errs.append(e)
    wstar = next((w for w, e in zip(WS, errs) if e >= 0.5), np.inf)
    print(f"  {j:5d}  {base:.6f}   " + " ".join(f"{e:5.2f}" for e in errs) + f"      w* = {wstar}")
print("  [w* at the MAXIMIZING rows j = 2-3 is the derived elbow of the form bound]")

print("=== (E4) same tolerance in the pencil aggregate + the frozen knee curves ===")
# aggregate over rows with the |dalpha| weighting the form bound actually sees:
base_rows = np.abs(da)
agg = []
for w in WS:
    dxa = block_avg(dx, w)
    agg.append(np.max(np.abs(Ka @ (dx - dxa))) / np.max(base_rows))
print("  sup_j|K.(dx - dx_w)| / sup_j|K.dx|: " + " ".join(f"w={w}: {a:4.2f}" for w, a in zip(WS, agg)))
knee = np.loadtxt(r"..\T2_pin_conjecture_2026-07-17\window_knee_production.csv",
                  delimiter=",", skiprows=1)
d0 = knee[knee[:, 0] == 0]
print("  frozen empirical C_needed(w), drop-0: " +
      " ".join(f"w={r[1]:.1f}: {r[3]:.2f}" for r in d0))
slopes = np.diff(d0[:, 3]) / np.diff(d0[:, 1])
i = int(np.argmax(slopes))
print(f"  max slope of C_needed between w = {d0[i,1]:.1f} and {d0[i+1,1]:.1f}"
      f"  (the empirical knee interval)")
print("done.")
