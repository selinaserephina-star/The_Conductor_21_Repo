# t2_f_field_tv_density.py — the FIELD-SIDE TV-density bound, numerics staged (the (F11)
# retarget; ninth session of 2026-07-19). Production quantiles + actual Euler-product S_P;
# frozen folders read-only; zeros used nowhere.
#
# Claim to stage: for quantile-class transport fields dx_n = u_n S(gamma_n),
# u_n = 2/(gamma_n^3 rho_n) > 0 smooth decreasing, the local TV density
# tau(n) := |dx_{n+1} - dx_n| obeys tau(n) <= C_geo * u_n * (|DS| + (q/n)|S|)  with
# u_n ~ n^(-q) geometric (provable from rho increasing — the IB-lane classical part) and
# the S-part bounded by certified data. Composed over the moving caustic window
# W_j (hw = 3 mu^(1/3) at n* = 2j/pi):  TV_{W_j}(dx) <= C * mu^(1/3) * n*^(-p) * ||field||
# — the lemma that makes the (F11) runaway a theorem. Here we MEASURE p, the split, the
# composed law, and the actual ||S||*_3 value the certified machinery must bound.
import os, sys
import numpy as np
import mpmath as mp

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'T3_twin_skeleton_2026-07-17'))
from operator_skeleton_hdv import theta, build_prime_data

FROZEN = os.path.join(HERE, '..', 'T2_K1K2_kernel_bounds_2026-07-18')
q = np.loadtxt(os.path.join(FROZEN, 'quantiles_production.csv'), delimiter=",", skiprows=1)
gD_full, gF_full = q[:, 1], q[:, 2]
K4 = 4
gD, gF = gD_full[K4:], gF_full[K4:]           # drop-4 section, 145 atoms (matches Ka)
M = len(gD)
dx = 1.0 / gF ** 2 - 1.0 / gD ** 2
TV = float(np.sum(np.abs(np.diff(dx))))

print("=== (T0) rebuild the S-side from the Euler product (P = 2e5, production spec) ===")
S_P, nterms = build_prime_data(200000)
print(f"  {nterms} prime-power terms")
S = np.array([S_P(g) for g in gD])
mp.mp.dps = 30
rho = np.array([float(mp.diff(theta, mp.mpf(g)) / mp.pi) for g in gD])
u = 2.0 / (gD ** 3 * rho)

print("=== (T1) linearization check: dx_n vs u_n * S_n (stage-2.5 revisited on the section) ===")
dg = gF - gD
lin_g = np.abs(dg + S / rho)
pred = -u * S                                  # dgamma = -S/rho => dx ~ -2 g^-3 dg = +... sign check below
r1 = np.abs(dx - pred) / np.maximum(np.abs(dx), 1e-12)
r1b = np.abs(dx + pred) / np.maximum(np.abs(dx), 1e-12)
sgn = '+' if np.median(r1) < np.median(r1b) else '-'
rr = r1 if sgn == '+' else r1b
print(f"  max|dgamma + S/rho| = {lin_g.max():.2e} (mean {lin_g.mean():.2e})")
print(f"  dx = {sgn}u*S: median rel dev {np.median(rr):.3f}, 90th pct {np.percentile(rr, 90):.3f}"
      f"  (nonlinearity + S-evaluation at shifted vs base quantile)")

print("=== (T2) the TV-density profile tau(n) and its split ===")
tau = np.abs(np.diff(dx))
n = np.arange(1, M, dtype=float)               # section index of the left atom
# fit tau ~ c n^-p on the bulk (exclude first 3 and last 5)
sel = (n >= 4) & (n <= M - 6) & (tau > 0)
A = np.column_stack([np.ones(sel.sum()), np.log(n[sel])])
coef, *_ = np.linalg.lstsq(A, np.log(tau[sel]), rcond=None)
p_fit = -coef[1]
# upper envelope exponent: the lemma needs a majorant, fit on block maxima
blocks = [(s, min(s + 12, int(n[sel].max()))) for s in range(4, M - 6, 12)]
bx, by = [], []
for lo, hi in blocks:
    m_ = (n >= lo) & (n < hi) & (tau > 0)
    if m_.sum():
        bx.append(np.log(np.mean(n[m_]))); by.append(np.log(np.max(tau[m_])))
ce, *_ = np.linalg.lstsq(np.column_stack([np.ones(len(bx)), bx]), np.array(by), rcond=None)
p_env = -ce[1]
# split: tau <= |Du|*|S| + u*|DS| (+ curvature crumbs)
geo = np.abs(np.diff(u)) * np.abs(S[:-1])
Spart = u[1:] * np.abs(np.diff(S))
# u's own exponent
cu, *_ = np.linalg.lstsq(np.column_stack([np.ones(M), np.log(np.arange(1, M + 1, dtype=float))]),
                         np.log(u), rcond=None)
q_u = -cu[1]
print(f"  tau exponent: LSQ p = {p_fit:.2f}; block-maxima envelope p_env = {p_env:.2f};"
      f"  u-profile exponent q = {q_u:.2f}")
print(f"  split totals: sum|Du||S| = {np.sum(geo):.5f}  vs  sum u|DS| = {np.sum(Spart):.5f}"
      f"  (TV = {TV:.5f})  ->  the S-part {'DOMINATES' if np.sum(Spart) > np.sum(geo) else 'is subdominant'}")
print(f"  per-spacing S variation: sup|DS| = {np.max(np.abs(np.diff(S))):.3f},"
      f"  mean|DS| = {np.mean(np.abs(np.diff(S))):.3f};  sup|S| = {np.max(np.abs(S)):.3f}")

print("=== (T3) the composed moving-window law: TV_Wj <= C * mu^(1/3) n*^(-p) * TV ===")
print("      j    n*   hw    TV_Wj/TV    law c*mu^(1/3)n*^(-p)/  ratio     windowterm 1.1 a mu^(1/3) TV_Wj")
A_INF = 0.346555372
rats = []
rows_out = []
for j in [5, 10, 20, 40, 80, 120, 139]:
    mu_ = 2 * j + 0.5
    nstar = max(1, int(round(2 * j / np.pi)))
    hw = max(2, int(round(3 * mu_ ** (1 / 3))))
    lo, hi = max(nstar - hw, 1), min(nstar + hw, M - 1)
    tvw = float(np.sum(tau[lo - 1:hi]))
    law = mu_ ** (1 / 3) * nstar ** (-p_fit)
    rats.append(tvw / TV / law)
    wterm = 1.10 * A_INF * mu_ ** (1 / 3) * tvw
    rows_out.append((j, nstar, hw, tvw / TV, law, tvw / TV / law, wterm))
C_law = max(rats)
for j, nstar, hw, tvfrac, law, rat, wterm in rows_out:
    print(f"  {j:5d}  {nstar:4d}  {hw:3d}   {tvfrac:8.4f}    {law:8.4f}       {rat:6.3f}     {wterm:9.6f}")
print(f"  law constant C = sup ratio = {C_law:.3f}  =>  TV_Wj <= {C_law:.2f} * mu^(1/3) n*^(-{p_fit:.2f}) * TV")
print(f"  window term decays like j^(2/3 - p) = j^({2/3 - p_fit:.2f}) — SUMMABLE/uniform"
      f"  (needs p > 2/3: {'YES' if p_fit > 2/3 else 'NO'})")

print("=== (T4) the certified-side ingredient: ||S||*_3 on production (the G-E norm) ===")
w = 3
sig_avgs = [abs(np.mean(S[s:s + w])) for s in range(0, M - w + 1)]
abs_avgs = [np.mean(np.abs(S[s:s + w])) for s in range(0, M - w + 1)]
print(f"  ||S||*_3 (signed, the derived norm) = {max(sig_avgs):.4f}   at window start n = "
      f"{int(np.argmax(sig_avgs))+1}")
print(f"  A_3 (abs-average proxy, knee-script norm) = {max(abs_avgs):.4f}   "
      f"(signed/abs ratio {max(sig_avgs)/max(abs_avgs):.2f})")
print(f"  [these are the two numbers the Turing/PZ certified machinery must bound;")
print(f"   S here is the pure Euler-product S_P at P = 2e5 — production spec, no zeros]")
print("done.")
