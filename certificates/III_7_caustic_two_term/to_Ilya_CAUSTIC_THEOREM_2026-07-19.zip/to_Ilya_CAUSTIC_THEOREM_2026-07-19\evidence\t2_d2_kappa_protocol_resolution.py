# t2_d2_kappa_protocol_resolution.py — resolve the OPEN FLAG of the sigma-calculus session.
#
# FINDING: sec-2's kappa (t2_d2_bessel_kernels.py block D) is max(sup_fwd, sup_rev) with
#   sup_rev = sup_m |1 - ps_{m-1}|  (tail-sum branch via row-sum = 1, initialized at 1.0),
# while the flag-raising reconstruction measured only sup_fwd = sup_m |ps_m|. The forward
# branches agree exactly (1.0414 at j=4, identical m*), so NEITHER scan was wrong — the
# flag was a definition mismatch. Here: rerun max(fwd, rev) on tonight's verified rows
# (rational A/B + mp-patched deep-zone rows), chunked; reproduce the CSV at j <= 192 and
# extend to j = 512 to test whether the 0.386 + 0.382 log(2+j) fit is asymptotic.
import numpy as np
import mpmath as mp

CH = 40000

def kappa_scan(j):
    mu = 2 * j + 0.5
    cap = int(max(2 * mu * mu / np.pi, 4000))
    kmax = 2 * j + 2
    zstar = 3.0 * kmax + 20.0
    ps_run = 0.0
    sup_fwd = 0.0; sup_rev = 1.0
    mstar_f = 1
    lo = 1
    npatched = 0
    from scipy.special import jv, yv
    while lo <= cap:
        hi = min(lo + CH - 1, cap)
        n = np.arange(lo, hi + 1, dtype=float)
        z = (n - 0.5) * np.pi
        eps = (-1.0) ** (n + 1)
        A = [np.ones_like(z), 1.0 / z]
        B = [np.zeros_like(z), np.ones_like(z)]
        for k in range(1, kmax):
            A.append(((2 * k + 1) / z) * A[k] - A[k - 1])
            B.append(((2 * k + 1) / z) * B[k] - B[k - 1])
        sm = z < zstar
        if np.any(sm):
            zs = z[sm]; pref = np.sqrt(np.pi * zs / 2.0) * eps[sm]
            with np.errstate(all='ignore'):
                for k in range(kmax + 1):
                    A[k][sm] = pref * jv(k + 0.5, zs)
                    B[k][sm] = -pref * yv(k + 0.5, zs)
        with np.errstate(all='ignore'):
            GJJ = ((2 * z / np.pi) * (A[2*j-1] * A[2*j+2] / (mu + 1) - A[2*j-3] * A[2*j] / (mu - 1))
                   - (1 / np.pi) * ((2*mu - 1) * A[2*j] * A[2*j+2] / (mu + 1)
                                    - (2*mu - 5) * A[2*j-2] * A[2*j] / (mu - 1)))
            GY = (-(4 / np.pi) * A[2*j+1] * B[2*j] + (2 * z / np.pi) * A[2*j] * B[2*j] / (mu + 1)
                  + (4 / np.pi) * A[2*j-1] * B[2*j-2] - (2 * z / np.pi) * A[2*j-2] * B[2*j-2] / (mu - 1))
            proj = (4 * mu / z ** 2) * A[2*j] ** 2
            K = proj - (np.pi / 2) * (GJJ + GY)
        bad = np.where(~np.isfinite(K))[0]
        if len(bad):                      # deep zone (i): patch with mpmath truth
            mp.mp.dps = 30
            npatched += len(bad)
            for i in bad:
                i = int(i)
                zz = mp.mpf(2 * (lo + i) - 1) * mp.pi / 2
                J = lambda kk: mp.besselj(kk + mp.mpf(1)/2, zz); Y = lambda kk: mp.bessely(kk + mp.mpf(1)/2, zz)
                dW = ((J(2*j-1) - (2*mu-1)*J(2*j)/(2*zz) + Y(2*j)) * J(2*j+2) / (mu+1)
                      - (J(2*j-3) - (2*mu-5)*J(2*j-2)/(2*zz) + Y(2*j-2)) * J(2*j) / (mu-1))
                pr = 2 * mp.pi * mu * J(2*j)**2 / zz
                K[i] = float(pr - (mp.pi / 2) * zz**2 * dW)
        ps = ps_run + np.cumsum(K)
        i1 = int(np.argmax(np.abs(ps)))
        if abs(ps[i1]) > sup_fwd:
            sup_fwd = float(abs(ps[i1])); mstar_f = lo + i1
        rev = np.abs(1.0 - np.concatenate([[ps_run], ps[:-1]]))
        sup_rev = max(sup_rev, float(np.max(rev)))
        ps_run = float(ps[-1])
        lo = hi + 1
    return max(sup_fwd, sup_rev), sup_fwd, sup_rev, mstar_f, ps_run, npatched

CSV = {8: 1.1775044650866837, 16: 1.3359798836918013, 32: 1.53912320756528,
       64: 1.9088587014230043, 128: 2.2741835641142716, 192: 2.6403354907190546}
print("   j    kappa=max(f,r)   CSV(sec-2)   fwd       rev       m*_f   rowsum    fit")
res = []
for j in [8, 16, 32, 64, 128, 192, 256, 384, 512]:
    kap, f, r, ms, rs, npat = kappa_scan(j)
    fit = 0.386 + 0.382 * np.log(2 + j)
    ref = CSV.get(j)
    res.append((j, kap))
    print(f"{j:5d}   {kap:9.4f}      {ref if ref is not None else float('nan'):9.4f}  {f:8.4f}  {r:8.4f}   {ms:6d}  {rs:8.5f}  {fit:.4f}")
js = np.array([r0 for r0, _ in res], dtype=float)
kk = np.array([k for _, k in res])
X = np.vstack([np.ones_like(js), np.log(2 + js)]).T
cf, *_ = np.linalg.lstsq(X, kk, rcond=None)
print(f"refit over j = 8..512: kappa = {cf[0]:+.3f} + {cf[1]:.3f} log(2+j); max resid {np.max(np.abs(kk - X@cf)):.3f}")
