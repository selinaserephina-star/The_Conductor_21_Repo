# diag 2: TU-Laurent vs AA-Laurent of the JJ half, as EXACT polynomials; who matches truth?
from fractions import Fraction
import numpy as np, sympy as sp, mpmath as mp
from t2_d2_common import phi_poly
from t2_d2_sigma_calculus import TU_laurent, AB_exact, dmul, dlin

j = 4
s = sp.Symbol('s'); mus = sp.Rational(4 * j + 1, 2)
Psi_s = sp.expand(phi_poly(2*j-1, 2*j+2, s) / (mus + 1) - phi_poly(2*j-3, 2*j, s) / (mus - 1))
Psi_c = sp.expand((2*mus-1) * phi_poly(2*j, 2*j+2, s) / (mus + 1)
                  - (2*mus-5) * phi_poly(2*j-2, 2*j, s) / (mus - 1))
gJJ_TU = dlin((Fraction(1), TU_laurent(Psi_s, s, 'T'), 0),
              (Fraction(1, 2), TU_laurent(Psi_c, s, 'U'), 0))

A, B = AB_exact(2 * j + 2)
# Casoratian assert on the exact dicts: A_{k+1}B_k - A_k B_{k+1} = -1 identically
for k in range(0, 2 * j + 2):
    cas = dlin((Fraction(1), dmul(A[k + 1], B[k]), 0), (Fraction(-1), dmul(A[k], B[k + 1]), 0))
    assert cas == {0: Fraction(-1)}, f"Casoratian fails at k={k}: {cas}"
print("Casoratian A_(k+1)B_k - A_k B_(k+1) = -1: EXACT for all k <= 2j+1  [assert passed]")

mp1 = Fraction(4 * j + 3, 2); mm1 = Fraction(4 * j - 1, 2)
mu_f = Fraction(4 * j + 1, 2)
gJJ_AA = dlin(
    (Fraction(2) / mp1, dmul(A[2*j-1], A[2*j+2]), -1),
    (Fraction(-2) / mm1, dmul(A[2*j-3], A[2*j]), -1),
    (-(2 * mu_f - 1) / mp1, dmul(A[2*j], A[2*j+2]), 0),
    ((2 * mu_f - 5) / mm1, dmul(A[2*j-2], A[2*j]), 0))

diff = dlin((Fraction(1), gJJ_TU, 0), (Fraction(-1), gJJ_AA, 0))
print("TU-minus-AA exact difference dict {x-power: coeff (float)}:")
for p in sorted(diff):
    print(f"   x^{p}: {float(diff[p]):+.6e}  ({diff[p]})")

# who matches mp-truth at n = 1?
mp.mp.dps = 60
mu = 2 * j + 0.5
zz = mp.pi / 2
J = lambda k: mp.besselj(k + mp.mpf(1)/2, zz)
true = mp.pi * (zz**2 * (J(2*j-1)*J(2*j+2)/(mu+1) - J(2*j-3)*J(2*j)/(mu-1))
                - (zz/2) * ((2*mu-1)*J(2*j)*J(2*j+2)/(mu+1) - (2*mu-5)*J(2*j-2)*J(2*j)/(mu-1)))
ev = lambda d: sum(mp.mpf(c.numerator) / c.denominator * zz ** (-p) for p, c in d.items())
print(f"n=1: truth {float(true):+.6e}   TU {float(ev(gJJ_TU)):+.6e}   AA {float(ev(gJJ_AA)):+.6e}")
# and mp.quad of the Z1-assembled integral H(z1): does H equal truth at z1?
fs = sp.lambdify(s, Psi_s, 'mpmath'); fc = sp.lambdify(s, Psi_c, 'mpmath')
H = (zz**3 * mp.quad(lambda t: fs(t) * mp.sin(zz * t), [0, 1, 2])
     + zz**2 / 2 * mp.quad(lambda t: fc(t) * mp.cos(zz * t), [0, 1, 2]))
print(f"n=1: Z1-integral H(z1) = {float(H):+.6e}")
