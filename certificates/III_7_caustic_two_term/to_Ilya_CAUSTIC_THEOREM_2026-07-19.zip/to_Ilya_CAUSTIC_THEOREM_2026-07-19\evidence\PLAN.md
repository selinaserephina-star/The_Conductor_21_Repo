# T2/P1 completion — execution plan (post-K1K2/P1 packages)

**Merkabit · Stenberg + Claude · 2026-07-19.** Continuation folder for everything after
`T2_K1K2_kernel_bounds_2026-07-18/` (frozen) and the two sent packages
(`to_Ilya_operator_program_2026-07-18`, SHA 16cd0374…521944;
`to_Ilya_K1K2_P1_program_2026-07-18`, SHA 3b17a4f0…bb9cf — both FROZEN).
Each stage has a GATE, an ACTION, a DELIVERABLE. Standing rules at the end. Not RH/GRH.

State inherited: kernel closed forms proven (uniform weights); spectral reduction R1/R2;
Chebyshev model solved (R3); string identification + companion exactly solved (B1/B2);
**Theorem D1**: (P1a)-companion proven, sup_m(1+i)|ĉ^L_i| ≤ 1.263 (true 0.783).
K1-companion = D1 + (P1b); K1-uniform additionally needs the weight transfer.

---

## Stage D2 — (P1b) for the companion   [GATE: none — READY; this session]
Target: **Theorem D2**: W_j = Σ_i |ĥ_i^{(j)}|/(1+i) ≤ c₀ + c₁ log(2+j) for the companion
system (weights w_n = 2x_n, atoms x_n = 1/z_n², z_n = (n−½)π), hence companion-K1:
κ_j ≤ 1 + a₃W_j ≤ C log j with both constants proven.
ACTION (numerics-first, the standing discipline):
1. **Theorem 1′** (general fixed weights): the kernel identity K_j^α(ν) =
   w_ν[p_j² + 2β_jp_j′p_{j+1} − 2β_{j−1}p_{j−1}′p_j](x_ν) — the uniform-weights proof never
   used uniformity; restate and VERIFY vs weighted-FD kernels before building on it.
2. Measure W_j^companion (finite-M, mp pipeline with weights): log-fit, resonance
   structure of ĥ, comparison with the uniform system's W_j.
3. Derive the string-side closed form of ĥ_i^{(j)}: products of two Bessel atom values →
   Poisson double integrals → lattice cosine sums → delta-comb collapse → Legendre
   linearization (3j-type) coefficients. Verify each identity numerically at 1e−10+.
4. Estimate: boundary-free IBP as in D1, or classical linearization asymptotics; an extra
   log factor is acceptable (program tolerates polylog).
DELIVERABLE: `D2_companion_P1b_2026-07-19.md` (theorem or honest obstruction) + scripts/logs.

**STATE (end of 2026-07-19 closed-form session): steps 1–3 DONE, step 4 zone (ii) at the
last sub-step.** Done: Theorem 1′; V1–V3; κ_j = 0.386 + 0.382·log(2+j) to j = 192; Z1–Z4;
N0–N4; **closed form of F_j derived + verified (parts 8.6e−10, TOTAL 8e−13; JJ collapse
certified EXACT in rational arithmetic)**; estimate block run: C_m = ∫F_jD_m exact (8e−8),
boundary-free IBP verified, naive-L¹ REFUTED (~j), uniform Γ_j = ∫|F|g ≈ 0.47√j, and
S_true = sup_m|C_m| = −0.174 + 0.216 log(2+j) ⇒ κ c₁ = 0.34 ≈ 0.38 ✓. The log is localized
in the m-signed pairing near m* ≈ 0.66j. **σ-calculus session (same day, later): C_m now
EXACT per m** (ρ-form; g₋₁ = g₀ = 0 and the row-sum C_∞ = 0 all exact-rational identities);
zone (iii) closes (alternating domination r ≤ 0.04); log localized AT the turning point
x = n/j = 2/π (envelope peak O(1) const-in-j; m*/j → 2/π); Y-side finite-m double-integral
rep verified (the stationary-phase object). **κ-protocol flag RESOLVED (same day, F7):
§2's κ = max(fwd, rev-tail-branch); CSV reproduced exactly; extension to j = 512 on
verified rows gives κ_j ≈ 0.46·j^{1/3} — the §2 LOG LAW IS SUPERSEDED (pre-asymptotic
fit); mechanism = Airy caustic window (width μ^{1/3}, O(1) amplitude) at n/j = 2/π.**
NEXT SESSION order: (1) consumer check — does the K1K2 tail assembly tolerate κ_j ~ j^{1/3}
(if yes retarget D2 to prove it; if no → IB discussion); (2) prove the j^{1/3} law at the
caustic (Olver/Airy + σ-calculus remainders; a lower bound refutes log-K1 definitively);
(3) zone-(iii) lemma; zone (i) Debye.

**STATE (end of 2026-07-19, caustic-profile derivation session — the fifth of the day):
zone (ii) law CLOSED FORM.** The Olver telescope gives Φ_∞(ŝ) = −4(AiBi)′(−2^{1/3}ŝ)
(verified 8.0e−5, first correction too at 0.998), hence **κ_j = 1 + E_j with
E_j = a_∞μ^{1/3} + O(1), a_∞ = 2^{2/3}3^{−5/6}/Γ(2/3)² = 0.34656 DERIVED** — no log at
all: (F8)'s √ln was refuted out-of-sample at j = 16384 (a finite-size mimic of the O(1)
constant). Caustic lower bound 0.1212μ^{1/3} − O(1) on a fixed verified window: log-K1
dead. Full-κ ladder corrected on Miller rows (384/512 were contaminated) and extended to
1024 (`t2_d2_kappa_full_ladder.csv` authoritative). NEXT SESSION order: (1) lemma (L-a)
Olver-remainder accumulation + lemma (L-b) zone-(i) Debye block (hyperbolic telescope —
warning: the u₁-order Debye terms are the leading ones after cancellation); (2)
zone-(iii) lemma write-up from (F5); (3) assemble the D2 zone-(ii) statement
(κ_j = 1 + a_∞μ^{1/3} + O(1), upper + lower) as the companion-K1/P1 replacement; sync
with IB — the side note now carries the closed-form law.

**STATE (end of 2026-07-19, zone-(ii) closure session — the sixth of the day): THE
ZONE-(ii) THEOREM CLOSES.** Lemmas (L-a)/(L-b) done ((F10); fixed split x₀ = 1/2;
two-piece envelope j-stable with 50% headroom; C_model closes in closed form −0.5770;
zone-(i) envelope 8× slack, C_b = 0.066); zone-(iii) lemma written (far partial sums
pinned ≤ 0.211, S_m = −(π/2)C_m exact). **κ_j = 1 + a_∞μ^{1/3} + R_j, −1.1 ≤ R_j ≤ 0.5
explicit (j ≥ 512); E_j ≥ 0.3466μ^{1/3} − 1.1 — log-K1 refuted at the exact constant.**
Subleading drift resolved structurally (no genuine ln μ; limit −0.934 matches measured).
Negative result: proj-drop fails beyond the caustic (theorem routes through measured
sup-at-m* + P* ≤ 0.02 instead). Stage D2 zone (ii) is DONE at theorem grade with the
finite-numeric ingredients itemized in (F10); remaining D2 sliver: none load-bearing
(R_∞ ≈ −0.357 has no closed form — recorded). Folder ready to cut into a dated send;
next real move is the consumer question (windowed-S pairing vs j^{1/3} row constants —
IB's menu) and/or the W/E/C stages per this PLAN.

**STEP-2 VERDICT (2026-07-19, `t2_d2_companion_kernels.py`): (P1b)-as-W-log is REFUTED for
the companion** — measured W_j ≈ 0.85j LINEAR (101 at j = 120, M = 128) while κ_j itself
stays log (slope 0.53, κ̂ = 5.04 ≈ uniform system). The ĥ/ĉ absolute-value assembly
destroys sign cancellation that the companion needs; the W-log-law is a uniform-weights
phenomenon (measured ≤ 5.3 there). Positives: Theorem 1′ VERIFIED (4e−7 FD floor, sum
rules 1e−15); R1 exact on the companion (1e−14); finite-M a₃ = 0.780 ≈ D1's 0.783.
**D2 RETARGETED:** bound C_j(m) = Σ_{n≤m} w_n h_j(x_n) DIRECTLY, D1-style, signs kept:
h_j at atoms is elementary (Bessel values + Bessel-derivative values), so step 3's
Poisson-product/comb machinery now serves the direct partial-sum bound, not the ĥ split.
Negative result recorded as a result: the correct general (P1b) statement is
weight-family-specific.

## Stage W — the weight transfer (M1; the hard one)   [GATE: D2 outcome helpful; Ilya may pick M1 from the menu — coordinate before deep-diving]
Target: transfer D1 (+D2) from companion weights to UNIFORM weights = full P1a (P1b) for
the model class; production measure then = log-density perturbation + finite-M lemma (M3).
ACTION, in route order:
- (b) λ-side orthogonal Laurent polynomials FIRST (cheap pattern check): in λ = 1/x the
  uniform measure IS the Lambert S-fraction system 1,3,5,7,…; compute the Laurent ladder
  numerically, look for a shifted-classical coefficient pattern; if found, chase closed
  forms (two-point Padé of tan at 0 and ∞) and rerun the D1 argument natively.
- (a) Christoffel at the CD-kernel level (rank-one-corrected kernel transfer; avoids the
  |r_i| ≈ 1.15 telescope).
- (c) direct uniform V-transform (least promising; obstruction recorded in the D1 note).
DELIVERABLE: route verdict note; if a route closes — full P1a/P1b for the model.
RISK: open-ended; timebox exploratory sessions.

## Stage E — the w ≈ 3 elbow re-derivation   [GATE: none — short session, any time]
Target: derive (or refute) the measured window-knee elbow from the exact kernels: the
sign-change spacing of Φ_j′ at the dominant rows j = 1–2, in quantile-cell units; if ≈ 3,
rewrite the Abel pairing as a signed windowed-S bound with DERIVED window w* — the precise
‖S‖* norm for the Turing/PZ machinery, feeding G4/IB.
ACTION: string-model closed-form wavelength (elementary Bessel) + production-ladder kernel
zeros (cached certified kernels in the frozen K1K2 folder; regenerate here if needed);
compare against `window_knee_production.csv`.
DELIVERABLE: `ELBOW_kernel_scale_note` — derivation or refutation; both are results.

## Stage C — certification (G2 + G3)   [LANE: Ilya (sent as C1/C2 in the K1K2/P1 package menu)]
Our side of the lane:
- Keep the certificate HYPOTHESES frozen: ladder definitions (θ/π = n−½; θ/π + S_P = n−½),
  P = 2×10⁵ term list, section definitions (N = 149, drops 1/4), target pair (0.3, 0.011).
  Any change → new dated statement, never a silent edit.
- On receipt of his certificates: verify per the standing both-ways protocol (recompute
  verdicts, hash manifests), file under a `*_received_*` folder, reply-verify note.
- If he passes on C1/C2: they return to our queue as a mechanical session (adaptive
  branch-and-bound on S_P + interval Newton for quantiles + Rump-style PSD).
DELIVERABLE (his): certified sup|S_P|, quantile enclosures, two PSD certificates, PZ c₁/c₂.

---

## Standing rules
- Verify every claimed identity/inequality numerically BEFORE building on it (caught the
  q²-conjecture, the z^{5/2} exponent, and two check-script bugs this week).
- Negative results are results — record them in `RESULTS.md` here.
- Working folder: no SHA until something ships; sent folders are frozen — continuation
  work lands HERE.
- Grades recorded per entry: float64 / mp(dps) / proven; zeros used nowhere unless stated.
