# t2_d2_sigma_calculus.py — D2 zone (ii)/(iii): the EXACT sigma-calculus of C_m.
#
# At the atoms both halves of pi*c_n = pi*z^2 dW_j(z_n) are EVEN Laurent polynomials in
# 1/z with exact rational coefficients:
#   pi*G_JJ = T[Psi_s] + U[Psi_c]/2      (per-atom IBP calculus, F2 certificate:
#       T[p] = z^2(p(0)+p(2)) - z^{-2} T[p''],  U[p] = -(p'(0)+p'(2)) - z^{-2} U[p''])
#   pi*G_Y  = -4 A_{2j+1}B_{2j} + 2z A_{2j}B_{2j}/(mu+1) + 4 A_{2j-1}B_{2j-2}
#             - 2z A_{2j-2}B_{2j-2}/(mu-1)      (Lommel polynomials, exact recurrence)
# So  pi*c_n = sum_k g_k z_n^{-2k}  (finite, k >= -1), and with
#   sigma_k(m) = sum_{n<=m} z_n^{-2k},  zeta*_k = sigma_k(inf) = (2^{2k}-1)zeta(2k)/pi^{2k},
#   rho_k(m) = zeta*_k - sigma_k(m) = pi^{-2k} zetaHurwitz(2k, m+1/2):
#   C_m = (1/pi) sum_k g_k sigma_k(m) = -(1/pi) sum_{k>=1} g_k rho_k(m).
# EXACT claims tested here, per j, in rational arithmetic:
#   (S1) g_{-1} = 0  (no z^2 term: Psi_s(0)+Psi_s(2) = 0 and the Y side has none)
#   (S2) g_0 = 0     (the constant parts of JJ and Y cancel EXACTLY — the c_inf identity)
#   (S3) sum_{k>=1} g_k (2^{2k}-1) (zeta(2k)/pi^{2k}) = 0  — the row-sum identity
#        C_inf = F_j(0+) = 0 as a PURE RATIONAL identity (zeta(2k)/pi^{2k} is rational)
#   (S4) numeric: Laurent reproduces c_n at atoms; C_m via rho-form matches direct sums
#   (S5) zone (iii): alternating domination of -(1/pi) sum g_k rho_k(m) for z_m >= 2mu^2;
#        the universal tail residual (sec 2's 0.231) = (pi/2)|C_{m_c}| ~ |g_1|/(2 pi z_m).
from fractions import Fraction
import numpy as np, sympy as sp, mpmath as mp
from t2_d2_common import G_parts, phi_poly

# ---------- exact Laurent dicts {even power p of x=1/z: Fraction}
def dmul(d1, d2):
    out = {}
    for p1, c1 in d1.items():
        for p2, c2 in d2.items():
            out[p1 + p2] = out.get(p1 + p2, Fraction(0)) + c1 * c2
    return out

def dlin(*terms):  # terms = (coeff_Fraction, dict, power_shift)
    out = {}
    for c, d, sh in terms:
        for p, v in d.items():
            out[p + sh] = out.get(p + sh, Fraction(0)) + c * v
    return {p: v for p, v in out.items() if v != 0}

def AB_exact(kmax):
    A = [{0: Fraction(1)}, {1: Fraction(1)}]
    B = [{}, {0: Fraction(1)}]
    for k in range(1, kmax):
        A.append(dlin((Fraction(2 * k + 1), A[k], 1), (Fraction(-1), A[k - 1], 0)))
        B.append(dlin((Fraction(2 * k + 1), B[k], 1), (Fraction(-1), B[k - 1], 0)))
    return A, B

def frac(r):
    """sympy rational-number expression -> Fraction, EXACTLY.
    Never nsimplify here: on unevaluated Adds it round-trips through float64 and silently
    truncates fractional parts below the 16th significant digit (cost: a phantom 14/19
    in the deep T-coefficients — the third float-trap lesson of this stage)."""
    rc = sp.cancel(sp.sympify(r))
    return Fraction(int(sp.numer(rc)), int(sp.denom(rc)))

def TU_laurent(p, s, kind):
    """T[p] or U[p] as {x-power: Fraction}; x-power 2m holds the z^{-2m} coefficient."""
    out = {}
    m = -1 if kind == 'T' else 0
    sgn = 1
    while p != 0:
        if kind == 'T':
            val = p.subs(s, 0) + p.subs(s, 2)
        else:
            dp = sp.diff(p, s)
            val = -(dp.subs(s, 0) + dp.subs(s, 2))
        if val != 0:
            out[2 * m] = out.get(2 * m, Fraction(0)) + sgn * frac(val)
        p = sp.diff(p, s, 2); m += 1; sgn *= -1
    return out

def g_total(j, tu_crosscheck=True):
    A, B = AB_exact(2 * j + 2)
    for k in range(0, 2 * j + 2):        # Casoratian: free consistency check on the rows
        cas = dlin((Fraction(1), dmul(A[k+1], B[k]), 0), (Fraction(-1), dmul(A[k], B[k+1]), 0))
        assert cas == {0: Fraction(-1)}, f"Casoratian fails at k={k}"
    mp1 = Fraction(4 * j + 3, 2); mm1 = Fraction(4 * j - 1, 2); mu_f = Fraction(4 * j + 1, 2)
    gJJ = dlin((Fraction(2) / mp1, dmul(A[2*j-1], A[2*j+2]), -1),
               (Fraction(-2) / mm1, dmul(A[2*j-3], A[2*j]), -1),
               (-(2*mu_f - 1) / mp1, dmul(A[2*j], A[2*j+2]), 0),
               ((2*mu_f - 5) / mm1, dmul(A[2*j-2], A[2*j]), 0))
    gY = dlin((Fraction(-4), dmul(A[2*j+1], B[2*j]), 0),
              (2 / mp1, dmul(A[2*j], B[2*j]), -1),
              (Fraction(4), dmul(A[2*j-1], B[2*j-2]), 0),
              (-2 / mm1, dmul(A[2*j-2], B[2*j-2]), -1))
    if tu_crosscheck:                    # TU (Z1-integral calculus) must equal AA exactly
        s = sp.Symbol('s')
        Psi_s = sp.expand(phi_poly(2*j-1, 2*j+2, s) / (sp.Rational(4*j+3, 2))
                          - phi_poly(2*j-3, 2*j, s) / (sp.Rational(4*j-1, 2)))
        Psi_c = sp.expand((4*j) * phi_poly(2*j, 2*j+2, s) / (sp.Rational(4*j+3, 2))
                          - (4*j - 4) * phi_poly(2*j-2, 2*j, s) / (sp.Rational(4*j-1, 2)))
        gJJ_TU = dlin((Fraction(1), TU_laurent(Psi_s, s, 'T'), 0),
                      (Fraction(1, 2), TU_laurent(Psi_c, s, 'U'), 0))
        assert gJJ_TU == gJJ, f"TU/AA mismatch at j={j}: {dlin((Fraction(1),gJJ_TU,0),(Fraction(-1),gJJ,0))}"
    return dlin((Fraction(1), gJJ, 0), (Fraction(1), gY, 0)), gJJ, gY

print("=== (S1)+(S2) exact cancellation of the z^2 and z^0 terms ===")
G = {}
for j in [2, 3, 4, 8]:
    g, gJJ, gY = g_total(j)
    G[j] = g
    print(f"  j={j}: g_(-1) = {g.get(-2, 0)};  g_0 = {g.get(0, 0)}   "
          f"[JJ const {float(gJJ.get(0,0)):+.6f}, Y const {float(gY.get(0,0)):+.6f}]; "
          f"powers k = 1..{max(g) // 2}")

print("=== (S3) row-sum identity C_inf = 0 as an EXACT RATIONAL identity ===")
for j in [2, 3, 4, 8]:
    tot = Fraction(0)
    for p, c in G[j].items():
        k = p // 2
        if k >= 1:
            q = frac(sp.zeta(2 * k) / sp.pi ** (2 * k))   # rational
            tot += c * (2 ** (2 * k) - 1) * q
    print(f"  j={j}: sum_k g_k (2^2k - 1) zeta(2k)/pi^2k = {tot}")

print("=== (S4) numeric closure: Laurent -> c_n and C_m(rho-form) vs direct sums ===")
mp.mp.dps = 60
for j in [4, 8]:
    g = G[j]
    z, GJJ, GY = G_parts(j, 400)
    c = GJJ + GY
    worst_c = 0.0
    for n in [1, 3, 10, 40, 200, 400]:
        zz = mp.mpf(2 * n - 1) * mp.pi / 2
        val = sum(mp.mpf(cc.numerator) / cc.denominator * zz ** (-p) for p, cc in g.items()) / mp.pi
        worst_c = max(worst_c, abs(float(val) - c[n - 1]))
    worst_C = 0.0
    cs = np.cumsum(c)
    for m in [3, 10, 30, 100, 300]:
        Cm = -sum((mp.mpf(cc.numerator) / cc.denominator) * mp.pi ** (-(p)) *
                  mp.zeta(p, m + mp.mpf(1) / 2) for p, cc in g.items() if p >= 2) / mp.pi
        worst_C = max(worst_C, abs(float(Cm) - cs[m - 1]))
    print(f"  j={j}: max |Laurent - c_n| = {worst_c:.2e};  max |C_m(rho) - direct| = {worst_C:.2e}")

print("=== (S5) zone (iii): alternating domination beyond z = 2 mu^2; the universal tail ===")
print("   j    m_c     r = |sum_(k>=2)|/|g1 rho1|    (pi/2)|C_mc|    g1/mu^2")
for j in [2, 3, 4, 8]:
    g = G[j]; mu = 2 * j + 0.5
    m_c = int(np.ceil(2 * mu * mu / np.pi + 0.5))
    g1 = g.get(2, Fraction(0))
    lead = (mp.mpf(g1.numerator) / g1.denominator) * mp.pi ** (-2) * mp.zeta(2, m_c + mp.mpf(1) / 2)
    rest = sum((mp.mpf(cc.numerator) / cc.denominator) * mp.pi ** (-p) *
               mp.zeta(p, m_c + mp.mpf(1) / 2) for p, cc in g.items() if p >= 4)
    Cmc = -(lead + rest) / mp.pi
    print(f"  {j:4d}  {m_c:5d}        {abs(float(rest / lead)):.4f}                 "
          f"{float(mp.pi / 2 * abs(Cmc)):.4f}        {float(g1) / mu**2:+.4f}")
print("done.")
