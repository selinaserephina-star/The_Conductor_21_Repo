# diagnostic c: N-dependence of lattice F_JJ at edge tau for j=8; large-n asymptotics of G_JJ
import numpy as np
from t2_d2_Fj_closed_form import G_parts, tapered_sum, FJJ_maker

j = 8
FJJ, _, _ = FJJ_maker(j)
for tau in [0.1, 1.8]:
    print(f"tau={tau}: closed = {FJJ(tau):+.10e}")
    for N in [120000, 240000, 480000, 960000]:
        z, GJJ, GY = G_parts(j, N)
        v = tapered_sum(GJJ, z, [tau], N)[0]
        print(f"  N={N:7d}: lattice = {v:+.10e}   (closed-lattice = {FJJ(tau)-v:+.3e})")
# large-n behavior of G_JJ and G_Y: fit c_inf + c1/z + c2/z^2 on tail
z, GJJ, GY = G_parts(j, 960000)
for name, G in [("G_JJ", GJJ), ("G_Y", GY)]:
    zz = z[-200000:]; gg = G[-200000:]
    X = np.vstack([np.ones_like(zz), 1/zz, 1/zz**2, 1/zz**3]).T
    c, *_ = np.linalg.lstsq(X, gg, rcond=None)
    resid = np.max(np.abs(gg - X @ c))
    print(f"{name} tail fit: c_inf={c[0]:+.6e} c1={c[1]:+.3e} c2={c[2]:+.3e} c3={c[3]:+.3e} resid={resid:.1e}")
