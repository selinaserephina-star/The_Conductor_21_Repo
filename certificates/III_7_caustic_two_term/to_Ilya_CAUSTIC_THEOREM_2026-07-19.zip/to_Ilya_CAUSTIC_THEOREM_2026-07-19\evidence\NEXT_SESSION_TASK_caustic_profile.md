# NEXT SESSION TASK — the caustic profile: derive Φ(s), prove κ_j ≤ C·j^{1/3}(log j)^{1/2}

**[EXECUTED 2026-07-19, fifth session of the day — see D2 note §7 (F9). Outcome exceeded
the target: Φ_∞ = −4(AiBi)′ derived and verified at 8.0e−5; the √log of the staged
target turned out NOT to exist (refuted out-of-sample at j = 16384) — the law is
κ_j = 1 + a_∞μ^{1/3} + O(1) with a_∞ = 2^{2/3}3^{−5/6}/Γ(2/3)² derived in closed form;
caustic lower bound 0.1212μ^{1/3} − O(1) kills log-K1; full ladder corrected+extended
(`t2_d2_kappa_full_ladder.csv`). Steps 1–4 and 6 done; step 5's zone-(iii)/(i) lemmas
are the new next-session items (see PLAN state block).]**

**Stage D2, zone (ii) endgame · staged 2026-07-19 (end of the four-session day) · not RH/GRH.**

## Read first (in this order)
1. `D2_progress_bessel_kernels_2026-07-19.md` **§7, blocks (F5)–(F8)** — the closed form,
   the exact σ-calculus, the localization, and the certified ladder. (F8) is the state.
2. `RESULTS.md`, last three entries (σ-calculus / consumer check / caustic ladder).
3. `EVIDENCE_CHAIN_T2_pin.md` §9 (master ledger; five dated 2026-07-19 entries).
4. `CONSUMER_CHECK_j13_2026-07-19.md` (why j^{1/3}-class growth is program-safe).

## Established state (all committed, all verified — do not re-derive)
- Rows: c_n = z²ΔW_j(z_n) and K_j(n) = proj − (π/2)c_n are **pure-rational** via
  `t2_d2_caustic_exponent.py :: rows(j, N)` — backward-Miller A (minimal solution,
  exact norm A₀ = 1) + forward B, log-mantissa. Verified: mp ≤ 2e−13 (j ≤ 1024),
  ktop-stability ≤ 2e−14 (all j), scipy/mp 4e−16 (clean zone). USE THIS AND NOTHING ELSE
  for rows (see float-traps below).
- Exact algebra: C_m = −(1/π)Σ_{k≥1}g_kρ_k(m) with exact rational g_k
  (`t2_d2_sigma_calculus.py :: g_total(j)`); g₋₁ = g₀ = 0 and the row-sum C_∞ = 0 are
  exact-rational identities; zone (iii) alternating-dominated (r ≤ 0.04, g₁/μ² → −8/π).
- Measured law (five octaves, j = 256–8192, m*_E/j = 2/π = 0.637 at EVERY j):
  **κ_j = 1 + E_j, E_j/(j^{1/3}√ln j) = 0.131 ± 2% flat.** Pure j^{1/3} and √j rejected;
  a drifting pure power j^{0.35±0.02} not fully excluded — the derivation must decide.
- Y-side analytic handle (exact finite-m, verified): C_m^Y = (8/π²)∬g₁′(t)D_m(u) −
  (4/π²)∬Δc₀(t)D_m″(u), u = 2cos t sinφ — the stationary-phase object; caustic = its
  fold at u-extremum ↔ z sin t ≈ μ.

## The task, in order
1. **Phase-aligned collapse.** Extract the caustic profile: sample c_n against the Olver
   variable s = (z_n − μ)/μ^{1/3} with PHASE ALIGNMENT (the (F8) coarse-s table aliases
   the oscillation — interpolate c(z) through several atoms per lobe, or sample at
   lobe extrema). Deliverable: measured Φ_j(s) on s ∈ [−4, +40]; verify collapse by
   j-doubling (1024 → 4096) at 1e−2 or better; measure the envelope decay exponent of
   Φ for s → +∞ and the s-range that the excursion sum actually uses (does it grow like
   log μ? that is the √log suspect: E ≈ (μ^{1/3}/π)∫^{s_max(j)}Φ with ∫ ~ √log-growing).
2. **Derive Φ from Olver.** Uniform asymptotics J_ν(z), Y_ν(z) near z = ν (Olver/Airy:
   J_μ(μ + sμ^{1/3}·2^{−1/3}-scale) ~ (2/μ)^{1/3}Ai(−2^{1/3}s)-form, same for Y with Bi,
   orders μ−3…μ+2 = argument shifts of the SAME Airy functions by δs ∝ μ^{−1/3}·k → the
   four-product combination becomes an explicit Airy-pair polynomial in (Ai, Ai′, Bi, Bi′)
   at one point — the telescope kills the leading order (this is the E-cancellation at
   the caustic; expect Φ = c₁·(AiBi)′-type + c₂·(AiAi′)-type combinations). VERIFY against
   step 1's measured Φ at 1e−3+ before using. Numerics-first: verify every Olver expansion
   order against mp Bessel at j = 256 before assembling.
3. **The bound.** Upper: |E_j| ≤ (μ^{1/3}/π)∫|Φ| over the window + σ-calculus/zone-(iii)
   control of everything beyond + Debye for z < μ-window. Target:
   **κ_j ≤ C·j^{1/3}(log j)^{1/2}** with explicit C (measured 0.131·(4)^{1/3}-scale…
   derive, don't fit). Lower: the first fixed-sign lobe of Φ gives E_j ≥ c·j^{1/3} —
   this alone REFUTES log-K1 permanently (record as a theorem-grade negative).
4. **Correct the record.** Re-run the FULL κ ladder (max(fwd, rev), caps 2μ²/π, chunked)
   on Miller rows; correct (F7)/CSV values at j = 256–512 in a dated note line; single
   authoritative fit table. (The j ≤ 192 CSV values are clean — verified.)
5. If budget remains: zone-(iii) lemma write-up from (F5); zone (i) Debye bound.
6. Update `D2_progress` §7 (new block (F9)), `RESULTS.md`, ledger §9, PLAN state block,
   and the DRAFT IB side note (`NOTE_to_Ilya_P1_target_revision_j13_DRAFT.md`) — it must
   carry whatever the final law is before it ships.

## Float-traps of this stage (all four are live hazards for exactly this work)
1. Far-tail trig-form phase noise (§3) — use rational forms.
2. Sub-turning-point forward Lommel recurrence — A is minimal there; use backward Miller.
3. Exactness leaks through floats: mpmath-lambdify float args (s**k in float64) AND sympy
   nsimplify on unevaluated Adds — convert to mpf / cancel+numer/denom, never nsimplify.
4. **Garbage-FINITE scipy underflow rows** (jv → 0, yv huge-finite, product = junk, NO
   NaN) — never reintroduce scipy jv/yv into row evaluation; if you must, diff against
   `rows()` over the FULL range, not spots.

## Standing rules (unchanged)
Verify every identity numerically before building on it. Negative results are results —
into RESULTS.md. Sent/sealed folders are frozen. No SHA until something ships. Grades on
every entry (float64 / mp(dps) / exact-rational / proven). Check CPU contention before
debugging stalls (parallel sessions).

## Suggested opening prompt for the next context window
> Mathematical proof session — D2 zone (ii), caustic profile. Read first:
> T2_P1_completion_2026-07-19/NEXT_SESSION_TASK_caustic_profile.md, then D2_progress
> note §7 (F5)–(F8). Task: execute the task file in order — phase-aligned Φ(s) collapse,
> Olver/Airy derivation of Φ (verify 1e−3+), upper bound κ_j ≤ C·j^{1/3}(log j)^{1/2} +
> caustic lower bound, then the corrected full-κ ladder. Verify every identity before
> building on it; negative results are results; update the folder + ledger before ending.
> Not RH/GRH. Don't touch sealed to_Ilya packages.
