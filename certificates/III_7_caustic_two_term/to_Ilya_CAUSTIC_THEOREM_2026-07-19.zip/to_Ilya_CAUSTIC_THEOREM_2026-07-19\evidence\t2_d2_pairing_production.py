# t2_d2_pairing_production.py — production half of the windowed-S pairing check.
# READS the frozen K1K2 folder (never writes there). Cross-checks against the committed
# CSV numbers before measuring anything new.
#
# Objects: Ka (145 x 145 drop-4 kernel matrix, j x n), x (section atoms), and the ACTUAL
# transport field dx_n = x_fwd(n) - x_D(n) rebuilt from quantiles_production.csv
# (x = gamma^(-2), drop first 4 atoms). Expected from the frozen CSV (k=4, N=149):
# TV(dx) = 0.04879/0.0490-class, max|dx| = 0.012934, sup_j|dalpha_true| = 0.010624,
# raw Abel = 0.2320 (N=100 row) / khat_a = 5.5956 at N=149.
import numpy as np

FROZEN = r"..\T2_K1K2_kernel_bounds_2026-07-18"
d = np.load(FROZEN + r"\k1_kernels_k4_N149.npz")
Ka, x = d['Ka'], d['x']
M = Ka.shape[0]
q = np.loadtxt(FROZEN + r"\quantiles_production.csv", delimiter=",", skiprows=1)
gD, gF = q[:, 1], q[:, 2]
xD, xF = 1.0 / gD ** 2, 1.0 / gF ** 2
k = 4
xD, xF = xD[k:], xF[k:]
print("=== (X0) cross-checks vs the frozen record ===")
print(f"  section size M = {M}; atoms match npz.x: max|x - xD| = {np.max(np.abs(x - xD)):.2e}")
dx = xF - xD
TV = float(np.sum(np.abs(np.diff(dx))))
print(f"  ACTUAL field: TV(dx) = {TV:.5f} [csv 0.0488 N=100 class], max|dx| = "
      f"{np.max(np.abs(dx)):.6f} [csv 0.012934]")
da = Ka @ dx
print(f"  sup_j |dalpha_j| = |Ka dx|_inf = {np.max(np.abs(da)):.6f} [csv true 0.010624]")
PS = np.cumsum(Ka[:, ::-1], axis=1)[:, ::-1]          # tail sums PS_j(m) = sum_{n>=m} K
kappa = np.max(np.abs(PS), axis=1)
print(f"  khat = sup_j kappa_j = {np.max(kappa):.4f} [csv 5.5956];  argmax j = "
      f"{int(np.argmax(kappa))+1} of {M}")

print("=== (X1) Abel identity + the three accountings of sup_j |dalpha_j| ===")
# exact: sum_n K b_n = sum_{m<M} PS(m+1)*(-(b_{m+1}-b_m)) ... verify numerically, then:
#   raw Abel:      kappa_j * (TV + |dx_M|)
#   majorant:      <|PS_j|, |Ddx|> + |PS_j(1)*dx_1|-side terms — computed exactly
j_chk = int(np.argmax(np.abs(da)))
lhs = float(Ka[j_chk] @ dx)
rhs = float(PS[j_chk, 0] * dx[0] + np.sum(PS[j_chk, 1:] * np.diff(dx)))
print(f"  Abel identity at j = {j_chk+1}: direct {lhs:+.8f} vs PS-form {rhs:+.8f}"
      f"  (diff {abs(lhs-rhs):.1e})")
abel = kappa * (TV + np.abs(dx[-1]) + np.abs(dx[0]))
holder = np.abs(PS[:, 0] * dx[0]) + np.abs(PS[:, 1:]) @ np.abs(np.diff(dx))
print(f"  sup_j: TRUE = {np.max(np.abs(da)):.4f};  profile-pairing <|PS|,|Ddx|> = "
      f"{np.max(holder):.4f};  raw Abel = {np.max(abel):.4f}")
print(f"  -> the pairing accounting recovers a factor {np.max(abel)/np.max(holder):.1f} "
      f"of the Abel slack (truth is another {np.max(holder)/np.max(np.abs(da)):.1f}x below"
      f" — sign cancellation inside the window)")

print("=== (X2) field families on the production kernels (TV = 1) ===")
n = np.arange(1, M + 1, dtype=float)
fams = {}
fams['ramp'] = 1.0 - (n - 1) / (M - 1)
for lam in [8, 24, 72]:
    a = lam / (4.0 * M)
    fams[f'sine{lam}'] = a * np.sin(2 * np.pi * n / lam) * np.hanning(M)
print("      family    sup_j|P|/TV    (raw Abel = khat = %.2f)" % np.max(kappa))
for name, b in fams.items():
    tv = float(np.sum(np.abs(np.diff(b)))) + abs(b[-1]) + abs(b[0]) * 0  # b_1 boundary via PS(1)
    vals = np.abs(Ka @ b)
    print(f"    {name:>8s}     {np.max(vals)/tv:8.4f}")
# steps at every position: sup over j AND position = the raw kappa story (sharpness)
step_sup = 0.0
for p in range(1, M):
    b = (n <= p).astype(float)
    step_sup = max(step_sup, float(np.max(np.abs(Ka @ b))))
print(f"    step (worst position, worst j): sup|P| = {step_sup:.4f}  "
      f"[= the khat object; TV concentrated => j^(1/3)/boundary-layer bites]")

print("=== (X3) where does the ACTUAL dx put its variation? (the moving-window test) ===")
# per-j: the caustic window in production sits at n*(j) ~ (2/pi) j (bulk); measure the
# fraction of TV(dx) inside the window of half-width 3 mu^(1/3) atoms around n*(j):
fr = []
for j in range(8, M - 6):
    mu = 2 * j + 0.5
    nstar = int(round(2 * j / np.pi))
    w = max(2, int(round(3 * mu ** (1 / 3))))
    lo, hi = max(nstar - w, 1), min(nstar + w, M - 1)
    fr.append(np.sum(np.abs(np.diff(dx))[lo - 1:hi]) / TV)
fr = np.array(fr)
print(f"  TV fraction inside the moving caustic window (hw = 3 mu^(1/3)): "
      f"median {np.median(fr):.3f}, max {np.max(fr):.3f} "
      f"(uniform density would give ~{np.median([2*max(2,int(round(3*(2*j+.5)**(1/3))))/M for j in range(8,M-6)]):.3f})")
print(f"  -> concentration factor vs uniform: {np.max(fr)/(2*3*(2*70)**(1/3)/M):.2f}x max")

print("=== (X4) the runaway: per-j profile — the dangerous product kappa_j x TVfrac_j never fires ===")
print("      j   kappa_j   TVfrac(window)   kappa*TVfrac*TV   <|PS|,|Ddx|>   |dalpha_j| true")
for j in [2, 5, 10, 20, 40, 80, 120, 139]:
    mu = 2 * j + 0.5
    nstar = int(round(2 * j / np.pi))
    w = max(2, int(round(3 * mu ** (1 / 3))))
    lo, hi = max(nstar - w, 1), min(nstar + w, M - 1)
    frj = float(np.sum(np.abs(np.diff(dx))[lo - 1:hi]))
    print(f"  {j:5d}  {kappa[j-1]:7.3f}      {frj/TV:6.3f}          {kappa[j-1]*frj:8.5f}"
          f"        {holder[j-1]:8.5f}       {abs(da[j-1]):8.6f}")
print("  [small j: window sits on the dx mass but kappa is O(1); large j: kappa grows like"
      " j^(1/3) but the window has run past the dx mass (TV density ~ n^(-3/2)) — the"
      " product is uniformly small. This is the mechanism, in production numbers.]")
print("done.")
