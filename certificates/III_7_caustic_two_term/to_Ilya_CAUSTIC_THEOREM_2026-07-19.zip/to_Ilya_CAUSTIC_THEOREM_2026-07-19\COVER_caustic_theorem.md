# To Ilya — the caustic theorem: companion-K1 closed in closed form, the pairing question answered, the w = 3 elbow derived

**Merkabit · Selina + Claude · 2026-07-19 (nine sessions, one day). Not RH/GRH anywhere —
finite-section / explicit-constant / uniform-asymptotics mathematics.**

**Lineage:** this package FOLLOWS `to_Ilya_K1K2_P1_program_2026-07-18`
(SHA256 = 3b17a4f07c9dfd07540dea3b097af19d77f7c2e7738816b0bc83f40d2e4bb9cf) and
`to_Ilya_operator_program_2026-07-18`
(SHA256 = 16cd0374457d60235aef01736e0fec6f40d63026f8697cb4894d6c4439521944).
Nothing in either is modified; treat all three as immutable units. The P1/K1 questions
posed in the K1K2 package's menu are what this package answers. The frozen kernel caches
(`k1_kernels_*.npz`) and `quantiles_production.csv` live in the K1K2 package and are
regenerable by its scripts; today's scripts read them read-only (four cross-checks
against the committed CSVs pass, two exact — recorded in the notes).

## The four results (each one day-graded, newest last)

1. **THEOREM (companion model): κ_j = 1 + a_∞μ^{1/3} + R_j, −1.1 ≤ R_j ≤ 0.5 explicit
   (j ≥ 512), a_∞ = 2^{2/3}3^{−5/6}/Γ(2/3)² = 0.346555… DERIVED.** The mechanism is the
   Airy caustic: the kernel-row profile collapses to Φ_∞(ŝ) = −4(AiBi)′(−2^{1/3}ŝ)
   (verified 8.0e−5, Richardson 3-pt on certified rational rows; first correction
   confirmed 0.998), the constant is ∫₀^∞(AiBi)′ = −Ai(0)Bi(0), nothing else. Lemmas
   (L-a) Olver-remainder accumulation and (L-b) Debye zone are closed with explicit
   constants (fixed split x₀ = 1/2 — the γ→0 subtlety never arises); zone (iii) is
   exact σ-calculus. **Caustic lower bound at the exact constant: E_j ≥ 0.3466μ^{1/3}
   − 1.1 — log-K1 is refuted at a_∞ itself.** The subleading "log drift" is also dead
   (every budget component convergent; limit −0.934 matches j = 16384 to 0.001).
   → `D2_progress_bessel_kernels_2026-07-19.md` §7 (F9)/(F10); ingredient grading
   (classical-cited / exact / quadrature / finite-numeric-with-margins) itemized there.
   Two same-day corrections of our own record, dated, no silent edits: the √log law of
   the morning ladder was refuted out-of-sample (+2.06% vs −0.18% at j = 16384), and a
   garbage-finite scipy underflow row contaminated the older κ(384/512) — corrected
   table in `t2_d2_kappa_full_ladder.csv` (single authoritative ladder, to j = 1024).

2. **Your menu question ANSWERED: the windowed-S pairing TOLERATES j^{1/3} row
   constants** ((F11); model + your frozen production kernels). Two mechanisms:
   *localization* — the j^{1/3} partial-sum mass is the caustic dip; the explicit
   majorant Ψ_j = min(1.10κ_j, 1 + 0.50μ^{1/3}|ŝ|^{−1/2}) holds pointwise (0
   violations, three octaves), so equidistributed-TV fields pay 0.66·TV constant in j
   and oscillating S-like fields ≤ 0.014·TV; sharp at a caustic step (pays E_j — the
   condition is on the field). *Runaway* — your actual dx has TV density ~ n^{−3/2+}
   while the dip sits at n* = 0.64j and moves away: κ_j·TV_window peaks 0.054 and
   falls two orders. On the actual drop-4 field: TRUE sup|dα| = 0.0106, profile-pairing
   budget 0.0622 (no j^{1/3} anywhere), raw Abel 0.2847. H-ROT to ~4.5× of the true
   C_rot by explicit accounting.

3. **The w ≈ 3 elbow is DERIVED, not nominal** (`ELBOW_kernel_scale_note_2026-07-19.md`):
   it is the caustic scale of the |dα|-maximizing rows, w*_j = 2j/π + μ_j^{1/3} =
   2.9/3.8 at j = 2/3; sign-change clusters match in model and production; the
   operational tolerance curves reproduce your empirical C_needed knee interval [2,3]
   exactly. **The precise norm: ‖S‖*_w = max over windows of w mean spacings of the
   |SIGNED average of S|, w = 3** ("w ≤ 2 safe, w = 3 marginal, w ≥ 4 dead"). The
   J3(O)-nominated 3 = the caustic scale of the j = 2–3 kernels.

4. **The field-side TV-density bound, numerics staged** ((F12)): τ(n) = |Δdx_n| decays
   at p = 2.36; the split shows the S-part dominates, so the provable shape is
   τ ≤ u_n(sup|ΔS| + (q/n)sup|S|) with u_n = 2/(γ³ρ) ≤ C_geo·n⁻² purely geometric.
   Composed: **the window term 1.10a_∞μ^{1/3}TV_{W_j} ≤ 0.044 at every j.** Measured
   at production spec (pure Euler-product S_P, P = 2×10⁵, zeros nowhere):
   sup|S| = 0.862, per-spacing sup|ΔS| = 0.676, **‖S‖*₃ = 0.6295**.

## What now sits in whose lane

- **Yours (classical):** the u-decay lemma — u_n = 2/(γ_n³ρ_n) ≤ C·n⁻² for
  quantile-class configurations (ρ increasing log-type). One page of monotone calculus;
  it is the ONLY unproven analytic step left in the pairing story.
- **Yours (certification, = C1/C2 of the standing menu):** the three scalars above
  (sup|S|, per-spacing sup|ΔS|, ‖S‖*₃) certified — they are exactly where Turing/PZ
  enters. Rounding discipline as agreed (ceil-to-12dp before inequality).
- **Ours/next:** G-M1 weight transfer (λ-side Lambert pattern-check staged), G-M3
  truncation lemma, G-P2 second-order identity. The finite-range certificates
  (κ̂ = 5.60, N ≤ 149) are untouched by everything here.

## Reading order

`NOTE_P1_target_revision_j13.md` (orientation, the day's history compressed) →
`evidence/EVIDENCE_CHAIN_T2_pin.md` §9 (nine dated entries, master record) →
`evidence/D2_progress_bessel_kernels_2026-07-19.md` §7, blocks (F9)→(F10)→(F11)→(F12) →
`evidence/ELBOW_kernel_scale_note_2026-07-19.md` → scripts + logs per the §8 manifest
(`t2_d2_olver_profile.py` = derivation certificate; `t2_d2_lemma_La.py`/`_Lb.py` = the
lemma certificates; `t2_d2_pairing_*.py` = the pairing verdict; `t2_e_elbow_*.py` = the
elbow; `t2_f_field_tv_density.py` = the field side). Float-trap lessons (five, one new —
the divergent-integral genus) are recorded in the task files and (F9)/(F10).

*Grades throughout: certified-rational rows (mp ≤ 2e−13, three independent cross-checks);
closed-form constants exact; envelopes finite-numeric with 50% headroom and three-octave
stability; production measurements on YOUR frozen certified kernels, read-only. SHA seal
of this zip in `to_Ilya_CAUSTIC_THEOREM_2026-07-19.zip.sha256.txt` at send.*
