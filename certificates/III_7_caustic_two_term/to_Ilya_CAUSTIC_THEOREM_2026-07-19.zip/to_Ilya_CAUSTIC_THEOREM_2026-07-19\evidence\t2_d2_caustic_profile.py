# t2_d2_caustic_profile.py — STEP 1 of the caustic-profile session (2026-07-19 handoff):
# phase-aligned extraction of the caustic profile from the certified Miller rows.
#
# Phase alignment = sample against the EXACT Olver variable, not the naive s:
#   x = z/mu;  x>1: phi = sqrt(x^2-1) - arccos(1/x),  chi = mu*phi = (2/3)(-sigma)^(3/2)
#              x<1: phi = arccosh(1/x) - sqrt(1-x^2), chi = mu*phi = (2/3)(+sigma)^(3/2)
#   sigma = mu^(2/3) * zeta(x)   (Olver's Airy argument), and we report
#   shat := -sigma / 2^(1/3)  (aligned s: shat ~ s near the caustic, monotone in z).
# At fixed shat the fast phase 2*chi is j-INDEPENDENT, so profiles collapse pointwise;
# on the oscillatory side (shat > 0) we demodulate c_n against {1, cos 2chi, sin 2chi}
# with the exactly known per-atom phases (LSQ — no Nyquist requirement).
#
# Rows: t2_d2_caustic_exponent.rows() — certified pure-rational Miller/forward rows.
# (Float-traps: NEVER scipy jv/yv here; rational forms only; rows() and nothing else.)
import numpy as np
from t2_d2_caustic_exponent import rows, mp_spot

CBRT2 = 2.0 ** (1.0 / 3.0)

def olver_shat_chi(z, mu):
    """exact aligned coordinate shat and Airy phase chi = (2/3)|sigma|^(3/2), per atom."""
    x = np.asarray(z, dtype=float) / mu
    shat = np.empty_like(x); chi = np.empty_like(x)
    hi = x > 1.0
    if np.any(hi):
        xx = x[hi]
        phi = np.sqrt(xx * xx - 1.0) - np.arccos(1.0 / xx)
        chi[hi] = mu * phi
        shat[hi] = (1.5 * mu * phi) ** (2.0 / 3.0) / CBRT2
    lo = ~hi
    if np.any(lo):
        xx = x[lo]
        phi = np.arccosh(1.0 / xx) - np.sqrt(1.0 - xx * xx)
        chi[lo] = mu * phi
        shat[lo] = -(1.5 * mu * phi) ** (2.0 / 3.0) / CBRT2
    return shat, chi

def profile(j, smin, smax):
    """atom rows in the window shat in [smin, smax]: (shat, chi, c, K, n)."""
    mu = 2 * j + 0.5
    # z-window: invert shat ~ s to first order (shat ~ s is good enough for a window)
    zmax = mu + (smax + 6.0) * mu ** (1.0 / 3.0)
    N = int(np.ceil(zmax / np.pi + 0.5))
    z, c, K = rows(j, N)
    shat, chi = olver_shat_chi(z, mu)
    sel = (shat >= smin) & (shat <= smax)
    n = np.arange(1, N + 1)[sel]
    return shat[sel], chi[sel], c[sel], K[sel], n

def demod(shat, chi, y, centers, halfwidth):
    """LSQ demodulation y ~ P + Q cos2chi + R sin2chi on windows around centers.
    Returns arrays P, A (=sqrt(Q^2+R^2)), npts."""
    P = np.full(len(centers), np.nan); A = np.full(len(centers), np.nan)
    NP = np.zeros(len(centers), dtype=int)
    for i, s0 in enumerate(centers):
        m = (shat >= s0 - halfwidth) & (shat <= s0 + halfwidth)
        if m.sum() < 7:
            continue
        M = np.column_stack([np.ones(m.sum()), np.cos(2 * chi[m]), np.sin(2 * chi[m])])
        coef, *_ = np.linalg.lstsq(M, y[m], rcond=None)
        P[i] = coef[0]; A[i] = np.hypot(coef[1], coef[2]); NP[i] = m.sum()
    return P, A, NP

print("=== (A) smooth-side collapse: c(shat) for shat < -0.5 (no oscillation) ===")
prof = {}
for j in [256, 1024, 4096, 8192]:
    prof[j] = profile(j, -60.0, 60.0)
for (j1, j2) in [(256, 1024), (1024, 4096), (4096, 8192)]:
    s1, ch1, c1, K1, n1 = prof[j1]
    s2, ch2, c2, K2, n2 = prof[j2]
    # dense j2 grid interpolated onto j1's atoms (cubic via np.interp is linear;
    # smooth side varies slowly -> use local quadratic refinement)
    sel1 = (s1 >= -12.0) & (s1 <= -0.5)
    sa = s1[sel1]; ca = c1[sel1]
    cb = np.interp(sa, s2, c2)  # j2 sampling is ~4x denser; linear on smooth side
    dev = np.max(np.abs(ca - cb)); rel = dev / np.max(np.abs(ca))
    print(f"  {j1:5d} vs {j2:5d}:  max|dc| = {dev:.3e}   (rel {rel:.3e})   pts {sel1.sum()}")

print("=== (B) oscillatory-side collapse: demodulated P (mean) and A (envelope) ===")
centers = np.concatenate([np.arange(1.0, 10.0, 1.0), np.arange(10.0, 41.0, 2.0)])
DEM = {}
for j in [1024, 4096, 8192]:
    s, ch, c, K, n = prof[j]
    P, A, NP = demod(s, ch, c, centers, halfwidth=1.6)
    DEM[j] = (P, A, NP)
for (j1, j2) in [(1024, 4096), (4096, 8192)]:
    P1, A1, _ = DEM[j1]; P2, A2, _ = DEM[j2]
    ok = ~(np.isnan(P1) | np.isnan(P2))
    dP = np.nanmax(np.abs(P1 - P2)[ok]); dA = np.nanmax(np.abs(A1 - A2)[ok])
    print(f"  {j1:5d} vs {j2:5d}:  max|dP| = {dP:.3e}   max|dA| = {dA:.3e}")
print("   shat      P(8192)     A(8192)    npts")
P, A, NP = DEM[8192]
for s0, p, a, np_ in zip(centers, P, A, NP):
    print(f"  {s0:6.1f}   {p:+9.5f}   {a:9.5f}   {np_:4d}")

print("=== (C) envelope decay exponents on [8, 40] (j = 8192) ===")
sel = (centers >= 8.0) & (centers <= 40.0) & ~np.isnan(A)
lx = np.log(centers[sel])
for name, y in [("A (envelope)", A[sel]), ("|P| (mean)", np.abs(P[sel]))]:
    b, a = np.polyfit(lx, np.log(np.abs(y)), 1)
    resid = np.max(np.abs(np.log(np.abs(y)) - (a + b * lx)))
    print(f"  {name}: ~ shat^{b:+.3f}   (max log-resid {resid:.2f})")

print("=== (D) smooth-side tail law: c(shat) for shat in [-60, -2] (j = 8192) ===")
s, ch, c, K, n = prof[8192]
sel = (s <= -2.0) & (s >= -60.0)
lx = np.log(-s[sel])
b, a = np.polyfit(lx, np.log(np.abs(c[sel])), 1)
resid = np.max(np.abs(np.log(np.abs(c[sel])) - (a + b * lx)))
print(f"  |c| ~ (-shat)^{b:+.3f} * {np.exp(a):.4f}   (max log-resid {resid:.2f}, pts {sel.sum()})")
print(f"  sign of c on the smooth side: min {c[sel].min():+.4f}, max {c[sel].max():+.4f}")

print("=== (E) excursion accounting: where does E_j accumulate? ===")
for j in [512, 2048, 8192]:
    mu = 2 * j + 0.5
    N = 6 * j
    z, c, K = rows(j, N)
    ps = np.cumsum(K)
    iE = int(np.argmax(-ps)); E = float(-ps[iE])
    shat, chi = olver_shat_chi(z, mu)
    sE = shat[iE]
    print(f"  j = {j}:  E = {E:.4f}   at n/j = {(iE+1)/j:.4f} (shat* = {sE:+.3f})")
    # per-octave contributions on the smooth side, measured back from the minimum
    print("    octave [-2S,-S):  S = ", end="")
    Ss = [0.5 * 2 ** k for k in range(0, 12)]
    parts = []
    for S in Ss:
        m = (shat >= -2 * S) & (shat < -S) & (np.arange(N) <= iE)
        parts.append(K[m].sum())
    print("  ".join(f"{S:g}" for S in Ss))
    print("    contribution      :  " + "  ".join(f"{p:+.3f}" for p in parts))
    # cumulative-from-caustic growth: B(S) = -sum K over [-S, shat*]
    print("    B(S) = -sum(K, -S<=shat<=shat*):")
    Sg = [1, 2, 4, 8, 16, 32, 64, 128, 256, 512]
    line1 = []; line2 = []
    for S in Sg:
        m = (shat >= -S) & (np.arange(N) <= iE)
        B = -K[m].sum()
        line1.append(f"{S:>7d}"); line2.append(f"{B:+7.3f}")
    print("      S:   " + " ".join(line1))
    print("      B:   " + " ".join(line2))
    # fraction of E inside |shat| <= 10
    m10 = (shat >= -10) & (np.arange(N) <= iE)
    print(f"    fraction of E from shat in [-10, s*]: {-K[m10].sum()/E:.3f}")

print("=== (V) row re-verification spots (import sanity; certified machinery) ===")
for j in [256, 1024]:
    spots = [int(round(x * j)) for x in [0.30, 0.60, 0.637, 1.0]]
    z, c, K = rows(j, max(spots) + 2)
    truth = mp_spot(j, spots)
    dev = max(abs(c[n - 1] - t) for n, t in zip(spots, truth))
    print(f"  j = {j}: mp spot dev = {dev:.1e}")
z, c, K = rows(8192, 5300)
z2, c2, K2 = rows(8192, 5300, ktop_extra=330)
print(f"  j = 8192: ktop-stability (n<=5300) = {np.max(np.abs(c - c2)):.1e}")
print("done.")
