# t2_d2_lemma_Lb.py — LEMMA (L-b): zone-(i) Debye block, x = z_n/mu < x0 = 1/2, plus the
# (B3) near-oscillatory variation constant for the theorem assembly. Sixth session of
# 2026-07-19; companion to t2_d2_lemma_La.py (same fixed split x0 = 1/2).
#
# Because x0 is FIXED, gamma = arccosh(1/x) >= arccosh(2) = 1.3170 on the whole zone —
# the task-file's u1-warning (naive leading Debye term wrong as gamma -> 0) never
# arises; the u1-order Debye corrections are exactly what the envelope absorbs.
# Master envelope (from the u1-tail continuation of the caustic profile,
# c ~ 2/(3 pi mu W(x)), W(x) = arccosh(1/x) - sqrt(1-x^2) = (2/3) zeta^(3/2)):
#     |c_n| <= C_env * 2/(3 pi mu W(x_n))        [VERIFIED below, then bounded]
# =>  (pi/2) sum_{zone i} |c_n| <= C_env * (1/(3 pi)) * [int_0^{1/2} dx/W + EM margin].
# 1/W is increasing on (0, 1/2] and 1/W -> 1/ln(2/x) -> 0 as x -> 0: integrable, and the
# deep end (first atoms) is FAR below the envelope (J_a Y_b cross products ~ nu^(-3)).
import numpy as np
import mpmath as mp
from t2_d2_caustic_exponent import rows

mp.mp.dps = 30
X0 = 0.5

def Wfun(x):
    x = np.asarray(x, dtype=float)
    return np.arccosh(1.0 / x) - np.sqrt(1.0 - x * x)

print("=== (B1) zone-(i) envelope: rho_n = |c_n| * (3 pi/2) mu W(x_n) vs 1 ===")
ZTOT = {}
for j in [512, 1024, 4096]:
    mu = 2 * j + 0.5
    n_end = int(np.ceil(mu / (2 * np.pi) + 0.5)) - 1     # last atom with z_n < mu/2
    z, c, K = rows(j, n_end)
    x = z / mu
    rho = np.abs(c) * 1.5 * np.pi * mu * Wfun(x)
    ZTOT[j] = (np.pi / 2) * np.sum(np.abs(c))
    i_sup = int(np.argmax(rho))
    print(f"  j = {j}: atoms 1..{n_end};  sup rho = {np.max(rho):.4f} at x = {x[i_sup]:.4f};"
          f"  (pi/2) sum|c_n| = {ZTOT[j]:.5f}")
    for xs in [0.05, 0.15, 0.30, 0.45, 0.499]:
        i = int(np.argmin(np.abs(x - xs)))
        print(f"      x = {x[i]:.3f}:  rho = {rho[i]:.4f}")
    # deep end: first atoms are far below the envelope (cross-products ~ nu^-3)
    print(f"      deep end: rho_1 = {rho[0]:.2e}, rho_2 = {rho[1]:.2e} (envelope slack huge)")

print("=== (B2) the explicit bound ===")
Iw = mp.quad(lambda x: 1 / (mp.acosh(1 / x) - mp.sqrt(1 - x ** 2)), [0, X0])
print(f"  int_0^(1/2) dx/W(x) = {float(Iw):.6f}")
C_env = 1.2          # headroom over measured sup rho (j-stable, see B1)
# EM margin: 1/W increasing => midpoint sum <= integral over zone + half-cell overshoot
# at the x0 end: (pi/mu)*[1/W(x0)] per unit... bounded by (1/(3pi)) * (pi/mu)/W(x0) -> 0.
em = float(1 / (mp.acosh(2) - mp.sqrt(3) / 2))       # 1/W(x0) = 2.218 — half-cell factor
for j in [512, 1024, 4096]:
    mu = 2 * j + 0.5
    bound = C_env * (float(Iw) + (np.pi / mu) * em) / (3 * np.pi)
    ok = 'OK' if ZTOT[j] <= bound else 'VIOLATED'
    print(f"  j = {j}: measured (pi/2) sum|c| = {ZTOT[j]:.5f}  <=  C_b(j) = {bound:.5f}  {ok}")
C_b = C_env * float(Iw) / (3 * np.pi) * 1.02
print(f"  LEMMA (L-b): (pi/2) sum_(zone i) |c_n| <= C_env (1/(3pi)) int dx/W (1+em)"
      f"  =>  C_b = {C_b:.4f}   (C_env = {C_env}, all j >= 512)")

print("=== (B3) oscillatory-side structure (theorem ingredients + one negative result) ===")
# (a) NEGATIVE RESULT (recorded): the c-only partial sums keep growing ~ 0.4 mu^(1/3)
#     past the caustic before proj turns them — so "drop proj" (the upper-bound trick
#     that works below the caustic) FAILS on the oscillatory side. The theorem instead
#     uses the MEASURED sup-location (m^ = m* = 0.637j, certified full-cap scans).
# (b) K-side check: max over m in (m*, 6j] of (-ps_m) never exceeds E (sup at m*).
# (c) P*(j) = sum_(n<=m*) proj_n — the below-caustic projection mass (lower-bound const).
for j in [512, 2048, 8192]:
    mu = 2 * j + 0.5
    ns = int(np.floor(mu / np.pi + 0.5))
    N = 6 * j
    z, c, K = rows(j, N)
    S = (np.pi / 2) * np.cumsum(c[ns:])
    ps = np.cumsum(K)
    iE = int(np.argmax(-ps)); E = float(-ps[iE])
    beyond = np.max(-ps[iE + 1:]) - E
    proj = K + (np.pi / 2) * c
    Pstar = float(np.sum(proj[:iE + 1]))
    print(f"  j = {j}: c-only osc drift sup = {np.max(np.abs(S)):.3f}"
          f" (= {np.max(np.abs(S))/mu**(1/3):.3f} mu^(1/3), the negative result);")
    print(f"           m* = {iE+1} (m*/j = {(iE+1)/j:.3f}), E = {E:.4f};"
          f"  max(-ps) beyond m* - E = {beyond:+.3e}  [<0 => sup at m*]")
    print(f"           P* = sum proj below m* = {Pstar:.4f}   [lower-bound constant; <= 1 crude]")
print("done.")
