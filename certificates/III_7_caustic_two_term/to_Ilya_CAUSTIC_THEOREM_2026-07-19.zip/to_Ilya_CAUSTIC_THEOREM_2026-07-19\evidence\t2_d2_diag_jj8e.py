# diagnostic e: per-n error of float64 rational G_JJ vs mpmath truth, j=8
import numpy as np, mpmath as mp
from t2_d2_Fj_closed_form import G_parts

j = 8; mu = 2 * j + 0.5
mp.mp.dps = 40
z, GJJ, GY = G_parts(j, 6000)
print(" n        z        G_JJ float64        G_JJ mp           abs err      rel err")
for n in [1, 3, 6, 10, 15, 20, 24, 25, 26, 30, 40, 60, 100, 200, 400, 800, 1600, 3200, 6000]:
    zz = mp.mpf(2 * n - 1) * mp.pi / 2
    J = lambda k: mp.besselj(k + mp.mpf(1)/2, zz)
    gm = float(zz**2 * (J(2*j-1)*J(2*j+2)/(mu+1) - J(2*j-3)*J(2*j)/(mu-1))
               - (zz/2) * ((2*mu-1)*J(2*j)*J(2*j+2)/(mu+1) - (2*mu-5)*J(2*j-2)*J(2*j)/(mu-1)))
    gf = GJJ[n - 1]
    print(f"{n:5d}  {float(zz):9.2f}  {gf:+.12e}  {gm:+.12e}  {abs(gf-gm):.2e}  {abs(gf-gm)/max(abs(gm),1e-300):.1e}")
