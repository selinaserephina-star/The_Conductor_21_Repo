# diag 3: the x^14 sector at j=4 from every independent angle
from fractions import Fraction
import numpy as np, sympy as sp, mpmath as mp
from t2_d2_common import phi_poly
from t2_d2_sigma_calculus import TU_laurent, AB_exact, dmul, dlin, frac

j = 4
s = sp.Symbol('s'); mus = sp.Rational(4 * j + 1, 2)
Phi1 = phi_poly(2*j-1, 2*j+2, s); Phi2 = phi_poly(2*j-3, 2*j, s)
Phi3 = phi_poly(2*j, 2*j+2, s);   Phi4 = phi_poly(2*j-2, 2*j, s)
Psi_s = sp.expand(Phi1 / (mus + 1) - Phi2 / (mus - 1))
Psi_c = sp.expand((2*mus-1) * Phi3 / (mus + 1) - (2*mus-5) * Phi4 / (mus - 1))

T = TU_laurent(Psi_s, s, 'T'); U = TU_laurent(Psi_c, s, 'U')
print("x^14 coefficients:")
print(f"  T[Psi_s][14]      = {T.get(14)}")
print(f"  (1/2)U[Psi_c][14] = {Fraction(1,2) * U.get(14, Fraction(0))}")
# independent endpoint-derivative data
d16 = sp.diff(Psi_s, s, 16); d15 = sp.diff(Psi_c, s, 15)
print(f"  indep: +[Psi_s^(16)(0)+Psi_s^(16)(2)] = {frac(d16.subs(s,0) + d16.subs(s,2))}")
print(f"  indep: +(1/2)[Psi_c^(15)(0)+Psi_c^(15)(2)] = {Fraction(1,2)*frac(d15.subs(s,0) + d15.subs(s,2))}")

A, B = AB_exact(2 * j + 2)
mp1 = Fraction(4*j+3, 2); mm1 = Fraction(4*j-1, 2); mu_f = Fraction(4*j+1, 2)
gJJ_AA = dlin((Fraction(2)/mp1, dmul(A[2*j-1], A[2*j+2]), -1),
              (Fraction(-2)/mm1, dmul(A[2*j-3], A[2*j]), -1),
              (-(2*mu_f-1)/mp1, dmul(A[2*j], A[2*j+2]), 0),
              ((2*mu_f-5)/mm1, dmul(A[2*j-2], A[2*j]), 0))
print(f"  AA[14]            = {gJJ_AA.get(14)}")
print(f"  TU-sum[14]        = {T.get(14, Fraction(0)) + Fraction(1,2)*U.get(14, Fraction(0))}")

# numerical truth: extract the x^14 coefficient of pi*G_JJ from mp Bessel at large z
mp.mp.dps = 80
mu = 2 * j + 0.5
gJJ_lowAA = {p: c for p, c in gJJ_AA.items() if p <= 12}
for zval in [50, 100, 200]:
    zz = mp.mpf(zval)
    # pi*G_JJ at a NON-atom z is not the Laurent (eps^2 structure needs atoms) — use the
    # Laurent-defining combination via Lommel R directly: A_k(z) exact recurrence at real z
    Anum = [mp.mpf(1), 1/zz]
    for k in range(1, 2*j + 2):
        Anum.append((2*k+1)/zz * Anum[k] - Anum[k-1])
    val = (2*zz*(Anum[2*j-1]*Anum[2*j+2]/(mu+1) - Anum[2*j-3]*Anum[2*j]/(mu-1))
           - ((2*mu-1)*Anum[2*j]*Anum[2*j+2]/(mu+1) - (2*mu-5)*Anum[2*j-2]*Anum[2*j]/(mu-1)))
    low = sum(mp.mpf(c.numerator)/c.denominator * zz**(-p) for p, c in gJJ_lowAA.items())
    print(f"  z={zval}: (LommelForm - AA_low)*z^14 = {float((val - low) * zz**14):+.9f}   (AA[14] = {float(gJJ_AA.get(14)):+.9f})")
