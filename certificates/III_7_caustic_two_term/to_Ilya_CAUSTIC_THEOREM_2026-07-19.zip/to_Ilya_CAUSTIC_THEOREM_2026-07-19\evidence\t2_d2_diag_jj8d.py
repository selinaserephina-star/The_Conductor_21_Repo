# diagnostic d: EXACT-arithmetic test of the comb-collapse identity for the j=8 Psi's.
# Lattice side, resummed exactly at atoms (sin 2z_n = 0, cos 2z_n = -1):
#   T[p] := z^3 int_0^2 p sin(z s) ds |atoms = z^2 (p(0)+p(2)) - T[p'']/z^2   (finite recursion)
#   U[p] := z^2 int_0^2 p cos(z s) ds |atoms = -(p'(0)+p'(2)) - U[p'']/z^2
#   Sum_n cos(z_n tau) z^{-2m} = S_2m(tau):  S_2 = (1-tau)/2,  S''_{2m} = -S_{2m-2},
#   S_{2m}(0) = (2^{2m}-1) zeta(2m)/pi^{2m} (rational), S'_{2m}(0) = 0 (m>=2);
#   z^2- and z^0-coefficients pair with 0 (Abel comb has no interior mass).
# Delta side: pi*F_sin = (1/2)[Psi_s'''(2-t) - Psi_s'''(t)], pi*F_cos = -(1/4)[Psi_c''(t) - Psi_c''(2-t)].
# Compare EXACTLY as polynomials in tau on (0,2).
import sympy as sp
from t2_d2_Fj_closed_form import phi_poly

t = sp.Symbol('tau'); s = sp.Symbol('s')

def laurent(p, kind):
    """dict m -> coeff of z^{-2m} of T[p] (kind='sin') or U[p] (kind='cos'); m=-1 is z^2."""
    out = {}
    m = -1 if kind == 'sin' else 0
    sgn = 1
    while p != 0:
        if kind == 'sin':
            out[m] = out.get(m, 0) + sgn * (p.subs(s, 0) + p.subs(s, 2))
        else:
            dp = sp.diff(p, s)
            out[m + 0] = out.get(m, 0) + sgn * (-(dp.subs(s, 0) + dp.subs(s, 2)))
        p = sp.diff(p, s, 2); m += 1; sgn *= -1
    return out

def S_functions(mmax):
    S = {1: (1 - t) / 2}
    for m in range(2, mmax + 1):
        raw = sp.integrate(sp.integrate(-S[m - 1], t), t)   # particular, constants 0
        c0 = (2**(2*m) - 1) * sp.zeta(2*m) / sp.pi**(2*m) - raw.subs(t, 0)
        c1 = -sp.diff(raw, t).subs(t, 0)
        S[m] = sp.expand(raw + c1 * t + c0)
    return S

for j in [4, 8]:
    mu = sp.Rational(4 * j + 1, 2)
    Psi_s = sp.expand(phi_poly(2*j-1, 2*j+2, s) / (mu + 1) - phi_poly(2*j-3, 2*j, s) / (mu - 1))
    Psi_c = sp.expand((2*mu-1) * phi_poly(2*j, 2*j+2, s) / (mu + 1) - (2*mu-5) * phi_poly(2*j-2, 2*j, s) / (mu - 1))
    Ls = laurent(Psi_s, 'sin'); Lc = laurent(Psi_c, 'cos')
    mmax = max(list(Ls) + list(Lc))
    S = S_functions(max(mmax, 1))
    # lattice-side exact resummation (m <= 0 terms pair with zero)
    lat = sum(Ls.get(m, 0) * S[m] for m in range(1, mmax + 1)) \
        + sp.Rational(1, 2) * sum(Lc.get(m, 0) * S[m] for m in range(1, mmax + 1))
    # delta-side
    P3 = sp.diff(Psi_s, s, 3); P2 = sp.diff(Psi_c, s, 2)
    del_ = sp.Rational(1, 2) * (P3.subs(s, 2 - t) - P3.subs(s, t)) \
         - sp.Rational(1, 4) * (P2.subs(s, t) - P2.subs(s, 2 - t))
    diff = sp.expand(sp.nsimplify(lat - del_))
    print(f"j={j}: exact (lattice-resummed minus delta-form) = {sp.simplify(diff)}")
    if diff != 0:
        print(f"       as float at tau=0.1: {float(diff.subs(t, sp.Rational(1,10))):+.6e}; "
              f"at 1.8: {float(diff.subs(t, sp.Rational(9,5))):+.6e}")
        print(f"       z^2-coeff (pairs w/ Sum z^2 cos): sin-side {Ls.get(-1,0)}, "
              f"z^0-coeff: sin {Ls.get(0,0)}, cos {Lc.get(0,0)}")
