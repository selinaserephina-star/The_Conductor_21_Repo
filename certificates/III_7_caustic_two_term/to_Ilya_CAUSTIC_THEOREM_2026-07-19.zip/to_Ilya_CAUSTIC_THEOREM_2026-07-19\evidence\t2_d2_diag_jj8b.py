# diagnostic b: tau-shape of the j=8 F_JJ closed-vs-lattice error
import numpy as np, sympy as sp
from t2_d2_Fj_closed_form import G_parts, tapered_sum, FJJ_maker

for j in [4, 8]:
    z, GJJ, GY = G_parts(j, 240000)
    FJJ, _, _ = FJJ_maker(j)
    taus = np.arange(0.1, 1.95, 0.1)
    lat = tapered_sum(GJJ, z, taus, 240000)
    clo = np.array([FJJ(t) for t in taus])
    err = clo - lat
    print(f"j={j}:")
    for t, e in zip(taus, err):
        print(f"  tau={t:4.2f}  err={e:+.3e}")
