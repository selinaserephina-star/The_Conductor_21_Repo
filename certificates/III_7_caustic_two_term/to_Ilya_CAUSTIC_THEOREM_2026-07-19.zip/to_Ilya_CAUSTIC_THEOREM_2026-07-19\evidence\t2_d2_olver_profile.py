# t2_d2_olver_profile.py — STEP 2: derive the caustic profile from Olver/Airy uniform
# asymptotics and VERIFY at 1e-3 against the measured (Richardson-extrapolated) profile.
#
# Derivation (hand algebra, verified numerically here):
#   J_{mu+r}(z) ~ phi [Ai(sigma_r)],  Y_{mu+r}(z) ~ -phi [Bi(sigma_r)],
#   sigma_r = (mu+r)^(2/3) zeta(z/(mu+r)),  sigma_r = sigma + r*Delta + O(eps^2),
#   Delta = d sigma/d nu = alpha/sqrt(sigma) -> 2^(1/3) eps,  eps = mu^(-1/3).
#   The four-product telescope kills the leading AB order:
#     dW = -(2 Delta phi^2/mu) [ (AiBi)'(sigma) + Delta*(AiAi')'(sigma) + O(eps^2) ]
#   =>  Phi_inf(shat) = -4 (AiBi)'(sigma),  sigma = -2^(1/3) shat        [LEADING]
#       Psi_1(shat)   = -4*2^(1/3) (AiAi')'(sigma)                       [first corr.]
#   Tail (smooth side): (AiBi)'(s) ~ -(1/(4 pi)) s^(-3/2)  ->  Phi ~ |shat|^(-3/2)/(pi sqrt(2))
#   Integral: I_inf = int_{-inf}^0 Phi_inf dshat = 4*2^(-1/3) Ai(0)Bi(0)
#         ->  a_inf = I_inf/2 = 2^(2/3) 3^(-5/6) / Gamma(2/3)^2 = 0.34655...
#   (numerically close to (ln 2)/2 — coincidence, NOT equal; see assert below)
import numpy as np
import mpmath as mp
from scipy.special import airy  # Ai, Ai', Bi, Bi' — well-conditioned; NOT jv/yv
from scipy.interpolate import CubicSpline
from t2_d2_caustic_exponent import rows

CBRT2 = 2.0 ** (1.0 / 3.0)

def olver_sigma(nu, z):
    """exact Olver sigma = nu^(2/3) zeta(z/nu), vectorized in z (float)."""
    x = np.asarray(z, dtype=float) / nu
    sig = np.empty_like(x)
    hi = x > 1.0
    if np.any(hi):
        xx = x[hi]
        W = np.sqrt(xx * xx - 1.0) - np.arccos(1.0 / xx)      # (2/3)(-zeta)^(3/2)/nu^-1...
        sig[hi] = -(1.5 * nu * W) ** (2.0 / 3.0)
    lo = ~hi
    if np.any(lo):
        xx = x[lo]
        W = np.arccosh(1.0 / xx) - np.sqrt(1.0 - xx * xx)
        sig[lo] = (1.5 * nu * W) ** (2.0 / 3.0)
    return sig

def olver_phi(nu, z, sig):
    """Olver prefactor (4 zeta/(1-x^2))^(1/4) nu^(-1/3)."""
    x = np.asarray(z, dtype=float) / nu
    zeta = sig / nu ** (2.0 / 3.0)
    return (4.0 * zeta / (1.0 - x * x)) ** 0.25 * nu ** (-1.0 / 3.0)

print("=== (O1) per-function Olver leading order vs mp Bessel, j = 256 ===")
mp.mp.dps = 40
j = 256; mu = 2 * j + 0.5
for shat_t in [-8.0, -2.0, -0.5, 0.7, 3.0, 10.0]:
    zt = mu + shat_t * mu ** (1.0 / 3.0)
    n0 = int(round(zt / np.pi + 0.5)); z0 = (n0 - 0.5) * np.pi
    worst = 0.0
    for r in [-3, -2, -1, 0, 2]:
        nu = mu + r
        sig = float(olver_sigma(nu, np.array([z0]))[0])
        ph = float(olver_phi(nu, np.array([z0]), np.array([sig]))[0])
        Ai, Aip, Bi, Bip = airy(sig)
        Jex = float(mp.besselj(mp.mpf(nu), mp.mpf(z0)))
        Yex = float(mp.bessely(mp.mpf(nu), mp.mpf(z0)))
        relJ = abs(ph * Ai - Jex) / max(abs(Jex), 1e-300)
        relY = abs(-ph * Bi - Yex) / max(abs(Yex), 1e-300)
        worst = max(worst, relJ, relY)
    print(f"  shat = {shat_t:+5.1f}:  worst rel err (J and Y, orders mu-3..mu+2) = {worst:.2e}"
          f"   [expect O(nu^-4/3) ~ {mu**(-4/3):.1e} x |Ai'/Ai|-scale]")

print("=== (O2) exact-sigma Olver assembly of c = z^2 dW vs certified rows ===")
def c_olver_exact(jj, nvals):
    mu_ = 2 * jj + 0.5
    z = (np.asarray(nvals, dtype=float) - 0.5) * np.pi
    F = {}
    for r in [-3, -2, -1, 0, 2]:
        nu = mu_ + r
        sig = olver_sigma(nu, z)
        ph = olver_phi(nu, z, sig)
        Ai, Aip, Bi, Bip = airy(sig)
        F[('J', r)] = ph * Ai
        F[('Y', r)] = -ph * Bi
    rho1 = (2 * mu_ - 1) / (2 * z); rho2 = (2 * mu_ - 5) / (2 * z)
    T1 = (F[('J', -1)] - rho1 * F[('J', 0)] + F[('Y', 0)]) * F[('J', 2)] / (mu_ + 1)
    T2 = (F[('J', -3)] - rho2 * F[('J', -2)] + F[('Y', -2)]) * F[('J', 0)] / (mu_ - 1)
    return z * z * (T1 - T2)
for jj in [1024, 4096]:
    mu_ = 2 * jj + 0.5
    ns = [int(round((mu_ + st * mu_ ** (1 / 3)) / np.pi + 0.5)) for st in [-8, -4, -2, -1, -0.5]]
    z, c, K = rows(jj, max(ns) + 2)
    co = c_olver_exact(jj, ns)
    dev = np.max(np.abs(co - c[np.array(ns) - 1]))
    rel = np.max(np.abs((co - c[np.array(ns) - 1]) / c[np.array(ns) - 1]))
    print(f"  j = {jj}: smooth-side spots, max abs dev {dev:.2e}, max rel {rel:.2e}"
          f"   [expect O(1/mu) ~ {1/mu_:.1e} from dropped Olver B0 terms]")

print("=== (O3) Richardson-extrapolated measured profile vs derived Phi_inf, 1e-3 target ===")
def smooth_profile(jj, smin=-20.0, smax=-0.25):
    mu_ = 2 * jj + 0.5
    zmax = mu_ + 2.0 * mu_ ** (1 / 3)
    N = int(np.ceil(zmax / np.pi + 0.5))
    z, c, K = rows(jj, N)
    sig = olver_sigma(mu_, z)
    shat = -sig / CBRT2
    sel = (shat >= smin) & (shat <= smax)
    return shat[sel], c[sel]
JS = [4096, 8192, 16384]
prof = {jj: smooth_profile(jj) for jj in JS}
sbase, cbase = prof[4096]
grid = sbase[(sbase >= -18.0) & (sbase <= -0.12)]
PH = {}
for jj in JS:
    s_, c_ = prof[jj]
    PH[jj] = CubicSpline(s_, c_)(grid) if jj != 4096 else np.interp(grid, s_, c_)
# model Phi_j = Phi_inf + eps*Psi1 + eps^2*Psi2, eps_j = mu_j^(-1/3): solve 3x3 per point
eps = np.array([(2 * jj + 0.5) ** (-1 / 3) for jj in JS])
V = np.vander(eps, 3, increasing=True)  # [1, eps, eps^2]
Vinv = np.linalg.inv(V)
stack = np.vstack([PH[jj] for jj in JS])
coef = Vinv @ stack                    # rows: Phi_inf, Psi1, Psi2 (measured)
Phi_inf_meas, Psi1_meas = coef[0], coef[1]
sig_g = -CBRT2 * grid
Ai, Aip, Bi, Bip = airy(sig_g)
Phi_inf_der = -4.0 * (Aip * Bi + Ai * Bip)
Psi1_der = -4.0 * CBRT2 * (Aip ** 2 + sig_g * Ai ** 2)
dev = np.abs(Phi_inf_meas - Phi_inf_der)
print(f"  Phi_inf: max|meas - derived| = {np.max(dev):.2e} over shat in [-18, -0.12]"
      f"   (n = {len(grid)} points)   [target <= 1e-3]")
i = int(np.argmax(dev))
print(f"    worst at shat = {grid[i]:+.2f}: meas {Phi_inf_meas[i]:+.6f} vs der {Phi_inf_der[i]:+.6f}")
# first-order correction shape check (loose tolerance: it carries the eps^2 leak)
m = np.abs(Psi1_der) > 0.05
if m.sum() >= 6:
    ratio = Psi1_meas[m] / Psi1_der[m]
    print(f"  Psi1 shape check ({m.sum()} pts, |Psi1_der| > 0.05): median(meas/derived) = "
          f"{np.median(ratio):+.3f}   (1.0 = hand algebra confirmed; spread "
          f"{np.percentile(ratio,10):+.2f}..{np.percentile(ratio,90):+.2f})")
else:
    print(f"  Psi1 shape check skipped (only {m.sum()} usable points)")

print("=== (O4) oscillatory side: demodulated envelope, derived vs measured (same pipeline) ===")
def osc_profile(jj, smax=42.0):
    mu_ = 2 * jj + 0.5
    zmax = mu_ + (smax + 6.0) * mu_ ** (1 / 3)
    N = int(np.ceil(zmax / np.pi + 0.5))
    z, c, K = rows(jj, N)
    sig = olver_sigma(mu_, z)
    shat = -sig / CBRT2
    sel = (shat >= 0.5) & (shat <= smax)
    chi = (2.0 / 3.0) * (CBRT2 * shat[sel]) ** 1.5
    return shat[sel], chi, c[sel]
def demod(shat, chi, y, centers, hw=1.6):
    P = np.full(len(centers), np.nan); A = np.full(len(centers), np.nan)
    for i, s0 in enumerate(centers):
        m = (shat >= s0 - hw) & (shat <= s0 + hw)
        if m.sum() < 7: continue
        M = np.column_stack([np.ones(m.sum()), np.cos(2 * chi[m]), np.sin(2 * chi[m])])
        cf, *_ = np.linalg.lstsq(M, y[m], rcond=None)
        P[i] = cf[0]; A[i] = np.hypot(cf[1], cf[2])
    return P, A
# Derived uniform envelope law (trig/Debye telescope, hand algebra):
#   c_osc = -(4/pi)(1 - sin th) cos(2 psi),  th = arccos(mu/z)
# so A(shat; j) = (4/pi)(1 - sin th) -> 4/pi at fixed shat as j -> inf (matches Phi_inf).
centers = np.arange(2.0, 41.0, 2.0)
for jj in [1024, 8192]:
    mu_ = 2 * jj + 0.5
    s_, chi_, c_ = osc_profile(jj)
    Pm, Am = demod(s_, chi_, c_, centers)
    z_ = None  # recover z from shat via the atom set used in osc_profile
    zmax = mu_ + (42.0 + 6.0) * mu_ ** (1 / 3)
    N = int(np.ceil(zmax / np.pi + 0.5))
    zfull = (np.arange(1, N + 1) - 0.5) * np.pi
    sfull = -olver_sigma(mu_, zfull) / CBRT2
    sel = (sfull >= 0.5) & (sfull <= 42.0)
    zsel = zfull[sel]
    sinth = np.sqrt(np.maximum(0.0, 1.0 - (mu_ / zsel) ** 2))
    Alaw = np.full(len(centers), np.nan)
    for i, s0 in enumerate(centers):
        m = (s_ >= s0 - 1.6) & (s_ <= s0 + 1.6)
        if m.sum() >= 7:
            Alaw[i] = (4 / np.pi) * (1 - np.median(sinth[m]))
    ok = ~np.isnan(Am)
    reldev = np.nanmax(np.abs((Am - Alaw) / Alaw)[ok & (centers >= 4)])
    print(f"  j = {jj}: envelope law A = (4/pi)(1 - sin th):  max rel dev (shat >= 4) = {reldev:.3e}")
    if jj == 8192:
        print("   shat    A_meas    A_law     dA        P_meas")
        for i in range(0, len(centers), 3):
            print(f"  {centers[i]:5.1f}  {Am[i]:8.5f} {Alaw[i]:8.5f} {Am[i]-Alaw[i]:+8.5f}   {Pm[i]:+8.5f}")
        print(f"  DC (mean) component |P| <= {np.nanmax(np.abs(Pm[centers >= 4])):.1e} for shat >= 4"
              f"   [O(eps^2) — the oscillatory side nets ~nothing into E]")

print("=== (O5) the integral: I_inf closed form, a_inf, and the ladder with a_inf FIXED ===")
mp.mp.dps = 30
# calculus identity at finite T (the inf-limit needs AiBi(T) ~ 1/(2 pi sqrt(T)) -> 0):
T = mp.mpf(20)
val = mp.quad(lambda t: mp.airyai(t, 1) * mp.airybi(t) + mp.airyai(t) * mp.airybi(t, 1), [0, T])
tgt = mp.airyai(T) * mp.airybi(T) - mp.airyai(0) * mp.airybi(0)
print(f"  int_0^20 (AiBi)' dt = {float(val):+.12f} vs AiBi(20)-AiBi(0) = {float(tgt):+.12f}"
      f"   (diff {float(val - tgt):.1e});  AiBi(T) ~ 1/(2 pi sqrt(T)) -> 0, so"
      f"  int_0^inf (AiBi)' = -Ai(0)Bi(0) exactly")
a_inf = 2 ** mp.mpf('2/3') * 3 ** mp.mpf('-5/6') / mp.gamma(mp.mpf(2) / 3) ** 2
print(f"  a_inf = 2^(2/3) 3^(-5/6) Gamma(2/3)^-2 = {float(a_inf):.9f}")
print(f"  [curiosity: (ln 2)/2 = {float(mp.log(2)/2):.9f} — close but NOT equal; diff "
      f"{float(a_inf - mp.log(2)/2):.2e}]")
print(f"  in j-units: kappa_j ~ 1 + a_inf mu^(1/3) = 1 + {float(a_inf * 2**mp.mpf('1/3')):.6f} j^(1/3) + O(subleading)")
E_LADDER = {256: 1.9103, 512: 2.6159, 1024: 3.5116, 2048: 4.6432, 4096: 6.0641,
            8192: 7.8836, 16384: 10.1571}
print("  residual E_j - a_inf mu^(1/3)  (the O(1)+subleading part):")
for jjj, Ev in E_LADDER.items():
    mu_ = 2 * jjj + 0.5
    print(f"    j = {jjj:6d}:  {Ev - float(a_inf) * mu_ ** (1/3):+.4f}")
js = np.array(sorted(E_LADDER)); Es = np.array([E_LADDER[t] for t in js])
mus = 2 * js + 0.5
res = Es - float(a_inf) * mus ** (1 / 3)
M = np.column_stack([np.ones_like(res), np.log(mus)])
(c0, b0), *_ = np.linalg.lstsq(M, res, rcond=None)
fitres = res - (c0 + b0 * np.log(mus))
print(f"  subleading fit: E - a_inf mu^(1/3) = {c0:+.4f} {b0:+.5f} ln(mu)   (max resid {np.max(np.abs(fitres)):.4f})")

print("=== (O6) lower-bound ingredient: Phi_inf > 0 on the whole smooth side ===")
tg = np.linspace(0.0, 40.0, 4001)[1:]
Ai, Aip, Bi, Bip = airy(tg)
d = Aip * Bi + Ai * Bip
print(f"  max over sigma in (0, 40] of (AiBi)'(sigma) = {np.max(d):.3e}  (< 0 => Phi_inf > 0)")
half = mp.quad(lambda t: -(mp.airyai(t, 1) * mp.airybi(t) + mp.airyai(t) * mp.airybi(t, 1)),
               [CBRT2 * 1.0, CBRT2 * 4.0])
print(f"  (1/2) int_{{-4}}^{{-1}} Phi_inf dshat = {float(2 * half / CBRT2):.4f} * mu^(1/3)"
      f"  — explicit caustic lower bound (kills log-K1)")
print("done.")
