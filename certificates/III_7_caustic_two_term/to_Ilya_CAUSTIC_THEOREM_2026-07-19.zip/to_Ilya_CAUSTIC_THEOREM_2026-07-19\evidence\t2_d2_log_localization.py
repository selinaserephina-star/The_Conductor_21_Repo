# t2_d2_log_localization.py — D2 zone (ii): WHERE does the log accumulate in C_m?
#  (M1) envelope of c_n = z^2 dW_j(z_n) at scaled positions n/j, vs j
#  (M2) window decomposition of C_{m*}: which n/j-window's contribution grows like log j
#  (M3) C-profile at scaled m/j vs j (the log seen developing)
#  (X2) the Y-side analytic handle: EXACT finite-m double-integral representation
#       C_m^Y = (8/pi^2) II g1'(t) D_m(2cos t sin phi) dphi dt
#             - (4/pi^2) II dc0(t) D_m''(2cos t sin phi) dphi dt,   D_m''(u) = -sum_{n<=m} z^2 cos(z_n u)
#       (no Abel step: finite m, absolutely convergent) — verified numerically.
import numpy as np
import mpmath as mp
from t2_d2_common import G_parts

def c_total(j, N):
    """z^2 dW_j at atoms, deep-zone-(i) rows (scipy under/overflow -> NaN) patched via mpmath."""
    z, GJJ, GY = G_parts(j, N)
    c = GJJ + GY
    bad = np.where(~np.isfinite(c))[0]
    if len(bad):
        mp.mp.dps = 30
        mu = 2 * j + 0.5
        for i in bad:
            i = int(i)
            zz = mp.mpf(2 * (i + 1) - 1) * mp.pi / 2
            J = lambda k: mp.besselj(k + mp.mpf(1)/2, zz); Y = lambda k: mp.bessely(k + mp.mpf(1)/2, zz)
            dW = ((J(2*j-1) - (2*mu-1)*J(2*j)/(2*zz) + Y(2*j)) * J(2*j+2) / (mu+1)
                  - (J(2*j-3) - (2*mu-5)*J(2*j-2)/(2*zz) + Y(2*j-2)) * J(2*j) / (mu-1))
            c[i] = float(zz**2 * dW)
    return z, c, len(bad)

print("=== (M1) envelope |c_n| at scaled positions x = n/j ===")
XS = [0.55, 0.60, 0.64, 0.66, 0.70, 0.80, 1.00, 1.50, 2.00, 4.00]
print("   j   " + " ".join(f"x={x:4.2f}" for x in XS))
for j in [32, 64, 128, 256]:
    z, c, nbad = c_total(j, 8 * j + 200)
    row = []
    for x in XS:
        n0 = max(1, int(round(x * j)))
        w = c[max(0, n0 - 3):n0 + 3]
        row.append(np.max(np.abs(w)))
    print(f"{j:5d}  " + " ".join(f"{v:6.3f}" for v in row))

print("=== (M2) window decomposition of C_(m*) and the sup ===")
print("   j     m*    m*/j   S_true    [0,.55j]   (.55j,.8j]   (.8j,1.5j]   (1.5j,4j]")
for j in [32, 64, 128, 256, 512]:
    N = 8 * j + 200
    z, c, nbad = c_total(j, N)
    cs = np.cumsum(c)
    m_star = int(np.argmax(np.abs(cs))) + 1
    S = abs(cs[m_star - 1])
    def win(a, b):
        ia, ib = max(0, int(a * j)), min(N, int(b * j))
        return float(np.sum(c[ia:ib]))
    print(f"{j:5d}  {m_star:5d}  {m_star/j:5.3f}  {S:7.4f}   {win(0,0.55):+9.4f}  {win(0.55,0.8):+9.4f}"
          f"   {win(0.8,1.5):+9.4f}  {win(1.5,4):+9.4f}")

print("=== (M3) C at scaled m = x*j (the log developing pointwise in x) ===")
XS2 = [0.60, 0.66, 0.70, 0.80, 1.00]
print("   j   " + " ".join(f"x={x:4.2f}" for x in XS2))
for j in [32, 64, 128, 256, 512]:
    z, c, nbad = c_total(j, 8 * j + 200)
    cs = np.cumsum(c)
    print(f"{j:5d}  " + " ".join(f"{cs[int(x*j)-1]:+7.4f}" for x in XS2))

print("=== (X2) Y-side exact finite-m double-integral representation (j=4) ===")
j = 4; mu = 2 * j + 0.5
z, GJJ, GY = G_parts(j, 100)
NT = 3000
t = (np.arange(NT) + 0.5) * (np.pi / 2) / NT
ph = (np.arange(NT) + 0.5) * (np.pi / 2) / NT
wq = (np.pi / 2) / NT
g1p = -2.0 * ((2*mu - 1) * np.cos((2*mu - 1) * t) * np.cos(t) - np.sin((2*mu - 1) * t) * np.sin(t))
dc0 = np.cos(2*mu*t) / (mu + 1) - np.cos((2*mu - 4)*t) / (mu - 1)
for m in [3, 10]:
    zn = (np.arange(1, m + 1) - 0.5) * np.pi
    U = 2.0 * np.outer(np.cos(t), np.sin(ph))          # u(t,phi)
    Dm = np.zeros_like(U); D2 = np.zeros_like(U)
    for zk in zn:
        Dm += np.cos(zk * U); D2 -= zk * zk * np.cos(zk * U)
    lhs = float(np.sum(GY[:m]))
    rhs = float((8 / np.pi**2) * wq * wq * g1p @ Dm @ np.ones(NT)
                - (4 / np.pi**2) * wq * wq * dc0 @ D2 @ np.ones(NT))
    print(f"  m={m:3d}: sum G_Y = {lhs:+.8f}   double integral = {rhs:+.8f}   dev {abs(lhs-rhs):.2e}")
print("done.")
