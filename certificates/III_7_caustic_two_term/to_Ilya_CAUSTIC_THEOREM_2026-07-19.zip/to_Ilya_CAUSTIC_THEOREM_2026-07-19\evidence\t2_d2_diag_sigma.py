# diag: which half's Laurent fails at small n, j=4
from fractions import Fraction
import numpy as np, sympy as sp, mpmath as mp
from t2_d2_common import G_parts, phi_poly
from t2_d2_sigma_calculus import g_total, TU_laurent, AB_exact, dmul, dlin

j = 4
mp.mp.dps = 80
g, gJJ, gY = g_total(j)
z, GJJ, GY = G_parts(j, 12)

def ev(d, zz):
    return sum(mp.mpf(c.numerator) / c.denominator * zz ** (-p) for p, c in d.items())

print(" n     pi*G_JJ dev          pi*G_Y dev           total dev")
for n in range(1, 9):
    zz = mp.mpf(2 * n - 1) * mp.pi / 2
    dJJ = float(ev(gJJ, zz) - np.pi * GJJ[n - 1])
    dY = float(ev(gY, zz) - np.pi * GY[n - 1])
    print(f"{n:3d}  {dJJ:+.6e}   {dY:+.6e}   {dJJ + dY:+.6e}")
# and the two halves directly vs mp Bessel at n=1
mu = 2 * j + 0.5
zz = mp.pi / 2
J = lambda k: mp.besselj(k + mp.mpf(1)/2, zz); Y = lambda k: mp.bessely(k + mp.mpf(1)/2, zz)
gjj_true = mp.pi * (zz**2 * (J(2*j-1)*J(2*j+2)/(mu+1) - J(2*j-3)*J(2*j)/(mu-1))
                    - (zz/2) * ((2*mu-1)*J(2*j)*J(2*j+2)/(mu+1) - (2*mu-5)*J(2*j-2)*J(2*j)/(mu-1)))
gy_true = mp.pi * (2*zz*(J(2*j+1)*Y(2*j) - J(2*j-1)*Y(2*j-2))
                   - zz**2*(J(2*j)*Y(2*j)/(mu+1) - J(2*j-2)*Y(2*j-2)/(mu-1)))
print(f"n=1: mp-true pi*G_JJ = {float(gjj_true):+.6e}, Laurent = {float(ev(gJJ, zz)):+.6e}")
print(f"n=1: mp-true pi*G_Y  = {float(gy_true):+.6e}, Laurent = {float(ev(gY, zz)):+.6e}")
