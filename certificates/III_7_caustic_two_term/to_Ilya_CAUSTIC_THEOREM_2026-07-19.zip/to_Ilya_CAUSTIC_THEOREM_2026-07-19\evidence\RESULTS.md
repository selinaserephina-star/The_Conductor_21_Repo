# T2/P1 completion — results ledger

Every entry: data + grade, tool, verdict. Negative results are results.

## 2026-07-19 — D2 step 1–2: Theorem 1′ verified; (P1b)-as-W-log REFUTED for the companion
- data: string atoms x_n = 1/(n−½)²π⁻²-scale, companion weights ∝ x_n (normalized),
  M ∈ {64, 128}; mp pipeline (weighted, full reorth, adaptive dps 700/1500, four exact
  a-posteriori checks all < 1e−25); weighted central-FD kernels (frozen weights) as the
  independent comparison. Script `t2_d2_companion_kernels.py`, log
  `t2_d2_companion_kernels_run.log`.
- **Theorem 1′ (general fixed weights) VERIFIED:** K_j^α(ν) = w_ν[p_j² + 2β_jp_j′p_{j+1}
  − 2β_{j−1}p_{j−1}′p_j](x_ν) matches weighted FD to 4.0e−7 (M=64) / 1.3e−6 (M=128) —
  the FD floor; sum rules ≤ 1.6e−15. The uniform-weights proof carries verbatim (w_ν =
  mass of the moved atom); the kernel framework is weight-agnostic. R1 (spectral
  reduction) exact on the companion: bandwidth ≤ 8.6e−15, reconstruction ≤ 4.0e−15.
- **Finite-M companion a₃ = 0.778 / 0.780** — matches Theorem D1's infinite-system true
  constant 0.783 (proven ≤ 1.263): D1 is already numerically tight at M = 64.
- **NEGATIVE (the headline): W_j^companion is LINEAR in j, not log.** Measured W_j =
  0.10, 0.61, 1.52, 3.51, 9.8, 21.5, 48.8, 80.3, 101.2 at j = 1..120 (M = 128) ≈ 0.85j;
  the log-fit fails (slope 35, negative intercept — not a log). Meanwhile κ_j^companion
  IS log: bulk fit −0.20 + 0.53·log(2+j), κ̂ = 5.04 — essentially the same profile as the
  uniform system. So the assembled bound κ_j ≤ 1 + a₃W_j HOLDS (verified all j) but is
  grossly lossy for the companion: the ĥ/ĉ absolute-value split discards sign
  cancellation the companion relies on. **The W-log-law (P1b) is a uniform-weights
  phenomenon** (measured W ≤ 5.3 there), not a general one.
- **Consequence — D2 retargeted (PLAN updated):** prove companion-K1 by bounding
  C_j(m) = Σ_{n≤m} w_n h_j(x_n) directly on the string side (D1-style, signs kept);
  h_j at the atoms is elementary (Bessel + Bessel-derivative values via Theorem 1′ +
  B1), so the Poisson-product/delta-comb machinery applies to the direct partial sum.
- grade: mp(≤1e−25 checks) + float64 FD floor; infinite-system D1 constants exact.

## 2026-07-19 — D2 step 3: companion kernels in CLOSED BESSEL/RATIONAL FORM; companion-K1 = one sum, three zones
- scripts `t2_d2_bessel_kernels.py` (log `t2_d2_bessel_kernels_run.log`); note
  `D2_progress_bessel_kernels_2026-07-19.md`; table `t2_d2_kappa_infinite.csv`.
- **Three identities verified:** (V1) global value law ŝ_k = √(2k+1)R_{k,½}(1/y), Bessel
  form R_{k,½} = √(πz/2)[J_{k+½}sin z − Y_{k+½}cos z] (3.1e−14); (V2) derivative law at
  atoms with the second-kind Y entering (1.8e−6 FD floor); (V3) **kernel closed form**
  K_j(n) = 2πμJ_μ²/z − (π/2)z²[W_j − W_{j−1}], W_j = [J_{μ−1} − (2μ−1)J_μ/2z + Y_μ]J_{μ+2}/(μ+1),
  μ = 2j+½ — verified vs finite-M certified kernels (deviation halves 64→128 = the ~1/M
  truncation; the formula is the M = ∞ kernel). Projection piece = Dini-proven ∈ [0,1].
- **The e^{cj} pointwise cancellation is now one line:** J_{μ−1} + Y_μ = O(z^{−3/2})
  (phase cancellation), and at atoms everything is ε·rational: K_j(n) is an explicit
  RATIONAL function of z_n (A/B Lommel values; no oscillatory evaluation).
- **Infinite-system profile measured from the formula (no sections!):** κ_j = 1.000 →
  2.640 over j = 1..192, fit **0.386 + 0.382·log(2+j)** — clean log; m* ≈ 0.66j (just
  above the turning point z ≈ μ); drift flags ≤ 4e−2; unscanned tail mass ≈ 0.231
  constant in j (universal; away from the sup; exact computation slated for zone (iii)).
- **Numerical lesson recorded:** trig-form far-tail float64 phase noise (~1e−9·z-sums)
  produced spurious κ ~ 240 before capping — the rational form is both the provable AND
  the stable representation.
- **Companion-K1 reduced to:** sup_m|Σ_{n≤m}z²ΔW_j| ≤ (2/π)(c₀+c₁log j), three-zone plan:
  Debye (below turning point) / D1-machinery on Bessel PAIRS (oscillatory, where the sup
  lives) / exact rational tail-zetas (alternating-dominated). All machinery exists.
- grade: identities float64/FD floor + mp spot checks; profile float64 with per-row flags.

## 2026-07-19 — D2 zone (ii) toolbox: product-comb lemma proven-shape, E is atomic
- script `t2_d2_zone2_products.py`, log `t2_d2_zone2_products_run.log`; note §5–6 of
  `D2_progress_bessel_kernels_2026-07-19.md` (incl. the ordered handoff list).
- **(Z1) Product-comb lemma VERIFIED (4.8e−16):** j_a(z)j_b(z) = (±½)∫₀²(P_a∗P_b)(τ)·
  cos/sin(zτ)dτ (Legendre convolution, support [0,2]); {cos(z_nτ)} orthonormal on (0,2)
  (the DOUBLED string). D1's machinery lifts to products of two Bessel values.
- **(Z2) Wronskian cancellation (5e−18):** the antisymmetric J·Y cross-products
  (= 4(ν+1)/πz², elementary) cancel identically in the j-telescope; only symmetric
  Σ_ν = J_{ν+2}Y_ν + J_νY_{ν+2} survives.
- **(Z3) Casoratian (2.8e−16 rel):** A_{k+1}B_k − A_kB_{k+1} = −1; A, B = the two solutions
  of u_{k+1} = ((2k+1)/z)u_k − u_{k−1} with initials (1,1/z), (0,1).
- **(Z4) NEGATIVE (decisive):** the JJ/Y split re-introduces the cancellation — each part's
  partial sums ~2485 vs total 0.23–0.77 (j = 4..64). **E_ν = J_{ν−1} + Y_ν is the atomic
  object of zone (ii)**; never separate J from Y against the lattice sum.
- next session (ordered, note §6): (1) reconstruct the (0,2)-kernel F_j(τ) =
  Σz²ΔW·cos(z_nτ) numerically, guess closed form (the "G̃ = 1 moment"); (2) E-representation
  via E_μ = J_{μ−1} − J_{−μ}; (3) D1-style IBP → target c₁ ≈ 0.38 log; (4) fallback Olver
  uniform asymptotics at z ≈ μ; (5) zones (i)/(iii) routine afterwards.

## 2026-07-19 — D2 zone (ii) estimate block: Neumann reduction + F_j reconstructed (boundary-free IBP confirmed)
- script `t2_d2_neumann_reduction.py`, log `t2_d2_neumann_reduction_run.log`; note §6
  updated with the full state + next actions.
- **(N0–N2, machine-exact):** Y_ν = −J_{−ν} (0.0); Σ_ν = (4(ν+1)/z)J_{ν+1}Y_ν − 2J_νY_ν −
  4(ν+1)/(πz²) (3.5e−18); the elementary parts cancel in the j-telescope a SECOND time
  (1.1e−18) — the Y-content of z²ΔW_j is exactly two products J_{ν+1}Y_ν, J_νY_ν at ν = μ, μ−2.
- **(N3, 9.0e−16): Neumann reps with fixed kernels** — J_{ν+1}Y_ν and J_νY_ν are
  (2/π)-weighted Fourier coefficients (frequency 2ν+1, 2ν) of the FIXED profiles
  −J_1(2z cos t), −J_0(2z cos t); stationary point z sin t ≈ μ = the measured sup location.
- **(N4, 1.1e−13):** doubled-string Dirichlet kernel Σ_{n≤m}cos(z_nτ) = sin(mπτ)/(2sin(πτ/2)).
- **(F) F_j(τ) reconstructed (j = 4, 8, N = 40000 terms):** antisymmetric about τ = 1
  (2e−15); **boundary values vanish** (truncation floor) — boundary-free IBP applies as in
  D1; amplitude decays in j (0.34 → 0.13); NOT low-degree polynomial (fit resid ~0.9) —
  oscillatory, closed form to come from pushing the comb through N3. Partial-sum target:
  C-correction = ∫_0^2 F_j(τ)sin(mπτ)/(2sin(πτ/2))dτ.
- grade: float64, all identity checks ≤ 1e−13; F-series tail ≤ 3e−5.

## 2026-07-19 — D2 zone (ii): CLOSED FORM of F_j derived + verified (total 8e−13); log LOCALIZED in the m-signed pairing
- scripts `t2_d2_Fj_closed_form.py`, `t2_d2_Fj_ibp_log.py`, exact certificate
  `t2_d2_diag_jj8d.py`; logs `*_run.log`, `t2_d2_Fj_exact_collapse_run.log`; note §7.
- **Closed form (the headline):** F_j = F_JJ + F_Y.
  F_JJ(τ) = (1/2π)[Ψ_s‴(2−τ) − Ψ_s‴(τ)] − (1/4π)[Ψ_c″(τ) − Ψ_c″(2−τ)] — LOCAL polynomial
  data of the Z1 Legendre convolutions (z³/z² combs = δ‴/δ″ combs, only σ = τ, 2−τ hit);
  F_Y = (4/π²)[Q[g₁′](τ) − Q[g₁′](2−τ)] − (2/π²)d²/dτ²[Q[Δc₀](τ) − Q[Δc₀](2−τ)] via per-n
  boundary-free IBP in t (kills the J₁ kernel exactly) + classical Schlömilch collapse
  S₀(a,τ) = (1/π)[𝟙(a>τ)(a²−τ²)^{−1/2} − 𝟙(a>2−τ)(a²−(2−τ)²)^{−1/2}] (4.2e−12).
  Verified vs tapered lattice sums: parts 8.6e−10 (taper floor), TOTAL 8e−13 (equal-and-
  opposite tails cancel), j = 2, 4, 8 — target 1e−8 beaten by 4–5 orders.
- **Exact collapse certificate:** in sympy rational arithmetic, the per-atom IBP Laurent
  series (sin 2z_n = 0, cos 2z_n = −1) resummed through S_{2m} = Σ z^{−2m}cos(z_nτ)
  (S₂ = (1−τ)/2, S″ = −S_{2m−2}, S_{2m}(0) = (2^{2m}−1)ζ(2m)/π^{2m}) equals the δ-form
  IDENTICALLY (difference = 0, j = 4, 8): the JJ collapse is a finite Lidstone-type
  polynomial identity; only Σcos = Σz²cos = 0 (interior Abel) is analytic input.
- **Estimate block (honest):** C_m = ∫F_jD_m verified 8e−8; boundary-free IBP C_m =
  2F′(0⁺)/(mπ²) + (1/mπ)∫(F_jg)′cos(mπτ) verified to the discrete-edge floor (F even ⇒
  F′(0⁺) = emergent jump). **NEGATIVE:** naive one-IBP L¹ bound fails structurally —
  ‖(F_jg)′‖₁ ~ j² ⇒ S_bound ~ j (Z4 recurs: never split/absolute-value against the signed
  m-pairing). **Partial win:** |D_m| ≤ g ⇒ sup_m|C_m| ≤ Γ_j = ∫|F_j|g ≈ 0.47√j (kills the
  naive j; √j real: sup|F_j| ≈ 0.43√j, ‖F_j‖₂ ≈ 0.26√j Parseval). **The log is real and
  localized:** S_true = sup_m|C_m| = −0.174 + 0.216·log(2+j) (j = 2..64, resid 0.064) ⇒
  κ_j ≤ 1 + (π/2)S_true, c₁ = 0.34 ≈ measured 0.382. The log lives entirely in the
  m-signed cancellation near m* ≈ 0.66j (the moving singularity 2cos t = τ ↔ z sin t ≈ μ).
- **Two numerical lessons recorded (note §7 F3):** (i) forward Lommel recurrence unstable
  BELOW the turning point (A minimal there; poisoned rows invisible to N-doubling) —
  hybrid jv/yv + recurrence evaluation; (ii) mpmath-lambdify float trap: float argument ⇒
  s**31 in float64 ⇒ 1e−5 edge-concentrated j-growing error mimicking a missing analytic
  term — convert to mpf first. Cost of the hunt: the exact certificate (kept — it upgrades
  the collapse to proof-grade).
- next: extract the m-signed cancellation analytically (S_{2m}-calculus for the JJ half;
  stationary-phase/Olver for ∫F_YD_m), then zones (i)/(iii) routine.
- grade: closed form float64 8e−13 + exact-rational certificate; estimate block float64 on
  2¹⁸ FFT grids (4.8e−16 vs direct); S_true from exact rational atom values.

## 2026-07-19 — D2 σ-calculus session: C_m EXACT per-m; row-sum identity exact-rational; zone (iii) closes; log localized AT the turning point; κ-profile OPEN FLAG raised
- scripts `t2_d2_sigma_calculus.py`, `t2_d2_log_localization.py`, `t2_d2_common.py`
  (hygiene extraction), diagnostics `t2_d2_diag_sigma*.py`; note §7 (F5)/(F6) + OPEN FLAG.
- **σ-calculus (the headline):** πc_n is an even Laurent polynomial in 1/z_n with exact
  rational coefficients (Y half = Lommel A·B products; JJ half = A·A products ≡ T/U
  atom-IBP calculus, cross-checked EXACTLY). Per j = 2, 3, 4, 8 in rational arithmetic:
  g₋₁ = g₀ = 0 exactly (z²/constant sectors of JJ and Y cancel identically; JJ const → 2⁻);
  **row-sum identity Σ g_k(2^{2k}−1)ζ(2k)/π^{2k} = 0 EXACTLY** (C_∞ = 0 as a pure rational
  identity); hence **C_m = −(1/π)Σ_{k≥1}g_kρ_k(m)** exact for every m (verified 4e−14;
  per-atom Laurent 1e−15). Casoratian assert wired into every construction.
- **Zone (iii) CLOSES (numerics-first):** beyond z = 2μ² the ρ-series is alternating-
  dominated, r ≤ 0.04 shrinking in j ⇒ |C_m| = |g₁|ρ₁(m)(1±4%); universal tail g₁-leading,
  g₁/μ² → ≈ −8/π. Lemma-ready.
- **Third float-trap lesson (same genus as lambdify):** sympy nsimplify on unevaluated
  exact Adds evaluates through float64 — silently truncated 14/19 at the 17th digit of one
  deep T-coefficient → phantom TU-vs-AA mismatch 7/(μ+1)·z^{−(4j−2)}. Cost: full forensic
  chain (kept). Fix: cancel + numer/denom, never nsimplify exact data.
- **Log localization (measured, rows mp-verified 3e−13):** c_n envelope peaks at
  x = n/j = 2/π EXACTLY (turning point in atom units), peak O(1) constant in j; far
  envelope collapses to (x_t/x)² = |g₁|/(πz²); m*/j → 2/π from above; turning-window
  contribution grows then saturates (−0.19 → −0.54). **S_true steepens to ~0.5–0.7·log per
  octave at j = 256–512** — the 0.216·log fit (j ≤ 64) is pre-asymptotic.
- **Y-side analytic handle VERIFIED (exact finite-m, no Abel):** C_m^Y = (8/π²)∬g₁′(t)·
  D_m(2cos t sinφ) − (4/π²)∬Δc₀(t)D_m″(2cos t sinφ) — the stationary-phase object; the
  measured sup sits at its caustic.
- **OPEN FLAG (blocks the κ-asymptote claim):** reproducing κ_j from tonight's verified
  rows matches §2's table at j ≤ 4 (1.041) but NOT beyond (mine 1.06/1.14/1.08/1.43 vs §2
  1.178/1.336/1.539/1.909 at j = 8/16/32/64; opposite sign also fails). Either §2's scan
  protocol differs or its large-j values carry float noise. Resolve against the committed
  `t2_d2_kappa_infinite.csv` + `t2_d2_bessel_kernels.py` scan block. Until then the 0.382
  slope is fit-range-only; ALL variants remain comfortably polylog (program-safe).
- grade: σ-calculus EXACT rational (asserts); measurements float64 with mp row-verification
  3e−13; Y-rep at 2-D quadrature floor 8e−6.

## 2026-07-19 — κ-protocol flag RESOLVED; §2 log law SUPERSEDED: κ_j ≈ 0.46·j^{1/3} (Airy caustic)
- script `t2_d2_kappa_protocol_resolution.py`, log `*_run.log`; note §7 (F7).
- **Flag resolution — no bug on either side:** §2's κ = max(sup_fwd, sup_rev), sup_rev =
  sup_m|1 − ps_{m−1}| (tail-sum branch, row-sum = 1, init 1.0); the flag-raising scan
  measured only sup_fwd. max(fwd, rev) on the verified rational rows reproduces
  `t2_d2_kappa_infinite.csv` to ALL displayed digits at j = 8..192, same m*. At large j
  the sup is the rev branch = 1 + |negative excursion at the turning point|.
- **Extension (verified rows): κ(256, 384, 512) = 2.9103, 3.2891, 3.7008** vs §2-fit
  predictions 2.51, 2.66, 2.77. Growth law: κ/j^{1/3} flat at 0.46 ± 3% over j = 64–512;
  κ/log and κ/log^{3/2} rise monotonically (rejected); local exponent 0.30 → 0.35.
  **REVISED: κ_j ≈ 0.46·j^{1/3}, NOT c₀ + c₁log** — §2's fit (j ≤ 192) was pre-asymptotic.
  Mechanism = (F6)'s localization: O(1)-amplitude coherent window of width ~μ^{1/3} atoms
  at the caustic n/j = 2/π. Also §2's "universal tail 0.231" is pre-asymptotic: exact
  σ-calculus limit (π/2)|C_cap| → 2/π² = 0.2026 (j ≥ 384 scan residuals 0.28–0.32 carry
  far-tail float drift; sup region clean).
- **PROGRAM FLAG (for T2 chain + IB): K1-as-log is FALSE for the companion model** — the
  correct target is κ_j ≤ C·j^{1/3}. Consumer check (does the K1K2 tail assembly tolerate
  j^{1/3}?) is now step 1 of the next session. Finite-range certificate κ̂ = 5.60
  (all j, N ≤ 149) untouched (0.46·149^{1/3} = 2.45 < 5.60).
- grade: rows float64 verified vs mp at 3e−13; CSV reproduction exact to displayed digits;
  growth-law discrimination over one decade (64–512), exponent measured 0.30–0.35.

## 2026-07-19 — Consumer check: j^{1/3} does NOT break the program; P1 restated; production profile consistent (c ≈ 0.5)
- note `CONSUMER_CHECK_j13_2026-07-19.md` (verdict + per-consumer table).
- **Production bulk κ_j refit from the frozen certified kernels** (both drops, N = 149,
  boundary layer excluded): c·j^{1/3} fits marginally better than log (resid 0.80–0.82 vs
  0.93–0.94) with **c ≈ 0.516/0.523 — next to the model's 0.46**; N = 149 is exactly the
  pre-asymptotic window, so the model (j ≤ 512) arbitrates: presume production
  κ_j ~ 0.5·j^{1/3}. κ̂ = 5.60 is the boundary-row object, not the bulk law.
- **Per-consumer verdicts:** finite production chain (N ≤ 149) UNAFFECTED (and the law
  explains the bulk ceiling 0.5·149^{1/3} ≈ 2.7); **(P1) restated: log target FALSE,
  correct target sup_m|C_j(A_m)| ≤ C·j^{1/3}** (explains the D2 estimate-block failures —
  no route produced log because log is not there); H-ROT/M→∞ qualitatively unchanged (raw
  Abel was already the known gap; new quantified question for the IB menu: windowed-S
  pairing with j^{1/3} row constants — naive accounting closes since j^{1/3} ≪ j/window,
  unproven); KLMN/G4 unchanged.
- **Net: a correction of target, not a loss of ground** — D2's proof goal becomes
  κ_j ≤ Cj^{1/3} (upper + caustic lower bound); bulk (j^{1/3}) and boundary (M/πℓ) unify
  as the same uniform-asymptotics regime.
- grade: float64 refit on frozen certified kernels; frozen folders read-only.

## 2026-07-19 — Caustic ladder to j = 8192 (Miller-certified rows): law refines to 0.131·j^{1/3}√(ln j); fourth float-trap (garbage-finite underflow rows)
- script `t2_d2_caustic_exponent.py`, log `t2_d2_caustic_exponent_run.log`; note §7 (F8).
- **Fourth float-trap:** at the scipy underflow boundary (jv → 0/denormal, yv huge-but-
  finite) hybrid rows contain GARBAGE-FINITE values — no NaN, invisible to non-finite
  patches and to spot checks off the boundary row. One row (n = 127, z/μ = 0.388, j = 512)
  carried 0.0849; all scipy-hybrid excursions at j ≥ 512 were contaminated ((F7)'s
  κ(256–512) by ≤ 0.085; corrected κ(512) = 3.6159). Replacement: pure-rational rows —
  backward Miller for A (minimal; exact norm A₀ = 1) + forward B, log-mantissa form;
  verified mp ≤ 2e−13 (j ≤ 1024), ktop-stability ≤ 2e−14 all j, scipy/mp 4e−16 clean zone.
- **The ladder:** E_j = 1.9103, 2.6159, 3.5116, 4.6432, 6.0641, 7.8836 at j = 256..8192,
  m*_E/j = 0.637 = 2/π at every j. Local exponent falls 0.454 → 0.379 (pure powers
  rejected); E/j^{1/3} rises, E/√j falls; **E_j/(j^{1/3}√ln j) = 0.131 ± 2% FLAT over
  five octaves. LAW: κ_j = 1 + E_j, E_j ≈ 0.131·j^{1/3}(ln j)^{1/2}** — Airy caustic
  window with half-log enhancement. ((F7)'s pure 0.46·j^{1/3} was itself a two-octave
  artifact on contaminated points — caught by the flag discipline one session later.
  Honest residual ambiguity: a drifting pure power j^{0.35±0.02} not fully excluded.)
- Proof target updated: κ_j ≤ C·j^{1/3}(log j)^{1/2} (conservatively j^{1/3+ε}); consumer
  verdicts unchanged (≪ per-row window gain ~j). Draft IB side note updated in place
  (still DRAFT/unsent).
- grade: certified-rational rows (three independent cross-checks); law from five octaves;
  collapse-profile extraction (phase-aligned) pending — next session with the Olver
  derivation.

## 2026-07-19 — Caustic profile DERIVED: kappa_j = 1 + a_inf*mu^(1/3) + O(1) in CLOSED FORM; the sqrt(log) law refuted out-of-sample; (F7) ladder corrected
- scripts `t2_d2_caustic_profile.py`, `t2_d2_law_decision.py`, `t2_d2_olver_profile.py`,
  `t2_d2_kappa_full_ladder.py` (+ logs); note section 7 (F9); authoritative kappa table
  `t2_d2_kappa_full_ladder.csv`.
- **Phase-aligned profile** (exact Olver variable sigma; LSQ demod with known phases):
  smooth-side collapse 1024->4096 at 9.0e-3 (->2.4e-3 at 4096->8192, ~mu^(-2/3));
  smooth tail same-sign ~0.267|s|^(-1.6); oscillatory DC ~ 0; excursion integral B(S)
  SATURATES (85-93% of E from |s| <= 10) - no room for a sqrt(log) window mechanism.
- **Law decision:** E = a*mu^(1/3) + c fits the ladder at 0.41% (vs 2.6% for the (F8)
  sqrt(ln) law); OUT-OF-SAMPLE j = 16384 (fits frozen on j <= 8192): measured
  E = 10.1571; offset model -0.18%, sqrt(ln) law +2.06%. **(F8)'s sqrt(log) REFUTED -
  it was a finite-size mimic of the additive constant** (E/mu^(1/3) = a - 0.86 mu^(-1/3)
  reproduces every point, incl. the falling local exponent 0.454 -> 0.379).
- **Olver derivation, verified through TWO orders:** the four-product telescope gives
  dW = -(2*Delta*phi^2/mu)[(AiBi)'(sigma) + Delta*(AiAi')'(sigma) + O(eps^2)], hence
  **Phi_inf(s) = -4(AiBi)'(-2^(1/3) s)** - verified at 8.0e-5 vs the Richardson-
  extrapolated measured profile (target 1e-3); first correction Psi_1 confirmed at
  0.998 +/- 0.01; oscillatory envelope law (4/pi)(1 - sin theta) verified 1.8e-3
  (explains the apparent s^(-0.15) as a uniform theta-shape, not a power).
  Exact-sigma assembly matches certified rows at 6.6e-7 (j = 1024).
- **Closed-form law:** I_inf = 4*2^(-1/3) Ai(0)Bi(0) (calculus identity, exact), so
  **kappa_j = 1 + E_j, E_j = a_inf mu^(1/3) + O(1), a_inf = 2^(2/3) 3^(-5/6) / Gamma(2/3)^2
  = 0.346555... (= 0.43663 j^(1/3))**. Subleading measured -0.76 - 0.017 ln(mu) (|c| < 1).
- **Bounds:** upper target now kappa_j <= 1 + a_inf mu^(1/3) + C0 (NO log - stronger than
  the staged target C j^(1/3) sqrt(log j)); pending lemmas (L-a) Olver-remainder
  accumulation, (L-b) zone-(i) Debye block (measured <= 0.02). Lower:
  **E_j >= 0.1212 mu^(1/3) - O(1)** from the fixed window s in [-4,-1] where
  Phi_inf > 0 with margin - **log-K1 refuted permanently** (theorem-grade modulo the
  same two lemmas, which reduce to classical Olver error bounds on a compact window).
- **Corrected full ladder** (Miller rows everywhere, far block bitwise = rows(), no
  scipy): j <= 256 reproduces CSV/(F7) to all digits; **kappa(384) = 3.2393,
  kappa(512) = 3.6159 (F7's 3.2891/3.7008 corrected)**; NEW kappa(768) = 4.1141,
  kappa(1024) = 4.5116; sup = rev branch = 1 + E_j exactly at every j >= 64.
- Negative-result lesson recorded: the slick (AiBi)' < 0 proof via integrating the
  product ODE over (x, inf) is WRONG (int AiBi diverges; AiBi is not convex) - caught
  numerically before use.
- grade: derivation verified vs certified-rational rows (three cross-checks; Richardson
  3-pt); law from 7 octaves + out-of-sample point; closed-form constant exact.

## 2026-07-19 — ZONE-(ii) THEOREM CLOSED: lemmas (L-a)/(L-b) done, kappa_j = 1 + a_inf*mu^(1/3) + R_j with -1.1 <= R_j <= 0.5 explicit; subleading drift resolved (no log)
- scripts `t2_d2_lemma_La.py`, `t2_d2_lemma_Lb.py` (+ logs); note section 7 (F10).
- **Fixed split x0 = 1/2** (x = z/mu): zone (i) x < 1/2 (gamma >= arccosh 2 — the
  u1/gamma->0 trap never arises), window [1/2, 1], osc + zone (iii) beyond. The window
  edge n* IS the measured excursion argmin m* at every ladder j.
- **(L-a):** two-piece residual envelope vs certified rows (j = 256/1024/4096, 50%
  headroom, j-stable): |r_n| <= 5.5 eps^2/(1+|shat|) on shat >= -40; |r_n| <= 2.7 eps^3
  deeper (the sigma-linearized model is only O(1)-relative at the deep edge but rows are
  O(eps^3) there — Debye order-splitting suppression, rows fall to 0.13 of the Phi_inf
  tail at x0). Model constant PURE AIRY and closed:
  C_model_inf = -D_inf + 2Ai(0)Ai'(0) + Jac_inf = -0.2878 - 0.1838 - 0.1054 = -0.5770
  (direct Airy sum at j = 2^20: -0.5761; D_inf = 2^(2/3)/(2 pi (3W0/2)^(1/3)) EXACT).
  Deliverable: |E_W - (mu^(1/3)/2) I_inf| <= 0.60 + 0.40 = 1.05, all j >= 256.
- **(L-b):** envelope |c_n| <= 1.2 * 2/(3 pi mu W(x)) — measured sup ratio 0.130,
  j-stable, 8x slack, peak AT x0, deep end 1e-10; C_b = 1.2*(1/3pi)*int_0^(1/2)dx/W
  = 0.066 (measured zone total 0.0027 — bound deliberately crude). All rows positive.
- **NEGATIVE RESULT (recorded):** proj-drop fails beyond the caustic — c-only partial
  sums run to ~0.5 mu^(1/3) past m* before proj turns them. No O(1) osc-variation
  constant for c-sums exists; the theorem uses the measured sup-at-m* instead
  (margin checks at 512/2048/8192; full-cap certified scans j <= 1024).
- **P*(j) = sum proj below m* = 0.015/0.011/0.006 — proportional to eps** (Airy ramp):
  the lower bound pays <= 0.02 for proj, not the crude 1.
- **Ledger balance (closes to 1e-4 at three j):** E - E_W = zone-i - P*.
- **THEOREM (j >= 512): kappa_j = 1 + E_j, E_j = a_inf mu^(1/3) + R_j, -1.1 <= R_j <= 0.5**
  (upper side only 0.47: model partial sums never exceed main since Psi_1 <= 0 exact,
  Phi_inf > 0, C_modelPhi <= -0.36 < 0 all j). **Caustic lower bound with the EXACT
  constant: E_j >= 0.3466 mu^(1/3) - 1.1 — log-K1 refuted at a_inf itself.**
  Grades: Olver structure classical-cited; a_inf/D_inf/int-Psi1/sigma-calculus exact;
  C_model/Jac quadrature; envelopes + sup-location + P* finite-numeric, margins quoted.
- **Zone-(iii) lemma written** (from F5): S_m = -(pi/2)C_m exactly, |C_m| = |g1|rho_1(m)
  (1 +/- 0.04) beyond z = 2 mu^2, far partial sums pinned <= 0.211 -> can never compete
  with 1 + E_j.
- **Subleading drift RESOLVED structurally:** R_j -> C_model_inf + R_inf ~ -0.934
  (matches j = 16384 residual -0.933); every budget component individually convergent —
  NO genuine ln mu; the fitted drift was eps-convergence + EM jitter (+-0.01). A 32768
  out-of-sample test was considered and REJECTED: model separation (0.008-0.016) is
  inside the jitter — cannot decide; recorded as such. R_inf ~ -0.357 has no closed
  form; measured-convergent; not load-bearing.
- grade: lemma envelopes float64 on certified-rational rows with 50% headroom, three-j
  stability shown; closed-form constants exact (mp cross-checked); theorem constants
  explicit with graded ingredients; folder ready to cut into a dated send.

## 2026-07-19 — MENU QUESTION ANSWERED: the windowed-S pairing TOLERATES j^(1/3) row constants (model + production, two independent mechanisms)
- scripts `t2_d2_pairing_windowedS.py`, `t2_d2_pairing_production.py` (+ logs); note (F11).
- **Localization (model, certified rows):** explicit profile majorant
  Psi_j = min(1.10 kappa_j, 1 + 0.50 mu^(1/3)|shat|^(-1/2)) holds POINTWISE
  (0 violations, min margin +0.178, j = 256/1024/4096); pairing |sum K b| <= <Psi,|Db|>.
  Ramp (equidistributed TV): |P| = 0.66*TV CONSTANT in j while kappa_j = 2.9 -> 7.1;
  tapered sines <= 0.014*TV at every wavelength; Sigma|ps| = 2.048 mu exactly linear.
  SHARP: step at m* pays exactly E_j — the j^(1/3) is real only for fields whose TV
  concentrates in the moving mu^(1/3) caustic window.
- **Runaway (production, frozen npz read-only; cross-checks: atoms bitwise, max|dx|
  exact, kappa-hat convention identified = worst-step = 5.5956):** the actual transport
  field dx = x_fwd - x_D has TV density ~ n^(-3/2); the caustic window n* = 0.64j runs
  past it: TV fraction in-window 0.66-0.85 at j <= 10 (kappa O(1) there) but
  0.038 -> 0.008 at j >= 80 (kappa largest there). kappa_j*TV_window peaks 0.054 and
  falls two orders — the dangerous corner is structurally empty for quantile fields.
- **Accountings on the actual field:** TRUE sup|dalpha| = 0.0106; profile-pairing
  0.0622 (5.9x, no j^(1/3)); raw Abel 0.2847 (27x). H-ROT: budget/dx = 4.8 vs Abel-route
  22 vs truth 1.04-1.18 — pairing closes to ~4.5x, remaining slack = in-window sign
  cancellation (S oscillates; the sine-gain regime).
- **Retargeted for IB:** kernel side is (F10)-grade; the one formalizable piece left is
  the FIELD-side TV-density bound for quantile-class dx (TV_{W_j} <= c TV mu^(1/3)
  n*^(-3/2)-class) — S enters through certified windowed averages as LEMMA-8 anticipated.
- grade: model float64 on certified rows; production float64 on frozen certified
  kernels, four cross-checks vs committed CSV pass (two exact).

## 2026-07-19 — G-E DERIVED: the w ~ 3 elbow is the caustic scale of the maximizing kernel rows
- script `t2_e_elbow_kernel_scale.py` + log; deliverable note
  `ELBOW_kernel_scale_note_2026-07-19.md`; ledger G-E flipped GAP -> DERIVED.
- |dalpha| peaks at j = 3 (0.01059) and j = 2; those rows carry 87-89% of |K.dx| mass
  at n <= 3, first sign change at n = 4 (production) — the (F9)/(F10) caustic scale
  w*_j = 2j/pi + mu^(1/3) = 2.9 (j=2) / 3.8 (j=3) matches the sign-change clusters in
  BOTH model (certified rational rows) and production (frozen kernels).
- Operational tolerance (window-average dx, kernels fixed — isolates the kernel side):
  j=2 err 0.28/0.55 at w=2/3 (w*(50%) = 3); j=3 err 0.76/0.91; aggregate information
  0%/76%/101% lost at w=1/2/3. Frozen empirical C_needed(w) max slope on [2,3] exactly.
- **Deliverable norm: ||S||*_w = max over w-spacing windows of |SIGNED avg S|, w = 3**
  (abs-average A_w is an upper proxy; the pairing consumes signed averages — F11 sines).
  Honest reading: w <= 2 safe, w = 3 marginal, w >= 4 dead (elbow soft on the left).
- The J3(O)-nominated w = 3 = the caustic scale of the j = 2-3 kernels. Feeds G-HROT
  (remaining 4.5x = in-window sign cancellation at w <= 3) and G4.
- grade: float64 on frozen certified kernels (read-only) + certified rational model
  rows; j = 1 model row outside rows() order range (production j = 1 sign-pure).

## 2026-07-19 — Field-side TV-density bound STAGED (F12): the pairing story's last piece reduces to one classical lemma + certified S scalars
- script `t2_f_field_tv_density.py` + log; note (F12). Production quantiles + pure
  Euler-product S_P (P = 2e5, production spec, zeros nowhere); frozen folders read-only.
- tau(n) = |Ddx| decays at p = 2.36 (envelope 2.60); u = 2/(g^3 rho) at q = 2.05;
  S-part DOMINATES the split (0.0460 vs 0.0129 of TV = 0.0490) => lemma shape
  tau <= u_n(sup|DS| + (q/n)sup|S|), u_n <= C_geo n^-2 GEOMETRIC (classical, IB-lane).
- Composed law: separated regime (j >~ 40): TV_Wj <= 78 mu^(1/3) n*^(-2.36) TV;
  j <~ 30 fallback TV_Wj <= TV (window overlaps the S-mass; mu^(1/3) small there).
  **Window term 1.10 a_inf mu^(1/3) TV_Wj <= 0.044 at EVERY j** (peak j = 10, decay
  j^(-1.69)) — matches (F11)/X4's independent 0.054. The runaway is now an inequality.
- Honesty: dx = -u*S linearization only median-22% at product level (S moves over the
  shift itself; per-spacing |DS| mean 0.219) — all tau measurements on the ACTUAL field.
- Certified-side scalars for the G-C1/G-C2 lane: sup|S| = 0.862, sup|DS| = 0.676,
  **||S||*_3 = 0.6295** (signed = abs at the maximizing window — a sign-pure run;
  knee-script A_3 = 0.6164 consistent within convention).
- Pairing story complete on our side: kernel side theorem-grade (F10 + G-E), field
  side = classical u-decay write-up + certified scalars + these numerics.
- grade: float64 on frozen quantiles + Euler-product S; rho via mp theta'.
