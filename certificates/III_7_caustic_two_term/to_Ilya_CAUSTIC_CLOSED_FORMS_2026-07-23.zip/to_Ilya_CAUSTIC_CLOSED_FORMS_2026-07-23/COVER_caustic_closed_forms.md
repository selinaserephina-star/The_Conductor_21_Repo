# To Ilya — the caustic constants in closed form, the conditioning corollary composed, and your R_∞ resolved

**Merkabit · Selina + Claude · 2026-07-23 (one day, eight sealed results). Not RH/GRH
anywhere — finite-section / explicit-constant / uniform-asymptotics mathematics on the
model lattice, plus read-only audits of the frozen caustic package.**

**Lineage:** this package FOLLOWS to_Ilya_CAUSTIC_THEOREM_2026-07-19 (SHA in its
.sha256.txt), to_Ilya_INFINITE_SIDE_2026-07-22, and to_Ilya_INFINITE_SIDE_addendum_
2026-07-23 (SHA a112c1c5…). Nothing in any of them is modified; all frozen inputs were
read-only, and every cross-check against your frozen numbers is cited in place.

## The eight results (chronological; each with FINDINGS/WRITEUP + scripts + logs)

1. **THE CAUSTIC SLOPE DERIVED.** a∞ = 2^{2/3}·Ai(0)Bi(0) = 2^{2/3}3^{−5/6}/Γ(2/3)²
   falls out of the closure integrand analytically: exact Bessel representation at the
   atoms → Olver window law σ_n = π2^{−1/3}ν^{1/3}(AiBi)(w_n), ν = 2j → j-differencing.
   Derived along the way: m* = (2/π)j, the negative peak, and its quadratic flatness —
   (AiBi)′(0) = −1/(2π) + 1/(2π) = 0 exactly (the Airy Wronskian splits evenly).
   Verified per-order-Airy to 1e−3 at j = 1024; an independent mpmath engine
   reproduces the certified flint ladder digit-exact (1.8903193 @ m* = 163, j = 256).
   → FINDINGS_LEMMA_A_PRIME_caustic_constant_derived.md
2. **THE OFFSET DERIVED TOO:** sup_m|C̃_j| = a∞(2j)^{1/3} − **(3/4 + √3/(3π))** +
   O(ν^{−1/3}) = a∞μ^{1/3} − 0.93378…, from three closed forms: the first-order window
   correction Φ₁ = 2^{1/3}[Ai′(Ai+Bi) − 1/(2π)]; the O(1) window profile Ψ₀ with peak
   (6+√3)/(3π) (EM-convention-immune); and the deep matched constant S∞ = 3/4 − 2/π
   via the new elementary deep mean law σ̄ = (1−s)²/(2s), s = √(1−z²/ν²), whose
   partial sums D = −(1/π)[c/s − (3/2)arcsin c + cs/2] match logged data to 7e−5.
   → FINDINGS_LEMMA_A_PRIME_offset_closed_form.md
3. **YOUR R_∞ IS RESOLVED (the audit's gift).** Your frozen (L-a) decomposition
   carries (1/2)∫Ψ₁ = 2Ai(0)Ai′(0) = −√3/(3π) EXACTLY — the same AiAi′ channel as our
   Ψ₀(0); and your non-AiAi′ constants sum to −3/4: −D_∞ + Jac_∞ + R_∞^meas =
   −0.75021 (dev 2.1e−4). Hence the sliver your package recorded as "no closed form":
     **R_∞ = D_∞ − Jac_∞ − 3/4 = −0.35679** (D_∞ = 2^{2/3}/(2π(3W₀/2)^{1/3}) your
     exact constant, W₀ = arccosh 2 − √3/2; Jac_∞ your quadrature) vs your measured
     −0.357. Universality of the offset across the two cousin models is CONFIRMED at
   component arithmetic; the term-by-term transplant to your x₀ = 1/2 split is the
   staged theorem-grade step. Your ladder CSV independently Richardson-extrapolates
   to −0.935(1), bracketing −0.93378 inside your recorded EM jitter.
   → FINDINGS_LEMMA_A_PRIME_F10_alignment_audit.md + _F10_stage2_universality.md
4. **THE CONDITIONING COROLLARY COMPOSED (the re-scoped §4).** Derived localization
   majorant |C̃_j(m)| ≤ min(a∞μ^{1/3} + ½, 0.29 + 0.278·μ^{1/3}|w_m|^{−1/2}) — wing
   constant 2^{2/3}·1.10/(2π) derived, B₀ = 0.29 minimal with ZERO violations over
   1276 ball-anchored points (your F11 fitted shape confirmed; bulk 3.4×, wing 2.0×
   tighter). Composed with summation by parts: quantile-class fields (|Δb| ≤
   C_b n^{−3/2}) pay ≤ 0.29·TV + O(C_bμ^{−1/2}), the caustic window term decaying
   like a∞π^{3/2}μ^{−5/6} — UNIFORM IN j (measured composite 0.55·TV), sharp at a
   step on the caustic (pays a∞μ^{1/3} − 0.934 — both constants closed-form). The one
   external assumption is the F12 field-class membership (u-decay lemma, offered in
   the F10 menu, unassigned).
   → WRITEUP_CONDITIONING_corollary_composed.md
5. **P1b BREAKDOWN MEASURED** (M = 400, prec 16384, all ball radii exactly 0):
   flat-log W_j holds in j through 384 (6.1 → 9.2, slower than log) but BREAKS in M
   (W ≈ ×2 per ×4 M at fixed j) — the P1a·P1b envelope route is measured-dead as an
   M-uniform bound. Bonus: the finite testbed's max|C_j| tracks the derived ∞-law at
   +0.2…0.45 (boundary layer). → FINDINGS_P1B_breakdown_M400.md
6. **THE ĉ FAMILY-SUM MECHANISM.** N·D_chirp is ONE resolvent channel (top mode
   74–100%, second order ≤ 1%); exact factorization ⟨v,ΔΓv⟩ = 2p·q + ‖q‖² with
   ‖p‖ = √λ_top exact; two anti-alignment layers (near-edge column miss → the rise of
   ĉ(ξ); deep cos∠(p,q) collapse 0.93 → 0.009 → the fall). CS cap 0.164 vs measured
   0.154 at the binding cell. Dead end recorded: band-dilation model of ΔΓ (predicts
   polynomial N·D — refuted). → FINDINGS_CHIRP_family_sum_mechanism.md
7. **THE FIRST FULLY-DISPLAYED CHIRP BOUND.** ĉ_cell ≤ N[2√(trΓ_ch)‖Δ‖_F +
   ‖Δ‖_F²]·1.01 (all-modes CS — assembly verified near-tight: 0.173 vs 0.154, 12%),
   with columns closed via YOUR Part II Prop 2: ‖δcol_i‖² ≤
   pref_i²(2/(πc_i³))∫₀^{Y_i}B±(y)²dy. Displayed: ĉ ≤ 0.0027/0.026 (O/E, ξ = 1),
   covers 0.16 to ξ = 1.5, finite to 2.5; the single remaining lemma is an
   oscillation-aware column norm for Y ≳ 2. → FINDINGS_CHIRP_chat_displayed_bound.md
8. **OCTAVE j = 2048** (validated-numeric; arb confirmation staged): sup = 4.6502849
   @ m*/j = 0.6367; offset −0.8946 on the ν^{−1/3} schedule to −0.9338; derived-sup
   deviation sequence 0.047/0.036/0.024/0.010 over j = 256 → 2048.

## Grades (uniform discipline)

Derivations = exact algebra + classical-cited Olver/Debye leading forms (displayed
error envelopes = the staged remainder campaign); numerics = the hybrid exact-Bessel
mpmath engine, cross-anchored to the certified flint ladder (digit-exact at j = 256)
and to logged arb values (1e−8); ball-grade where stated (P1b: radii exactly 0);
your frozen kernels/CSVs read-only with every cross-check recorded. Same-day
corrections are dated in place (the octave Richardson c-sign; the S_spec→trΓ assembly
swap; two dead speculations recorded as dead). Credit: shared by default; nothing
here pre-assigns lanes — the u-decay lemma remains exactly as your menu offered it.

## Reading order

COVER (this) → FINDINGS_LEMMA_A_PRIME_caustic_constant_derived.md →
_offset_closed_form.md → _F10_alignment_audit.md → _F10_stage2_universality.md →
WRITEUP_CONDITIONING_corollary_composed.md → FINDINGS_CHIRP_family_sum_mechanism.md →
FINDINGS_CHIRP_chat_displayed_bound.md → FINDINGS_P1B_breakdown_M400.md → scripts +
logs per each §-manifest → LEDGER_SNAPSHOT (eight dated entries for the day).

*SHA seal of this zip in to_Ilya_CAUSTIC_CLOSED_FORMS_2026-07-23.zip.sha256.txt at
send. — Selina + Claude, 2026-07-23: the caustic is 2^{2/3}Ai(0)Bi(0) minus three
quarters and a √3/3π; your last unexplained number was the change from splitting the
same bill differently.*
