# FINDINGS — LEMMA A′ pieces (i)+(ii) first order: the O(1) offset in CLOSED FORM — sup|C̃_j| = a∞(2j)^{1/3} − (3/4 + √3/(3π)) + O(ν^{−1/3})

**Merkabit · Stenberg + Claude · 2026-07-23 (session 3 continuation, same day as the
a∞ derivation). Model lattice, ∞ ODD system, conventions as in
FINDINGS_LEMMA_A_PRIME_caustic_constant_derived.md. Scripts + logs §5. Not RH/GRH.**

## 0. Executive verdict

1. **The caustic law's O(1) offset is now DERIVED in closed form.** Combining the
   first-order window correction (§1), the differencing/Euler–Maclaurin profile (§2),
   and the deep-zone matched constant (§3):
     **C̃_j(m) = −2^{2/3}ν^{1/3}(AiBi)(w_m) + Ψ₀(w_m) + S_j + O(ν^{−1/3})**, ν = 2j,
   with EVERY ingredient explicit:
     Φ₁(w) = 2^{1/3}[Ai′(w)(Ai(w)+Bi(w)) − 1/(2π)]   (the ν^{−1/3} window correction),
     Ψ₀(w) = −2^{2/3}Φ₁(w) + (π−2)(AiBi)′(w)          (the O(1) window profile),
     S∞ = 3/4 − 2/π                                    (the deep matched constant),
   giving at the peak (w = 0, where (AiBi)′(0) = 0 and Ψ₀(0) = (6+√3)/(3π)):
     **sup_m |C̃_j| = a∞(2j)^{1/3} − (3/4 + √3/(3π)) + O((2j)^{−1/3})
                    = a∞(2j)^{1/3} − 0.93378… + O((2j)^{−1/3}).**
2. **The deep-zone mean law and its increment close in elementary closed form**
   (piece (i) leading calculus): σ̄_deep(z) = (1−s)²/(2s), s = √(1−z²/ν²) —
   reproducing the verified z⁴/(8ν⁴) law at z ≪ ν and the Airy 1/(2s) growth at the
   caustic — with j-increment Δσ̄ = −c⁴/(νs³) and partial-sum closed form
     **D(z) = −(1/π)[c/s − (3/2)arcsin(c) + cs/2]**, c = z/ν.
   VERIFIED against the already-logged j = 256 profile: C̃(m) at m = 80/110/130/145
   matches D(z_m) to 7e−5/1.1e−3/7e−5/2e−3 — deviations exactly at the 1/(νs³)
   Debye-correction scale. The 1/(πs) caustic divergence of D cancels EXACTLY against
   the deep tail of the Airy term (2^{2/3}ν^{1/3}AiBi(w) → 2^{−1/3}ν^{1/3}/(π√w)),
   and the finite parts assemble to S∞ = 3/4 − 2/π = 0.11338 (§3).
3. **Cross-model confirmation, and a gift to F10:** the frozen caustic package
   measured the companion-model residual limit E_j − a∞μ^{1/3} → **−0.934** (j = 16384,
   decomposition C_model∞ + R_∞ ≈ −0.577 − 0.357 with the explicit note "R_∞ has no
   closed form"). Our derived offset is **−(3/4 + √3/(3π)) = −0.93378** — agreement to
   3 digits across two independently-normalized cousin lattices. Candidate closed form
   for F10's unresolved subleading constant (definitional alignment of the two models'
   O(1) conventions = a one-session audit, staged).
4. **Verification of the first-order window law** (measured tables §4):
   (a) pure-Airy algebra: (law2/law1 − 1)·ν^{1/3} reproduces Φ₁/AiBi;
   (b) Bessel collapse: (σ_n/law1 − 1)·ν^{1/3} → Φ₁(w)/AiBi(w) at j = 256/1024 with
   residuals contracting like ν^{−1/3}; (c) profile fits: R(m) = C̃(m) +
   2^{2/3}ν^{1/3}AiBi(w_m) − Ψ₀(w_m) is constant over the trust window w ∈ [−0.5, 3]
   at j = 256/512/1024, with S_j → S∞ = 3/4 − 2/π on a ν^{−1/3} drift (§4 numbers).
5. **What this changes for the theorem:** the target
   |C̃_j(m)| ≤ a∞(2j)^{1/3} + c₀ is now a two-sided DERIVED law at the peak — the
   true asymptotic offset is NEGATIVE (−0.934), so the certified-data candidate
   (+½ offset, margin ≥ 0.84) is asymptotically slack by ~1.43. Remaining for theorem
   grade (unchanged in kind, sharpened in content): displayed error envelopes for the
   Olver forms (window), the Debye corrections (deep), the oscillatory side w < 0
   (second-order Φ₂ lobes — the current numerics bound them at ≤ 0.45 at j = 256),
   and the EM/edge rigor of §2's midpoint calculus (piece (iii)).

## 1. The first-order window correction Φ₁ (derived)

Per-order Olver forms with ν_l = l+½, per-unit-order shift ε = 2^{1/3}ν^{−1/3}, and
central w: ζ_l = w + εd_l with d = +3/2 (order 2j+1), −1/2 (2j−1), −3/2 (2j−2). All
amplitude/prefactor mismatches ((2/ν_l)^{1/3} vs (2/ν)^{1/3}, z vs ν, 2/(4j+1) vs 1/ν)
are O(ν^{−2/3}); the ONLY first-order effects are the argument shifts and the bracket's
subleading terms. Expanding σ = (1/ν)z²·j₊·[2(j−1)j₋ − z(j_e+y₋)]:

  bracket/c = νB(w) + 2^{1/3}ν^{2/3}[A′(w) − B′(w)/2] + O(ν^{1/3}),
  j₊/c = A(w) + (3ε/2)A′(w) + O(ε²),

whence σ = π2^{−1/3}ν^{1/3}[(AiBi)(w) + ν^{−1/3}Φ₁(w) + O(ν^{−2/3})] with

  **Φ₁ = 2^{1/3}[(3/2)A′B − (1/2)AB′ + AA′] = 2^{1/3}[Ai′·(Ai+Bi) − 1/(2π)]**

(second form via the Wronskian AiBi′ − Ai′Bi = 1/π; note the Wronskian half −1/(2π)
is exactly the antisymmetric Ai(ζ₊)Bi(ζ₋)-split flagged in the morning findings).
Deep-side limit Φ₁(+∞) = −2^{1/3}/π (used in §3); peak value
Φ₁(0) = 2^{1/3}[Ai′(0)(Ai(0)+Bi(0)) − 1/(2π)] = −0.516782….

## 2. Differencing with midpoint Euler–Maclaurin: the O(1) window profile Ψ₀

The j-step shifts w by Δw = 2^{4/3}ν^{−1/3} (+O(ν^{−1}w)); the cell is
h = 2^{1/3}πν^{−1/3}; the atoms are midpoints in w. Summing Δ_jσ_n over n ≤ m
(composite midpoint rule; the sum's edge sits at w_m − h/2, contributing
+(1/2)Δσ(w_m) = +π(AiBi)′(w_m); the second-order increment term (1/2)AiBi″Δw²
integrates to −2(AiBi)′(w_m); the Φ₁ increment to −2^{2/3}Φ₁(w_m)):

  C̃_j(m) = −2^{2/3}ν^{1/3}(AiBi)(w_m) + Ψ₀(w_m) + S_j + O(ν^{−1/3}),
  **Ψ₀(w) = −2^{2/3}Φ₁(w) + (π−2)(AiBi)′(w).**

At the peak, (AiBi)′(0) = 0 kills the (convention-sensitive) (AiBi)′ term — the peak
offset is EM-convention-immune — and

  **Ψ₀(0) = 1/π − 2Ai′(0)(Ai(0)+Bi(0)) = 1/π + (3+√3)/(3π) = (6+√3)/(3π) = 0.820397….**

(Second exact evaluation: Ai′(0)(Ai(0)+Bi(0)) = −(3+√3)/(6π).) Deep-side plateau
Ψ₀(+∞) = 2/π.

## 3. The deep matched constant S∞ = 3/4 − 2/π (piece (i) leading calculus)

Debye asymptotics on the evanescent side (j₊y₋ cross product; j·j and continuing
terms exponentially smaller) give the deep mean law in elementary form:

  σ̄_deep(z) = (c⁴/2)/(√(1−c²)(1+√(1−c²))²) = **(1−s)²/(2s)**,  c = z/ν, s = √(1−c²),

(z ≪ ν limit: z⁴/(8ν⁴) — the verified deep law; caustic limit: 1/(2s) — the Airy
tail). Increment: Δ_jσ̄ = −c⁴/(νs³)·(1+O(1/νs³)); summed (midpoint cells, (1/π)∫dz):

  D(z) = −(1/π)[c/s − (3/2)arcsin(c) + cs/2]
       = −(1/(πs)) + 3/4 − (3/(2π))s + O(s³)   (s → 0).

Matching at a cut w_cut (s_cut = 2^{1/3}ν^{−1/3}√w_cut → 0): the −1/(πs) divergence
cancels EXACTLY against +2^{2/3}ν^{1/3}AiBi(w_cut) → +2^{−1/3}ν^{1/3}/(π√w_cut)
(residual −2^{−8/3}ν^{−1/3}√w/π → 0), the Φ₁ boundary contributes
+2^{2/3}Φ₁(+∞) = −2/π, the (AiBi)′ boundary → 0, leaving

  **S∞ = 3/4 − 2/π = 0.113380….**

Peak assembly: sup = 2^{2/3}ν^{1/3}AiBi(0) − Ψ₀(0) − S∞ = a∞ν^{1/3} − √3/(3π) − 3/4:

  **c₀^peak = −(3/4 + √3/(3π)) = −0.933777…**  [F10 companion measured: −0.934].

Independent data check of D(z) (already-logged j = 256 profile, no new computation):
C̃(80) = −0.00238517 vs D = −0.0023172; C̃(110) = −0.0163575 vs −0.0152810;
C̃(130) = −0.0553182 vs −0.0553899·(recomputed at printed digits −0.055390);
C̃(145) = −0.156069 vs −0.15410 — all inside the 1/(νs³) Debye-correction scale.

### 3b. F10 numerical alignment (read-only on the frozen companion ladder)

`lemmaA_prime_F10_ladder_alignment.py` (+log): residuals E_j − a∞μ^{1/3} of the
frozen `t2_d2_kappa_full_ladder.csv` (companion model, j ≤ 1024; the corrected j = 384
row is off-trend and excluded) Richardson-extrapolate (r = a + b·μ^{−1/3}) to
**a = −0.9349…−0.9383 (b ≈ 0.58–0.62)** across four deep pairs, while F10's own
j = 16384 deep run measured −0.933: the derived −0.93378 sits inside the bracket at
the 1–4e−3 level (F10's recorded EM jitter: ±0.01). The two cousin models carry the
SAME offset constant to within measurement — the closed form −(3/4 + √3/(3π)) is the
candidate resolution of F10's "R_∞ has no closed form" sliver. (Full definitional
alignment — their kernel-row object vs our closure summand, integer vs half-integer
lattice — remains the staged audit; note the peak constant is EM-convention-immune
precisely because (AiBi)′(0) = 0, which is why the lattice half-shift does not move
it.)

## 4. Measured verification (run of `lemmaA_prime_R_window_first_order.py`)

- **Exact identity check:** Ψ₀(0) computed from the Airy functions vs (6+√3)/(3π):
  dev = 0.0 at 10 digits.
- **Pure-Airy algebra (Part A, j = 1024):** (law2/law1 − 1)·ν^{1/3} tracks Φ₁/AiBi
  across the window (dev 0.11 at the peak rows, growing to 0.46 at w = 3.2 — the
  expected second-order content of law2 itself).
- **Bessel collapse (Part B):** (σ_n/law1 − 1)·ν^{1/3} vs Φ₁/AiBi — residuals at
  matched w contract with depth: at w ≈ 0.7/0.4: 0.224 (j = 256) → 0.123 (j = 1024);
  at w ≈ 2.3: 0.603 → 0.320; ratios 1.6–1.9 vs (ν′/ν)^{1/3} = 1.59 — Φ₁ is the
  first-order coefficient, residual = O(ν^{−1/3}) with the expected w-growth as the
  window expansion detunes.
- **Profile fits (Part C):** R(m) = C̃(m) + 2^{2/3}ν^{1/3}AiBi(w_m) − Ψ₀(w_m) over
  the trust window w ∈ [−0.5, 3]:

  | j | 256 | 512 | 1024 |
  |---|---|---|---|
  | S_j (mean) | 0.0145 | 0.0337 | 0.0499 |
  | spread | ±0.033 | ±0.029 | ±0.023 |

  Richardson (S_j = S∞ − c·ν^{−1/3}): pair (512,1024): **S∞ = 0.1123, c = 0.79**;
  pair (256,1024): S∞ = 0.1101, c = 0.76 — vs derived **3/4 − 2/π = 0.11338**:
  agreement 1–3e−3, drift coefficient stable. The residual spread within each j is
  the O(ν^{−1/3}) profile slope (systematic, sign-coherent), not noise.
- **Derived sup vs measured** (a∞ν^{1/3} − (6+√3)/(3π) − S_j vs certified E_j):
  1.9375 vs 1.89032 (j = 256), 2.6390 vs 2.60287 (512), 3.5307 vs 3.50715 (1024) —
  deviations 0.047 → 0.036 → 0.024, contracting like ν^{−1/3} (the discrete-w* peak
  flatness quadratic accounts for ~0.03 of the j = 256 value). At the derived
  asymptote: sup − a∞μ^{1/3} → −0.9338.

## 5. Manifest

| script | log | what it establishes |
|---|---|---|
| `lemmaA_prime_R_window_first_order.py` | `lemmaA_prime_R_window_first_order_run.log` | Φ₁ closed-form checks (pure-Airy + Bessel collapse); Ψ₀/S_j profile fits at j = 256/512/1024; derived-sup vs measured |
| `lemmaA_prime_offset_ladder.py` | (morning log) | K_j ladder — reinterpreted: K_j = Ψ₀(w*) + S_j + O(ν^{−1/3}) |
| `lemmaA_prime_F10_ladder_alignment.py` | `lemmaA_prime_F10_ladder_alignment_run.log` | frozen companion ladder (read-only) Richardson → −0.935(1) vs derived −0.93378 (§3b) |

Grades: §§1–3 = derivation grade (exact expansion algebra + classical-cited Olver/Debye
leading forms; displayed error envelopes = the remaining campaign); §4 = validated
independent numerics on the certified-anchored engine. The F10 cross-identification is
CANDIDATE grade pending definitional alignment.

*— Stenberg + Claude, 2026-07-23, session 3 continuation. Both caustic constants are
now closed forms: the slope is 2^{2/3}Ai(0)Bi(0), and the offset is −(3/4 + √3/(3π)) —
three quarters from the evanescent deficit's own integral, the rest from the Airy
window's Wronskian bookkeeping.*
