# lemmaA_prime_F10_stage2_identity.py — F10 ALIGNMENT AUDIT STAGE 2 (2026-07-23):
# component-arithmetic verdict on the offset universality.
# OUR derived model-lattice offset: -(3/4 + sqrt3/(3pi)), where the sqrt3/(3pi) is the
# AiAi' channel (-2Ai'(0)Ai(0) inside Psi0(0)) and the -3/4 is window(2/pi) +
# deep-matching(3/4 - 2/pi).
# F10's frozen companion decomposition ((L-a), D2 section 7):
#   offset = C_model_inf + R_inf,  C_model_inf = -D_inf + (1/2)IntPsi1 + Jac_inf,
#   (1/2)IntPsi1 = 2Ai(0)Ai'(0)  [EXACT — the SAME AiAi' channel],
#   D_inf = 2^{2/3}/(2pi(3W0/2)^{1/3}) EXACT, W0 = arccosh2 - sqrt3/2,
#   Jac_inf = -0.1054 (their quadrature),  R_inf ~ -0.357 (measured Cauchy limit,
#   recorded "no closed form").
# UNIVERSALITY TEST: the non-AiAi' constants of the companion must sum to -3/4:
#   -D_inf + Jac_inf + R_inf =? -3/4   <=>   R_inf = D_inf - Jac_inf - 3/4.
# Not RH/GRH.
import mpmath as mp
mp.mp.dps = 30
PI = mp.pi

AiAip = mp.airyai(0)*mp.airyai(0, 1)
print(f"shared AiAi' channel: 2Ai(0)Ai'(0) = {mp.nstr(2*AiAip, 8)}  "
      f"= -sqrt3/(3pi) = {mp.nstr(-mp.sqrt(3)/(3*PI), 8)}  "
      f"(dev {mp.nstr(2*AiAip + mp.sqrt(3)/(3*PI), 3)})")

W0 = mp.acosh(2) - mp.sqrt(3)/2
D_inf = 2**(mp.mpf(2)/3)/(2*PI*(3*W0/2)**(mp.mpf(1)/3))
print(f"D_inf = 2^(2/3)/(2pi(3W0/2)^(1/3)) = {mp.nstr(D_inf, 8)}   [F10: 0.2878]")

Jac_inf = mp.mpf('-0.1054')   # F10 quadrature (frozen)
R_meas = mp.mpf('-0.357')     # F10 measured Cauchy limit (frozen; 'no closed form')
total_f10 = -D_inf + 2*AiAip + Jac_inf + R_meas
ours = -(mp.mpf(3)/4 + mp.sqrt(3)/(3*PI))
print(f"\nF10 total: -D_inf + 2AiAi' + Jac_inf + R_meas = {mp.nstr(total_f10, 6)}")
print(f"our derived total: -(3/4 + sqrt3/(3pi))         = {mp.nstr(ours, 6)}")
print(f"F10 direct j=16384 measurement                  = -0.934 (+-0.001)")

nonairy = -D_inf + Jac_inf + R_meas
print(f"\nUNIVERSALITY TEST (non-AiAi' constants sum to -3/4):")
print(f"  -D_inf + Jac_inf + R_meas = {mp.nstr(nonairy, 6)}   vs  -3/4   "
      f"(dev {mp.nstr(nonairy + mp.mpf(3)/4, 3)})")
R_pred = D_inf - Jac_inf - mp.mpf(3)/4
print(f"\nCLOSED FORM FOR F10'S OPEN SLIVER:")
print(f"  R_inf = D_inf - Jac_inf - 3/4 = {mp.nstr(R_pred, 6)}   vs measured -0.357  "
      f"(dev {mp.nstr(R_pred + mp.mpf('0.357'), 3)})")
print(f"\n(sign conventions: F10's Jac_inf carries its own sign, -0.1054; the AiAi'")
print(f" channel enters both models with the same sign and weight; our -3/4 splits as")
print(f" 2/pi [window] + (3/4 - 2/pi) [deep matching], theirs as D/Jac/Olver-accum.)")
