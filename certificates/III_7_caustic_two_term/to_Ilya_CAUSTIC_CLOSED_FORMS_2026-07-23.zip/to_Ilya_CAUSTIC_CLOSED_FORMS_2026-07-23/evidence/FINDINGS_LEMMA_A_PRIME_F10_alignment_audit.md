# FINDINGS — F10 alignment audit (stage 1): the dictionary, the R_∞ prediction, and what full closure needs

**Merkabit · Stenberg + Claude · 2026-07-23 (session 3, third push). Read-only on the
frozen to_Ilya_CAUSTIC_THEOREM_2026-07-19 package; all new claims live here.
Not RH/GRH.**

## 0. Executive verdict

1. **The dictionary between F10's companion object and this campaign's C̃ is exact at
   the mechanism level.** F10's kernel-row correction is ALREADY a j-telescope
   (K-row ∝ −(π/2)z²[W_j − W_{j−1}]), and their derived row profile is
   dW = −(2Δφ²/μ)[(AiBi)′(σ) + Δ·(AiAi′)′(σ) + O(ε²)], Δ = 2^{1/3}ε, ε = μ^{−1/3}
   (frozen D2 §7 (F9)) — i.e. the SAME Airy-product derivative kernel our
   j-differencing produces (our window increment Δσ_n = 2π(AiBi)′(w)·(1+…) per atom).
   Both models' leading constants are the same calculus at the turning point:
   their I_∞ = 4·2^{−1/3}Ai(0)Bi(0) with E_j = (μ^{1/3}/2)I_∞ + O(1) ≡ our
   2^{2/3}Ai(0)Bi(0)·ν^{1/3} — a∞ shared EXACTLY (both now derived).
2. **The models are genuinely different at first order** — cousins, not twins: F10's
   companion system runs on weights w_n = 2x_n with row orders (μ−1, μ, μ+2) and its
   first-order profile correction is Ψ₁ = −4·2^{1/3}(AiAi′)′ (Ai-only, no Bi-content;
   confirmed 0.998 in the frozen package); our ODD system (weights 2x_n², orders
   2j−2/2j−1/2j+1) has Φ₁ = 2^{1/3}[Ai′(Ai+Bi) − 1/(2π)]. The O(1) offsets therefore
   do NOT match term-by-term, and the two packages split their budgets along different
   seams (F10: C_model[D_∞ + Ψ₁-part + Jac + EM + zone-(i)] + R_∞[accumulated Olver
   ε²]; ours: Ψ₀(0)[window] + S∞[deep matching]).
3. **THE PREDICTION (the audit's stage-1 deliverable):** taking F10's own convergent
   C_model_∞ = −0.577 (their decomposition, frozen) and OUR derived total
   −(3/4 + √3/(3π)) = −0.93378, the open F10 sliver is predicted:
     **R_∞ = −0.93378 − C_model_∞ = −0.3568   vs F10's measured R_∞ ≈ −0.357** —
   agreement 2e−4 (well inside their stated accuracy). Together with the frozen-CSV
   Richardson (−0.935(2), `lemmaA_prime_F10_ladder_alignment.py`) and their j = 16384
   run (−0.933): every number F10 measured is consistent with the closed form.
4. **Honest status:** this establishes *data-consistency at the 2e−3 level*, NOT yet
   equality of the two models' offsets. Because the models differ at first order, the
   equality of totals is a UNIVERSALITY statement (the peak offset is shared across
   the family) — plausible (the peak constant is EM-convention-immune, (AiBi)′(0) = 0,
   and both deep zones are the same Debye calculus), but it must be PROVEN by
   transplanting the Ψ₀ + S∞ calculus to F10's (μ−1, μ, μ+2)/2x_n-weight structure.
   That transplant is the staged stage-2 audit (one session with D2 §7 (V3)/(F9) in
   hand: compute their Ψ₀^{comp}(0) + S∞^{comp} and compare to (6+√3)/(3π) + (3/4 −
   2/π)). Alternative decisive numeric: extend OUR S_j ladder one octave (j = 2048;
   ~1–2 h mpmath run) to sharpen our extrapolation below the 1e−3 gap.

## 1. The dictionary (reference table)

| | F10 companion (frozen) | this campaign (∞ ODD) |
|---|---|---|
| system | weights 2x_n, P1 lattice (half-shift) | weights 2x_n², z_n = (n−½)π |
| object | κ_j = sup_m Σ K_j(n); E_j = κ_j − 1 | C̃_j(m) = t̃_{j+1}(m) − t̃_j(m); E_j = sup_m\|C̃\| |
| j-structure | row IS the telescope W_j − W_{j−1} | explicit Δ_j of the closure summand |
| window kernel | Φ_∞ = −4(AiBi)′(σ) | Δσ_n = 2π(AiBi)′(w)·Δw-scale |
| leading const | (1/2)∫Φ_∞ = 2·2^{−1/3}Ai(0)Bi(0) | 2^{2/3}Ai(0)Bi(0) — SAME a∞ (both derived) |
| maximizer | m*/j = 0.6366 | m* = (2/π)j — derived |
| first order | Ψ₁ = −4·2^{1/3}(AiAi′)′ (Ai-only) | Φ₁ = 2^{1/3}[Ai′(Ai+Bi) − 1/(2π)] |
| offset split | C_model_∞ + R_∞ = −0.577 − 0.357 | Ψ₀(0) + S∞ = −0.8204 − 0.1134 (signs as −sup shift) |
| offset total | −0.934 measured; "R_∞ no closed form" | **−(3/4 + √3/(3π)) = −0.93378 DERIVED** |

## 2. Stage-2 audit (staged, precise task)

Transplant the two derived calculi to the companion structure: (a) window — redo §1–§2
of FINDINGS_LEMMA_A_PRIME_offset_closed_form.md with F10's order set (μ−1, μ, μ+2),
their 1/(μ±1) split (which kills the AB-order — their telescope's own (III)-analog),
and their w_n = 2x_n weights ⇒ Ψ₀^{comp}(0); (b) deep — their projection part is
Dini-pinned in [0,1], their deep correction rows have the same j₊y₋ Debye product ⇒
σ̄^{comp} and S∞^{comp} by the same matched integral; (c) compare Ψ₀^{comp}(0) +
S∞^{comp} with (6+√3)/(3π) + (3/4 − 2/π). Outcome either way is a result: equality =
family universality of BOTH caustic constants (and F10's R_∞ closed in one line);
inequality = two displayed closed forms, and the 1e−3 data agreement was partial
coincidence (decidable against their j = 16384 point).

## 3. Manifest

Stage-1 is analysis + frozen-data reads only: `lemmaA_prime_F10_ladder_alignment.py`
(+log; previous push) and this note. Frozen inputs (read-only):
to_Ilya_CAUSTIC_THEOREM_2026-07-19/evidence/D2_progress_bessel_kernels_2026-07-19.md
§§1–3, §7 (F9)/(F10); t2_d2_kappa_full_ladder.csv.

*— Stenberg + Claude, 2026-07-23. The two packages measured the same number from
opposite sides of a telescope; the closed form −(3/4 + √3/(3π)) now sits between
them, predicting F10's open sliver to 2e−4. What remains is to prove the family
shares it.*
