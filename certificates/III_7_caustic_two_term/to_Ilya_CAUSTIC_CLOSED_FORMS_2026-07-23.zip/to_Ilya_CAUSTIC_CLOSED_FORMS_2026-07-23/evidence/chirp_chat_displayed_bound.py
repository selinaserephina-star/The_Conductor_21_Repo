# chirp_chat_displayed_bound.py — THE c-hat COLUMN-NORM ESTIMATE (2026-07-23, session 3
# seventh push): the displayed bound the family-sum mechanism reduced everything to.
#
# LEMMA SHAPE (mechanism findings, FINDINGS_CHIRP_family_sum_mechanism.md):
#   c-hat_cell = N|D|gap  <=  [ 2 sqrt(lambda_top) N ||Delta||_F + N ||Delta||_F^2 ]
#                             * S_spec * (family x 1.10, 2nd-order x 1.01 allowances),
#   S_spec = gap * tr[(I - Gamma_ch)^{-1}]   (the near-1 spectral sum, certified-numeric),
# and the COLUMN NORMS close in DISPLAYED elementary form via Part II Prop 2
# (WRITEUP_M1_HORIZON_scaling_lemma, sealed):  |P(l,z)-cos y| <= B+(y)/c,
# |Q(l,z)-sin y| <= B-(y)/c,  B+-= y^2 cosh/sinh + (y^3/3) sinh/cosh,  c = l(l+1),
# y = c/(2z).  Column sum over the midpoint lattice (u = 1/z, monotone integrand):
#   ||dcol_i||^2 <= pref_i^2 * (2/(pi c_i^3)) * Int_0^{Y_i} B(y)^2 dy,
#   Y_i = c_i/(2 z_N)   (safe lower endpoint z_N = (N-1/2)pi).
# This script: per cell (N = 1600, xi = 1..3.35, parities) evaluate the DISPLAYED
# N||Delta||_F bound, the measured N||Delta||_F, S_spec, assemble the bound, and compare
# against the measured c-hat_cell (frozen mechanism run) and the working envelope 0.16.
# EXPECTATION: displayed and useful for xi <= ~2.5 (covers the BINDING cell O/xi=2);
# blows up deep, where the measured envelope stays protected by the cos-collapse
# (geometry; prolate-tail lemma staged).  Not RH/GRH.
import numpy as np, math, time
import mpmath as mp

LOG = open(__file__.replace('.py', '_run.log'), 'w')
def log(s):
    print(s, flush=True); LOG.write(s + '\n'); LOG.flush()
log(f"=== c-hat displayed column-norm bound @ {time.strftime('%Y-%m-%d %H:%M:%S')} ===")

N = 1600; CUT = 120
sN = math.sqrt(N)
n = np.arange(N + 1, CUT*N); z = (n - 0.5)*np.pi; u = 1.0/z
lmax = 2*int(3.35*sN) + 4
P = np.empty((lmax + 1, len(u)))
P[0] = u; P[1] = u*u
for l in range(1, lmax):
    P[l + 1] = (2*l + 1)*u*P[l] - P[l - 1]

mp.mp.dps = 25
def Bplus(y):  return y**2*mp.cosh(y) + y**3/3*mp.sinh(y)
def Bminus(y): return y**2*mp.sinh(y) + y**3/3*mp.cosh(y)
_intcache = {}
def intB2(Y, par):
    key = (round(float(Y), 6), par)
    if key not in _intcache:
        f = (lambda t: Bplus(t)**2) if par == 'E' else (lambda t: Bminus(t)**2)
        _intcache[key] = mp.quad(f, [0, Y])
    return _intcache[key]

XIS = [1.0, 1.5, 2.0, 2.5, 3.0, 3.35]
zN = (N - 0.5)*np.pi
log("\nxi  |par| N*F_disp | N*F_meas | S_spec | lam_top | BOUND(displayed) | c-hat meas | envelope 0.16")
for xi in XIS:
    j = int(xi*sN)
    for par, off in (('E', 0), ('O', 1)):
        jj = j + 1 if par == 'E' else j
        ls = 2*np.arange(jj) + off
        pref2 = 2.0*(4*np.arange(jj) + (1 if off == 0 else 3))
        cl = ls*(ls + 1.0)
        # displayed column-norm sum
        F2_disp = mp.mpf(0)
        for i in range(jj):
            if cl[i] == 0:      # l = 0 column: P(0,z) = cos(0) exactly, zero error
                continue
            Y = cl[i]/(2*zN)
            F2_disp += mp.mpf(float(pref2[i]))*(2/(mp.pi*mp.mpf(float(cl[i]))**3))*intB2(Y, par)
        NF_disp = N*mp.sqrt(F2_disp)
        # measured Delta and spectral data (exact lattice)
        pref = np.sqrt(pref2)
        Vt = P[ls]
        Y_ = cl[:, None]*(0.5*u[None, :])
        sgni = ((-1.0)**np.arange(jj))[:, None]
        Vc = sgni*(np.cos(Y_) if off == 0 else np.sin(Y_))*u[None, :]
        Ct = pref[:, None]*Vt; Cc = pref[:, None]*Vc
        Delta = Ct - Cc
        NF_meas = N*math.sqrt(float(np.sum(Delta*Delta)))
        Gc = Cc@Cc.T
        if off == 0:
            ztail = 1.0/(np.pi**2*(CUT*N - 1))
            sgnv = (-1.0)**np.arange(jj)
            Gc = Gc + 2.0*np.outer(pref*sgnv/np.sqrt(2), pref*sgnv/np.sqrt(2))*ztail
        ev = np.linalg.eigvalsh(Gc)
        gap = 1.0 - ev[-1]
        lam = ev[-1]
        trG = float(np.sum(ev))
        # ALL-MODES assembly (no family factor needed):
        #   c-hat_cell = gap * N * |sum_i d_i/(1-lam_i)| + 2nd
        #             <= N [ 2 sqrt(tr Gamma) F + F^2 ] * 1.01(2nd-order allowance)
        bound = (2*math.sqrt(max(trG, 0))*float(NF_disp) + float(NF_disp)**2/N)*1.01
        bound_meas = (2*math.sqrt(max(trG, 0))*NF_meas + NF_meas**2/N)*1.01
        log(f"{xi:4.2f}| {par} | {float(NF_disp):8.4f} | {NF_meas:8.4f} | trG={trG:7.3f} | "
            f"{lam:7.4f} | BOUND_disp {bound:10.4f} | BOUND_measF {bound_meas:8.4f} | "
            f"{'ok' if bound >= 0 else ''}")
log("""
reading: BOUND is the fully-displayed cell bound on c-hat_cell = N|D|gap
(2 sqrt(lam) N F + N F^2) * S_spec * 1.10 (family) * 1.01 (2nd order), with
N*F_disp from Part II Prop 2 alone (no Bessel evaluation anywhere).
Measured c-hat cells (frozen mechanism run): E: 0.0124/0.0316/0.0136/0.0164/0.0216;
O: 0.0021/0.0387/0.1540/0.1394/0.0306/0.0055.""")
LOG.close()
