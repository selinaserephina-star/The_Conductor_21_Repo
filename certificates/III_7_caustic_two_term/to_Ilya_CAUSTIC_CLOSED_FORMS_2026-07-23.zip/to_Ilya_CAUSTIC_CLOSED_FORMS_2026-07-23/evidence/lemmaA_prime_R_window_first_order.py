# lemmaA_prime_R_window_first_order.py — LEMMA A' piece (ii) AT FIRST ORDER: the
# R-window correction DERIVED in closed Airy form and verified by collapse (2026-07-23,
# session 3 continuation).
#
# DERIVED (this session, pure expansion algebra on the per-order Olver forms; per-unit-
# order shift eps = 2^{1/3} nu^{-1/3}, orders nu+3/2 / nu-1/2 / nu-3/2, nu = 2j; all
# amplitude/prefactor corrections are O(nu^{-2/3}) so the ONLY first-order effects are
# the Airy argument shifts and the bracket's subleading terms):
#
#   (W1)  sigma_n = pi 2^{-1/3} nu^{1/3} [ (AiBi)(w) + nu^{-1/3} Phi1(w) + O(nu^{-2/3}) ],
#         Phi1(w) = 2^{1/3} [ (3/2)Ai'Bi - (1/2)AiBi' + AiAi' ](w)
#                 = 2^{1/3} [ Ai'(w)(Ai(w)+Bi(w)) - 1/(2pi) ]        (Wronskian AiBi'-Ai'Bi=1/pi)
#
#   (W2)  differencing (Delta w = 2^{4/3}nu^{-1/3}, cell h = 2^{1/3}pi nu^{-1/3}) with
#         midpoint Euler-Maclaurin (sum edge at w_m - h/2 => +(1/2)Delta-sigma(w_m) term):
#         C~_j(m) = -2^{2/3}nu^{1/3}(AiBi)(w_m) + Psi0(w_m) + S_j + O(nu^{-1/3}),
#         Psi0(w) = -2^{2/3} Phi1(w) + (pi-2)(AiBi)'(w),
#         S_j = the mid/far/deep matching constant (piece (i)+(iii) content, measured here).
#
#   (W3)  peak value CLOSED FORM: (AiBi)'(0)=0 and Phi1(0) = 2^{1/3}[Ai'(0)(Ai(0)+Bi(0)) - 1/(2pi)]
#         give  Psi0(0) = 1/pi - 2Ai'(0)(Ai(0)+Bi(0)) = (6+sqrt(3))/(3pi) = 0.8204...
#         =>  sup_m|C~_j| = a_inf (2j)^{1/3} - (6+sqrt3)/(3pi) - S_j + O(nu^{-1/3}).
#
# CHECKS: (A) pure-Airy algebra: (law2/law1 - 1)*nu^{1/3} -> Phi1/AiBi (validates the
# expansion independent of Bessel data); (B) Bessel collapse: (sigma/law1 - 1)*nu^{1/3}
# vs Phi1/AiBi at j = 256/1024 with the ratio of residuals ~ (nu'/nu)^{-1/3};
# (C) profile fits at j = 256/512/1024: R(m) = C~(m) + 2^{2/3}nu^{1/3}AiBi(w_m) - Psi0(w_m)
# should be ~constant (= S_j) over the trust window w in [-0.5, 3]; S_j reported + drift.
# Engine identical to lemmaA_prime_airy_window_law.py (validated there vs certified ladder).
# Not RH/GRH.
import mpmath as mp
import time

mp.mp.dps = 40
PI = mp.pi

# ---------------- hybrid spherical Bessel engine (as validated) ----------------
_DF = {}
def dfact(l):
    if l not in _DF:
        v = mp.mpf(1)
        for i in range(3, 2*l + 2, 2):
            v *= i
        _DF[l] = v
    return _DF[l]

def j_series(l, z):
    guard = int(0.44*float(z)) + 30
    with mp.workdps(mp.mp.dps + guard):
        zz = mp.mpf(z)
        z2 = zz*zz/2
        t = mp.mpf(1); s = mp.mpf(1); k = 0
        thr = mp.mpf(10)**(-(mp.mp.dps + 10))
        while True:
            k += 1
            t *= -z2/(k*(2*l + 1 + 2*k))
            s += t
            if abs(t) < thr*(abs(s) + 1) and 2*k > float(z):
                break
        val = s*zz**l/dfact(l)
    return +val

def rows(z, Lmax, jorders):
    with mp.workdps(80):
        zz = mp.mpf(z)
        y = [-mp.cos(zz)/zz, -mp.cos(zz)/zz**2 - mp.sin(zz)/zz]
        for l in range(1, Lmax):
            y.append((2*l + 1)/zz*y[-1] - y[-2])
        Lup = min(Lmax, int(float(z)) - 3)
        jup = None
        if any(l <= Lup for l in jorders):
            jup = [mp.sin(zz)/zz, mp.sin(zz)/zz**2 - mp.cos(zz)/zz]
            for l in range(1, Lup):
                jup.append((2*l + 1)/zz*jup[-1] - jup[-2])
    jv = {}
    for l in jorders:
        if jup is not None and l <= Lup:
            jv[l] = +jup[l]
        elif z < l:
            jv[l] = j_series(l, z)
        else:
            with mp.workdps(60):
                v = mp.sqrt(PI/(2*z))*mp.besselj(mp.mpf(l) + mp.mpf(1)/2, z)
            jv[l] = +v
    return jv, y

def sigma_pair(j, n):
    z = (2*n - 1)*PI/2
    Ls = sorted({2*j - 2, 2*j - 1, 2*j + 1, 2*j, 2*j + 3})
    jv, y = rows(z, 2*j + 4, Ls)
    def sig(jj):
        return (mp.mpf(2)/(4*jj + 1))*z**2*jv[2*jj + 1]*(
            2*(jj - 1)*jv[2*jj - 1] - z*(jv[2*jj - 2] + y[2*jj - 1]))
    return sig(j), sig(j + 1)

# ---------------- laws and derived window functions ----------------
Ai = mp.airyai; Bi = mp.airybi
Aip = lambda w: mp.airyai(w, 1); Bip = lambda w: mp.airybi(w, 1)
AiBi = lambda w: Ai(w)*Bi(w)
dAiBi = lambda w: Aip(w)*Bi(w) + Ai(w)*Bip(w)
CBRT2 = mp.cbrt(2)

def Phi1(w):
    return CBRT2*(Aip(w)*(Ai(w) + Bi(w)) - 1/(2*PI))

def Psi0(w):
    return -2**(mp.mpf(2)/3)*Phi1(w) + (PI - 2)*dAiBi(w)

def wof(j, n):
    nu = mp.mpf(2*j); z = (2*n - 1)*PI/2
    return CBRT2/mp.cbrt(nu)*(nu - z)

def law1(j, n):
    nu = mp.mpf(2*j)
    return PI/CBRT2*nu**(mp.mpf(1)/3)*AiBi(wof(j, n))

def law2(j, n):
    z = (2*n - 1)*PI/2
    c = mp.sqrt(PI/(2*z))
    def A_(l):
        nl = l + mp.mpf(1)/2
        return c*mp.cbrt(2/nl)*Ai(CBRT2*nl**(-mp.mpf(1)/3)*(nl - z))
    def B_(l):
        nl = l + mp.mpf(1)/2
        return c*mp.cbrt(2/nl)*Bi(CBRT2*nl**(-mp.mpf(1)/3)*(nl - z))
    return (mp.mpf(2)/(4*j + 1))*z**2*A_(2*j + 1)*(
        2*(j - 1)*A_(2*j - 1) - z*(A_(2*j - 2) - B_(2*j - 1)))

print("closed forms:")
print(f"  Phi1(0)  = {mp.nstr(Phi1(0), 8)}")
p0 = (6 + mp.sqrt(3))/(3*PI)
print(f"  Psi0(0)  = {mp.nstr(Psi0(0), 10)}   vs (6+sqrt3)/(3pi) = {mp.nstr(p0, 10)}   "
      f"dev = {mp.nstr(Psi0(0) - p0, 3)}")
print(f"  Psi0(+inf) -> 2/pi = {mp.nstr(2/PI, 6)} (deep-side plateau)")

# ---------------- Part A: pure-Airy algebra check ----------------
print("\n== Part A: (law2/law1 - 1)*nu^(1/3) vs Phi1/AiBi  [pure Airy algebra, j=1024] ==")
j = 1024; nu13 = mp.mpf(2*j)**(mp.mpf(1)/3)
mstar = round(2*j/PI)
print("    n  |    w    | (l2/l1-1)nu^(1/3) | Phi1/AiBi | dev")
for n in range(mstar - 10, mstar + 6, 3):
    w = wof(j, n)
    d = (law2(j, n)/law1(j, n) - 1)*nu13
    p = Phi1(w)/AiBi(w)
    print(f"  {n:4d} | {mp.nstr(w, 4):>7s} | {mp.nstr(d, 6):>13s} | {mp.nstr(p, 6):>9s} | "
          f"{mp.nstr(d - p, 3)}")

# ---------------- Part B: Bessel collapse at j = 256 / 1024 ----------------
print("\n== Part B: Bessel collapse (sigma/law1 - 1)*nu^(1/3) vs Phi1/AiBi ==")
t0 = time.time()
for j in (256, 1024):
    nu13 = mp.mpf(2*j)**(mp.mpf(1)/3)
    mstar = round(2*j/PI)
    span = 9 if j == 256 else 13
    print(f"-- j={j} --")
    print("    n  |    w    | measured D | Phi1/AiBi | resid (=O(nu^-1/3)*Phi2-ratio)")
    for n in range(mstar - span, mstar + span//2, max(2, span//4)):
        w = wof(j, n)
        if float(w) < -0.9:
            continue
        s, _ = sigma_pair(j, n)
        D = (s/law1(j, n) - 1)*nu13
        p = Phi1(w)/AiBi(w)
        print(f"  {n:4d} | {mp.nstr(w, 4):>7s} | {mp.nstr(D, 6):>10s} | {mp.nstr(p, 6):>9s} | "
              f"{mp.nstr(D - p, 4)}")
print(f"  ({time.time()-t0:.0f}s)")

# ---------------- Part C: profile fits — Psi0 + S_j ----------------
print("\n== Part C: C~ profile vs -2^(2/3)nu^(1/3)AiBi + Psi0 + S_j  (S_j = fitted const) ==")
for j in (256, 512, 1024):
    t0 = time.time()
    nu = mp.mpf(2*j)
    mstar = round(2*j/PI)
    NPRO = mstar + 45
    acc = mp.mpf(0); Ct = [mp.mpf(0)]*(NPRO + 1)
    for n in range(1, NPRO + 1):
        s0, s1 = sigma_pair(j, n)
        acc += s1 - s0
        Ct[n] = acc
    sup = max(range(1, NPRO + 1), key=lambda m: abs(Ct[m]))
    # R(m) = C~ + 2^{2/3}nu^{1/3}AiBi - Psi0  -> S_j on the trust window w in [-0.5, 3]
    Rs = []
    for m in range(1, NPRO + 1):
        w = wof(j, m)
        if -mp.mpf(1)/2 <= w <= 3:
            R = Ct[m] + 2**(mp.mpf(2)/3)*mp.cbrt(nu)*AiBi(w) - Psi0(w)
            Rs.append((m, w, R))
    S = sum(r for _, _, r in Rs)/len(Rs)
    spread = max(abs(r - S) for _, _, r in Rs)
    print(f"-- j={j}: sup|C~| = {mp.nstr(abs(Ct[sup]), 8)} @ m*={sup}; "
          f"S_j = {mp.nstr(S, 4)} +- {mp.nstr(spread, 2)} over {len(Rs)} atoms (w in [-0.5,3])")
    for m, w, R in Rs[::max(1, len(Rs)//7)]:
        print(f"     m={m:4d}  w={mp.nstr(w, 4):>7s}  R = {mp.nstr(R, 4)}")
    # derived-peak comparison
    pk = 2**(mp.mpf(2)/3)*mp.cbrt(nu)*AiBi(0) - p0 - S
    print(f"   derived sup (a_inf nu^(1/3) - (6+sqrt3)/(3pi) - S_j) = {mp.nstr(pk, 6)}   "
          f"measured {mp.nstr(abs(Ct[sup]), 6)}   dev = {mp.nstr(pk - abs(Ct[sup]), 3)}")
    print(f"   ({time.time()-t0:.0f}s)")
print("\ndone.")
