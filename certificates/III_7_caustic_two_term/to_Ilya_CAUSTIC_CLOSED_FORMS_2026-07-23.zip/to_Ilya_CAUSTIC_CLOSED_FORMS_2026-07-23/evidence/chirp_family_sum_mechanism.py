# chirp_family_sum_mechanism.py — THE c-hat FAMILY-SUM MECHANISM (2026-07-23, session 3
# fifth push; the near-1 family-sum sequel lemma of FINDINGS_CHIRP_true_kernel_verdict).
#
# QUESTION: N*D_chirp ~ c-hat/gap with c-hat <= 0.16 measured stable — WHY? Per-mode
# anti-alignment is proven (FH), but the family sum's law had no mechanism.
#
# THIS SCRIPT establishes, on the exact lattice Grams (N = 1600, cut 120N):
#  (A) BUDGET: N*D = [1st-order top channel] + [1st-order rest-of-family] + [2nd order]
#      + resid — identifying the carrier cell by cell (expectation from the frozen
#      tables: the top channel N<v,DG v>/gap carries 75-100%).
#  (B) FACTORIZATION: with C_t = diag(pref)Vt, C_c = diag(pref)Vc (column/lattice form,
#      G = C C^T), Delta = C_t - C_c:
#        <v_top, DG v_top> = 2 p.q + ||q||^2,   p := C_c^T v_top,  q := Delta^T v_top
#      — the anti-alignment is the GEOMETRY of two lattice vectors: ||q|| small (the
#      error columns nearly miss v_top) and p.q with cancellation. Reported: ||p||,
#      ||q||, p.q, cos angle, and the per-mode profile |v_i * <delta-col_i, .>| that
#      shows WHICH columns carry q (expectation: the near-edge i ~ j, where the chirp
#      y-expansion is worst — the growth law of c-hat(xi)).
#  (C) THE MECHANISM LAW: c-hat_cell = N*|<v,DGv>|/gap vs N*(2 p.q + q.q)/gap (exact
#      identity check) and the envelope shape c-hat <= 2N ||p|| ||q|| /gap * |cos| —
#      the displayed-bound route for the sequel lemma.
# Not RH/GRH.
import numpy as np, math, time

LOG = open(__file__.replace('.py', '_run.log'), 'w')
def log(s):
    print(s, flush=True); LOG.write(s + '\n'); LOG.flush()
log(f"=== chirp family-sum mechanism @ {time.strftime('%Y-%m-%d %H:%M:%S')} ===")

N = 1600; CUT = 120
sN = math.sqrt(N)
n = np.arange(N + 1, CUT*N); z = (n - 0.5)*np.pi; u = 1.0/z
lmax = 2*int(3.35*sN) + 4
t0 = time.time()
P = np.empty((lmax + 1, len(u)))
P[0] = u; P[1] = u*u
for l in range(1, lmax):
    P[l + 1] = (2*l + 1)*u*P[l] - P[l - 1]
log(f"lattice values built ({time.time()-t0:.0f}s; {len(u)} atoms, lmax={lmax})")

XIS = [1.0, 1.5, 2.0, 2.5, 3.0, 3.35]
log("\n== (A) BUDGET + (B) FACTORIZATION per cell ==")
log("xi  |par|  N*D exact | 1st top  | 1st fam  | 2nd ord  | resid   | gap      | c-hat cell")
prof_cells = {}
for xi in XIS:
    j = int(xi*sN)
    for par, off in (('E', 0), ('O', 1)):
        jj = j + 1 if par == 'E' else j
        ls = 2*np.arange(jj) + off
        pref = np.sqrt(2.0*(4*np.arange(jj) + (1 if off == 0 else 3)))
        Vt = P[ls]
        cl = ls*(ls + 1.0)
        Y = cl[:, None]*(0.5*u[None, :])
        sgni = ((-1.0)**np.arange(jj))[:, None]
        Vc = sgni*(np.cos(Y) if off == 0 else np.sin(Y))*u[None, :]
        Ct = pref[:, None]*Vt
        Cc = pref[:, None]*Vc
        if off == 0:
            ztail = 1.0/(np.pi**2*(CUT*N - 1))
            sgnv = (-1.0)**np.arange(jj)
            tails = 2.0*np.outer(pref*sgnv/np.sqrt(2), pref*sgnv/np.sqrt(2))*ztail
        else:
            tails = 0.0
        Gt = Ct@Ct.T + tails
        Gc = Cc@Cc.T + tails
        _, ldt = np.linalg.slogdet(np.eye(jj) - Gt)
        _, ldc = np.linalg.slogdet(np.eye(jj) - Gc)
        ND = N*(ldt - ldc)
        ev, evec = np.linalg.eigh(Gc)
        gap = 1.0 - ev[-1]
        DG = Gt - Gc
        R = evec@np.diag(1.0/(1.0 - ev))@evec.T
        d = np.array([evec[:, i]@(DG@evec[:, i]) for i in range(jj)])
        first_all = -N*np.sum(d/(1.0 - ev))
        first_top = -N*d[-1]/gap
        fam = (1.0 - ev < 0.5)
        first_fam = -N*np.sum((d/(1.0 - ev))[fam]) - first_top*0 - (-N*d[-1]/gap)
        M2 = R@DG
        second = -0.5*N*np.trace(M2@M2)
        resid = ND - first_all - second
        chat = abs(ND)*gap
        log(f"{xi:4.2f}| {par} | {ND:+9.4f} | {first_top:+8.4f} | {first_fam:+8.4f} | "
            f"{second:+8.4f} | {resid:+7.4f} | {gap:.2e} | {chat:.4f}")
        # (B) factorization for the top mode
        v = evec[:, -1]
        p = Cc.T@v; q = (Ct - Cc).T@v
        pq = float(p@q); nq = float(np.sqrt(q@q)); npv = float(np.sqrt(p@p))
        dtop_fact = 2*pq + nq*nq
        cosang = pq/(npv*nq) if nq > 0 else 0.0
        # per-mode carrier profile of q: q = sum_i v_i * deltacol_i
        contrib = np.abs(v)*np.sqrt(np.sum((Ct - Cc)**2, axis=1))
        topi = np.argsort(contrib)[-3:][::-1]
        prof_cells[(xi, par)] = (v, Ct, Cc, contrib)
        log(f"      factorize: d_top = {d[-1]:+.3e} vs 2p.q+q.q = {dtop_fact:+.3e} "
            f"(id-check {abs(d[-1]-dtop_fact):.1e}); ||p|| = {npv:.4f}, ||q|| = {nq:.2e}, "
            f"cos = {cosang:+.3f}; top q-carrier modes i = {list(topi)} of {jj-1} "
            f"(near-edge frac {topi[0]/(jj-1):.2f})")

log("\n== (C) the envelope shape: c-hat_cell vs 2N||p||||q||/gap (Cauchy-Schwarz of the channel) ==")
log("xi  |par| c-hat cell | 2N||p||||q||*gap^-1*gap = 2N||p||||q|| |  used |cos|")
for xi in XIS:
    j = int(xi*sN)
    for par in ('E', 'O'):
        v, Ct, Cc, contrib = prof_cells[(xi, par)]
        p = Cc.T@v; q = (Ct - Cc).T@v
        npv = float(np.sqrt(p@p)); nq = float(np.sqrt(q@q)); pq = float(p@q)
        env = 2*N*npv*nq + N*nq*nq
        log(f"{xi:4.2f}| {par} |  (from A)  |  {env:10.4f}  |  {abs(pq)/(npv*nq) if nq>0 else 0:.3f}")
log("\ndone.")
LOG.close()
