# WRITE-UP — the conditioning corollary COMPOSED: derived localization majorant × field-class pairing = the layer-window statement, uniform in j

**Merkabit · Stenberg + Claude · 2026-07-23 (session 3, fourth push — the campaign the
bird's-eye ranked first: F11 pairing × the derived caustic law ⇒ the re-scoped §4
corollary of WRITEUP_XI_LIMIT_layer_form_gamma.md). Model lattice ∞ ODD system,
conventions of FINDINGS_LEMMA_A_PRIME_caustic_constant_derived.md /
_offset_closed_form.md. Scripts + logs §5. Not RH/GRH.**

## 0. What is being composed, and the statement

The Abel/κ̂ machinery's one unproven-uniform component is the excess pairing: the
derivative-row functional ⟨Δrow_j, b⟩ = Σ_n Δ_jσ_n·b_n against transport/layer fields
b. Raw Abel pays sup_m|C̃_j(m)|·TV(b) ~ a∞μ^{1/3}·TV — unbounded in j (the refuted §4
claim). The two halves that fix it are now BOTH in hand: the derived caustic profile
(localization) and the field class (the fields the machinery meets have decaying TV
density). Composed:

**LEMMA C1 (derived localization majorant).** For all (j, m), with w_m =
2^{1/3}ν^{−1/3}(ν − z_m), ν = μ = 2j:
  |C̃_j(m)| ≤ Ψ_j(m) := min( a∞μ^{1/3} + ½ ,  B₀ + a_w·μ^{1/3}|w_m|^{−1/2} ),
  a_w = 2^{2/3}·1.10/(2π) = 0.27788,  B₀ = [fitted minimal, §4 — zero violations].
The CAP is the certified-data theorem candidate (ball-verified j ≤ 1024, margin
≥ 0.84; derived asymptote a∞μ^{1/3} − 0.9338). The WING follows from the derived
profile C̃ = −2^{2/3}ν^{1/3}(AiBi)(w) + Ψ₀(w) + S_j + O(ν^{−1/3}) and the Airy-product
envelope |AiBi(w)| ≤ min(AiBi(0), 1.10/(2π√|w|)) (grid-verified §4; asymptotic
amplitude 1/(2π√|w|)). F11's companion-model majorant (fitted, 0 violations at
j ≤ 4096) had the same shape with wing constant 0.561·μ^{1/3}|w|^{−1/2} — ours is
2.0× tighter and derived, and F11's independent fit is a cross-model confirmation of
the shape.

**LEMMA C2 (pairing).** Summation by parts, for any b of bounded variation supported
on m ≤ M: |⟨Δrow_j, b⟩| ≤ Σ_m |Δb_m|·Ψ_j(m) + |C̃_j(M)||b_M|. For QUANTILE-CLASS
fields (|Δb_n| ≤ C_b·n^{−3/2} — the F12 shape τ ≤ u_n(sup|ΔS| + (q/n)sup|S|),
u_n ≤ C_geo n^{−2}, measured exponent 2.36 on the production field):
  window term  Σ_{|w_n|≤W} (a∞μ^{1/3} + ½)|Δb| ≤ a∞π^{3/2}C_b·μ^{−5/6}·(1 + o(1)),
  wing term    Σ_{off-window} a_wμ^{1/3}|w_n|^{−1/2}|Δb| = O(C_b·μ^{−1/2}),
  bulk term    B₀·TV(b),
hence
  **|⟨Δrow_j, b⟩| ≤ B₀·TV(b) + O(C_b·μ^{−1/2}) — uniform in j; μ^{1/3} appears
  nowhere, and the caustic's own contribution DECAYS like μ^{−5/6}.**
SHARPNESS (unchanged from F11, now with derived value): a unit step AT m* pays
exactly |C̃_j(m*)| = a∞μ^{1/3} − 0.934 + o(1) — the condition is genuinely on the
field class, not the kernels.

**COROLLARY (the re-scoped §4 sentence).** On layer windows, the Abel/κ̂ machinery
meets smooth layer/transport fields of quantile class; for these the excess pairing
is ≤ B₀·TV + o(1), uniform in the mode index j, the atom cut, and the window. The
μ^{1/3} caustic growth is real but confined to a moving O(μ^{1/3})-atom window at
m* = (2/π)j that quantile-class variation cannot chase. [This replaces the refuted
"excess ≤ 1/gap uniform" of §4; together with the proven ĉ-side (Σĉ² ≤ 1) it is the
conditioning input the Abel/κ̂ machinery needs on layer windows.]

## 1. Proof of C1 (grades itemized)

(i) The cap: certified-data (ball ladder j ≤ 1024, all radii 0) + the derived
asymptote (both constants closed-form) — the sup never reaches a∞μ^{1/3} + ½, with
margin ≥ 0.84 measured and 1.43 asymptotic. (ii) The wing: on the window and
oscillatory side, the derived profile bounds |C̃| ≤ 2^{2/3}ν^{1/3}|AiBi(w)| + |Ψ₀(w)|
+ |S_j| + resid; the envelope lemma (§4, grid + asymptotic amplitude) converts the
first term to a_wμ^{1/3}|w|^{−1/2}·(1/1.10 headroom); B₀ absorbs sup|Ψ₀| + S + resid
— fitted minimal against the computed profiles, ZERO violations required (§4). On the
deep side the exact closed form D(z) = −(1/π)[c/s − (3/2)arcsin c + cs/2] is
monotone-small (≤ 1/(πs) ≤ wing). Mid/far side beyond the computed range: |C̃| is
O(1)-bounded by the zone laws (Debye mean q−1 ∈ [−1,0], far x²-law tiny, coherent
bits ≤ 1-ish) — B₀ covers it; grade for that stretch = zone-law + certified-data.

## 2. Proof of C2 (elementary, complete given C1)

Summation by parts is an identity; the class arithmetic: the window |w_n| ≤ W spans
≤ 2W·2^{−1/3}ν^{1/3}/π + 1 atoms centered at n* = (2/π)j, where |Δb_n| ≤
C_b·((2/π)j)^{−3/2}(1+o(1)); product with the cap gives a∞π^{3/2}C_b μ^{−5/6}(1+o(1)).
The wing: Σ_{k≥1}(k·2^{1/3}πν^{−1/3})^{−1/2}·C_b(n*±k)^{−3/2} ≤ C_b·O(ν^{1/6}·n*^{−1})
= O(C_b μ^{−5/6}·μ^{... }) ≤ O(C_bμ^{−1/2}) crude. Bulk: Σ|Δb|·B₀ = B₀·TV. ∎

## 3. What this does and does not claim

DOES: give the uniform-in-j conditioning statement for the field class the machinery
meets, with displayed constants (B₀, a_w, the cap) and a decaying caustic term; make
the F11 tolerance mechanism a lemma with derived constants; keep the sharpness honest
(step-at-caustic pays the full μ^{1/3}). DOES NOT: restore the refuted operator-norm
uniform bound (impossible); prove the field-class membership of every production
field — that is F12's u-decay lemma (classical monotone calculus; offered in the F10
menu, unassigned) plus the two certified S-scalars; close the O(ν^{−1/3}) profile remainders
at displayed-envelope grade (the standing LEMMA A′ envelope campaign — the majorant
is verified pointwise on ball-anchored data precisely to be usable before that
lands).

## 4. Verification (run of `lemmaA_prime_conditioning_composition.py`)

- **Envelope:** |AiBi(w)|/env ≤ 0.99979 over the grid |w| ≤ 400 (step 0.02), max at
  the trivial w → 0 point — PASS everywhere (asymptotic amplitude 1/(2π√|w|); the
  1.10 factor covers corrections with room).
- **Minimal B₀ (zero violations):** need = 0.28784 over all three profiles →
  **B₀ = 0.29** displayed; final check 0 violations, min margin 0.0022 over 1276
  (j,m) points (j = 256/512/1024, m through m* + 45). [F11's companion-model bulk
  floor was 1; ours is 0.29 — 3.4× tighter, and the wing 2.0× tighter.]
- **Pairing demos (TV = 1 fields):**

  | field | true (j=256/512/1024) | ⟨Ψ,\|Δb\|⟩ bound | raw Abel |
  |---|---|---|---|
  | ramp | 0.019 / 0.023 / 0.055 | 0.850 / 0.858 / 0.849 | 1.89 / 2.60 / 3.51 |
  | quantile n^{−3/2} | 1.4e−4 / 9.4e−4 / 1.1e−3 | **0.556 / 0.550 / 0.546** | 1.89 / 2.60 / 3.51 |
  | tapered sine (λ ≈ μ^{1/3}) | 0.033 / 0.027 / 0.019 | 0.852 / 0.858 / 0.849 | 1.89 / 2.60 / 3.51 |
  | step @ m* | 1.8903 / 2.6029 / 3.5071 | 3.27 / 3.99 / 4.90 | 1.89 / 2.60 / 3.51 |

  The quantile-class bound is j-UNIFORM (slightly decreasing) while raw Abel grows
  like μ^{1/3}; the true pairings sit further below (in-window sign cancellation on
  top of localization — the same 5.9× reserve F11 saw in production). The step field
  pays exactly sup|C̃| — sharpness as stated.
- **Window-term decay** (quantile class, C_b = 1): a∞π^{3/2}μ^{−5/6} = 0.0107 /
  0.0034 / 0.0011 / 0.00033 at j = 256/1024/4096/16384.

## 5. Manifest

| script | log | what it establishes |
|---|---|---|
| `lemmaA_prime_conditioning_composition.py` | `lemmaA_prime_conditioning_composition_run.log` | envelope grid check; profiles cached (`lemmaA_prime_profiles_cache.csv`); minimal B₀ zero-violation fit; pairing demos + window-term decay |

Frozen inputs (read-only): to_Ilya_CAUSTIC_THEOREM_2026-07-19 (F11 majorant/pairing
formalism, F12 field class); WRITEUP_XI_LIMIT_layer_form_gamma.md §4 (the re-scoped
target); the two session-3 FINDINGS (derived profile and constants).

*— Stenberg + Claude, 2026-07-23. The caustic grows like μ^{1/3} and it does not
matter: it lives in a window the fields can't follow, and everything else is B₀.*
