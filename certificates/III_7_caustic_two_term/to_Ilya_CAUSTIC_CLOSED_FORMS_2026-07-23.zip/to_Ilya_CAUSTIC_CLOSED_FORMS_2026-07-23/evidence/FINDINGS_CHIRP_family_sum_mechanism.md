# FINDINGS — the ĉ family-sum MECHANISM: a top-resolvent channel with two anti-alignment layers, column-factorized

**Merkabit · Stenberg + Claude · 2026-07-23 (session 3, fifth push — the "near-1
family-sum lemma" companion task of the LEMMA A′ list; sequel to
FINDINGS_CHIRP_true_kernel_verdict.md). Exact lattice Grams, N = 1600, cut 120N,
ξ = 1…3.35, both parities. Script + log §4. Not RH/GRH.**

## 0. Executive verdict

1. **The family-sum law N·D_chirp ≈ ĉ/gap now has its mechanism, measured at every
   cell.** Exact budget of N·D = N·Δlndet into [first-order top channel] +
   [first-order rest-of-near-1-family] + [second order] + resid: on every reliable
   cell the FIRST-ORDER near-1 family carries the total — the top channel alone
   74–100% (100% at ξ ≤ 2, thickening to 2–3 modes at ξ ≥ 3: O/3.35: top −6.27 +
   family −3.52 = 95% of −10.32), second order ≤ 0.025 throughout the O-range.
   There is no hidden higher-order carrier.
2. **The top channel factorizes EXACTLY through the error columns** (identity check
   1e-17): with C = diag(pref)·V (Gram = CCᵀ), Δ = C_true − C_chirp:
     ⟨v_top, ΔΓ v_top⟩ = 2·p·q + ‖q‖²,   p := C_chirpᵀ v_top,  q := Δᵀ v_top,
   and **‖p‖ = √λ_top ≤ 1 exactly** (‖p‖² = ⟨v, Γ_ch v⟩). ‖q‖² is negligible
   (≤ 1e-8), so N·D ≈ −2N·(p·q)/gap and
     **ĉ_cell = |N·D|·gap ≈ 2N·|p·q| ≤ 2N·√λ_top·‖q‖·|cos∠(p,q)|.**
3. **Two anti-alignment layers, and they explain the ĉ(ξ) hump:**
   - *Layer 1 — the column miss:* ‖q‖ = ‖Δᵀv_top‖ is tiny (5.5e-6 → 1.2e-4 across
     the range): the chirp column errors nearly miss the top mode. q is carried by
     the NEAR-EDGE columns (top carrier index / j = 0.65…1.00 at every cell) — the
     atoms where the chirp y-expansion is worst. N‖q‖ grows with ξ (0.0087 → 0.19):
     this is the RISE of ĉ toward its ξ = 2 peak.
   - *Layer 2 — deep decoherence:* cos∠(p, q) collapses with depth: +0.92-ish at
     ξ ≤ 2 (both parities), then 0.70 → 0.06 → 0.009 (O) — past ξ = 2.5 the top
     mode's lattice profile decouples from the error direction. This is the FALL of
     ĉ after the peak (0.154 → 0.031 → 0.0055) — the deep cells are protected by
     geometry, not by smallness of the error.
   - The binding cell (O, ξ = 2, ĉ = 0.154) is exactly where N‖q‖ has grown large
     (0.109) while cos is still 0.93: the Cauchy–Schwarz cap 2N‖p‖‖q‖ = 0.164 is
     TIGHT there (margin 6%).
4. **The sequel lemma is now posed as a classical estimate, no spectral mystery
   left:** ĉ ≤ 2N·sup_cells ‖Δᵀv_top‖·√λ_top + [family thickening ≤ 1.35× deep,
   measured] + [second order ≤ 1%]. Bounding ‖Δᵀv_top‖ ≤ Σ_i |v_top,i|·‖δcol_i‖
   needs only the EXPLICIT Part II Prop 1/2 chirp remainders (y⁴/c-class) on the
   near-edge columns — one column-norm estimate with certified inputs. Until that
   lands, ĉ = 0.16 stays measured-envelope grade but now MECHANISM-IDENTIFIED
   (the displayed value is unchanged; its proof surface shrank to one lemma).
5. **Cautions carried forward:** E-parity cells at ξ ≥ 2.5 remain flagged
   (truncation-limited; at ξ = 3.35 the chirp Gram loses contraction, gap < 0 —
   budget meaningless there, excluded as before). The "1st fam" budget column reads
   −first_top at shallow cells where the near-1 mask (1−λ < 0.5) is empty —
   bookkeeping artifact, noted so nobody re-reads it as a cancellation.

## 1. Measured tables (from `chirp_family_sum_mechanism_run.log`)

Budget, O-parity (reliable throughout): N·D exact vs 1st-top:
−0.0022/−0.0022, −0.0464/−0.0465, −0.3552/−0.3524, −1.584/−1.446, −5.154/−3.790
(+fam −1.312), −10.317/−6.273 (+fam −3.522) at ξ = 1/1.5/2/2.5/3/3.35;
second order −0.0000/−0.0000/−0.0000/−0.0007/−0.0064/−0.0248.

Factorization (O): ‖p‖ = 0.134/0.408/0.753/0.955/0.997/0.9997 (= √λ_top ✓);
‖q‖ = 5.5e-6/3.2e-5/6.8e-5/6.0e-5/1.1e-4/1.2e-4; cos∠ = +0.916/+0.917/+0.932/
+0.700/+0.062/+0.009; near-edge carrier fraction 1.00/1.00/0.91/1.00/0.86/0.78.

Cauchy–Schwarz cap 2N‖p‖‖q‖ vs ĉ_cell (O): 0.0023/0.042/0.164/0.182/0.36/0.37 vs
0.0021/0.039/0.154/0.139/0.031/0.0055 — tight at the binding cells, 10–70× slack
deep (the cos collapse is the deep reserve). E-parity binding range (ξ ≤ 2):
ĉ_E ≤ 0.032, same structure (cos 0.75/0.78/0.19).

## 2. What this changes upstream

- Part II B(ξ)/C2: the displayed chirp constant ĉ = 0.16 is UNCHANGED; its grade
  improves from measured-envelope to mechanism-identified-envelope. The remaining
  proof step is named: the near-edge column-norm estimate (classical, certified
  inputs), replacing "why does the family sum stay small?" (answered).
- The deep-horizon budget e^{1.9L}·ĉ keeps its shape; the new datum is that the
  deep cells are geometry-protected (cos ≤ 0.06 at ξ ≥ 3), so if a future
  application needs deep slack, the cos-collapse is the quantity to prove
  (prolate-tail asymptotics again — same family as the §4c anti-alignment lemma).
- Dead end recorded: do NOT model ΔΓ as an effective band-dilation
  (ΔL_eff·dΓ/dL) — the uniform-shift picture predicts polynomial N·D and is
  refuted by the 1/gap data; the carrier is the near-edge column residual, which
  is NOT in the band-flow direction.

## 3. The posed lemma (for the record)

**LEMMA (ĉ column-norm bound; to prove).** For X ∈ {E, O}, ξ in the reliable range,
with v the top eigenvector of Γ_ch(L*): N‖Δᵀv‖ ≤ N·max_i ‖δcol_i‖_w·Σ|v_i| with
δcol_i the Prop-1/2 chirp remainder columns; the Part II remainder envelopes
(y⁴/c, y⁴/c² classes with c_l = 2πN L_i) give N‖δcol_i‖_w ≤ [explicit],
near-edge-dominated; conclude ĉ ≤ 2·sup(N‖Δᵀv‖) + 1.35× family + 1% second-order
allowances. Target: reproduce ĉ ≤ 0.16 with a displayed constant.

## 4. Manifest

`chirp_family_sum_mechanism.py` + `chirp_family_sum_mechanism_run.log`: budget
decomposition (exact lndet vs 1st/2nd order, per cell), the p/q factorization with
identity checks, carrier profiles, Cauchy–Schwarz caps. Inputs re-derived exactly as
`chirp_true_kernel_overlap.py` (same lattice recurrences, same (−1)^i phase, same
shared-tail handling); frozen references read-only.

*— Stenberg + Claude, 2026-07-23. The family sum is one resolvent channel wide; the
error sneaks in through the last few columns and, past ξ = 2.5, forgets how to point
at the top mode.*
