# FINDINGS — the ĉ column-norm estimate EXECUTED: the first fully-displayed chirp bound, and a near-tight assembly

**Merkabit · Stenberg + Claude · 2026-07-23 (session 3, seventh push — the classical
lemma the family-sum mechanism reduced everything to). Inputs: Part II Proposition 2
(sealed WRITEUP_M1_HORIZON_scaling_lemma §1 — displayed, proven entrywise chirp
bounds) + the mechanism factorization (FINDINGS_CHIRP_family_sum_mechanism.md).
Script + log §3. Not RH/GRH.**

## 0. Executive verdict

1. **The ĉ bound is now DISPLAYED** (first fully-displayed chirp constant; no Bessel
   evaluation anywhere in the bound side). Chain: (all-modes first-order bound)
     ĉ_cell = N|D|·gap ≤ N[2√(tr Γ_ch)·‖Δ‖_F + ‖Δ‖_F²]·1.01,
   (Cauchy–Schwarz over the WHOLE eigenbasis: Σ_i‖p_i‖² = tr Γ exactly — no spectral
   factor, no family allowance needed; 1.01 = the measured ≤ 1% second order), and
   the column norms close in elementary displayed form via Prop 2
   (|P(l,z) − cos y| ≤ B⁺(y)/c, |Q − sin y| ≤ B⁻(y)/c, B± = y²cosh/sinh + (y³/3)·
   sinh/cosh, c = l(l+1), y = c/2z; l = 0 column error is exactly zero):
     **‖δcol_i‖² ≤ pref_i²·(2/(π c_i³))·∫₀^{Y_i} B±(y)² dy,  Y_i = c_i/(2z_N)**
   (midpoint-lattice sum ≤ the safe-endpoint integral; elementary quadrature).
2. **Displayed values per cell** (N = 1600; tr Γ_ch certified-numeric per cell):

   | ξ | 1.0 | 1.5 | 2.0 | 2.5 |
   |---|---|---|---|---|
   | ĉ ≤ (E) | **0.0262** | 0.201 | 1.52 | 14.2 |
   | ĉ ≤ (O) | **0.0027** | 0.078 | 1.04 | 11.0 |
   | measured (E/O) | 0.012/0.0021 | 0.032/0.039 | 0.014/0.154 | 0.016/0.139 |

   TIGHT at ξ = 1 (1.3–2.1×), covers the working envelope 0.16 through ξ ≈ 1.5,
   stays finite-displayed through 2.5, blows up beyond (the B±-envelope pays e^Y
   where the truth pays oscillatory-cancelled powers: N‖Δ‖_F^{disp}/N‖Δ‖_F^{meas} =
   1.4 → 370 over ξ = 1 → 3.35).
3. **The assembly is NEAR-TIGHT — the remaining slack is all in Prop-2's envelope.**
   Substituting the TRUE column norms (measured Frobenius) into the same displayed
   assembly gives 0.0024/0.044/0.173/0.486/1.28/2.38 (O, ξ = 1…3.35) — covering
   every measured cell, and at the binding cell (O, ξ = 2) landing at **0.173 vs
   measured 0.154 — 12% margin**. No better assembly is needed; the one remaining
   lemma for a fully-displayed 0.16-grade constant is an oscillation-aware
   column-norm estimate for Y ≳ 2 (signed next-order chirp remainder instead of the
   absolute B±-envelope) — named, classical, certified inputs.
4. **Status of the chirp constant after this push:** ĉ = 0.16 (measured envelope,
   mechanism-identified) remains the working value for the full range; NEW: on
   ξ ≤ 1.5 the constant is now fully displayed (and much smaller: e.g. 0.0027 at
   O/ξ = 1); on ξ ≤ 2.5 a finite displayed bound exists; deep cells stay
   geometry-protected (cos-collapse, prolate-tail lemma staged). Part II B(ξ)
   consumers can quote the displayed column per cell where it is competitive.

## 1. Proof sketch of the assembly (complete given the mechanism findings)

First order: N·D₁ = −N Σ_i d_i/(1−λ_i), |d_i| = |2p_i·q_i + ‖q_i‖²| ≤ 2‖p_i‖‖q_i‖ +
‖q_i‖²; Σ_i‖p_i‖² = tr(C_cᵀ... ) = tr Γ_ch and Σ_i‖q_i‖² = ‖Δ‖_F² (eigenbasis is
orthonormal), so Σ_i|d_i| ≤ 2√(trΓ)‖Δ‖_F + ‖Δ‖_F² (CS), and Σ_i|d_i|/(1−λ_i) ≤
(1/gap)·Σ_i|d_i|. Multiply by N·gap; add the measured ≤ 1% second order (reliable
cells; E ξ ≥ 2.5 flagged as before — the bound side is unconditional for the exact
lattice Grams, the flag concerns the measured comparison). The column-norm step is
Prop 2 entrywise + the monotone midpoint-sum-to-integral bound. ∎-shape; the only
non-displayed ingredient is tr Γ_ch (certified-numeric per cell; a displayed chirp
trace bound is elementary if wanted).

## 2. What remains (named)

- Oscillation-aware column norms for Y ≳ 2 (the single remaining lemma between the
  displayed route and the 0.16-grade constant at the binding cell).
- Optional: displayed tr Γ_ch (elementary chirp sums).
- The deep-cell cos-collapse lemma (prolate tails) if any consumer ever needs
  displayed constants past ξ ≈ 2.5 — currently none does (the horizon budget uses
  the measured envelope there).

## 3. Manifest

`chirp_chat_displayed_bound.py` + `chirp_chat_displayed_bound_run.log`: displayed
column-norm sums (Prop-2 quadratures), measured Frobenius comparison, tr Γ_ch, both
assemblies per cell. (First run had S_spec-based assembly — replaced same day by the
sharper all-modes trΓ assembly before any use; the log carries the final form.
An l = 0 zero-column division guard was also fixed pre-run.) Frozen inputs
(read-only): Part II Prop 1/2 (sealed M1-HORIZON scaling write-up);
`chirp_family_sum_mechanism_run.log` (measured ĉ cells, second-order sizes).

*— Stenberg + Claude, 2026-07-23. The chirp error's bill is now itemized: two
Cauchy–Schwarzes that cost 12%, and one hyperbolic envelope that pays for
oscillations it never sees.*
