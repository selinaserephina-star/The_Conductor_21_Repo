# FINDINGS — F10 alignment audit STAGE 2: offset universality CONFIRMED at component arithmetic — the AiAi′ channel is shared exactly and the rest sums to −3/4 in both models

**Merkabit · Stenberg + Claude · 2026-07-23 (session 3, sixth push; stage 1 =
FINDINGS_LEMMA_A_PRIME_F10_alignment_audit.md). Read-only on the frozen
to_Ilya_CAUSTIC_THEOREM_2026-07-19 package ((L-a) closed-form decomposition, D2 §7
(F10)); scripts + logs §4. Not RH/GRH.**

## 0. Executive verdict

1. **The two models share the offset constant STRUCTURALLY, not numerically-by-luck.**
   F10's own frozen (L-a) decomposition of the companion offset,
     offset = C_model_∞ + R_∞,  C_model_∞ = −D_∞ + (1/2)∫Ψ₁ + Jac_∞,
   contains **(1/2)∫Ψ₁ = 2Ai(0)Ai′(0) = −√3/(3π) EXACTLY** — the same AiAi′ channel
   that sits inside our derived Ψ₀(0) (the −2Ai′(0)Ai(0) term). The Airy-product
   first-order constant is IDENTICAL in both models, sign and weight.
2. **The non-AiAi′ constants sum to −3/4 in both models** (the universality test):
   ours splits as 2/π (window) + (3/4 − 2/π) (deep matching); F10's as window-edge
   deficit + Jacobian + Olver accumulation:
     −D_∞ + Jac_∞ + R_∞^meas = −0.28781 − 0.1054 − 0.357 = **−0.75021 vs −3/4**
   (dev 2.1e−4, inside F10's stated component accuracy; their directly measured
   total −0.934 ± 0.001 vs our derived −0.933776 — same 2e−4).
3. **F10's open sliver closes in closed form.** Their record says "R_∞ ≈ −0.357 (the
   accumulated Olver ε²-remainder) has no closed form." It now does:
     **R_∞ = D_∞ − Jac_∞ − 3/4 = 2^{2/3}/(2π(3W₀/2)^{1/3}) − Jac_∞ − 3/4 =
     −0.35679**,  W₀ = arccosh 2 − √3/2,
   (Jac_∞ their own quadrature, −0.1054), vs their measured −0.357 — dev 2.1e−4.
4. **Verdict grade:** universality is CONFIRMED at component-arithmetic grade (each
   side's constants are closed-form or frozen-quadrature; the identity closes at
   2e−4, better than the recorded ±0.01 EM jitter of the individual components
   because the totals were measured directly). What would make it THEOREM-grade:
   derive the companion's D_∞/Jac_∞/R_∞ assembly as our window+deep matched calculus
   on their row object (their x₀ = 1/2 split vs our w-cut — one bookkeeping session);
   the AiAi′-channel equality is already exact algebra on both sides.
5. **One dead speculation recorded honestly:** the companion's cap constant
   1 − 0.76891 = 0.23109 numerically grazes 2^{4/3}√3/(6π) = 0.23158 — but F10's own
   footnote identifies it as the pre-asymptotic universal-tail mass → 1 − 2/π²
   at larger caps. Not an Airy constant; do not reuse.

## 1. The dictionary at the constant level

| constant | this campaign (∞ ODD) | F10 companion | shared? |
|---|---|---|---|
| slope | a∞ = 2^{2/3}Ai(0)Bi(0) — derived | same, derived | YES (exact) |
| AiAi′ channel | −√3/(3π) inside Ψ₀(0) = 2/π + √3/(3π) | (1/2)∫Ψ₁ = 2Ai(0)Ai′(0) = −√3/(3π) | YES (exact) |
| the rest | 2/π + (3/4 − 2/π) = 3/4 (window + deep matching, closed form) | D_∞ − Jac_∞ + \|R_∞\| = 0.75021 (one exact + one quadrature + one measured) | YES (2e−4) |
| total offset | −(3/4 + √3/(3π)) = −0.933776 DERIVED | −0.934 ± 0.001 measured (j = 16384) | YES |

D_∞ = 2^{2/3}/(2π(3W₀/2)^{1/3}) = 0.2878100 (exact, W₀ = arccosh 2 − √3/2);
Jac_∞ = −0.1054 (their atom-density-Jacobian quadrature, frozen).

## 2. Why this is the expected structure (mechanism sketch, for the stage-3 proof)

Both objects are j-differences of window sums of the SAME Airy product kernel at the
turning point (their telescope row ↔ our Δ_j; F10's dW carries (AiBi)′ + Δ(AiAi′)′,
ours carries AiBi with the differencing supplying the derivative). At first order the
only model-dependent items are (a) the per-order argument shifts (they enter the
shared AiAi′/AiBi′ channels with universal weights once the Wronskian split is used),
and (b) the deep-side geometry — and the deep zone of BOTH lattices is the same Debye
calculus (the −3/4 = the evanescent deficit's matched integral: our closed chain
(1−s)²/(2s) → −(1/π)[c/s − (3/2)arcsin c + cs/2] → 3/4 at the caustic, with the 2/π
transfer between window and matching cancelling in the total). F10 sliced the same
−3/4 along x₀ = 1/2 instead of a w-cut, which distributed it over D_∞ (edge), Jac_∞
(atom density), and R_∞ (the ε²-accumulation their split assigns to the remainder).
Stage 3 (staged): transplant our S∞ chain to their x₀-split to reproduce D_∞ − Jac_∞
+ R_∞ = 3/4 term by term.

## 3. Our-side octave extension (j = 2048)

- **New deepest ladder point:** sup|C̃_2048| = 4.6502849 at m* = 1304, m*/j = 0.6367
  = 2/π to 4 digits (validated-numeric grade — mpmath hybrid engine, the one that
  reproduced the certified j = 256 sup digit-exact; an arb confirmation is the
  natural add-on to the next certified-ladder run).
- **Offset drift:** sup − a∞μ^{1/3} = −0.894601 (was −0.89383 at j = 1024) — moving
  toward the derived asymptote −0.933776 on the expected ν^{−1/3} schedule; the
  derived-sup formula (a∞μ^{1/3} − (6+√3)/(3π) − S_j) now deviates from measurement
  by only 0.010 (sequence 0.047 → 0.036 → 0.024 → 0.010 over j = 256 → 2048).
- **S-ladder:** S_2048 = 0.0642 ± 0.018 (trust-window mean, 14 atoms), extending
  0.0145/0.0337/0.0499/0.0642 toward 3/4 − 2/π = 0.11338. Pairwise Richardson now
  BRACKETS the derived value: shallow pairs from below (0.110, 0.112), deep pairs
  from above (0.1163, 0.1195) — scatter ±0.006 set by the estimator's own
  O(ν^{−1/3}) profile systematics and lobe contamination (per-point spreads
  0.018–0.033), i.e. fully consistent with S∞ = 3/4 − 2/π and not a
  sharper-than-1e-2 test. (The direct total-offset drift above is the cleaner
  ladder-side check; the 2e−4 confirmation lives in §0/§1's component arithmetic.)
- Correction recorded (dated, no silent edit): the first run of the octave script
  printed the Richardson pairs with a sign slip in c (S∞ = 0.012/0.009 nonsense);
  fixed same day before any use — the script carries the corrected line + comment,
  and this file quotes only corrected values.

## 4. Manifest

| script | log | what it establishes |
|---|---|---|
| `lemmaA_prime_F10_stage2_identity.py` | `lemmaA_prime_F10_stage2_identity_run.log` | the component arithmetic: AiAi′ channel exact; non-AiAi′ sum −0.75021 vs −3/4; R_∞ closed form −0.35679 vs −0.357 |
| `lemmaA_prime_j2048_octave.py` | `lemmaA_prime_j2048_octave_run.log` | our-side j = 2048 profile: S_2048 + sup + Richardson (§3) |

Frozen inputs (read-only): D2 §7 (F10) (L-a) block — C_model_∞ decomposition with
D_∞ exact, (1/2)∫Ψ₁ = 2Ai(0)Ai′(0) exact, Jac_∞ quadrature, R(j) Cauchy data.

*— Stenberg + Claude, 2026-07-23. Two lattices, two tellings, one ledger: √3/(3π)
from the Airy product, three quarters from the dark side of the caustic — and F10's
last unexplained number was the change from splitting the bill differently.*
