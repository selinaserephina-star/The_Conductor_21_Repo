# FINDINGS — LEMMA A′ flagship: the caustic constant DERIVED — a∞ = 2^{2/3}·Ai(0)Bi(0) from the closure integrand's Airy window

**Merkabit · Stenberg + Claude · 2026-07-23 (LEMMA A′ completion campaign, session 3 —
the staged flagship piece (iv), executed via the uniform-Airy route, which also delivers
piece (ii) at leading order). Model lattice z_n = (n−½)π, x = z⁻², ∞ ODD system,
C̃_j(m) = t̃_{j+1}(m) − t̃_j(m), summand σ_n^{(j)} = (2/(4j+1))·2x²R′_{j−1}(x_n)R_j(x_n).
Scripts + logs §5. Not RH/GRH.**

## 0. Executive verdict

1. **The caustic constant of the model-lattice excess is now DERIVED, not identified:**
     **a∞ = 2^{2/3}·Ai(0)Bi(0) = 2^{2/3}3^{−5/6}/Γ(2/3)² = 0.3465553716…**
   — F10's constant appears as the value of the Airy product kernel AT the caustic,
   from the closure integrand itself. Along the way the maximizer m* = (2/π)j, the
   NEGATIVE sign of the caustic peak, and the peak's quadratic flatness are all derived
   (§3). This closes the identification half of LEMMA A′ at derivation grade; what
   remains for the full theorem is uniform-envelope bookkeeping (pieces (i)–(iii),
   §4.4).
2. **Mechanism in three exact steps** (§§1–3): (a) at the atoms the closure summand has
   an EXACT spherical-Bessel representation (the value-law signs square away),
   σ_n = (2/(4j+1))z²j_{2j+1}·[2(j−1)j_{2j−1} − z(j_{2j−2}+y_{2j−1})](z_n);
   (b) in the caustic window |z−ν| ≲ ν^{1/3}, ν = 2j, Olver's uniform-Airy forms
   collapse it to the **window law σ_n = π2^{−1/3}ν^{1/3}·(AiBi)(w_n)·(1+O(ν^{−1/3}))**,
   w = 2^{1/3}ν^{−1/3}(ν−z) — the bracket is dominated by its Neumann term z·y_{2j−1}
   → −z·Bi (the same (III)-cancellation structure that kills the tail); (c) the j-step
   shifts every order by 2, hence the Olver variable by Δw = 2^{4/3}ν^{−1/3}, while the
   window cell is 2^{1/3}πν^{−1/3}; summing the increment by parts,
     **C̃_j(m) = K_j − 2^{2/3}ν^{1/3}·(AiBi)(w_m) + [O(1) oscillatory-side residual]**,
   so sup_m|C̃_j| = 2^{2/3}Ai(0)Bi(0)·ν^{1/3} − K_j + o(1), attained at w = 0, i.e.
   z_{m*} = ν = 2j, i.e. **m* = (2/π)j — derived**.
3. **Verified at three grades** (§2–§3 tables; `lemmaA_prime_airy_window_law.py`):
   pointwise per-order-Airy law ratios **1.0001–1.0006 near the peak at j = 1024**
   (0.98–1.01 across the window; O(ν^{−2/3})-class defects); increment law ratios
   1.001–1.01 at the peak, window-cumulative ratio 1.038; and the full j = 256 profile
   from the INDEPENDENT mpmath Bessel engine reproduces the certified flint ladder:
   **sup = 1.8903193 at m* = 163 vs certified 1.89032 at 163** (engine also anchored to
   the logged arb polynomial values at j = 64, reldev ≤ 1.6e−7 = the log's print
   precision). The certified-ladder slope 0.3461 (0.15% from a∞) is thereby explained,
   not just fitted.
4. **The exact Γ-algebra of the peak** (§3): Ai(0)Bi(0) = 3^{−5/6}/Γ(2/3)², and
   **(AiBi)′(0) = Ai′(0)Bi(0) + Ai(0)Bi′(0) = −1/(2π) + 1/(2π) = 0 exactly** — the
   Airy Wronskian 1/π splits evenly and cancels. The caustic peak is quadratically
   flat ((AiBi)″(0) = 2Ai′(0)Bi′(0) = −0.23204), which is WHY the discrete lattice
   finds the peak cleanly and the m*-drift is only 4th-digit.
5. **The O(1) offset is coherent across the certified ladder** (§4.1;
   `lemmaA_prime_offset_ladder.py`): K_j = 2^{2/3}ν^{1/3}(AiBi)(w_{m*}) − E_j =
   0.8127 / 0.8387 / 0.8519 / 0.8605 at j = 256/512/768/1024 — a clean ν^{−1/3} drift,
   **K∞ = 0.945, c ≈ 1.07** (both deep pairs agree to 0.002). The ladder-fit offset
   b = −0.894 is the two-parameter-fit shadow of −K∞ + drift; the displayed candidate
   sup ≤ a∞μ^{1/3} + ½ keeps its ≥ 0.84 margin (K_j > 0 helps the bound).
6. **Secondary Airy constant derived** (§4.2): the first oscillatory lobe of AiBi at
   w_lobe = −1.76475, giving the positive-side growth constant a_lobe =
   2^{2/3}|AiBi(w_lobe)| = **0.18551 = 0.5353·a∞**. The caustic peak wins
   asymptotically; at j = 128 the +K_j tilt let the lobe win — this DERIVES the
   recorded maximizer migration m*/j = 0.664 (j = 128, w(m*) = −1.88 ≈ w_lobe) →
   0.6367 = 2/π (j ≥ 256).
7. **The mean law and the far phase-locking** (§4.3): the Debye phase-average of the
   atom-sampled product is **σ̄(z) = √(1−ν²/z²) − 1** — verified against 21-atom
   windowed means in the mid zone (dev ≤ 3e−3 at z/ν = 2–3.5). CAUTION (structural,
   load-bearing for c₀): this mean law does NOT extend to the far zone — there the
   lattice is coherently phase-locked to the Bessel zeros (j_{2j+1}(z_n) → 0; the
   (III) cancellation PLUS the l(l+1)/2z² correction give the bracket-sum
   2(j−1)j₋ − z(j_e+y₋) = +sinχ/z + O(z⁻²), χ = z−(2j+1)π/2), the slow and aliased
   parts cancel at the atoms, and the residual x²-law far mass is POSITIVE and large
   (+11.4 at j = 64, measured against the mid zone's −12.27 and deep's +0.85 — the
   exact full-sum-zero budget). Any c₀ derivation must count the far-mass increment;
   it is O(1), part of the piece-(iii) EM/boundary bucket.
8. **Status after this session:** flagship (iv) EXECUTED at derivation grade (via the
   Airy route; the pure-ℤ[x] coefficient-asymptotics re-derivation remains open as an
   alternative); piece (ii) leading order done (its remaining content = the explicit
   R-window envelope, i.e. the law-2−law-1 defect as a displayed bound); pieces (i)
   and (iii) untouched. Success criterion unchanged:
   |C̃_j(m)| ≤ a∞(2j)^{1/3} + c₀ displayed, now with a∞ DERIVED and c₀ = −K∞-side
   structure mapped (§4.4).

## 1. The exact Bessel representation at the atoms

At z_n = (n−½)π: cos z_n = 0, sin z_n = (−1)^{n+1}, so the value laws give
R_j(x_n) = (−1)^{n+1}z_n²j_{2j+1}(z_n), S_{j−1}(x_n) = (−1)^{n+1}z_n j_{2j−2}(z_n),
T_{j−1}(x_n) = (−1)^{n+1}z_n y_{2j−1}(z_n), and x_nz_n² = 1. Substituting into the
closure form σ_n = (2/(4j+1))[2(j−1)x_nR_{j−1} − S_{j−1} − T_{j−1}]·R_j, the two
(−1)^{n+1} square away:

  **σ_n^{(j)} = (2/(4j+1))·z² j_{2j+1}(z)·[2(j−1)j_{2j−1}(z) − z(j_{2j−2}(z) + y_{2j−1}(z))]
  at z = z_n**  — exact, every n, every zone.

(Verified against the logged arb polynomial values at j = 64, n = 3/30/600: reldev
1.6e−7/1.3e−8/1.0e−8 = the log's own print precision. This representation is also what
makes the deep zone numerically benign — no polynomial cancellation, only small×large
Bessel products.)

## 2. The window law (piece (ii) at leading order)

With ν_l = l+½ and Olver's turning-point forms J_ν(z) ≈ (2/ν)^{1/3}Ai(ζ),
Y_ν(z) ≈ −(2/ν)^{1/3}Bi(ζ), ζ = 2^{1/3}ν^{−1/3}(ν−z), valid on |z−ν| = O(ν^{1/3}):
each spherical factor is j_l ≈ √(π/2z)(2/ν_l)^{1/3}Ai(ζ_l), y_l ≈ −√(π/2z)(2/ν_l)^{1/3}Bi(ζ_l).
In the bracket, the y-term is the leader: z·y_{2j−1} ~ ν·Bi-scale, while
2(j−1)j_{2j−1} − z·j_{2j−2} = ν[Ai(ζ₋)−Ai(ζ_e)] + (ν−z−2)Ai-terms = O(ν^{2/3})·Ai′ —
one power of ν^{1/3} down. Collapsing all arguments to the central w = 2^{1/3}ν^{−1/3}(ν−z),
ν = 2j:

  **(LAW 1)  σ_n = π·2^{−1/3}·ν^{1/3}·(AiBi)(w_n)·(1 + O(ν^{−1/3})).**

(LAW 2) keeps every order's own (2/ν_l)^{1/3} and ζ_l and the full bracket — it is the
derivation with nothing collapsed, defect O(ν^{−2/3})-class. Measured (σ/law ratios):

| j | near-peak law2 | window law2 range | law1 defect scale |
|---|---|---|---|
| 64 | 0.996–1.008 | 0.91–1.04 (w∈[−2.2, 4.9]) | ~0.4–0.6 (=O(ν^{−1/3}), aliasing lobes) |
| 256 | 0.998–1.001 | 0.98–1.04 (w∈[−2.3, 4.7]) | 0.44–0.73 |
| 1024 | 0.9999–1.0006 | 0.99–1.06 (w∈[−2.4, 4.2]) | 0.64–0.83 |

(Ratios at AiBi's oscillatory-side zeros are ratios of near-zeros — absolute deviations
stay O(ν^{−1/3})-small; law1's slow ratio-approach is the expected ν^{−1/3} defect whose
leading part is the antisymmetric Ai(ζ₊)Bi(ζ₋) split, coefficient (Ai′Bi−AiBi′)(0) =
−1/π exactly.)

## 3. The differencing step and the constants (piece (iv))

The j-step shifts all four orders by exactly 2, so ζ shifts by Δw = 2·2^{1/3}ν^{−1/3} =
2^{4/3}ν^{−1/3} (the recorded Δt = −2/ν^{1/3} mechanism, in w-units), while the lattice
cell in w is |Δw_cell| = 2^{1/3}πν^{−1/3}. Summing Δ_jσ_n over n ≤ m (window Riemann
sum; the prefactor's own j-derivative enters at O(ν^{−1/3})):

  C̃_j(m)|_window = −[π2^{−1/3}ν^{1/3}]·(Δw/|Δw_cell|)·(AiBi)(w_m) + O(1)
                  = **−2^{2/3}ν^{1/3}·(AiBi)(w_m) + O(1).**

Consequences, all exact Airy algebra:

- **sup**: max_w AiBi = AiBi(0) = Ai(0)Bi(0) = 3^{−5/6}/Γ(2/3)², so
  sup_m|C̃_j| = **2^{2/3}Ai(0)Bi(0)·(2j)^{1/3}** + O(1) — i.e. **a∞ derived**, equal to
  F10's a∞ = 2^{2/3}3^{−5/6}/Γ(2/3)² digit for digit (printed check 0.3465553716 both).
- **maximizer**: w = 0 ⇔ z_{m*} = ν = 2j ⇔ **m* = (2/π)j** (certified ladder: 0.6367j).
- **sign**: the peak is NEGATIVE (matches all ball data).
- **flatness**: (AiBi)′(0) = Ai′(0)Bi(0) + Ai(0)Bi′(0) = −1/(2π) + 1/(2π) = **0
  exactly** (the Airy Wronskian split); (AiBi)″(0) = 2Ai′(0)Bi′(0) = −0.232. The
  discrete-atom peak therefore sits within O(ν^{−1/3}) in w of the true peak with only
  a quadratic value defect — the reason m*/j locks to 4 digits and the sup is clean.
- **connection to F10**: F10's row profile was Φ∞ = −4(AiBi)′ with constant
  ∫₀^∞(AiBi)′ = −Ai(0)Bi(0); here the SUMMAND is AiBi and the J-DIFFERENCING evaluates
  it at the caustic. Same Airy kernel, two readings — the transplant carries F10's
  constant because both are AiBi at the turning point.

Verification (j = 1024 window): Δσ_n/Δlaw2 = 1.001–1.012 (peak rows 0.996–1.001);
27-atom window cumulative exact/law2 = 1.038. Full-profile verification at j = 256:
sup and m* reproduced against the certified ladder to every printed digit (§0.3);
window-shape residual C̃(m) − [K − 2^{2/3}ν^{1/3}AiBi(w_m)]: smooth −0.26…0 on the
deep side (the R-window drift), ±0.45 oscillatory-side lobes (law-1-grade shape;
law-2-grade shape halves the lobes — the remaining O(1) is genuine window-subleading
content, part of c₀).

## 4. The O(1) landscape (what c₀ is made of)

### 4.1 The offset ladder

K_j ≡ 2^{2/3}ν^{1/3}(AiBi)(w_{m*}) − E_j on the certified ladder (E_j, m* frozen):

| j | 256 | 512 | 768 | 1024 |
|---|---|---|---|---|
| w(m*) | 0.2348 | 0.1764 | 0.1454 | 0.1243 |
| K_j | 0.8127 | 0.8387 | 0.8519 | 0.8605 |

K_j = K∞ − c·ν^{−1/3} with **K∞ = 0.945, c = 1.06–1.09** (pairs (512,1024), (768,1024)
agree to 0.002). j = 128 excluded — its m* sits on the first LOBE (w = −1.88), see
§4.2. The ladder-fit offset b = −0.894 is the 2-parameter shadow of this drift;
the theorem-candidate offset should be read as c₀ ≈ −K∞ + [window/EM residues].

### 4.2 The lobe constant and the maximizer migration

First lobe of AiBi: w_lobe = −1.76475, AiBi(w_lobe) = −0.116865, so the positive side
of the profile grows like **a_lobe·(2j)^{1/3} + K_j, a_lobe = 2^{2/3}|AiBi(w_lobe)| =
0.18551 = 0.5353·a∞**. Caustic peak (negative, a∞-rate, MINUS K_j) vs first lobe
(positive, a_lobe-rate, PLUS K_j): asymptotically the caustic wins; at j = 128 the
K-tilt made them cross — recorded m*/j = 0.664 with w(m*) = −1.88 ≈ w_lobe. The
migration 0.664 → 0.6367 is thereby derived, and any displayed theorem must (and
does) cover the lobe side: a_lobe < a∞ with room for K + lobe-residual inside c₀.

### 4.3 The mean law and the far phase-locking (feeds pieces (i)/(iii))

Debye phase-averaging the atom-sampled product (the s² ≡ 1 sampling; phase differences
θ_{ν+δ} − θ_ν = −δ·arccos(ν/z) + O(δ²/zq)) collapses, via cos2φ·cosφ − cos3φ =
sin2φ·sinφ, to

  **σ̄(z) = q − 1,  q = √(1−ν²/z²)**  (the evanescent deficit, ≤ 0),

verified by 21-atom windowed means at j = 64: dev −0.015/+0.0009/−0.0027/+0.0019 at
z/ν = 1.46/1.95/2.44/3.42 (transition noise ±0.03 at z/ν = 4.9–7.4, then the far
regime). CAUTION, structural: beyond the mid zone the mean law FAILS BY DESIGN — the
atoms are asymptotically the zeros of j_{2j+1} (phase-locking χ_n = (n−j−1)π), the
(III) cancellation plus the l(l+1)/2z² far correction give
2(j−1)j_{2j−1} − z(j_{2j−2}+y_{2j−1}) = +sinχ/z + O(z⁻²) — so slow and
aliased-coherent parts cancel AT the atoms and the surviving far mass is the POSITIVE
x²-law tail. Exact budget at j = 64 (ball data): deep+caustic +0.854, mid (n = 53–240)
−12.27, far return +11.42 → full sum 0 exactly (orthogonality: deg p̃′_{j−1} < j).
Consequences: (a) t̃'s drift is NOT (1/π)∫(q−1) alone — the sampled sums must be read
through the Poisson identity with its caustic-edge AND far-coherent corrections;
(b) the far-mass j-increment is O(1) and belongs to c₀ — it is exactly the
offset-lattice boundary calculus already practiced in FINDINGS_BEM_closed_form.md
(piece (iii)'s bucket, now with a second named term).

### 4.4 The honest remainder (unchanged pieces, sharpened targets)

(i) deep-zone increment envelope (Nicholson + ratio-monotonicity; feeds the deep-side
O(1)); (ii) the R-window: displayed envelope for law2−law1 and for the Olver
remainders (F10 L-a analog; its leading antisymmetric term has the EXACT coefficient
−1/π from the Wronskian split); (iii) caustic-edge EM terms + the far-coherent
increment (B_EM-class boundary calculus, two named terms); assembly then gives
|C̃_j(m)| ≤ a∞(2j)^{1/3} + c₀ with c₀ displayed. The certified-data candidate
sup ≤ a∞μ^{1/3} + ½ stands (margin ≥ 0.84, and K_j > 0 means the true peak sits
BELOW a∞μ^{1/3}).

## 5. Manifest (this session)

| script | log | what it establishes |
|---|---|---|
| `lemmaA_prime_airy_window_law.py` | `lemmaA_prime_airy_window_law_run.log` | Part 0 convention anchors (Bessel≡polynomial, 1e−8); Part A window law1/law2 tables j = 64/256/1024; Part B2 increment law j = 1024; Part B1 full j = 256 profile — sup/m* vs certified ladder + window shape + fitted K; Part C mean-law means |
| `lemmaA_prime_offset_ladder.py` | `lemmaA_prime_offset_ladder_run.log` | K_j ladder + K∞/c extrapolation; lobe constant a_lobe, w_lobe; j = 128 lobe diagnosis |

Engine: hybrid exact-Bessel (ascending series with adaptive precision / upward y- and
j-recurrences in their stable ranges / mpmath in the turning sliver), mpmath dps 40,
per-atom Wronskian spot-checks j_l y_{l−1} − j_{l−1}y_l = z⁻² — INDEPENDENT of the
flint polynomial engine, cross-anchored at j = 64 (logged arb values) and j = 256
(certified sup/m* to all printed digits). Grades: derivation = exact algebra +
classical-cited Olver leading forms (uniform error envelopes = the open piece (ii));
numerics = validated-independent double engine, not itself ball-certified.

Frozen inputs consulted (read-only): to_Ilya_CAUSTIC_THEOREM_2026-07-19 (F10 a∞, Φ∞,
L-a/L-b pattern), FINDINGS_LEMMA_A_PRIME_architecture.md + logs (zone laws, Poisson
identity, certified deep-j ladder), FINDINGS_LEMMA_A_closure_and_caustic_reconciliation.md
(closure identities, value laws), lemmaA_closure_Q_certificate.py (ℤ[x] closure).

*— Stenberg + Claude, 2026-07-23, LEMMA A′ session 3. The capital is no longer
measured: the caustic carries 2^{2/3}Ai(0)Bi(0) because the closure integrand IS the
Airy product kernel at the lattice's Nyquist boundary, and the j-step reads it off at
the turning point — where its derivative vanishes by the Wronskian's even split.*
