# NEXT-SESSION TASK — LEMMA A′ completion: the four named pieces of the caustic theorem

**Staged 2026-07-23 (Stenberg + Claude), post-addendum-seal (a112c1c5…). Goal: finish
the caustic law |C̃_j(m)| ≤ a∞(2j)^{1/3} + c₀ at theorem grade on the closure
integrands. Everything below is self-contained for a cold start. Not RH/GRH.**

**[2026-07-23 session 3: FLAGSHIP (iv) EXECUTED at derivation grade — a∞ =
2^{2/3}·Ai(0)Bi(0) DERIVED from the closure integrand (exact Bessel rep at atoms →
Olver window law σ_n = π2^{−1/3}ν^{1/3}(AiBi)(w_n) → j-differencing), with m* = (2/π)j,
negative sign, and quadratic peak flatness ((AiBi)′(0) = 0 exactly) all derived;
verified per-order-Airy to 1e−3 at j = 1024 and against the certified ladder
(sup 1.8903193 @ 163 reproduced digit-exact at j = 256 by an independent mpmath
engine). Piece (ii) leading order included; offset structure mapped (K∞ = 0.945,
c ≈ 1.07 exact ν^{−1/3} drift; lobe constant a_lobe = 0.18551 derives the j = 128
maximizer migration); mean law σ̄ = q − 1 verified mid-zone with the far
PHASE-LOCKING caution (far mass +11.4 at j = 64 is c₀-relevant, piece-(iii) bucket).
See FINDINGS_LEMMA_A_PRIME_caustic_constant_derived.md. REMAINING for theorem grade:
pieces (i) deep envelope, (ii) R-window envelope (leading antisym coeff −1/π exact),
(iii) EM edge + far-coherent increment, then assembly with displayed c₀.]**

**[2026-07-23 session 3, continuation: THE OFFSET TOO — pieces (i)+(ii) at first
order EXECUTED: sup_m|C̃_j| = a∞(2j)^{1/3} − (3/4 + √3/(3π)) + O(ν^{−1/3}) with all
three ingredients closed-form (Φ₁ = 2^{1/3}[Ai′(Ai+Bi) − 1/(2π)]; Ψ₀(0) =
(6+√3)/(3π); deep mean law σ̄ = (1−s)²/(2s) ⇒ S∞ = 3/4 − 2/π). Verified: deep
partial-sum closed form to 7e−5 on logged data; S_j Richardson 0.1123 vs 0.11338;
sup devs 0.047→0.024 ~ν^{−1/3}. −0.93378 matches F10's unresolved −0.934 → candidate
closed form for the companion's R_∞ (alignment audit staged). See
FINDINGS_LEMMA_A_PRIME_offset_closed_form.md. Remaining: displayed error envelopes
(Olver window / Debye deep), oscillatory-side Φ₂ lobes, EM/edge + far-coherent rigor
(assembly constants now all named and valued).]**

## Established (do not re-derive — FINDINGS_LEMMA_A_PRIME_architecture.md)

- Closure identity PROVEN (ℤ[x], j ≤ 60): summand σ_n = (2/(4j+1))·2x²R′_{j−1}R_j;
  families R/S/T/W with S_j(0)+T_j(0) = 0.
- Zone map with verified leading laws: DEEP (z < 2j): σ_n → (2/(4j+1))z⁴/((4j+3)(4j+1)(4j−1))
  (ratio 1.004 deep; increment law 1.03; window-summed const −(1/5π)(z/2j)⁵);
  TRUE-FAR (z ≳ ν²): σ_n → (4/(4j+1))x²R′_{j−1}(0)R_j(0), R_j(0) = (−1)^j(2j+1)(j+1).
- CAUTION (recorded): the e^{ν²x/2} envelope for R_j is FALSE — coefficient ratios are
  ν⁴-scale; correct domination is I₀-type, domain z ≳ ν².
- Nyquist structure: below the caustic R_j is aliased (zeros between every atom pair —
  off-lattice integral diverges); beyond it the Poisson/midpoint identity HOLDS
  (ball-verified 1e-4…1e-5 relative outside an O(ν^{1/3}) edge layer) and
  (1/π)∫F dz = (2/(π(4j+1)))∫√x·R′_{j−1}R_j dx — EXACT closed form.
- Constants IDENTIFIED (certified-data, ladder j = 8…1024, radii 0): slope → a∞ =
  2^{2/3}3^{−5/6}/Γ(2/3)² (0.15%), offset −0.894, m* = (2/π)j to 4 digits. Displayed
  candidate data-true: sup_m|C̃_j| ≤ a∞(2j)^{1/3} + ½ (margin ≥ 0.84).

## The four pieces (any order; (iv) is the flagship)

1. **Deep-zone increment envelope (proof).** Rigorous |Δ_jσ_n| bound over z ≤ (1−δ)2j
   via classical inequalities: Nicholson-type two-sided bounds on −z²j_ly_l vs
   z/(2√(ν²−z²)), ratio-monotonicity for j_{l+2}/j_l. Leading law + increment already
   verified; this is envelope bookkeeping with explicit constants.
2. **Caustic-window uniform Airy (the F10 L-a analog).** Olver expansions of the four
   Bessel families on |z−ν| ≲ ν^{1/3} with explicit error envelopes; the
   ν^{1/3}-differencing (Δt = −2/ν^{1/3}) gives the window contribution; target =
   re-derive a∞ + an explicit R_j-window.
3. **Caustic-edge EM terms of the Poisson identity.** The measured edge-layer error
   (4.3e-2 → 1.3e-5 decay at J = 64) is the offset-lattice boundary calculus of the
   B_EM close (FINDINGS_BEM_closed_form.md) at a new location — same machinery,
   displayed edge terms.
4. **Closed-form integral asymptotics (flagship, pure algebra).** The mid+far
   region is (2/(π(4j+1)))∫√x·R′_{j−1}(x)R_j(x)dx exactly; its large-j asymptotics
   should re-derive the caustic constant ANALYTICALLY (a∞ from the ℤ-exact
   coefficients) and produce the displayed c₀. Route: term-by-term integration +
   the coefficient closed forms (Hankel-symbol structure); or steepest-descent on
   the integral representation.

## Success criteria

THEOREM: |C̃_j(m)| ≤ a∞(2j)^{1/3} + c₀ for all j ≥ j₀, all m, displayed constants;
verified against the certified ladder. Then the payoff chain: F11 field-side pairing
⇒ the layer-window conditioning statement the Abel/κ̂ machinery needs (the re-scoped
§4 corollary route).

## Companion smaller tasks (independent, pick-up-able)

- **Near-1 family-sum lemma:** why ĉ ≤ 0.16 in N·D_chirp ≈ ĉ/gap (per-mode
  anti-alignment proven; the family sum is the one measured law without a mechanism).
  Upgrades the chirp bound envelope → displayed.
  **[2026-07-23 MECHANISM IDENTIFIED (`chirp_family_sum_mechanism.py`): the family
  sum is ONE resolvent channel — first-order top-mode term carries 74–100% at every
  reliable cell (2nd order ≤ 1%); exact factorization d_top = 2p·q + ‖q‖² with
  ‖p‖ = √λ_top ≤ 1 EXACT; two anti-alignment layers: (1) ‖q‖ = ‖Δᵀv_top‖ tiny,
  carried by NEAR-EDGE columns (i/j = 0.65–1.0) — the rise of ĉ(ξ); (2) deep
  cos∠(p,q) collapse 0.93 → 0.009 — the fall past ξ = 2.5. Binding cell O/ξ=2:
  CS cap 2N‖p‖‖q‖ = 0.164 vs ĉ = 0.154 (tight). Remaining = ONE classical
  column-norm estimate (Prop-1/2 remainders on near-edge columns) → displayed ĉ.
  Dead end recorded: effective band-dilation model REFUTED (predicts polynomial).
  See FINDINGS_CHIRP_family_sum_mechanism.md.]**
  **[2026-07-23 seventh push: the column-norm estimate EXECUTED — first
  fully-displayed chirp bound (Prop-2 columns, all-modes trΓ assembly, no spectral
  factor): ĉ ≤ 0.0027/0.026 (O/E, ξ = 1), covers 0.16 to ξ = 1.5, finite to 2.5;
  assembly near-tight (0.173 vs 0.154 at the binding cell, 12%). Remaining lemma:
  oscillation-aware column norms for Y ≳ 2. See
  FINDINGS_CHIRP_chat_displayed_bound.md.]**
- **Interval-certify the δ/δ′/η/gap grids** (arb Nyström; certified GL nodes) —
  upgrades C2 + B_EM + chirp grades in one stroke.
- **Operator-EM lemma write-up** (B_EM remainder majorants displayed; audit-proofing).
- **P1b breakdown measurement** (cheap): where flat-log W_j breaks (larger-M arb run).
  **[2026-07-23 EXECUTED (`k1k2_p1b_breakdown_M400.py`, M = 400, prec 16384, radii 0):
  flat-log HOLDS in j to 384 (W = 6.1→9.2, slower than log); the break is in M —
  W_j ≈ doubles per 4× M at fixed j ⇒ P1a·P1b is measured-dead as an M-uniform route.
  Bonus: finite-testbed max|C_j| tracks the derived ∞-caustic-law +0.2…0.45
  (boundary layer), j = 384 = 0.96M boundary-contaminated. See
  FINDINGS_P1B_breakdown_M400.md.]**

- **F10 alignment audit stage 2 EXECUTED (same day): UNIVERSALITY CONFIRMED at
  component arithmetic** — the AiAi′ channel 2Ai(0)Ai′(0) = −√3/(3π) is shared
  EXACTLY (their (1/2)∫Ψ₁ ↔ our Ψ₀(0)-term); the non-AiAi′ constants sum to −3/4 in
  both models (theirs: −D_∞ + Jac_∞ + R_∞ = −0.75021, dev 2.1e−4); **F10's open
  sliver closed: R_∞ = D_∞ − Jac_∞ − 3/4 = −0.35679 vs measured −0.357**. Our octave
  j = 2048 added (sup = 4.6503 @ 0.6367j; offset −0.8946 on schedule to −0.9338;
  derived-sup dev 0.010). Stage 3 (term-by-term transplant to their x₀-split) staged
  for theorem grade. See FINDINGS_LEMMA_A_PRIME_F10_stage2_universality.md.

- **F10 alignment audit (added this session): stage 1 EXECUTED** — dictionary built
  (their telescope row ↔ our Δ_j; same (AiBi)′ kernel; a∞ shared exactly; first-order
  corrections genuinely differ: Ψ₁ = −4·2^{1/3}(AiAi′)′ vs Φ₁ = 2^{1/3}[Ai′(Ai+Bi) −
  1/(2π)]), and the derived total −0.93378 PREDICTS F10's open sliver R_∞ = −0.3568
  vs their measured −0.357 (2e−4). Stage 2 staged: transplant Ψ₀ + S∞ to the
  companion (μ−1, μ, μ+2)/2x_n structure → prove (or refute) family universality of
  the offset. See FINDINGS_LEMMA_A_PRIME_F10_alignment_audit.md.

## Files

`FINDINGS_LEMMA_A_PRIME_architecture.md` (the map); `lemmaA_prime_zone_laws.py`,
`lemmaA_prime_poisson_identity.py`, `lemmaA_prime_deepj.py` (+logs);
`lemmaA_closure_Q_certificate.py` (the identity); `FINDINGS_BEM_closed_form.md`
(the edge calculus); frozen F10: to_Ilya_CAUSTIC_THEOREM_2026-07-19 (zone-(ii)
theorem, L-a/L-b pattern, a∞/R_∞). Toolchain standing orders: no-reorth arb jets;
check-existing-first; the pre-send attribution grep BEFORE any SHA.
