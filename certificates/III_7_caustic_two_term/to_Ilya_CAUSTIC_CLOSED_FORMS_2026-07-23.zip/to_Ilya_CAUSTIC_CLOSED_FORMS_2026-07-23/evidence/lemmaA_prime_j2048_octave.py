# lemmaA_prime_j2048_octave.py — one more octave for the offset ladder (2026-07-23,
# F10 stage-2 support): full C~ profile at j = 2048 via the validated hybrid Bessel
# engine; measures sup, m*, and S_j (the deep matched constant) to sharpen the
# S_inf extrapolation against the derived 3/4 - 2/pi = 0.11338 and the offset
# -(3/4 + sqrt3/(3pi)) = -0.93378 vs F10's -0.934/-0.935(1).  Not RH/GRH.
import mpmath as mp
import time, csv

mp.mp.dps = 40
PI = mp.pi

_DF = {}
def dfact(l):
    if l not in _DF:
        v = mp.mpf(1)
        for i in range(3, 2*l + 2, 2):
            v *= i
        _DF[l] = v
    return _DF[l]

def j_series(l, z):
    guard = int(0.44*float(z)) + 30
    with mp.workdps(mp.mp.dps + guard):
        zz = mp.mpf(z)
        z2 = zz*zz/2
        t = mp.mpf(1); s = mp.mpf(1); k = 0
        thr = mp.mpf(10)**(-(mp.mp.dps + 10))
        while True:
            k += 1
            t *= -z2/(k*(2*l + 1 + 2*k))
            s += t
            if abs(t) < thr*(abs(s) + 1) and 2*k > float(z):
                break
        val = s*zz**l/dfact(l)
    return +val

def rows(z, Lmax, jorders):
    with mp.workdps(80):
        zz = mp.mpf(z)
        y = [-mp.cos(zz)/zz, -mp.cos(zz)/zz**2 - mp.sin(zz)/zz]
        for l in range(1, Lmax):
            y.append((2*l + 1)/zz*y[-1] - y[-2])
        Lup = min(Lmax, int(float(z)) - 3)
        jup = None
        if any(l <= Lup for l in jorders):
            jup = [mp.sin(zz)/zz, mp.sin(zz)/zz**2 - mp.cos(zz)/zz]
            for l in range(1, Lup):
                jup.append((2*l + 1)/zz*jup[-1] - jup[-2])
    jv = {}
    for l in jorders:
        if jup is not None and l <= Lup:
            jv[l] = +jup[l]
        elif z < l:
            jv[l] = j_series(l, z)
        else:
            with mp.workdps(60):
                v = mp.sqrt(PI/(2*z))*mp.besselj(mp.mpf(l) + mp.mpf(1)/2, z)
            jv[l] = +v
    return jv, y

def sigma_pair(j, n):
    z = (2*n - 1)*PI/2
    Ls = sorted({2*j - 2, 2*j - 1, 2*j + 1, 2*j, 2*j + 3})
    jv, y = rows(z, 2*j + 4, Ls)
    def sig(jj):
        return (mp.mpf(2)/(4*jj + 1))*z**2*jv[2*jj + 1]*(
            2*(jj - 1)*jv[2*jj - 1] - z*(jv[2*jj - 2] + y[2*jj - 1]))
    return sig(j), sig(j + 1)

Ai = mp.airyai; Bi = mp.airybi
AiBi = lambda w: Ai(w)*Bi(w)
dAiBi = lambda w: mp.airyai(w, 1)*Bi(w) + Ai(w)*mp.airybi(w, 1)
CBRT2 = mp.cbrt(2)
a_inf = 2**(mp.mpf(2)/3)*AiBi(0)
def Phi1(w):
    return CBRT2*(mp.airyai(w, 1)*(Ai(w) + Bi(w)) - 1/(2*PI))
def Psi0(w):
    return -2**(mp.mpf(2)/3)*Phi1(w) + (PI - 2)*dAiBi(w)
def wof(j, n):
    nu = mp.mpf(2*j); z = (2*n - 1)*PI/2
    return CBRT2/mp.cbrt(nu)*(nu - z)

j = 2048
nu = mp.mpf(2*j)
mstar = round(2*j/PI)
NPRO = mstar + 45
t0 = time.time()
import os
CSV = "lemmaA_prime_profile_j2048.csv"
Ct = {}
if os.path.exists(CSV):
    with open(CSV) as f:
        for row in csv.reader(f):
            Ct[int(row[1])] = mp.mpf(row[2])
    print(f"profile loaded from cache ({len(Ct)} atoms)")
else:
    acc = mp.mpf(0)
    for n in range(1, NPRO + 1):
        s0, s1 = sigma_pair(j, n)
        acc += s1 - s0
        Ct[n] = acc
        if n % 200 == 0:
            print(f"  n={n}/{NPRO} ({time.time()-t0:.0f}s)", flush=True)
    with open(CSV, "w", newline="") as f:
        wcsv = csv.writer(f)
        for m in sorted(Ct):
            wcsv.writerow([j, m, mp.nstr(Ct[m], 30)])
sup = max(Ct, key=lambda m: abs(Ct[m]))
print(f"\nj=2048: sup|C~| = {mp.nstr(abs(Ct[sup]), 8)} at m* = {sup}  (m*/j = {sup/j:.4f}; "
      f"2/pi = 0.63662)   [{time.time()-t0:.0f}s]")
Rs = []
for m in sorted(Ct):
    w = wof(j, m)
    if -mp.mpf(1)/2 <= w <= 3:
        Rs.append(Ct[m] + 2**(mp.mpf(2)/3)*mp.cbrt(nu)*AiBi(w) - Psi0(w))
S = sum(Rs)/len(Rs)
spread = max(abs(r - S) for r in Rs)
print(f"S_2048 = {mp.nstr(S, 5)} +- {mp.nstr(spread, 2)} over {len(Rs)} atoms")
# Richardson vs the cached S_j values (256/512/1024 from the R-window run)
prev = {256: mp.mpf('0.014507'), 512: mp.mpf('0.033659'), 1024: mp.mpf('0.049880')}
for ja in (512, 1024):
    xa, xb = mp.cbrt(mp.mpf(2*ja))**-1, mp.cbrt(nu)**-1
    # model S_j = S_inf - c*x, x = (2j)^{-1/3}  [first run had (prev-S): sign slip,
    # corrected same day before any use — this line is the corrected record]
    c = (S - prev[ja])/(xa - xb)
    Sinf = S + c*xb
    print(f"  pair ({ja},2048): S_inf = {mp.nstr(Sinf, 5)}   c = {mp.nstr(c, 4)}   "
          f"[derived 3/4 - 2/pi = {mp.nstr(mp.mpf(3)/4 - 2/PI, 6)}]")
pk = a_inf*mp.cbrt(nu) - (6 + mp.sqrt(3))/(3*PI) - S
print(f"derived sup = {mp.nstr(pk, 6)}   measured = {mp.nstr(abs(Ct[sup]), 6)}   "
      f"dev = {mp.nstr(pk - abs(Ct[sup]), 3)}")
print(f"offset check: sup - a_inf*mu^(1/3) = {mp.nstr(abs(Ct[sup]) - a_inf*mp.cbrt(nu), 6)}  "
      f"[derived asymptote -(3/4+sqrt3/(3pi)) = {mp.nstr(-(mp.mpf(3)/4 + mp.sqrt(3)/(3*PI)), 6)}]")
print("done.")
