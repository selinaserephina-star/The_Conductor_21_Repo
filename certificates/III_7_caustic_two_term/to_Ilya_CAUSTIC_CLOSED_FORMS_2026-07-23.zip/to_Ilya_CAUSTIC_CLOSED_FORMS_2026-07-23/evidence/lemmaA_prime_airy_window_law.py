# lemmaA_prime_airy_window_law.py — LEMMA A' FLAGSHIP (pieces (ii)+(iv), leading order):
# the caustic constant a_inf DERIVED analytically on the closure integrand, verified here.
#
# DERIVATION BEING CERTIFIED (2026-07-23 session):
#   At atoms z_n=(n-1/2)pi the closure summand has the EXACT Bessel representation
#     sigma_n^{(j)} = (2/(4j+1)) z^2 j_{2j+1}(z) [ 2(j-1) j_{2j-1}(z) - z (j_{2j-2}(z)+y_{2j-1}(z)) ],
#   (the (-1)^{n+1} value-law signs square away; R_j(x_n)=(-1)^{n+1}z^2 j_{2j+1}(z_n) etc).
#   In the caustic window |z - nu| = O(nu^{1/3}), nu = 2j, Olver's uniform-Airy forms
#     j_l ~ sqrt(pi/2z)(2/nu_l)^{1/3} Ai(zeta_l),  y_l ~ -sqrt(pi/2z)(2/nu_l)^{1/3} Bi(zeta_l),
#     zeta_l = 2^{1/3} nu_l^{-1/3} (nu_l - z),  nu_l = l + 1/2,
#   give (leading order; the bracket is dominated by the z*Bi term, the Ai-difference and
#   (nu-z)Ai terms are O(nu^{-1/3}) relative):
#     (LAW 1)  sigma_n = pi 2^{-1/3} nu^{1/3} (Ai*Bi)(w_n) * (1+O(nu^{-1/3})),
#              w_n = 2^{1/3} nu^{-1/3} (nu - z_n).
#   The j-step j -> j+1 shifts w by Delta w = 2^{4/3} nu^{-1/3} (all orders shift by 2), so
#     C~_j(m) = sum_{n<=m} Delta_j sigma_n = -2^{2/3} nu^{1/3} (Ai*Bi)(w_m) + O(1),
#   using sum -> integral of (AiBi)' (window Riemann sum, cell 2^{1/3} pi nu^{-1/3}).  Hence
#     sup_m |C~_j| = 2^{2/3} Ai(0)Bi(0) nu^{1/3} + O(1),   maximizer at w=0 i.e. m* = (2/pi) j,
#   and 2^{2/3} Ai(0)Bi(0) = 2^{2/3} 3^{-5/6} / Gamma(2/3)^2 = a_inf — F10's own constant,
#   with the peak at w=0 QUADRATICALLY FLAT because (AiBi)'(0) = Ai'(0)Bi(0)+Ai(0)Bi'(0) = 0
#   exactly (Gamma-value identity), and the peak value NEGATIVE (matches the ball data sign).
#
# WHAT THIS SCRIPT CHECKS (mpmath, hybrid exact-Bessel engine, dps 40):
#   0. Convention anchors: sigma_n(Bessel form) == logged arb polynomial values (j=64).
#   A. LAW 1 and LAW 2 (per-order Airy arguments, full bracket) pointwise in the window,
#      j = 64 / 256 / 1024: ratios -> 1 with O(nu^{-1/3}) resp. O(nu^{-2/3}) defects.
#   B1. j=256 FULL C~ profile from the Bessel forms: sup and m* vs the CERTIFIED ladder
#      (1.89032 @ m*=163); window shape vs K - 2^{2/3}nu^{1/3}(AiBi)(w_m); fitted K vs
#      the ladder offset (+0.894 expected: E_j = a_inf mu^{1/3} - 0.894).
#   B2. j=1024 window increments Delta_j sigma_n vs law increments (the differencing step).
#   C. Mid-zone mean law (j=64): windowed means of sigma_n vs (q-1), q = sqrt(1-nu^2/z^2)
#      [the Debye phase-average of the atom-sampled product], and the recorded caveat that
#      the far zone is coherently phase-locked (mean law does NOT extend there; the far
#      x^2 law with its positive mass is the return path to the exact full-sum zero).
# Not RH/GRH.
import mpmath as mp
import time

mp.mp.dps = 40
PI = mp.pi

# ---------------- hybrid spherical Bessel engine ----------------
_DF = {}
def dfact(l):  # (2l+1)!!
    if l not in _DF:
        v = mp.mpf(1)
        for i in range(3, 2*l + 2, 2):
            v *= i
        _DF[l] = v
    return _DF[l]

def j_series(l, z):
    """ascending series for j_l(z), adaptive precision (cancellation <= ~e^z)."""
    guard = int(0.44*float(z)) + 30
    with mp.workdps(mp.mp.dps + guard):
        zz = mp.mpf(z)
        z2 = zz*zz/2
        t = mp.mpf(1); s = mp.mpf(1); k = 0
        thr = mp.mpf(10)**(-(mp.mp.dps + 10))
        while True:
            k += 1
            t *= -z2/(k*(2*l + 1 + 2*k))
            s += t
            if abs(t) < thr*(abs(s) + 1) and 2*k > float(z):
                break
        val = s*zz**l/dfact(l)
    return +val

def rows(z, Lmax, jorders):
    """y_0..y_Lmax by upward recurrence (stable everywhere); j at the orders in jorders:
    shared upward run for l <= z-3, series for z < l, mpmath in the turning sliver."""
    with mp.workdps(80):
        zz = mp.mpf(z)
        y = [-mp.cos(zz)/zz, -mp.cos(zz)/zz**2 - mp.sin(zz)/zz]
        for l in range(1, Lmax):
            y.append((2*l + 1)/zz*y[-1] - y[-2])
        Lup = min(Lmax, int(float(z)) - 3)
        jup = None
        if any(l <= Lup for l in jorders):
            jup = [mp.sin(zz)/zz, mp.sin(zz)/zz**2 - mp.cos(zz)/zz]
            for l in range(1, Lup):
                jup.append((2*l + 1)/zz*jup[-1] - jup[-2])
    jv = {}
    for l in jorders:
        if jup is not None and l <= Lup:
            jv[l] = +jup[l]
        elif z < l:
            jv[l] = j_series(l, z)
        else:
            with mp.workdps(60):
                v = mp.sqrt(PI/(2*z))*mp.besselj(mp.mpf(l) + mp.mpf(1)/2, z)
            jv[l] = +v
    return jv, y

_SIG = {}
def sigma_pair(j, n, wronsk=False):
    """(sigma_n^{(j)}, sigma_n^{(j+1)}) via the exact Bessel representation."""
    key = (j, n)
    if key in _SIG:
        return _SIG[key]
    z = (2*n - 1)*PI/2
    Ls = sorted({2*j - 2, 2*j - 1, 2*j + 1, 2*j, 2*j + 3})
    jv, y = rows(z, 2*j + 4, Ls)
    if wronsk:  # j_l y_{l-1} - j_{l-1} y_l = 1/z^2  (mixed-pipeline validator)
        l = 2*j + 1
        jv2, _ = rows(z, 2*j + 4, [l - 1])
        w = jv[l]*y[l - 1] - jv2[l - 1]*y[l]
        dev = abs(w*z*z - 1)
        if dev > mp.mpf(10)**(-25):
            print(f"  !! Wronskian dev {mp.nstr(dev, 3)} at j={j} n={n}")
    def sig(jj):
        return (mp.mpf(2)/(4*jj + 1))*z**2*jv[2*jj + 1]*(
            2*(jj - 1)*jv[2*jj - 1] - z*(jv[2*jj - 2] + y[2*jj - 1]))
    out = (sig(j), sig(j + 1))
    _SIG[key] = out
    return out

# ---------------- the laws ----------------
def law1(j, n):
    nu = mp.mpf(2*j); z = (2*n - 1)*PI/2
    w = mp.cbrt(2)/mp.cbrt(nu)*(nu - z)
    return PI*mp.cbrt(2)**-1*nu**(mp.mpf(1)/3)*mp.airyai(w)*mp.airybi(w)

def law2(j, n):
    z = (2*n - 1)*PI/2
    c = mp.sqrt(PI/(2*z))
    def A(l):
        nl = l + mp.mpf(1)/2
        return c*mp.cbrt(2/nl)*mp.airyai(mp.cbrt(2)*nl**(-mp.mpf(1)/3)*(nl - z))
    def B(l):
        nl = l + mp.mpf(1)/2
        return c*mp.cbrt(2/nl)*mp.airybi(mp.cbrt(2)*nl**(-mp.mpf(1)/3)*(nl - z))
    return (mp.mpf(2)/(4*j + 1))*z**2*A(2*j + 1)*(
        2*(j - 1)*A(2*j - 1) - z*(A(2*j - 2) - B(2*j - 1)))

def wof(j, n):
    nu = mp.mpf(2*j); z = (2*n - 1)*PI/2
    return mp.cbrt(2)/mp.cbrt(nu)*(nu - z)

AiBi0 = mp.airyai(0)*mp.airybi(0)
a_inf = 2**(mp.mpf(2)/3)*AiBi0
print(f"a_inf = 2^(2/3) Ai(0)Bi(0) = {mp.nstr(a_inf, 10)}  "
      f"(F10: 2^(2/3) 3^(-5/6)/Gamma(2/3)^2 = "
      f"{mp.nstr(2**(mp.mpf(2)/3)*3**(-mp.mpf(5)/6)/mp.gamma(mp.mpf(2)/3)**2, 10)})")
print(f"(AiBi)'(0) = Ai'(0)Bi(0)+Ai(0)Bi'(0) = "
      f"{mp.nstr(mp.airyai(0, 1)*mp.airybi(0) + mp.airyai(0)*mp.airybi(0, 1), 3)}  [exact 0]")

# ---------------- Part 0: convention anchors vs logged arb values (j=64) ----------------
t0 = time.time()
print("\n== Part 0: Bessel-form sigma vs logged arb polynomial values (j=64) ==")
REF = {3: mp.mpf('1.751091e-06'), 30: mp.mpf('6.820869e-02'), 600: mp.mpf('-5.596832e-03')}
for n, ref in REF.items():
    s, _ = sigma_pair(64, n, wronsk=True)
    print(f"  n={n:4d}: sigma = {mp.nstr(s, 8)}   log = {mp.nstr(ref, 8)}   "
          f"reldev = {mp.nstr(abs(s/ref - 1), 3)}")
print(f"  ({time.time()-t0:.0f}s)")

# ---------------- Part A: window law pointwise ----------------
print("\n== Part A: caustic-window law  sigma_n vs pi 2^(-1/3) nu^(1/3) (AiBi)(w_n) ==")
for j, span in ((64, 6), (256, 9), (1024, 13)):
    t0 = time.time()
    mstar = round(2*j/PI)
    print(f"-- j={j} (nu={2*j}, m*={mstar}, nu^(-1/3)={mp.nstr(mp.mpf(2*j)**(-mp.mpf(1)/3), 3)}) --")
    print("    n  |    w    |   sigma      | sig/law1 | sig/law2")
    for n in range(mstar - span, mstar + span + 1, max(1, span//4)):
        s, _ = sigma_pair(j, n, wronsk=(n == mstar))
        l1 = law1(j, n); l2 = law2(j, n)
        print(f"  {n:4d} | {mp.nstr(wof(j, n), 4):>7s} | {mp.nstr(s, 6):>12s} | "
              f"{mp.nstr(s/l1, 6):>8s} | {mp.nstr(s/l2, 7):>8s}")
    print(f"  ({time.time()-t0:.0f}s)")

# ---------------- Part B2: j=1024 increment law in the window ----------------
print("\n== Part B2: j=1024 increments Delta_j sigma_n vs law increments ==")
t0 = time.time()
j = 1024; mstar = round(2*j/PI)
csum_ex = mp.mpf(0); csum_l2 = mp.mpf(0)
print("    n  |    w    | Dsigma       | D/dlaw1  | D/dlaw2")
for n in range(mstar - 13, mstar + 14):
    s0, s1 = sigma_pair(j, n)
    d = s1 - s0
    d1 = law1(j + 1, n) - law1(j, n)
    d2 = law2(j + 1, n) - law2(j, n)
    csum_ex += d; csum_l2 += d2
    if (n - mstar) % 3 == 0:
        print(f"  {n:4d} | {mp.nstr(wof(j, n), 4):>7s} | {mp.nstr(d, 6):>12s} | "
              f"{mp.nstr(d/d1, 6):>8s} | {mp.nstr(d/d2, 7):>8s}")
print(f"  window-cumulative: exact {mp.nstr(csum_ex, 8)}  law2 {mp.nstr(csum_l2, 8)}  "
      f"ratio {mp.nstr(csum_ex/csum_l2, 6)}")
print(f"  ({time.time()-t0:.0f}s)")

# ---------------- Part B1: j=256 full profile, sup vs certified ladder, window shape ----------------
print("\n== Part B1: j=256 full C~ profile (Bessel forms) vs certified ladder + window shape ==")
t0 = time.time()
j = 256; nu = mp.mpf(2*j)
NPRO = 240
Ct = [mp.mpf(0)]*(NPRO + 1)
acc = mp.mpf(0)
for n in range(1, NPRO + 1):
    s0, s1 = sigma_pair(j, n, wronsk=(n % 40 == 0))
    acc += (s1 - s0)
    Ct[n] = acc
sup = max(range(1, NPRO + 1), key=lambda m: abs(Ct[m]))
print(f"  sup_m|C~| = {mp.nstr(abs(Ct[sup]), 8)} at m*={sup}   "
      f"[certified ladder: 1.89032 at m*=163]")
mstar = sup
shape = lambda m: -2**(mp.mpf(2)/3)*nu**(mp.mpf(1)/3)*mp.airyai(wof(j, m))*mp.airybi(wof(j, m))
K = Ct[mstar] - shape(mstar)
Kd = K + (2/PI)*mp.acos(min(nu/((2*mstar - 1)*PI/2), mp.mpf(1)))
print(f"  fitted K (anchor at m*): {mp.nstr(K, 5)}   [ladder offset expectation ~ +0.894]")
print("    m  |    w    |   C~(m)    | K+shape  | resid   | resid+Debye")
for m in list(range(mstar - 12, mstar + 13, 2)):
    z = (2*m - 1)*PI/2
    deb = (2/PI)*mp.acos(min(nu/z, mp.mpf(1)))  # = (2/pi)*phi_m, 0 below caustic
    lawv = K + shape(m)
    lawd = Kd + shape(m) - deb
    print(f"  {m:4d} | {mp.nstr(wof(j, m), 4):>7s} | {mp.nstr(Ct[m], 6):>10s} | "
          f"{mp.nstr(lawv, 6):>8s} | {mp.nstr(Ct[m]-lawv, 3):>7s} | {mp.nstr(Ct[m]-lawd, 3):>7s}")
print("  profile samples (deep plateau -> mid):")
for m in (40, 80, 110, 130, 145, 155, 175, 190, 210, 230, 240):
    print(f"    m={m:4d}  w={mp.nstr(wof(j, m), 4):>7s}  C~={mp.nstr(Ct[m], 6)}")
print(f"  ({time.time()-t0:.0f}s)")

# ---------------- Part C: mid-zone mean law (j=64) ----------------
print("\n== Part C: mid-zone mean law: 21-atom windowed means vs (q-1) [j=64, nu=128] ==")
t0 = time.time()
j = 64; nu = mp.mpf(128)
for c in (60, 80, 100, 140, 200, 300, 600):
    W = 10
    s = mp.mpf(0)
    for n in range(c - W, c + W + 1):
        s += sigma_pair(j, n)[0]
    mean = s/(2*W + 1)
    zc = (2*c - 1)*PI/2
    q = mp.sqrt(1 - (nu/zc)**2)
    print(f"  n={c:4d} (z/nu={mp.nstr(zc/nu, 4)}): mean sigma = {mp.nstr(mean, 5):>10s}   "
          f"q-1 = {mp.nstr(q - 1, 5):>10s}   dev = {mp.nstr(mean - (q - 1), 3)}")
print(f"  ({time.time()-t0:.0f}s)")
print("\ndone.")
