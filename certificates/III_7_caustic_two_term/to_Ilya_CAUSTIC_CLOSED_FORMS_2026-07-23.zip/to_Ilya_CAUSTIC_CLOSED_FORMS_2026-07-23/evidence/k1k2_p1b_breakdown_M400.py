# k1k2_p1b_breakdown_M400.py — P1b BREAKDOWN MEASUREMENT (companion task, 2026-07-23):
# where does the FLAT-log W_j = sum_i |hhat_i|/(1+i) break?
# Same engine as k1k2_normal_form_arb_fullj.py (the SENT khat-enclosure engine
# retargeted to the model lattice z_n=(n-1/2)pi, x=z^-2, uniform w=1/M; no-reorth
# Lanczos per the toolchain standing order), scaled M 100 -> 400, prec 4096 -> 16384.
# CONTEXT: at M=100 the ball-grade measurement gave W_j = 3.09/2.66/3.30/4.51/4.39/4.47
# (j = 8..98) — flat-log; but R2 (kappa_j <= 1 + a3 W_j, proven) plus the now-DERIVED
# caustic law sup_m|C_j| = a_inf(2j)^{1/3} - 0.934 + o(1) force a3*W_j >= that, so W_j
# (or a3) must grow ~ mu^{1/3} at depth.  This run measures where.
# Columns: max_m|C_j| (the excess — should follow the caustic law for j << M),
# ||hhat||_2, W_j, and the derived-law reference a_inf(2j)^{1/3} - 0.9338.
# Not RH/GRH.
from flint import arb, ctx
import math, time
ctx.prec = 16384
M = 400
t0 = time.time()
xs = [ (arb(2*n-1)*arb.pi()/2)**-2 for n in range(1, M+1) ]
w = arb(1)/M; sw = w.sqrt()
v = [sw]*M; V=[v[:]]; al=[]; be=[]
wk = [xs[i]*v[i] for i in range(M)]
a = sum((v[i]*wk[i] for i in range(M)), arb(0)); al.append(a)
wk = [wk[i]-a*v[i] for i in range(M)]
for j in range(1, M):
    b = sum((t*t for t in wk), arb(0)).sqrt(); be.append(b)
    vn = [t/b for t in wk]; V.append(vn)
    wk = [xs[i]*vn[i]-b*V[-2][i] for i in range(M)]
    a = sum((vn[i]*wk[i] for i in range(M)), arb(0)); al.append(a)
    wk = [wk[i]-a*vn[i] for i in range(M)]
print(f"lanczos {time.time()-t0:.0f}s; prec {ctx.prec}, M={M}, no-reorth", flush=True)
P = [[V[j][n]/sw for n in range(M)] for j in range(M)]
D = [[arb(0)]*M, [arb(1)/be[0]]*M]
for j in range(1, M-1):
    D.append([(P[j][n]+(xs[n]-al[j])*D[j][n]-be[j-1]*D[j-1][n])/be[j] for n in range(M)])
print(f"setup {time.time()-t0:.0f}s", flush=True)
a_inf = 0.34655537161903093
print("  j | recon_err(ball) | max_m|C_j| | caustic law | ||hhat||_2 |   W_j   | worst rad")
for j in (8, 16, 32, 64, 98, 128, 192, 256, 320, 384):
    Phip = [ be[j]*(D[j][n]*P[j+1][n]+P[j][n]*D[j+1][n])
           - be[j-1]*(D[j-1][n]*P[j][n]+P[j-1][n]*D[j][n]) for n in range(M) ]
    h = [Phip[n]-P[j][n]**2 for n in range(M)]
    hhat = [ sum((w*h[n]*P[i][n] for n in range(M)), arb(0)) for i in range(M) ]
    err = arb(0); Cmax = arb(0); acc_d = arb(0)
    chat_acc = [arb(0)]*M
    for m in range(M):
        acc_d += w*Phip[m] - w*P[j][m]**2
        for i in range(M):
            chat_acc[i] += sw*V[i][m]
        r = sum((hhat[i]*chat_acc[i] for i in range(M)), arb(0))
        d = abs(acc_d - r)
        if float(d.mid())+float(d.rad()) > float(err.mid())+float(err.rad()): err = d
        c = abs(acc_d)
        if float(c.mid()) > float(Cmax.mid()): Cmax = c
    n2 = sum((t*t for t in hhat), arb(0)).sqrt()
    wsum = sum((abs(hhat[i])/(1+i) for i in range(M)), arb(0))
    wr = max(float(t.rad()) for t in hhat)
    law = a_inf*(2*j)**(1.0/3.0) - 0.93378
    print(f"{j:4d} | {float(err.mid())+float(err.rad()):.1e} | {float(Cmax.mid()):10.4f} | "
          f"{law:9.4f} | {float(n2.mid()):10.3f} | {float(wsum.mid()):7.4f} | {wr:.1e}", flush=True)
print(f"total {time.time()-t0:.0f}s")
