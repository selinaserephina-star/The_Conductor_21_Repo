# lemmaA_prime_offset_ladder.py — LEMMA A' flagship, companion: the O(1) offset ladder.
# Law (derived + verified in lemmaA_prime_airy_window_law.py):
#   C~_j(m) = K_j - 2^{2/3} nu^{1/3} (AiBi)(w_m) + [oscillatory-side O(1) residual],
# so on the CERTIFIED ladder (E_j = sup_m|C~_j| at m*, all ball radii 0) the implied
# anchor is K_j = 2^{2/3} nu^{1/3} (AiBi)(w_{m*}) - E_j.  This prints K_j (expected slowly
# convergent, K_inf ~ +0.9 = -[ladder offset b = -0.894]), plus the SECONDARY Airy
# constant: the first oscillatory lobe min(AiBi) that governs the positive side of the
# profile and explains the m*/j = 0.664 -> 0.6367 migration (lobe vs caustic competition).
# Not RH/GRH.
import mpmath as mp
mp.mp.dps = 30
PI = mp.pi

AiBi = lambda w: mp.airyai(w)*mp.airybi(w)
a_inf = 2**(mp.mpf(2)/3)*AiBi(0)

# certified ladder (frozen: lemmaA_inf_system_octave_check + lemmaA_prime_deepj logs)
LAD = [(128, 85, mp.mpf('1.49015')), (256, 163, mp.mpf('1.89032')),
       (512, 326, mp.mpf('2.60287')), (768, 489, mp.mpf('3.10576')),
       (1024, 652, mp.mpf('3.50715'))]

print("j    | m*  |   w(m*)  | AiBi(w*) | E_j meas | a_inf nu^(1/3) | K_j = 2^(2/3)nu^(1/3)AiBi(w*)-E_j")
for j, ms, E in LAD:
    nu = mp.mpf(2*j)
    z = (2*ms - 1)*PI/2
    w = mp.cbrt(2)/mp.cbrt(nu)*(nu - z)
    K = 2**(mp.mpf(2)/3)*mp.cbrt(nu)*AiBi(w) - E
    note = " (m* on first lobe, caustic-peak formula not applicable)" if w < -1 else ""
    print(f"{j:4d} | {ms:3d} | {mp.nstr(w, 4):>8s} | {mp.nstr(AiBi(w), 5):>8s} | {mp.nstr(E, 6):>8s} | "
          f"{mp.nstr(a_inf*mp.cbrt(nu), 6):>9s}  | {mp.nstr(K, 4)}{note}")

# K_inf extrapolation from the two deepest pairs (K_j = K_inf - c nu^(-1/3))
(_, _, _), (nu1, K1), (nu2, K2) = (0, 0, 0), (mp.mpf(1024), None), (mp.mpf(2048), None)
Ks = {}
for j, ms, E in LAD:
    nu = mp.mpf(2*j); z = (2*ms - 1)*PI/2
    w = mp.cbrt(2)/mp.cbrt(nu)*(nu - z)
    Ks[j] = 2**(mp.mpf(2)/3)*mp.cbrt(nu)*AiBi(w) - E
for ja, jb in ((512, 1024), (768, 1024)):
    na, nb = mp.mpf(2*ja)**(-mp.mpf(1)/3), mp.mpf(2*jb)**(-mp.mpf(1)/3)
    c = (Ks[jb] - Ks[ja])/(na - nb)
    Kinf = Ks[jb] + c*nb
    print(f"  pair ({ja},{jb}): c = {mp.nstr(c, 3)}   K_inf = {mp.nstr(Kinf, 4)}   "
          f"[ladder-fit offset was b = -0.894 => K ~ +0.894]")

# secondary constant: the first oscillatory lobe of AiBi
wmin = mp.findroot(lambda w: mp.airyai(w, 1)*mp.airybi(w) + mp.airyai(w)*mp.airybi(w, 1),
                   mp.mpf(-2))
print(f"\nfirst lobe of AiBi: w_lobe = {mp.nstr(wmin, 6)}  AiBi(w_lobe) = {mp.nstr(AiBi(wmin), 6)}")
print(f"  => positive-side growth constant a_lobe = 2^(2/3)|AiBi(w_lobe)| = "
      f"{mp.nstr(2**(mp.mpf(2)/3)*abs(AiBi(wmin)), 6)}  vs a_inf = {mp.nstr(a_inf, 6)}")
print(f"  ratio a_lobe/a_inf = {mp.nstr(abs(AiBi(wmin))/AiBi(0), 5)}  (caustic peak wins "
      f"asymptotically; at j=128 the +K_j tilt let the lobe win: recorded m*/j = 0.664)")
