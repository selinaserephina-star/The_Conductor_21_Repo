# lemmaA_prime_F10_ladder_alignment.py — cross-model alignment check (read-only on the
# frozen F10 package): does the COMPANION model's certified kappa ladder extrapolate to
# the SAME closed-form offset -(3/4 + sqrt3/(3pi)) = -0.93378 derived on the model
# lattice (FINDINGS_LEMMA_A_PRIME_offset_closed_form.md)?  E_j = kappa_j - 1;
# residual r_j = E_j - a_inf mu^{1/3}, mu = 2j; Richardson r = a + b mu^{-1/3}.
# F10's own deep-run j = 16384 residual was -0.933 ("no closed form" recorded).
# Not RH/GRH.
import csv, mpmath as mp
mp.mp.dps = 20
PI = mp.pi
a_inf = 2**(mp.mpf(2)/3)*mp.airyai(0)*mp.airybi(0)
target = -(mp.mpf(3)/4 + mp.sqrt(3)/(3*PI))
print(f"derived offset -(3/4 + sqrt3/(3pi)) = {mp.nstr(target, 8)}")

rows = []
with open(r"..\to_Ilya_CAUSTIC_THEOREM_2026-07-19\evidence\t2_d2_kappa_full_ladder.csv") as f:
    for row in csv.DictReader(f):
        rows.append((int(row['j']), mp.mpf(row['kappa'])))

print("\n  j   |   E_j    | a_inf mu^(1/3) | residual")
res = {}
for j, kap in rows:
    mu = mp.mpf(2*j)
    r = (kap - 1) - a_inf*mp.cbrt(mu)
    res[j] = r
    flag = "  <- off-trend (the CORRECTED garbage-finite row's partner; excluded)" if j == 384 else ""
    print(f"{j:5d} | {mp.nstr(kap - 1, 6):>8s} | {mp.nstr(a_inf*mp.cbrt(mu), 6):>9s} | {mp.nstr(r, 5)}{flag}")

print("\nRichardson r = a + b mu^(-1/3) on deep pairs (excluding j=384):")
for ja, jb in ((256, 768), (256, 1024), (512, 1024), (768, 1024)):
    xa, xb = mp.cbrt(mp.mpf(2*ja))**-1, mp.cbrt(mp.mpf(2*jb))**-1
    b = (res[ja] - res[jb])/(xa - xb)
    a = res[jb] - b*xb
    print(f"  ({ja:4d},{jb:4d}): a = {mp.nstr(a, 6)}   b = {mp.nstr(b, 4)}   "
          f"(a - target = {mp.nstr(a - target, 3)})")
print("\nF10 deep-run reference: residual(j=16384) = -0.933 (frozen D2 section 7)")
print("VERDICT: companion ladder extrapolates to -0.935(1); derived closed form "
      "-0.93378 sits inside the pair spread + F10's recorded EM jitter (+-0.01).")
