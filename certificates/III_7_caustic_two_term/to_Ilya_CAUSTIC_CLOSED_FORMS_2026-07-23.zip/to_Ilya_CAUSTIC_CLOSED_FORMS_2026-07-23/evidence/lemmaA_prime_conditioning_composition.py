# lemmaA_prime_conditioning_composition.py — THE CONDITIONING COROLLARY COMPOSED
# (2026-07-23, session 3 fourth push): F11 pairing x derived caustic law => the
# layer-window conditioning statement the Abel/khat machinery needs (re-scoped section 4).
#
# LEMMA C1 (derived localization majorant): for all m,
#   |C~_j(m)| <= Psi_der_j(m) := min( a_inf mu^{1/3} + 1/2 ,
#                                     B0 + a_w mu^{1/3} |w_m|^{-1/2} ),
#   a_w = 2^{2/3} * 1.10/(2pi) = 0.27788...,  w_m = 2^{1/3}nu^{-1/3}(nu - z_m), nu=2j=mu,
# where the cap is the certified-data theorem-candidate (ball-verified j <= 1024,
# margin >= 0.84, derived asymptote a_inf mu^{1/3} - 0.9338) and the wing follows from
# the derived profile C~ = -2^{2/3}nu^{1/3}(AiBi)(w) + Psi0(w) + S_j + O(nu^{-1/3})
# plus the Airy-product envelope |AiBi(w)| <= min(AiBi(0), 1.10/(2pi sqrt|w|)).
# B0 is fitted MINIMAL over the computed profiles with ZERO violations (reported).
# Compare F11's fitted majorant (companion model): 1 + 0.50 mu^{1/3}|shat|^{-1/2}
# = 1 + 0.561 mu^{1/3}|w|^{-1/2} — our wing constant is 2.0x tighter and DERIVED.
#
# LEMMA C2 (pairing, summation by parts): for any field b on the atoms,
#   |sum_n Dsigma_n b_n| <= sum_m |C~_j(m)| |Db_m| + |C~_j(M)||b_M|
#                        <= <Psi_der, |Db|> + boundary.
# For QUANTILE-CLASS fields (|Db_n| <= C_b n^{-3/2}): the caustic-window part is
#   <= a_inf C_b pi^{3/2} mu^{-5/6}(1+o(1)) -> 0, the wing part O(mu^{-1/2}),
# so |pairing| <= B0*C_b*zeta(3/2)-type + o(1) — UNIFORM IN j, no mu^{1/3} anywhere.
# SHARPNESS: a step at m* pays exactly |C~(m*)| ~ a_inf mu^{1/3} - 0.93 (the condition
# is on the field, as F11 found).
#
# This script: (A) verifies the AiBi envelope on a dense grid; (B) recomputes the
# C~ profiles at j = 256/512/1024 (validated engine) and caches them to CSV;
# (C) fits minimal B0 (zero violations) and reports margins; (D) pairing demos:
# ramp, quantile-class, tapered sine, step@m* — true signed pairing vs <Psi_der,|Db|>
# bound vs raw Abel sup|C~|*TV.  Not RH/GRH.
import mpmath as mp
import time, csv, os

mp.mp.dps = 40
PI = mp.pi

# ---------------- engine (validated in lemmaA_prime_airy_window_law.py) ----------------
_DF = {}
def dfact(l):
    if l not in _DF:
        v = mp.mpf(1)
        for i in range(3, 2*l + 2, 2):
            v *= i
        _DF[l] = v
    return _DF[l]

def j_series(l, z):
    guard = int(0.44*float(z)) + 30
    with mp.workdps(mp.mp.dps + guard):
        zz = mp.mpf(z)
        z2 = zz*zz/2
        t = mp.mpf(1); s = mp.mpf(1); k = 0
        thr = mp.mpf(10)**(-(mp.mp.dps + 10))
        while True:
            k += 1
            t *= -z2/(k*(2*l + 1 + 2*k))
            s += t
            if abs(t) < thr*(abs(s) + 1) and 2*k > float(z):
                break
        val = s*zz**l/dfact(l)
    return +val

def rows(z, Lmax, jorders):
    with mp.workdps(80):
        zz = mp.mpf(z)
        y = [-mp.cos(zz)/zz, -mp.cos(zz)/zz**2 - mp.sin(zz)/zz]
        for l in range(1, Lmax):
            y.append((2*l + 1)/zz*y[-1] - y[-2])
        Lup = min(Lmax, int(float(z)) - 3)
        jup = None
        if any(l <= Lup for l in jorders):
            jup = [mp.sin(zz)/zz, mp.sin(zz)/zz**2 - mp.cos(zz)/zz]
            for l in range(1, Lup):
                jup.append((2*l + 1)/zz*jup[-1] - jup[-2])
    jv = {}
    for l in jorders:
        if jup is not None and l <= Lup:
            jv[l] = +jup[l]
        elif z < l:
            jv[l] = j_series(l, z)
        else:
            with mp.workdps(60):
                v = mp.sqrt(PI/(2*z))*mp.besselj(mp.mpf(l) + mp.mpf(1)/2, z)
            jv[l] = +v
    return jv, y

def sigma_pair(j, n):
    z = (2*n - 1)*PI/2
    Ls = sorted({2*j - 2, 2*j - 1, 2*j + 1, 2*j, 2*j + 3})
    jv, y = rows(z, 2*j + 4, Ls)
    def sig(jj):
        return (mp.mpf(2)/(4*jj + 1))*z**2*jv[2*jj + 1]*(
            2*(jj - 1)*jv[2*jj - 1] - z*(jv[2*jj - 2] + y[2*jj - 1]))
    return sig(j), sig(j + 1)

AiBi0 = mp.airyai(0)*mp.airybi(0)
a_inf = 2**(mp.mpf(2)/3)*AiBi0
a_w = 2**(mp.mpf(2)/3)*mp.mpf('1.10')/(2*PI)

def wof(j, n):
    nu = mp.mpf(2*j); z = (2*n - 1)*PI/2
    return mp.cbrt(2)/mp.cbrt(nu)*(nu - z)

# ---------------- Part A: the AiBi envelope ----------------
print("== Part A: envelope |AiBi(w)| <= min(AiBi(0), 1.10/(2pi sqrt|w|)) on a grid ==")
t0 = time.time()
worst = mp.mpf(-1); wworst = None
wg = [mp.mpf(k)/50 for k in range(1, 20001)]  # |w| in (0, 400], step 0.02
for wv in wg:
    for sgn in (1, -1):
        w = sgn*wv
        e = min(AiBi0, mp.mpf('1.10')/(2*PI*mp.sqrt(wv)))
        r = abs(mp.airyai(w)*mp.airybi(w))/e
        if r > worst:
            worst, wworst = r, w
print(f"  max |AiBi|/envelope = {mp.nstr(worst, 6)} at w = {mp.nstr(wworst, 4)}  "
      f"({'PASS' if worst < 1 else 'FAIL'}; margin {mp.nstr((1-worst)*100, 3)}%)  "
      f"[asymptotic amplitude 1/(2pi sqrt|w|), factor 1.10 covers corrections]")
print(f"  ({time.time()-t0:.0f}s)")

# ---------------- Part B: profiles (compute + cache) ----------------
CACHE = "lemmaA_prime_profiles_cache.csv"
prof = {}
if os.path.exists(CACHE):
    with open(CACHE) as f:
        for row in csv.reader(f):
            j, m, v = int(row[0]), int(row[1]), mp.mpf(row[2])
            prof.setdefault(j, {})[m] = v
    print(f"\n== Part B: profiles loaded from cache ({sorted(prof)}) ==")
else:
    print("\n== Part B: computing C~ profiles (j = 256/512/1024) ==")
    for j in (256, 512, 1024):
        t0 = time.time()
        mstar = round(2*j/PI); NPRO = mstar + 45
        acc = mp.mpf(0); prof[j] = {}
        for n in range(1, NPRO + 1):
            s0, s1 = sigma_pair(j, n)
            acc += s1 - s0
            prof[j][n] = acc
        print(f"  j={j}: {NPRO} atoms ({time.time()-t0:.0f}s)", flush=True)
    with open(CACHE, "w", newline="") as f:
        wcsv = csv.writer(f)
        for j in sorted(prof):
            for m in sorted(prof[j]):
                wcsv.writerow([j, m, mp.nstr(prof[j][m], 30)])
    print(f"  cached -> {CACHE}")

# ---------------- Part C: LEMMA C1 — minimal B0, zero violations ----------------
print("\n== Part C: derived majorant Psi_der = min(a_inf mu^(1/3) + 1/2, B0 + a_w mu^(1/3)|w|^(-1/2)) ==")
print(f"  wing constant a_w = 2^(2/3)*1.10/(2pi) = {mp.nstr(a_w, 6)}  "
      f"[F11 fitted equivalent: 0.561 — ours 2.0x tighter, derived]")
need = mp.mpf(0)
for j in prof:
    mu13 = mp.cbrt(mp.mpf(2*j))
    for m, C in prof[j].items():
        w = wof(j, m)
        cap = a_inf*mu13 + mp.mpf(1)/2
        if abs(C) >= cap:
            print(f"  !! cap violation j={j} m={m}")
        wing_no_b0 = a_w*mu13/mp.sqrt(abs(w)) if w != 0 else mp.inf
        b0_needed = abs(C) - wing_no_b0
        if b0_needed > need and abs(C) < cap:
            need = b0_needed
B0 = mp.ceil(need*100)/100
print(f"  minimal B0 (zero violations, all three profiles): {mp.nstr(need, 5)}  -> display B0 = {mp.nstr(B0, 4)}")
viol = 0; minmarg = mp.inf
for j in prof:
    mu13 = mp.cbrt(mp.mpf(2*j))
    for m, C in prof[j].items():
        w = wof(j, m)
        psi = min(a_inf*mu13 + mp.mpf(1)/2,
                  B0 + a_w*mu13/mp.sqrt(abs(w))) if w != 0 else a_inf*mu13 + mp.mpf(1)/2
        marg = psi - abs(C)
        if marg < 0: viol += 1
        if marg < minmarg: minmarg = marg
print(f"  final check: violations = {viol}, min margin = {mp.nstr(minmarg, 4)} over "
      f"{sum(len(p) for p in prof.values())} (j,m) points")

# ---------------- Part D: LEMMA C2 — pairing demos ----------------
print("\n== Part D: pairing demos (TV = 1 fields on m = 1..M0), per j ==")
print("  field          |   true |sum Db*C~|  |  <Psi_der,|Db|>  |  raw Abel sup|C~|*TV")
for j in sorted(prof):
    mu13 = mp.cbrt(mp.mpf(2*j))
    M0 = max(prof[j]); mstar = round(2*j/PI)
    Cm = prof[j]
    supC = max(abs(v) for v in Cm.values())
    def psi(m):
        w = wof(j, m)
        return min(a_inf*mu13 + mp.mpf(1)/2, B0 + a_w*mu13/mp.sqrt(abs(w))) if w != 0 else a_inf*mu13 + mp.mpf(1)/2
    # fields given by their increments Db_m (m = 1..M0-1), TV = sum|Db| = 1
    fields = {}
    fields['ramp'] = {m: mp.mpf(1)/(M0 - 1) for m in range(1, M0)}
    s32 = sum(mp.mpf(m)**mp.mpf(-1.5) for m in range(1, M0))
    fields['quantile n^-3/2'] = {m: mp.mpf(m)**mp.mpf(-1.5)/s32 for m in range(1, M0)}
    lam = max(4, round(mu13.mid if hasattr(mu13,'mid') else float(mu13)))
    raw = {m: mp.sin(2*PI*m/lam) for m in range(1, M0)}
    tvs = sum(abs(raw[m+1] - raw[m]) for m in range(1, M0 - 1))
    fields[f'sine lam={lam}'] = {m: (raw[m+1] - raw[m])/tvs for m in range(1, M0 - 1)}
    fields['step@m*'] = {mstar: mp.mpf(1)}
    print(f"-- j={j} (M0={M0}, sup|C~| = {mp.nstr(supC, 5)}):")
    for name, Db in fields.items():
        true = abs(sum(Db[m]*Cm[m] for m in Db))
        bound = sum(abs(Db[m])*psi(m) for m in Db)
        print(f"  {name:14s} |  {mp.nstr(true, 5):>10s}      |  {mp.nstr(bound, 5):>9s}       |  {mp.nstr(supC, 5)}")
# quantile-class window-term arithmetic (the corollary's decay statement)
print("\n== window-term arithmetic (quantile class, C_b = 1): a_inf*C_b*pi^(3/2)*mu^(-5/6) ==")
for j in (256, 1024, 4096, 16384):
    mu = mp.mpf(2*j)
    print(f"  j={j:6d}: window term <= {mp.nstr(a_inf*PI**mp.mpf(1.5)*mu**(-mp.mpf(5)/6), 3)}")
print("\ndone.")
