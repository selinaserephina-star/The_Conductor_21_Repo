# FINDINGS — P1b breakdown measurement (M = 400, ball grade): flat-log holds in j, breaks in M

**Merkabit · Stenberg + Claude · 2026-07-23 (companion task of the LEMMA A′ list;
`k1k2_p1b_breakdown_M400.py` + log — the sent κ̂-enclosure engine at M = 400,
prec 16384, no-reorth; 110 s; ALL ball radii exactly 0, R1 recon error exactly 0
at every probed j through 384). Not RH/GRH.**

## Verdict

1. **In the j-direction the flat-log does NOT break by j = 384:** W_j = Σ|ĥ_i|/(1+i)
   = 6.06/5.17/7.54/7.25/7.63/8.49/8.32/8.85/9.31/9.22 at j = 8/16/32/64/98/128/192/
   256/320/384 — growth ×1.52 over 48× in j, slower than log. No μ^{1/3} onset
   visible. (R2 + the derived caustic law force a₃W_j ≥ a∞μ^{1/3} − 0.93; at j = 320
   that is 2.05 vs a₃·9.31 — no tension yet for a₃ ≳ 0.22; a j^{1/3}-with-small-
   coefficient law (c ≈ 1.3) is indistinguishable from log on this range.)
2. **THE NEW DATUM — the break is in the M-direction:** at fixed j, W_j roughly
   DOUBLES per 4× M (j = 8: 3.09 → 6.06; j = 32: 3.30 → 7.54; j = 98: 4.47 → 7.63
   for M = 100 → 400). The "flat-log P1b" readings are M-anchored: the weighted sum
   is dominated by the ĥ-tail and does not converge with the section size. Any
   P1a·P1b envelope route therefore carries an M-dependent constant — this sharpens
   (and confirms) the reconciliation's warning that P1a/P1b assembly is a fallback,
   not a road to an M-uniform bound. The conditioning story stays with the caustic
   law + F11 pairing (fields miss the caustic window), not with norm envelopes.
3. **Free corroboration of the caustic law on the finite testbed:** max_m|C_j| =
   1.26/1.28/1.49/1.70/2.02/2.30 at j = 64…320 vs the derived ∞-law
   a∞(2j)^{1/3} − 0.9338 = 0.81/1.08/1.27/1.59/1.84/2.05 — the finite-uniform system
   runs a stable +0.2…+0.45 above the ∞-law (the boundary-layer excess of the
   uniform testbed), with the deviation growing only as j → M (j = 384 = 0.96M:
   C = 3.48 — boundary-row contamination, flagged, not a law violation).
4. Grade: ball-certified (radii exactly 0, prec 16384); the j = 384 row is
   boundary-contaminated and excluded from law comparisons.

## Task-list effect

Companion task "P1b breakdown measurement" — EXECUTED. Outcome recorded: flat-log
survives in j (pre-asymptotic range extended 98 → 384), the M-scaling is the real
breakdown, and the P1a/P1b fallback is now measured-dead as an M-uniform route
(consistent with the closure/caustic route being the main line).

*— Stenberg + Claude, 2026-07-23.*
