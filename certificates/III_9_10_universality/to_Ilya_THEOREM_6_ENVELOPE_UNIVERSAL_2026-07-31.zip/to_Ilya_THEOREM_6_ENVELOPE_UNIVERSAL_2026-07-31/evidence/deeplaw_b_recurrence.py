# deeplaw_b_recurrence.py -- EXACT b(s) via recurrence reduction (exp-free).
# c_n = z^2[Y_nu J_{nu+2}/(nu+1) - Y_{nu-2} J_nu/(nu-1)]  (algebraic Y.J part, mp_spot 113-115).
# Reduce the +-2 shifts to same-order {J,J',Y,Y'} by the Bessel recurrence, express products via
# JY and its z-derivatives + the EXACT Wronskian J Y' - J' Y = 2/(pi z).  Substitute the PROVEN
# JY ~ -(1/(pi nu s))(1 + g/nu^2), g = 2u2-u1^2 = (s^2-1)(s^2-5)/(8 s^6).  NO fitting.  Not RH/GRH.
import sympy as sp
nu, z = sp.symbols('nu z', positive=True)
pi = sp.pi
s = sp.sqrt(1 - (z/nu)**2)                 # = sqrt(1-x^2), x=z/nu
g = (s**2 - 1)*(s**2 - 5)/(8*s**6)         # 2u2 - u1^2 (proven, sympy-exact)
JY  = -(1/(pi*nu*s))*(1 + g/nu**2)         # J_nu Y_nu to 1/nu^2
JYz = sp.diff(JY, z)                        # (JY)' = J'Y + JY'
W   = 2/(pi*z)                              # Wronskian J Y' - J' Y  (EXACT)
p_JY  = JY                                  # J Y
p_JpY = (JYz - W)/2                         # J' Y   ( (JY)'-W )/2
p_JYp = (JYz + W)/2                         # J Y'   ( (JY)'+W )/2
# recurrence:  C_{nu+2} = (2(nu+1)nu/z^2 - 1)C - (2(nu+1)/z)C' ;  C_{nu-2}=(2(nu-1)nu/z^2 -1)C +(2(nu-1)/z)C'
# Y_nu J_{nu+2} = (2(nu+1)nu/z^2-1)(YJ) - (2(nu+1)/z)(Y J')  = A1 p_JY - B1 p_JpY
A1 = 2*(nu+1)*nu/z**2 - 1;  B1 = 2*(nu+1)/z
YJp2 = A1*p_JY - B1*p_JpY
# Y_{nu-2} J_nu = (2(nu-1)nu/z^2-1)(YJ) + (2(nu-1)/z)(Y' J) = A2 p_JY + B2 p_JYp
A2 = 2*(nu-1)*nu/z**2 - 1;  B2 = 2*(nu-1)/z
Ym2J = A2*p_JY + B2*p_JYp
c_n = z**2*( YJp2/(nu+1) - Ym2J/(nu-1) )
# substitute z = nu x, expand in 1/nu
x = sp.symbols('x', positive=True); e = sp.symbols('e', positive=True)
c_x = c_n.subs(z, nu*x)
c_x = c_x.subs(sp.sqrt(1-x**2), sp.Symbol('S', positive=True))   # keep s=S symbolic
S = sp.Symbol('S', positive=True)
c_x = c_x.rewrite(sp.Pow)
# force s->S consistently: replace remaining sqrt(1-x^2)
c_x = c_x.subs(sp.sqrt(1-x**2), S)
c_e = c_x.subs(nu, 1/e)
ser = sp.series(sp.expand(c_e), e, 0, 4).removeO()
C1 = sp.simplify(ser.coeff(e,1)); C3 = sp.simplify(ser.coeff(e,3))
print("C1 (leading, want (2/pi) x^4/S^3):", sp.simplify(C1))
print("  C1 - (2/pi)x^4/S^3 =", sp.simplify(C1 - (2/pi)*x**4/S**3))
b = sp.simplify(C3/C1)
print("\n=== b(s) = C3/C1  (S = s = sqrt(1-x^2)) ===")
# express b in terms of S alone (x^2 = 1-S^2)
b_S = sp.simplify(b.subs(x**2, 1-S**2).subs(x, sp.sqrt(1-S**2)))
b_S = sp.simplify(b_S)
print("  b =", b_S)
print("  b*S^6 =", sp.simplify(b_S*S**6))
print("  caustic limit S->0 of b*S^6 :", sp.limit(sp.simplify(b_S*S**6), S, 0))
for Sv in [sp.Rational(96,100), sp.Rational(866,1000), sp.Rational(6,10)]:
    print(f"  S={float(Sv):.3f}: b={float(b_S.subs(S,Sv)):.4f}  b*S^6={float((b_S*S**6).subs(S,Sv)):.4f}")
