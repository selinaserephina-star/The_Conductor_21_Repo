# THEOREM 6 STRENGTHENING: the deep-law envelope coefficient b(s) is the SAME in the U-model
# (uniform-normalization sigma-difference) and the C-model (companion telescope rows).
#
# Mechanism (structural identity, not a fit):
#   Companion algebraic object   T(p,z) = z^2[ Y_p J_{p+2}/(p+1) - Y_{p-2} J_p/(p-1) ].
#   Companion c_n           = T(mu,z)  + O(e^{-2 nu xi}),   mu  = 2j+1/2.
#   U-model increment dsig_n = -(pi/2) T(nu*,z) + O(e^{-2 nu xi}),  nu* = 2j+3/2 = mu+1.
# So the two per-atom deep-law increments are the SAME Debye object at reference orders differing
# by exactly 1.  The recurrence machine (deeplaw_b_recurrence.py) derives, for T at a GENERIC
# symbolic order nu:  (pi/2) nu T(nu)/(x^4/s^3) = 1 + b(s)/nu^2 + ...,  b(s)=1+9/8 s^2+35/8 s^6.
# Hence b_U(s) = b(s) identically, and (since the drop is beyond-all-orders) the ENTIRE deep-law
# power series is shared.  Op 1 / caustic / frame-side.  Not RH/GRH.
import mpmath as mp
import sympy as sp
mp.mp.dps = 50

# ---------- Part A: the structural identity, numerically (super-exp-small residual) ----------
def J(p, z): return mp.besselj(p, z)
def Y(p, z): return mp.bessely(p, z)
def T(p, z): return z**2*( Y(p, z)*J(p+2, z)/(p+1) - Y(p-2, z)*J(p, z)/(p-1) )

def sph_j(l, z): return mp.sqrt(mp.pi/(2*z))*mp.besselj(l+mp.mpf(1)/2, z)
def sph_y(l, z): return mp.sqrt(mp.pi/(2*z))*mp.bessely(l+mp.mpf(1)/2, z)
def sigma(j, z):
    br = 2*(j-1)*sph_j(2*j-1, z) - z*(sph_j(2*j-2, z) + sph_y(2*j-1, z))
    return (mp.mpf(2)/(4*j+1))*z*z*sph_j(2*j+1, z)*br
def dsig(j, z): return sigma(j+1, z) - sigma(j, z)
def c_companion_full(j, z):
    mu = mp.mpf(2*j)+mp.mpf(1)/2
    JJ = lambda k: mp.besselj(k+mp.mpf(1)/2, z); YY = lambda k: mp.bessely(k+mp.mpf(1)/2, z)
    dW = ((JJ(2*j-1) - (2*mu-1)*JJ(2*j)/(2*z) + YY(2*j))*JJ(2*j+2)/(mu+1)
          - (JJ(2*j-3) - (2*mu-5)*JJ(2*j-2)/(2*z) + YY(2*j-2))*JJ(2*j)/(mu-1))
    return z**2*dW

print("=== A. structural identity (below turning; residual = dropped J.J ~ e^{-2 nu xi}) ===")
print("  j    X     dsig_n vs -(pi/2)T(2j+3/2)   |   c_n vs T(2j+1/2)")
for j in [100, 200, 400]:
    mu = mp.mpf(2*j)+mp.mpf(1)/2; nus = mu+1
    for X in [mp.mpf('0.4'), mp.mpf('0.6')]:
        zu = nus*X; zc = mu*X
        r1 = abs(dsig(j, zu) + (mp.pi/2)*T(nus, zu))/abs(dsig(j, zu))
        r2 = abs(c_companion_full(j, zc) - T(mu, zc))/abs(c_companion_full(j, zc))
        print(f"  {j:4d} {float(X):.1f}   reldiff={mp.nstr(r1,3):>9}            reldiff={mp.nstr(r2,3)}")

# ---------- Part B: the machine is ORDER-GENERIC -> b(s) is a property of T(nu) at any nu ----------
print("\n=== B. recurrence machine on T at GENERIC symbolic order nu -> b(s) ===")
nu, z = sp.symbols('nu z', positive=True); pi = sp.pi
s = sp.sqrt(1 - (z/nu)**2)
g = (s**2 - 1)*(s**2 - 5)/(8*s**6)
JY = -(1/(pi*nu*s))*(1 + g/nu**2)
JYz = sp.diff(JY, z); W = 2/(pi*z)
p_JY = JY; p_JpY = (JYz - W)/2; p_JYp = (JYz + W)/2
A1 = 2*(nu+1)*nu/z**2 - 1; B1 = 2*(nu+1)/z
A2 = 2*(nu-1)*nu/z**2 - 1; B2 = 2*(nu-1)/z
c_n = z**2*((A1*p_JY - B1*p_JpY)/(nu+1) - (A2*p_JY + B2*p_JYp)/(nu-1))   # = T(nu) algebraic
x = sp.symbols('x', positive=True); S = sp.Symbol('S', positive=True)
c_e = c_n.subs(z, nu*x).subs(sp.sqrt(1-x**2), S).subs(nu, 1/sp.Symbol('e', positive=True))
e = sp.Symbol('e', positive=True)
ser = sp.series(sp.expand(c_e), e, 0, 4).removeO()
C1 = sp.simplify(ser.coeff(e, 1)); C3 = sp.simplify(ser.coeff(e, 3))
b = sp.simplify((C3/C1).subs(x**2, 1-S**2).subs(x, sp.sqrt(1-S**2)))
print("  leading C1 - (2/pi)x^4/S^3 =", sp.simplify(C1 - (2/pi)*x**4/S**3), " (0 => shared x^4/s^3 law)")
print("  b(s) =", b, "   [same expression applies at nu=2j+1/2 (C) and nu=2j+3/2 (U)]")
print("  b*S^6 =", sp.simplify(b*S**6), "   caustic S->0 :", sp.limit(sp.simplify(b*S**6), S, 0))

# ---------- Part C: U-model b measured in its natural order nu*=2j+3/2 == b(s) ----------
print("\n=== C. U-model b_rel (natural order nu*=2j+3/2) vs companion b(s) ===")
def Rstar(j, X):
    nus = mp.mpf(2*j)+mp.mpf(3)/2; zz = nus*X; Ss = mp.sqrt(1-X*X)
    return -(2/mp.pi)*(mp.pi/2)*nus*dsig(j, zz)/(X**4/Ss**3), nus
JS = [200, 400, 800, 1600, 3200]
print("  X      b_U (fit, natural order)   b(s)=1+9/8S^2+35/8S^6     diff")
for Xf in [mp.mpf('0.3'), mp.mpf('0.5'), mp.mpf('0.7')]:
    Rs = []; nn = []
    for j in JS:
        r, nu_ = Rstar(j, Xf); Rs.append(r); nn.append(nu_)
    n = len(JS); M = mp.matrix(n, n)
    for i in range(n):
        for k in range(n): M[i, k] = 1/nn[i]**k
    coef = mp.lu_solve(M, mp.matrix(Rs))
    Sv = mp.sqrt(1-Xf*Xf); bc = 1 + mp.mpf(9)/(8*Sv**2) + mp.mpf(35)/(8*Sv**6)
    print(f"  {float(Xf):.1f}    {mp.nstr(coef[2],11):>16}      {mp.nstr(bc,11):>13}     {mp.nstr(coef[2]-bc,3)}")
