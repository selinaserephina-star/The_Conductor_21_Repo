# U-model deep law in the NATURAL centering nu* = 2j+3/2 (the top spherical order 2j+1 <-> J_{2j+3/2}).
# X = z/nu*, S = sqrt(1-X^2).  R* := -(2/pi)*(pi/2) nu* dsig /(X^4/S^3) = 1 + b_rel/nu*^2 (1/nu* term should vanish).
# Compare b_rel(S) to companion b(s) = 1 + 9/8 s^2 + 35/8 s^6.
import mpmath as mp
mp.mp.dps = 60

def sph_j(l, z): return mp.sqrt(mp.pi/(2*z))*mp.besselj(l+mp.mpf(1)/2, z)
def sph_y(l, z): return mp.sqrt(mp.pi/(2*z))*mp.bessely(l+mp.mpf(1)/2, z)
def sigma(j, z):
    br = 2*(j-1)*sph_j(2*j-1, z) - z*(sph_j(2*j-2, z) + sph_y(2*j-1, z))
    return (mp.mpf(2)/(4*j+1))*z*z*sph_j(2*j+1, z)*br
def dsig(j, z): return sigma(j+1, z) - sigma(j, z)

def Rstar(j, X):
    nus = mp.mpf(2*j)+mp.mpf(3)/2       # natural order
    z = nus*X; S = mp.sqrt(1-X*X)
    val = -(2/mp.pi)*(mp.pi/2)*nus*dsig(j, z)/(X**4/S**3)
    return val, nus

JS = [200, 400, 800, 1600, 3200]
print("Fit R* = 1 + a/nu* + b_rel/nu*^2 + d/nu*^3 + e/nu*^4  (a should be ~0)\n")
print("  X       R*_const       a(1/nu*)       b_rel           b_comp(=1+9/8S^2+35/8S^6)   b_rel-b_comp")
for Xf in [mp.mpf('0.3'), mp.mpf('0.4'), mp.mpf('0.5'), mp.mpf('0.6'), mp.mpf('0.7'), mp.mpf('0.8')]:
    Rs = []; nus = []
    for j in JS:
        r, nu = Rstar(j, Xf); Rs.append(r); nus.append(nu)
    n = len(JS)
    M = mp.matrix(n, n)
    for i in range(n):
        for k in range(n):
            M[i, k] = 1/nus[i]**k
    coef = mp.lu_solve(M, mp.matrix(Rs))
    c0, a, b = coef[0], coef[1], coef[2]
    S = mp.sqrt(1-Xf*Xf)
    bc = 1 + mp.mpf(9)/(8*S**2) + mp.mpf(35)/(8*S**6)
    print(f"  {float(Xf):.1f}   {mp.nstr(c0,10):>11}  {mp.nstr(a,7):>11}  {mp.nstr(b,10):>12}  "
          f"{mp.nstr(bc,10):>14}      {mp.nstr(b-bc,6)}")
