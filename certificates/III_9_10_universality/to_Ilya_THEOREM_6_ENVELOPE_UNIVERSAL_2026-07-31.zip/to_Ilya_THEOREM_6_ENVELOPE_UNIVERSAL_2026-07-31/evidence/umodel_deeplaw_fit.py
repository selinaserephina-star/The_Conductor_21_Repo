# Careful Richardson fit of the U-model per-atom increment deep law.
# dsig_n = sigma^{(j+1)}(z) - sigma^{(j)}(z),  z = mu*x,  mu = 2j+1/2.
# Define R(x,mu) = (pi/2) mu dsig_n / (x^4/s^3).   Fit R = K + a/mu + b/mu^2 + d/mu^3.
# Compare K to -pi/2 ; a to 0 (companion had a=0) ; b(s) to companion 1+9/8s^2+35/8s^6.
import mpmath as mp
mp.mp.dps = 60

def sph_j(l, z): return mp.sqrt(mp.pi/(2*z))*mp.besselj(l+mp.mpf(1)/2, z)
def sph_y(l, z): return mp.sqrt(mp.pi/(2*z))*mp.bessely(l+mp.mpf(1)/2, z)
def sigma(j, z):
    br = 2*(j-1)*sph_j(2*j-1, z) - z*(sph_j(2*j-2, z) + sph_y(2*j-1, z))
    return (mp.mpf(2)/(4*j+1))*z*z*sph_j(2*j+1, z)*br
def dsig(j, z): return sigma(j+1, z) - sigma(j, z)

def Rval(j, x):
    mu = mp.mpf(2*j)+mp.mpf(1)/2
    z = mu*x; s = mp.sqrt(1-x*x)
    return (mp.pi/2)*mu*dsig(j, z)/(x**4/s**3), mu

# geometric j ladder; fit K + a/mu + b/mu^2 + d/mu^3 + e/mu^4 (5 pts)
JS = [200, 400, 800, 1600, 3200]
print("K = leading const, a = 1/mu coeff, b = 1/mu^2 coeff (the target)\n")
print("  x       K(fit)          a(fit)         b(fit)          [K vs -pi/2, resid]")
bU = {}
for xf in [mp.mpf('0.3'), mp.mpf('0.4'), mp.mpf('0.5'), mp.mpf('0.6'), mp.mpf('0.7'), mp.mpf('0.8')]:
    Rs = []; mus = []
    for j in JS:
        r, mu = Rval(j, xf); Rs.append(r); mus.append(mu)
    n = len(JS)
    M = mp.matrix(n, n)
    for i in range(n):
        for k in range(n):
            M[i, k] = 1/mus[i]**k
    v = mp.matrix(Rs)
    coef = mp.lu_solve(M, v)
    K, a, b = coef[0], coef[1], coef[2]
    bU[xf] = b
    resid = abs(K - (-mp.pi/2))
    print(f"  {float(xf):.1f}   {mp.nstr(K,10):>13}  {mp.nstr(a,8):>12}  {mp.nstr(b,10):>12}   "
          f"[Kres {mp.nstr(resid,3)}]")

print("\n=== compare b_U(s) to companion b(s)=1+9/8s^2+35/8s^6 ===")
print("  x       b_U(fit)         b_comp          b_U/K?          b_U + K*?  ")
for xf in [mp.mpf('0.3'), mp.mpf('0.4'), mp.mpf('0.5'), mp.mpf('0.6'), mp.mpf('0.7'), mp.mpf('0.8')]:
    s = mp.sqrt(1-xf*xf)
    bc = 1 + mp.mpf(9)/(8*s**2) + mp.mpf(35)/(8*s**6)
    b = bU[xf]
    # if U-model law is K*(x^4/s^3)(1+ a/mu + b_rel/mu^2), then b (abs) = K*b_rel; b_rel=b/K
    b_rel = b/(-mp.pi/2)
    print(f"  {float(xf):.1f}   {mp.nstr(b,10):>13}  {mp.nstr(bc,10):>12}  b_rel={mp.nstr(b_rel,8):>10}  "
          f"b_rel/b_comp={mp.nstr(b_rel/bc,8)}")
