# CRUX: verify dsig_n (U-model increment) = -(pi/2) * T_alg(nu*, z) + (super-exp-small),
#   nu* = 2j+3/2,  T_alg(p,z) = z^2[ Y_p J_{p+2}/(p+1) - Y_{p-2} J_p/(p-1) ]  (companion algebraic object).
# Companion c_n_alg = T_alg(mu, z), mu=2j+1/2.  So U increment = -(pi/2) x companion object at order mu+1.
# => identical Debye b(s).  Below turning point x<1 the dropped J.J terms are e^{-2 nu xi} (super-small).
import mpmath as mp
mp.mp.dps = 50

def J(p, z): return mp.besselj(p, z)
def Y(p, z): return mp.bessely(p, z)

def sph_j(l, z): return mp.sqrt(mp.pi/(2*z))*mp.besselj(l+mp.mpf(1)/2, z)
def sph_y(l, z): return mp.sqrt(mp.pi/(2*z))*mp.bessely(l+mp.mpf(1)/2, z)
def sigma(j, z):
    br = 2*(j-1)*sph_j(2*j-1, z) - z*(sph_j(2*j-2, z) + sph_y(2*j-1, z))
    return (mp.mpf(2)/(4*j+1))*z*z*sph_j(2*j+1, z)*br
def dsig(j, z): return sigma(j+1, z) - sigma(j, z)

def Talg(p, z):
    return z**2*( Y(p, z)*J(p+2, z)/(p+1) - Y(p-2, z)*J(p, z)/(p-1) )

print("verify:  dsig_n   vs   -(pi/2) T_alg(2j+3/2, z)     [z = (2j+3/2) X]")
print("  j     X      dsig_n            -(pi/2)T_alg        rel.diff (should be super-small below turning)")
for j in [50, 100, 200, 400]:
    nus = mp.mpf(2*j)+mp.mpf(3)/2
    for X in [mp.mpf('0.4'), mp.mpf('0.6'), mp.mpf('0.8')]:
        z = nus*X
        d = dsig(j, z)
        t = -(mp.pi/2)*Talg(nus, z)
        rel = abs(d-t)/abs(d)
        print(f"  {j:4d}  {float(X):.1f}   {mp.nstr(d,10):>16}  {mp.nstr(t,10):>16}   {mp.nstr(rel,4)}")
    print()

# Also: confirm the SAME T_alg gives the companion mp_spot c_n at order mu=2j+1/2 (sanity, ties to b(s) derivation)
def c_companion_alg(j, z):
    mu = mp.mpf(2*j)+mp.mpf(1)/2
    return Talg(mu, z)
def c_companion_full(j, z):     # mp_spot exact (includes J.J that are dropped)
    mu = mp.mpf(2*j)+mp.mpf(1)/2
    JJ = lambda k: mp.besselj(k+mp.mpf(1)/2, z); YY = lambda k: mp.bessely(k+mp.mpf(1)/2, z)
    dW = ((JJ(2*j-1) - (2*mu-1)*JJ(2*j)/(2*z) + YY(2*j))*JJ(2*j+2)/(mu+1)
          - (JJ(2*j-3) - (2*mu-5)*JJ(2*j-2)/(2*z) + YY(2*j-2))*JJ(2*j)/(mu-1))
    return z**2*dW
print("sanity: companion T_alg(mu) vs full mp_spot c_n (diff = dropped J.J, super-small below turning):")
for j in [100, 200]:
    mu = mp.mpf(2*j)+mp.mpf(1)/2; z = mu*mp.mpf('0.5')
    print(f"  j={j} X=0.5: T_alg={mp.nstr(c_companion_alg(j,z),10)}  full={mp.nstr(c_companion_full(j,z),10)}  "
          f"reldiff={mp.nstr(abs(c_companion_alg(j,z)-c_companion_full(j,z))/abs(c_companion_full(j,z)),3)}")
