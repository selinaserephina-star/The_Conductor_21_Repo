# Reply to Ilya — b(s) is universal: Theorem 6 grows an envelope

**From Selina + Claude (Opus), 2026-07-31. Addendum to Theorem 6 (offset universality,
sent 07-30) and the exact b(s) (sent 07-31). We ran the recurrence machine on the U-model
deep-row law, as the last note suggested. Result below. Frame-side (Op 1 / caustic); the
wall is untouched. Not RH/GRH.**

## The answer

> **b_U(s) = b_C(s) = 1 + 9/(8s²) + 35/(8s⁶).** The deep-law envelope coefficient is the
> **same** in the U-model (uniform-normalization σ-difference) and the C-model (companion
> telescope rows). So **Theorem 6 strengthens from "same offset" to "same deep-law error
> envelope."**

And it is not a coefficient coincidence — it is a **structural identity**, which is the
cleanest way this could have gone.

## Why (the one-line mechanism)

Both per-atom deep-law increments are the **same Debye object**
`T(p,z) = z²[Y_p J_{p+2}/(p+1) − Y_{p−2} J_p/(p−1)]`, read at reference orders differing by
exactly 1:

- **C:**  `c_n = T(μ, z) + O(e^{−2νξ})`,  μ = 2j+½.
- **U:**  `δσ_n = −(π/2)·T(ν★, z) + O(e^{−2νξ})`,  ν★ = 2j+3/2 = μ+1.

Your recurrence machine derives b(s) for `T(ν)` at a **generic** symbolic order ν (it never
uses ν = 2j+½). So the exact same derivation applies at ν★, and b_U = b_C identically. Because
the two models differ only by the beyond-all-orders `e^{−2νξ}` term, **the entire deep-law 1/ord
power series is shared** — b(s) and every deeper coefficient.

## The trap worth knowing (why the naive test misfires)

Measured in a **common** centering, the U-model shows a large **nonzero 1/μ term**
`a(x) = (π/2)(5 + 3x²/s²)` — which reads as "the envelopes differ at first order." It is a
**pure recentering artifact**: exactly the 1/μ term the order-shift ν★ = μ+1 generates on
`−(x⁴/s³)/ord`. In each model's **natural order** (U: 2j+3/2 = the top Bessel order j_{2j+1};
C: 2j+½) the 1/ord term vanishes and b(s) is intrinsic. The invariant, centering-free statement
is the T(ν) identity above. (We recorded this explicitly so nobody re-derives the artifact and
concludes non-universality.)

## Verified three ways (`umodel_b_universality.py`, dps 50)

1. **Structural identity** — `δσ_n` vs `−(π/2)T(2j+3/2)` and `c_n` vs `T(2j+½)`: relative
   ~10⁻⁵⁰ below turning (the residual IS the dropped `e^{−2νξ}`, growing only as x→1 where ξ→0).
2. **Order-generic machine** — the recurrence reduction at symbolic ν returns
   `b(s) = 1 + 9/(8s²) + 35/(8s⁶)`, leading `(2/π)x⁴/s³` (residual `2x²(1−S²−x²)/(πS³) ≡ 0`).
3. **Direct Richardson** of b_U in natural order vs b(s): 8–10 digits (x=0.3: 1.4e−8; x=0.7:
   1.8e−5 = finite-j tail, growing toward the caustic — consistent with an exact match).

## What this closes / settles

- **Theorem 6 (Paper A §9):** the "one named remainder" (the deep-law envelope) is now not only
  closed-form (b(s), sent 07-31) but **shown universal** — the companion R_∞ envelope transplants
  to the U-model verbatim. Offset universality → deep-law-envelope universality.
- **Next-coefficient c(s) at O(1/μ³):** **also universal** by the same identity — no separate
  U-model computation needed; whatever T(ν) gives at O(1/ν³) holds for both models.
- **Twin invariance:** consistent — b(s) is a property of T(ν), pure Bessel geometry, no
  arithmetic, so the twin shares it.

## For your independent check

The U-model summand in exact Bessel form (spherical → half-integer):
`σ_n^{(j)} = (2/(4j+1))·z²·j_{2j+1}(z)·[2(j−1)j_{2j−1}(z) − z(j_{2j−2}(z)+y_{2j−1}(z))]`,
`j_l=√(π/2z)J_{l+½}`, `y_l=√(π/2z)Y_{l+½}`, `z=(2n−½)π`; increment `δσ_n = σ^{(j+1)}−σ^{(j)}`.
Reduce below turning (only the single Y·J survives) and you should land on `−(π/2)T(2j+3/2)`. If
you get a different b_U, send it and we'll reconcile — but the route needs only your two proven
inputs (JY's g and the vanishing 1/ν term) plus the exact Wronskian, at order ν★ instead of μ.

*— Selina + Claude (Opus), 2026-07-31. Two models, one Debye object T(ν) read at orders μ and
μ+1; so b(s) — and every deeper coefficient — is universal, and Theorem 6 grows an envelope.
Not RH/GRH.*
