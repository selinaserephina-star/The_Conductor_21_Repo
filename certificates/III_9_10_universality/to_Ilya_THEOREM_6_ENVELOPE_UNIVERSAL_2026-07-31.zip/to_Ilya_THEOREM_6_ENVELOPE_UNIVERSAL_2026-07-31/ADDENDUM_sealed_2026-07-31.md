# THEOREM 6 ADDENDUM — deep-law-envelope universality (b(s) shared across the companion family)

**Merkabit · Stenberg + Claude (Opus) · sealed 2026-07-31. Addendum to
`to_Ilya_THEOREM_6_UNIVERSALITY_2026-07-30` (offset universality) and
`to_Ilya_DEEPLAW_b_EXACT_2026-07-31` (the exact b(s)). Upgrades Theorem 6's offset
universality to deep-law-envelope universality. Paper A §9 lane (finite-section caustic
analysis); no Op 2 / wall contact. Not RH/GRH.**

---

## Statement (the strengthening)

For the two companion-family models M ∈ {U (uniform-normalization, Paper A σ-difference),
C (companion, F10 telescope rows)}, the per-atom deep-law increment obeys, in each model's
natural order (U: ν★ = 2j+3/2; C: μ = 2j+½), with x = z/ord, s = √(1−x²):

  **(π/2)·ord·(increment)/(x⁴/s³) = 1 + b(s)/ord² + O(1/ord³),  b(s) = 1 + 9/(8s²) + 35/(8s⁶)**
  — the **same** b(s) in both models.

In fact the **entire** deep-law 1/ord power series is shared; the two models differ only by a
beyond-all-orders term e^{−2νξ}. This upgrades Theorem 6:

  **Theorem 6 (offset) → Theorem 6′ (envelope): both models share not only the offset
  −(3/4 + √3/(3π)) but the entire deep-law error envelope, coefficient b(s) and all higher orders.**

## Proof (structural identity — not a fit)

Define the companion algebraic Debye object `T(p,z) = z²[Y_p J_{p+2}/(p+1) − Y_{p−2} J_p/(p−1)]`
(the Y·J part of the companion c_n; J·J are e^{−2νξ} below turning, dropped). Then:

1. **Companion:** `c_n = T(μ,z) + O(e^{−2νξ})`, μ = 2j+½ (FINDINGS_deeplaw_b_exact §2).
2. **U-model:** the summand `σ_n^{(j)} = (2/(4j+1))z² j_{2j+1}[2(j−1)j_{2j−1} − z(j_{2j−2}+y_{2j−1})]`
   has only one Y below turning (`y_{2j−1} = Y_{ν★−2}`); carrying its `−z` coefficient and the
   prefactor `πz²/(4j+1)` and telescoping j → j+1 gives
   **`δσ_n = σ^{(j+1)}_n − σ^{(j)}_n = −(π/2)·T(ν★,z) + O(e^{−2νξ})`, ν★ = 2j+3/2 = μ+1.**
3. The recurrence machine (`deeplaw_b_recurrence.py`) derives b(s) for `T(ν)` at a **generic
   symbolic order ν**. Applying it at ν = μ gives the companion law; at ν = ν★ gives the U-model
   law. Same b(s). Since the model difference is beyond all orders, every 1/ord coefficient agrees.

## Verification (reproduced this seal — `umodel_b_universality.py` + log, dps 50)

- **§A structural identity:** `δσ_n` vs `−(π/2)T(2j+3/2)` and `c_n` vs `T(2j+½)` agree to
  relative ~10⁻⁵⁰ below turning (residual = dropped e^{−2νξ}, growing only as x→1).
- **§B order-generic machine:** symbolic ν → `b(s) = 1 + 9/(8s²) + 35/(8s⁶)`, `b·s⁶ = s⁶ + (9/8)s⁴ + 35/8`,
  caustic 35/8; leading residual `C1 − (2/π)x⁴/S³ = 2x²(1−S²−x²)/(πS³) ≡ 0` on S²=1−x².
- **§C direct Richardson** (natural order ν★, j = 200…3200) vs b(s): x=0.3 → 1.4e−8,
  x=0.5 → 2.0e−7, x=0.7 → 1.8e−5 (residual = finite-j tail, blows up toward the caustic).

## The natural-order caveat (recorded to prevent a false negative)

In a **common** centering the U-model increment shows a large 1/μ term
`a(x) = (π/2)(5 + 3x²/s²)` (`umodel_deeplaw_fit.py`, measured to 5 digits) — a **pure
recentering artifact** of the order-shift ν★ = μ+1 acting on −(x⁴/s³)/ord. It **vanishes** in
the natural order ν★ (`umodel_deeplaw_natural.py`, ~10⁻¹²), exactly as the companion's 1/μ term
vanishes at μ = 2j+½. The centering-free invariant is the T(ν) identity above.

## Grade and boundaries

- **Grade: THEOREM (derivation grade).** The identity `δσ_n = −(π/2)T(2j+3/2) + O(e^{−2νξ})` is
  exact algebra on the Bessel forms (numerically ~10⁻⁵⁰); b(s) at generic ν is the already-PROVEN
  companion derivation. No constant fitted.
- **Consequences (free):** the next coefficient c(s) at O(1/μ³) is likewise universal (no separate
  U calc); twin invariance of b(s) is consistent (pure Bessel geometry).
- **Scope.** Finite-section caustic asymptotics (Paper A Part IV, §9). Op 1 / companion family;
  **does not touch Op 2 or the wall.**

## Manifest (`evidence/`)

`FINDINGS_umodel_b_universality.md` (the finding), `umodel_b_universality.py` (+
`_run.log`, authoritative: §A identity, §B order-generic machine, §C Richardson),
`umodel_structural_identity.py` (identity focus), `umodel_deeplaw_natural.py` (natural-order
fit), `umodel_deeplaw_fit.py` (the centering-artifact, common centering), `deeplaw_b_recurrence.py`
(the machine, order-generic — reference copy of the 07-31 send).

*— Stenberg + Claude (Opus), sealed 2026-07-31. One Debye object T(ν) at orders μ and μ+1;
b(s) and every deeper coefficient universal; Theorem 6 grows an envelope. Not RH/GRH.*
