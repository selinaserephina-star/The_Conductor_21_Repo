import sys, numpy as np
sys.path.insert(0,"../to_Ilya_CAUSTIC_THEOREM_2026-07-19/evidence")
from t2_d2_caustic_exponent import rows
def ns_of(j): return int(np.floor((2*j+0.5)/np.pi+0.5))
def s_of(x): return np.sqrt(1.0-x*x)
JS=[512,1024,2048,4096,8192]
DATA={}
for j in JS:
    mu=2*j+0.5; ns=ns_of(j); z,c,K=rows(j,ns+2)
    x=z[:ns]/mu; s=s_of(x); law=x**4/s**3; meas=(np.pi/2)*mu*c[:ns]
    DATA[j]=(mu,x,meas/law-1.0)
xt=np.arange(0.20,0.86,0.025)
b=[]
for xx in xt:
    mus=[];dl=[]
    for j in JS:
        mu,x,delta=DATA[j]; mus.append(mu); dl.append(np.interp(xx,x,delta))
    mus=np.array(mus);dl=np.array(dl)
    M=np.vstack([1/mus,1/mus**2,1/mus**3]).T
    coef,*_=np.linalg.lstsq(M,dl,rcond=None); b.append(coef[1])
b=np.array(b); s=s_of(xt); s2=s*s
g=b*s**6   # b(x)*s^6
# polynomial fit g = c0 + c1 s^2 + c2 s^4  (+ c3 s^6)
for deg,lbl in [(2,"c0+c1 s^2+c2 s^4"),(3,"+c3 s^6")]:
    A=np.vstack([s2**k for k in range(deg+1)]).T
    coef,res,*_=np.linalg.lstsq(A,g,rcond=None)
    pred=A@coef; mx=np.max(np.abs(pred-g))
    print(f"  b*s^6 = {lbl}:  coeffs={[round(v,4) for v in coef]}   maxdev={mx:.2e}")
# show g at sample x and the caustic limit c0 (=lim s->0 of b*s^6)
print("\n  x, s^2, b(x), b*s^6:")
for i in range(0,len(xt),3):
    print(f"   x={xt[i]:.3f} s^2={s2[i]:.3f}  b={b[i]:8.3f}  b*s^6={g[i]:.4f}")
# test nice rationals for c0 (caustic-limit constant) via the deg-2 fit
A=np.vstack([s2**k for k in range(3)]).T; coef,*_=np.linalg.lstsq(A,g,rcond=None)
c0,c1,c2=coef
print(f"\n  => b(s) = ({c0:.4f} + {c1:.4f} s^2 + {c2:.4f} s^4)/s^6")
print(f"     caustic-limit c0={c0:.4f} (35/8={35/8}, 4={4}, 25/8={25/8}); check 385/1152*? ..")
print(f"     DISPLAYED ENVELOPE: |delta_n| <= sup_deep b(s)/mu^2; b grows to caustic ~ c0/s^6")
