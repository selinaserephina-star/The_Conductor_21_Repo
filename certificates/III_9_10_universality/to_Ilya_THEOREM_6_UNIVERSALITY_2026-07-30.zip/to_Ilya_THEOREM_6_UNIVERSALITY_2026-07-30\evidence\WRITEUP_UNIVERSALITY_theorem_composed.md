# WRITE-UP — THEOREM 6 COMPOSED: offset universality across the companion family (the stage-3 transplant, at theorem grade)

**Merkabit · Stenberg + Claude · 2026-07-25 (night). OUTSTANDING 2.2 executed: the term-by-term
transplant of the stage-3 arithmetic (`FINDINGS_LEMMA_A_PRIME_F10_stage3_theorem.md`) into a
composed theorem. New verification: `universality_transplant_verify.py` (+log) — the full
symbolic identity set re-checked exact (sympy), and V/Jac_∞/R_∞ pinned to ~20 digits by
evaluating the V-integral's singular part in closed form (∫3/s³dx = 3x/s exactly; series-safe
splice, deviation 4.8e−14). Not RH/GRH.**

## THEOREM 6 (offset universality). 

Let C̃_j^{(M)} be the excess partial sums of the two models M ∈ {U (uniform-normalization,
this paper), C (companion, F10's telescope rows)} — both j-differences of the same Airy
product kernel — and E_j = sup_m |C̃_j(m)|, μ = 2j. Then for BOTH models

  **E_j − a∞μ^{1/3} → −(3/4 + √3/(3π)) = −0.93377629847393068…,**

and the offset decomposes identically in the two slicings:

**(i) The shared Airy channel [E, exact].** The caustic-window first-order profile
contributes (1/2)∫Ψ₁ = 2Ai(0)Ai′(0) = −√3/(3π) in both models — an exact Airy identity
(2·3^{−2/3}Γ(2/3)^{−1}·(−3^{−1/3})Γ(1/3)^{−1} = −√3/(3π), sympy-zero; check A7).

**(ii) The cut-free deep ledger [D+E].** With x = z/μ, s = √(1−x²), and any cut
x₀ ∈ (0,1) splitting the deep range:

  F(c) = c/s − (3/2)arcsin c + cs/2   (F′ = c⁴/s³ exact [A1]; F = 1/s − 3π/4 + O(s) at the
  caustic [A2]),  W(x) = artanh(s) − s,  V(x₀) = (1/(3π))∫_{x₀}^{1}(1/W − 3/s³)dx − x₀/(πs₀),

the three ledger constants have closed forms — zone-i mass = F(x₀)/π, Jac_∞ = V(x₀) + D_∞
(the measure identity), R_∞(x₀) = −3/4 − F(x₀)/π − V(x₀) — and their sum obeys the
**cut-free identity**

  **[zone-i] + [−D_∞ + Jac_∞ + R_∞] = −3/4   for every x₀** (x₀-independence: dF/dx₀
  compensation is exact; the −3/4 is F's caustic finite part and belongs to no slicing).

At the companion's conventional cut x₀ = 1/2 (20-digit values, this run):

| constant | closed form | value |
|---|---|---|
| F(1/2)/π (zone-i) | (1/π)(1/√3 + √3/8) − 1/4 [A3, exact] | +0.00269241040165468936 |
| W₀ | artanh(√3/2) − √3/2 | 0.45093249314037806186 |
| D_∞ | 2^{2/3}/(2π(3W₀/2)^{1/3}) | +0.28780999073490792882 |
| V(1/2) | singular-part-exact quadrature | −0.39325753798704209655 |
| Jac_∞ | V(1/2) + D_∞ | −0.10544754725213416774 |
| **R_∞** | −3/4 − F(1/2)/π − V(1/2) | **−0.35943487241461259281** |

## Proof (composition; each step's grade and source)

1. **Deep row law** (π/2)μc_n = x⁴/s³·(1+O(1/(μs³))) — DERIVED by the Debye telescope on the
   frozen GY assembly (four leading channels cancel pairwise; survivors closed by
   d/dν[J_νY_ν] = 1/(πν²s³) and dα/dν = 1/(νs); e^{−α} = x/(1+s) exact [A6]). Verified on
   certified rows: ratio → 1.00000 (6 digits at j = 8192), both sides of the cut. [D + B]
2. **F-calculus**: the partial sums of the law are (π/2)Σc_n → F(x)/π; F′ = c⁴/s³ exact [A1];
   caustic finite part −3π/4 [A2]. [E]
3. **Measure identity**: (2^{−1/3}/2π)g·ζ^{−3/2}|dζ| = (1/(3π))dx/W (checked 6.7e−16, stage 3)
   ⟹ Jac_∞ = V(x₀) + D_∞ with no residue at either end. [E/B]
4. **Matched-asymptotics assembly**: R_∞ = lim[(1/π)(F(x_c) − F(x₀)) − (1/(3π))∫dx/W]; the
   1/(πs_c) divergences cancel (the same 3x/s antiderivative [A4] that makes V finite), F's
   finite part supplies −3/4; near-caustic Olver residuals → 0 by the frozen (L-a) envelope.
   [D]
5. **Verification ladders** (stage 3, certified rows): R(j) = −0.328988…−0.344312
   (j = 1024…8192), Richardson bracket [−0.3603, −0.3587] ∋ −0.359435; measured zone-i
   0.002691…0.002694 vs derived 0.0026924. [B] ∎

## Honest grade + the one named remainder

**Theorem at derivation grade**: every constant closed-form or 20-digit quadrature, every
symbolic identity machine-exact, the analytic content anchored to certified-row ladders. The
single non-displayed remainder: the deep-law correction O(1/(μs³)) has no displayed envelope —
upgrading the companion R_∞ to an (L-a)-grade two-sided constant would need it (named,
non-gating, not staged). The composition checks in the new script are algebraic where they are
algebraic — stated explicitly in the log's honesty note; the ladder anchors are the analytics.

## Corrections banked by this run

- **V(1/2) tension resolved**: stage-3's "−0.393257 vs −0.393276 (quadrature-limited)" —
  the true value is −0.3932575379…; −0.393276 was the bad quadrature. Jac_∞ and R_∞ now carry
  20 digits (−0.1054475472…, −0.3594348724…), superseding the 6-digit displays.
- Paper-drafting TODO resolutions: R_∞ sixth-decimal question → −0.359435 correct to 6dp
  (−0.3594348724…); Jac_∞ primary value confirmed. The superseded stage-2 candidate is quoted
  as ≈ −0.3567 (its two printings −0.35674/−0.35679 differ in the 5th digit across records;
  both are dead — do not quote either as live).

## Consumers / files

Paper A §9 (Thm 6: [E-arith] → composed theorem, this write-up is the drop-in source);
STATE_OF_PROOF §−0.5(b); OUTSTANDING 2.2 → closed; F10 (L-a)/(L-b) records gain the closed
forms (flag for IB — shared credit, their lemma lane, coordination discipline as in stage 3).
Files: `universality_transplant_verify.py` + `_run.log`; reads stage-2/3 findings + frozen
(L-a) constants (read-only).

*— Stenberg + Claude, 2026-07-25. One antiderivative, two slicings, no free constants left.*
