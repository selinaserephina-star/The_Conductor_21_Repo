# Summary for Ilya — Theorem 6 (offset universality) COMPLETED

**From Selina + Claude (Opus), 2026-07-30. The completed Theorem 6 package: the composed
offset-universality theorem + its one remainder advanced a full μ-order (deep-law envelope
now O(1/μ²), leading s⁻⁶ proven). Paper A §9; shares the F10 (L-a)/(L-b) lane. Not RH/GRH.**

## One-line

Theorem 6 — both models (uniform-normalization U and companion C) share the offset
`E_j − a∞μ^{1/3} → −(3/4 + √3/(3π))`, with `R_∞ = −0.35943487241461` — is complete. The
offset is at derivation grade; the single remainder (the deep-law error envelope) is now
**closed to O(1/μ²) with proven leading power s⁻⁶**, leaving only its exact coefficient as a
named, non-gating refinement.

## What's proven / banked

- **The offset universality theorem** — the cut-free −3/4 ledger identity (x₀-independent),
  symbolic set A1–A7 machine-exact, constants 20-digit (V singular part closed-form), anchored
  to the stage-3 certified-row ladders + the Richardson bracket [−0.3603, −0.3587] ∋ R_∞.
  Verifier re-run reproduces exactly.
- **The deep-law remainder, advanced (this completion):** for
  `(π/2)μc_n = (x⁴/s³)(1 + δ_n)` —
  - **δ_n = O(1/μ²) — the 1/μ term VANISHES** (μ-fit a(x)=0 to 10⁻¹²; proven at product level:
    the symmetric Debye product J_νY_ν ~ −1/(πνs)[1+u₁/ν+u₂/ν²][1−u₁/ν+u₂/ν²] is even-only,
    1/ν coefficient u₁−u₁ = 0). A full μ-order better than the composed theorem's loose O(1/(μs³)).
  - **Leading caustic power s⁻⁶ — proven** (2u₂−u₁² = (s²−1)(s²−5)/(8s⁶), leads 5/(8s⁶)).
  - **Coefficient b(s) = lim μ²δ_n — measured** (b·s⁶ caustic-limit ≈ 4.4; the telescope + d/dν
    amplify the raw 5/8 by ≈ 7×).
  - **Displayed envelope now available:** `|δ_n| ≤ B_W/μ²` on any deep window, `≲ 4.4/(μ²s⁶)`
    near the caustic. (This supersedes the interim "two-ended" reading — that was window-edge
    noise; the 1/μ term is exactly zero.)

## The one remaining refinement (non-gating)

Only the **exact closed form of b(s)** is open — the analytic propagation of the proven
`2u₂−u₁²` correction through the GJJ+GY assembly and the ν-derivative. Order and leading power
are proven, target measured, so it is fully scoped. It refines the companion R_∞ to an
(L-a)-grade two-sided constant; it does **not** gate the offset theorem, which is complete.

## Coordination (the F10 lane)

The deep-law / (L-a)/(L-b) constants are the shared F10 lemma lane, so the telescope-propagation
step sits naturally there — the Debye apparatus may already be partly on your side. For your
markup: whether the exact b(s) closed form is worth doing, or the O(1/μ²)-with-measured-b(s)
envelope is the right stopping point for Paper A §9. Registered as **M-323**.

## Reproducers (evidence/)

`WRITEUP_UNIVERSALITY_theorem_composed.md` (composed source); `universality_transplant_verify.py`
(+log); `lemmaA_prime_F10_stage3_derivation.py` (+log; deep law + R(j) ladder);
`FINDINGS_C2_deeplaw_next_order.md` + `c2_deeplaw_next_order.py` / `c2_deeplaw_bfit.py` (the
O(1/μ²) close + b(s) measurement); `universality_deeplaw_envelope.py` (+log; first envelope pass).

*— Selina + Claude (Opus), 2026-07-30. Theorem 6 completed: offset universality at derivation
grade; the deep-law remainder closed to O(1/μ²) with proven s⁻⁶ leading, coefficient measured;
only its exact closed form is a deferred, non-gating refinement. Not RH/GRH.*
