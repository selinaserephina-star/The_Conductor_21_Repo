# FINDINGS — the deep-law remainder is O(1/μ²) with leading s⁻⁶ (Thm 6 envelope, partial close)

**Merkabit · Stenberg + Claude (Opus) · 2026-07-30. Closing what's closable of Theorem 6's
one named remainder (the deep-law correction envelope). Scripts `c2_deeplaw_next_order.py`,
`c2_deeplaw_bfit.py`. Op 1 / companion — no wall contact. Not RH/GRH.**

## The claim being sharpened

The deep row law is `(π/2)μ c_n = (x⁴/s³)(1 + δ_n)`, and Theorem 6's sole remainder is a
*displayed envelope* for δ_n (needed to lift the companion R_∞ to (L-a) two-sided grade).
The composed theorem carried only `δ_n = O(1/(μs³))` (loose). This note **improves the order
by a full power of μ, proves the leading caustic power, and measures the coefficient.**

## 1. The O(1/μ) term VANISHES → δ_n = O(1/μ²)  [measured 1e-12 + proven at product level]

Fitting `δ_n = a/μ + b/μ² + d/μ³` at matched x across j = 512/1024/2048/4096/8192
(certified rows, `c2_deeplaw_next_order.py`): **a(x) = 0 to ≤10⁻¹²** at every x (residuals
3×10⁻¹²…3×10⁻¹⁰). The 1/μ term is exactly absent.

**Analytic backbone (proven).** Below the turning point the symmetric product has the Debye
form `J_ν Y_ν ~ −1/(πνs)·[1 + u₁/ν + u₂/ν²][1 − u₁/ν + u₂/ν²]` (the sign flip is the
J-vs-Y exponent). The 1/ν coefficient is `u₁ + (−u₁) = 0` (sympy-verified) — **the product
expansion is even-only**, so the correction is O(1/ν²) = O(1/μ²). The measured a = 0 (for the
full GJJ+GY assembly, order-shifts included) is this cancellation surviving the telescope.

## 2. The leading near-caustic power is s⁻⁶  [proven from the Debye polynomials]

The 1/ν² coefficient is `2u₂ − u₁² = (s²−1)(s²−5)/(8s⁶)` (u₁=(3t−5t³)/24, u₂=(81t²−462t⁴+
385t⁶)/1152, t = 1/s; sympy-factored), leading **5/(8s⁶)** as s → 0. So the deep-law
correction is `δ_n = b(s)/μ² + O(1/μ³)` with **b(s) → C/s⁶** at the caustic.

## 3. The coefficient b(s) — measured  [the exact closed form = the remaining step]

`b(s) = lim μ²δ_n` (`c2_deeplaw_bfit.py`), on x ∈ [0.2, 0.85]:

| x | 0.20 | 0.35 | 0.50 | 0.65 | 0.80 |
|---|---|---|---|---|---|
| b(x) | 7.12 | 8.76 | 12.87 | 25.66 | 97.84 |
| b·s⁶ | 6.30 | 5.92 | 5.43 | 4.94 | 4.56 |

`b·s⁶` is smooth, decreasing to a caustic-limit **≈ 4.4–4.6** — i.e. the telescope + the
d/dν of the deep-law construction **amplify** the raw product constant 5/8 ≈ 0.625 by ≈ 7×.
`b·s⁶` is *not* a clean low-degree polynomial in s² (best deg-2 fit residual 1.6×10⁻²), so the
exact b(s) is **not** a curve-fit — it needs the analytic propagation of `2u₂−u₁²` through the
GJJ+GY assembly and the ν-derivative. That propagation is the remaining (L-a) step; it is now
**well-scoped**: target b(s) measured, order O(1/μ²) and leading s⁻⁶ proven.

## 4. The displayed envelope (now available)

On any deep window bounded from the caustic, `|δ_n| ≤ B_W/μ²` with B_W = sup_W b(s) measured;
near the caustic `|δ_n| ≲ 4.4/(μ² s⁶)`. This **supersedes** the seal's earlier "two-ended /
O(1/(μs³))" characterization (the "0.008/μ at small x" was window-edge noise — the clean μ-fit
shows the 1/μ term is exactly zero).

## Grade

- **Order O(1/μ²)** — PROVEN at the product level (1/ν cancellation) + measured 1e-12 for the
  full assembly.
- **Leading caustic power s⁻⁶** — PROVEN (Debye 2u₂−u₁²).
- **Coefficient b(s)** — MEASURED (4-digit); exact closed form = the telescope-propagation step
  (deferred, non-gating, now scoped).

*— Stenberg + Claude (Opus), 2026-07-30. The deep-law remainder is a full μ-order smaller than
stated (O(1/μ²), 1/μ vanishes) with proven s⁻⁶ leading; the coefficient is measured, its closed
form one telescope-propagation from proven. Not RH/GRH.*
