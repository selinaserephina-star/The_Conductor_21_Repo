# lemmaA_prime_F10_stage3_derivation.py — F10 STAGE 3: universality at theorem grade
# (item 2 of NEXT_SESSION_TASK_theorem_grade_closes, 2026-07-24).
#
# GOAL: derive the companion's D_inf / Jac_inf / R_inf assembly analytically by
# transplanting our window+deep matched calculus (Psi0 + S_inf chain) to their
# x0 = 1/2 split.  THE DERIVED STRUCTURE (verified piece by piece below):
#
#  (S1) DEEP ROW LAW (Debye telescope, same mechanism as our Delta-sigma law):
#         (pi/2) mu c_n  =  x^4/s^3 * (1 + O(1/(mu s^3))),   x = z/mu, s = sqrt(1-x^2),
#       valid on BOTH sides of x0 (zone i and the deep window) — the law knows
#       nothing about the cut.  [Our model: |Delta_j sigma| = c^4/(nu s^3) — identical.]
#  (S2) PARTIAL SUMS = F-calculus:  (pi/2) sum_{n<=m} c_n -> F(x_m)/pi,
#         F(c) = c/s - (3/2) arcsin c + c s/2,   F' = c^4/s^3   (exact),
#       caustic finite part: F(c) = 1/s - 3 pi/4 + O(s)  ==> the 3/4.
#  (S3) MEASURE IDENTITY (exact, one line):  (2^(-1/3)/2pi) g zeta^(-3/2) dzeta
#         = (1/(3 pi)) dx / W(x)  — the Airy-tail model sum in x-form; hence
#         Jac_inf = V(x0) + D_inf  EXACTLY, where
#         V(x0) := lim_{xc->1} [ (1/(3pi)) Int_{x0}^{xc} dx/W  -  1/(pi s_c) ].
#  (S4) R_inf DERIVED:  R_inf = -3/4 - F(x0)/pi - V(x0)
#         ==>  -D_inf + Jac_inf + R_inf = -3/4 - F(x0)/pi   (NOT exactly -3/4:
#       the staged identity misses the ZONE-I MASS F(x0)/pi = 0.00269 at x0 = 1/2 —
#       numerically the companion's measured zone-i total 0.0027).  The EXACT,
#       cut-free universality statement is
#         [zone-i] + [-D_inf + Jac_inf + R_inf] = -3/4,
#       and with (1/2)IntPsi1 = -sqrt(3)/(3pi) (AiAi' channel, shared exactly):
#         E_j - main  ->  -(3/4 + sqrt(3)/(3pi))  — BOTH models, same closed form.
#
# PART A: deep law + partial-sum F-profile on certified rows (frozen engine, read-only).
# PART B: the calculus identities (sympy + numeric grids).
# PART C: quadratures: Jac_inf reproduction, V(x0), Jac_inf = V + D_inf check,
#         derived R_inf, N(x0) = -3/4 - F(x0)/pi.
# PART D: R(j) ladder (j = 1024..8192) extrapolated vs derived R_inf = -0.3595
#         (their frozen extrapolation was -0.357, inside its own jitter).
# Not RH/GRH.
import sys, os, time
import numpy as np
import mpmath as mp

FROZEN = r"C:\Users\selin\OneDrive\Desktop\Ilya Riemanns\to_Ilya_CAUSTIC_THEOREM_2026-07-19\evidence"
sys.path.insert(0, FROZEN)
from t2_d2_caustic_exponent import rows          # certified rational rows (read-only import)
from scipy.special import airy

LOG = open(__file__.replace('.py', '_run.log'), 'w')
def log(s):
    print(s, flush=True); LOG.write(s + '\n'); LOG.flush()
log(f"=== F10 stage 3: universality derivation @ {time.strftime('%Y-%m-%d %H:%M:%S')} ===")

mp.mp.dps = 30
CBRT2 = 2.0**(1.0/3.0)
X0 = 0.5
W0 = float(mp.acosh(2) - mp.sqrt(3)/2)
ZETA0 = (1.5*W0)**(2.0/3.0)
D_inf = float(2**mp.mpf('2/3')/(2*mp.pi*(3*W0/2)**mp.mpf('1/3')))
Ai0 = float(mp.airyai(0)); Bi0 = float(mp.airybi(0)); Aip0 = float(mp.airyai(0, 1))
I_inf = 4*2**(-1/3)*Ai0*Bi0
PSI1_HALF = 2*Ai0*Aip0                     # (1/2) Int Psi1 = 2 Ai(0)Ai'(0) = -sqrt3/(3pi)

def s_of(x):  return np.sqrt(1.0 - x*x)
def W_of(x):  return np.arccosh(1.0/x) - s_of(x)
def F_of(c):
    s = np.sqrt(1.0 - c*c)
    return c/s - 1.5*np.arcsin(c) + c*s/2

def olver_sigma(nu, z):
    x = np.asarray(z, dtype=float)/nu
    sig = np.empty_like(x)
    hi = x > 1.0
    if np.any(hi):
        xx = x[hi]; Wf = np.sqrt(xx*xx - 1.0) - np.arccos(1.0/xx)
        sig[hi] = -(1.5*nu*Wf)**(2.0/3.0)
    lo = ~hi
    if np.any(lo):
        xx = x[lo]; Wf = np.arccosh(1.0/xx) - np.sqrt(1.0 - xx*xx)
        sig[lo] = (1.5*nu*Wf)**(2.0/3.0)
    return sig

def PhiInf_sigma(sig):
    sig = np.asarray(sig, dtype=float); out = np.empty_like(sig)
    lo = sig <= 88.0
    if np.any(lo):
        Ai, Aip, Bi, Bip = airy(sig[lo]); out[lo] = -4.0*(Aip*Bi + Ai*Bip)
    hi = ~lo
    if np.any(hi):
        s = sig[hi]; out[hi] = (1.0/np.pi)*s**-1.5*(1.0 + 35.0/(32.0*s**3))
    return out

def Psi1_sigma(sig):
    sig = np.asarray(sig, dtype=float); out = np.zeros_like(sig)
    lo = sig <= 88.0
    if np.any(lo):
        Ai, Aip, Bi, Bip = airy(sig[lo]); out[lo] = -4.0*CBRT2*(Aip**2 + sig[lo]*Ai**2)
    return out

def window_atoms(j):
    mu = 2*j + 0.5
    n0 = int(np.ceil(mu/(2*np.pi) + 0.5))
    ns = int(np.floor(mu/np.pi + 0.5))
    return mu, n0, ns

# ---------------- PART A: deep law + F-profile on certified rows ----------------
log("\n--- PART A: (S1) deep law (pi/2) mu c_n s^3/x^4 -> 1  and (S2) F-profile ---")
ROWCACHE = {}
for j in [512, 2048, 8192]:
    mu, n0, ns = window_atoms(j)
    z, c, K = rows(j, ns + 2)
    ROWCACHE[j] = (mu, n0, ns, z, c)
    x = z[:ns]/mu; s3 = s_of(x)**3
    ratio_rows = []
    for xt in [0.20, 0.35, 0.50, 0.65, 0.80, 0.90]:
        i = int(np.argmin(np.abs(x - xt)))
        law = x[i]**4/s3[i]
        meas = (np.pi/2)*mu*c[i]
        ratio_rows.append(f"{meas/law:8.5f}")
    log(f"  j = {j:5d}: ratio at x = .20/.35/.50/.65/.80/.90:  " + " ".join(ratio_rows))
log("  [1 + O(1/(mu s^3)) expected: deviations largest at the caustic end, shrink with j]")
log("  partial sums (pi/2) sum_{n<=m} c_n  vs  F(x_m)/pi   (the S2 check):")
for j in [2048, 8192]:
    mu, n0, ns, z, c = ROWCACHE[j]
    ps = (np.pi/2)*np.cumsum(c[:ns])
    x = z[:ns]/mu
    outr = []
    for xt in [0.35, 0.50, 0.70, 0.85]:
        i = int(np.argmin(np.abs(x - xt)))
        outr.append(f"x={xt:.2f}: {ps[i]:+.6f} vs {F_of(x[i])/np.pi:+.6f}")
    log(f"  j = {j:5d}:  " + " | ".join(outr))

# ---------------- PART B: calculus identities ----------------
log("\n--- PART B: identities ---")
try:
    import sympy as sp
    cs_, ss_ = sp.symbols('c s', positive=True)
    Fexpr = cs_/sp.sqrt(1 - cs_**2) - sp.Rational(3, 2)*sp.asin(cs_) + cs_*sp.sqrt(1 - cs_**2)/2
    dF = sp.simplify(sp.diff(Fexpr, cs_) - cs_**4/(1 - cs_**2)**sp.Rational(3, 2))
    log(f"  (B1) F'(c) - c^4/s^3 = {dF}   [0 required]")
    sser = sp.symbols('sser', positive=True)
    Wser = sp.series(sp.acosh(1/sp.sqrt(1 - sser**2)) - sser, sser, 0, 8).removeO()
    log(f"  (B3) W in s near caustic: {sp.nsimplify(Wser)}   [s^3/3 + s^5/5·(3/2)?]")
    Fser = sp.series(Fexpr.subs(cs_, sp.sqrt(1 - sser**2)), sser, 0, 3)
    log(f"  (B1') F near caustic: {Fser}   [1/s - 3pi/4 + O(s) required]")
except ImportError:
    log("  (sympy unavailable — identities checked numerically only)")
xg = np.linspace(0.05, 0.999, 4001)
sg = s_of(xg); Wg = W_of(xg); zg = (1.5*Wg)**(2/3)
gg = CBRT2*xg*np.sqrt(zg)/sg
lhs = (2**(-1/3)/(2*np.pi))*gg*zg**(-1.5)*(zg**(-0.5)*sg/xg)   # g z^{-3/2} |dzeta/dx|
rhs = 1.0/(3*np.pi*Wg)
log(f"  (B2) measure identity (2^(-1/3)/2pi) g zeta^(-3/2)|dzeta/dx| = 1/(3 pi W):"
    f"  max rel dev {np.max(np.abs(lhs/rhs - 1)):.2e}   [exact algebra; float grid]")
# W closed form + the e^{-alpha} identity used in the Debye telescope derivation
xg2 = np.linspace(0.05, 0.995, 191)
sg2 = s_of(xg2)
dev_W = np.max(np.abs(W_of(xg2) - (np.arctanh(sg2) - sg2)))
dev_al = np.max(np.abs(np.exp(-np.arccosh(1.0/xg2)) - xg2/(1 + sg2)))
log(f"  (B3') W(x) = artanh(s) - s EXACTLY (max dev {dev_W:.1e});"
    f"  e^(-alpha) = x/(1+s) EXACTLY (max dev {dev_al:.1e})   [telescope ingredients]")
# x0-derivative cancellation of the D/Jac boundary pieces (the (c)+(d) algebra):
# d/dx0[-D_inf + Jac_inf] must equal MINUS the model-tail density -1/(3 pi W0),
# i.e. termC + termD + 1/(3 pi W0) = 0 identically in x0.
x0g = np.linspace(0.2, 0.8, 13)
s0 = s_of(x0g); W0g = W_of(x0g); z0 = (1.5*W0g)**(2/3)
g0 = CBRT2*x0g*np.sqrt(z0)/s0
termC = -2**(2/3)*s0/(4*np.pi*x0g)*z0**(-2.0)
termD = -(2**(-1/3)*s0/(2*np.pi*x0g))*z0**(-2.0)*(g0 - 1)
resid = np.max(np.abs((termC + termD + 1.0/(3*np.pi*W0g))/(1.0/(3*np.pi*W0g))))
log(f"  (B4) d/dx0 boundary algebra: max rel |termC + termD + 1/(3 pi W0)| = {resid:.2e}"
    f"   [0 required: the -D/Jac x0-boundary terms = minus the model-tail density]")

# ---------------- PART C: quadratures and the derived constants ----------------
log("\n--- PART C: quadratures ---")
def g_of_zeta(zt):
    zt = mp.mpf(zt)
    if zt < mp.mpf('1e-12'):
        return mp.mpf(1)
    tgt = (mp.mpf(2)/3)*zt**mp.mpf(1.5)
    lo, hi = mp.mpf('1e-9'), 1 - mp.mpf('1e-25')
    for _ in range(140):
        mid = (lo + hi)/2
        if mp.acosh(1/mid) - mp.sqrt(1 - mid**2) > tgt:
            lo = mid
        else:
            hi = mid
    x = (lo + hi)/2
    return 2**mp.mpf('1/3')*x*mp.sqrt(zt)/mp.sqrt(1 - x**2)
Jac_inf = float(2**mp.mpf('-1/3')/(2*mp.pi) *
                mp.quad(lambda zt: (g_of_zeta(zt) - 1)/zt**mp.mpf(1.5), [0, ZETA0]))
log(f"  Jac_inf reproduced: {Jac_inf:+.6f}   [frozen: -0.1054]")
def V_of(x0, sc):
    # (1/(3pi)) Int_{x0}^{xc} dx/W - 1/(pi s_c), xc = sqrt(1-sc^2)
    xc = float(np.sqrt(1 - sc*sc))
    q = mp.quad(lambda t: 1/(mp.acosh(1/t) - mp.sqrt(1 - t*t)), [x0, xc])
    return float(q/(3*mp.pi) - 1/(mp.pi*sc))
log("  V(1/2) cut convergence: " + "  ".join(
    f"s_c=1e-{k}: {V_of(X0, 10.0**-k):+.6f}" for k in [2, 3, 4]))
V_half = V_of(X0, 1e-4)
log(f"  (S3) CHECK  Jac_inf - D_inf = {Jac_inf - D_inf:+.6f}  vs  V(1/2) = {V_half:+.6f}"
    f"   [equality required; dev {Jac_inf - D_inf - V_half:+.1e}]")
F_half = float(F_of(X0))
log(f"  F(1/2) = {F_half:+.7f};  zone-i mass F(1/2)/pi = {F_half/np.pi:+.7f}"
    f"   [companion measured zone-i total: +0.0027]")
R_inf_derived = -0.75 - F_half/np.pi - V_half
log(f"  (S4) DERIVED R_inf = -3/4 - F(1/2)/pi - V(1/2) = {R_inf_derived:+.6f}"
    f"   [stage-2 closed-form candidate was D-Jac-3/4 = {D_inf - Jac_inf - 0.75:+.6f};")
log(f"        the difference is EXACTLY the zone-i mass {F_half/np.pi:+.6f}]")
N_half = -D_inf + Jac_inf + R_inf_derived
log(f"  N(1/2) = -D_inf + Jac_inf + R_inf = {N_half:+.6f}  =  -3/4 - F(1/2)/pi"
    f" = {-0.75 - F_half/np.pi:+.6f}")
tot = N_half + F_half/np.pi + PSI1_HALF
log(f"  CUT-FREE LEDGER: zone-i + N(1/2) + (1/2)IntPsi1 = {tot:+.6f}"
    f"   vs  -(3/4 + sqrt3/(3pi)) = {-(0.75 + np.sqrt(3)/(3*np.pi)):+.6f}")

# ---------------- PART D: R(j) ladder vs the derived R_inf ----------------
log("\n--- PART D: R(j) ladder (certified rows) vs derived R_inf ---")
Rj = {}
for j in [1024, 2048, 4096, 8192]:
    if j in ROWCACHE:
        mu, n0, ns, z, c = ROWCACHE[j]
    else:
        mu, n0, ns = window_atoms(j)
        z, c, K = rows(j, ns + 2)
        ROWCACHE[j] = (mu, n0, ns, z, c)
    eps = mu**(-1/3)
    n = np.arange(n0, ns + 1)
    zn = z[n - 1]
    sig = olver_sigma(mu, zn)
    chat = PhiInf_sigma(sig) + eps*Psi1_sigma(sig)
    Rj[j] = (np.pi/2)*np.sum(c[n - 1] - chat)
    zi = (np.pi/2)*np.sum(c[:n0 - 1])
    log(f"  j = {j:5d}: R(j) = {Rj[j]:+.6f}   zone-i(j) = {zi:+.6f}"
        f"  [F(1/2)/pi = {F_half/np.pi:+.6f}]   eps = {eps:.5f}")
js = sorted(Rj)
for (ja, jb) in [(js[0], js[2]), (js[1], js[3]), (js[2], js[3])]:
    ea, eb = (2*ja + 0.5)**(-1/3), (2*jb + 0.5)**(-1/3)
    Rext = (Rj[jb]*ea - Rj[ja]*eb)/(ea - eb)
    log(f"  Richardson (R = R_inf + b*eps) on ({ja},{jb}): R_inf = {Rext:+.6f}")
log(f"  DERIVED: R_inf = {R_inf_derived:+.6f}   [old frozen extrapolation: -0.357]")
log("""
reading: (S1)/(S2) = the transplanted deep law and its F-calculus verified on the
companion's certified rows on BOTH sides of x0.  (B2)+(S3) = the exact measure
identity making Jac_inf = V + D_inf — the model-tail bookkeeping collapses to pure
F-calculus.  (S4) = the derived R_inf and the corrected identity
-D+Jac+R = -3/4 - F(x0)/pi; the -3/4 is exact only in the CUT-FREE ledger
(zone-i restored), which is the true universality statement — both models then land
at offset -(3/4 + sqrt3/(3pi)) with the AiAi' channel shared exactly.""")
LOG.close()
