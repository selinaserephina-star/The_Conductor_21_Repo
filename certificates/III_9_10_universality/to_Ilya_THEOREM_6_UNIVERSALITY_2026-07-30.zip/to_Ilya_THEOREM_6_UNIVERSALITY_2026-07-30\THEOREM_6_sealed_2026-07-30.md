# THEOREM 6 — offset universality across the companion family (COMPLETED)

**Merkabit · Stenberg + Claude (Opus) · sealed 2026-07-30 as the completed theorem. The
composed offset-universality theorem (Paper A §9), verified at derivation grade, with its
one named remainder — the deep-law envelope — now **advanced a full μ-order to O(1/μ²)
with proven leading power s⁻⁶** (only the exact coefficient closed-form remains, non-gating).
Paper A lane (finite-section caustic analysis); no Op 2 / wall contact. Not RH/GRH.**

---

## Theorem 6 (offset universality)

For the two models M ∈ {U (uniform-normalization, Paper A), C (companion, F10
telescope rows)} — both j-differences of the same Airy product kernel — with
E_j = sup_m |C̃_j^{(M)}(m)| and μ = 2j,

  **E_j − a∞ μ^{1/3} → −(3/4 + √3/(3π)) = −0.93377629847393068…** (both models),

and the offset decomposes identically in the two slicings:
- **(i) shared Airy channel [E, exact]:** (1/2)∫Ψ₁ = 2Ai(0)Ai′(0) = −√3/(3π) (A7, sympy-zero);
- **(ii) cut-free deep ledger [D+E]:** with F(c)=c/s−(3/2)arcsin c+cs/2, W=artanh s−s,
  V(x₀)=(1/3π)∫_{x₀}^1(1/W−3/s³)dx − x₀/(πs₀), the ledger obeys the **cut-free identity**
  [zone-i F(x₀)/π] + [−D_∞ + Jac_∞ + R_∞] = **−3/4 for every x₀** (x₀-independence exact).

At the companion cut x₀=1/2, pinned to 20 digits (this seal's verifier):
`R_∞ = −3/4 − F(1/2)/π − V(1/2) = −0.35943487241461259281`, `Jac_∞ = −0.10544754725213416774`,
`F(1/2)/π = +0.00269241040165469`, `V(1/2) = −0.39325753798704210`.

## Verification (reproduced this seal)

`universality_transplant_verify.py`: the full symbolic identity set A1–A7 machine-exact
(sympy-zero); constants B pinned to 20 digits (V singular part in closed form
∫3/s³dx = 3x/s, series-safe splice, deviation 4.8×10⁻¹⁴); the ledger combinations
cancel V and give −3/4 exactly. Analytic content anchored to the stage-3 certified-row
ladders: deep law (π/2)μc_n s³/x⁴ → 1 (6 digits at j=8192, both sides of the cut); the
R(j) ladder j=1024…8192 with Richardson bracket **[−0.3603, −0.3587] ∋ R_∞**; measured
zone-i 0.002691…0.002694 vs F(1/2)/π = 0.0026924.

## The one named remainder — now numerically characterized (this seal's new content)

The single non-displayed piece is the **deep-law correction** in
(π/2)μc_n = (x⁴/s³)(1 + δ_n) — needed only to upgrade the *companion* R_∞ to an
(L-a)-grade two-sided constant (named, non-gating for the offset theorem itself).
**Sharpened 2026-07-30** (`FINDINGS_C2_deeplaw_next_order.md`), improving the loose
O(1/(μs³)) by a full μ-order:

- **δ_n = O(1/μ²) — the 1/μ term VANISHES.** μ-fit at matched x across j = 512…8192 gives
  a(x) = 0 to ≤10⁻¹². Proven at the product level: the symmetric Debye product
  J_νY_ν ~ −1/(πνs)[1+u₁/ν+u₂/ν²][1−u₁/ν+u₂/ν²] is **even-only** (1/ν coeff = u₁−u₁ = 0).
- **Leading caustic power s⁻⁶ — proven.** The 1/ν² coefficient 2u₂−u₁² =
  (s²−1)(s²−5)/(8s⁶) (sympy-factored) leads 5/(8s⁶), so **b(s) := lim μ²δ_n → C/s⁶**.
- **Coefficient b(s) — measured** (b·s⁶ ≈ 4.6→6.3 over x∈[0.8,0.2]; the telescope + d/dν
  amplify the raw 5/8 by ≈7× to the caustic-limit ≈4.4–4.6). Exact closed form = the
  analytic propagation of 2u₂−u₁² through the GJJ+GY assembly — the remaining (L-a) step,
  now well-scoped (target measured, order + leading power proven).

**Displayed envelope (now available):** `|δ_n| ≤ B_W/μ²` on any deep window bounded from
the caustic (B_W = sup_W b(s) measured); near the caustic `|δ_n| ≲ 4.4/(μ²s⁶)`. This
supersedes the earlier "two-ended / O(1/(μs³))" reading (that was window-edge noise; the
1/μ term is exactly zero). The remainder is **benign and now O(1/μ²)-bounded**; the
*proven closed-form* b(s) is the one deferred analytic step.

## Grade and boundaries

- **Grade: THEOREM (derivation grade).** Every constant closed-form or 20-digit
  quadrature; every symbolic identity machine-exact; the offset and R_∞ anchored to
  certified-row ladders + Richardson. The **offset universality statement is complete**
  at this grade (the envelope is not a gate on it).
- **Residual (deferred, non-gating):** the *proven closed-form* coefficient b(s) in the
  deep-law envelope δ_n = b(s)/μ² + O(1/μ³) → the companion R_∞ as an (L-a)-grade
  two-sided constant. **Order O(1/μ²) and leading power s⁻⁶ now PROVEN** (Debye product,
  §remainder); b(s) measured; only its exact closed form (the GJJ+GY telescope propagation
  of 2u₂−u₁²) is open. Scoped by the envelope data.
- **Scope.** Finite-section caustic asymptotics (Paper A Part IV, §9). Op 1 / companion
  family; **does not touch Op 2 or the wall.**

## Manifest

`evidence/`: `WRITEUP_UNIVERSALITY_theorem_composed.md` (the composed source),
`universality_transplant_verify.py` (+log), `lemmaA_prime_F10_stage3_derivation.py`
(+log, the deep-law + R(j) ladder), `FINDINGS_LEMMA_A_PRIME_F10_stage2_universality.md`,
`universality_deeplaw_envelope.py` (+log, this seal's envelope characterization).

*— Stenberg + Claude (Opus), sealed 2026-07-30. Offset universality composed and
verified at derivation grade; R_∞ = −0.35943487241461; the one remainder (deep-law
envelope) measured benign but its proven displayed form remains the deferred (L-a) item.
One antiderivative, two slicings, no free constants in the offset. Not RH/GRH.*
