import sys, numpy as np
sys.path.insert(0,"../to_Ilya_CAUSTIC_THEOREM_2026-07-19/evidence")
from t2_d2_caustic_exponent import rows
def ns_of(j): return int(np.floor((2*j+0.5)/np.pi+0.5))
def s_of(x): return np.sqrt(1.0-x*x)

JS=[512,1024,2048,4096,8192]
# build delta(x) on the deep atoms for each j
DATA={}
for j in JS:
    mu=2*j+0.5; ns=ns_of(j); z,c,K=rows(j,ns+2)
    x=z[:ns]/mu; s=s_of(x)
    law=x**4/s**3; meas=(np.pi/2)*mu*c[:ns]; delta=meas/law-1.0
    DATA[j]=(mu,x,delta)
    print(f"  j={j:5d} mu={mu:8.1f} deep atoms={ns}")

# at matched x, interpolate delta and fit delta = a/mu + b/mu^2 + d/mu^3
xt_list=[0.30,0.40,0.50,0.60,0.70,0.80]
print("\n  x      a(x)=lim mu*delta      b(x)=lim mu^2*delta     (fit a/mu+b/mu^2+d/mu^3)")
A={}; B={}
for xt in xt_list:
    mus=[]; dl=[]
    for j in JS:
        mu,x,delta=DATA[j]
        dd=np.interp(xt,x,delta)     # x is increasing
        mus.append(mu); dl.append(dd)
    mus=np.array(mus); dl=np.array(dl)
    M=np.vstack([1/mus,1/mus**2,1/mus**3]).T
    coef,*_=np.linalg.lstsq(M,dl,rcond=None)
    a,b,d=coef; A[xt]=a; B[xt]=b
    resid=np.max(np.abs(M@coef-dl))
    print(f"  {xt:.2f}   a={a:+.5f}          b={b:+.4f}          resid={resid:.1e}")

# identify s-dependence of a(x) and b(x)
print("\n  s-power fit of a(x) and b(x)  (s=sqrt(1-x^2)):")
xs=np.array(xt_list); ss=s_of(xs)
av=np.array([A[x] for x in xt_list]); bv=np.array([B[x] for x in xt_list])
for name,vv in (("a",av),("b",bv)):
    # try a(x) = C * s^p  -> log|v| = logC + p log s
    good=np.abs(vv)>1e-9
    if good.sum()>=2:
        p,logC=np.polyfit(np.log(ss[good]),np.log(np.abs(vv[good])),1)
        print(f"    {name}(x): |{name}| ~ {np.exp(logC):.4f} * s^({p:+.2f})   [values: "+", ".join(f'{v:+.4f}' for v in vv)+"]")
    else:
        print(f"    {name}(x): ~0 (values "+", ".join(f'{v:+.5f}' for v in vv)+")")
# also test specific closed forms near caustic
print("\n  b(x)*s^6 (test const near caustic):", ", ".join(f"{B[x]*s_of(x)**6:+.4f}" for x in xt_list))
print("  a(x)*s^3 (test):", ", ".join(f"{A[x]*s_of(x)**3:+.4f}" for x in xt_list))
