import sys, numpy as np, math
sys.path.insert(0, "../to_Ilya_CAUSTIC_THEOREM_2026-07-19/evidence")
from t2_d2_caustic_exponent import rows
def window_atoms(j):
    mu=2*j+0.5; ns=int(np.floor(mu/np.pi+0.5)); return mu, ns
def s_of(x): return np.sqrt(1.0-x*x)

print("deep-law correction delta = (pi/2) mu c_n s^3/x^4 - 1 ; find p with |delta|*mu*s^p bounded")
JS=[512,2048,8192]
# find best-fit power over the deep window x in [0.20,0.90]
for j in JS:
    mu,ns=window_atoms(j); z,c,K=rows(j,ns+2)
    x=z[:ns]/mu; s=s_of(x)
    law=x**4/s**3; meas=(np.pi/2)*mu*c[:ns]; delta=meas/law-1.0
    mask=(x>=0.20)&(x<=0.90)
    row=f"  j={j:5d}: "
    for p in (3,4,5,6):
        env=np.abs(delta)*mu*s**p
        row+=f"sup|d|mu s^{p}={np.max(env[mask]):.4f}  "
    print(row)
print("\n  => the p whose sup is j-STABLE (same across j) is the true envelope power.")
# report the winning-power envelope constant across j + its x-location
print("\n  detailed s^6 envelope (candidate) across j and x:")
for j in JS:
    mu,ns=window_atoms(j); z,c,K=rows(j,ns+2)
    x=z[:ns]/mu; s=s_of(x)
    law=x**4/s**3; meas=(np.pi/2)*mu*c[:ns]; delta=meas/law-1.0
    vals=[]
    for xt in (0.5,0.65,0.8,0.9):
        i=int(np.argmin(np.abs(x-xt))); vals.append(f"x={xt}:{abs(delta[i])*mu*s[i]**6:.4f}")
    print(f"  j={j:5d}: "+"  ".join(vals))
