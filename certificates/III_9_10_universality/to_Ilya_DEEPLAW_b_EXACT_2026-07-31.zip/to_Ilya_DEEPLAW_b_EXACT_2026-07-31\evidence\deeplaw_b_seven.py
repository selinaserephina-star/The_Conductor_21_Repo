import sympy as sp
nu,z,e=sp.symbols('nu z e',positive=True); pi=sp.pi; S=sp.Symbol('S',positive=True)
def s6lead(pJY_g, JYz_g):
    """s^-6 leading of b when p_JY carries pJY_g's g, and (JY)' carries JYz_g's g (booleans)."""
    s=sp.sqrt(1-(z/nu)**2); g=(s**2-1)*(s**2-5)/(8*s**6)
    JY0=-(1/(pi*nu*s)); JYg=-(1/(pi*nu*s))*(1+g/nu**2)
    pJY = JYg if pJY_g else JY0
    JYz = sp.diff(JYg if JYz_g else JY0, z); W=2/(pi*z)
    pJpY=(JYz-W)/2; pJYp=(JYz+W)/2
    A1=2*(nu+1)*nu/z**2-1;B1=2*(nu+1)/z;A2=2*(nu-1)*nu/z**2-1;B2=2*(nu-1)/z
    c=z**2*((A1*pJY-B1*pJpY)/(nu+1)-(A2*pJY+B2*pJYp)/(nu-1))
    x=sp.symbols('x',positive=True); c=c.subs(z,nu*x).subs(sp.sqrt(1-x**2),S).subs(nu,1/e)
    ser=sp.series(sp.expand(c),e,0,4).removeO()
    C1=sp.simplify(ser.coeff(e,1));C3=sp.simplify(ser.coeff(e,3))
    b=sp.simplify((C3/C1).subs(x**2,1-S**2).subs(x,sp.sqrt(1-S**2)))
    return sp.limit(sp.simplify(b*S**6),S,0)
print("s^-6 leading of b*s^6, by source of the g-term:")
print("  full (g in both p_JY and (JY)'):      ", s6lead(True,True), " = 35/8")
print("  direct only  (g in p_JY, not (JY)'):  ", s6lead(True,False))
print("  deriv only   (g in (JY)', not p_JY):  ", s6lead(False,True))
print("  raw Debye g s^-6 leading = 5/8")
print()
d=s6lead(True,False); v=s6lead(False,True)
print(f"  direct/(5/8) = {d/sp.Rational(5,8)},  deriv/(5/8) = {v/sp.Rational(5,8)},  sum = {(d+v)/sp.Rational(5,8)} x")
