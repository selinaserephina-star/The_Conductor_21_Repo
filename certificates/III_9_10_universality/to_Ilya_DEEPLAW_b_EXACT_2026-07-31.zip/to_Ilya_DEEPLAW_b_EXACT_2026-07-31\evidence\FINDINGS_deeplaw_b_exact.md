# FINDINGS — the exact closed form of b(s): derived, not fitted

**Merkabit · Stenberg + Claude (Opus) · 2026-07-31. M-323 deferred item closed:
the exact b(s) in the deep-law envelope δ_n = b(s)/μ² + O(1/μ³). Derivation by
recurrence reduction of the exact c_n; verified independently to ~10 digits against
the exact Bessel c_n. Scripts `deeplaw_b_recurrence.py`, `deeplaw_b_verify.py`,
`deeplaw_b_decompose.py`, `deeplaw_b_seven.py`. Not RH/GRH.**

## Result

> **b(s) = 1 + 9/(8s²) + 35/(8s⁶)**,  so  **b(s)·s⁶ = s⁶ + (9/8)s⁴ + 35/8**,
> caustic limit (s→0) = **35/8**. The ≈7× over the raw Debye 5/8 is **exactly 7**.

Not a fit: it falls out of the propagation, and matches the exact-Bessel measurement to
9–10 digits (x=0.3: 8.04195424221 measured vs 8.04195424187 derived; x=0.5:
12.8703703754 vs 12.8703703704).

## 1. The exact c_n (t2_d2_caustic_exponent.py, `mp_spot` lines 106–116)

With μ = 2j+½ (so the half-integer orders are exactly μ), z = z_n, J_k := J_{k+½}(z),
Y_k := Y_{k+½}(z):

```
c_n = z² · [ (J_{2j-1} − (2μ−1)J_{2j}/(2z) + Y_{2j})·J_{2j+2} / (μ+1)
           − (J_{2j-3} − (2μ−5)J_{2j-2}/(2z) + Y_{2j-2})·J_{2j} / (μ−1) ]
```
i.e. c_n = z²[ (J_{μ-1} − (2μ−1)J_μ/2z + Y_μ)·J_{μ+2}/(μ+1) − (J_{μ-3} − (2μ−5)J_{μ-2}/2z + Y_{μ-2})·J_μ/(μ−1) ].
(The rational `rows(j,N)` engine, lines 49–104, is the numerically-stable Miller/forward
build of the same object; `mp_spot` is its Bessel closed form and is what we expand.)

## 2. Only the Y·J cross-products survive (the algebraic part)

Below the turning point (x = z/μ ∈ (0,1)): J_ν(z) ~ e^{−νξ} (exp-small), Y_ν(z) ~ e^{+νξ}.
So J·J products are e^{−2μξ} (super-exp-small, dropped). The Y·J products are algebraic:
their combined exponent collapses via d/dν[νξ] = β (β = arccosh(1/x)) to e^{−2β} =
(x/(1+s))² — the [A6] identity. So

  **c_n ≈ z²[ Y_μ J_{μ+2}/(μ+1) − Y_{μ-2} J_μ/(μ−1) ]**.

## 3. Recurrence reduction — exp-free, no companion Debye polynomials

Reduce the ±2 order shifts to the same order μ by the Bessel recurrence
(C_{ν+2} = (2(ν+1)ν/z²−1)C_ν − (2(ν+1)/z)C_ν′, and the −2 analog):
- Y_μ J_{μ+2} = (2(μ+1)μ/z²−1)·**JY** − (2(μ+1)/z)·**J′Y**,
- Y_{μ-2} J_μ = (2(μ−1)μ/z²−1)·**JY** + (2(μ−1)/z)·**JY′**.

Then express the three same-order products through **JY and its z-derivative + the
EXACT Wronskian** (no derivative-Debye needed):
  JY′ − J′Y = 2/(πz) (Wronskian, exact); JY′ + J′Y = (JY)′ ⟹
  **J′Y = ((JY)′ − 2/πz)/2, JY′ = ((JY)′ + 2/πz)/2**.

Substitute the **proven** product asymptotic
  **JY = J_μ Y_μ ~ −(1/(πμs))·(1 + g/μ²)**, g = 2u₂ − u₁² = (s²−1)(s²−5)/(8s⁶),
compute (JY)′ = d/dz(JY) with s = √(1−(z/μ)²) (so s′ = −z/(μ²s)), set z = μx, and expand
in 1/μ. The leading coefficient is (2/π)x⁴/s³ (using s²+x² = 1) — Theorem 6's deep law —
and the 1/μ² relative coefficient is **b(s) = 1 + 9/(8s²) + 35/(8s⁶)**.

## 4. Where the ≈7× comes from — a single specific term

Decomposing b (scripts `_decompose`, `_seven`):
- **b_geom (g = 0) = s²/(s²−1)** — the recurrence/telescope 1/μ² structure. It has **no s⁻⁶
  pole** (→ 0 at the caustic): the geometry alone does not make the caustic blow-up.
- **The entire s⁻⁶ = 35/8 comes from the propagated Debye g**, and — traced further — it
  comes **entirely from the ν-derivative term (JY)′**, i.e. the Wronskian-split products
  J′Y, JY′. The **direct** J_μY_μ contribution to the s⁻⁶ pole is **exactly 0**.
- **The 7 is the differentiation exponent.** The g-term in JY is (−1/(πμs))·g/μ² ∝ s⁻⁷/μ³
  (s⁻⁶ from g × s⁻¹ from the JY prefactor). The Wronskian-split products carry
  (JY)′ = d/dz(·), and **d/dz(s⁻⁷) = −7 s⁻⁸ s′** — the factor **7 = 6 + 1** (g's pole order
  plus the JY prefactor pole). That is the specific term; nothing is a black box.

## 5. Verification (independent, exact Bessel)

`deeplaw_b_verify.py`: c_n from the exact half-integer Bessel `mp_spot` at dps=40, δ_n·μ²
Richardson-extrapolated in 1/μ over j = 200…1600, vs b(s) = 1+9/(8s²)+35/(8s⁶):
x = 0.3 / 0.5 / 0.7 → agreement 3.4e−10 / 5e−9 / 4.4e−7 (residual = finite-j Richardson,
shrinking with j). Confirms the derivation; no constant was fitted.

## Grade

**PROVEN closed form** (recurrence reduction is exact algebra; the only asymptotic input is
the proven JY ~ −(1/πμs)(1+g/μ²) with g = 2u₂−u₁², and the exact Wronskian), verified
independently to ~10 digits. **This closes the M-323 deferred item** — Theorem 6's deep-law
envelope now has its coefficient in closed form: δ_n = [1 + 9/(8s²) + 35/(8s⁶)]/μ² + O(1/μ³).

*— Stenberg + Claude (Opus), 2026-07-31. b(s) = 1 + 9/(8s²) + 35/(8s⁶); the caustic 35/8 is
7×5/8, the 7 the exponent of s⁻⁷ under the ν-derivative — derived from the exact c_n, verified
against exact Bessel. Not RH/GRH.*
