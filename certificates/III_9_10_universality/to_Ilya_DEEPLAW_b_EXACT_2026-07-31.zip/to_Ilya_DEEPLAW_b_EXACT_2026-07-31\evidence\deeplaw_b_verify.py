# independent high-precision check: exact c_n (mp_spot Bessel formula) -> delta*mu^2 -> b(s),
# Richardson in 1/mu, compare to derived b(s)=1+9/(8 s^2)+35/(8 s^6).  NOT a fit.
import mpmath as mp
mp.mp.dps = 40
def c_exact(j, x):
    mu = mp.mpf(2*j) + mp.mpf(1)/2
    z  = mu*x
    J = lambda k: mp.besselj(k+mp.mpf(1)/2, z); Y = lambda k: mp.bessely(k+mp.mpf(1)/2, z)
    dW = ((J(2*j-1) - (2*mu-1)*J(2*j)/(2*z) + Y(2*j))*J(2*j+2)/(mu+1)
          - (J(2*j-3) - (2*mu-5)*J(2*j-2)/(2*z) + Y(2*j-2))*J(2*j)/(mu-1))
    return z**2*dW, mu
def delta(j, x):
    c, mu = c_exact(j, x)
    s = mp.sqrt(1-x*x)
    return (mp.pi/2)*mu*c*s**3/x**4 - 1, mu
def b_meas(x, js=(200,400,800,1600)):
    ds=[]; mus=[]
    for j in js:
        d,mu = delta(j,x); ds.append(d*mu*mu); mus.append(mu)   # mu^2 * delta -> b + a/mu + ...
    # Richardson: fit b + a/mu + c/mu^2 (3 pts) using last three
    import mpmath
    A = mp.matrix([[1, 1/mus[i], 1/mus[i]**2] for i in range(-3,0)])
    v = mp.matrix([ds[i] for i in range(-3,0)])
    coef = mp.lu_solve(A, v)
    return coef[0]
def b_derived(x):
    s = mp.sqrt(1-x*x); return 1 + mp.mpf(9)/(8*s**2) + mp.mpf(35)/(8*s**6)
print("   x        b_measured (exact Bessel, Richardson)      b_derived=1+9/8s^2+35/8s^6     diff")
for x in [mp.mpf('0.3'), mp.mpf('0.5'), mp.mpf('0.7'), mp.mpf('0.85')]:
    bm = b_meas(x); bd = b_derived(x)
    print(f"  {float(x):.2f}   {mp.nstr(bm,12):>20}   {mp.nstr(bd,12):>18}   {mp.nstr(abs(bm-bd),3)}")
