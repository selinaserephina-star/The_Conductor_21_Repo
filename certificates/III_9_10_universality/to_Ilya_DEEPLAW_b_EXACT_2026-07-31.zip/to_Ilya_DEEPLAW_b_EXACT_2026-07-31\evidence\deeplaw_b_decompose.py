import sympy as sp
nu,z,e = sp.symbols('nu z e', positive=True); pi=sp.pi; S=sp.Symbol('S',positive=True)
def bfun(with_g):
    s=sp.sqrt(1-(z/nu)**2)
    g=(s**2-1)*(s**2-5)/(8*s**6) if with_g else 0
    JY=-(1/(pi*nu*s))*(1+g/nu**2); JYz=sp.diff(JY,z); W=2/(pi*z)
    pJY=JY; pJpY=(JYz-W)/2; pJYp=(JYz+W)/2
    A1=2*(nu+1)*nu/z**2-1; B1=2*(nu+1)/z; A2=2*(nu-1)*nu/z**2-1; B2=2*(nu-1)/z
    c=z**2*((A1*pJY-B1*pJpY)/(nu+1) - (A2*pJY+B2*pJYp)/(nu-1))
    x=sp.symbols('x',positive=True); c=c.subs(z,nu*x).subs(sp.sqrt(1-x**2),S).subs(nu,1/e)
    ser=sp.series(sp.expand(c),e,0,4).removeO()
    C1=sp.simplify(ser.coeff(e,1)); C3=sp.simplify(ser.coeff(e,3))
    b=sp.simplify((C3/C1).subs(x**2,1-S**2).subs(x,sp.sqrt(1-S**2)))
    return sp.simplify(b)
b_full=bfun(True); b_geom=bfun(False); b_gpart=sp.simplify(b_full-b_geom)
print("b_full           =", b_full)
print("b_geom (g=0)     =", b_geom, "   [recurrence/telescope 1/nu^2, NO Debye correction]")
print("b_gpart (g only) =", b_gpart, "   [the 2u2-u1^2 Debye correction, propagated]")
print()
print("s^-6 leading (s->0):  full", sp.limit(b_full*S**6,S,0),
      "| geom", sp.limit(b_geom*S**6,S,0), "| g-part", sp.limit(b_gpart*S**6,S,0))
print("raw g=2u2-u1^2 s^-6 leading = 5/8 =", float(sp.Rational(5,8)))
print("amplification of the g-part s^-6 over raw 5/8:", sp.limit(b_gpart*S**6,S,0)/sp.Rational(5,8))
