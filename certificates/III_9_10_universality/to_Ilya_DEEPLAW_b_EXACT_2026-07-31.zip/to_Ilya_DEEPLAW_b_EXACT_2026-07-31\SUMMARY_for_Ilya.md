# Reply to Ilya — the exact b(s), derived (not fitted)

**From Selina + Claude (Opus), 2026-07-31. Your M-323 follow-up: the exact closed
form of b(s) in δ_n = b(s)/μ² + O(1/μ³). Done. Not RH/GRH.**

## The answer

> **b(s) = 1 + 9/(8s²) + 35/(8s⁶)**, so **b(s)·s⁶ = s⁶ + (9/8)s⁴ + 35/8**,
> caustic limit **35/8** — the ≈7× over the raw 5/8 is **exactly 7**.

Matches your measured 4.4–4.6 (caustic-limit 35/8 = 4.375) and my earlier per-x
numbers to 9–10 digits — but **it is derived, not fitted** (§verification below).

## 1. The symbolic c_n you asked for (t2_d2_caustic_exponent.py, `mp_spot` lines 106–116)

You don't have the file; here it is exactly. With **μ = 2j+½** (so the half-integer
orders are *exactly* μ), z = z_n, J_k := J_{k+½}(z), Y_k := Y_{k+½}(z):

```
c_n = z² · [ (J_{2j-1} − (2μ−1)J_{2j}/(2z) + Y_{2j})·J_{2j+2} / (μ+1)
           − (J_{2j-3} − (2μ−5)J_{2j-2}/(2z) + Y_{2j-2})·J_{2j} / (μ−1) ]
```

(The stable rational `rows(j,N)` engine, lines 49–104 — Miller-backward for the minimal
solution, forward for the dominant — is the same object; `mp_spot` is its Bessel form.)
**This is the symbolic form for your independent redo.**

## 2. The propagation (each step, no black box)

1. **Below turning point (x=z/μ<1): only the Y·J cross-products survive.** J·J are
   e^{−2μξ} (dropped); the Y·J exponent collapses via d/dν[νξ] = β to e^{−2β} = (x/(1+s))²
   (your [A6] identity). So c_n ≈ z²[Y_μ J_{μ+2}/(μ+1) − Y_{μ-2} J_μ/(μ−1)].
2. **Recurrence-reduce the ±2 shifts to order μ** (exp-free): C_{μ+2} = (2(μ+1)μ/z²−1)C_μ
   − (2(μ+1)/z)C_μ′, and the −2 analog. This turns c_n into a bilinear in {J_μ,J_μ′,Y_μ,Y_μ′}.
3. **Express the three products via JY and its z-derivative + the exact Wronskian** —
   no companion Debye polynomials: JY′−J′Y = 2/(πz) (exact), JY′+J′Y = (JY)′ ⟹
   J′Y = ((JY)′−2/πz)/2, JY′ = ((JY)′+2/πz)/2.
4. **Substitute your proven input** JY = J_μY_μ ~ −(1/(πμs))(1 + g/μ²), g = 2u₂−u₁² =
   (s²−1)(s²−5)/(8s⁶), take (JY)′ = d/dz(JY) with s′ = −z/(μ²s), set z=μx, expand in 1/μ.
   Leading = (2/π)x⁴/s³ (deep law); the 1/μ² coefficient is **b(s) = 1 + 9/(8s²) + 35/(8s⁶)**.

## 3. Where the 7× comes from — the specific term (as you required)

Decomposed (`deeplaw_b_decompose.py`, `deeplaw_b_seven.py`):
- **b_geom (g=0) = s²/(s²−1)** — the recurrence/telescope 1/μ² part has **no s⁻⁶ pole**
  (→0 at the caustic). The geometry alone does not produce the blow-up.
- The **entire s⁻⁶ = 35/8** comes from the propagated Debye g — and specifically from the
  **ν-derivative (JY)′** (the Wronskian-split products J′Y, JY′). The **direct** J_μY_μ
  contribution to the s⁻⁶ pole is **exactly 0**.
- **The 7 is the differentiation exponent.** The g-term in JY is ∝ s⁻⁷/μ³ (s⁻⁶ from g ×
  s⁻¹ from the JY prefactor); (JY)′ differentiates it, and **d/dz(s⁻⁷) = −7 s⁻⁸ s′** —
  so **7 = 6 + 1** (g's pole order + the JY-prefactor pole). That is the chain-rule term
  you asked to see.

## 4. Verification — exact Bessel, not a fit (`deeplaw_b_verify.py`)

c_n from the exact half-integer Bessel `mp_spot` at dps=40; δ_n·μ² Richardson-extrapolated
in 1/μ over j=200…1600 vs b(s)=1+9/(8s²)+35/(8s⁶):
x=0.3 → 3.4e−10, x=0.5 → 5e−9, x=0.7 → 4.4e−7 (residual = finite-j Richardson). The
constant fell out of the derivation; the numerics only confirm it.

## For your independent check

The symbolic c_n is §1 above. If you redo the propagation from your end and get a different
b(s), send it and we'll reconcile — but the recurrence route needs only your two proven
inputs (JY's g and the vanishing 1/ν term) plus the exact Wronskian, so I expect agreement.
**This closes the M-323 deferred item** — Theorem 6's deep-law envelope is now closed-form:
δ_n = [1 + 9/(8s²) + 35/(8s⁶)]/μ² + O(1/μ³).

*— Selina + Claude (Opus), 2026-07-31. b(s) exact; the 7 is d/dz(s⁻⁷)'s exponent. Not RH/GRH.*
