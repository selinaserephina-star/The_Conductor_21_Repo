# To Ilya — FIRST_21_ZERO_COMPLETENESS: CLOSED (numerical grade) · 2026-07-18

**Selina + Claude.** The line you marked `FIRST_21_ZERO_COMPLETENESS — OPEN, pending N_{χ₈}⁺(T*) = 21`
is closed:

$$\boxed{N(T^*) = 21 \quad (T^* = 5.969)\ \ \text{— the 21 certified zeros are ALL the zeros below } T^*.}$$

**Grade: numerical_anchored** (every error term estimated and cross-checked; not yet ball arithmetic —
the certified upgrade is a bounded engineering ladder on the same pipeline, step 1 already done).
Not RH/GRH.

## How it was closed — exactly the plan from our 07-17 note, executed

1. **Built the Booker §5 / Palojärvi–Zhao §5 rescaled-FFT engine** (engine/, one day's build).
   Validation chain: coefficients match PARI `direuler` 1000/1000 blocks; the (5.4)–(5.5) identity
   verified against a direct Λ-contour integral (rel. 2×10⁻¹¹); **L(½) = 5.8379065826346** vs your
   independent 5.8379065826347 (5×10⁻¹⁴); all 21 certified zeros reproduced in-bracket; two η-channels
   agree to ~10⁻⁵. The kernel table additionally **ball-certified** in arb (radii ≤ 10⁻⁷²,
   engine/G_KERNEL_ARB_RESULTS — rigor-ladder step 1).
2. **Production run** (AWS, 2026-07-18): M = 9×10⁹ coefficients, η = 0.82, all-float64 by the η-knob
   (SCALING_MEMO §3–4), t-range [0, 28]. Found **149 zeros** (zeros/zeros_found.csv), tracking the
   smooth count Φ(t) to |S| ≤ 0.7 through t = 26.
3. **Turing condition** (PZ Thm 2.3, ε = ½; B derivation in engine/turing_constant_chi8.py, evaluated
   at the actual (t₁, t₂)): one-sided rule-out of a 22nd zero below T* requires
   (t₂ − T*) − D > B/π ≈ 18.1. Result (verdict/turing_verdict_t2opt.json):

   | t₂ | D | margin | verdict |
   |---|---|---|---|
   | 25.0 | +0.14 | **+0.80** | CERTIFIED |
   | 25.5 | −0.01 | **+1.44** | CERTIFIED |
   | 26.0 | −0.19 | **+2.10** | CERTIFIED |
   | 26.5 | +0.07 | **+2.34** | CERTIFIED |

   Four t₂ choices, growing margins — not a knife-edge.

## Honest scope

- The raw t₂ = 28 evaluation (verdict/turing_verdict.json) is NOT certified: the amplitude guard
  (which rejects sign changes too close to the float64 noise floor — the anti-false-certification
  safeguard) dropped ~4 genuine zeros in (26, 28], inflating D there. Evaluating at t₂ ≤ 26.5, where
  the found list demonstrably tracks Φ (gap analysis in the cover of zeros/), is the correct one-sided
  application. Missed zeros below t₂ can only make the verdict MORE conservative, never less.
- Single η-channel (0.82) above t = 9.7; below 9.7 two channels agree. A second-η confirmation run is
  specified (SCALING_MEMO) and cheap to add.
- Numerical grade throughout the tail; the ball-certified completeness upgrade = rigor-ladder steps
  2–6 (engine/SCALING_MEMO §5), with step 1 (certified kernel) done.
- γ₂₂–γ₂₄ in the tail are ball-certified separately — see the companion package
  `to_Ilya_gamma22_24_certified_2026-07-18` (two-engine handshake inside).

## What's in the box

- `verdict/` — both verdict JSONs + the full production log
- `zeros/zeros_found.csv` — 149 zeros to t = 27.9 (**~109 first-ever computed**);
  `zeros_chi8_rescaled_engine_t9p7.csv` — the 40-zero two-η validation list
- `engine/` — the complete engine source (12 files), scaling memo, arb-kernel results, and the
  B = 57.89 derivation. Reproducible end-to-end: gen → G-table → F̂ → FFT → scan → verdict.
- `SHA256SUMS.txt` seals everything.

Your H₂₁ monomiality certificate is what makes PZ Thm 2.3 apply unconditionally (entirety) — this
count is the same thread as your bridge, now closed at its first station. Suggested next sequencing
on our side: second-η confirmation; ball-certified completeness (ladder); then the joint write-up
with the 24 certified zeros + completeness as one result block.

— S. + C., 2026-07-18. Shared-credit conventions.
