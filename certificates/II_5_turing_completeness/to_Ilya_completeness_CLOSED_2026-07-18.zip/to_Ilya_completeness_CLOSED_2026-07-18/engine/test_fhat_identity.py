# test_fhat_identity.py — verify Booker (5.4)-(5.5) for chi8 at a few x:
#   Fhat(x) = (1/2pi i) int_{Re s=2} Lambda(s) e^{(x+2pi i eta)(1/2-s)} ds        [direct]
#           = N^{1/4} * sum_n a_n n^{-1/2} G(x + log(n/sqrt N); eta)             [G-sum]
# with Lambda(s) = N^{s/2} 16 (2pi)^{-4s} Gamma(s)^4 L(s),  L via Dirichlet series
# (converges absolutely on Re s = 2).  No poles => no residue terms (chi8 entire).
import numpy as np
import mpmath as mp
from g_kernel import g_kernel

mp.mp.dps = 30
N = mp.mpf(21) ** 10
logsqN = mp.log(N) / 2
ETA = mp.mpf(3) / 10

a = np.load('an_chi8_2M.npy')
M = len(a) - 1
nz = np.nonzero(a)[0]
nz = nz[nz >= 1]
an_nz = a[nz]

def L_dirichlet(s):
    # sum a_n n^-s (abs convergent at Re s = 2; tail ~ M^{-1} negligible for test)
    ns = np.array([mp.e**(-s * mp.log(int(n))) for n in nz[:200000]])
    # too slow elementwise in mpmath for 2M terms; use numpy complex128 for the tail
    s_c = complex(s)
    vals = an_nz.astype(np.float64) * np.exp(-s_c * np.log(nz.astype(np.float64)))
    return vals.sum()

def Lambda(s):
    Ls = L_dirichlet(s)
    gam = 16 * mp.e**((s / 2) * mp.log(N) - 4 * s * mp.log(2 * mp.pi)) * mp.gamma(s)**4
    return gam * mp.mpc(Ls)

def fhat_direct(x, T=18, dt=0.02):
    # fixed trapezoid in float64 (integrand analytic + e^{-4.4|t|} decay:
    # geometric convergence; accuracy limited by the float64 Dirichlet sum ~1e-15)
    w = complex(x + 2j * np.pi * float(ETA))
    ts = np.arange(-T, T + dt, dt)
    logN = float(10 * mp.log(21))
    l2pi = float(np.log(2 * np.pi))
    ln_n = np.log(nz.astype(np.float64))
    af = an_nz.astype(np.float64)
    vals = np.empty(len(ts), dtype=np.complex128)
    for i, t in enumerate(ts):
        s = 2 + 1j * t
        Ls = (af * np.exp(-s * ln_n)).sum()
        gam = 16 * np.exp((s / 2) * logN - 4 * s * l2pi) * complex(mp.gamma(s)) ** 4
        vals[i] = gam * Ls * np.exp(w * (0.5 - s))
    return np.trapezoid(vals, dx=dt) / (2 * np.pi)

def fhat_gsum(x, dps=30):
    # Fhat(x) = N^{1/4} sum a_n n^{-1/2} G(x + log(n/sqrtN))
    tot = mp.mpc(0)
    for n, an in zip(nz, an_nz):
        u = float(mp.mpf(x) + mp.log(int(n)) - logsqN)
        if u > 5.5:
            break
        g = g_kernel(u, ETA, 0, dps=dps)
        tot += int(an) * g / mp.sqrt(int(n))
    return mp.e**(logsqN / 2) * tot  # N^{1/4}

if __name__ == '__main__':
    import time
    for x in (16.0, 17.5):
        t0 = time.time()
        d = fhat_direct(x)
        g = fhat_gsum(x, dps=30)
        rel = abs(d - g) / abs(d)
        print(f"x={x}: direct={mp.nstr(d, 12)}")
        print(f"        G-sum ={mp.nstr(g, 12)}   rel diff={mp.nstr(rel, 3)}   ({time.time()-t0:.0f}s)")
