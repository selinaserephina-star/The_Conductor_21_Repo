# Turing constant B and required tail h for chi8, from Palojarvi-Zhao arXiv:2508.03023v1 Thm 2.3.
# Also derives the RvM constant A=0 and the smooth count M(T*)=Phi(T*)=theta(T*)/pi.
#
# chi8 in the Selberg normalization Lambda(s) = L(s) N^s prod_j Gamma(lambda_j s + mu_j):
#   ours  Lambda(s) = q^{s/2} prod_{j=1}^{8} Gamma_R(s+mu_j^ours) L(s),  q=21^10, mu^ours=[0,0,0,0,1,1,1,1]
#   Gamma_R(s+mu) = pi^{-(s+mu)/2} Gamma((s+mu)/2)  =>  lambda_j = 1/2 (<1, REQUIRED by Thm 2.2),
#                                                        mu_j = mu_j^ours/2 in {0 x4, 1/2 x4},
#                                                        N = 21^5 / pi^4   (leftover pi^-2 is a positive
#                                                        real constant: irrelevant to zeros/arg)
#   theta_L = 0 and polynomial Euler product of order l = 8  => Thm 2.3: c_{theta_L}(eps) -> 8*c0(eps)
#   k_L = 0 (entire: chi8 monomial => Hecke over F=L^{H21} => entire)   => the k_L term vanishes
#   L(1) != 0 (classical, nontrivial Artin L)
import mpmath as mp
mp.mp.dps = 25
z = mp.zeta; PI = mp.pi

# (2.1)  A_eps := (1/2+eps) log(1 + 1/(1/2+eps)) + log(3/2+eps)
def A(e): return (mp.mpf('0.5')+e)*mp.log(1+1/(mp.mpf('0.5')+e)) + mp.log(mp.mpf('1.5')+e)

# (2.2) at theta=0:  Z0(s)=zeta(s),  z0(s)=zeta(2s)/zeta(s)
logZ0 = lambda s: mp.log(z(s))
logz0 = lambda s: mp.log(z(2*s)/z(s))
def dlogz0(s):    # (z0'/z0)(s) = 2 zeta'(2s)/zeta(2s) - zeta'(s)/zeta(s)
    return 2*mp.zeta(2*s, derivative=1)/z(2*s) - mp.zeta(s, derivative=1)/z(s)
def c0(e):
    a = 1+e
    return ((mp.mpf('0.5')+e)*logZ0(a)
            + mp.quad(logZ0, [a, mp.inf])
            - mp.quad(logz0, [a, 2+e])
            - mp.quad(logz0, [mp.mpf('1.5'), mp.inf])
            + A(e)*dlogz0(a))

Nsel = mp.mpf(21)**5/PI**4                 # N in their normalization
MU   = [mp.mpf(0)]*4 + [mp.mpf('0.5')]*4   # mu_j
f, kL = 8, 0
Tstar = mp.mpf('5.969')

def logQL(s):                              # (2.4) Q_L(s) = N^2 prod (lambda_j s + mu_j + 1)^{2 lambda_j=1}
    v = 2*mp.log(Nsel)
    for m in MU: v += mp.log(abs(s/2 + m + 1))
    return v
def Xmax(e):                               # hypothesis: (t1+Im mu)^2 >= (lam(2+eps)+Re mu)^2 + X^2 ; worst mu=1/2
    return mp.sqrt(Tstar**2 - ((2+e)/2 + mp.mpf('0.5'))**2)
def B(e, h):
    t2 = Tstar + h; X = Xmax(e)
    if X <= 5: return None, None           # Thm requires X > 5
    Ae = A(e)
    b = ((mp.mpf(1)/16 + e*(1+e)/4)*logQL(1+e+1j*t2)
         + ((Ae-1)/2)*logQL(1+e+1j*Tstar)
         + f*c0(e)                          # Thm 2.3: l*c0 with l=8
         + (f/X)*(mp.mpf('0.9') + 4*Ae/5))  # k_L = 0 -> last term of (2.3) absent
    return b, X

# ---- smooth count: Phi(t) = theta(t)/pi ; A = 0 (Lambda entire; Phi(0)=0, S(0)=0 since L(1/2)>0)
logq = 10*mp.log(21); MUours = [0,0,0,0,1,1,1,1]
def theta(T):
    s = mp.mpf('0.5') + 1j*mp.mpf(str(T)); v = (s/2)*logq
    for m in MUours: v += -((s+m)/2)*mp.log(PI) + mp.loggamma((s+m)/2)
    return mp.im(v)
print("A = 0  (derived: Lambda entire; Phi(0)=0; S(0)=0 because L(1/2)=+5.8379065826347>0)")
print("      confirmed against Palojarvi-Zhao Sec 1.3:  N(t) = Phi(t) + S(t),  Phi(t) == theta(t)/pi")
M = theta(Tstar)/PI
print(f"M(T*) = theta(T*)/pi = {float(M):.4f}")
for n in (20,21,22): print(f"   N(T*)={n}  =>  S(T*) = {n-float(M):+.4f}")
print(f"   our 21 certified zeros force N(T*)>=21, hence S(T*) >= {21-float(M):+.4f}")
print(f"   => task is the ONE-SIDED rule-out of S(T*) >= {22-float(M):.4f}\n")

print(f"{'eps':>5} {'A_eps':>8} {'c0':>9} {'Xmax':>7}")
for ei in (10,20,30,40,50):
    e = mp.mpf(ei)/100
    print(f"{float(e):>5.2f} {float(A(e)):>8.4f} {float(c0(e)):>9.4f} {float(Xmax(e)):>7.3f}")

best = None
for ei in range(5, 51):                    # optimize eps in (0, 1/2]; fixed point h = 2B/pi
    e = mp.mpf(ei)/100; h = mp.mpf(20); b = None
    for _ in range(40):
        b, X = B(e, h)
        if b is None: break
        h = 2*b/PI
    if b is None: continue
    if best is None or b < best[1]: best = (e, b, h, X)
e, b, h, X = best
print(f"\noptimum eps = {float(e):.3f}, X = {float(X):.3f}")
print(f"B = {float(b):.3f}")
print(f"h (two-sided)  = 2B/pi           = {float(h):.2f}   -> tail to t = {float(Tstar+h):.1f}")
h1 = b/(mp.mpf('1.06')*PI)                 # one-sided + certified N>=21:  n <= B/(pi h) + 20.94 < 22
print(f"h (one-sided)  = B/(1.06 pi)     = {float(h1):.2f}   -> tail to t = {float(Tstar+h1):.1f}")
