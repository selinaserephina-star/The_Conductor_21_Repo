# Ball-certified G-kernel — results summary (rigor-ladder step 1)

**Merkabit Research · 2026-07-17 · Selina Stenberg + Claude.** Step 1 of the rigor ladder in
`SCALING_MEMO_production_spec.md` §5: the G-table upgraded from float (mpmath quadrature,
estimated error) to **rigorous arb enclosures** (python-flint acb). Not RH/GRH.

## Deliverables (this folder, commit eb3bfb8)

| file | content |
|---|---|
| `g_kernel_arb.py` | the certified builder + full validation harness |
| `gtab_arb_B64_eta082.csv` | 4,088 certified balls: G^(k)(l·π/32; 41/50), l = −157..134, k = 0..13; mid to 50 digits + radius upper bound per entry |
| `g_kernel_arb_run.log` | verbatim build + validation output |

## Method (Booker 2006 (5.9)–(5.10), made ball-rigorous)

- **Residue series**: contour shifted to −∞; G^(k) = Σ_j Res at the order-4 poles s = −j of
  Γ(s)⁴. Near s = −j the integrand is A_j(ε)/ε⁴ with
  A_j(ε) = 16(2π)^{4j} e^{w(1/2+j)} (j+½−ε)^k e^{−βε} Γ(1+ε)⁴ ∏_{m≤j}(ε−m)^{−4},
  β = w + 4 log 2π, w = u + 2πiη. Each residue = [ε³]A_j, computed **exactly** in acb via
  degree-3 truncated series (Γ(1+ε) from γ, ζ(2), ζ(3); the pole product via harmonic sums).
- **Tail bound** (Lemma 5.1's geometric-domination logic, adapted to the Γ(s)⁴ form with the
  (½−s)^k factor): the exact ratio identity A_{j+1} = A_j · (2π)⁴e^w ((j+3/2−ε)/(j+½−ε))^k /
  (ε−j−1)⁴ on |ε| ≤ ½ gives max|A_{j+1}| ≤ q_j max|A_j| with computable q_j < 1; Cauchy on
  |ε| = ½ turns that into Σ_{j>J}|Res_j| ≤ 8·MA_J·q_J/(1−q_J), added as a centered ball.
  Tail cut at 1e-72 absolute.
- **Exact inputs**: u = l·π/32 and η = 41/50 as exact ball quantities; precision 1500 bits
  (the u ≈ 9 cancellation is ~155 digits, worst ~390 digits at u_max = 13.16 — both absorbed).

## Results

- **All radii ≤ 9.9e-73** (spec: < 1e-30 — met by 42 orders). Build time ≈ **2 s** for the
  whole table (the memo's provisioning estimate was ~1 h on AWS for the float version).
- **Midpoints validated** two independent ways:
  - dps-85/90 saddle-line quadrature (`g_kernel.py`) at 10 spot points: agreement ~1e-15
    (1.3e-9 at (127,13) where |G^(13)| ~ 6e-40 is at the quadrature's own absolute floor);
  - residue-by-circle-contour series (`g_kernel_residue_series`): concurs at every
    adjudicated point.
- **vs the float table** `gtab_B64_eta082.pkl`: row-relative diff < 2.8e-7 for **all k ≤ 9**;
  float-zeroed rows (l ≥ 128) confirmed negligible (max |G^(k)|/k! = 2.6e-51).

## Finding: the float table is wrong at high k (superseded)

The certified table exposed that the float table's **k = 10..13 entries fail at 278
scattered |u|-large points** (49/64/77/88 per k above 1e-6 row-relative; none in l ∈ [−60,0]).
Worst cases are O(1) at row scale — e.g. (l,k) = (−116,13): float −0.83−11.9j vs true
0.62+0.79j — adjudicated by both independent methods. Cause: mp.quad at dps 45 (and even
dps 60) under-resolves the |t|^k-weighted oscillatory integrand. Additionally the float
deep tail (l ≳ 115, |G| < 1e-50) has O(1) relative errors from the dps-45 absolute floor.

**Impact on the float64 production pipeline: none in practice.** k ≥ 10 Taylor terms enter
the assembly with weight ε^k/k! ≤ 2e-20, invisible at the pipeline's validated 5e-14 level.
But the float table's high-k entries should not be trusted for anything else; the certified
table supersedes them.

## Remaining rigor-ladder steps (memo §5, unchanged)

2. a_n exact integers (already are) · 3. S_m^(k) in ball/exact-rational arithmetic ·
4. truncation tails via Lemma 5.3 with Γ(s)⁴-specific constants; aliasing via Lemmas 5.4–5.5 ·
5. ball FFT (acb_dft) or rigorous float64-FFT forward bound · 6. interval bisection ⇒
certified zero list ⇒ certified N(T*) = 21.

— Selina + Claude, 2026-07-17
