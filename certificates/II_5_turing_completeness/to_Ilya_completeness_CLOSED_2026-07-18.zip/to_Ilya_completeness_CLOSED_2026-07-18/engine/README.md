# χ₈ rescaled-FFT engine (Booker §5 / Palojärvi–Zhao §5) — working folder

**Merkabit · Selina + Claude · started 2026-07-17.** The evaluator that computes
F(t) = Λ(½+it,χ₈)·e^(2πηt) via one Mellin kernel + FFT, evading the raw-amplitude wall.
Built for the completeness count N(T*) = 21 (Turing's method, PZ Thm 2.3, B = 57.89).
Not RH/GRH. This is a *working* folder (nothing here is a frozen deliverable).

Read first: `SCALING_MEMO_production_spec.md` (validation results + production spec).

## Status 2026-07-17
- Engine validated end-to-end at M = 10⁸, η = 0.3 (float64):
  L(½) to 5×10⁻¹⁴, all 21 certified zeros in-bracket, 3 new zeros γ₂₂–γ₂₄ (numerical grade).
- η = 0.55 cross-check + production G-table (η = 0.82, B = 64): computed here, see pickles.
- Production run (M ≈ 7×10⁹, t₂ = 26, AWS 123 GB box): `production_turing_run.py` — waiting
  for the box to finish the in-flight γ₂₂₋₂₅ jets run (two-engine handshake when it lands).

## Files
- `gen_an_chi8.py` — coefficients (flint Frobenius + multiplicative sieve); PARI-validated.
- `g_kernel.py` — G(u;η) = 16e^(w/2)K₄((2π)⁴eʷ); quadrature + residue-series cross-check.
- `test_fhat_identity.py` — independent contour-integral test of (5.4)–(5.5) (rel 2×10⁻¹¹).
- `build_fhat.py` — bucketed assembly + FFT; prints the L(½) check.
- `zero_scan.py` — Z(t) sign changes + bisection refinement vs certified master CSV.
- `turing_count.py` — Φ(t) = θ(t)/π, the one-sided Turing condition (t₂−T*) − D > B/π.
- `production_turing_run.py` — one-shot orchestrator (stages 1–5) for the AWS run.
- `../to_Ilya_completeness_analysis_2026-07-17/turing_constant_chi8.py` — B = 57.89 derivation.

## Provenance of the new zeros (grade: numerical, NOT ball-certified)
γ₂₂ ≈ 6.106223, γ₂₃ ≈ 6.299157, γ₂₄ ≈ 6.464523 — float64 pipeline, M = 10⁸, η = 0.3;
first computed zeros of this L-function past t = 6. Cross-checks pending:
(a) η = 0.55 rerun (kernel-independence), (b) AWS jets w1–w9 ball certification in flight
(passport predictions 6.07 / 6.28 / 6.49 — ours sit within the ±0.1 windows).
