# χ₈ rescaled-FFT engine — build report + production spec for the Turing count

**Merkabit · Selina + Claude · 2026-07-17.** The Booker §5 / Palojärvi–Zhao §5 rescaled-FFT
evaluator for L(s,χ₈), built and validated end-to-end. Not RH/GRH.

## 1. What was built (this folder)

| file | what it does |
|---|---|
| `gen_an_chi8.py` | a_n via loc8 Frobenius recipe: python-flint `factormod(x⁷−7x+3, p)` + in-place multiplicative sieve. **Validated: 1000/1000 blocks of the 100M run match the PARI `direuler` block sums** (`an_chi8_blocks_160M.csv`). ~31 µs/prime. |
| `g_kernel.py` | the Mellin kernel. Key identity (Legendre duplication): ∏ⱼΓ_ℝ(s+μⱼ) = 16·(2π)^(−4s)·Γ(s)⁴, so **G(u;η) = 16·e^(w/2)·K₄((2π)⁴eʷ)**, w = u+2πiη, K₄ = inverse Mellin of Γ(s)⁴. Saddle-line quadrature (well-conditioned; no cancellation blow-up). Cross-checked against the residue series over the order-4 poles (Booker (5.9)/Lemma 5.1 structure): agreement to working precision. |
| `test_fhat_identity.py` | independent verification of Booker (5.4)–(5.5): direct contour integral of Λ(s) (Dirichlet series + Γ-factors) vs the G-sum. **rel diff 2×10⁻¹¹.** NB the identity carries weight aₙ·(n/√N)^(−1/2) = N^(1/4)·aₙ/√n — the N^(1/4) is easy to lose reading Booker's typeset (5.5); PZ (5.2) shows it explicitly. |
| `build_fhat.py` | F̂(2πn/B) by bucketed Taylor sums (Booker (5.18)–(5.19)), buckets aligned to the x-grid (u_m = m·h, h = 2π/B, K = 14); then inverse FFT → F(m/A) = Λ(½+i·m/A)e^(2πη·m/A). χ₈ entire ⇒ **no residue/pole corrections anywhere**. |
| `zero_scan.py` | Z(t) reconstruction, sign-change scan, bisection refinement (arbitrary t from the same F̂ data), comparison vs certified table. |
| `turing_count.py` | Φ(t) = θ(t)/π (A = 0, derived), the one-sided Turing contradiction: certify N(T*) = 21 iff (t₂−T*) − D > B/π, D = ∫(Φ−N_found). |

## 2. Validation results (local, M = 10⁸, η = 0.3, A = 64, B = 40, float64)

- **L(½) = 5.8379065826346** vs independent 2026-06 value 5.8379065826347 (**5×10⁻¹⁴**).
  At M = 2×10⁶ the same pipeline gave 5.8379065820 — truncation behaves exactly as the kernel law predicts.
- **All 21 certified zeros reproduced inside their certified brackets** (γ₁ to 4×10⁻⁷ of the exact value).
- **24 sign changes on [0, 6.6]** vs smooth count Φ(6.6) ≈ 24.06 → S(6.6) ≈ −0.06: no missed zeros in range.
- **Three new zeros past the old amplitude wall: γ₂₂ ≈ 6.1062, γ₂₃ ≈ 6.2992, γ₂₄ ≈ 6.4645**
  (grade: numerical, float64 pipeline; η-independence cross-check at η = 0.55 in progress).
  Raw |Λ| there ≈ 10⁻¹⁷ — the arb-jets engine died at 10⁻¹² (t ≈ 6). **The rescaling removes the wall entirely**:
  the exponential decay is cancelled analytically before anything is computed; F(t) is O(1)-conditioned.

## 3. The kernel decay law — why the coefficient demand is 10⁹, not 10¹⁵

Saddle-point analysis of K₄ (exact, not the generic bound):
**|G(u;η)| ~ C·exp(−8π·cos(πη/2)·e^(u/4))**.
The generic Selberg-class bound (Booker Lemma 5.2 / PZ Lemma 5.3) has the same shape with constant
8π·δe^(−δ), δ = π(1−|η|)/2 — up to **3× weaker in the exponent**, hence (3)⁴ ≈ 100× more coefficients
if used for planning. Empirical check from our G-table (η = 0.3): |G(0)| = 1.5×10⁻⁹ ≈ exp(−8π·0.891) ✓.

Truncation criterion at height t₂ (error ≤ 1% of |F(t₂)| scale):

  (M/√N)^(1/4) ≈ [15 + 2π(1−η)·t₂] / [8π·cos(πη/2)]

Consequences at t₂ = 24 (the Turing tail: T* + h, h ≈ B/π + D ≈ 18.4 + O(1), target t₂ = 24–26 with margin):

| η | M needed | F(24)/F(0) dynamic range | arithmetic |
|---|---|---|---|
| 0.50 | ≈ 2.7×10⁹ | e^(−75) ≈ 10⁻³³ | needs ~45-digit FFT |
| **0.82** | **≈ 5×10⁹** | e^(−27) ≈ 2×10⁻¹² | **float64 works** (S/N ≈ 10³ over FFT noise) |
| 0.85 | ≈ 7×10⁹ | e^(−23) ≈ 10⁻¹⁰ | float64 comfortable |
| 0.90 | ≈ 1.4×10¹⁰ | e^(−15) ≈ 3×10⁻⁷ | float64 easy |

**The η-knob converts precision cost into coefficient cost.** At η ≈ 0.82–0.85 the entire production run
stays in float64/numpy — no high-precision FFT. This is Booker's own trade ("adjusting the constant of
proportionality… trades off precision and number of coefficients"), pushed to the coefficient-rich end
because our coefficient pipeline is cheap and validated.

## 4. Production run (AWS, 128+ GB box)

Target: certified sign-change list on [T*, t₂], t₂ ≈ 26, then `turing_count.py` condition
(t₂−T*) − D > B/π = 18.43 (B = 57.89, PZ Thm 2.3, ε = ½ — see `turing_constant_chi8.py`).

| stage | cost (r7i.4xlarge-class) |
|---|---|
| 1. a_n to M = 7×10⁹ (`gen_an_chi8.py`, int64 = 56 GB + ≤ M/2 copy transient) | ~2 h flint factoring (π(7e9) ≈ 3.2×10⁸ primes) + ~2 h sieve |
| 2. S_m^(k): streaming bucket sums, **np.longdouble accumulation** (Linux 80-bit; kills the bincount noise floor) | ~30 min |
| 3. G-table at η_prod, dps 45 (~200 points × K=14, mpmath) | ~1 h, embarrassingly parallel |
| 4. assembly + FFT (q = A·B, B = 64, A = 64 → 4096 pts) | seconds |
| 5. zero scan [0, 26] + refinement + η-cross-check at second η | minutes |
| 6. `turing_count.py` → N(T*) = 21 | seconds |

Parameters: B = 64 (aliasing margin: F(t−B) ≈ e^(−2π(1+η)(B−t)) negligible for t ≤ 26 by ≥ 30 digits);
A = 64 ≈ 8× the zero density at t = 26 (density ≈ (log N + 8log(t/2π))/2π ≈ 7.8).
Run **two η values** (e.g. 0.82 / 0.87) as the standard two-channel check; zeros must agree.

## 5. Rigor ladder

- **Grade now achievable (production run above): `numerical_anchored` completeness** — N(T*) = 21 with all
  error terms *estimated* (kernel truncation by the decay law, FFT noise empirical, S-sum noise bounded).
- **Upgrade to CERTIFIED (ball) — engineering on the same pipeline, no new math:**
  1. G-table in arb (`python-flint` acb): residue series (5.9)–(5.10) with Lemma 5.1 tail bound — fully
     rigorous enclosures; high dps handles the cancellation (worst ≈ 155 digits at u ≈ 9; table is ~200
     points × 14 derivatives, computed once).
  2. a_n exact integers (already are).
  3. S_m^(k) in ball arithmetic or exact rational splitting (d = log(n/√N) − u_m enclosed in balls).
  4. truncation tails by Lemma 5.3 with **case-specific constants** for our Γ(s)⁴ kernel (Booker §5.3
     endorses exactly this); aliasing by Lemmas 5.4–5.5 (no residue terms — entire).
  5. FFT in ball arithmetic (acb_dft in flint) or rigorous forward error bound for float64 FFT.
  6. Bisection sign changes evaluated through interval F(t) ⇒ certified zero list ⇒ certified N(T*) = 21.
- T* note: Φ(T*) = 20.9419 sits 0.06 below the 21 midpoint — good positioning (our 21 zeros force
  S(T*) ≥ +0.058 for free; the one-sided rule-out of 22 has a full unit of room).

## 5b. Update (same day): η-independence passed, 40 zeros to t = 9.7, D measured

The η = 0.55 rerun (same M = 10⁸): identical L(½) (5×10⁻¹⁴), all 21 zeros identical, γ₂₂–γ₂₄
reproduced to ~10⁻⁵ (η = 0.3 noise floor), and **19 new zeros total: γ₂₂–γ₄₀** out to t = 9.59
(`zeros_chi8_rescaled_engine_t9p7.csv`). γ₂₅ = 6.7218 vs passport 6.69 ✓. Count vs smooth law:
N_found(6.6) = 24 vs Φ = 23.998; N(8.0) = 31 vs 31.045; N(9.7) = 40 vs 40.020 — |S| ≤ 0.05 at all
checkpoints, **no missed zeros to t = 9.7**, and the Turing integrand D(T*, 9.7) = −0.35 (small,
sign helping). Production margin at t₂ = 28: (t₂−T*) − D − B/π ≈ 22.03 + O(0.5) − 18.16 ≈ **+4**.

Production parameters locked: **η = 0.82, M = 9×10⁹ (int32, 36 GB), B = 64, A = 64, t₂ = 28**
(B(t₁,28) = 57.05, need h > 18.16, have h = 22.03). max|a_n| = 64 at 10⁸ — int32 ample.

## 6. Bottom line

The "wall" was an artifact of the raw-amplitude engine. The rescaled engine reproduces every certified
result to float64 precision, walks past t = 6 without noticing, and the full Turing tail to t₂ ≈ 26 is a
**one-night AWS job in plain float64** at η ≈ 0.82, M ≈ 5–7×10⁹. The completeness count
N(T*) = 21 (numerical grade) is at most days away, and the ball-certified upgrade is a bounded
engineering task on this exact pipeline.
