# Request to Selina / Claude — final χ₈ Turing-count package

Please return the completed production Turing-method package for
`8.16679880978201.21t14.b.a`, from the run reported with
\(t_2=28\), \(M=9\times10^9\).

Required contents:

- complete source and exact command line;
- full stdout/stderr log;
- coefficient-source hashes;
- all precision and kernel parameters;
- rigorous truncation and rounding-error bounds;
- the final Turing inequality;
- exact count convention and endpoint handling;
- confirmation that multiplicities and every zero in the full critical
  strip are counted;
- `TURING_RESULT.json` matching the attached template;
- `SHA256SUMS.txt`.

Required result:

```text
T=6.55
POSITIVE_ORDINATE_COUNT=24
COUNT_INCLUDES_MULTIPLICITY=True
ALL_NONTRIVIAL_ZEROS_IN_STRIP_COUNTED=True
TURING_INEQUALITY_PASS=True
ENDPOINT_ZERO_AT_T=False
COEFFICIENT_CUTOFF_M>=9000000000
UPPER_TURING_HEIGHT_T2>=28
FINAL_STATUS=CHI8_TURING_COUNT_EXACTLY_24_BELOW_6_55_CERTIFIED
```

Do not label the spectrum complete if the result is merely numerical or if
the rigorous remainder inequality did not pass.
