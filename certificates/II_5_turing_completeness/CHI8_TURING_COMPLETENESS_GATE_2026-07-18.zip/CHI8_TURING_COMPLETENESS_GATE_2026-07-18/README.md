# Usage

Run:

```bash
python3 verify_turing_completion.py
```

Without `TURING_RESULT.json`, the verifier intentionally exits with code 2:

```text
FINAL_STATUS=CHI8_TURING_COMPLETENESS_GATE_READY
```

After receiving the final production result, put it in this directory as
`TURING_RESULT.json` and rerun.
