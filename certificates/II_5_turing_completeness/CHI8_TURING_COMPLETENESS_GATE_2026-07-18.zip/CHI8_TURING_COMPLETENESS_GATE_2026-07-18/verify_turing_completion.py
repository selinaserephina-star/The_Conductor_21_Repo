#!/usr/bin/env python3
import csv
import json
import sys
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "source"
RESULT_FILE = ROOT / "TURING_RESULT.json"

completed = json.loads((SRC / "COMPLETED_L_RESULT.json").read_text(encoding="utf-8"))
zeros = json.loads((SRC / "ZERO_LOCATIONS_RESULT.json").read_text(encoding="utf-8"))
rows = list(csv.DictReader(
    (SRC / "chi8_24_certified_zero_locations.csv")
    .read_text(encoding="utf-8").splitlines()
))

assert completed["final_status"] == "ARITHMETIC_CHI8_TO_COMPLETED_L_FUNCTION_BRIDGE_CERTIFIED"
assert completed["degree"] == 8
assert completed["conductor"] == 21**10
assert completed["gamma_factor"] == "Gamma_C(s)^4"
assert completed["root_number_from_source_passport"] == 1

assert zeros["final_status"] == "COMPLETED_L_TO_24_CERTIFIED_ZERO_LOCATIONS_BRIDGE_CERTIFIED"
assert zeros["total_disjoint_certified_critical_line_locations"] == 24
assert len(rows) == 24
assert [int(r["label"]) for r in rows] == list(range(1,25))

previous_upper = None
for row in rows:
    lo = Decimal(row["lower"])
    hi = Decimal(row["upper"])
    assert lo <= hi
    if previous_upper is not None:
        assert previous_upper < lo
    previous_upper = hi
assert previous_upper < Decimal("6.55")

print("UPSTREAM_COMPLETED_L=PASS")
print("UPSTREAM_24_DISJOINT_ZERO_LOCATIONS=PASS")
print("ALL_24_LOCATIONS_BELOW_6_55=True")

if not RESULT_FILE.exists():
    print("TURING_RESULT_PRESENT=False")
    print("BRIDGE_STATUS=READY_FOR_TURING_RESULT;NOT_CLOSED")
    print("FINAL_STATUS=CHI8_TURING_COMPLETENESS_GATE_READY")
    sys.exit(2)

r = json.loads(RESULT_FILE.read_text(encoding="utf-8"))
required = {
    "lfunction_label": "8.16679880978201.21t14.b.a",
    "count_convention": "0<Im(rho)<=T, 0<=Re(rho)<=1",
    "T": 6.55,
    "positive_ordinate_count": 24,
    "count_includes_multiplicity": True,
    "all_nontrivial_zeros_in_strip_counted": True,
    "turing_inequality_pass": True,
    "endpoint_zero_at_T": False,
    "final_status": "CHI8_TURING_COUNT_EXACTLY_24_BELOW_6_55_CERTIFIED",
}
for key, value in required.items():
    assert r.get(key) == value, (key, r.get(key), value)

assert int(r["coefficient_cutoff_M"]) >= 9_000_000_000
assert Decimal(str(r["upper_turing_height_t2"])) >= Decimal("28")
assert r.get("rigorous_error_bound") is not None
sha = r.get("source_log_sha256")
assert isinstance(sha, str) and len(sha) == 64
assert all(c in "0123456789abcdef" for c in sha)

closure = {
    "T": 6.55,
    "exact_total_positive_ordinate_count": 24,
    "exactly_one_zero_in_each_certified_interval": True,
    "all_24_zeros_simple": True,
    "no_additional_zero_in_critical_strip_below_T": True,
    "no_off_critical_line_zero_below_T": True,
    "labels_gamma_1_to_gamma_24_are_rigorous_ordinals": True,
    "rh_grh_beyond_T_claimed": False,
    "final_status": "CHI8_INITIAL_24_ZERO_SPECTRUM_COMPLETE_BELOW_6_55_CERTIFIED",
}
(ROOT / "CLOSURE_RESULT.json").write_text(
    json.dumps(closure, indent=2) + "\n", encoding="utf-8"
)

print("TURING_RESULT_PRESENT=True")
print("EXACT_TOTAL_POSITIVE_ORDINATE_COUNT=24")
print("EXACTLY_ONE_ZERO_IN_EACH_CERTIFIED_INTERVAL=True")
print("ALL_24_ZEROS_SIMPLE=True")
print("NO_ADDITIONAL_ZERO_BELOW_6_55=True")
print("NO_OFF_LINE_ZERO_BELOW_6_55=True")
print("GAMMA_1_TO_GAMMA_24_ORDINAL_LABELS_CERTIFIED=True")
print("RH_GRH_BEYOND_6_55_CLAIMED=False")
print("FINAL_STATUS=CHI8_INITIAL_24_ZERO_SPECTRUM_COMPLETE_BELOW_6_55_CERTIFIED")
