# Selina-side verification — CHI8_FIRST24 closure package (received 2026-07-18)

Received from IB: `CHI8_FIRST24_COMPLETENESS_CLOSURE_NUMERICAL_ANCHORED_2026-07-18.zip`
(outer sha256 0ff209a5...a8d2 — verified against the shipped .sha256.txt; original zip
archived in `Downloads from Ilya/`).

Independent rerun of `recompute_all_turing_verdicts.py` on our box, same day:

- PROVENANCE_ARCHIVE_HASHES = PASS (all three upstream archives, incl. our
  to_Ilya_completeness_CLOSED and to_Ilya_gamma22_24_certified — byte-verified)
- Internal SHA256SUMS: all files OK
- ALL_FOUR_T2_CHOICES_PASS_FOR_BOTH_COUNTS = True (t1 = 5.969/n=21 and t1 = 6.55/n=24)
- FINAL_STATUS = CHI8_FIRST24_COMPLETENESS_CLOSED_NUMERICAL_ANCHORED — reproduced.

Notes:
- IB's correction accepted: upstream optimized JSON stored B_used = 56.94 (rounded DOWN);
  true value 56.9405358493...; his verifier ceils to 12 dp before the inequality. Verdicts
  unchanged; the rounding rule is the right discipline and should be adopted in our
  turing_count tooling going forward.
- The ladder now reads: FIRST_24 locations EXACT_OR_BALL_CERTIFIED; completeness /
  uniqueness / simplicity / off-line exclusion below 6.55 all NUMERICAL_ANCHORED;
  FULL_BALL_COMPLETENESS = OPEN (the rigor ladder's remaining steps 3-6).

— Selina + Claude, 2026-07-18

## Addendum (same day, later): 24-count reproduced with OUR OWN tooling

Selina flagged that our shipped certificate evaluated the Turing inequality only at
t1 = 5.969 (the 21-count); the t1 = 6.55 / 24-count was IB's derived extension. Closed:
we re-derived it independently with our engine's `turing_count.py` + our
`turing_constant_chi8.py` recomputed at Tstar = 6.55 (B(6.55, t2) = 56.6586..56.7724):

  t2=25.0: margin +0.2758   t2=25.5: +0.9097   t2=26.0: +1.5757   t2=26.5: +1.8105

All four CERTIFIED-condition passes (numerical grade), matching IB's FIRST24 margins to
4 decimals. Cross-check at t1 = 5.969 reproduces his stored first-21 margins (+0.8038,
+2.3384) and his corrected B = 56.940536 exactly. The 24-count now rests on three
independent legs: his verifier (his box), his verifier (our box), our implementation.
