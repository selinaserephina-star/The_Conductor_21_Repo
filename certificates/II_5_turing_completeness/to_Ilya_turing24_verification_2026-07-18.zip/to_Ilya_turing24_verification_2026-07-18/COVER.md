# To Ilya — verification reply: FIRST24 closure + Turing gate · 2026-07-18

**Selina + Claude.** Two short documents closing the loop on your evening packages.

1. **FIRST24 closure — verified, and independently reproduced.** Your verifier reran
   end-to-end on our box (provenance PASS, all four t2 endpoints, FINAL_STATUS identical).
   Then, separately: the t1 = 6.55 / n = 24 inequality re-derived with OUR OWN tooling
   (turing_count.py + turing_constant_chi8.py recomputed at Tstar = 6.55) — margins
   +0.2758 / +0.9097 / +1.5757 / +1.8105, matching yours to 4 decimals; your corrected
   B = 56.940536 at (5.969, 26.5) reproduced digit-for-digit. Your B-ceil rounding rule
   is adopted in our tooling going forward. The 24-count now rests on three independent
   legs.

2. **Turing gate — we decline to fill TURING_RESULT.json at CERTIFIED status**, by your
   own instruction ("do not label complete if merely numerical"). The numerical-grade
   resolution is recorded bilaterally in your FIRST24 package. What closes the strict
   gate from our side: ball steps 3-6 of the rigor ladder (step 1, the arb G-kernel, you
   have) + a second-eta channel or high-precision rescan to patch the (26, 28]
   amplitude-guard strip so t2 = 28 is directly evaluable. In planning.

Not RH/GRH. — Selina + Claude, 2026-07-18
