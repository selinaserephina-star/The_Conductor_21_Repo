# FINDINGS — the KLMN wall instrument, arb-certified: ‖V_m‖/‖D_m‖ ≤ 0.62904 < 1 for m = 40…300 (rigorous), saturating, no creep

**Stenberg + Claude (Opus), 2026-07-31. WALL MAP M-233. Upgrades the Pick-1 read
(M-231, 2026-07-29) from float diagnostic to a rigorous arb interval certificate on
the true θ+S_P genome operator, past the certified range. Instrument, not lever:
sharpens WHERE the wall stands; the n→∞ gate ⟺ GRH(χ₈) is untouched (R-013/R-209).
Retires the $280 AWS certified run. Not RH/GRH.**

## What was certified

Op 2 = H = D + V; deficiency (0,0) ⟺ GRH(χ₈) (R-209). The one open finite handle is
whether the certified Kato/KLMN relative bound **‖V‖/‖D‖ < 1** (T2a/M-206, headroom
≥4265×) survives the tail. Pick 1 READ it on the true operator and found it saturates
below 1 with no creep — but at **float grade** (n≤300). This session makes that read a
**rigorous interval certificate**.

**Result (nominal certified atoms; every entry a rigorous arb enclosure [lo,hi]):**

| m | ‖V‖/‖D‖ FULL [lo, hi] | INTERIOR (drop-2) [lo, hi] | Δ(int) | grade |
|---|---|---|---|---|
| 40  | [0.62744, 0.62744] | [0.32321, 0.32321] | — | certified |
| 80  | [0.62833, 0.62833] | [0.33076, 0.33076] | +0.0076 | certified |
| 120 | [0.62864, 0.62864] | [0.33333, 0.33333] | +0.0026 | certified |
| 149 | [0.62876, 0.62876] | [0.33434, 0.33434] | +0.0010 | certified edge |
| 180 | [0.62885, 0.62885] | [0.33508, 0.33508] | +0.0007 | **cert-tail** |
| 220 | [0.62893, 0.62893] | [0.33572, 0.33572] | +0.0006 | **cert-tail** |
| 260 | [0.62899, 0.62899] | [0.33618, 0.33618] | +0.0005 | **cert-tail** |
| 300 | [0.62904, 0.62904] | [0.33651, 0.33651] | +0.0003 | **cert-tail** |

(Enclosure half-widths are < 1e-25; they print identical to 5 places. Full JSON:
`certificate_results.json`.)

- **‖V_m‖/‖D_m‖ ≤ 0.62904 < 1 for every m in 40…300** — rigorous. Headroom to 1 is
  **0.371**.
- The interior (tail) bound rises only 0.32321 → 0.33651 across the whole range with
  **monotonically decelerating increments** (+0.0076 → +0.0003) — converging to an
  asymptote ≈ 0.337, **not creeping toward 1**. This is now a *certified* saturation,
  reproducing the Pick-1 diagnostic (M-231) at arb grade, bit-for-bit on the
  increment ladder.

## How it is rigorous (the instrument, built)

Three pieces, all in `WALL_KLMN_ARB_CERT_2026-07-31/`:

1. **Quantiles arb-IVT-certified** (`klmn_arb_quantiles.py` → `quantiles_certified.json`).
   The production θ (Γ-factors, Q=21¹⁰) and S_P (18,120-term Euler sum, P=2×10⁵,
   LOC8[frob_class]) rebuilt; γ_D, γ_fwd for n=1…300. Reproduce the frozen
   `quantiles_production.csv` to **max|Δγ_D|=1.7e-15, max|Δγ_F|=3.4e-15** (= the
   production determinism check). Each root is then **proven** enclosed by a rigorous
   arb IVT sign-check (f(γ−r)<0<f(γ+r), verified in interval arithmetic; f strictly
   increasing = the production selection rule) — all 600 roots certified, max relative
   enclosure radius 2.6e-11. P=2×10⁵ is the operator *definition*, not a truncation, so
   no truncation error enters.

2. **Lanczos in verified arb** (`klmn_arb_certify.py`). (N1) production convention: the
   size-m operator is Lanczos of diag(x₁…x_m), x=1/γ², start (1…1)/√m — **re-run per m**
   (sections are non-nested = G-M3, NOT slices of one matrix). Plain 3-term recursion,
   **no reorthogonalisation**. Ill-conditioning note: naive *interval* Lanczos radii
   explode by step 9 (the interval dependency/wrapping over-estimation, **not** true
   sensitivity — float64 point-Lanczos reproduces the frozen caches to 8e-17). Carrying
   the exact certified atoms as arb **points at prec 6000 bits (~1800 digits)** keeps the
   verified coefficient ball radius at **0.0 (< machine, proven)** all the way to m=300
   (`diag_lanczos_growth.py` maps the precision/step frontier: prec ≈ 20·m bits).

3. **Operator norms by rigorous Sturm** (ported from `xi_limit_C2_cert_arb.py`).
   ‖T‖₂ = max(|λ_min|, |λ_max|) of the symmetric tridiagonal, each eigenvalue enclosed by
   Sturm-sequence bisection (pivot recurrence, #negative pivots = #eigenvalues<μ). The
   ratio enclosure is [‖V‖_lo/‖D‖_hi, ‖V‖_hi/‖D‖_lo]; the reported certificate is the
   upper endpoint.

**Atom-value uncertainty, honestly closed.** The ≤5e-11 tie of the certified atoms to
the ideal production roots is propagated by a uniform ±rad sensitivity probe (re-run at
γ±rad): it moves the ratio by **≤ 4.7e-12** — nine orders of magnitude below the 0.371
headroom to 1, and below the 1e-4 diagnostic increments. The linear-algebra step is a
certificate; the residual atom uncertainty is quantified and negligible.

## What this buys, and the honest limit

- **The $280 AWS certified run is retired.** It would have certified the tail saturation
  the diagnostic showed. That saturation is now certified *locally* — rigorously, for $0
  — through n=300 (γ≈48.5). The certified run would confirm, not surprise (WALL_MAP
  §Pick-1); the local certificate replaces it.
- **FINITE-m certificate.** n=300 is finite. The true gate — does the sub-critical KLMN
  bound survive **n→∞** (the S(T) prime fine-structure in the tail) — is ledger gap
  G-M3/M-210 and is **⟺ GRH(χ₈)** (R-013/R-209). No finite certificate crosses it, and
  this one does not claim to. It is an **instrument** (R-013): it says *where* the wall
  stands with the sharpest rigorous statement available — the finite KLMN bound is
  provably sub-critical (≤0.629, saturating) past the certified range — leaving only the
  arithmetic n→∞ gate.

## Net

The last diagnostic-grade wall instrument is now a **certificate**: on the genuine θ+S_P
genome operator, the Kato/KLMN operator-norm relative bound is rigorously enclosed
≤ 0.62904 < 1 for all m = 40…300, saturating (interior → ≈0.337, decelerating, no
creep), with the linear algebra verified in arb (Lanczos radius 0, Sturm eigenvalue
enclosures) and the atom uncertainty bounded at 4.7e-12. The finite side of the wall is
certified as far as finite goes; the arithmetic gate (n→∞ ⟺ GRH) stands, untouched.

*— Stenberg + Claude (Opus), 2026-07-31. Finite KLMN bound sub-critical and saturating,
now with rigorous interval enclosures; the wall (n→∞ = GRH) is where it was. Not RH/GRH.*
