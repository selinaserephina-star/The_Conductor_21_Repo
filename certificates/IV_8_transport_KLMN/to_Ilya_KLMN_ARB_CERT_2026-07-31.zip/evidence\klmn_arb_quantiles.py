r"""
STEP 1 of the KLMN arb-certificate: rigorous arb enclosures of the production
theta+S_P quantile ladders (gamma_D, gamma_fwd), n = 1..NMAX.

Method
------
- Build the SAME theta (Gamma-factors, Q=21^10) and S_P (18,120-term Euler sum,
  P=2e5, LOC8[frob_class]) as the frozen production ladder.
- High-precision approximate root g0 via mpmath (dps=45).
- Validate g0 bit-for-bit vs the frozen 149-row quantiles_production.csv.
- CERTIFY each root by a rigorous arb IVT sign-check: f is the ladder residual,
  evaluated in acb/arb interval arithmetic at g0 +/- r; opposite STRICT signs
  (verified, not assumed) => a root lies in the ball [g0-r, g0+r].  (f is strictly
  increasing on the range -- theta' > 0, |S_P'| small -- so it is THE quantile;
  monotonicity is the production selection rule, measured on n<=300.)
- Emit the certified atom balls x = 1/g^2 (mid, rad) for step 2.

Diagnostic-vs-certified: the mpmath root is the *witness*; the arb sign-check is
the *proof*.  P=2e5 S_P is the operator DEFINITION (not a truncation of it), so no
truncation error enters -- the certified object is the production operator itself.
Not RH/GRH.
"""
import sys, csv, json
import numpy as np, mpmath as mp
from flint import arb, acb, ctx

sys.path.insert(0, r"C:\Users\selin\OneDrive\Desktop\Ilya Riemanns\Operator_program_addendum")
from gen_an_chi8 import LOC8, frob_class

NMAX = 300
mp.mp.dps = 45
ctx.prec = 200                       # arb working precision (bits)

Q = mp.mpf(21) ** 10
LOGQ = mp.log(Q)
MU = [0, 0, 0, 0, 1, 1, 1, 1]
PI = mp.pi

# ---------- mpmath theta / S_P (witness computation) ----------
def theta_mp(t):
    s = mp.mpf('0.5') + 1j * t
    v = (s / 2) * LOGQ
    for m_ in MU:
        v += -((s + m_) / 2) * mp.log(mp.pi) + mp.loggamma((s + m_) / 2)
    return mp.im(v)

def newton_ps(loc, kmax):
    deg = len(loc) - 1
    e = [((-1) ** i) * loc[i] for i in range(len(loc))]
    p = [0] * (kmax + 1)
    for k in range(1, kmax + 1):
        s = ((-1) ** (k - 1)) * k * e[k] if k <= deg else 0
        for i in range(1, min(k - 1, deg) + 1):
            s += ((-1) ** (i - 1)) * e[i] * p[k - i]
        p[k] = s
    return p[1:]

# S_P term data: integer trace tr, index k, prime p  ->  co = tr/k * p^{-k/2}, phase = k*log p
print("building S_P term list (P=2e5)...", flush=True)
P_MAX = 200000
isp = np.ones(P_MAX + 1, bool); isp[:2] = False
for q in range(2, int(P_MAX ** .5) + 1):
    if isp[q]: isp[q * q::q] = False
TERMS = []   # (tr_int, k, p)
for p in np.nonzero(isp)[0]:
    p = int(p); kmax = 1
    while p ** (kmax + 1) <= P_MAX: kmax += 1
    tr = newton_ps(LOC8[frob_class(p)], kmax)
    for k in range(1, kmax + 1):
        TERMS.append((int(tr[k - 1]), k, p))
print(f"  {len(TERMS)} prime-power terms", flush=True)

# fast float S_P (witness only; the arb S_P below is the proof).  numpy-vectorised
# exactly like ladder_extend_300.py -> root witness accurate ~1e-12, which the
# adaptive arb IVT ball comfortably contains.
_co_np = np.array([float(mp.mpf(tr) / k * mp.mpf(p) ** (mp.mpf(-k) / 2)) for (tr, k, p) in TERMS])
_lg_np = np.array([float(k * mp.log(p)) for (tr, k, p) in TERMS])
def SP_wit(t):
    return float(-(1.0 / np.pi) * np.sum(_co_np * np.sin(float(t) * _lg_np)))

# ---------- arb theta / S_P (proof) ----------
ARB_PI = arb.pi()
ARB_LOGPI = ARB_PI.log()
ARB_LOGQ = (arb(21) ** 10).log()
def theta_arb(t):
    # t : arb ; returns arb enclosure of theta(t)
    s_im = t
    half = arb(1) / 2
    # v = (s/2)logQ ; s=1/2+it -> Re part (1/4)logQ has zero imaginary contribution except via i t/2 * logQ
    v_im = (s_im / 2) * ARB_LOGQ                      # Im[(s/2)logQ] = (t/2) logQ
    for m_ in MU:
        # term: -((s+m)/2) log pi  +  loggamma((s+m)/2)
        v_im += -(s_im / 2) * ARB_LOGPI              # Im[-((s+m)/2) log pi] = -(t/2) log pi
        z = acb(arb(1 + 2 * m_) / 4, s_im / 2)       # (s+m)/2 = (1/2+m)/2 + i t/2
        v_im += z.lgamma().imag
    return v_im

# precompute arb coefficients / phases once
print("building arb S_P coefficients...", flush=True)
_co_arb = [arb(tr) / arb(k) / (arb(p) ** k).sqrt() for (tr, k, p) in TERMS]
_lg_arb = [arb(k) * arb(p).log() for (tr, k, p) in TERMS]
def SP_arb(t):
    acc = arb(0)
    for c, l in zip(_co_arb, _lg_arb):
        acc += c * (t * l).sin()
    return -(arb(1) / ARB_PI) * acc

def f_arb(g, n, fwd):
    # ladder residual: theta/pi (+ S_P) - (n-1/2), as arb enclosure
    val = theta_arb(g) / ARB_PI - arb(2 * n - 1) / 2
    if fwd:
        val += SP_arb(g)
    return val

# ---------- root solve (witness: mpmath theta + fast float S_P) ----------
def quant_mp(n, fwd):
    if fwd:
        f = lambda g: theta_mp(g) / PI + SP_wit(g) - (mp.mpf(n) - mp.mpf('0.5'))
    else:
        f = lambda g: theta_mp(g) / PI - (mp.mpf(n) - mp.mpf('0.5'))
    return mp.findroot(f, mp.mpf('1.0') + mp.mpf('0.22') * n, tol=mp.mpf('1e-13'))

print(f"solving {NMAX} quantiles x2 (mpmath witness)...", flush=True)
gD = [quant_mp(n, False) for n in range(1, NMAX + 1)]
gF = [quant_mp(n, True)  for n in range(1, NMAX + 1)]

# ---------- validate vs frozen CSV ----------
ref = r"C:\Users\selin\OneDrive\Desktop\Ilya Riemanns\T2_K1K2_kernel_bounds_2026-07-18\quantiles_production.csv"
rD, rF = [], []
with open(ref) as f:
    for r in csv.DictReader(f):
        rD.append(mp.mpf(r["gamma_D"])); rF.append(mp.mpf(r["gamma_fwd"]))
dD = max(abs(gD[i] - rD[i]) for i in range(len(rD)))
dF = max(abs(gF[i] - rF[i]) for i in range(len(rF)))
print(f"validate vs frozen CSV (149): max|dgD|={float(dD):.2e}  max|dgF|={float(dF):.2e}")
monoD = all(gD[i + 1] > gD[i] for i in range(NMAX - 1))
monoF = all(gF[i + 1] > gF[i] for i in range(NMAX - 1))
print(f"monotone gD={monoD} gF={monoF}; gD_300={float(gD[-1]):.4f} gF_300={float(gF[-1]):.4f}")

# ---------- arb IVT certification of each root ----------
def certify(g0, n, fwd):
    """return (mid_str, rad) with proven root in [mid-rad, mid+rad], else raise."""
    g0 = mp.mpf(g0)
    for rexp in range(11, 4, -1):           # witness ~1e-12 accurate; widen ball if undecided
        r = mp.mpf(10) ** (-rexp) * (abs(g0) + 1)
        glo = arb(mp.nstr(g0 - r, 42))
        ghi = arb(mp.nstr(g0 + r, 42))
        flo = f_arb(glo, n, fwd)
        fhi = f_arb(ghi, n, fwd)
        # strict opposite signs?  flo<0<fhi  (f increasing)
        if flo.upper() < 0 and fhi.lower() > 0:
            return mp.nstr(g0, 42), float(r)
    raise RuntimeError(f"IVT sign-check undecided at n={n} fwd={fwd}")

print("certifying roots (arb IVT sign-check)...", flush=True)
out = []
maxrad_rel = 0.0
for i, n in enumerate(range(1, NMAX + 1)):
    mD, rDrad = certify(gD[i], n, False)
    mF, rFrad = certify(gF[i], n, True)
    out.append((n, mD, rDrad, mF, rFrad))
    maxrad_rel = max(maxrad_rel, rDrad / float(gD[i]), rFrad / float(gF[i]))
    if n % 50 == 0 or n == 1:
        print(f"  n={n:3d} certified  rad_rel~{rDrad/float(gD[i]):.1e}", flush=True)
print(f"ALL {NMAX} roots certified.  max relative enclosure radius = {maxrad_rel:.2e}")

# ---------- write certified atom balls ----------
outpath = r"C:\Users\selin\OneDrive\Desktop\Ilya Riemanns\WALL_KLMN_ARB_CERT_2026-07-31\quantiles_certified.json"
with open(outpath, "w") as f:
    json.dump({
        "nmax": NMAX, "prec_bits": ctx.prec,
        "validate_max_dgD": float(dD), "validate_max_dgF": float(dF),
        "monotone_D": monoD, "monotone_F": monoF,
        "max_rel_radius": maxrad_rel,
        "rows": [{"n": n, "gD_mid": mD, "gD_rad": rDrad, "gF_mid": mF, "gF_rad": rFrad}
                 for (n, mD, rDrad, mF, rFrad) in out],
    }, f)
print(f"wrote {outpath}")
print("\nStep 1 complete: production quantiles reproduced bit-for-bit and arb-IVT-certified.")
print("Not RH/GRH.")
