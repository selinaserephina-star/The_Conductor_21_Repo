# To Ilya — the last diagnostic wall-instrument is now a certificate (and the $280 run is retired)

**From Selina + Claude (Opus), 2026-07-31. Registry M-233. Instrument, not lever —
this sharpens WHERE the wall stands; the n→∞ gate ⟺ GRH(χ₈) is untouched. Not RH/GRH.**

Ilya — quick one, our lane. We had one wall instrument still sitting at *diagnostic*
(float) grade: the Kato/KLMN relative bound of V against D on the true θ+S_P genome
operator, read into the tail (Pick 1 / M-231). It's now a **rigorous arb interval
certificate**, and it retires the $280 AWS certified run — the local certificate gives
the same information for $0.

## The result

For the (N1) production operator (H = D + V, atoms x = 1/γ², γ from the θ + S_P
ladders), the operator-norm relative bound is rigorously enclosed:

**‖V_m‖ / ‖D_m‖ ≤ 0.62904 < 1 for every m = 40…300** (headroom to 1 = **0.371**).

| m | FULL [lo, hi] | INTERIOR (drop-2) [lo, hi] | Δ(int) |
|---|---|---|---|
| 40  | [0.62744, 0.62744] | [0.32321, 0.32321] | — |
| 149 | [0.62876, 0.62876] | [0.33434, 0.33434] | +0.0010 |
| 300 | [0.62904, 0.62904] | [0.33651, 0.33651] | +0.0003 |

The interior (tail) bound rises only 0.32321 → 0.33651 across the whole range, increments
decelerating monotonically (+0.0076 → +0.0003) → **certified saturation to ≈0.337, no
creep toward 1**. This is the M-231 diagnostic reproduced *bit-for-bit on the increment
ladder*, now with proven [lo,hi] enclosures (half-width < 1e-25).

## Why it's a certificate, not a read

- **Quantiles arb-IVT-certified.** Rebuilt θ (Q=21¹⁰) and S_P (18,120-term, P=2×10⁵);
  reproduce the frozen `quantiles_production.csv` to <4e-15, then *prove* each of 600
  roots enclosed by an interval sign-check f(γ−r)<0<f(γ+r) (f = θ/π + S_P − (n−½),
  strictly increasing = the production selection rule). P=2×10⁵ is the operator
  *definition*, so no truncation error enters.
- **Verified Lanczos.** (N1) sections re-run per m (non-nested = G-M3), plain 3-term, no
  reorth. One caution worth flagging to you: *naive interval* Lanczos on ~300 atoms
  accumulating at 0 blows the ball radius to ∞ by step 9 — but that's the interval
  dependency/wrapping over-estimation, **not** true sensitivity (float64 point-Lanczos
  reproduces the frozen caches to 8e-17). Carrying the exact atoms as arb **points at
  prec 6000 bits (~1800 digits)** keeps the verified coefficient ball radius at **0.0**
  all the way to m=300.
- **Norms by rigorous Sturm.** ‖T‖₂ = max(|λ_min|, |λ_max|) of the symmetric tridiagonal,
  each eigenvalue enclosed by Sturm-sequence bisection — the same tool we built for the
  ξ-limit Cor 4′ certifier, ported straight over (the genome operator is exactly a
  tridiagonal Jacobi/de Branges operator).
- **Atom-value uncertainty closed honestly.** The ≤5e-11 tie of the certified atoms to
  the ideal production roots, propagated by a uniform ±rad probe, moves the ratio by
  **≤ 4.7e-12** — nine orders below the 0.371 headroom.

## The honest limit (unchanged)

FINITE-m. n=300 is γ≈48.5. The true gate — does the sub-critical KLMN bound survive
**n→∞** (the S(T) prime fine-structure in the tail) — is G-M3/M-210 and is **⟺ GRH(χ₈)**
(R-013/R-209). No finite certificate crosses it, and this one doesn't claim to. It is an
instrument: it says the finite KLMN bound is *provably* sub-critical (≤0.629, saturating)
past the certified range, leaving only the arithmetic n→∞ gate. Consistent with the §8
no-go and the whole wall picture — the finite side is certified as far as finite goes.

## In this package

- `KLMN_ARB_CERT_sealed_2026-07-31.md` — the FINDINGS note (full method + tables).
- `evidence/klmn_arb_quantiles.py` → `quantiles_certified.json` (IVT-certified quantiles).
- `evidence/klmn_arb_certify.py` → `certificate_results.json` (the certificate).
- `evidence/diag_lanczos_growth.py` — the precision/step frontier (prec ≈ 20·m bits).
- `evidence/test_lanczos_radii.py` — the no-reorth-vs-reorth ball-radius probe.

*— Selina + Claude (Opus), 2026-07-31. The finite side of the wall, certified as far as
finite goes; the arithmetic gate stands. Not RH/GRH.*
