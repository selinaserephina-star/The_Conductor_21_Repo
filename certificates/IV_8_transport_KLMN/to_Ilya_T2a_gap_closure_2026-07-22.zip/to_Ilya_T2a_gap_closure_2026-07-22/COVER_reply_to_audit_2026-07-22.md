# Reply to the independent audit — T2a + THEOREM-M1: the flagged gap repaired, four closes

**Merkabit · Stenberg + Claude · 2026-07-22. Reply to
`INDEPENDENT_AUDIT_SELINAS_T2A_AND_THEOREM_M1_2026-07-22` (ext SHA b4f509b2…). Working
home `T2_gap_closure_2026-07-22/`; this folder is the sealed snapshot. Not RH/GRH.**

## Reply-verify (the audit, reconciled)

The audit opened cleanly on our side and its three source-integrity SHAs were re-checked
against our copies (60410732… / 9a92a6e7… / 9222de62… — all match). Every finding was
reproduced and acted on:

- **G-M3 / THEOREM-M1 part IV — the `up`-nonexpansiveness gap: CONFIRMED, then REPAIRED.**
  The counterexample is exact (reproduced: `A=[[-1,2,2],[2,-1,2],[2,2,-1]]` has ‖A‖₂=3,
  ‖up(A)‖₂≈3.169). The GS-stability proof as written is not valid in spectral norm.
  **Repair:** `up` IS Frobenius-nonexpansive, so the Cholesky/GS fixed point runs in ‖·‖_F.
  The entrywise bound gives ‖E‖_F ≤ (j+2)‖τ‖B² directly, so — contrary to a first guess —
  there is **no √(j+2) penalty**: the order stays LINEAR in (j+2), constant 6 → 16 (leading
  9). Rates untouched; measured envelope 0.065. THEOREM-M1 part IV is PROVEN again.
  (Aside worth noting: the original spectral S-bound holds empirically, ‖S‖₂/‖E‖₂ ≤ 1.073
  < 4/3 — the theorem was true; only its proof was broken.)
  → `CLOSURE_G-M3_frobenius_repair.md`, `t2_m1_GS_frobenius_repair_check.py`.

- **κ̂ strict interval enclosure — the "value not enclosure" flag: RESOLVED.**
  The re-grade's float64 cumsum is replaced by end-to-end arb ball accumulation:
  **κ̂ ∈ [5.59564988046657624 ± 2×10⁻²⁰]** (argmax j=145,k=120; non-overlap margin 0.102 ≫
  radius). → `CLOSURE_T2a_khat_enclosure.md`.

- **Two grading corrections applied.** (i) κ̂'s [CERTIFIED] tag is now the strict enclosure
  above, not a ball-derived value. (ii) The horizon 3.2√N is recorded MEASURED, not proven —
  the fixed-j g-lemma rate k(k+1)/(π²N) → O(1) at j∼√N, so a uniform-in-j argument is needed
  (see the "still open" note below). Both match the audit's read.

- **sup|S_P|, self-adjointness scope, true-quantile transfer** — all recorded as the audit
  framed them. The frozen-center certificate was always honestly scoped to the dyadic-center
  object; the true-quantile extension is the T2a-QT close below.

## What the audit catalyzed (the closes)

- **T2a-QT — true-quantile transfer CERTIFIED-as-computed** (the audit's OPEN item). The
  KLMN form bound holds at the TRUE quantiles, not just the frozen centers. Route: Abel
  summation against the certified κ̂ (era-2 Theorems 1–2), ‖ΔJ‖∞ ≤ (κ̂^α+2κ̂^β)(TV(Δx)+|Δx_M|),
  then Weyl. κ̂ certified at ball grade (κ̂^α(drop-4 D)=5.5956 — reproduces the enclosure above
  exactly), TV(Δx) rigorous from the 1e-10 enclosures. All four pencils PSD, headroom
  4,265×–294,500×. The independently re-verified margins (drop-4 5.82e-5/4.23e-4, drop-1
  1.09e-2/1.26e-3) match the audit's 60-digit rebuild. → `CLOSURE_T2a_QT_abel.md`,
  `FINDINGS_T2a_QT_reduction.md`.

- **G-P2 — K2 transport-remainder constant CERTIFIED at ball grade.** sup_s|J″(s)| upgraded
  from float64 stencil (1e-3) to exact 2nd-derivative jets through Lanczos (flint-arb, prec
  16000, all rows radius 0): drop-4 sup|α″|=0.01137 (j=23), drop-1 0.09177 (j=3); validated
  vs the sealed stencil. → `CLOSURE_G-P2_jet_hessian.md`.

## Two corrections to our own prior framing (for the shared record)

- **P1 is not open.** The κ_j growth law is a THEOREM — the caustic result
  κ_j = 1 + a_∞μ^{1/3} + R_j, −1.1≤R_j≤0.5, a_∞ = 2^{2/3}3^{−5/6}/Γ(2/3)², via Olver/Airy
  (sent in the CAUSTIC_THEOREM package). The G-HROT explicit-constant question reduces to
  the same κ̂/Abel machinery and is delivered at config grade by the T2a-QT close above.

## Still open (honest)

- **M1-HORIZON** — the sharp horizon 3.2√N as a uniform-in-j statement. The tool is the
  caustic Olver/Airy machinery already built for the κ_j law; the specific uniform horizon
  lemma still has to be written. Recorded MEASURED with that route flagged.
- The fully-PROVEN *uniform* T2a-QT theorem (vs the config-grade certificate here) would use
  the caustic κ_j theorem for the boundary constant + a G-P2 continuous-s bridge. Offerable.

## Manifest

`evidence/` holds the four CLOSURE notes, two FINDINGS notes, the campaign `GAP_LIST.md`,
and every script + run log. `SHA256SUMS.txt` is the inner manifest; the external zip SHA is
in the `.sha256.txt` beside the zip. Grades and naming are shared/unsettled per usual — to
settle together.
