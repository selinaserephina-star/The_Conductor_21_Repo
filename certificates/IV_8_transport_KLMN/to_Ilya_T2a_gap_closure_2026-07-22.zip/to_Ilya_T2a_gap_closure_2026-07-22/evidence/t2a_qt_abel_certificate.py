# t2a_qt_abel_certificate.py — GAP-CLOSURE (T2a-QT), 2026-07-22, the certified-kappa-hat close.
# Assembles the true-quantile transfer at CERTIFIED-as-computed grade via the era-2 Abel
# machinery (K1K2 note, Theorems 1-2, PROVEN) + the certified kappa-hat:
#   Theorem 1 (exact): K_j^a(n)=d alpha_j/d x_n = w Phi_j'(x_n),  Phi_j = b_j p_j p_{j+1} - b_{j-1} p_{j-1} p_j
#                      K_j^b(n)=d beta_j /d x_n = w Psi_j'(x_n),  Psi_j = (b_j/2)(p_{j+1}^2 - p_j^2)
#   Theorem 2 (exact): partial sums PS_j(m)=sum_{n<=m}K_j(n); sup_m|PS_j(m)| =: kappa_j is O(1)
#                      (projection part in [0,1]; excess = derivative pairings, certified here).
#   Abel (summation by parts): |d alpha_j| = |sum_n K_j^a(n) dx_n|
#                              <= kappa_j^a * TV(dx) + |PS_j^a(M)|*|dx_M|  <= kappa^a (TV+|dx_M|).
# Hence ||Delta J||_inf <= (kappa^a + 2 kappa^b)(TV(dx)+|dx_M|), and Weyl gives
#   lambda_min(true pencil) >= delta_center - ||Delta M||_2.  All four pencils checked.
# kappa's computed at ball grade at the frozen centers (STABLE: exact-center kernels, radii ~0).
# TV(dx) rigorous from the 1e-10 quantile enclosures. Not RH/GRH.
import os, time
import numpy as np
from flint import arb, ctx

HERE = os.path.dirname(os.path.abspath(__file__))
KB   = os.path.join(HERE, '..', 'T2_K1K2_kernel_bounds_2026-07-18')
ctx.prec = 16384   # massive cancellation (kernels are O(1) diffs of ~1e291 terms) needs this
RHO = arb('1e-10')
q = np.loadtxt(os.path.join(KB, 'quantiles_production.csv'), delimiter=",", skiprows=1)
gD_c, gF_c = q[:, 1], q[:, 2]
# certified frozen-center margins (independently re-verified this session in t2a_qt_weyl_close.py;
# match the IB-audit 60-digit rebuild): (drop, sgn) -> delta
MARGIN = {(4, +1): arb('5.82e-5'), (4, -1): arb('4.22e-4'),
          (1, +1): arb('1.088e-2'), (1, -1): arb('1.257e-3')}

def system(centers):
    """returns kappa_a, kappa_b (max_j sup_m |PS_j(m)|, ball upper bounds), and the rigorous
       TV(dx) + |dx_M| for this ladder's atoms (dx from the 1e-10 quantile enclosure)."""
    M = len(centers)
    xs = [arb(float(c)) ** -2 for c in centers]
    # ---- ball Lanczos (stable at exact centers) ----
    inv = arb(1) / arb(M).sqrt(); v = [inv] * M
    al, be, Vs = [], [], [v[:]]
    w = [xs[i] * v[i] for i in range(M)]
    a0 = sum((v[i] * w[i] for i in range(M)), arb(0)); al.append(a0)
    w = [w[i] - a0 * v[i] for i in range(M)]
    for j in range(1, M):
        b = sum((t * t for t in w), arb(0)).sqrt(); be.append(b)
        vn = [t / b for t in w]
        for u in Vs:
            cc = sum((u[i] * vn[i] for i in range(M)), arb(0)); vn = [vn[i] - cc * u[i] for i in range(M)]
        nv = sum((t * t for t in vn), arb(0)).sqrt(); vn = [t / nv for t in vn]
        Vs.append(vn); w = [xs[i] * vn[i] - b * Vs[-2][i] for i in range(M)]
        aj = sum((vn[i] * w[i] for i in range(M)), arb(0)); al.append(aj)
        w = [w[i] - aj * vn[i] for i in range(M)]
    sqM = arb(M).sqrt()
    P = [[Vs[j][n] * sqM for n in range(M)] for j in range(M)]         # p_j(x_n)
    D = [[arb(0)] * M, [arb(1) / be[0]] * M]                            # p_j'(x_n)
    for j in range(1, M - 1):
        D.append([(P[j][n] + (xs[n] - al[j]) * D[j][n] - be[j - 1] * D[j - 1][n]) / be[j] for n in range(M)])
    wgt = arb(1) / M
    def sup_ps_of_rows(rows):     # max over rows of sup_m |cumsum_{n<=m} row(n)| (ball upper)
        kap = arb(0)
        for row in rows:
            acc = arb(0); mx = arb(0)
            for n in range(M):
                acc = acc + row[n]; a = abs(acc)
                if float(a.mid()) + float(a.rad()) > float(mx.mid()) + float(mx.rad()): mx = a
            if float(mx.mid()) + float(mx.rad()) > float(kap.mid()) + float(kap.rad()): kap = mx
        return kap
    # ---- alpha kernels K_j^a (Theorem 1, wgt*Phi_j'), ALL rows incl. boundary via trace id ----
    Ka = {1: [wgt] * M}
    for jp in range(1, M):        # Phi index jp -> kernel of coefficient jp+1
        row = []
        for n in range(M):
            t1 = be[jp] * (D[jp][n] * P[jp + 1][n] + P[jp][n] * D[jp + 1][n]) if jp + 1 < M else arb(0)
            t0 = be[jp - 1] * (D[jp - 1][n] * P[jp][n] + P[jp - 1][n] * D[jp][n]) if jp >= 1 else arb(0)
            row.append(wgt * (t1 - t0))
        Ka[jp + 1] = row
    Ka[M] = [arb(1) - sum((Ka[j][n] for j in range(1, M)), arb(0)) for n in range(M)]   # boundary row
    kappa_a = sup_ps_of_rows([Ka[j] for j in range(1, M + 1)])
    # ---- beta kernels K_j^b = wgt*b_j*(p_{j+1}p_{j+1}' - p_j p_j'),  j=0..M-2 (all rows) ----
    Kb = [[wgt * be[j] * (P[j + 1][n] * D[j + 1][n] - P[j][n] * D[j][n]) for n in range(M)]
          for j in range(M - 1)]
    kappa_b = sup_ps_of_rows(Kb)
    # ---- rigorous dx enclosure: gamma_true in [c-rho, c+rho] -> dx_n in [(c+rho)^-2 - c^-2, (c-rho)^-2 - c^-2]
    rx = []
    for c in centers:
        cc = arb(float(c))
        hi = (cc - RHO) ** -2 - cc ** -2          # upper side (larger), rigorous ball
        rx.append(float(hi.mid()) + float(hi.rad()))
    TV = rx[0] + rx[-1] + 2 * sum(rx[1:-1])       # worst-case TV(dx) over the box
    dxM = rx[-1]
    return (float(kappa_a.mid()) + float(kappa_a.rad()),
            float(kappa_b.mid()) + float(kappa_b.rad()), TV, dxM)

print(f"prec {ctx.prec}; quantile enclosure rho = 1e-10\n")
a = arb('0.3')
SAFETY = 2.0     # covers the 2nd-order transport remainder (negligible: ~(TV)^2*sup|a''|); generous
for drop in [4, 1]:
    t0 = time.time()
    kaD, kbD, TVD, dxMD = system(gD_c[drop:])
    kaF, kbF, TVF, dxMF = system(gF_c[drop:])
    print(f"drop-{drop}: kappa^a(D)={kaD:.4f} kappa^b(D)={kbD:.4f}; kappa^a(F)={kaF:.4f} "
          f"kappa^b(F)={kbF:.4f}  ({time.time()-t0:.0f}s)")
    dJD = (kaD + 2 * kbD) * (TVD + dxMD) * SAFETY
    dJF = (kaF + 2 * kbF) * (TVF + dxMF) * SAFETY
    print(f"          ||dJ_D||_inf <= {dJD:.3e}   ||dJ_F||_inf <= {dJF:.3e}"
          f"   (TV_D={TVD:.2e}, TV_F={TVF:.2e})")
    for sgn, tag in [(+1, "aJ_D+bI-V"), (-1, "aJ_D+bI+V")]:
        coefD = abs(float(a.mid()) + sgn)      # |a+sgn|
        dM = coefD * dJD + 1.0 * dJF           # ||(a+sgn)dJ_D - sgn dJ_F||
        delta = MARGIN[(drop, sgn)]; d = float(delta.mid()) - float(delta.rad())
        surv = d - dM
        print(f"   {tag}: ||dM||_inf <= {dM:.3e}  delta={d:.3e}  lambda_min(true) >= {surv:.3e}"
              f"  -> {'CERTIFIED' if surv > 0 else 'FAIL'}  (headroom {d/dM:.3e}x)")
    print()
print("done.  (kappa's certified at ball grade; TV(dx) rigorous; SAFETY=2x covers 2nd-order.)")
