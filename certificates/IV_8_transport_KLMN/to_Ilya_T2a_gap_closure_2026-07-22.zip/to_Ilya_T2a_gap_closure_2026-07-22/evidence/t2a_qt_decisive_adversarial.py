# t2a_qt_decisive_adversarial.py — GAP-CLOSURE (T2a-QT), 2026-07-22, the decisive test.
# Question that decides whether the kappa-hat/K1-cumulative route can close T2a-QT:
#   the point-FD only tested UNIFORM delta (all atoms shifted alike), where the sum rule
#   sum_n K_j(n)=1 forces Delta alpha_j = eps trivially. The TRUE deviation
#   delta_n = gamma^true_n - c_n is float64 rounding -> NON-uniform. So: does a non-uniform
#   / adversarially-aligned delta of size 1e-10 blow up Delta alpha_j (=> the box contains
#   PSD-violating points, transfer FALSE as posed) or does deeper cancellation hold it
#   down (=> kappa-hat governs, transfer certifiable)?
# Test (stable dps-60 point arithmetic; interval Lanczos was the only unstable thing):
#   (T1) many RANDOM delta_n in {+eps,-eps}, measure ||Delta J||_inf.
#   (T2) the WORST-aligned delta_n = eps * sign(K_{j*}(n)) at the deepest row j*, where
#        the alpha-kernel L1 is largest (~1e89) -> if Delta alpha_{j*} ~ L1*eps the box is
#        malignant; if ~eps it is benign.
# Not RH/GRH.
import os, time
import numpy as np
import mpmath as mp
from flint import arb, ctx

HERE = os.path.dirname(os.path.abspath(__file__))
KB   = os.path.join(HERE, '..', 'T2_K1K2_kernel_bounds_2026-07-18')
EPS  = 1e-10
q = np.loadtxt(os.path.join(KB, 'quantiles_production.csv'), delimiter=",", skiprows=1)
gD_c, gF_c = q[:, 1], q[:, 2]

mp.mp.dps = 60
def mp_alpha(xs):
    N = len(xs); v = [mp.mpf(1) / mp.sqrt(N)] * N
    al, Vs = [], [v[:]]
    w = [xs[i] * v[i] for i in range(N)]
    a0 = mp.fsum(v[i] * w[i] for i in range(N)); al.append(a0); w = [w[i] - a0 * v[i] for i in range(N)]
    be_prev = None
    for j in range(1, N):
        b = mp.sqrt(mp.fsum(t * t for t in w)); vn = [t / b for t in w]
        for u in Vs:
            c = mp.fsum(u[i] * vn[i] for i in range(N)); vn = [vn[i] - c * u[i] for i in range(N)]
        nv = mp.sqrt(mp.fsum(t * t for t in vn)); vn = [t / nv for t in vn]
        Vs.append(vn); w = [xs[i] * vn[i] - b * Vs[-2][i] for i in range(N)]
        aj = mp.fsum(vn[i] * w[i] for i in range(N)); al.append(aj); w = [w[i] - aj * vn[i] for i in range(N)]
    return al

drop = 4
cD = [mp.mpf(x) for x in gD_c[drop:]]
M = len(cD)
a0 = mp_alpha([1 / g**2 for g in cD])       # baseline alpha at centers

print(f"drop-{drop}, M={M}, eps={EPS:.0e}; baseline alpha computed (dps 60)\n")
print("(T1) RANDOM delta_n in {+eps,-eps}, independent per atom:")
rng = np.random.default_rng(20260722)
for trial in range(6):
    signs = rng.choice([-1.0, 1.0], size=M)
    gp = [cD[n] + mp.mpf(float(signs[n])) * mp.mpf(EPS) for n in range(M)]
    ap = mp_alpha([1 / g**2 for g in gp])
    dmax = max(abs(float(ap[j] - a0[j])) for j in range(M))
    jmax = max(range(M), key=lambda j: abs(float(ap[j] - a0[j])))
    print(f"   trial {trial}: max|d.alpha_j| = {dmax:.3e} at j={jmax}")

print("\n(T2) WORST-aligned delta_n = eps*sign(K_{j*}(n)) at the deepest rows:")
# get sign(K_j(n)) from a stable ball kernel at centers
ctx.prec = 2048
xs = [arb(float(g)) ** -2 for g in gD_c[drop:]]
inv = arb(1) / arb(M).sqrt(); v = [inv]*M
al, be, Vs = [], [], [v[:]]
w = [xs[i]*v[i] for i in range(M)]
aa = sum((v[i]*w[i] for i in range(M)), arb(0)); al.append(aa); w = [w[i]-aa*v[i] for i in range(M)]
for j in range(1, M):
    b = sum((t*t for t in w), arb(0)).sqrt(); be.append(b); vn = [t/b for t in w]
    for u in Vs:
        cc = sum((u[i]*vn[i] for i in range(M)), arb(0)); vn = [vn[i]-cc*u[i] for i in range(M)]
    nv = sum((t*t for t in vn), arb(0)).sqrt(); vn = [t/nv for t in vn]
    Vs.append(vn); w = [xs[i]*vn[i]-b*Vs[-2][i] for i in range(M)]
    aj = sum((vn[i]*w[i] for i in range(M)), arb(0)); al.append(aj); w = [w[i]-aj*vn[i] for i in range(M)]
sqM = arb(M).sqrt(); Pv = [[Vs[j][n]*sqM for n in range(M)] for j in range(M)]
Dv = [[arb(0)]*M, [arb(1)/be[0]]*M]
for j in range(1, M-1):
    Dv.append([(Pv[j][n]+(xs[n]-al[j])*Dv[j][n]-be[j-1]*Dv[j-1][n])/be[j] for n in range(M)])
wgt = arb(1)/M
def Krow(j):   # K_{j+1}(n) signs and L1
    row = []
    for n in range(M):
        t1 = be[j]*(Dv[j][n]*Pv[j+1][n]+Pv[j][n]*Dv[j+1][n]) if j+1 < M else arb(0)
        t0 = be[j-1]*(Dv[j-1][n]*Pv[j][n]+Pv[j-1][n]*Dv[j][n])
        row.append(wgt*(t1-t0))
    return row
for jstar in [M-5, M-2, M//2, M//4]:
    j = jstar - 1                       # K row index for alpha_{jstar}
    if j < 1 or j >= M-1: continue
    row = Krow(j)
    L1 = sum(float(abs(t.mid())) for t in row)
    signs = [1.0 if float(t.mid()) >= 0 else -1.0 for t in row]
    gp = [cD[n] + mp.mpf(signs[n]) * mp.mpf(EPS) for n in range(M)]
    ap = mp_alpha([1 / g**2 for g in gp])
    dstar = abs(float(ap[jstar] - a0[jstar]))
    print(f"   j*={jstar}: kernel L1 = {L1:.3e};  aligned d.alpha_j* = {dstar:.3e};"
          f"  L1*eps = {L1*EPS:.3e}  -> {'MALIGNANT (~L1*eps)' if dstar > 100*EPS else 'BENIGN (~eps)'}")
print("\ndone.")
