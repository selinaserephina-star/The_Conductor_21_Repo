# CLOSURE — T2a-KHAT: κ̂ strict interval enclosure

**Merkabit · Stenberg + Claude · 2026-07-22.** Closes the audit item
`KHAT_STRICT_INTERVAL_ENCLOSURE = OPEN` (`INDEPENDENT_AUDIT_received_2026-07-22/`) and
the CAVEAT added to ledger item 3.5. Script `t2a_khat_enclosure.py` (+ run log). Source
(read-only, sealed): `T2a_pencil_certification_2026-07-21/t2a_khat_regrade.py`. Not RH/GRH.

## The gap
The re-grade computed the Theorem-1 kernel rows K[j] as prec-16384 **arb balls** (entry
radii < 2⁻¹⁶³⁸⁴; per-row sum-rule dev = 0), but the final head-suppression cumulative
sums and their max were taken on **float64 midpoints** (`np.cumsum([float(t.mid()) …])`).
So κ̂ = 5.5956 was a ball-*derived* value, not an interval enclosure — exactly the
audit's point ("accumulate the Arb balls themselves and output κ̂ ∈ [κ₋, κ₊]").

## The fix (keep the balls)
Re-ran (K1)–(K3) verbatim (ball Lanczos + derivative recurrence + Theorem-1 rows +
boundary row via the exact trace identity K_M = 1 − Σ_{j<M}K_j), then:
- **(E1)** head sums H_{j,k} = Σ_{n≤k} K[j][n] accumulated **in arb**;
- **(E2)** κ_j = max_k |H_{j,k}| via `abs_ball` (rigorous, since the maximizing head is
  bounded away from 0) on the ball upper endpoints;
- **(E3)** κ̂ = max_j κ_j reported as an arb enclosure, with an a-posteriori
  **non-overlap certificate**: the argmax head beats every other head's upper endpoint
  by margin 0.102 ≫ the ~2e-20 ball radius, so the argmax is unambiguous.

## Result
```
kappa-hat argmax at (j=145, k=120); enclosure [5.5956498804665762372 +/- 1.98e-20]
STRICT ENCLOSURE:  kappa-hat in [5.595649880467, 5.595649880467]   (width ~4e-20)
non-overlap margin = 1.023563e-01  (>> radius: argmax certified)
```

**κ̂ ∈ [5.59564988046657624 ± 2×10⁻²⁰]** — 18 correct digits, strict.
The boundary-row location (j = 145 = M) and the stored value 5.5956 are both confirmed;
the mildness-vs-Chebyshev claim (5.60 vs 46.15) is unaffected and now rests on an
enclosed κ̂.

## Grade
`KHAT_STRICT_INTERVAL_ENCLOSURE`: **OPEN → CERTIFIED (strict enclosure)**.
Ledger item 3.5 κ̂ tag: [CERTIFIED, value] → [CERTIFIED, strict enclosure].
