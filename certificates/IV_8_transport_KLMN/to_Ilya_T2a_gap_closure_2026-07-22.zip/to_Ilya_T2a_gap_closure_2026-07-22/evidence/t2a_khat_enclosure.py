# t2a_khat_enclosure.py — GAP-CLOSURE (T2a-KHAT), 2026-07-22.
# Closes the audit's kappa-hat item: the re-grade script t2a_khat_regrade.py computed
# the kernel rows K[j] as prec-16384 ARB BALLS (radii 0), but then took the cumulative
# head-sums and the max on float64 MIDPOINTS (np.cumsum([float(t.mid()) ...])) — so it
# delivered a ball-DERIVED value, not a strict interval enclosure. Here we keep the
# accumulation IN BALL ARITHMETIC end-to-end and emit  kappa-hat in [k-, k+].
#
# Method: reuse the exact (K1)-(K3) ball computation of the drop-4 D-system kernels from
# the regrade script (Lanczos + derivative recurrence + Theorem-1 rows + boundary row via
# the exact trace identity, all arb prec 16384, per-row sum-rule certificate). Then:
#   (E1) head-suppression partial sums H_{j,k} = sum_{n<=k} K[j][n]  IN ARB;
#   (E2) kappa_j = max_k |H_{j,k}|  as a rigorous enclosure (balls don't straddle 0 at
#        the maximizing k, and the inter-kappa gaps ~1e-4 dwarf the ~1e-4900 radii, so the
#        argmax is unambiguous — verified a posteriori by the non-overlap margin);
#   (E3) kappa-hat = max_j kappa_j, reported as [k-, k+] with the achieving (j,k).
# Not RH/GRH.
import os, time
import numpy as np
from flint import arb, ctx

HERE = os.path.dirname(os.path.abspath(__file__))
SRC  = os.path.join(HERE, '..', 'T2a_pencil_certification_2026-07-21')  # read-only source
KB   = os.path.join(HERE, '..', 'T2_K1K2_kernel_bounds_2026-07-18')
ctx.prec = 16384

# ---- (K1) ball Lanczos of the drop-4 D-system, keeping the basis (verbatim) ----
q = np.loadtxt(os.path.join(KB, 'quantiles_production.csv'), delimiter=",", skiprows=1)
gD0 = q[:, 1]
xs = [arb(float(gD0[n])) ** -2 for n in range(4, 149)]     # exact dyadic centers, drop-4
M = len(xs)
t0 = time.time()
inv = arb(1) / arb(M).sqrt()
v = [inv for _ in range(M)]
al, be, Vs = [], [], [v[:]]
w = [xs[i] * v[i] for i in range(M)]
a0 = sum((v[i] * w[i] for i in range(M)), arb(0)); al.append(a0)
w = [w[i] - a0 * v[i] for i in range(M)]
for j in range(1, M):
    b = sum((t * t for t in w), arb(0)).sqrt()
    be.append(b)
    vn = [t / b for t in w]
    for u in Vs:
        cc = sum((u[i] * vn[i] for i in range(M)), arb(0))
        vn = [vn[i] - cc * u[i] for i in range(M)]
    nv = sum((t * t for t in vn), arb(0)).sqrt()
    vn = [t / nv for t in vn]
    Vs.append(vn)
    w = [xs[i] * vn[i] - b * Vs[-2][i] for i in range(M)]
    aj = sum((vn[i] * w[i] for i in range(M)), arb(0)); al.append(aj)
    w = [w[i] - aj * vn[i] for i in range(M)]
rmax = max(max(float(t.rad()) for t in al), max(float(t.rad()) for t in be))
print(f"(K1) M = {M}; Jacobi entry radii <= {rmax:.2e}; basis kept  ({time.time()-t0:.0f}s)")
sqM = arb(M).sqrt()
Pv = [[Vs[j][n] * sqM for n in range(M)] for j in range(M)]

# ---- (K2) ball derivative recurrence for p'_j(x_n) (verbatim) ----
Dv = [[arb(0) for _ in range(M)]]
Dv.append([arb(1) / be[0] for _ in range(M)])
Dv[1] = [arb(1) / be[0] for _ in range(M)]
for j in range(1, M - 1):
    Dv.append([(Pv[j][n] + (xs[n] - al[j]) * Dv[j][n] - be[j - 1] * Dv[j - 1][n]) / be[j]
               for n in range(M)])

# ---- (K3) Theorem-1 kernel rows + boundary row + per-row sum-rule certificate ----
wgt = arb(1) / M
K = {}
for j in range(1, M):
    row = []
    for n in range(M):
        t1 = be[j] * (Dv[j][n] * Pv[j + 1][n] + Pv[j][n] * Dv[j + 1][n]) if j + 1 < M else arb(0)
        t0_ = be[j - 1] * (Dv[j - 1][n] * Pv[j][n] + Pv[j - 1][n] * Dv[j][n]) if j >= 1 else arb(0)
        row.append(wgt * (t1 - t0_))
    K[j + 1] = row
K[1] = [wgt for _ in range(M)]
K[M] = [arb(1) - sum((K[j][n] for j in range(1, M)), arb(0)) for n in range(M)]
worst_sum = 0.0
for j in range(2, M + 1):
    s = sum(K[j], arb(0))
    worst_sum = max(worst_sum, abs(float((s - 1).mid())) + float((s - 1).rad()))
print(f"(K3) per-row sum rule sum_n K_j = 1: worst |dev| (mid+rad) = {worst_sum:.2e}")

# ---- (E1)-(E3) THE ENCLOSURE: ball head-sums, ball max, strict [k-, k+] ----
def abs_ball(x):
    # rigorous enclosure of |x| for a ball that does not straddle 0
    return x if float(x.mid()) >= 0 else -x

best = {'khi': -1.0, 'arb': None, 'j': None, 'k': None}   # global argmax by upper endpt
second_hi = -1.0                                          # 2nd-largest upper endpoint
for j in range(2, M + 1):
    head = arb(0)
    for k in range(M):
        head = head + K[j][k]                # H_{j,k} in ARB (exact ball accumulation)
        a = abs_ball(head)
        hi = float(a.mid()) + float(a.rad())
        if hi > best['khi']:
            second_hi = best['khi']
            best = {'khi': hi, 'arb': a, 'j': j, 'k': k}
        elif hi > second_hi:
            second_hi = hi
khat = best['arb']
kmid, krad = float(khat.mid()), float(khat.rad())
klo, khi = kmid - krad, kmid + krad
gap = klo - second_hi     # margin by which the argmax beats every other head (non-overlap)
print(f"(E) kappa-hat argmax at (j={best['j']}, k={best['k']}); ball radius = {krad:.2e}")
print(f"    STRICT ENCLOSURE:  kappa-hat in [{klo:.12f}, {khi:.12f}]")
print(f"    arb enclosure:     {khat.str(20, radius=True)}")
print(f"    non-overlap margin (klo - 2nd-largest head upper) = {gap:.6e}  "
      f"{'(argmax certified: gap >> 0)' if gap > 0 else '(FAIL: overlap!)'}")
print(f"    stored record 5.5956  ->  now enclosed to width {khi-klo:.2e}")
print("done.")
