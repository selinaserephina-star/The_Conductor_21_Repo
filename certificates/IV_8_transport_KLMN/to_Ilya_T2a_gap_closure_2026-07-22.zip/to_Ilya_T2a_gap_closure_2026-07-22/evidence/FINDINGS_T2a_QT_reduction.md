# FINDINGS — T2a-QT (true-quantile transfer): the obstruction was illusory; transfer is benign

**Merkabit · Stenberg + Claude · 2026-07-22.** Progress on the audit item
`T2A_TRUE_QUANTILE_FORM_BOUND = OPEN_PENDING_SENSITIVITY`. **This note supersedes its own
first version** (which concluded T2a-QT reduced to the hard K1/κ̂ lane — that was WRONG,
based on a mis-identified kernel). Scripts: `t2a_true_quantile_transfer.py` (direct route,
unstable), `t2a_qt_kernel_sensitivity.py` (wrong-kernel bound, vacuous),
`t2a_qt_decisive_adversarial.py` (the decisive test), `t2a_qt_true_sensitivity.py` (the
O(1) constant). Not RH/GRH.

## The three routes and the decisive test

**Route 1 — direct ball propagation** (1e-10 quantile balls → ball Lanczos + Cholesky,
prec 16384). **Unstable:** interval dependency (reorthogonalization subtracts near-equal
balls) blows Jacobi-entry radii to `inf` in ~1s. An interval-arithmetic artifact on an
ill-conditioned *construction*, not a real failure — unusable as the certificate.

**Route 2a — first-order bound with the Theorem-1 kernel** `Σ_n|K_j(n)|·r_x(n)`.
**Vacuous** (≤ 3×10⁸⁹). BUT the object was WRONG: the Theorem-1 kernel
`K_j(n) = w[β_j(p_jp_{j+1})' − β_{j-1}(p_{j-1}p_j)'](x_n)` carries the polynomial
derivatives `p'_j(x)` (~10²⁹¹) — it is the sensitivity of the *K1 partial-sum functional*,
**not** the atom-position sensitivity `∂α_j/∂x_n`. Bounding the wrong gradient produced a
phantom e^{cj} "wall."

**The decisive test** (`t2a_qt_decisive_adversarial.py`, stable dps-60 point arithmetic —
only *interval* Lanczos was unstable):
- **(T1) random δ_n ∈ {±10⁻¹⁰}, independent per atom (6 trials):**
  `max|Δα_j| ≈ 2.0–2.8×10⁻¹¹`.
- **(T2) adversarially aligned** δ_n = ε·sign(K_{j*}(n)) at j* = 36, 72, 140, 143:
  `Δα_{j*} ≈ 1.5×10⁻¹⁴ … 1.9×10⁻¹³` — at j*=36 where the (wrong) kernel L1 = 23,
  the aligned Δα (1.9×10⁻¹³) is **~10⁴× below L1·ε = 2.3×10⁻⁹**.

**Conclusion: the transfer is benign in EVERY direction — random and adversarial alike.**
The true atom-position sensitivity is O(1) (the G-HROT rotation scale, C_rot ≈ 1.04–1.18),
not e^{cj}. `Δα_j ≈ ε` because the sum rule `Σ_n ∂α_j/∂x_n = O(1)` (uniform shift →
`Δα_j = ε` exactly), and the fluctuation part does not amplify.

## The true sensitivity (route 2b, correct object)

`t2a_qt_true_sensitivity.py` computes the honest Jacobian L1,
`L1_j = Σ_m |∂α_j/∂x_m|` and the box-worst `Σ_m|∂α_j/∂x_m|·r_x(m)`, by a stable point
forward-difference (dps 40, full M=145 Jacobian). **Result (drop-4):**
- `max_j Σ_m|∂α_j/∂x_m| = 52.667`,  `max_j Σ_m|∂β_j/∂x_m| = 25.371` — **bounded ~O(10¹),
  NOT e^{cj}** (contrast the wrong-kernel 10⁸⁹).
- box-worst `|Δα_j| ≤ 3.30×10⁻¹¹`, `|Δβ_j| ≤ 1.70×10⁻¹¹`  (aligned δ = r_x·sign(∂/∂x)).
- **rigorous first-order `‖ΔJ‖∞ ≤ 6.69×10⁻¹¹`  vs tightest margin 5.0×10⁻⁵ → headroom
  747,267×.**

## The close (Weyl structure)

The frozen-center pencils are certified PSD with margins δ (drop-1 5.5e-3 / 6.9e-4,
drop-4 5.0e-5 / 4.0e-4 — smallest eigenvalue ≥ δ, ball-verified in the sealed cert). By
Weyl, the true-quantile pencil has smallest eigenvalue ≥ δ − ‖ΔJ‖₂, and
`‖ΔJ‖₂ ≤ ‖ΔJ‖∞ ≤ 6.69×10⁻¹¹ ≪ 5.0×10⁻⁵ = δ_min`. **So the true-quantile pencils are PSD,
and the KLMN form bound holds at the true quantiles — with 7.5×10⁵× headroom on the
binding (drop-4) pencil.** Script `t2a_qt_weyl_close.py`.

## Grade

`T2A_TRUE_QUANTILE_FORM_BOUND`: **OPEN → CERTIFIED-modulo-sensitivity-ceiling.** The Weyl
structure and the margins are rigorous; what remains for a full ball-grade tag is a single
mechanical item — a **rigorous ceiling on the atom→Jacobi sensitivity** (replacing the
stable point-FD value 52.667). The requirement is extremely loose: *any* rigorous ceiling
`< δ_min/(3·max_m r_x) = 5.0×10⁻⁵/(3·2.25×10⁻¹¹) ≈ 7.4×10⁵` closes it, versus the measured
53 — i.e. **4 orders of slack on the ceiling itself.** Candidate rigorous ceilings:
(i) the G-HROT rotation bound with an explicit constant (item 3.8, measured C_rot≈1.1);
(ii) validated forward-AD of the center Lanczos (stable at the center) → enclosed gradient
+ crude ball curvature remainder. This is a formality of the same character as the sealed
cert's own θ-module ("25 orders of headroom, awaiting the rigorous wrapper").

- **Correction on record:** the earlier "e^{cj} wall / reduces to the hard K1 lane" was
  WRONG — it bounded the Theorem-1 kernel (polynomial derivatives p'), not the
  atom-position sensitivity ∂α_j/∂x_n, which is O(10¹).
- Frozen-center certificate (the sent T2a object) is unaffected throughout.
