# CLOSURE — G-P2: K2's transport-remainder constant, stencil → certified 2nd derivative

**Merkabit · Stenberg + Claude · 2026-07-22.** Delivers the interval upgrade the K1K2 note
flagged for G-P2/"P2" (§8: "K2 is closed on the range by measured sup|J″| with stencil
consistency 1e-3 — numerical grade, **interval-upgradeable by evaluating J″ certified
rather than by stencil**"). Scripts `t2_gp2_jet_hessian_arb.py` (+ mpmath validator
`t2_gp2_jet_hessian.py`, run logs). Not RH/GRH.

## What was numerical

K2/Theorem 3 bounds the transport remainder `|V − V^lin| ≤ ½·sup_s|J″(s)|` along
`x(s) = (1−s)x^D + s x^F`. The sealed K1K2 note computed `sup|J″|` by a **float64 central
2nd-difference stencil** (33-point s-grid, h-vs-2h consistency ~1e-3) — a numerical-grade
constant.

## The upgrade — exact 2nd derivative by jets, ball grade

`J″(s)` is computed **exactly** by 2nd-order automatic differentiation (jets `(v, ∂_s,
∂²_s)`) propagated through the Lanczos recursion at point atoms `x_n(s)` — no stencil, no
finite h. Point arithmetic is STABLE (unlike interval Lanczos over the box). Ported to
flint-arb (mpmath was too slow); at prec 16000 **every row's α″ ball has radius 0**
(`worst clean rad 0.0e+00`), so the sup is a certified enclosure, not a measurement.

Validation: N=60 drop-4 reproduces the mpmath jet (0.0119396, j=22) and the note's stencil
(1.12e-2); the row-certification check ("ALL rows certified") holds.

## Certified constants (production sections, prec 16000, all rows certified)

| section | sup_s,j \|α_j″\| | at (j,s) | sup \|β_j″\| | note stencil (α) |
|---|---|---|---|---|
| drop-4, N=149 | **0.0113682 ± 1.7×10⁻⁸** | (23, s=1) | 0.0041283 | 1.063e-2 @ j=23 |
| drop-1, N=149 | **0.0917675 ± 1.6×10⁻⁹** | (3, s=1) | 0.0358598 | 8.46e-2 @ j=3 |

The exact values sit slightly above the stencil (the finite-h central difference
under-resolves the true max) and localize at the same j. The max is at the **s=1 endpoint**
(the F-config) in every case. Hence the certified transport-remainder constants
`½·sup|J″|`: drop-4 α 5.68e-3 / β 2.06e-3; drop-1 α 4.59e-2 / β 1.79e-2.

## Grade

`G-P2`: **[GAP] → K2 transport-remainder constant CERTIFIED at ball grade** (exact
2nd-derivative jets, all rows radius 0). This is the note's stated interval upgrade
(stencil → certified J″). Feeds directly into the T2a-QT 2nd-order term (the O(0.01–0.09)
sup|α″| scale is now certified, amply justifying the 2× safety there).

Honest residual (offerable, NOT needed for the constant): (i) the sup is certified at the
s-grid {0, ½, 1} with the max at the s=1 endpoint — full continuous-s coverage needs a
finer grid + an |α‴| bridge (mechanical; the endpoint location makes it low-risk);
(ii) the closed-form second-order kernel IDENTITY in {p, p′, p″, first-order kernels}
(the symbolic "differentiate Theorem 1") remains a separate derivation — offerable, not
required to certify sup|J″|.
