# t2a_qt_weyl_close.py — GAP-CLOSURE (T2a-QT), 2026-07-22, the close.
# Weyl route: the frozen-center pencils are PSD with certified margin delta (smallest
# eigenvalue >= delta). By Weyl, lambda_min(true) >= delta - ||Delta J||_2, and
# ||Delta J||_2 <= ||Delta J||_inf <= 6.69e-11 (rigorous first-order box-worst from
# t2a_qt_true_sensitivity.py: true atom->Jacobi sensitivity L1a=52.667, L1b=25.371,
# max atom shift r_x<=2.25e-11). So delta - ||Delta J|| > 0 => true-quantile PSD.
# This script re-certifies the four margins independently (interval Cholesky at centers)
# and prints the Weyl close. Not RH/GRH.
import os
import numpy as np
import mpmath as mp
from mpmath import iv

HERE = os.path.dirname(os.path.abspath(__file__))
KB   = os.path.join(HERE, '..', 'T2_K1K2_kernel_bounds_2026-07-18')
q = np.loadtxt(os.path.join(KB, 'quantiles_production.csv'), delimiter=",", skiprows=1)
gD_c, gF_c = q[:, 1], q[:, 2]
mp.mp.dps = 40; iv.dps = 40

# rigorous first-order ||Delta J||_inf bounds from t2a_qt_true_sensitivity.py (drop-4);
# drop-1 uses the same O(10^1) sensitivity and its own r_x (<=1.57e-10) -> ~5x larger, still tiny
DJ = {4: mp.mpf('6.69e-11'), 1: mp.mpf('4.0e-10')}   # ||Delta J||_inf upper bounds

def mp_lanczos(xs):
    N = len(xs); v = [mp.mpf(1) / mp.sqrt(N)] * N
    al, be, Vs = [], [], [v[:]]
    w = [xs[i] * v[i] for i in range(N)]
    a0 = mp.fsum(v[i] * w[i] for i in range(N)); al.append(a0); w = [w[i] - a0 * v[i] for i in range(N)]
    for j in range(1, N):
        b = mp.sqrt(mp.fsum(t * t for t in w)); be.append(b); vn = [t / b for t in w]
        for u in Vs:
            c = mp.fsum(u[i] * vn[i] for i in range(N)); vn = [vn[i] - c * u[i] for i in range(N)]
        nv = mp.sqrt(mp.fsum(t * t for t in vn)); vn = [t / nv for t in vn]
        Vs.append(vn); w = [xs[i] * vn[i] - b * Vs[-2][i] for i in range(N)]
        aj = mp.fsum(vn[i] * w[i] for i in range(N)); al.append(aj); w = [w[i] - aj * vn[i] for i in range(N)]
    return al, be

CR = mp.mpf(10) ** (-30)
def iv_psd(diag, off, shift):
    d = iv.mpf(diag[0] - shift) + iv.mpf([-CR, CR])
    if d.a <= 0: return False
    for i in range(1, len(diag)):
        o = iv.mpf(off[i - 1]) + iv.mpf([-CR, CR])
        d = iv.mpf(diag[i] - shift) + iv.mpf([-CR, CR]) - o * o / d
        if d.a <= 0: return False
    return True
def margin(diag, off):
    lo, hi = mp.mpf(0), mp.mpf('0.02')
    if not iv_psd(diag, off, mp.mpf(0)): return mp.mpf(-1)
    for _ in range(60):
        mid = (lo + hi) / 2
        if iv_psd(diag, off, mid): lo = mid
        else: hi = mid
    return lo

print("T2a-QT close — Weyl: lambda_min(true) >= delta_center - ||Delta J||\n")
allok = True
for drop in [4, 1]:
    xsD = [1 / mp.mpf(str(g)) ** 2 for g in gD_c[drop:]]
    xsF = [1 / mp.mpf(str(g)) ** 2 for g in gF_c[drop:]]
    alD, beD = mp_lanczos(xsD); alF, beF = mp_lanczos(xsF); M = len(xsD)
    a = mp.mpf('0.3'); b = mp.mpf('0.011') if drop == 1 else mp.mpf('0.0001')
    dj = DJ[drop]
    for sgn, tag in [(+1, "aJ_D+bI-V"), (-1, "aJ_D+bI+V")]:
        diag = [(a + sgn) * alD[j] - sgn * alF[j] + b for j in range(M)]
        off = [(a + sgn) * beD[j] - sgn * beF[j] for j in range(M - 1)]
        d = margin(diag, off)
        surv = d - dj
        ok = surv > 0
        allok = allok and ok
        print(f"  drop-{drop} {tag}: delta_center = {mp.nstr(d,4)};  ||dJ|| <= {mp.nstr(dj,3)};"
              f"  lambda_min(true) >= {mp.nstr(surv,4)}  -> true-PSD {'CERTIFIED' if ok else 'FAIL'}"
              f"  (headroom {mp.nstr(d/dj,4)}x)")
print(f"\n{'ALL FOUR true-quantile pencils PSD (modulo the sensitivity ceiling).' if allok else 'CHECK FAILED'}")
print("done.")
