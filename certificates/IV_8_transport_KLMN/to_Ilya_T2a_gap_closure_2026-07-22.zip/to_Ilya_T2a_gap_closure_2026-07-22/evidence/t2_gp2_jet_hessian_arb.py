# t2_gp2_jet_hessian_arb.py — GAP-CLOSURE (G-P2), 2026-07-22. flint-arb port of the jet
# Hessian (mpmath was too slow for N=149). Computes alpha_j''(s), beta_j''(s) EXACTLY by
# 2nd-order automatic differentiation (jets) through the Lanczos recursion at point atoms
# x_n(s)=(1-s)x^D_n + s x^F_n; certifies sup_{j,s}|alpha_j''|, |beta_j''|, upgrading K2's
# transport-remainder constant from float64 stencil (1e-3) to exact ball-grade 2nd deriv.
# Validated to reproduce the mpmath value (N=60 drop-4: 0.0119396). Not RH/GRH.
import os, csv, sys, time
from flint import arb, ctx

HERE = os.path.dirname(os.path.abspath(__file__))
KB   = os.path.join(HERE, '..', 'T2_K1K2_kernel_bounds_2026-07-18')

class Jet:
    __slots__ = ('v', 'd', 'dd')
    def __init__(self, v, d=0, dd=0):
        self.v = v if isinstance(v, arb) else arb(v)
        self.d = d if isinstance(d, arb) else arb(d)
        self.dd = dd if isinstance(dd, arb) else arb(dd)
    def __add__(s, o):
        o = o if isinstance(o, Jet) else Jet(o)
        return Jet(s.v + o.v, s.d + o.d, s.dd + o.dd)
    __radd__ = __add__
    def __sub__(s, o):
        o = o if isinstance(o, Jet) else Jet(o)
        return Jet(s.v - o.v, s.d - o.d, s.dd - o.dd)
    def __rsub__(s, o):
        return (o if isinstance(o, Jet) else Jet(o)).__sub__(s)
    def __mul__(s, o):
        o = o if isinstance(o, Jet) else Jet(o)
        return Jet(s.v * o.v, s.d * o.v + s.v * o.d, s.dd * o.v + 2 * s.d * o.d + s.v * o.dd)
    __rmul__ = __mul__
    def __truediv__(s, o):
        o = o if isinstance(o, Jet) else Jet(o)
        v = s.v / o.v
        d = (s.d - v * o.d) / o.v
        dd = (s.dd - 2 * d * o.d - v * o.dd) / o.v
        return Jet(v, d, dd)
    def sqrt(s):
        v = s.v.sqrt(); d = s.d / (2 * v); dd = (s.dd - 2 * d * d) / (2 * v)
        return Jet(v, d, dd)

def lanczos_jets(xj):
    N = len(xj)
    inv = Jet(1) / Jet(N).sqrt()
    v = [inv] * N
    al, be, Vs = [], [], [v[:]]
    w = [xj[i] * v[i] for i in range(N)]
    a0 = sum((v[i] * w[i] for i in range(N)), Jet(0)); al.append(a0)
    w = [w[i] - a0 * v[i] for i in range(N)]
    for j in range(1, N):
        b = sum((t * t for t in w), Jet(0)).sqrt(); be.append(b)
        vn = [t / b for t in w]
        for u in Vs:
            c = sum((u[i] * vn[i] for i in range(N)), Jet(0)); vn = [vn[i] - c * u[i] for i in range(N)]
        nv = sum((t * t for t in vn), Jet(0)).sqrt(); vn = [t / nv for t in vn]
        Vs.append(vn); w = [xj[i] * vn[i] - b * Vs[-2][i] for i in range(N)]
        aj = sum((vn[i] * w[i] for i in range(N)), Jet(0)); al.append(aj)
        w = [w[i] - aj * vn[i] for i in range(N)]
    return al, be

q = []
with open(os.path.join(KB, 'quantiles_production.csv')) as fh:
    for row in csv.DictReader(fh):
        q.append((float(row['gamma_D']), float(row['gamma_fwd'])))
gD = [r[0] for r in q]; gF = [r[1] for r in q]

CASES = [(4, 60, 2048), (4, 149, 16000), (1, 149, 16000)]
if len(sys.argv) > 1 and sys.argv[1] == 'validate':
    CASES = [(4, 60, 2048)]
S_GRID = ['0', '0.5', '1']
for k, N, prec in CASES:
    ctx.prec = prec
    t0 = time.time()
    xD = [arb(str(gD[n])) ** -2 for n in range(k, N)]
    xF = [arb(str(gF[n])) ** -2 for n in range(k, N)]
    dx = [xF[i] - xD[i] for i in range(len(xD))]
    sup_a = arb(0); sup_b = arb(0); at = None
    bad = 0; worstrad = 0.0
    for ss in S_GRID:
        s = arb(ss)
        xj = [Jet(xD[i] + s * dx[i], dx[i], 0) for i in range(len(xD))]
        al, be = lanczos_jets(xj)
        for j in range(len(al)):
            r = float(al[j].dd.rad())
            if not (r < 1e-6): bad += 1              # NaN/inf-safe: count uncertified rows
            worstrad = max(worstrad, r) if r < 1e300 else worstrad
            a = abs(al[j].dd)
            if float(a.mid()) > float(sup_a.mid()): sup_a = a; at = (j, ss)
        for j in range(len(be)):
            b = abs(be[j].dd)
            if float(b.mid()) > float(sup_b.mid()): sup_b = b
    tag = "ALL rows certified" if bad == 0 else f"{bad} UNCERTIFIED rows (raise prec)"
    print(f"k={k} N={N} (prec {prec}): sup|alpha''| = {sup_a.str(6)} at (j,s)={at}; "
          f"sup|beta''| = {sup_b.str(6)}; worst clean rad {worstrad:.1e}; {tag}  ({time.time()-t0:.0f}s)")
print("done. (exact 2nd derivs via arb jets; note's stencil: (4,60)1.12e-2, (4,149)1.06e-2@j23,"
      " (1,149)8.46e-2@j3)")
