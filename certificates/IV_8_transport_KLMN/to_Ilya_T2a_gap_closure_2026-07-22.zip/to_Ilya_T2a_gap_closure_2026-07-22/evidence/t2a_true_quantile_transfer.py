# t2a_true_quantile_transfer.py — GAP-CLOSURE (T2a-QT), 2026-07-22.
# Closes the audit item T2A_TRUE_QUANTILE_FORM_BOUND = OPEN_PENDING_SENSITIVITY.
# The sealed T2a cert (t2a_certify.py / t2a_theta_module.py) proves the four PSD
# statements on the EXACT dyadic-center atoms, and separately certifies the true
# quantiles lie in balls of radius 1e-10 (both ladders). The bridge — how much the
# Jacobi entries move under a 1e-10 atom shift — was MEASURED (||dM||_inf <= 2.29 max|dg|),
# not certified. Here we make it rigorous by the direct route: put the 1e-10 quantile
# uncertainty INTO the atoms as arb balls and re-run Lanczos + Cholesky at prec 16384.
# arb propagates the sensitivity rigorously; if every Cholesky pivot's LOWER bound stays
# positive, the PSD (hence KLMN form bound) holds for the true quantiles, not just the
# frozen centers. Not RH/GRH.
import os, time
import numpy as np
from flint import arb, ctx

HERE = os.path.dirname(os.path.abspath(__file__))
KB   = os.path.join(HERE, '..', 'T2_K1K2_kernel_bounds_2026-07-18')
ctx.prec = 16384
RHO_GAMMA = arb(0, 1e-10)     # certified quantile enclosure radius (both ladders, theta-module)

q = np.loadtxt(os.path.join(KB, 'quantiles_production.csv'), delimiter=",", skiprows=1)
gD_c, gF_c = q[:, 1], q[:, 2]     # dyadic centers, D and F ladders (149 rows)

def gamma_ball(c):
    return arb(float(c)) + RHO_GAMMA      # true quantile in [c +/- 1e-10], certified

def ball_lanczos(xs):
    """full-reorth ball Lanczos; returns al[0..M-1], be[0..M-2] as arb balls."""
    M = len(xs)
    inv = arb(1) / arb(M).sqrt()
    v = [inv for _ in range(M)]
    al, be, Vs = [], [], [v[:]]
    w = [xs[i] * v[i] for i in range(M)]
    a0 = sum((v[i] * w[i] for i in range(M)), arb(0)); al.append(a0)
    w = [w[i] - a0 * v[i] for i in range(M)]
    for j in range(1, M):
        b = sum((t * t for t in w), arb(0)).sqrt(); be.append(b)
        vn = [t / b for t in w]
        for u in Vs:
            cc = sum((u[i] * vn[i] for i in range(M)), arb(0))
            vn = [vn[i] - cc * u[i] for i in range(M)]
        nv = sum((t * t for t in vn), arb(0)).sqrt()
        vn = [t / nv for t in vn]
        Vs.append(vn)
        w = [xs[i] * vn[i] - b * Vs[-2][i] for i in range(M)]
        aj = sum((vn[i] * w[i] for i in range(M)), arb(0)); al.append(aj)
        w = [w[i] - aj * vn[i] for i in range(M)]
    return al, be

def lower(x):     # rigorous lower bound of an arb ball
    return float(x.mid()) - float(x.rad())

def ball_chol_margin(diag, off):
    """largest shift s with tridiag(diag,off) - s*I still ball-PSD (all pivot lower
       bounds > 0); returns (psd_at_0, certified_margin_lowerbound, max_entry_radius)."""
    def psd(shift):
        d = diag[0] - shift
        if lower(d) <= 0: return False
        for i in range(1, len(diag)):
            d = diag[i] - shift - off[i - 1] ** 2 / d
            if lower(d) <= 0: return False
        return True
    psd0 = psd(arb(0))
    lo, hi = arb(0), arb(1) / 50          # search margin in [0, 0.02]
    if not psd0:
        return False, 0.0, max(max(float(t.rad()) for t in diag), max(float(t.rad()) for t in off))
    for _ in range(80):
        mid = (lo + hi) / 2
        if psd(mid): lo = mid
        else: hi = mid
    mrad = max(max(float(t.rad()) for t in diag), max(float(t.rad()) for t in off))
    return True, lower(lo), mrad

FROZEN = {(1, +1): 5.5e-3, (1, -1): 6.875e-4, (4, +1): 5.0e-5, (4, -1): 4.0e-4}
print(f"prec {ctx.prec}; quantile ball radius {float(RHO_GAMMA.rad()):.1e} (both ladders)\n")
for drop in [4, 1]:                       # tightest margin (drop-4) first — the acid test
    t0 = time.time()
    xsD = [gamma_ball(gD_c[n]) ** -2 for n in range(drop, 149)]
    xsF = [gamma_ball(gF_c[n]) ** -2 for n in range(drop, 149)]
    xrad = max(max(float(t.rad()) for t in xsD), max(float(t.rad()) for t in xsF))
    alD, beD = ball_lanczos(xsD)
    alF, beF = ball_lanczos(xsF)
    aradD = max(max(float(t.rad()) for t in alD), max(float(t.rad()) for t in beD))
    a = arb(3) / 10                        # 0.3 exact
    b = arb(11) / 1000 if drop == 1 else arb(1) / 10000
    print(f"drop-{drop}: M={len(xsD)}; atom-ball rad <= {xrad:.2e} -> "
          f"Jacobi(alpha,beta)-ball rad <= {aradD:.2e}  ({time.time()-t0:.0f}s)")
    for sgn, tag in [(+1, "aJ_D+bI-V"), (-1, "aJ_D+bI+V")]:
        diag = [(a + sgn) * alD[j] - sgn * alF[j] + b for j in range(len(alD))]
        off = [(a + sgn) * beD[j] - sgn * beF[j] for j in range(len(beD))]
        ok, marg, mrad = ball_chol_margin(diag, off)
        fz = FROZEN[(drop, sgn)]
        print(f"   {tag}: PSD-for-true-quantiles {'CERTIFIED' if ok else 'FAILED'}; "
              f"ball margin >= {marg:.3e}  (frozen-center margin {fz:.1e}; "
              f"pencil-entry rad <= {mrad:.1e})")
    print()
print("done.")
