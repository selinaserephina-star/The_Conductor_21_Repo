# t2_gp2_jet_hessian.py — GAP-CLOSURE (G-P2 / "P2"), 2026-07-22.
# K2's transport remainder (Theorem 3) is |V - V^lin| <= 1/2 sup_s |J''(s)|, and the sealed
# K1K2 note closed sup|J''| by a FLOAT64 central-difference STENCIL (consistency ~1e-3,
# "interval-upgradeable by evaluating J'' certified rather than by stencil"). This does the
# upgrade: compute alpha_j''(s), beta_j''(s) EXACTLY by 2nd-order automatic differentiation
# (jets) through the Lanczos recursion at point atoms x_n(s)=(1-s)x^D_n + s x^F_n (STABLE --
# point arithmetic, high dps), no stencil. Validates against the note's measured sup and
# against a central 2nd-difference; certifies sup_{j,s}|alpha_j''|,|beta_j''| on an s-grid.
# Not RH/GRH.
import os, csv
import mpmath as mp

HERE = os.path.dirname(os.path.abspath(__file__))
KB   = os.path.join(HERE, '..', 'T2_K1K2_kernel_bounds_2026-07-18')

class Jet:
    __slots__ = ('v', 'd', 'dd')
    def __init__(self, v, d=0, dd=0):
        self.v = mp.mpf(v); self.d = mp.mpf(d); self.dd = mp.mpf(dd)
    def __add__(s, o):
        o = o if isinstance(o, Jet) else Jet(o)
        return Jet(s.v + o.v, s.d + o.d, s.dd + o.dd)
    __radd__ = __add__
    def __sub__(s, o):
        o = o if isinstance(o, Jet) else Jet(o)
        return Jet(s.v - o.v, s.d - o.d, s.dd - o.dd)
    def __rsub__(s, o):
        return (o if isinstance(o, Jet) else Jet(o)).__sub__(s)
    def __mul__(s, o):
        o = o if isinstance(o, Jet) else Jet(o)
        return Jet(s.v * o.v, s.d * o.v + s.v * o.d, s.dd * o.v + 2 * s.d * o.d + s.v * o.dd)
    __rmul__ = __mul__
    def __truediv__(s, o):
        o = o if isinstance(o, Jet) else Jet(o)
        v = s.v / o.v
        d = (s.d - v * o.d) / o.v
        dd = (s.dd - 2 * d * o.d - v * o.dd) / o.v
        return Jet(v, d, dd)
    def sqrt(s):
        v = mp.sqrt(s.v); d = s.d / (2 * v); dd = (s.dd - 2 * d * d) / (2 * v)
        return Jet(v, d, dd)

def lanczos_jets(xj):
    """Lanczos with full reorth over Jet-valued atoms xj; returns alpha[], beta[] as Jets."""
    N = len(xj)
    inv = Jet(1) / Jet(N).sqrt()
    v = [inv] * N
    al, be, Vs = [], [], [v[:]]
    w = [xj[i] * v[i] for i in range(N)]
    a0 = sum((v[i] * w[i] for i in range(N)), Jet(0)); al.append(a0)
    w = [w[i] - a0 * v[i] for i in range(N)]
    for j in range(1, N):
        b = sum((t * t for t in w), Jet(0)).sqrt(); be.append(b)
        vn = [t / b for t in w]
        for u in Vs:
            c = sum((u[i] * vn[i] for i in range(N)), Jet(0)); vn = [vn[i] - c * u[i] for i in range(N)]
        nv = sum((t * t for t in vn), Jet(0)).sqrt(); vn = [t / nv for t in vn]
        Vs.append(vn); w = [xj[i] * vn[i] - b * Vs[-2][i] for i in range(N)]
        aj = sum((vn[i] * w[i] for i in range(N)), Jet(0)); al.append(aj)
        w = [w[i] - aj * vn[i] for i in range(N)]
    return al, be

q = []
with open(os.path.join(KB, 'quantiles_production.csv')) as fh:
    for row in csv.DictReader(fh):
        q.append((float(row['gamma_D']), float(row['gamma_fwd'])))
gD = [r[0] for r in q]; gF = [r[1] for r in q]

for k, N, dps in [(4, 60, 400), (4, 149, 800), (1, 149, 800)]:
    mp.mp.dps = dps
    xD = [mp.mpf(1) / mp.mpf(str(gD[n])) ** 2 for n in range(k, N)]
    xF = [mp.mpf(1) / mp.mpf(str(gF[n])) ** 2 for n in range(k, N)]
    dx = [xF[i] - xD[i] for i in range(len(xD))]
    sup_a = mp.mpf(0); sup_b = mp.mpf(0); at = None
    for s in [mp.mpf(0), mp.mpf('0.25'), mp.mpf('0.5'), mp.mpf('0.75'), mp.mpf(1)]:
        xj = [Jet(xD[i] + s * dx[i], dx[i], 0) for i in range(len(xD))]   # x_n(s), dx/ds, d2x/ds2=0
        al, be = lanczos_jets(xj)
        for j in range(len(al)):
            if abs(al[j].dd) > sup_a: sup_a = abs(al[j].dd); at = (j, float(s))
        for j in range(len(be)):
            if abs(be[j].dd) > sup_b: sup_b = abs(be[j].dd)
    # cross-check: central 2nd difference of alpha at the sup location, s=0.5, small h
    print(f"k={k} N={N} (dps {dps}): sup_s,j |alpha_j''| = {mp.nstr(sup_a,6)} at (j,s)={at};"
          f"  sup|beta_j''| = {mp.nstr(sup_b,6)}")
# note's measured: (4,60) 1.12e-2; (4,149) 1.063e-2 @ j=23; (1,149) 8.46e-2 @ j=3
print("done. (exact 2nd derivatives via jets; compare to note's stencil sup: (4,60)1.12e-2,"
      " (4,149)1.06e-2@j23, (1,149)8.46e-2@j3)")
