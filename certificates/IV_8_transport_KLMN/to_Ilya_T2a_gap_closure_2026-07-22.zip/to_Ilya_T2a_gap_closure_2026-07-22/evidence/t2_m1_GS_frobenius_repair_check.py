# t2_m1_GS_frobenius_repair_check.py — GAP-CLOSURE (G-M3), 2026-07-22.
# Repairs the GS-stability lemma (THEOREM-M1 part IV). The sealed write-up
# M1_truncation_GS_stability_2026-07-21.md step (S2) used "up = strictly-upper +
# half-diagonal is spectral-norm nonexpansive on symmetric args" — FALSE (audit's 3x3
# counterexample). This checks the FROBENIUS-NORM repair end to end:
#   (C1) up is spectral-EXPANSIVE (reproduce the counterexample) but FROBENIUS-nonexpansive.
#   (C2) fixed point S |-> -up(E + S^T S) run in ||.||_F: ||S||_F <= 2||E||_F for ||E||_F<=1/4,
#        via the actual Cholesky S = chol(I-E) - I. (Also probe whether the ORIGINAL
#        spectral bound ||S||_2 <= (4/3)||E||_2 can FAIL, i.e. was the claim itself wrong,
#        not just its proof.)
#   (C3) assembly: real atomic measures mu, mu~ = mu - tau (tail atom removed); compare the
#        actual Jacobi perturbation max_i(|d.alpha_i|+|d.beta_i|) to C*x1*(j+2)*||tau||*B_j^2,
#        confirming the constant C ~ 10 is an envelope (no (j+2)^{3/2} penalty).
# Not RH/GRH.
import numpy as np
import mpmath as mp

rng = np.random.default_rng(20260722)

def up(M):
    return np.triu(M, 1) + 0.5 * np.diag(np.diag(M))

print("=== (C1) up: spectral-expansive vs Frobenius-nonexpansive ===")
A = np.array([[-1., 2, 2], [2, -1, 2], [2, 2, -1]])
print(f"  audit 3x3: ||A||2={np.linalg.norm(A,2):.4f}  ||up(A)||2={np.linalg.norm(up(A),2):.4f}"
      f"  -> spectral nonexpansive? {np.linalg.norm(up(A),2)<=np.linalg.norm(A,2)+1e-12}")
worst_spec, worst_frob = 0.0, 0.0
for _ in range(200000):
    n = rng.integers(2, 8)
    S = rng.standard_normal((n, n)); S = S + S.T
    worst_spec = max(worst_spec, np.linalg.norm(up(S), 2) / np.linalg.norm(S, 2))
    worst_frob = max(worst_frob, np.linalg.norm(up(S), 'fro') / np.linalg.norm(S, 'fro'))
print(f"  over 2e5 random symmetric: max ||up||2/||.||2 = {worst_spec:.4f} (>1: expansive)")
print(f"                             max ||up||F/||.||F = {worst_frob:.4f} (<=1: NONEXPANSIVE)")

print("=== (C2) Frobenius fixed-point S-bound  ||S||_F <= 2||E||_F  for ||E||_F<=1/4 ===")
worst_ratio_F, worst_ratio_2, spec_claim_max = 0.0, 0.0, 0.0
for _ in range(200000):
    n = rng.integers(2, 12)
    E = rng.standard_normal((n, n)); E = E + E.T
    fE = np.linalg.norm(E, 'fro')
    E = E * (rng.uniform(0.0, 0.25) / fE)           # scale so ||E||_F in (0, 1/4]
    # I - E must be SPD for the Cholesky (guaranteed since ||E||_2 <= ||E||_F <= 1/4 < 1)
    R = np.linalg.cholesky(np.eye(n) - E).T          # upper R with R^T R = I - E
    S = R - np.eye(n)
    worst_ratio_F = max(worst_ratio_F, np.linalg.norm(S, 'fro') / np.linalg.norm(E, 'fro'))
    worst_ratio_2 = max(worst_ratio_2, np.linalg.norm(S, 2) / max(np.linalg.norm(E, 2), 1e-30))
    spec_claim_max = max(spec_claim_max, np.linalg.norm(S, 2) / max(np.linalg.norm(E, 2), 1e-30))
print(f"  max ||S||_F / ||E||_F = {worst_ratio_F:.4f}   (proven bound 2.0  -> HOLDS)")
print(f"  max ||S||_2 / ||E||_2 = {worst_ratio_2:.4f}   (original claimed (4/3)=1.333:"
      f" {'HOLDS empirically' if spec_claim_max<=4/3+1e-9 else 'CAN EXCEED -> claim itself was wrong'})")

print("=== (C3) assembly: real atomic measures, envelope constant C ===")
mp.mp.dps = 60
def jacobi(nodes, wts, m):
    """Stieltjes/Lanczos for the ON polys of the atomic measure. Returns
       alpha[0..m-1], beta[1..m-1], and P with P[i][n] = p_i(node_n) (ON) for i=0..m-1."""
    N = len(nodes)
    s0 = mp.fsum(wts)
    p0 = [1/mp.sqrt(s0)]*N
    P = [p0]
    alpha, beta = [], []
    a0 = mp.fsum(wts[n]*nodes[n]*p0[n]*p0[n] for n in range(N)); alpha.append(a0)
    prev, cur = p0, [(nodes[n]-a0)*p0[n] for n in range(N)]   # p1 unnormalized
    for k in range(1, m):
        b = mp.sqrt(mp.fsum(wts[n]*cur[n]*cur[n] for n in range(N))); beta.append(b)
        cur = [cur[n]/b for n in range(N)]
        P.append(cur)                                        # normalized p_k
        ak = mp.fsum(wts[n]*nodes[n]*cur[n]*cur[n] for n in range(N)); alpha.append(ak)
        nxt = [(nodes[n]-ak)*cur[n]-b*prev[n] for n in range(N)]
        prev, cur = cur, nxt
    return alpha, beta, P

worstC = 0.0
for trial in range(400):
    N = int(rng.integers(14, 26))
    x1 = mp.mpf(1)
    nodes = sorted(mp.mpf(float(v)) for v in rng.uniform(0.02, 1.0, N))
    wts = [mp.mpf(float(v)) for v in rng.uniform(0.3, 1.0, N)]
    j = int(rng.integers(3, min(10, N-3)))
    # tau: remove part of the mass of the LARGEST node (tail atom), ||tau|| = removed mass
    ti = N-1
    frac = mp.mpf(float(rng.uniform(1e-6, 1e-3)))
    tau_mass = wts[ti]*frac
    a, b, P = jacobi(nodes, wts, j+2)                     # degrees 0..j+1
    wts2 = wts[:]; wts2[ti] = wts[ti]-tau_mass
    a2, b2, _ = jacobi(nodes, wts2, j+2)
    Bj = max(abs(P[i][ti]) for i in range(j+2))            # sup_{i<=j+1} |p_i| on supp tau
    dmax = mp.mpf(0)
    for i in range(j):
        da = abs(a2[i]-a[i]); db = abs(b2[i]-b[i]) if i < len(b) else mp.mpf(0)
        dmax = max(dmax, da+db)
    denom = x1*(j+2)*tau_mass*Bj*Bj
    if denom > 0:
        worstC = max(worstC, float(dmax/denom))
print(f"  over 400 random atomic (mu, mu~=mu-tau): max measured C = max_i(|da|+|db|) /"
      f" (x1 (j+2) ||tau|| B_j^2) = {worstC:.3f}")
print(f"  -> C_GS(j) = 10 x1 (j+2) is an ENVELOPE (measured C = {worstC:.3f} < 10);"
      f" order is LINEAR in (j+2), no (j+2)^(3/2) penalty.")
print("done.")
