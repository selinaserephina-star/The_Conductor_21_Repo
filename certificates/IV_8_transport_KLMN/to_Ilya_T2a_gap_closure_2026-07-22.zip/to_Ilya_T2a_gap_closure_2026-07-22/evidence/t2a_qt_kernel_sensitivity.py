# t2a_qt_kernel_sensitivity.py — GAP-CLOSURE (T2a-QT), 2026-07-22, route 2.
# The direct route (t2a_true_quantile_transfer.py) is UNSTABLE: putting the 1e-10 atom
# balls through Lanczos makes the interval dependency problem blow the radii to inf in
# ~1s (reorthogonalization subtracts near-equal balls). That is an artifact of interval
# arithmetic, not a real failure — the true atom->Jacobi sensitivity is mild (kappa-hat
# ~ 5.6). So we bound ||Delta J|| the STABLE way:
#   (R1) the Theorem-1 alpha-kernel K_j(n) = d alpha_{j+1}/d x_n, built at ball grade at
#        the EXACT centers (stable, radii ~0 — same computation as t2a_khat_enclosure.py),
#        gives the rigorous FIRST-ORDER bound |Delta alpha_{j+1}| <= sum_n |K_j(n)| r_x(n),
#        r_x(n) = atom-ball radius from the 1e-10 quantile enclosure (x = gamma^-2).
#   (R2) an independent STABLE high-precision POINT finite-difference (dps 60) of the FULL
#        pencil in the worst uniform direction, to capture BOTH alpha and beta sensitivity
#        and cross-check (R1). Point arithmetic is stable; only INTERVAL Lanczos was not.
# Compare max ||Delta J||_inf to the certified frozen-center margins. Not RH/GRH.
import os, time
import numpy as np
import mpmath as mp
from flint import arb, ctx

HERE = os.path.dirname(os.path.abspath(__file__))
KB   = os.path.join(HERE, '..', 'T2_K1K2_kernel_bounds_2026-07-18')
RHOG = 1e-10                      # certified quantile enclosure radius (theta-module)
q = np.loadtxt(os.path.join(KB, 'quantiles_production.csv'), delimiter=",", skiprows=1)
gD_c, gF_c = q[:, 1], q[:, 2]
FROZEN = {(1, +1): 5.5e-3, (1, -1): 6.875e-4, (4, +1): 5.0e-5, (4, -1): 4.0e-4}

# ---------- (R1) ball kernels at centers -> rigorous first-order alpha-sensitivity ----------
ctx.prec = 4096
def ball_alpha_kernel_L1_and_shift(centers):
    """returns per-j S_j = sum_n |K_j(n)| r_x(n)  (arb upper bounds), the certified
       first-order bound on |d alpha_j|, for j=2..M (K_1 = w exact -> 0 sensitivity)."""
    xs = [arb(float(c)) ** -2 for c in centers]                 # exact-center atoms (stable)
    rx = [2 * arb(float(c)) ** -3 * arb(RHOG) for c in centers] # |dx_n| <= 2 c^-3 rho  (>0 ball)
    M = len(xs)
    inv = arb(1) / arb(M).sqrt(); v = [inv] * M
    al, be, Vs = [], [], [v[:]]
    w = [xs[i] * v[i] for i in range(M)]
    a0 = sum((v[i] * w[i] for i in range(M)), arb(0)); al.append(a0)
    w = [w[i] - a0 * v[i] for i in range(M)]
    for j in range(1, M):
        b = sum((t * t for t in w), arb(0)).sqrt(); be.append(b)
        vn = [t / b for t in w]
        for u in Vs:
            cc = sum((u[i] * vn[i] for i in range(M)), arb(0)); vn = [vn[i] - cc * u[i] for i in range(M)]
        nv = sum((t * t for t in vn), arb(0)).sqrt(); vn = [t / nv for t in vn]
        Vs.append(vn); w = [xs[i] * vn[i] - b * Vs[-2][i] for i in range(M)]
        aj = sum((vn[i] * w[i] for i in range(M)), arb(0)); al.append(aj)
        w = [w[i] - aj * vn[i] for i in range(M)]
    sqM = arb(M).sqrt()
    Pv = [[Vs[j][n] * sqM for n in range(M)] for j in range(M)]
    Dv = [[arb(0)] * M, [arb(1) / be[0]] * M]
    for j in range(1, M - 1):
        Dv.append([(Pv[j][n] + (xs[n] - al[j]) * Dv[j][n] - be[j - 1] * Dv[j - 1][n]) / be[j] for n in range(M)])
    wgt = arb(1) / M
    S = {}
    for j in range(1, M - 1):        # K_{j+1}(n) = wgt[be_j (p_j p_{j+1})' - be_{j-1}(p_{j-1}p_j)'](x_n)
        acc = arb(0)
        for n in range(M):
            t1 = be[j] * (Dv[j][n] * Pv[j + 1][n] + Pv[j][n] * Dv[j + 1][n])
            t0_ = be[j - 1] * (Dv[j - 1][n] * Pv[j][n] + Pv[j - 1][n] * Dv[j][n])
            Kjn = wgt * (t1 - t0_)
            acc = acc + abs(Kjn) * rx[n]        # sum_n |K_j(n)| |dx_n|
        S[j + 1] = acc
    maxrx = max(float(r.mid()) + float(r.rad()) for r in rx)
    return S, maxrx

# ---------- (R2) stable high-precision point FD of the full pencil ----------
mp.mp.dps = 60
def mp_lanczos(xs):
    N = len(xs); v = [mp.mpf(1) / mp.sqrt(N)] * N
    al, be, Vs = [], [], [v[:]]
    w = [xs[i] * v[i] for i in range(N)]
    a0 = mp.fsum(v[i] * w[i] for i in range(N)); al.append(a0); w = [w[i] - a0 * v[i] for i in range(N)]
    for j in range(1, N):
        b = mp.sqrt(mp.fsum(t * t for t in w)); be.append(b); vn = [t / b for t in w]
        for u in Vs:
            c = mp.fsum(u[i] * vn[i] for i in range(N)); vn = [vn[i] - c * u[i] for i in range(N)]
        nv = mp.sqrt(mp.fsum(t * t for t in vn)); vn = [t / nv for t in vn]
        Vs.append(vn); w = [xs[i] * vn[i] - b * Vs[-2][i] for i in range(N)]
        aj = mp.fsum(vn[i] * w[i] for i in range(N)); al.append(aj); w = [w[i] - aj * vn[i] for i in range(N)]
    return al, be
def pencil_entries(gD, gF, drop, a, b, sgn):
    xsD = [1 / g ** 2 for g in gD[drop:]]; xsF = [1 / g ** 2 for g in gF[drop:]]
    aD, bD = mp_lanczos(xsD); aF, bF = mp_lanczos(xsF); M = len(xsD)
    diag = [(a + sgn) * aD[j] - sgn * aF[j] + b for j in range(M)]
    off = [(a + sgn) * bD[j] - sgn * bF[j] for j in range(M - 1)]
    return diag, off

print(f"quantile enclosure radius rho = {RHOG:.0e} (both ladders); frozen margins in table\n")
for drop in [4, 1]:
    t0 = time.time()
    Sa, maxrx = ball_alpha_kernel_L1_and_shift(gD_c[drop:])
    da_max = max(float(s.mid()) + float(s.rad()) for s in Sa.values())     # rigorous max|d alpha_j| (D)
    # F ladder alpha-sensitivity too
    SaF, _ = ball_alpha_kernel_L1_and_shift(gF_c[drop:])
    daF_max = max(float(s.mid()) + float(s.rad()) for s in SaF.values())
    print(f"drop-{drop}: (R1) max atom-shift r_x <= {maxrx:.2e};  rigorous max|d.alpha_j|: "
          f"D <= {da_max:.2e}, F <= {daF_max:.2e}   ({time.time()-t0:.0f}s)")
    # (R2) point FD of full pencil, worst uniform +/- direction (captures alpha AND beta)
    a = mp.mpf('0.3'); b = mp.mpf('0.011') if drop == 1 else mp.mpf('0.0001')
    gDp = [g + mp.mpf(RHOG) for g in gD_c]; gDm = [g - mp.mpf(RHOG) for g in gD_c]
    gFp = [g + mp.mpf(RHOG) for g in gF_c]; gFm = [g - mp.mpf(RHOG) for g in gF_c]
    for sgn, tag in [(+1, "aJ_D+bI-V"), (-1, "aJ_D+bI+V")]:
        d0, o0 = pencil_entries([mp.mpf(x) for x in gD_c], [mp.mpf(x) for x in gF_c], drop, a, b, sgn)
        best = 0.0
        for gD2, gF2 in [(gDp, gFp), (gDm, gFm), (gDp, gFm), (gDm, gFp)]:
            d1, o1 = pencil_entries(gD2, gF2, drop, a, b, sgn)
            dJ = max(max(abs(float(d1[j] - d0[j])) for j in range(len(d0))),
                     max(abs(float(o1[j] - o0[j])) for j in range(len(o0))))
            best = max(best, dJ)
        fz = FROZEN[(drop, sgn)]
        verdict = "PSD SURVIVES" if best < fz else "MARGIN EATEN"
        print(f"   {tag}: point-FD ||dJ||_inf(worst uniform) <= {best:.2e}  vs margin {fz:.1e}"
              f"  -> {verdict} (headroom {fz/best:.0f}x)")
    print()
print("done.")
