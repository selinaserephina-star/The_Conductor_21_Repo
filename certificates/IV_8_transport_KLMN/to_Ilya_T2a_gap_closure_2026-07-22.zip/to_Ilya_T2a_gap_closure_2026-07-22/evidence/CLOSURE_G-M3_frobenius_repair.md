# CLOSURE — G-M3 / THEOREM-M1 part IV: the GS-stability constant, Frobenius repair

**Merkabit · Stenberg + Claude · 2026-07-22.** Closes the audit's one substantive
re-open (`INDEPENDENT_AUDIT_received_2026-07-22/`, `G_M3_EXPLICIT_CONSTANT_6 =
PROOF_GAP`). Repairs step (S2)–(S3) of the sealed write-up
`M1_truncation_GS_stability_2026-07-21.md` (FROZEN; re-derived here, seal untouched).
Verified in `t2_m1_GS_frobenius_repair_check.py` (+ run log). Not RH/GRH.

## What was wrong
The sealed proof ran the Cholesky/GS fixed point `S ↦ −up(E + SᵀS)` in **spectral
norm**, asserting `up` (strictly-upper + half-diagonal) is spectral-norm nonexpansive
on symmetric arguments. **False** — audit counterexample
`A=[[-1,2,2],[2,-1,2],[2,2,-1]]` has `‖A‖₂=3`, `‖up(A)‖₂≈3.169` (reproduced; over 2×10⁵
random symmetric matrices `up` reaches ratio 1.055 > 1). So the S-bound `‖S‖₂ ≤
(4/3)‖E‖₂` and the constant `C_GS(j)=6x₁(j+2)` were **not certified** by that proof.

*(Note — the RESULT was not false, only the proof: empirically `‖S‖₂/‖E‖₂` maxes at
1.073 < 4/3 over the same random sweep. The repair below gives a valid proof of a
statement of the same order.)*

## The repair — run the fixed point in the Frobenius norm
`up` **is** Frobenius-nonexpansive on symmetric `M`: with `‖M‖_F² = Σ_i m_ii² +
2Σ_{i<k} m_ik²`,
```
‖up(M)‖_F² = Σ_{i<k} m_ik² + ¼ Σ_i m_ii²  ≤  2Σ_{i<k} m_ik² + Σ_i m_ii² = ‖M‖_F².
```
(Verified: ratio ≤ 0.7071 over 2×10⁵ random symmetric.) Triangular and tridiagonal
(band) projections `up`, `tri` are likewise `‖·‖_F`-nonexpansive — they only delete or
halve entries.

**(S2′) Fixed point.** `T(S) = −up(E+SᵀS)`. Using `‖AB‖_F ≤ ‖A‖₂‖B‖_F` and `‖S‖₂ ≤
‖S‖_F`:
- **Self-map** on `{‖S‖_F ≤ 2‖E‖_F}`: `‖T(S)‖_F ≤ ‖E+SᵀS‖_F ≤ ‖E‖_F + ‖S‖_F² ≤
  ‖E‖_F + 4‖E‖_F² ≤ 2‖E‖_F` whenever `‖E‖_F ≤ ¼`.
- **Contraction**: `‖T(S)−T(S′)‖_F ≤ ‖SᵀS − S′ᵀS′‖_F ≤ (‖S‖₂+‖S′‖₂)‖S−S′‖_F ≤
  4‖E‖_F·‖S−S′‖_F`, factor `< 1` for `‖E‖_F < ¼`.

Banach ⇒ unique `S` with **`‖S‖_F ≤ 2‖E‖_F`** (measured max 0.74·‖E‖_F). Hence for
`G := R⁻¹−I = −S+S²−…`, `‖G‖_F ≤ ‖S‖_F/(1−‖S‖₂) ≤ 2‖E‖_F/(1−½) = 4‖E‖_F`.

**(S3′) Assembly.** `J̃ − J = tri(Δ)`, `Δ = R⁻ᵀ(X−F)R⁻¹ − X = −F + GᵀX + XG + GᵀXG −
FG − GᵀF − GᵀFG`. Since `tri` is `‖·‖_F`-nonexpansive and `‖J̃−J‖₂ ≤ ‖J̃−J‖_F`,
with `‖X‖₂ ≤ x₁`, `‖G‖_F ≤ 4‖E‖_F`, `‖G‖₂ ≤ 4‖E‖_F`:
```
‖J̃−J‖₂ ≤ ‖Δ‖_F ≤ ‖F‖_F + 8x₁‖E‖_F + (24x₁‖E‖_F² + 16x₁‖E‖_F³).
```
**The key point (why there is no √(j+2) penalty):** the entrywise bound `|E_ik| ≤
‖τ‖B_j²` gives `‖E‖_F ≤ (j+2)‖τ‖B_j²` **directly** — the same order the sealed proof
used for `‖E‖_op`. Set `ε := (j+2)‖τ‖B_j²` (so `‖E‖_F ≤ ε`, `‖F‖_F ≤ x₁ε`). Then for
`ε ≤ ¼`,
```
‖J̃−J‖₂ ≤ 9x₁ε + 24x₁ε² + 16x₁ε³ ≤ 16·x₁·(j+2)·‖τ‖·B_j²  =: C_GS(j)·‖τ‖·B_j²,
```
with leading constant 9 (the ε², ε³ terms are ≤ 7x₁ε at ε ≤ ¼). Entrywise
`|Δα_i|,|Δβ_i| ≤ ‖J̃−J‖₂`. ∎

## Result
- **`C_GS(j) = 16·x₁·(j+2)`** (leading constant 9), valid whenever
  `(j+2)‖τ‖B_j² ≤ ¼`. **Linear in (j+2)** — same order as the original claim; the proof
  is now valid.
- Measured envelope over 400 random atomic `(μ, μ̃=μ−τ)`:
  `max_i(|Δα_i|+|Δβ_i|)/(x₁(j+2)‖τ‖B_j²) = 0.065` — ~140× headroom under the proven 9.
- **Rates unchanged:** ODD `‖τ_N‖=1/(3π⁴N³)` and companion `‖τ_M‖=2/(π²M)` still give
  the N⁻³ and N⁻¹ tail-mass laws (the ‖τ‖·B_j² structure was never touched). The
  side-condition `ε ≤ ¼` holds comfortably in the ODD instantiation over the lemma
  range (e.g. `(j+2)B² ~ 10⁶`, `‖τ‖ ~ 1/(3π⁴N³)` ⇒ `ε ~ 5×10⁻³` at N~100).

## Grade
`G_M3_EXPLICIT_CONSTANT`: **PROOF_GAP → PROVEN** (Frobenius route; explicit constant
16·x₁·(j+2), leading 9). THEOREM-M1 part IV re-closed at PROVEN grade. Parts (I)–(III)
(bordered identity, odd-Lambert block, Bessel endpoint-sum identity + fixed-j tail
rate) were never affected. The only unresolved M-lane item is the separate
M1-HORIZON (3.2√N uniform-in-j) — still MEASURED.
