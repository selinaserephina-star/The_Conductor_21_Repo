# ghrot_reduction_check.py — GAP-CLOSURE (G-HROT explicit constant), 2026-07-22.
# Goal: a rigorous explicit ceiling on the atom->Jacobi sensitivity (the G-HROT lemma),
# which upgrades T2a-QT to full CERTIFIED. Strategy: the RIGOROUS REDUCTION
#     ||J' - J||_2 <= max_n|x'_n - x_n| + 2 x_max ||U - U'||_2,
# where J = U diag(x) U^T (U = eigenvector matrix, columns phi_n with fixed first
# component sqrt(w_n)). Derivation: J-J' = U diag(x-x') U^T + [U diag(x') U^T -
# U' diag(x') U'^T]; first term has norm max|x-x'|; second = (U-U')diag(x')U^T +
# U'diag(x')(U-U')^T, norm <= 2 x_max ||U-U'||.  This reduces G-HROT to the ON-frame
# rotation ||U-U'||. Here we (a) VERIFY the reduction numerically and (b) measure the
# frame-rotation constant ||U-U'||/eps to see if the rigorous ceiling is in reach.
# Not RH/GRH.
import os
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
KB   = os.path.join(HERE, '..', 'T2_K1K2_kernel_bounds_2026-07-18')
q = np.loadtxt(os.path.join(KB, 'quantiles_production.csv'), delimiter=",", skiprows=1)

def jacobi_from_atoms(x, w):
    """Jacobi matrix (tridiagonal) of the atomic measure sum w_n delta_{x_n}, via
       stable symmetric Lanczos in float64 (the matrix is well-conditioned even though
       the polynomial basis is not)."""
    N = len(x)
    v = np.sqrt(w); v = v / np.linalg.norm(v)
    al, be, V = [], [], [v.copy()]
    w0 = x * v
    a0 = v @ w0; al.append(a0); w0 = w0 - a0 * v
    for j in range(1, N):
        b = np.linalg.norm(w0); be.append(b)
        vn = w0 / b
        for u in V:                      # full reorth (float64)
            vn = vn - (u @ vn) * u
        vn = vn / np.linalg.norm(vn)
        V.append(vn)
        w0 = x * vn - b * V[-2]
        aj = vn @ w0; al.append(aj); w0 = w0 - aj * vn
    J = np.diag(al) + np.diag(be, 1) + np.diag(be, -1)
    return J

def frame(J):
    """eigenvalues (sorted) and eigenvector matrix with columns sign-fixed so the first
       component is >= 0 (matches the fixed norming-constant sqrt(w_n) > 0)."""
    x, U = np.linalg.eigh(J)
    for n in range(U.shape[1]):
        if U[0, n] < 0: U[:, n] = -U[:, n]
    return x, U

for drop in [4, 1]:
    gD = q[drop:, 1]
    N = len(gD)
    w = np.ones(N) / N
    x = gD.astype(float) ** -2
    x_max = x.max()
    J = jacobi_from_atoms(x, w)
    _, U = frame(J)
    print(f"\ndrop-{drop}: N={N}, x_max={x_max:.4e}")
    for label, mk in [("uniform +", lambda e: np.full(N, e)),
                      ("random +/-", lambda e: e * np.random.default_rng(1).choice([-1.,1.], N)),
                      ("random2", lambda e: e * np.random.default_rng(7).choice([-1.,1.], N))]:
        eps = 1e-6
        dg = mk(eps)
        gD2 = gD + dg
        x2 = gD2.astype(float) ** -2
        J2 = jacobi_from_atoms(x2, w)
        _, U2 = frame(J2)
        dJ = np.linalg.norm(J2 - J, 2)
        # atom shift in x-units and the reduction RHS
        eps_x = np.abs(x2 - x).max()
        dU = np.linalg.norm(U - U2, 2)
        rhs = eps_x + 2 * x_max * dU
        ok = "OK" if dJ <= rhs * (1 + 1e-6) else "VIOLATED"
        print(f"   {label:11s} eps_g={eps:.0e}: ||dJ||={dJ:.3e}  RHS(reduction)={rhs:.3e}"
              f"  [{ok}]  ||U-U'||/eps_x={dU/eps_x:.2f}  ->  ||dJ||/eps_x={dJ/eps_x:.2f}")
print("\ndone.")
