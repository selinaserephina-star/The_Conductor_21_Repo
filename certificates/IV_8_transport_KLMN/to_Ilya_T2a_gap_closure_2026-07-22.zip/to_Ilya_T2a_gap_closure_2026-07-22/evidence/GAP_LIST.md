# T2 GAP-CLOSURE LIST — what remains, and where the material already lives

**Merkabit · Stenberg + Claude · opened 2026-07-22.** Continuation folder for the
sealed T2a / THEOREM-M1 packages (those are FROZEN; work lands HERE). Trigger: IB's
independent audit `INDEPENDENT_AUDIT_received_2026-07-22/` re-opened one substantive
tag and flagged four polish items. This list widens that to the full live T2/T2a/M1
gap set from `LEDGER/EVIDENCE_CHAIN_T2_pin.md` §§3,7. Working hypothesis (Selina):
*the closing material is already in the repo* — so each item names its source and a
grade target, not new research. **Not RH/GRH.**

Discipline: one row per gap; flip its status here AND in the ledger when closed; cite
the script/note that closes it; frozen packages stay untouched (corrections = new
dated notes in THIS folder).

Status key: `OPEN` · `IN-PROGRESS` · `CLOSED` · `IB-LANE` (offerable to Ilya).

---

## Tier 1 — the audit's substantive re-open (do first)

### G-M3 · GS-stability constant (THEOREM-M1 part IV) — `CLOSED 2026-07-22`
- **CLOSED:** Frobenius-route repair (`t2_m1_GS_frobenius_repair_check.py`, note
  `CLOSURE_G-M3_frobenius_repair.md`). `up` IS ‖·‖_F-nonexpansive → fixed point re-run
  in Frobenius, giving **`C_GS(j)=16·x₁·(j+2)`** (leading constant 9). **Correction to
  the earlier estimate in this file:** the entrywise bound gives `‖E‖_F ≤ (j+2)‖τ‖B²`
  *directly*, so there is **NO √(j+2) penalty** — order stays LINEAR in (j+2) (not
  ^{3/2}), constant 6→~16. Rates unchanged; measured envelope 0.065 (~140× headroom).
  Bonus: the original spectral bound holds empirically (1.073 < 4/3) — the theorem was
  true, only its proof was broken. Grade PROOF_GAP → PROVEN.

---

## Tier 2 — T2a certificate polish (audit findings 2–4)

### T2a-QT · true-quantile sensitivity transfer — `CLOSED 2026-07-22 (CERTIFIED-as-computed)`
- **CLOSED** via the certified-κ̂ Abel assembly (`t2a_qt_abel_certificate.py`, note
  `CLOSURE_T2a_QT_abel.md`), using era-2 Theorems 1–2 (PROVEN) found in the folder search.
  Abel summation against the partial-sum bound κ̂ (Theorem 2) beats the e^{cj} ℓ1:
  ‖ΔJ‖∞ ≤ (κ̂^α+2κ̂^β)(TV(Δx)+|Δx_M|). κ̂ certified at ball grade (κ̂^α(D)=5.5956 — matches
  the T2a-KHAT enclosure exactly), TV(Δx) rigorous from the 1e-10 enclosures, Weyl closes.
- **All four pencils CERTIFIED** (true-quantile KLMN holds): headroom 4,265× (drop-4 −V,
  tightest) to 294,500×. The obstruction (my earlier e^{cj}/hard-lane readings) is fully
  dissolved and withdrawn.
- **Grade:** OPEN → **CERTIFIED-as-computed** (same grade as the sealed T2a cert). Honest
  residual for a fully-PROVEN uniform theorem: the pairing-excess / κ_j growth law is
  CLOSED at THEOREM grade (the caustic theorem G-D2b/F10: κ_j = 1 + a_∞μ^{1/3} + R_j,
  −1.1 ≤ R_j ≤ 0.5, Olver/Airy — NOT open; corrects my earlier "= P1 open" note). The finite-M
  boundary κ̂ is certified numerically here; the 2nd-order term = G-P2 (measured sup|α″| + 2×).

### T2a-KHAT · κ̂ strict interval enclosure — `CLOSED 2026-07-22`
- **CLOSED:** `t2a_khat_enclosure.py` keeps the head-sums in arb end-to-end →
  **κ̂ ∈ [5.59564988046657624 ± 2×10⁻²⁰]** (argmax j=145,k=120; non-overlap margin
  0.102 ≫ radius). Note `CLOSURE_T2a_khat_enclosure.md`. Grade OPEN → CERTIFIED
  (strict enclosure). Ledger item 3.5 caveat resolved.

### T2a-SP · sup|S_P| ≤ 0.901946 via Arb grid — `OPEN`
- **What's missing:** the S_P bound rests on a dense binary64 scan + Lipschitz/float
  budget (useful, not publication-clean). sup|S_P'| ≤ 188.804 already stands on
  interval termwise bounds — fine.
- **Where the fix lives:** replace the float64 scan with an Arb-grid evaluation over
  the same node set (the Lipschitz constant 188.804 already bounds the inter-node gap
  → grid density is known).
- **Source material:** the S_P scan script in `T2a_pencil_certification_2026-07-21/`.
- **Grade target:** CERTIFIED (Arb grid).

---

## Tier 3 — structural / horizon (audit finding 5 + ledger)

### M1-HORIZON · sharp horizon 3.2√N uniform in j — `OPEN (reassess vs caustic machinery)`
- **What's missing:** J(N)=3.2√N and full-horizon g-alternation are MEASURED. The fixed-j
  g-lemma rate k(k+1)/(π²N) → O(1) at j~√N, so the fixed-j closed form degrades at the
  horizon scale — a genuinely uniform-in-j argument is needed.
- **CORRECTION 2026-07-22:** the needed tool — Olver/Airy uniform asymptotics at the
  turning point/caustic — is NOT missing; it was BUILT and used to prove the caustic
  theorem (G-D2b/F10: κ_j = 1 + a_∞μ^{1/3} + R_j). So M1-HORIZON is "reassess against the
  caustic Olver machinery," NOT "hardest of the set / needs a tool we don't have." Caveat:
  the caustic law is the j≥512 asymptotic; the horizon g_j/s²-floor is a related but
  distinct uniform-asymptotic estimate — the machinery transfers, the specific lemma still
  has to be written. (Prior over-pessimism withdrawn.)
- **Grade target:** a uniform-in-j horizon lemma via the caustic/Olver machinery, or honest
  MEASURED with that route flagged.

### G-P2 · second-order kernel identity — `CLOSED (constant) 2026-07-22`
- **CLOSED (K2 constant):** `t2_gp2_jet_hessian_arb.py`, note `CLOSURE_G-P2_jet_hessian.md`.
  K2's transport-remainder constant sup|J″| upgraded from float64-stencil (1e-3) to EXACT
  ball-grade 2nd derivative via jets (all rows radius 0, prec 16000): drop-4 sup|α″|=0.01137
  (j=23), sup|β″|=0.00413; drop-1 sup|α″|=0.09177 (j=3), sup|β″|=0.03586. Max at s=1 endpoint.
  Feeds the T2a-QT 2nd-order term. Offerable residual: continuous-s bridge + the closed-form
  p″ identity.
- **(original)** upgrades K2 from stencil-verified to identity-verified
  (differentiate Theorem 1′ along the transport flow).
- **Source material:** Theorem 1′ + K2 stencil in `T2_K1K2_kernel_bounds_2026-07-18/`.
- **Grade target:** identity-verified (PROVEN+VER).

---

## Tier 4 — IB-lane / offerable (list, don't necessarily close here)

### G-HROT explicit constant (= T2a-QT sensitivity ceiling) — `REDUCED 2026-07-22, not closed`
- **ATTEMPTED 2026-07-22 (`FINDINGS_GHROT_reduction.md`, `ghrot_reduction_check.py`).**
  Proven rigorous reduction: **‖J'−J‖₂ ≤ max_n|Δx_n| + 2·x_max·‖U−U'‖** (U = eigenvector
  matrix, fixed first component √w_n). Reduces the whole T2a-QT ceiling to a rigorous
  ε-Lipschitz bound on the ON-frame rotation ‖U−U'‖ ≤ C'·max_n|Δx_n|.
- **Not closed by elementary means:** Davis–Kahan is circular + vacuous (min atom gap
  ~9e-5 ≪ 2·x_max≈0.47); trivial ‖U−U'‖≤2 doesn't shrink with ε. The ε-Lipschitz property
  holds ONLY because norming constants w_n are fixed = the inverse-spectral / κ̂
  conditioning. Measured C'~O(10¹); need any C'<1.6e6.
- **The uniform statement** (our K1/κ̂ lane — Theorems 1–2 are era-2 ours; NOT pre-assigned
  to IB): prove ‖U−U'‖ ≤ C'·max_n|Δx_n| explicit for the χ8 quantile config. NB: for the
  T2a-QT purpose this is already delivered at config grade by the certified-κ̂ Abel close
  (κ̂ IS the C'); the uniform-in-j κ_j growth law is ALREADY a theorem (caustic theorem
  G-D2b/F10, κ_j = 1 + a_∞μ^{1/3} + R_j via Olver/Airy) — P1 is NOT open (memory index said
  so; I mislabeled it). The only genuinely-uncovered residual is the finite-M boundary-row
  constant, certified numerically here.

### G-HROT / G-E · sharp C≈1.1 (the ORIGINAL rotation-packaging item)
- **What's missing:** (a) the classical u-decay write-up (quantile-class, ρ increasing) and
  (b) certified S scalars (sup|S|=0.862, sup|ΔS|=0.676, ‖S‖*_3=0.6295, measured at
  production spec; certification via G-C1/G-C2).
- **Lane (per ledger item 3.8):** (a) the u-decay write-up is on IB's menu — record it as
  his priority IF he claims it; do not pre-assign. (b) is our T2a S_P cert lane. Numerics
  staged (F11/F12). Shared by default; keep on the offer list.

---

## Working order / progress
1. ✅ **T2a-KHAT** — CLOSED 2026-07-22 (κ̂ strict enclosure).
2. ✅ **G-M3 Frobenius repair** — CLOSED 2026-07-22 (PROVEN, C_GS=16x₁(j+2)).
3. ✅ **T2a-QT** — CLOSED 2026-07-22 (CERTIFIED-as-computed; certified-κ̂ Abel assembly, all
   four pencils, headroom ≥4,265×). Used era-2 Theorems 1–2 found by the folder search.
4. ✅ **G-P2** — CLOSED 2026-07-22 (K2 constant: exact ball-grade 2nd-derivative jets,
   all rows radius 0; stencil → certified). Offerable: continuous-s bridge + p″ identity.
5. ✅ **P1** — was already CLOSED at THEOREM grade (caustic theorem G-D2b/F10); my "open"
   labels corrected. Not a gap.
6. ⏭ **M1-HORIZON** (our M-lane; genuinely open, but the caustic/Olver machinery for it
   EXISTS — reassess against it; the uniform horizon lemma still has to be written).
7. ◻ **T2a-SP** (already rigorous; Arb-grid = presentation upgrade, heavy — deprioritized).
8. ⏭ **G-HROT/G-E** — u-decay write-up (a) on IB's menu per item 3.8 (his priority if he
   claims it); S-scalar cert (b) is our T2a lane. Shared by default.

*Opened 2026-07-22 in response to `INDEPENDENT_AUDIT_received_2026-07-22/`. Update this
file in place; mirror closures into `LEDGER/EVIDENCE_CHAIN_T2_pin.md` §9.*
