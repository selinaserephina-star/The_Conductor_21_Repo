# FINDINGS — G-HROT explicit constant: reduced to a clean core, NOT closed

**Merkabit · Stenberg + Claude · 2026-07-22.** Attempt to prove an explicit rigorous
ceiling on the atom→Jacobi sensitivity (the G-HROT lemma, item 3.8), which would upgrade
T2a-QT to full CERTIFIED. **Outcome: a clean rigorous REDUCTION + a precise identification
of the irreducible core — but NOT a full close.** Script `ghrot_reduction_check.py`.
Not RH/GRH.

## The rigorous reduction (proven, verified)

For atomic measures μ = Σ w_n δ_{x_n}, μ' = Σ w_n δ_{x'_n} (same weights), write
J = U diag(x) Uᵀ with U the eigenvector matrix (columns φ_n, fixed first component
√w_n). Splitting
`J − J' = U diag(x−x') Uᵀ + [U diag(x')Uᵀ − U' diag(x')U'ᵀ]` and bounding the second
bracket as `(U−U')diag(x')Uᵀ + U'diag(x')(U−U')ᵀ` gives the **rigorous inequality**

  **‖J' − J‖₂ ≤ max_n|x'_n − x_n| + 2·x_max·‖U − U'‖₂.**

Verified numerically on drop-4/drop-1, uniform and random directions (all satisfy it).
This reduces G-HROT to bounding the **ON-frame rotation ‖U − U'‖**.

## What the numerics show

- The true operator-norm sensitivity is tame: **‖ΔJ‖₂ / max|Δx_n| ≈ 1.0–1.5** — far below
  the L1 sensitivity (52.7). (The L1 counts every entry's worst-aligned δ separately; the
  operator norm sees the cancellation.)
- The frame rotation **‖U−U'‖ / max|Δx_n| ≈ 10–85** — bounded, O(10¹), but this is a
  *measured* Lipschitz constant, not a proven one.

## Why it does not close by elementary means (the irreducible core)

A useful ceiling needs `‖U−U'‖ ≤ C'·ε` (**shrinking with** ε = max|Δx_n|). The elementary
routes all fail:
- **Davis–Kahan**: `‖U−U'‖ ≤ ‖ΔJ‖₂ / gap` is (i) circular with the reduction and (ii)
  vacuous — the atom gaps are tiny (`min_n|x_n−x_{n+1}| ~ 9×10⁻⁵ ≪ 2·x_max ≈ 0.47`), so
  `2·x_max/gap ≫ 1` and the self-consistent bound diverges.
- **Trivial** `‖U−U'‖ ≤ 2`: does not shrink with ε → gives `‖ΔJ‖ ≤ ε + 4x_max ≈ 0.9`,
  useless against the 5×10⁻⁵ margin.
- **Entrywise** `ΔU_{jn} = √w_n[p_j(x_n) − p'_j(x'_n)]`: each term is huge (`p'_j ~ 10²⁹¹`)
  and only cancels in aggregate — the same oscillation cancellation as everywhere.

**The frame rotation is ε-Lipschitz only because the norming constants w_n are FIXED
while the eigenvalues move** — i.e. the *inverse-spectral conditioning* of the Jacobi map,
which is exactly what κ̂ = 5.5956 measures. Bounding it rigorously is the κ̂/K1 structural
lemma, not an elementary estimate. Every elementary route hits the small-gap / e^{cj} wall.

## CORRECTION 2026-07-22 (after searching the era-1/era-2 folders — this over-pessimism is WITHDRAWN)

Substantial prior G-HROT work exists and supplies the rigorous mechanism I claimed was
missing. It is NOT "hand off a hard κ̂ lemma to Ilya" — most of it is proven:

- **`T2_pin_conjecture_2026-07-17/t2_stage26c_rotation.py`** — the EXACT unitary
  decomposition `V = Wᵀ(T(J_D)−J_D)W + R`, machine-verified (thm_err ~1e-15): the
  unitary-equivalence theorem `J_F = Tri_{e0}(T(J_D))`, `‖Wᵀ(T(J_D)−J_D)W‖ = max|Δx|`
  EXACTLY, and R the rotation term with C_rot = ‖V‖/max|Δx| = **1.045–1.175, flat in N**.
  (Cleaner than the ‖U−U'‖ split above — same R, tighter.)
- **`T2_K1K2_kernel_bounds_2026-07-18/…md` Theorem 1** (PROVEN): exact closed forms for
  the sensitivity kernels `K_j^α(n)=∂α_j/∂x_n`, `K_j^β(n)=∂β_j/∂x_n`.
- **Theorem 2** (PROVEN): `Σ_{n∈A}K_j^α(n) = ⟨p_j,P_A p_j⟩ + (derivative pairings)`, and
  `⟨p_j,P_A p_j⟩ = ⟨e_j,𝟙_A(J)e_j⟩ ∈ [0,1] ALWAYS` (spectral-projector diagonal). This is
  the **Abel-summation mechanism** that beats e^{cj}: `|Δα_j| ≤ κ̂_j·(TV(Δx)+|Δx_M|)`,
  turning the huge ℓ1 into `κ̂·TV`. The κ̂ here is EXACTLY the constant I certified to
  strict enclosure (κ̂ = 5.5956) in the T2a-KHAT close — the pieces connect.
- **Assembly** (K1K2 note item 4): `|Δα_j| ≤ κ̂_j^α(TV(dx)+|dx_M|) + ½sup_s|α_j″|` —
  "every ingredient proven (Theorems 1–3) or a finite verified constant."

**So my "Davis–Kahan wall / reduces to a hard κ̂ lemma" reading is withdrawn.** The κ̂
route is the correct rigorous one and is largely proven. What is NOT yet a *uniform
theorem*: (i) the derivative-pairing partial sums ≤ κ̂ is proven only in its projection
part [0,1]; the excess (κ̂ up to 5.6) is certified-numerically at the config, not proven
uniform (that is P1, still [GAP]); (ii) the 2nd-order transport remainder ½sup|α″| needs
G-P2-level treatment. For the T2a-QT close both are handled: (i) κ̂ is CERTIFIED at the
frozen config by ball arithmetic (Theorem 1 kernels, stable at centers — my κ̂ enclosure),
(ii) the perturbation is ~10⁻¹¹ so the 2nd-order term is negligible in magnitude.

**Revised path:** assemble ‖ΔJ‖ ≤ (κ̂^α + 2κ̂^β)·(TV(Δx)+|Δx_M|) with the certified κ̂'s and
a rigorous TV(Δx) bound, giving T2a-QT at CERTIFIED-as-computed grade (same grade as the
sealed T2a cert itself). See §9 2026-07-22.

## Status (original, pre-correction)

- **G-HROT explicit constant: NOT closed.** Reduced to: a rigorous `‖U−U'‖ ≤ C'·ε` bound
  (the fixed-norming-constant inverse-spectral / κ̂ conditioning). Measured C' ~ O(10¹).
- **This is the SAME object as T2a-QT's remaining sensitivity ceiling** — both wait on the
  one κ̂-conditioning lemma. T2a-QT therefore stays **CERTIFIED-modulo-sensitivity-ceiling**;
  the ceiling is now sharply named: the ON-frame rotation is ε-Lipschitz with an explicit
  constant.
- **Lane:** this is our K1/κ̂ lane (Theorems 1–2 are era-2 ours) — NOT to be pre-assigned to
  IB (correcting an earlier drift in this note). The clean statement: "prove ‖U−U'‖ ≤
  C'·max_n|Δx_n| with explicit C' for the χ8 quantile configuration; any C' < 1.6×10⁶
  upgrades T2a-QT to full CERTIFIED (measured ~O(10¹))." Offerable, shared by default.
  NB (2026-07-22): for the T2a-QT purpose this is now CLOSED at config grade by the
  certified-κ̂ Abel assembly (κ̂ IS the explicit C'); only the uniform-in-j version (= P1,
  our lane) remains.
