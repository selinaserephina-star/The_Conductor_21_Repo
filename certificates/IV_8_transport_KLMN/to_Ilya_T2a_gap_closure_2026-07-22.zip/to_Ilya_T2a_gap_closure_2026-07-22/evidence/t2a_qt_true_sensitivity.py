# t2a_qt_true_sensitivity.py — GAP-CLOSURE (T2a-QT), 2026-07-22.
# The decisive test showed the transfer is benign in ALL directions -> the true
# atom-position sensitivity d(alpha,beta)_j / d x_m is O(1), NOT the e^{cj} of the
# Theorem-1 kernel (which uses polynomial derivatives p'_j, a different object).
# Here we compute the TRUE sensitivity L1 per coefficient by a stable point Jacobian
#   L1a_j = sum_m |d alpha_j / d x_m|,   L1b_j = sum_m |d beta_j / d x_m|
# via forward differences at dps 40 (point arithmetic, stable). The worst delta over the
# box for coefficient j is delta_m = r_x(m) sign(d./dx_m), giving |Delta| <= L1_j * max r_x.
# If max_j L1_j = O(1), then ||Delta J|| <= O(1) * max_m r_x(m) << the PSD margins, and the
# true-quantile transfer is certified up to a (mechanical) rigorous-remainder step.
# Not RH/GRH.
import os, time
import numpy as np
import mpmath as mp

HERE = os.path.dirname(os.path.abspath(__file__))
KB   = os.path.join(HERE, '..', 'T2_K1K2_kernel_bounds_2026-07-18')
q = np.loadtxt(os.path.join(KB, 'quantiles_production.csv'), delimiter=",", skiprows=1)
gD_c, gF_c = q[:, 1], q[:, 2]
mp.mp.dps = 40

def jac_coeffs(xs):
    N = len(xs); v = [mp.mpf(1) / mp.sqrt(N)] * N
    al, be, Vs = [], [], [v[:]]
    w = [xs[i] * v[i] for i in range(N)]
    a0 = mp.fsum(v[i] * w[i] for i in range(N)); al.append(a0); w = [w[i] - a0 * v[i] for i in range(N)]
    for j in range(1, N):
        b = mp.sqrt(mp.fsum(t * t for t in w)); be.append(b); vn = [t / b for t in w]
        for u in Vs:
            c = mp.fsum(u[i] * vn[i] for i in range(N)); vn = [vn[i] - c * u[i] for i in range(N)]
        nv = mp.sqrt(mp.fsum(t * t for t in vn)); vn = [t / nv for t in vn]
        Vs.append(vn); w = [xs[i] * vn[i] - b * Vs[-2][i] for i in range(N)]
        aj = mp.fsum(vn[i] * w[i] for i in range(N)); al.append(aj); w = [w[i] - aj * vn[i] for i in range(N)]
    return al, be

for drop in [4]:
    cs = [mp.mpf(x) for x in gD_c[drop:]]
    M = len(cs)
    x0 = [1 / g**2 for g in cs]
    a0, b0 = jac_coeffs(x0)
    rx = [float(2 * cs[m]**-3 * mp.mpf('1e-10')) for m in range(M)]   # atom shift bound |dx_m|
    h = mp.mpf('1e-12')
    L1a = [mp.mpf(0)] * M          # L1a[j] = sum_m |d alpha_j / d x_m|
    L1b = [mp.mpf(0)] * (M - 1)
    # box-worst accumulation directly: sum_m |d./dx_m| * r_x(m)
    Wa = [mp.mpf(0)] * M
    Wb = [mp.mpf(0)] * (M - 1)
    t0 = time.time()
    for m in range(M):
        xp = x0[:]; xp[m] = 1 / (cs[m] + h)**2      # perturb atom m via gamma+h (real dx)
        dxm = xp[m] - x0[m]
        ap, bp = jac_coeffs(xp)
        for j in range(M):
            s = abs((ap[j] - a0[j]) / dxm)          # |d alpha_j / d x_m|
            L1a[j] += s; Wa[j] += s * mp.mpf(rx[m])
        for j in range(M - 1):
            s = abs((bp[j] - b0[j]) / dxm)
            L1b[j] += s; Wb[j] += s * mp.mpf(rx[m])
        if m % 40 == 0:
            print(f"   atom {m}/{M}  ({time.time()-t0:.0f}s)")
    maxL1a = max(float(x) for x in L1a); maxL1b = max(float(x) for x in L1b)
    maxWa = max(float(x) for x in Wa); maxWb = max(float(x) for x in Wb)
    print(f"\ndrop-{drop}, M={M}:")
    print(f"  TRUE sensitivity L1:  max_j sum_m|d.alpha_j/d.x_m| = {maxL1a:.3f}  (O(1) => G-HROT scale)")
    print(f"                        max_j sum_m|d.beta_j /d.x_m| = {maxL1b:.3f}")
    print(f"  box-worst |Delta alpha_j| <= max_j sum_m|d.alpha_j/dx_m| r_x(m) = {maxWa:.3e}")
    print(f"  box-worst |Delta beta_j|  <= {maxWb:.3e}")
    print(f"  => rigorous first-order ||Delta J||_inf <= {maxWa+2*maxWb:.3e}"
          f"   (vs tightest margin 5.0e-5: headroom {5.0e-5/(maxWa+2*maxWb):.0f}x)")
print("done.")
