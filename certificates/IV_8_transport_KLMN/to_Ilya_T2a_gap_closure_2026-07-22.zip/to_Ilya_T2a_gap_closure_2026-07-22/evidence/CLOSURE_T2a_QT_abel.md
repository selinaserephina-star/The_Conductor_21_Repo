# CLOSURE — T2a-QT: true-quantile transfer, CERTIFIED-as-computed via certified-κ̂ Abel

**Merkabit · Stenberg + Claude · 2026-07-22.** Closes `T2A_TRUE_QUANTILE_FORM_BOUND` at
CERTIFIED-as-computed grade — the SAME grade as the sealed T2a certificate itself.
Script `t2a_qt_abel_certificate.py` (+ run log). Builds on era-2 `K1K2_kernel_bounds`
Theorems 1–2 (PROVEN) and the era-1 unitary decomposition. Not RH/GRH.

## The route (found by searching era-1/era-2, after the false-start pessimism)

The naive routes failed (direct ball-Lanczos unstable; wrong-kernel ℓ1 vacuous). The
correct rigorous route is **Abel summation against the certified κ̂**:

- **Theorem 1** (PROVEN, K1K2 note): exact `K_j^α(n)=∂α_j/∂x_n = wΦ_j'(x_n)`,
  `K_j^β(n)=∂β_j/∂x_n = wΨ_j'(x_n)`.
- **Theorem 2** (PROVEN): `Σ_{n≤m}K_j^α(n) = ⟨p_j,P_A p_j⟩ + (derivative pairings)`, and
  `⟨p_j,P_A p_j⟩∈[0,1]` always. So `κ̂_j := sup_m|Σ_{n≤m}K_j(n)|` is O(1) — the huge ℓ1 is
  irrelevant; the partial sums are bounded.
- **Abel (summation by parts):** `|Δα_j| = |Σ_n K_j(n)Δx_n| ≤ κ̂_j^α·TV(Δx) + |Σ_n K_j(n)|·|Δx_M|`.
  Since the row sum `Σ_n K_j^α(n)=1` (Theorem 2, A=all), `|Δα_j| ≤ κ̂^α·(TV(Δx)+|Δx_M|)`;
  likewise `|Δβ_j| ≤ κ̂^β·(TV(Δx)+|Δx_M|)`. Hence
  **`‖ΔJ‖∞ ≤ (κ̂^α + 2κ̂^β)·(TV(Δx)+|Δx_M|)`.**
- **Weyl:** frozen-center pencils are PSD with margin δ ⇒ `λ_min(true) ≥ δ − ‖ΔM‖₂`.

## Certified inputs

- **κ̂ at ball grade** (prec 16384, stable at the exact centers; boundary row via the
  trace identity): κ̂^α(D)=**5.5956** [matches the T2a-KHAT strict enclosure exactly —
  cross-validation], κ̂^β(D)=2.8598, κ̂^α(F)=9.4916, κ̂^β(F)=6.0075 (both drops).
- **TV(Δx) rigorous** from the certified 1e-10 quantile enclosures:
  `Δx_n ∈ [(c_n+ρ)⁻²−c_n⁻², (c_n−ρ)⁻²−c_n⁻²]`, worst-case
  `TV ≤ r_x(1)+r_x(M)+2Σ_{2..M-1}r_x(n) ≈ 1.9×10⁻¹⁰` (drop-4).
- **2nd-order transport term:** covered by a 2× safety factor. The true remainder is
  `½sup_s|α_j″|·(scale)² ~ 10⁻²¹` (measured sup|α″|≤1.07e-2, K1K2 Thm 3) — ~13 orders
  below the first-order Abel bound, so the 2× is enormous overkill.

## Result — all four pencils CERTIFIED

| pencil | ‖ΔM‖∞ (≤) | δ_center | λ_min(true) ≥ | headroom |
|---|---|---|---|---|
| drop-4  aJ_D+bI−V | 1.365×10⁻⁸ | 5.820×10⁻⁵ | 5.819×10⁻⁵ | 4,265× |
| drop-4  aJ_D+bI+V | 1.108×10⁻⁸ | 4.220×10⁻⁴ | 4.220×10⁻⁴ | 38,080× |
| drop-1  aJ_D+bI−V | 3.694×10⁻⁸ | 1.088×10⁻² | 1.088×10⁻² | 294,500× |
| drop-1  aJ_D+bI+V | 2.917×10⁻⁸ | 1.257×10⁻³ | 1.257×10⁻³ | 43,090× |

**⇒ the KLMN form bound `|⟨Vu,u⟩| ≤ a⟨J_Du,u⟩ + b‖u‖²` holds at the TRUE quantiles**, not
just the frozen dyadic centers — tightest headroom 4,265×.

## Grade

`T2A_TRUE_QUANTILE_FORM_BOUND`: **OPEN → CERTIFIED-as-computed** (same grade as the sealed
T2a cert). Rests on: PROVEN Theorems 1–2; κ̂ certified at ball grade at each config; TV(Δx)
rigorous; Weyl. Honest residual for a fully-PROVEN *uniform* theorem (not needed for this
grade): the derivative-pairing partial-sum bound κ̂≤5.6/9.5 is proven only in its [0,1]
projection part — the excess is certified-numerically at the config (uniform-in-j proof =
P1, still [GAP]); and the 2nd-order transport term is G-P2-level (here bounded by the
measured sup|α″| + 2× margin). Both are exactly the "certified-as-computed" allowances the
sealed cert already uses (CONSTR_R, the θ-module headroom).
