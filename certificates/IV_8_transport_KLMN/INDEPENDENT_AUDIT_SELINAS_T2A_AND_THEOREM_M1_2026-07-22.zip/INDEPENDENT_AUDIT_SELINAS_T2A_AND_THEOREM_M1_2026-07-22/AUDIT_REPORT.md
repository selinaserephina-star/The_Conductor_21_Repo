# Independent audit — Selina T2a certificate, κ̂ addendum, and THEOREM-M1

**Date:** 2026-07-22  
**Scope:** package integrity, logical scope, independent numerical corroboration,
and proof-boundary review.  
**Not RH/GRH.**

## Source integrity

The following uploaded archives opened cleanly and their internal manifests verified:

- `to_Ilya_T2a_CERTIFICATE_2026-07-21.zip`
  - external SHA-256:
    `60410732cfc547f140be48975a77783df4ff2be6568db39a576d306007784482`
  - 8/8 internal manifest entries verified.
- `to_Ilya_T2a_khat_addendum_2026-07-21.zip`
  - external SHA-256:
    `9a92a6e7cf0e8917a52e267b3e0768c2e5cb801d839c76250643e0181937df86`
  - 3/3 internal manifest entries verified.
- `to_Ilya_THEOREM_M1_2026-07-21.zip`
  - external SHA-256:
    `9222de626309c8c56b25780f51d3c65c28e9a1bdda67aa414b591b2db982fea4`
  - 32/32 internal manifest entries verified.

The archives are not self-contained reproductions: their scripts depend on exact files
from earlier operator/K1K2/spectrum packages. The lineage is documented, but the
dependencies are not bundled into these three ZIPs.

## T2a: what is genuinely established

For the frozen dyadic-center finite sections:

\[
V=J_F-J_D,
\]

and the four PSD tests establish

\[
|\langle Vu,u\rangle|
\leq
a\langle J_Du,u\rangle+b\|u\|^2
\]

for:

- drop-1, dimension 148, \((a,b)=(0.3,0.011)\);
- drop-4, dimension 145, \((a,b)=(0.3,0.0001)\).

The package's ball-Cholesky lower margins are:

- drop-1: \(5.500\times10^{-3}\) and \(6.875\times10^{-4}\);
- drop-4: \(5.000\times10^{-5}\) and \(4.000\times10^{-4}\).

An independent 60-digit rebuild from the frozen CSV centers numerically found
approximate lower eigenvalue thresholds:

- drop-1, \(aJ_D+bI-V\): \(1.08792188748915\times10^{-2}\);
- drop-1, \(aJ_D+bI+V\): \(1.25716417040033\times10^{-3}\);
- drop-4, \(aJ_D+bI-V\): \(5.82114387213117\times10^{-5}\);
- drop-4, \(aJ_D+bI+V\): \(4.22729873271415\times10^{-4}\).

Thus the reported dyadic margins are numerically corroborated and conservative.

### Correct interpretation

This does **not** newly prove self-adjointness of the infinite operator.

1. Every frozen finite real symmetric Jacobi matrix is already self-adjoint.
2. The present infinite Jacobi operators were already bounded/self-adjoint because
   the underlying atomic measures have compact support.
3. T2a's new content is a quantitative relative form bound for two finite frozen
   sections. It becomes an infinite-dimensional KLMN result only after a uniform
   limit theorem and an infinite form bound are proved.

### Frozen versus true quantiles

The 298 quantiles are ball-localized to radius \(10^{-10}\), but the full-depth
Lanczos/PSD calculation is performed on the exact dyadic CSV centers, not on atom
balls containing the true quantiles. Therefore:

- frozen-center certificate: closed;
- true-quantile matrix certificate: still requires the stated sensitivity transfer.

The transfer is likely to have very large numerical slack, but it is not yet in the
certificate.

### \(S_P\) bounds

- `sup|S_P'| <= 188.804` is supported by interval termwise bounds.
- `sup|S_P| <= 0.901946` uses a dense binary64 scan plus a Lipschitz and floating
  budget. It is useful, but a fully Arb grid evaluation would provide a cleaner
  certificate for publication.

## κ̂ addendum

The high-precision calculation strongly confirms

\[
\widehat\kappa\approx 5.5956
\]

for the frozen drop-4 D-system, and shows the maximum occurs at the boundary row.

However, the final cumulative sums and maximum are computed from floating conversions
of Arb midpoints. A strict interval certificate should accumulate the Arb balls
themselves and output an enclosure such as
\(\widehat\kappa\in[\kappa_-,\kappa_+]\).
The current grade is best described as high-precision ball-derived numerical
confirmation, not a complete interval enclosure of \(\widehat\kappa\).

## THEOREM-M1: accepted core

The strongest parts are:

1. Exact one-row bordering/arrowhead identity for the uniform system over the
   odd weighted block.
2. Exact odd-Lambert moment/block formulas.
3. The standalone identity
   \[
   \sum_{n\ge1}(-1)^{n+1}
   j_{2j+1}((n-\tfrac12)\pi)
   =\frac{(-1)^j}{2}.
   \]
   The supplied Poisson-representation and endpoint Fourier-series proof is sound
   for each fixed \(j\).
4. The fixed-\(j\) tail rate
   \[
   1-S_NP_{2j+1}(1)
   \sim \frac{(2j+1)(2j+2)}{\pi^2N}.
   \]

These results give a stable forward weight-transfer dictionary and are the most
useful mathematical content of the package.

## THEOREM-M1: proof gap in G-M3

The stated truncation proof uses the assertion that the upper-triangular
half-diagonal projection `up` is nonexpansive in spectral norm. This is false.

For example,

\[
A=
\begin{pmatrix}
-1&2&2\\
2&-1&2\\
2&2&-1
\end{pmatrix}
\]

has \(\|A\|_2=3\), while

\[
\operatorname{up}(A)=
\begin{pmatrix}
-\tfrac12&2&2\\
0&-\tfrac12&2\\
0&0&-\tfrac12
\end{pmatrix}
\]

has spectral norm approximately \(3.169079>3\).

The subsequent assembly also uses an unquantified `h.o.` term. Therefore the
explicit bound with constant 6 and the claim `G-M3 PROVEN` are not certified by
the supplied proof as written.

This does not refute the finite-section convergence rates. It means the proof must
be repaired using, for example:

- a standard Cholesky perturbation theorem;
- a Frobenius-norm argument with explicit dimension dependence;
- or exact Gram/Hankel determinant perturbation bounds.

The tail-mass scales \(N^{-3}\) and \(N^{-1}\) remain well supported for fixed
polynomial degree.

## Other grading corrections

- The identity and tail asymptotic are proved for each fixed \(j\).
- The claimed sharp horizon \(3.2\sqrt N\) requires estimates uniform in
  \(j\sim\sqrt N\); these are not supplied. It remains measured/heuristic.
- The finite-\(N\) sign alternation of every actual coupling across the full
  horizon is numerically observed, but does not follow solely from the fixed-\(j\)
  infinite-sum identity.
- The production head-suppression and deep ODD-difference decomposition are useful
  measured structural facts, not yet an infinite-limit theorem.

## Recommended registry

```text
T2A_FROZEN_DROP1_DROP4_FORM_BOUND = CERTIFIED
T2A_TRUE_QUANTILE_FORM_BOUND = OPEN_PENDING_SENSITIVITY
INFINITE_OPERATOR_SELF_ADJOINTNESS_NEWLY_PROVED_BY_T2A = FALSE
FINITE_FROZEN_MATRICES_SELF_ADJOINT = TRIVIAL/EXACT
T2A_SUP_SP_PRIME_BOUND = USEFUL_WITH_FLOAT_SCAN_CAVEAT

THEOREM_M1_BORDERING_IDENTITY = EXACT
THEOREM_M1_ODD_LAMBERT_BLOCK = EXACT
BESSEL_ENDPOINT_SUM_IDENTITY = PROVEN
FIXED_J_FINITE_N_TAIL_RATE = PROVEN
G_M3_EXPLICIT_CONSTANT_6 = PROOF_GAP
HORIZON_3_2_SQRT_N = MEASURED_NOT_PROVEN
PRODUCTION_V_HEAD_SUPPRESSION = MEASURED_EXACT_FORMULA_CONTROLLED

KHAT_5_5956 = HIGH_PRECISION_CONFIRMED
KHAT_STRICT_INTERVAL_ENCLOSURE = OPEN
```

## Most useful next theorem

Use the exact bordered ODD representation to construct a canonical infinite
principal operator \(V_\infty\), repair the finite-section perturbation theorem,
and prove:

1. \(J_D^{(N)}\to J_D\);
2. \(V^{(N)}\to V_\infty\) in a specified operator/form topology;
3. a uniform relative bound with \(a<1\);
4. transfer from dyadic centers to true quantiles.

Only then does the finite T2a bound become a genuine infinite KLMN theorem.
