#!/usr/bin/env python3
"""Independent high-precision numerical corroboration of the frozen T2a PSD margins.

Usage:
    python3 independent_frozen_psd_check.py quantiles_production.csv

This is not an interval certificate. It rebuilds the frozen dyadic-center
Jacobi matrices at 60 decimal digits and estimates their smallest eigenvalue
thresholds via shifted Cholesky.
"""
import sys, time
import numpy as np
import mpmath as mp

if len(sys.argv) != 2:
    raise SystemExit("usage: independent_frozen_psd_check.py quantiles_production.csv")

q = np.loadtxt(sys.argv[1], delimiter=",", skiprows=1)
mp.mp.dps = 60

def mp_lanczos(xs):
    N = len(xs)
    v = [mp.mpf(1) / mp.sqrt(N) for _ in range(N)]
    al, be, basis = [], [], [v[:]]
    w = [xs[i] * v[i] for i in range(N)]
    a0 = mp.fsum(v[i] * w[i] for i in range(N))
    al.append(a0)
    w = [w[i] - a0 * v[i] for i in range(N)]
    for _ in range(1, N):
        beta = mp.sqrt(mp.fsum(x*x for x in w))
        be.append(beta)
        vn = [x / beta for x in w]
        for u in basis:
            c = mp.fsum(u[i] * vn[i] for i in range(N))
            vn = [vn[i] - c*u[i] for i in range(N)]
        norm = mp.sqrt(mp.fsum(x*x for x in vn))
        vn = [x / norm for x in vn]
        basis.append(vn)
        w = [xs[i]*vn[i] - beta*basis[-2][i] for i in range(N)]
        alpha = mp.fsum(vn[i]*w[i] for i in range(N))
        al.append(alpha)
        w = [w[i] - alpha*vn[i] for i in range(N)]
    return al, be

def positive_after_shift(diag, off, shift):
    d = diag[0] - shift
    if d <= 0:
        return False
    for i in range(1, len(diag)):
        d = diag[i] - shift - off[i-1]**2/d
        if d <= 0:
            return False
    return True

for drop, a, b in [
    (1, mp.mpf("0.3"), mp.mpf("0.011")),
    (4, mp.mpf("0.3"), mp.mpf("0.0001")),
]:
    xsD = [mp.mpf(float(x))**-2 for x in q[drop:, 1]]
    xsF = [mp.mpf(float(x))**-2 for x in q[drop:, 2]]
    alD, beD = mp_lanczos(xsD)
    alF, beF = mp_lanczos(xsF)
    for sign, label in [(1, "aJ+bI-V"), (-1, "aJ+bI+V")]:
        diag = [(a+sign)*alD[j] - sign*alF[j] + b for j in range(len(alD))]
        off = [(a+sign)*beD[j] - sign*beF[j] for j in range(len(beD))]
        lo, hi = mp.mpf("0"), mp.mpf("0.02")
        for _ in range(60):
            mid = (lo+hi)/2
            if positive_after_shift(diag, off, mid):
                lo = mid
            else:
                hi = mid
        print(f"drop-{drop} {label}: lower threshold ~ {mp.nstr(lo, 16)}")
