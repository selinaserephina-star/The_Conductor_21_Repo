# To Ilya — T2a delivered: the finite-range KLMN certificate for χ8, ball grade end to end

**Merkabit · Selina + Claude · 2026-07-21. Not RH/GRH — a finite-range,
explicit-constant certificate about the frozen production operator pair.**

**Lineage:** follows `to_Ilya_CAUSTIC_THEOREM_2026-07-19`
(SHA256 = 284d21b50996dc76bf74e86567c7c53c6ef5ef78f344860ba90fa440769326b7),
`to_Ilya_Q2_OPERATOR_BRIDGE_audit_2026-07-19`
(SHA256 = 930b3315c7dcd5a86db5f7dd3eebd36ada93fb6718603b92c3be9212d982ccd8), and
`to_Ilya_CERTIFIED_spectrum_2026-07-19` (SHA256 = 587d757c…, your gate form filled at
CERTIFIED) — whose delivery is what made this actionable. Frozen hypotheses are
ledger item 0.1, untouched. All prior packages immutable.

## The result

**C1 of your certification lane is DONE.** For the frozen production pair
(J_D, V = J_F − J_D) at N = 149:

  **|⟨Vu, u⟩| ≤ a⟨J_D u, u⟩ + b‖u‖²  at CERTIFICATE grade,**
  (a, b) = (0.3, 0.011) drop-1 and (0.3, 0.0001) drop-4,

via ball-certified PSD of all four matrices aJ_D + bI ∓ V at FULL dimension
(148×148 / 145×145), with certified margins

  drop-1: δ ≥ 5.500e−3 (−V) / 6.875e−4 (+V);  drop-4: δ ≥ 5.000e−5 / 4.000e−4.

This is the first rigorous finite-range self-adjointness statement for the χ8
operator family. The whole chain is ball arithmetic (arb via python-flint 0.8.0,
run locally): conductor 21¹⁰ + exact Frobenius traces → ball θ/θ′ (8 lgammas +
digamma) and ball S_P/S_P′ (18,120 terms) → **298/298 quantile enclosures at radius
1e−10** (interval Newton: definite endpoint signs + f′ > 0 per bracket ⇒ unique
roots) → **full-dimension ball Lanczos** (prec 16384; entry radii below 1e−308
display) → **ball Cholesky positivity**. Also certified en route:
**sup|S_P| ≤ 0.901946** on [0.5, 27.79] and **sup|S_P′| ≤ 188.804** (interval
Lipschitz + dense scan with explicit float budget) — the ‖S‖*-lane scalars you
asked after now exist at certificate grade. Only assumption anywhere: arb itself.
Rounding discipline: all quoted bounds are interval upper ends (ceil-safe).

## Two audit findings — please read these even if you skip the rest

1. **The Krylov-conditioning wall (affects YOUR instruments too).** Certification
   exhausts at depth ~94 for any precision ≤ 4096 bits — the clustered atom
   spectrum drives ~10¹³/step error amplification; full depth needs ~16k bits.
   Consequence: **the deep rows (j ≳ 94) of every float64/dps-40 Lanczos build ever
   made from these ladders — including the frozen kernel caches — were below their
   own noise floors.** Everything the T2 chain consumes (V at j = 1–3, the caustic
   at j ≤ 40, K1 bulk) lives safely above the line. The one flagged constant:
   **κ̂ = 5.5956 is attained at j = 145, inside the noise regime** — it must be
   re-graded against this package's 16k-bit ball values before further citation
   (dated flag placed at ledger item 3.5). The boundary-layer THEORY (Chebyshev
   κ_{M−ℓ} ≍ M/πℓ, proven) is untouched; it is the measured production value that
   needs re-grading.
2. **A prec-16384 wide-ball quirk in the tooling** (mechanism unresolved, recorded
   so nobody trips on it): the quantile sign tests regress to 66/149 at 16k bits
   while passing 149/149 at 1024/4096; the θ probe at 16k is tight, so the
   wideness enters elsewhere (suspect: trig at interval arguments). Certificates
   are taken at prec 4096 — a ball certificate at any precision is a certificate.

## Honest scope

- The certificate is about the **frozen-as-computed object** (the float64 ladder
  centers of the frozen CSV — dyadic rationals — are the object every T2 result is
  about), PLUS the certified localization of the true quantiles to 1e−10 of those
  centers. Transferring the PSD margins to the true-quantile object needs a
  certified entry-sensitivity bound ≤ 5×10⁵ (measured 0.76–50; one more ball run
  over the Theorem-1 kernel formulas). Astronomic slack; staged as optional
  polish, not claimed.
- Nothing here touches C2 (Palojärvi–Zhao constants) — that remains yours if you
  want it; the certified sup|S_P| above is an input you can now cite.

## Reproduction

`evidence/t2a_certify.py` (session 1: iv-based sup|S_P|, interval-Cholesky PSD,
cross-checks vs your frozen CSV at 3.6e−15 and the frozen npz at 8.3e−17) and
`evidence/t2a_theta_module.py` (session 2: the arb chain; stage precisions 4096 /
16384). Requirements: python-flint ≥ 0.8, numpy, mpmath. Runtimes on a laptop:
session 1 ≈ 8 min (the S_P scan dominates); session 2 ≈ 15 min (the 16k-bit
Lanczos dominates). Logs included; ledger + register snapshots in `evidence/`.

*SHA seal of this zip in `to_Ilya_T2a_CERTIFICATE_2026-07-21.zip.sha256.txt` at
send. Per-file manifest in `SHA256SUMS.txt`.*
