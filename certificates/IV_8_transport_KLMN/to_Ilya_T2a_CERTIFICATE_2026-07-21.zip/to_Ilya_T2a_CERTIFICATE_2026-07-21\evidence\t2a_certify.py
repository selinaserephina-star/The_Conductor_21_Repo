# t2a_certify.py — T2a: the finite-range pencil certificate, LOCAL SCOPE (session 1 of
# the T2a campaign, 2026-07-21). Target (G-C1, our lane per Selina's decision):
#   aJ_D + bI -+ V  >= 0  at N = 149,  (a,b) = (0.3, 0.011) drop-1 / (0.3, 0.0001) drop-4
# certified by interval arithmetic, plus certified sup|S_P|, plus the perturbation
# wiring that isolates the ONE non-certified module (theta evaluation).
#
# GRADES DELIVERED (honest, per the ledger's tag conventions):
#   [CERTIFIED]           sup|S_P| bound and |S_P'| bound — the Euler side is a finite
#                         explicit sum, fully interval-computable; the sup uses a dense
#                         float64 scan with an EXPLICIT rounding budget + an interval
#                         Lipschitz constant (no unproven step).
#   [CERTIFIED-as-computed] PSD of the constructed matrices M+- with margin delta, by
#                         interval Cholesky on enclosures centered at the mp-computed
#                         entries with a stated construction allowance.
#   [CONDITIONAL-on-theta] the quantile enclosures |gamma - gamma~| (residual/derivative
#                         argument needs a rigorous theta enclosure — mp.loggamma is not
#                         a certified library). The module is specified exactly; margin
#                         accounting below shows how much theta-error the certificate
#                         tolerates.
# Frozen hypotheses (ledger item 0.1): theta/pi = n - 1/2 (D) and theta/pi + S_P = n - 1/2
# (F), P = 2e5, atoms x = 1/gamma^2, uniform masses, N = 149, drops = smallest-gamma rows.
import os, sys, time
import numpy as np
import mpmath as mp
from mpmath import iv

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', 'T3_twin_skeleton_2026-07-17'))
from operator_skeleton_hdv import theta, build_prime_data
from gen_an_chi8 import LOC8, frob_class

mp.mp.dps = 40
iv.dps = 40

print("=== (P0) rebuild the frozen ladders and cross-check against the sealed record ===")
q = np.loadtxt(os.path.join(HERE, '..', 'T2_K1K2_kernel_bounds_2026-07-18',
                            'quantiles_production.csv'), delimiter=",", skiprows=1)
gD_frozen, gF_frozen = q[:, 1], q[:, 2]
S_P, nterms = build_prime_data(200000)
print(f"  prime data: {nterms} terms (frozen spec P = 2e5)")
# refine the frozen gammas at dps 40 (Newton on f = theta/pi [+ S_P] - (n - 1/2))
def refine(g0, n, with_S):
    g = mp.mpf(g0)
    for _ in range(4):
        f = theta(g) / mp.pi - (n - mp.mpf('0.5')) + (S_P(float(g)) if with_S else 0)
        fp = mp.diff(lambda t: theta(t) / mp.pi, g) + \
             ((S_P(float(g) + 5e-8) - S_P(float(g) - 5e-8)) / 1e-7 if with_S else 0)
        g = g - f / fp
    return g
gD = [refine(gD_frozen[n], n + 1, False) for n in range(149)]
gF = [refine(gF_frozen[n], n + 1, True) for n in range(149)]
dev = max(max(abs(float(gD[n]) - gD_frozen[n]) for n in range(149)),
          max(abs(float(gF[n]) - gF_frozen[n]) for n in range(149)))
print(f"  refined at dps 40; max |refined - frozen csv| = {dev:.2e}  [same ladders]")

print("=== (P1) CERTIFIED sup|S_P| and |S_P'| on the ladder range (interval, rigorous) ===")
# term data: S_P(t) = -(1/pi) sum co_k sin(t lg_k); rebuild the exact term list
def newton_power_sums(loc, kmax):
    deg = len(loc) - 1
    e = [((-1) ** i) * loc[i] for i in range(len(loc))]
    p = [0] * (kmax + 1)
    for k in range(1, kmax + 1):
        s = ((-1) ** (k - 1)) * k * e[k] if k <= deg else 0
        for i in range(1, min(k - 1, deg) + 1):
            s += ((-1) ** (i - 1)) * e[i] * p[k - i]
        p[k] = s
    return p[1:]
P = 200000
isp = np.ones(P + 1, dtype=bool); isp[:2] = False
for q_ in range(2, int(P ** 0.5) + 1):
    if isp[q_]: isp[q_ * q_::q_] = False
primes = np.nonzero(isp)[0]
lg_f, co_f = [], []
# interval accumulators for the two rigorous constants
S_abs = iv.mpf(0)        # (1/pi) sum |co|          >= sup|S_P|   (crude ceiling)
L_lip = iv.mpf(0)        # (1/pi) sum |co| lg       >= sup|S_P'|  (Lipschitz constant)
for p in primes:
    p = int(p)
    kmax = 1
    while p ** (kmax + 1) <= P: kmax += 1
    tr = newton_power_sums(LOC8[frob_class(p)], kmax)
    for k in range(1, kmax + 1):
        c = mp.mpf(tr[k - 1]) / k          # exact rational
        lg_f.append(k * np.log(p)); co_f.append(float(c) * p ** (-k / 2))
        civ = iv.mpf(abs(tr[k - 1])) / k * iv.mpf(p) ** (-iv.mpf(k) / 2)
        S_abs += civ
        L_lip += civ * (iv.mpf(k) * iv.log(iv.mpf(p)))
S_abs /= iv.pi; L_lip /= iv.pi
lg_v = np.array(lg_f); co_v = np.array(co_f)
print(f"  crude ceiling (1/pi) sum|co| = {mp.nstr(mp.mpf(S_abs.b), 8)} (upper end)")
Lb = mp.mpf(L_lip.b)
print(f"  CERTIFIED Lipschitz: sup|S_P'| <= {mp.nstr(Lb, 8)}")
# dense scan with explicit budget: sup <= max_grid + L h/2 + float rounding budget
t_lo, t_hi = 0.5, float(gD[-1]) + 0.5
h = 2e-5
grid = np.arange(t_lo, t_hi, h)
mx = 0.0
t0 = time.time()
for s in range(0, len(grid), 4000):
    ch = grid[s:s + 4000]
    vals = np.abs((co_v[None, :] * np.sin(ch[:, None] * lg_v[None, :])).sum(axis=1)) / np.pi
    m = float(vals.max())
    if m > mx: mx = m
fl_budget = len(co_v) * 1.2e-16 * float(np.abs(co_v).sum()) / np.pi
sup_cert = mx + float(Lb) * h / 2 + fl_budget
print(f"  scan [{t_lo}, {t_hi:.2f}] at h = {h}: max = {mx:.6f}  ({time.time()-t0:.0f}s)")
print(f"  CERTIFIED: sup|S_P| <= {sup_cert:.6f}  (= scan + L*h/2 [{float(Lb)*h/2:.1e}]"
      f" + float budget [{fl_budget:.1e}])")

print("=== (P2) build the matrices at dps 40 and cross-check the frozen npz ===")
def mp_lanczos(xs, m):
    Nn = len(xs)
    v = [mp.mpf(1) / mp.sqrt(Nn) for _ in range(Nn)]
    al, be, Vs = [], [], [v[:]]
    w = [xs[i] * v[i] for i in range(Nn)]
    a0 = mp.fsum(v[i] * w[i] for i in range(Nn)); al.append(a0)
    w = [w[i] - a0 * v[i] for i in range(Nn)]
    for j in range(1, m):
        b = mp.sqrt(mp.fsum(t * t for t in w))
        be.append(b)
        vn = [t / b for t in w]
        for u in Vs:
            c = mp.fsum(u[i] * vn[i] for i in range(Nn))
            vn = [vn[i] - c * u[i] for i in range(Nn)]
        nv = mp.sqrt(mp.fsum(t * t for t in vn))
        vn = [t / nv for t in vn]
        Vs.append(vn)
        w = [xs[i] * vn[i] - b * Vs[-2][i] for i in range(Nn)]
        aj = mp.fsum(vn[i] * w[i] for i in range(Nn)); al.append(aj)
        w = [w[i] - aj * vn[i] for i in range(Nn)]
    return al, be
CASES = {}
for drop, (aa, bb) in [(1, ('0.3', '0.011')), (4, ('0.3', '0.0001'))]:
    xsD = [1 / g ** 2 for g in gD[drop:]]
    xsF = [1 / g ** 2 for g in gF[drop:]]
    M = len(xsD)
    alD, beD = mp_lanczos(xsD, M)
    alF, beF = mp_lanczos(xsF, M)
    CASES[drop] = (alD, beD, alF, beF, mp.mpf(aa), mp.mpf(bb), M)
    print(f"  drop-{drop}: built J_D, J_F at dps 40 (M = {M})")
d = np.load(os.path.join(HERE, '..', 'T2_K1K2_kernel_bounds_2026-07-18',
                         'k1_kernels_k4_N149.npz'))
alD4, beD4 = CASES[4][0], CASES[4][1]
devA = max(abs(float(alD4[j]) - d['al'][j]) for j in range(len(d['al'])))
devB = max(abs(float(beD4[j]) - d['be'][j]) for j in range(len(d['be'])))
print(f"  cross-check vs FROZEN npz (drop-4 J_D): max|dal| = {devA:.2e}, max|dbe| = {devB:.2e}")

print("=== (P3) interval-Cholesky PSD of M+- = aJ_D + bI -+ V, with margin ===")
CONSTR_R = mp.mpf(10) ** (-30)     # construction allowance per entry (dps-40 build)
def iv_cholesky_psd(diag, off, shift):
    """certify tridiag(diag, off) - shift*I >= 0 by interval Cholesky; True if success."""
    n = len(diag)
    dprev = iv.mpf(diag[0] - shift) + iv.mpf([-CONSTR_R, CONSTR_R])
    if dprev.a <= 0: return False
    for i in range(1, n):
        o = iv.mpf(off[i - 1]) + iv.mpf([-CONSTR_R, CONSTR_R])
        di = iv.mpf(diag[i] - shift) + iv.mpf([-CONSTR_R, CONSTR_R]) - o * o / dprev
        if di.a <= 0: return False
        dprev = di
    return True
for drop in [1, 4]:
    alD, beD, alF, beF, aa, bb, M = CASES[drop]
    for sgn, tag in [(+1, "aJ+bI-V"), (-1, "aJ+bI+V")]:
        # M_sgn = a*J_D + b*I - sgn*(J_F - J_D) = (a+sgn)*J_D - sgn*J_F + b*I
        diag = [(aa + sgn) * alD[j] - sgn * alF[j] + bb for j in range(M)]
        off = [(aa + sgn) * beD[j] - sgn * beF[j] for j in range(M - 1)]
        ok0 = iv_cholesky_psd(diag, off, mp.mpf(0))
        # largest certified margin delta by dyadic trial
        delta = bb / 2
        best = mp.mpf(0)
        for _ in range(12):
            if iv_cholesky_psd(diag, off, delta):
                best = delta; delta = delta * 2
            else:
                delta = delta / 2
            if best and delta <= best: break
        print(f"  drop-{drop} {tag} (a={aa}, b={bb}): PSD {'CERTIFIED' if ok0 else 'FAILED'};"
              f"  certified margin delta >= {mp.nstr(best, 4)}")

print("=== (P4) perturbation wiring: how much gamma-error the certificate tolerates ===")
# entry sensitivity: FD on the whole build wrt a uniform gamma perturbation bound
drop = 1
alD, beD, alF, beF, aa, bb, M = CASES[drop]
eps_g = 1e-7
xsP = [1 / (g + eps_g) ** 2 for g in gF[drop:]]
alP, beP = mp_lanczos(xsP, M)
sens = max(max(abs(float(alP[j] - alF[j])) for j in range(M)),
           max(abs(float(beP[j] - beF[j])) for j in range(M - 1))) / eps_g
row_norm = 3 * sens          # tridiagonal row: |d diag| + 2|d off|  (crude, uniform-shift proxy)
print(f"  measured build sensitivity: max entry drift / |dgamma| = {sens:.3f}"
      f"  ->  ||dM||_inf <= {row_norm:.2f} * max_n|dgamma_n|  (uniform-shift proxy, x2 both ladders)")
print(f"  with certified margin delta ~ 5e-3 (drop-1): tolerated max|dgamma| ~"
      f" {5e-3 / (2 * row_norm):.1e}")
print(f"  quantile residual scale at mp-grade: |f(gamma~)| ~ 1e-30; f' >= rho - sup|S_P'|"
      f" ... rho ~ O(1) vs certified sup|S_P'| = {mp.nstr(Lb, 4)} -- f' sign NOT globally"
      f" certified by the crude Lipschitz alone: the theta-module must also certify the"
      f" LOCAL derivative lower bound. BOTH needs land in the same pending module.")
print("=== (P5) verdict ===")
print("  [CERTIFIED]              sup|S_P'| and the sup|S_P| bound (explicit budgets).")
print("  [CERTIFIED-as-computed]  PSD with margin for all four matrices (above).")
print("  [CONDITIONAL-on-theta]   gamma enclosures; module spec: rigorous enclosure of")
print("     theta and theta' (8 loggamma terms; Stirling with explicit remainder in iv,")
print("     or the arb port on the box) -> |dgamma| <= |f|/inf f' closes the chain.")
print("done.")
