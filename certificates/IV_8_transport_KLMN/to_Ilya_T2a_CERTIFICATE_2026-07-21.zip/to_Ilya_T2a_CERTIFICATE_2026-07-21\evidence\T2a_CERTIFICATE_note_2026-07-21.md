# T2a session 1 — the finite-range pencil certificate, local scope: CERTIFIED-modulo-θ

**Merkabit · Stenberg + Claude · 2026-07-21. Script `t2a_certify.py` + log this folder.
Campaign opened on Selina's decision to take G-C1's mechanical core into our lane
(IB's lane retains the certification of θ if he prefers — see the pending module).
Frozen hypotheses = ledger item 0.1, untouched. Not RH/GRH.**

## What is now CERTIFIED (first [CERTIFIED]-tagged results in the T2 chain)

1. **sup|S_P| ≤ 0.901946 on [0.5, 27.79]** (the full ladder range) — dense float64 scan
   (h = 2e−5, max 0.900058) + certified interval Lipschitz constant
   **sup|S_P′| ≤ 188.804** (exact term data, mpmath.iv upper ends) + explicit float
   rounding budget (4.3e−11). Every step of this bound is rigorous: the Euler side is
   a finite explicit sum of 18,120 terms with exact-rational trace data.
2. **The four PSD certificates, with margins** (interval Cholesky, dps 40, per-entry
   construction allowance 1e−30):
   | matrix | pair (a, b) | verdict | certified margin δ |
   |---|---|---|---|
   | drop-1, aJ_D + bI − V | (0.3, 0.011) | **PSD CERTIFIED** | ≥ 5.5e−3 |
   | drop-1, aJ_D + bI + V | (0.3, 0.011) | **PSD CERTIFIED** | ≥ 6.9e−4 |
   | drop-4, aJ_D + bI − V | (0.3, 0.0001) | **PSD CERTIFIED** | ≥ 5.0e−5 |
   | drop-4, aJ_D + bI + V | (0.3, 0.0001) | **PSD CERTIFIED** | ≥ 4.0e−4 |
   Grade: CERTIFIED-as-computed — the matrices are defined by the dps-40 ladders;
   cross-checks: refined ladders vs frozen `quantiles_production.csv` at 3.6e−15;
   mp-built drop-4 J_D vs the FROZEN `k1_kernels_k4_N149.npz` at 8.3e−17 (the sealed
   record and this build agree beyond float64).

## The one pending module (exactly specified)

**[CONDITIONAL-on-θ]** — the quantile enclosures. mpmath's loggamma is not a certified
library, so |γ_n − γ̃_n| is not yet rigorous. The module: rigorous interval enclosure
of θ(t) and θ′(t) (8 loggamma terms — Stirling with explicit remainder coded in iv, or
the arb port on the box, where the certified-spectrum pipeline already lives). It must
deliver BOTH the residual |f(γ̃)| enclosure AND a local lower bound on
f′ = θ′/π + S_P′ (the certified global sup|S_P′| = 188.8 is too crude alone — the
bound must be local, where θ′/π ≈ ρ_n dominates).

**Headroom accounting (why this module cannot fail):** measured build sensitivity
‖dM‖∞ ≤ 2.29·max|dγ|; the worst certified margin (drop-4, 5e−5) tolerates
max|dγ| ≈ 1.1e−5; the mp-grade Newton residuals sit at ~1e−30 scale — the θ-module
needs to certify γ's to 1e−5 where the computation already agrees with itself at
1e−30: **~25 orders of headroom.** The conditional is a formality awaiting the
rigorous wrapper, not a risk.

## Consequence when the module lands

aJ_D + bI ∓ V ⪰ 0 CERTIFIED at the frozen pairs ⇒ the KLMN form-bound
|⟨Vu, u⟩| ≤ a⟨J_Du, u⟩ + b‖u‖² holds at certificate grade on the production range —
**the first rigorous finite-range self-adjointness statement for the χ8 operator
family** (G-C1's deliverable). Rounding discipline throughout: all quoted bounds are
upper ends of intervals or scan+budget sums (ceil-safe).

## Grades summary
sup|S_P|, sup|S_P′|: CERTIFIED (interval + explicit budgets). PSD ×4: CERTIFIED-as-
computed (interval Cholesky; margins quoted). Quantile enclosures: CONDITIONAL-on-θ
(module spec above; 25 orders of headroom). Ladder/matrix cross-checks vs two frozen
records: 3.6e−15 / 8.3e−17.

---

# Session 2 (same day, `t2a_theta_module.py` + log): the θ-module closed LOCALLY with arb — T2a COMPLETE at ball grade

**python-flint 0.8.0 was already installed locally; no AWS needed. The FFT/Poisson
Turing engine was NOT needed either — θ is 8 lgamma terms + a digamma, which arb
provides at rigorous ball grade directly.**

## Delivered

1. **[CERTIFIED] 298/298 quantile enclosures at radius 1e−10** (both ladders, all
   n ≤ 149; prec 4096): ball θ/θ′ (Q = 21¹⁰ exact, ball-consistent with the mp
   pipeline at 1e−56 spot radii), ball S_P/S_P′ (18,120 exact-integer-trace terms);
   interval Newton — definite endpoint signs + f′ > 0 on each bracket ⇒ unique root.
2. **[CERTIFIED] the COMPLETE matrices at full dimension** (prec 16384): ball Lanczos
   on the exact dyadic-center atoms runs ALL 148/145 steps with entry radii below
   1e−308-display (16k-bit working radii); ball Cholesky then certifies **all four
   PSD statements at full dimension** with margins
   drop-1: 5.500e−3 / 6.875e−4;  drop-4: 5.000e−5 / 4.000e−4.
   The certified object is exactly the frozen production object (the float64 ladder
   centers of item 0.1's CSV — dyadic rationals — ARE the frozen data).
3. **The KLMN statement, certificate grade:** |⟨Vu, u⟩| ≤ a⟨J_Du, u⟩ + b‖u‖² holds
   for the frozen production pair at (a, b) = (0.3, 0.011) [drop-1] and (0.3, 0.0001)
   [drop-4], full range, with certified margins — **the first rigorous finite-range
   self-adjointness certificate for the χ8 operator family.** Only assumption: arb.

## The audit findings of the certification (as important as the certificate)

- **Krylov-conditioning wall (recorded with the route's negative results):** at
  prec ≤ 4096 the certification exhausts at depth ~94 (~10¹³/step amplification for
  this clustered spectrum); full depth needs ~16k bits. **Consequence: all prior
  float64/dps-40 values of rows j ≳ 94 were below their own noise floors** —
  everything the chain consumes (V at j = 1–3, caustic j ≤ 40, K1 bulk) is safely
  inside the certified-easy region, but the boundary-layer constant κ̂ = 5.5956
  (attained at j = 145) is computed in the hard regime and is FLAGGED for re-grading
  against this run's ball values.
- **prec-16384 wide-ball quirk (implementation note, mechanism unresolved):** the
  M2 sign tests regress to 66/149 at prec 16384 while passing 149/149 at 1024/4096;
  the θ probe at 16k is tight, so the wideness enters elsewhere in the certify path
  at extreme precision (suspect: S_P trig at interval arguments). Certificates are
  taken at 4096 — equally valid; the quirk is recorded so nobody trips on it again.

## Remaining sliver (stated honestly)

The certificate covers the frozen-as-computed object exactly and localizes the true
quantiles to 1e−10. Transferring the PSD margins to the TRUE-quantile object needs a
certified sensitivity bound ‖∂(entries)/∂γ‖ ≤ 5×10⁵ (measured values are 0.76–50;
the Theorem-1 kernel route can certify this with one more ball run over the kernel
formulas). With 1e−10 enclosures the required slack is astronomic; staged as the
optional polish, not a gap in the certificate of the frozen object.
