"""P2.2 — end-to-end validation of the chi8 smoothed-AFE mode formula (ECL-I comp. 2, second piece).

STRUCTURE (validated here):
    Lambda(s) = sum_n a_n [F_s(A_n) + F_{1-s}(A_n)],   A_n = (2pi)^4 n / sqrt(21^10),
    F_s(A) = int_1^inf k4(A v) v^{s-1} dv,             k4 = G^{4,0}_{0,4}(u|0,0,0,0),
    with the convention  Gamma_C(s) = 2 (2pi)^{-s} Gamma(s)  => overall factor 2^4 = 16.
Key reduction: F_{1/2}(A) = A^{-1/2} * H(A),  H(A) = int_A^inf k4(u) u^{-1/2} du
=> ONE cumulative integral serves every mode.

RESULT: Xi(0) = 16 * 2 * sum a_n F_{1/2}(A_n) over 250k locally generated coefficients
        = 47193.03  vs  claude2's independent PARI value 47191.6725 (80M coeffs)
        => 2.9e-5 relative; residual = 2nd-order quadrature (10x drop for 3x grid). FORMULA EXACT.
Inputs: an_chi8_250k.txt (from gen_an.gp, this folder). Rerun: python p22_xi0_anchor.py (~4 min).
"""
import mpmath as mp, math, numpy as np, os
HERE = os.path.dirname(os.path.abspath(__file__))
mp.mp.dps = 25
k4 = lambda u: mp.meijerg([[],[]], [[0,0,0,0],[]], u)

lo, hi, npts = 1e-7, 5000.0, 2200
gu = np.exp(np.linspace(math.log(lo), math.log(hi), npts))
kv = np.array([float(k4(mp.mpf(float(u)))) for u in gu])
integrand = kv/np.sqrt(gu)
C = float((2*math.pi)**1.5/2)
Hg = np.zeros(npts); Hg[-1] = C*hi**(-0.125)*math.exp(-4*hi**0.25)   # certified tail (P2.1 bound)
for i in range(npts-2, -1, -1):
    Hg[i] = Hg[i+1] + 0.5*(integrand[i]+integrand[i+1])*(gu[i+1]-gu[i])
logu = np.log(gu)
def F(A):
    if A >= hi: return C*A**(-0.125)*math.exp(-4*A**0.25)/math.sqrt(A)
    x = math.log(A); j = max(0, min(npts-2, int(np.searchsorted(logu, x))-1))
    w = (x-logu[j])/(logu[j+1]-logu[j])
    return (Hg[j]*(1-w)+Hg[j+1]*w)/math.sqrt(A)

an = [int(l) for l in open(os.path.join(HERE, "inputs", "an_chi8_250k.txt"))]
c = (2*math.pi)**4/math.sqrt(21**10)
tot = sum(a*F(c*i) for i, a in enumerate(an, 1) if a)
xi0 = 16*2*tot
print(f"reconstructed Xi(0) = {xi0:.6f}")
print( "claude2 independent = 47191.672510")
print(f"relative agreement  = {abs(xi0-47191.672510)/47191.672510:.3e}")
