"""P2.3 — the chi8 delta-c_k truncation-constant table (dck_table.csv analogue).

Per-mode bound (all t-dependence sits in v^{s-1}, s=1/2+it, so these are t-UNIFORM on any range):
    |d^k/dt^k mode_n| <= 32 |a_n| I_k(A_n),
    I_k(A) = int_1^inf K4B(Av) v^{-1/2} (log v)^k dv,
    K4B(u) = (2pi)^{3/2}/2 u^{-3/8} e^{-4u^{1/4}}   (P2.1-certified upper bound on k4).
Coefficient bound: |a_n| <= d_8(n) <= 128 n^{7/2}  (crude explicit; the e^{-4A^{1/4}} eats it).
Truncation constants:
    dck(k, M) = 32 * sum_{n>M} 128 n^{7/2} I_k(A_n),  A_n = (2pi)^4 n / sqrt(21^10),
summed numerically to 6*M then closed by doubling the last block (super-geometric decay check).
Output: p23_dck_chi8.csv  (rows: M ; columns dc0, dc1, dc2).
NOTE: integrals evaluated on the CERTIFIED bound => results are valid upper bounds up to
quadrature; interval-arithmetic hardening deferred to packaging.
"""
import math, csv, os
HERE = os.path.dirname(os.path.abspath(__file__))
C = (2*math.pi)**1.5/2
K4B = lambda u: C*u**-0.375*math.exp(-4*u**0.25)

def I_k(A, k, n=4000, vmax_pow=6):
    # integrate K4B(Av) v^{-1/2} (log v)^k on [1, e^{vmax_pow}] in log-v, then tail-doubled
    import numpy as np
    x = np.linspace(0, vmax_pow, n)                     # x = log v
    v = np.exp(x)
    f = np.array([K4B(A*vi) for vi in v])*v**0.5*x**k   # dv = v dx -> v^{-1/2}*v = v^{1/2}
    val = np.trapezoid(f, x)
    return val*1.02                                     # 2% headroom for the (checked tiny) tail

cn = (2*math.pi)**4/math.sqrt(21**10)
Ms = [500_000, 1_000_000, 2_000_000, 4_000_000, 8_000_000, 16_000_000, 40_000_000, 80_000_000]
rows = []
for M in Ms:
    dc = [0.0, 0.0, 0.0]
    # geometric blocks n in (M, 6M], block-max bound: 128 n^{7/2} I_k monotone dec. in n past cutoff
    n = M
    while n < 6*M:
        step = max(1, n//200)
        top = min(n+step, 6*M)
        for k in range(3):
            dc[k] += 32*128*(top**3.5)*I_k(cn*(n+1), k)*(top-n)
        n = top
    for k in range(3): dc[k] *= 2.0   # close the >6M tail (decay e^{-4(A)^{1/4}}: block ratio << 1/2)
    rows.append([M]+dc)
    print(f"M={M:>9}: dc0={dc[0]:.3e}  dc1={dc[1]:.3e}  dc2={dc[2]:.3e}", flush=True)
with open(os.path.join(HERE, "outputs", "p23_dck_chi8.csv"), "w", newline="") as f:
    w = csv.writer(f); w.writerow(["M", "dc0", "dc1", "dc2"]); w.writerows(rows)
print("written p23_dck_chi8.csv")
