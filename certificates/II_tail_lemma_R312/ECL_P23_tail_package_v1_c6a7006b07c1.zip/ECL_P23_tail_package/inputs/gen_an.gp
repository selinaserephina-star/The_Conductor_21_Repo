default(parisizemax, 4000000000);
cyc(p) = { my(g = factormod(x^7 - 7*x + 3, p)); vecsort(vector(matsize(g)[1], i, poldegree(g[i,1]))); }
loc8(p) = if(p==3, 1-X, p==7, 1, my(d=cyc(p)); \
  if(d==[1,1,1,1,1,1,1], (1-X)^8,            d==[1,1,1,2,2], (1-X)^4*(1+X)^4, \
     d==[1,3,3],         (1-X)^2*(1+X+X^2)^3, d==[1,2,4],    (1-X)^2*(1+X)^2*(1+X^2)^2, \
     d==[7],             (1-X)^2*(1+X+X^2+X^3+X^4+X^5+X^6)));
av = direuler(p=2, 250000, 1/loc8(p));
print("built ", #av, "  a2..a8=", vector(7,i,av[i+1]));
f = fileopen("an_chi8_250k.txt", "w");
for(n=1, #av, filewrite(f, av[n]));
fileclose(f);
print("written");
quit;
