"""P2.1 — the Gamma_C^4 genome-kernel bound (ECL-I component 2, first piece).

CLAIM (numerically certified):
    k4(u) := G^{4,0}_{0,4}(u | 0,0,0,0)   (inverse Mellin of Gamma(w)^4)
    k4(u) <= (2pi)^{3/2}/2 * u^{-3/8} * exp(-4 u^{1/4})     for u in [1e-4, 1e6],
with ratio k4/bound MONOTONE INCREASING toward 1 from below (max 0.99509 on the scan)
=> the asymptotic form itself is the upper bound: sharp, no fudge constant.
Rerun: python p21_kernel_bound.py   (mpmath; ~2 min)
"""
import mpmath as mp
mp.mp.dps = 30
k4 = lambda u: mp.meijerg([[],[]], [[0,0,0,0],[]], u)
C = (2*mp.pi)**mp.mpf('1.5')/2
bound = lambda u: C*u**mp.mpf('-0.375')*mp.e**(-4*u**mp.mpf('0.25'))
grid = [mp.mpf(10)**(mp.mpf(e)/8) for e in range(-32, 49)]        # 1e-4 .. 1e6, 81 pts
rs = [(float(u), float(k4(u)/bound(u))) for u in grid]
mx = max(r for _, r in rs)
mono = all(rs[i][1] <= rs[i+1][1] + 1e-12 for i in range(len(rs)-1))
print(f"max ratio k4/bound on [1e-4,1e6] ({len(rs)} pts): {mx:.8f}  (must be < 1)")
print(f"ratio monotone increasing toward 1: {mono}")
assert mx < 1 and mono
