"""P2.3 composition -- assembled B_sup(I_j) per ECL SIDE LEMMAS v1, Lemma 2 (TAIL-COMPOSITION).

Lemma 2 (Ilya Balashov, audited CLOSED):  with Xi = C0+e0, Xi' = C1+e1, Xi'' = C2+e2,
|e_k| <= delta_c_k, and |C_k(t)| <= S_k(I) on an interval I,
    B_sup(I) = 2 S1 dc1 + dc1^2 + S0 dc2 + S2 dc0 + dc0 dc2
satisfies sup_I |Q_full - Q_main| <= B_sup(I), so
    inf_I Q_main - B_sup(I) > 0   ==>   Q_full > 0 on I.

THIS SCRIPT (demonstration grade, clearly labeled):
  - delta_c_k at M = 80,000,000 (claude2's actual truncation) from outputs/p23v2_dck_chi8.csv;
  - S_k(I_j) = 2 x (grid max of |Xi^(k)| over I_j widened by one grid point), from claude2's
    independent 6-column PARI curve inputs/gq_curve_chi8.txt (161 pts, t in [0,3.2], step 0.02);
  - inf Q proxy = grid min of Q over I_j;
  - subintervals I_j = [0.2j, 0.2(j+1)], j = 0..15, covering [0,3.2].

CAVEAT (the honest line): grid max x2 is a PROXY for the interval suprema S_k, and grid min
is a PROXY for inf Q. Theorem-grade closure substitutes Ilya's fixed-center Cauchy/DFT
Taylor-jet enclosures for both (the D.3b machinery) -- the delta_c_k column is the part this
package certifies (t-uniform, closed-form); the composition line is shown so the two halves
plug together with no algebra left to do.

Deterministic: stdlib only. Rerun: python p24_bsup_compose.py (<1 s).
Outputs: outputs/bsup_chi8.csv, outputs/bsup_out.txt.
NOT claimed: chi8 interval theorem, GRH(chi8), RH.
"""
import os

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "outputs")
M_USED = 80_000_000
SAFETY = 2.0
STEP = 0.2

# --- delta_c_k at M_USED ---
with open(os.path.join(OUT, "p23v2_dck_chi8.csv")) as f:
    next(f)
    dck = {int(r[0]): [float(x) for x in r[1:4]] for r in (l.split(",") for l in f)}
dc0, dc1, dc2 = dck[M_USED]

# --- claude2 6-column curve: t, Xi, Xi', Xi'', Q, Q/Xi^2 (PARI writes "+4.719167 e4") ---
rows = []
with open(os.path.join(HERE, "inputs", "gq_curve_chi8.txt")) as f:
    for line in f:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        toks, vals = line.split(), []
        for tk in toks:
            if tk.startswith("e") and vals:
                vals[-1] += tk          # rejoin PARI's "mantissa e4" split
            else:
                vals.append(tk)
        try:
            v = [float(x) for x in vals]
        except ValueError:
            continue                    # trailing annotation lines in the raw PARI dump
        if len(v) == 6 and v[0] <= 3.2 + 1e-12:
            rows.append(v)
assert len(rows) == 161, f"expected 161 grid points on [0,3.2], got {len(rows)}"

def fmt(x):
    return f"{x:.6e}"

out_rows, lines = [], []
lines.append(f"delta_c_k at M={M_USED}: dc0={fmt(dc0)}  dc1={fmt(dc1)}  dc2={fmt(dc2)}")
lines.append(f"S_k = {SAFETY:.1f} x grid max |Xi^(k)| (one-point widened); inf Q = grid min.")
lines.append("")
worst = None
for j in range(16):
    lo, hi = j*STEP, (j+1)*STEP
    sel = [r for r in rows if lo - 0.021 <= r[0] <= hi + 0.021]
    S0 = SAFETY*max(abs(r[1]) for r in sel)
    S1 = SAFETY*max(abs(r[2]) for r in sel)
    S2 = SAFETY*max(abs(r[3]) for r in sel)
    infq = min(r[4] for r in [r for r in rows if lo - 1e-12 <= r[0] <= hi + 1e-12])
    bsup = 2*S1*dc1 + dc1*dc1 + S0*dc2 + S2*dc0 + dc0*dc2
    margin = infq/bsup
    ok = infq - bsup > 0
    out_rows.append((lo, hi, S0, S1, S2, infq, bsup, margin, ok))
    if worst is None or margin < worst[7]:
        worst = out_rows[-1]
    lines.append(f"I=[{lo:4.2f},{hi:4.2f}]: S0={fmt(S0)} S1={fmt(S1)} S2={fmt(S2)}"
                 f"  infQ={fmt(infq)}  B_sup={fmt(bsup)}  margin={fmt(margin)}"
                 f"  {'PASS' if ok else 'FAIL'}")
lines.append("")
lines.append(f"all 16 subintervals: B_sup(I_j) < inf Q  -> {all(r[8] for r in out_rows)}")
lines.append(f"worst margin infQ/B_sup = {fmt(worst[7])} on I=[{worst[0]:.2f},{worst[1]:.2f}]")
lines.append("")
lines.append("Demonstration grade: S_k and inf Q are grid proxies (x2 safety on S_k);")
lines.append("theorem grade = same composition with Ilya's Taylor-jet interval enclosures.")

with open(os.path.join(OUT, "bsup_chi8.csv"), "w", newline="\n") as f:
    f.write("t_lo,t_hi,S0,S1,S2,infQ_grid,B_sup,margin,pass\n")
    for r in out_rows:
        f.write(f"{r[0]:.2f},{r[1]:.2f}," + ",".join(fmt(x) for x in r[2:8])
                + f",{int(r[8])}\n")
with open(os.path.join(OUT, "bsup_out.txt"), "w", newline="\n") as f:
    f.write("\n".join(lines) + "\n")
print("\n".join(lines))
print("written outputs/bsup_chi8.csv, outputs/bsup_out.txt")
