# ECL_P23_tail_package — χ₈ Γ_C⁴ genome-kernel tail lemma (P2.1–P2.3 + composition)

**Date:** 2026-07-02
**Builder:** avatar session (Selina + Claude), Merkabit Research
**Prepared for:** Ilya Balashov / Scar–Merkabit ECL registry (registry item ECL-I / P2)
**Object:** χ₈, degree-8 Artin rep of PSL(2,7), conductor 21¹⁰, Γ_C(s)⁴, ε=+1
(passport: `passport_chi8.json`, identical to the one in ECL_chi8_package)

## Audit order (per IB protocol — verify shipped bytes FIRST)

1. verify outer `.sha256` sidecar of the zip;
2. unzip; `sha256sum -c SHA256SUMS.txt` (LF, UTF-8);
3. rerun declared scripts (below); verify SHA256SUMS again (rerun-touched files);
4. compare summary numbers against the registry claims;
5. only then regenerate sidecars if bytes were intentionally rewritten.

Declared rerun scripts (deterministic, byte-identical on rerun, verified at build):

```text
python p23v2_dck_table.py      # ~10 s, stdlib only -> outputs/p23v2_dck_chi8.csv, p23v2_out.txt
python p24_bsup_compose.py     # <1 s,  stdlib only -> outputs/bsup_chi8.csv, bsup_out.txt
python p21_kernel_bound.py     # ~2 min, mpmath     -> compare stdout to outputs/p21_rerun_out.txt
python p22_xi0_anchor.py       # ~4 min, mpmath+numpy -> compare to outputs/p22_rerun_out.txt
```

(`p23v1_dck_table.py` is historical, superseded — see §4; rerun optional, ~8 min.)

## 1. What this package claims

The **tail half** of the χ₈ interval certificate on t ∈ [0,3.2], in the exact notation of
**ECL SIDE LEMMAS v1, Lemma 2 (TAIL-COMPOSITION)**: writing Ξ = C₀+e₀, Ξ′ = C₁+e₁,
Ξ″ = C₂+e₂ for the truncation of the smoothed AFE at cutoff M,

```text
|e_k(t)| ≤ δc_k(M),   k = 0,1,2,   UNIFORM in t (any range; a fortiori [0,3.3]),
```

with the closed-form table `outputs/p23v2_dck_chi8.csv`. At claude2's actual truncation
**M = 80,000,000**:

```text
δc₀ = 4.181981e-09      δc₁ = 3.078281e-10      δc₂ = 4.453713e-11
```

all far below the certificate scale (grid min Q = 6.772945e-7 at t = 3.20).

Composed per Lemma 2,

```text
B_sup(I) = 2 S₁ δc₁ + δc₁² + S₀ δc₂ + S₂ δc₀ + δc₀ δc₂,
```

the demonstration table `outputs/bsup_chi8.csv` gives **B_sup(I_j) < inf Q on all 16
subintervals of width 0.2 covering [0,3.2]**, worst margin inf Q / B_sup ≈ 1.7e3 on
[3.0,3.2] (with ×2 safety on the S_k proxies), growing to ~4e12 near t = 0.

**NOT claimed:** the χ₈ interval theorem (main-term side is Ilya's jets, see §5),
GRH(χ₈), RH. Status: numerically certified constants; interval-arithmetic hardening
available on request (same status language as P2.1).

## 2. The chain (P2.1 → P2.2 → P2.3)

**P2.1 — kernel bound** (`p21_kernel_bound.py`, `outputs/P21_kernel_certification.txt`):

```text
k₄(u) = G^{4,0}_{0,4}(u|0,0,0,0) ≤ (2π)^{3/2}/2 · u^{−3/8} e^{−4u^{1/4}}  on [1e−4, 1e6],
```

ratio monotone increasing to 1 from below, max 0.99509 — asymptotically sharp, no fudge
constant. This is the χ₈ replacement for ζ's e^{−u}: the decay is exp(−4u^{1/4}).

**P2.2 — mode formula + normalization anchor** (`p22_xi0_anchor.py`,
`outputs/P22_xi0_reconstruction.txt`, `P22_refined.txt`):

```text
Λ(s) = 16 Σ_n a_n [F_s(A_n) + F_{1−s}(A_n)],  A_n = (2π)⁴ n / √(21¹⁰),
F_s(A) = ∫₁^∞ k₄(Av) v^{s−1} dv,   convention Γ_C(s) = 2(2π)^{−s}Γ(s) ⇒ factor 2⁴ = 16.
```

Anchor: Ξ(0) reconstructed from 250k locally generated coefficients
(`inputs/an_chi8_250k.txt`, generator `inputs/gen_an.gp`) = **47193.03** vs claude2's
independent PARI value **47191.6725** → 2.9e−5 relative; residual is second-order
quadrature. The mode formula and every constant entering P2.3 are thereby end-to-end
validated against an independent computation.

**P2.3 — the δc_k(M) table** (`p23v2_dck_table.py`): per-mode t-uniform bound

```text
|d^k/dt^k mode_n(t)| ≤ 32 |a_n| I_k(A_n),
I_k(A) = ∫₁^∞ K4B(Av) v^{−1/2} (log v)^k dv     (K4B = the P2.1-certified bound),
```

(32 = 2 from the θ-split × 16 from the Γ_C convention; the t-dependence sits entirely in
v^{±it}, whose k-th t-derivative has magnitude v^{−1/2}(log v)^k — this is why the δc_k
are t-uniform), then the tail sum closed by the **Rankin coefficient bound** (§3).

## 3. The Rankin coefficient bound (the v2 step — documentation requested)

Coefficient bound [T]: χ₈ has unitary Satake parameters, so |a_n| ≤ d₈(n), the 8-fold
divisor function, with Dirichlet series Σ d₈(n) n^{−σ} = ζ(σ)⁸. Rankin's trick: for any
σ > 1,

```text
Σ_{n>M} d₈(n) I_k(A_n) ≤ [sup_{n>M} n^σ I_k(A_n)] · Σ_{n>M} d₈(n) n^{−σ}
                       ≤ (M+1)^σ I_k(A_{M+1}) · ζ(σ)⁸,
```

the sup attained at n = M+1 because n^σ I_k(A_n) is monotone decreasing past every
tabulated M (the exponential rate d/dn[4A_n^{1/4}] = A_n^{1/4}/n exceeds σ/n there;
**verified numerically at the chosen σ, printed in `p23v2_out.txt`**). Hence

```text
δc_k(M) = 32 · min_{σ ∈ {1.05, 1.10, …, 6.00}} ζ(σ)⁸ (M+1)^σ I_k(A_{M+1}),
```

with ζ(σ) evaluated as the conservative upper bound Σ_{n≤10⁴} n^{−σ} + 10⁴⁽¹⁻σ⁾/(σ−1),
and I_k by trapezoid quadrature ×1.02 headroom (refinement + truncation self-checks
printed in `p23v2_out.txt`: both ≤ 1e−8 relative, i.e. absorbed by the headroom).
Every ingredient errs on the upper side, so the tabulated δc_k are valid upper bounds.

## 4. v1 vs v2 provenance

`p23v1_dck_table.py` + `outputs/p23_dck_chi8.csv` (v1, historical): same I_k machinery
but the pointwise bound d₈(n) ≤ 128 n^{7/2} — mechanics right, constants astronomically
useless (δc₀ ~ 4e13 at M = 80M). Superseded by the Rankin bound; kept for provenance.
The v2 table in `outputs/` is regenerated by the shipped script; it agrees with the
transcript-level v2 table circulated earlier to 3–5 significant digits at M ≥ 40M and is
a few % **tighter** at smaller M (finer σ grid); both are valid upper bounds — the
packaged values supersede.

## 5. What remains for theorem grade (division of labor)

This package certifies the δc_k column of the TAIL-COMPOSITION lemma. The composition
demonstration (`p24_bsup_compose.py`) uses **grid proxies** for the interval data: S_k =
2 × (grid max |Ξ^(k)| over the widened subinterval, from claude2's independent 6-column
curve `inputs/gq_curve_chi8.txt` — SHA-256 identical to the copy in ECL_chi8_package)
and inf Q = grid min. Theorem-grade closure substitutes Ilya's fixed-center Cauchy/DFT
Taylor-jet enclosures (the D.3b machinery) for S_k and inf Q_main in the same formula —
no algebra is left on the tail side, and the δc_k are t-uniform, so one table serves any
subinterval partition of [0,3.2] (or beyond, to any range where a curve exists).

ζ precedent: the same split closed [219.75,220.0] with the closed-form tail matching
Ilya's independent Arb err16 to 4 significant figures (2.924e−155 vs 2.9235917837e−155).

## 6. File map

```text
p23v2_dck_table.py            THE deliverable: δc_k(M) generator (stdlib, deterministic)
p24_bsup_compose.py           Lemma-2 composition demo (stdlib, deterministic)
p21_kernel_bound.py           P2.1 kernel-bound certification (mpmath)
p22_xi0_anchor.py             P2.2 Ξ(0) anchor (mpmath+numpy; reads inputs/)
p23v1_dck_table.py            v1, superseded (provenance)
passport_chi8.json            analytic passport (identical to ECL_chi8_package)
inputs/an_chi8_250k.txt       250k local coefficients (P2.2 input)
inputs/gen_an.gp              PARI generator for the above
inputs/gq_curve_chi8.txt      claude2's 6-column curve (S_k / inf Q proxies; provenance hash)
outputs/p23v2_dck_chi8.csv    THE δc_k(M) table (M = 1M…80M)
outputs/p23v2_out.txt         run log: σ*, monotonicity + quadrature certificates
outputs/bsup_chi8.csv         B_sup(I_j) vs inf Q, 16 subintervals, all PASS
outputs/bsup_out.txt          composition run log
outputs/p21_rerun_out.txt     P2.1 rerun stdout (this build)
outputs/p22_rerun_out.txt     P2.2 rerun stdout (this build)
outputs/P21_kernel_certification.txt   original P2.1 certification summary
outputs/P22_xi0_reconstruction.txt     original P2.2 log (pre-2⁴ fix, 16.00× low — the
outputs/P22_refined.txt                convention-factor discovery) + corrected anchor
outputs/p23_dck_chi8.csv      v1 table (superseded, provenance)
outputs/p23_dck_output.txt    v1 run log
P23_status.json               registry block (machine-readable)
MANIFEST.json                 file inventory with SHA-256
SHA256SUMS.txt                LF, UTF-8; `sha256sum -c` clean
```
