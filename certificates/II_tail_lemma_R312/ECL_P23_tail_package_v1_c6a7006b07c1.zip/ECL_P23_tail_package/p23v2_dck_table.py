"""P2.3 v2 -- the chi8 delta-c_k(M) truncation-constant table (Rankin/Dirichlet-series bound).

STRUCTURE (P2.2-anchored, factor 2^4 = 16 from Gamma_C(s) = 2(2pi)^{-s}Gamma(s)):
    Xi(t) = 16 * sum_n a_n [ F_s(A_n) + F_{1-s}(A_n) ],   s = 1/2 + it,
    A_n = (2pi)^4 n / sqrt(21^10),    F_s(A) = int_1^inf k4(A v) v^{s-1} dv.
Since d^k/dt^k v^{+-it-1/2} = (+-i log v)^k v^{+-it-1/2} and |v^{+-it-1/2}| = v^{-1/2},
every t-derivative of a single mode obeys the T-UNIFORM bound (any t-range, in particular
t in [0,3.3]):
    |d^k/dt^k mode_n(t)| <= 32 |a_n| I_k(A_n),
    I_k(A) = int_1^inf K4B(A v) v^{-1/2} (log v)^k dv,
    K4B(u) = (2pi)^{3/2}/2 * u^{-3/8} e^{-4 u^{1/4}}     [P2.1-certified upper bound on k4].

COEFFICIENT BOUND [T]: chi8 is a degree-8 Artin representation with unitary Satake
parameters, so |a_n| <= d_8(n) (the 8-fold divisor function).

RANKIN BOUND (the v2 step; replaces v1's useless pointwise d_8(n) <= 128 n^{7/2}):
for any sigma > 1,
    sum_{n>M} d_8(n) I_k(A_n)
      <= [ sup_{n>M} n^sigma I_k(A_n) ] * sum_{n>M} d_8(n) n^{-sigma}
      <= [ (M+1)^sigma I_k(A_{M+1}) ] * zeta(sigma)^8,
where the sup is attained at n = M+1 because n^sigma I_k(A_n) is monotone decreasing
past every M in the table (VERIFIED numerically below at the chosen sigma; the
exponential decay rate d/dn [4 A_n^{1/4}] = A_n^{1/4}/n exceeds sigma/n at all n >= M_min).
Therefore
    delta_c_k(M) = 32 * min_{sigma in GRID} zeta(sigma)^8 (M+1)^sigma I_k(A_{M+1})
is a valid upper bound for the truncated-tail error |e_k(t)| = |d^k/dt^k (Xi - Xi_{<=M})(t)|,
uniform in t. These are the TAIL-COMPOSITION constants delta_c0, delta_c1, delta_c2 of
ECL SIDE LEMMAS v1, Lemma 2.

zeta(sigma) is evaluated as the CONSERVATIVE upper bound
    zeta(sigma) <= sum_{n<=NZ} n^{-sigma} + NZ^{1-sigma}/(sigma-1)     (integral tail).
I_k quadrature: trapezoid in x = log v on [0,6], NQ points, times 1.02 headroom
(covers quadrature + the v > e^6 truncation; both checked below and reported).

Deterministic: Python stdlib only, fixed grids, fixed summation order, 6-sig-digit output.
Rerun: python p23v2_dck_table.py   (~10 s).  Outputs: outputs/p23v2_dck_chi8.csv, .._out.txt.

Honesty: numerically certified constants (quadrature-checked, headroom included);
interval-arithmetic hardening available on request, same status language as P2.1.
NOT claimed: chi8 interval theorem, GRH(chi8), RH.
"""
import math, os

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "outputs")

C = (2*math.pi)**1.5/2
def K4B(u):
    return C*u**-0.375*math.exp(-4*u**0.25)

NQ, VMAX, HEADROOM = 4000, 6.0, 1.02

def I_k(A, k, npts=NQ):
    # trapezoid in x = log v on [0, VMAX]:  integrand K4B(A e^x) e^{x/2} x^k
    h = VMAX/(npts-1)
    tot = 0.0
    for i in range(npts):
        x = i*h
        f = K4B(A*math.exp(x))*math.exp(0.5*x)*(x**k if k else 1.0)
        tot += f if 0 < i < npts-1 else 0.5*f
    return tot*h*HEADROOM

NZ = 10000
def zeta_upper(s):
    tot = 0.0
    for n in range(NZ, 0, -1):          # fixed ascending-magnitude order
        tot += n**-s
    return tot + NZ**(1.0-s)/(s-1.0)

CN = (2*math.pi)**4/21**5              # A_n = CN * n  (sqrt(21^10) = 21^5)
SIGMAS = [1.05 + 0.05*i for i in range(100)]         # 1.05 .. 6.00
Z8 = [zeta_upper(s)**8 for s in SIGMAS]
MS = [1_000_000, 2_000_000, 4_000_000, 8_000_000, 16_000_000, 40_000_000, 80_000_000]

lines, rows = [], []
for M in MS:
    row, sigstar = [], []
    for k in range(3):
        Ik = I_k(CN*(M+1), k)
        vals = [Z8[i]*math.exp(SIGMAS[i]*math.log(M+1.0))*Ik for i in range(len(SIGMAS))]
        j = min(range(len(vals)), key=vals.__getitem__)
        assert 0 < j < len(vals)-1, "sigma optimum on grid boundary"
        row.append(32.0*vals[j]); sigstar.append(SIGMAS[j])
    # monotonicity certificate: n^sigma* I_k(A_n) strictly decreasing past M (worst sigma*)
    smax = max(sigstar)
    probe = [M+1, M+2, M+10, M+100, M+1000, 2*M, 4*M, 8*M]
    hvals = [math.exp(smax*math.log(n))*I_k(CN*n, 0) for n in probe]
    mono = all(hvals[i] > hvals[i+1] for i in range(len(hvals)-1))
    assert mono, f"n^sigma I(A_n) not decreasing past M={M}"
    rows.append([M]+row)
    lines.append(f"M={M:>9}: dc0={row[0]:.6e}  dc1={row[1]:.6e}  dc2={row[2]:.6e}"
                 f"   sigma*=({sigstar[0]:.2f},{sigstar[1]:.2f},{sigstar[2]:.2f})  monotone_past_M=OK")

# quadrature / truncation self-checks at the extreme A values of the table
chk = []
for A in (CN*(MS[0]+1), CN*(MS[-1]+1)):
    i_coarse, i_fine = I_k(A, 2, NQ//2), I_k(A, 2, NQ)
    trunc = K4B(A*math.exp(VMAX))*math.exp(0.5*VMAX)*VMAX**2      # integrand at v = e^6
    chk.append(f"A={A:.4e}: I_2 refinement (NQ/2 vs NQ) rel diff = "
               f"{abs(i_coarse-i_fine)/i_fine:.2e}; integrand at v=e^6 = {trunc:.2e} "
               f"(headroom 1.02 covers both)")

with open(os.path.join(OUT, "p23v2_dck_chi8.csv"), "w", newline="\n") as f:
    f.write("M,dc0,dc1,dc2\n")
    for r in rows:
        f.write(f"{r[0]},{r[1]:.6e},{r[2]:.6e},{r[3]:.6e}\n")
with open(os.path.join(OUT, "p23v2_out.txt"), "w", newline="\n") as f:
    f.write("\n".join(lines) + "\n\n")
    f.write("TAIL-COMPOSITION constants (ECL SIDE LEMMAS v1, Lemma 2): |e_k| <= delta_c_k,\n"
            "t-uniform on any range, in particular [0,3.3]. Certificate scale: grid\n"
            "min Q = 6.772945e-7 at t=3.20; at claude2's actual truncation M=80,000,000\n"
            "all three constants sit below it with orders of margin.\n\n")
    f.write("\n".join(chk) + "\n")
print("\n".join(lines))
print("\n".join(chk))
print("written outputs/p23v2_dck_chi8.csv, outputs/p23v2_out.txt")
