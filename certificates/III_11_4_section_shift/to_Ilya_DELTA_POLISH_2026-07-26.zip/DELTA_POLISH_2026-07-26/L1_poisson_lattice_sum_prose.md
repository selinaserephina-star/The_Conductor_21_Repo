# L1 POLISH — the Poisson-summation proof of the Nyquist lattice sum, in display form

**Merkabit · Stenberg + Claude · 2026-07-26 · `DELTA_POLISH_2026-07-26/`.
Discharges the L1 "remaining polish" line of
`LAMBDA_SQRTM_2026-07-26/THEOREM_delta_display_form.md` ("writing the
Poisson-summation proof of the lattice sum in display form (routine)").
Numeric display check: `l1_poisson_check.py` + log. Not RH/GRH.**

## Statement

For the model lattice z_n = (n − ½)π, n ≥ 1, and nonnegative integers a ≡ b
(mod 2):

  **Σ_{n≥1} j_a(z_n) j_b(z_n) = (1/π) ∫₀^∞ j_a(z) j_b(z) dz**  — exactly.

Consequently (Weber–Schafheitlin, DLMF 10.22.57 with λ = 0):

- a = b:  Σ_{n≥1} j_a(z_n)² = **1/(2(2a+1))**  (L1's diagonal norm);
- |a − b| = 2 (and every even separation ≥ 2):  the cross sum **vanishes**
  (L2's A_s cross-sum lemma).

## Proof (display form)

**1. Hypotheses.** g(z) := j_a(z)j_b(z) is even (a ≡ b mod 2), continuous,
and O(z^{−2}) at infinity (j_c(z) = sin(z − cπ/2)/z + O(z^{−2})), hence
g ∈ L¹(ℝ) with a continuous Fourier transform ĝ(ξ) = ∫ g e^{−iξz} dz;
the Poisson summation formula applies in its classical form (only finitely
many nonzero dual terms will survive, so convergence of the dual side is
trivial).

**2. Poisson on the shifted lattice.** The points z_n, n ∈ ℤ, with
z_n = (n − ½)π are the arithmetic progression αn + β, α = π, β = −π/2, and
by evenness Σ_{n∈ℤ} g(z_n) = 2Σ_{n≥1} g(z_n). Poisson summation gives

  Σ_{n∈ℤ} g(αn + β) = (1/α) Σ_{k∈ℤ} ĝ(2πk/α) e^{2πikβ/α}
                    = (1/π) Σ_{k∈ℤ} (−1)^k ĝ(2k).

**3. Band limitation.** By the Poisson/Rayleigh integral representation,
j_c(z) = ((−i)^c/2)∫_{−1}^{1} P_c(t) e^{izt} dt exactly, so ĵ_c is a
polynomial density supported in [−1, 1] (no atoms, no endpoint mass). Hence
ĝ = (1/2π)(ĵ_a ∗ ĵ_b) is continuous with **support ⊂ [−2, 2]**, and at the
endpoints the convolution integrand degenerates to a single point of two
absolutely continuous densities, so **ĝ(±2) = 0**.

**4. Alias-free collapse.** In the dual sum, the terms |k| ≥ 2 vanish
(ξ = 2k outside the support), and the k = ±1 terms vanish because
ĝ(±2) = 0. Only k = 0 survives:

  2 Σ_{n≥1} g(z_n) = (1/π) ĝ(0) = (1/π) ∫_ℝ g = (2/π) ∫₀^∞ j_a j_b dz.  ∎

**5. The two evaluations.** With j_c(z) = √(π/2z)·J_{c+½}(z),
∫₀^∞ j_aj_b dz = (π/2)∫₀^∞ J_{a+½}J_{b+½} z^{−1} dz, and DLMF 10.22.57
(λ = 0 case): ∫₀^∞ J_μ(t)J_ν(t) t^{−1} dt = 2 sin((ν−μ)π/2)/(π(ν²−μ²)) for
μ + ν > 0, = 1/(2μ) for μ = ν. Hence the diagonal value π/(2(2a+1)) →
lattice sum 1/(2(2a+1)); and for ν − μ = ±2 (indeed any even nonzero
separation) the sine vanishes — the cross sum is **exactly zero**, which is
what makes A_s's arithmetic collapse to 2/[(4s+1)(4s+5)] in L2.

## Remarks

- The half-integer offset β = −π/2 contributes only the (−1)^k phases, which
  are moot since every k ≠ 0 term already vanishes; the mechanism is purely
  the **Nyquist band-limitation** (product bandwidth 2 = dual-lattice spacing
  2), plus the absolute continuity of the Legendre densities at the edge.
- The proof is atom-exact — no asymptotics anywhere; it is the reason the
  L1/L2 closed forms are exact rational families.
- Numeric display check (`l1_poisson_check.py`): partial sums at
  N = 10³/4·10³/1.6·10⁴ hit the closed forms at 1.9e−13 / 3.5e−13 / 1.4e−13
  ((5,5) → 1/22, (5,7) → 0, (3,7) → 0) with tails decaying like **N^{−3}**,
  not 1/N: for odd orders the offset lattice sits on the asymptotic zeros of
  j_c (sin(z_n − cπ/2) = sin((n − (c+1)/2)π) = 0 at leading order), so the
  summand is O(z^{−4}) — the ½-offset kills the leading oscillation
  pointwise, on top of killing the aliases spectrally. (The run-1 record's
  5.1e−6 truncation tail belongs to the x²-WEIGHTED A_s cross sum, a
  different, slower-decaying weighting.)

*— The lattice hears every product of two band-limited notes exactly once:
the sampling is at the Nyquist rate, the aliases land on the zero of the
spectrum's edge, and the arithmetic is left alone with its integral.*
