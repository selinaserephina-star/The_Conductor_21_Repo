r"""
l5_transition_constants2.py -- L5 polish, corrected extraction. The first
pass (l5_transition_constants.py, kept as the record) divided the residual by
Ai' and was polluted near Ai''s zero (w = -1.0188, i.e. t = +0.809): the
t = +0.9 row jumped to -0.904 against a smooth trend, and the cubic fit +
rational hunt overfitted (denominator-450 "matches" = noise).

Corrected method -- MULTIPLY, never divide: fit the residual
    Rsd(nu, t) := nu/2^{2/3} * [ J_nu(nu + t nu^{1/3}) - (2^{1/3}/nu^{1/3}) Ai(-2^{1/3}t) ]
jointly over a t-grid against the design
    Rsd = sum_k b_k t^k Ai'(-2^{1/3}t)  +  nu^{-1/3} sum_k c_k t^k Ai(-2^{1/3}t)
(the second block absorbs the next order and decontaminates the first), at
nu = 1600, 6400, 25600; Richardson the b_k in nu^{-2/3}.  Same for Y with
-Bi/-Bi'.  Output: the displayed polynomial B0(t) with per-coefficient
convergence gaps, and a small-denominator rational comparison ONLY where the
gap supports it.
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (Delta polish, item 4).
"""
import numpy as np
import mpmath as mp

mp.mp.dps = 40
C13 = mp.mpf(2) ** (mp.mpf(1) / 3)
KMAX = 3          # cubic in t per channel
NUS = (400, 1600, 6400)   # 25600 hits mpmath's large-z hypsum trap (known)


def residuals(kind, nu, tgrid):
    out = []
    nu = mp.mpf(nu)
    for t in tgrid:
        w = -C13 * t
        if kind == 'J':
            lead = C13 * mp.airyai(w)
            val = mp.besselj(nu, nu + t * nu ** (mp.mpf(1) / 3))
        else:
            lead = -C13 * mp.airybi(w)
            val = mp.bessely(nu, nu + t * nu ** (mp.mpf(1) / 3))
        r = nu / 2 ** (mp.mpf(2) / 3) * (val - lead / nu ** (mp.mpf(1) / 3))
        out.append(float(r))
    return np.array(out)


def design(kind, nu, tgrid):
    cols = []
    for k in range(KMAX + 1):
        col = []
        for t in tgrid:
            w = -C13 * t
            ap = float(mp.airyai(w, 1)) if kind == 'J' else -float(mp.airybi(w, 1))
            col.append(float(t) ** k * ap)
        cols.append(col)
    for k in range(KMAX + 1):
        col = []
        for t in tgrid:
            w = -C13 * t
            a = float(mp.airyai(w)) if kind == 'J' else -float(mp.airybi(w))
            col.append(float(nu) ** (-1.0 / 3) * float(t) ** k * a)
        cols.append(col)
    return np.column_stack(cols)


def main():
    tgrid = [mp.mpf(x) / 20 for x in range(-28, 29, 2)]
    r = 4.0 ** (2.0 / 3)
    for kind in ('J', 'Y'):
        Bs = []
        for nu in NUS:
            y = residuals(kind, nu, tgrid)
            X = design(kind, nu, tgrid)
            beta, _, _, _ = np.linalg.lstsq(X, y, rcond=None)
            Bs.append(beta[:KMAX + 1])
        Bs = np.array(Bs)
        b01 = (r * Bs[1] - Bs[0]) / (r - 1)
        b12 = (r * Bs[2] - Bs[1]) / (r - 1)
        b = (r ** 2 * b12 - b01) / (r ** 2 - 1)
        gap = np.abs(b12 - b01)
        names = ("const", "t", "t^2", "t^3")
        print(f"== {kind}-side  B0(t) = sum b_k t^k  (Richardson over nu = {NUS}) ==")
        for k in range(KMAX + 1):
            line = f"  b[{names[k]}] = {b[k]:+.9f}   (conv gap {gap[k]:.1e})"
            if gap[k] < 3e-4:
                best = None
                for pnum in range(-40, 41):
                    for pden in (1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 14, 15, 20,
                                 21, 28, 30, 35, 42, 70):
                        d = abs(b[k] - pnum / pden)
                        if best is None or d < best[0]:
                            best = (d, pnum, pden)
                d, pnum, pden = best
                if d < 5 * gap[k] + 1e-6:
                    line += f"   ~ {pnum}/{pden} (diff {d:.1e})"
            print(line)


if __name__ == '__main__':
    main()
