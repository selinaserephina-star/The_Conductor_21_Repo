# FINDINGS — Δ POLISH (menu item 4): three of the five debts DISCHARGED tonight. (1) The Δ-chain is INTERVAL-CERTIFIED at sample (j, n) — full arb port, radii ≤ 1e−604, both frozen-log targets enclosed. (2) L5's transition envelope constant is DISPLAYED: B₀(t) = (3/10)t² (Y-side pinned to 2e−6; DLMF 10.19(iii) cited). (3) L1's Poisson lattice-sum proof written in display form (+ a bonus: the ½-offset kills the leading oscillation pointwise — partial sums decay N^{−3}). Deferred with routes stated: a's closed form (inner matching integral); §11.5 full prose expansion (audit-pending — dated addendum added instead).

**Merkabit · Stenberg + Claude · 2026-07-26 (night) ·
`DELTA_POLISH_2026-07-26/`** (new folder — `LAMBDA_SQRTM_2026-07-26/` stays
sealed-v6, untouched). Scripts + logs: `delta_chain_interval_cert.py`,
`l5_transition_constants.py` (first pass, kept as the record of the
division-by-Ai′ artifact), `l5_transition_constants2.py` (corrected),
`l1_poisson_check.py`; prose: `L1_poisson_lattice_sum_prose.md`.
**Not RH/GRH.**

## 1. Δ-chain interval certification (the staged flint item — DONE)

Full python-flint arb port of the exact rational chain
(`lambda_chain_highj.py` conventions, read-only): spherical j/y upward
recurrence in balls; head values by the small-z series with a rigorous
truncation ball (tail ≤ 2× first dropped term, ratio < 0.3); the 4×4
equilibrated tail-Gram solve via rigorous arb LU; certified Airy target.
prec = 2200 bits.

- **Enclosure radii: 1e−604 … 1e−660** on every certified quantity
  (F_chain, F_full, σ, Δ_tot, Δ_head, Δ_wt, B̃/B, 8π(AiBi)′(w)) at
  (j, n) = (54; 35, 37, 40) and (140; 92, 93).
- **Both frozen-log targets ENCLOSED** (j = 54, n = 37: Δ_tot +0.6362,
  F 1.5185; j = 140, n = 92: +0.5552, 2.3342) — the mpmath dps-220 chain is
  certified correct at the sample points.
- Additivity Δ_tot = Δ_head + Δ_wt verified inside the balls.
- Sample values now at certified grade: Δ_tot(54, 37) = +0.6362172275…,
  Δ_tot(140, 92) = +0.5551659676…, B̃/B(54) = 0.864898427316…,
  B̃/B(140) = 0.944916277527… (radii as above).

## 2. L5 envelope constant DISPLAYED: B₀(t) = (3/10)t²

The transition-region substitution L5 uses (J_{ν+a}, Y_{ν+a} →
(2/ν)^{1/3}{Ai, −Bi}(w + aδ)) has first correction

  J_ν(ν + tν^{1/3}) = (2^{1/3}/ν^{1/3})·Ai(−2^{1/3}t)
                    + (2^{2/3}/ν)·**(3/10)t²**·Ai′(−2^{1/3}t) + O(ν^{−5/3}),

and identically for Y with (−Bi, −Bi′) — DLMF §10.19(iii) is the citation;
the constant is now pinned OUR side: joint two-channel least-squares
(multiply-by-Ai′ design, never divide), ν = 400/1600/6400,
Richardson in ν^{−2/3}: **Y-side t² coefficient 0.299998029 (conv gap
2.1e−4, diff from 3/10 = 2.0e−6), all other cubic coefficients zero at
their gaps**; J-side consistent (0.3004, weaker resolution — the Ai-decay
side conditions the fit). First-pass artifact recorded: dividing the
residual by Ai′ pollutes near Ai′'s zero (t = +0.809) — the t = +0.9 row
jumped to −0.904 and the rational hunt overfitted (denominator-450
"matches" = noise). Multiply, never divide.
(The ζ-uniform Olver constants A₁(0) = −1/225, B₀^{Olver}(0) = 2^{1/3}/70 of
the caustic lane were already verified corpus-side — ledger §1.3; this is
the transition-variable version L5 actually substitutes.)

## 3. L1 Poisson prose WRITTEN (`L1_poisson_lattice_sum_prose.md`)

Display-form proof: Poisson on the shifted lattice (phases (−1)^k), exact
Rayleigh band-limitation (ĵ_c = Legendre density on [−1,1], no atoms) ⇒
ĝ supported in [−2,2], continuous, ĝ(±2) = 0 ⇒ every alias term vanishes ⇒
Σ_{n≥1} j_aj_b(z_n) = (1/π)∫₀^∞ j_aj_b — exactly; Weber–Schafheitlin
(DLMF 10.22.57) evaluates: diagonal 1/(2(2a+1)), every even-separation cross
sum 0. **Bonus finding:** the ½-offset also kills the leading oscillation
POINTWISE (odd-order j's have asymptotic zeros on this lattice) ⇒ partial
sums converge like N^{−3} (measured: 1.4e−13…3.5e−13 at N = 1.6e4) — the
lattice is doubly matched to the odd system.

## 4. Deferred, with routes (honest scorecard)

| debt | status |
|---|---|
| interval cert of the Δ-chain at sample (j, n) | **DONE** (§1) |
| L5 DLMF envelope constants | **DONE** (§2) |
| L1 Poisson prose | **DONE** (§3) |
| a = −0.770's closed form | **DEFERRED** — the route stands as §Z.6 states it (inner first-order profile matching: ∫[g₁ − κ/τ-tail] + boundary terms); candidate matching at the current 3–4 pinned digits is underdetermined and was not attempted beyond a sanity look — deriving g₁ is a session of its own |
| Paper A §11.5 prose expansion | **PARTIAL by design** — §11.5 already carries the full statement + proof layout; a dated addendum recording tonight's three upgrades was added; the full lemma-ladder prose expansion is deferred until AFTER the IB v6 audit (which may rename/adjust the theorem) to avoid churn against the audit |

## 5. Cautions

- The certification covers the SAMPLE points (the staged ask); it is not an
  all-(j, n) certificate — the chain's uniformity claims rest on the theorem,
  not on this run.
- The first-pass L5 numbers (cubic fit with denominator-450 rationals) are
  ARTIFACT-grade — do not quote; only B₀(t) = (3/10)t² with the §2 gaps.
- Nothing was added to `LAMBDA_SQRTM_2026-07-26/` (sealed-v6 home intact).

*— Stenberg + Claude, 2026-07-26, night. Three debts paid at the counter,
two left with signed IOUs and the route to the bank written on them.*
