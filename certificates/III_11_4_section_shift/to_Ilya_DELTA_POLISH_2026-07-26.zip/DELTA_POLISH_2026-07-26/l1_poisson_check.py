r"""
l1_poisson_check.py -- numeric display check for the L1 Poisson lattice-sum
prose (L1_poisson_lattice_sum_prose.md): partial sums of j_a(z_n)j_b(z_n)
over z_n = (n-1/2)pi converge to the closed forms at the 1/N tail rate;
Richardson removes the tail.  Diagonal (5,5) -> 1/22; cross (5,7) -> 0;
(3,7) [separation 4] -> 0.  -- Stenberg + Claude, 2026-07-26.
"""
import mpmath as mp

mp.mp.dps = 30
PI = mp.pi


def j(a, z):
    return mp.sqrt(PI / (2 * z)) * mp.besselj(a + mp.mpf(1) / 2, z)


def partial(a, b, N):
    return mp.fsum(j(a, (mp.mpf(2 * n) - 1) * PI / 2)
                   * j(b, (mp.mpf(2 * n) - 1) * PI / 2) for n in range(1, N + 1))


def main():
    for a, b, tgt in ((5, 5, mp.mpf(1) / 22), (5, 7, mp.mpf(0)), (3, 7, mp.mpf(0))):
        vals = [partial(a, b, N) for N in (1000, 4000, 16000)]
        # Richardson at 1/N (ratio 4)
        v01 = (4 * vals[1] - vals[0]) / 3
        v12 = (4 * vals[2] - vals[1]) / 3
        v = (16 * v12 - v01) / 15
        print(f"(a,b) = ({a},{b}): partials "
              + " ".join(mp.nstr(x - tgt, 3) for x in vals)
              + f"  | Richardson - target = {mp.nstr(v - tgt, 3)}")


if __name__ == '__main__':
    main()
