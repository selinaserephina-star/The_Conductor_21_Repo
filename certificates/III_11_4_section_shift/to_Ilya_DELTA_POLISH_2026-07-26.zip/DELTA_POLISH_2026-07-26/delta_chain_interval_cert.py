r"""
delta_chain_interval_cert.py -- THE DELTA-CHAIN INTERVAL CERTIFICATION at
sample (j, n)  (item-4 polish debt of NEXT_SESSION_TASK_infinite_side.md;
staged in THEOREM_delta_display_form.md's closing list: "interval/arb
certification of the chain at sample (j, n) (local flint available)").

Full python-flint arb port of the exact rational chain of
LAMBDA_SQRTM_2026-07-26/lambda_chain_highj.py (read-only reference; nothing
written there):
  - spherical j/y by upward recurrence IN BALLS (orders <= 1.06 z: stable,
    radii tracked rigorously),
  - head values by the explicit small-z series WITH a rigorous truncation
    ball (tail majorized by twice the first dropped term -- ratio < 0.3),
  - the equilibrated 4x4 tail-Gram solve via arb_mat.solve (rigorous LU),
  - Airy target 8*pi*(AiBi)'(w) via arb's certified Airy.
Certified quantities per (j, n): F_chain, F_full, sigma, Delta_tot,
Delta_head, Delta_wt, and the Airy head target.  (The U-display column of the
float script is an approximation layer, not part of the exact chain -- not
certified here, by design.)
Cross-check: the frozen-log targets recorded in the sealed script's docstring
  j=54  n=37: Dtot +0.6362, F 1.5185
  j=140 n=92: Dtot +0.5552, F 2.3342
must fall inside (mid +/- rad) at 4-digit grade.
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (Delta polish, item 4).
"""
import time
from flint import arb, arb_mat, ctx

PREC = 2200          # bits; the mpmath chain ran at dps 220 (~730 bits)
ctx.prec = PREC
PI = arb.pi()
BALL1 = arb(0, 1)    # the interval [-1, 1] for rigorous tail balls


def sph_tables(z, Lmax):
    sz, cz = z.sin(), z.cos()
    j = [sz / z, sz / z ** 2 - cz / z]
    y = [-cz / z, -cz / z ** 2 - sz / z]
    for l in range(1, Lmax):
        j.append((2 * l + 1) / z * j[l] - j[l - 1])
        y.append((2 * l + 1) / z * y[l] - y[l - 1])
    return j, y


def dfact_log(n):
    m = (n - 1) // 2
    return (m + 1) * arb(2).log() + (arb(m) + arb(3) / 2).lgamma() - PI.log() / 2


def sph_j_small(l, z, maxterms=500):
    s = arb(1)
    t = arb(1)
    tail = None
    for m_ in range(1, maxterms):
        t *= (-z ** 2 / 2) / (m_ * (2 * l + 2 * m_ + 1))
        s += t
        if abs(t).mid() < arb(2) ** (-PREC - 30):
            tail = 2 * abs(t)
            break
    assert tail is not None, "series did not converge"
    s += tail * BALL1                      # rigorous truncation ball
    return ((l * z.log()) - dfact_log(2 * l + 1)).exp() * s


def kap(s):
    return (2 * (arb(4 * s) + 3)).sqrt()


def r_head(s, k):
    z = (arb(2 * k) - 1) * PI / 2
    return kap(s) * (-1) ** (k + 1) * z ** 2 * sph_j_small(2 * s + 1, z)


def Bfull(i):
    return 1 / (arb(4 * i - 1) * arb(4 * i + 1) ** 2 * arb(4 * i + 3)).sqrt()


def head_solve_scaled(i, atoms=(1, 2, 3, 4), tail=14):
    na = len(atoms)
    v = [r_head(i, k) for k in atoms]
    sc = [abs(r_head(i + 1, k)) for k in atoms]
    Tp = arb_mat(na, na)
    for t in range(i + 1, i + 1 + tail):
        u = [r_head(t, k) for k in atoms]
        for a_ in range(na):
            for b_ in range(na):
                Tp[a_, b_] += (u[a_] / sc[a_]) * (u[b_] / sc[b_])
    rhs = arb_mat([[v[k] / sc[k]] for k in range(na)])
    ws = Tp.solve(rhs)
    w = [ws[k, 0] / sc[k] for k in range(na)]
    q = sum(v[k] * w[k] for k in range(na))
    a = [w[k] / (1 + q) for k in range(na)]
    N = (1 + q).sqrt()
    return a, N, q


def level_coeffs(i, tail=14):
    a, N, q = head_solve_scaled(i, tail=tail)
    B = Bfull(i)
    beta, gamma, ys = [], [], []
    for idx, k in enumerate((1, 2, 3, 4)):
        zk = (arb(2 * k) - 1) * PI / 2
        ys.append(1 / zk ** 2)
        beta.append(B * a[idx] * r_head(i - 1, k))
        gamma.append(B * a[idx] * r_head(i, k))
    return beta, gamma, ys, N


def AbarCbar(coeffs, x):
    beta, gamma, ys, N = coeffs
    Abar = N * (1 - sum(b / (yl - x) for b, yl in zip(beta, ys)))
    Cbar = N * sum(g / (yl - x) for g, yl in zip(gamma, ys))
    dAbar = -N * sum(b / (yl - x) ** 2 for b, yl in zip(beta, ys))
    dCbar = N * sum(g / (yl - x) ** 2 for g, yl in zip(gamma, ys))
    return Abar, Cbar, dAbar, dCbar


def fmt(x, digs=10):
    r = x.rad()
    if r > 0:
        lr = float((r.log() / arb(10).log()).mid())
        rs = f"rad 1e{lr:+.0f}"
    else:
        rs = "rad 0"
    return f"{float(x.mid()):+.{digs}f} ({rs})"


def run_j(j, nlist, targets=None):
    t0 = time.time()
    nu = arb(2 * j)
    n13 = nu ** (arb(1) / 3)
    i1, i2 = j - 1, j - 2
    c1 = level_coeffs(i1)
    c2 = level_coeffs(i2)
    N1, N2 = c1[3], c2[3]
    Bt = (N2 / N1) * Bfull(i1)
    print(f"\n== j = {j}  (prec {PREC} bits) ==")
    print(f"  Btilde/B enclosure: {fmt(N2 / N1, 12)}")
    for n in nlist:
        z = (arb(2 * n) - 1) * PI / 2
        x = 1 / z ** 2
        w = arb(2) ** (arb(1) / 3) / n13 * (nu - z)
        sj, sy = sph_tables(z, 2 * j + 3)
        sgn = (-1) ** (n + 1)

        def rb(s):
            return kap(s) * sgn * z ** 2 * sj[2 * s + 1]

        def rpb(s):
            jp = sj[2 * s] - (2 * s + 2) / z * sj[2 * s + 1]
            return -(z ** 3) / 2 * kap(s) * sgn * (2 * z * sj[2 * s + 1]
                                                   + z ** 2 * (jp + sy[2 * s + 1]))

        A1, C1, dA1, dC1 = AbarCbar(c1, x)
        A2, C2, dA2, dC2 = AbarCbar(c2, x)
        rt1 = A1 * rb(i1) + C1 * rb(i1 - 1)
        rt2 = A2 * rb(i2) + C2 * rb(i2 - 1)
        drt2 = A2 * rpb(i2) + C2 * rpb(i2 - 1) + dA2 * rb(i2) + dC2 * rb(i2 - 1)
        Fch = 2 * Bt * x * rt1 * (rt2 + x * drt2)
        B12 = Bfull(i1)
        Ffull = 2 * B12 * x * rb(i1) * (rb(i2) + x * rpb(i2))
        sg = (arb(2) / (4 * j + 1)) * z ** 2 * sj[2 * j + 1] * (
            2 * (j - 1) * sj[2 * j - 1] - z * (sj[2 * j - 2] + sy[2 * j - 1]))
        Dtot = (Fch - sg) / n13
        Dhead = (Fch - Ffull) / n13
        Dwt = (Ffull - sg) / n13
        ai, aip, bi, bip = w.airy()
        gh = 8 * PI * (aip * bi + ai * bip)
        print(f"  n = {n}  w = {float(w.mid()):+.4f}")
        print(f"    F_chain = {fmt(Fch)}")
        print(f"    F_full  = {fmt(Ffull)}")
        print(f"    sigma   = {fmt(sg)}")
        print(f"    D_tot   = {fmt(Dtot)}   D_head = {fmt(Dhead)}   "
              f"D_wt = {fmt(Dwt)}")
        print(f"    consistency D_tot - (D_head + D_wt) = "
              f"{fmt(Dtot - Dhead - Dwt, 2)}")
        print(f"    Airy target 8pi(AiBi)'(w) = {fmt(gh)}")
        if targets and n in targets:
            tD, tF = targets[n]
            okD = abs(float(Dtot.mid()) - tD) < 5e-5 + float(Dtot.rad())
            okF = abs(float(Fch.mid()) - tF) < 5e-5 + float(Fch.rad())
            print(f"    [frozen-log target: Dtot {tD:+.4f} F {tF:.4f} -> "
                  f"{'ENCLOSED' if (okD and okF) else 'MISMATCH'}]")
    print(f"  [{time.time()-t0:.0f}s]")


def main():
    t00 = time.time()
    run_j(54, [35, 37, 40], targets={37: (+0.6362, 1.5185)})
    run_j(140, [92, 93], targets={92: (+0.5552, 2.3342)})
    print(f"\n[total {time.time()-t00:.0f}s]")


if __name__ == '__main__':
    main()
