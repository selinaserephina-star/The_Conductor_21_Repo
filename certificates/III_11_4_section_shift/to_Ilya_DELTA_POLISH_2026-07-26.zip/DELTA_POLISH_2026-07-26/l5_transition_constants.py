r"""
l5_transition_constants.py -- L5 POLISH: pin the first-correction coefficient
of the transition-region asymptotics L5 uses, so the O(nu^{-1/3}) term's
envelope constant can be DISPLAYED (with the DLMF 10.19(iii) citation) rather
than waved at.

L5 (THEOREM_delta_display_form.md) uses
    J_{nu+a}(z), Y_{nu+a}(z) -> (2/nu)^{1/3} {Ai, -Bi}(w + a*delta),
    delta = 2^{1/3} nu^{-1/3},
and its "remaining polish" is the displayed constant of the next order.  The
DLMF 10.19(iii) transition expansion has the form
    J_nu(nu + t nu^{1/3}) ~ (2^{1/3}/nu^{1/3}) Ai(-2^{1/3}t) * [1 + O(nu^{-2/3})]
                          + (2^{2/3}/nu)      Ai'(-2^{1/3}t) * [B0(t) + ...]
(and Y with -Bi, -Bi').  This script EXTRACTS B0(t) (and the Y-side BY0(t))
numerically: R(nu, t) = nu * [J - leading] / (2^{2/3} Ai'), Richardson in
nu^{-2/3} over nu = 400/1600/6400, on a t-grid; then fits a cubic.  The
polynomial is displayed with digits and matched against small-rational
candidates.  (The zeta-uniform Olver constants A1(0) = -1/225, B0_Olver(0) =
2^{1/3}/70 of the caustic lane are already verified our side -- ledger 1.3;
this is the TRANSITION-VARIABLE version L5 actually substitutes.)
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (Delta polish, item 4).
"""
import numpy as np
import mpmath as mp

mp.mp.dps = 60
C13 = mp.mpf(2) ** (mp.mpf(1) / 3)


def extract(kind, t):
    """Richardson-extrapolated first-correction coefficient at offset t."""
    w = -C13 * t
    if kind == 'J':
        lead = C13 * mp.airyai(w)
        dcf = 2 ** (mp.mpf(2) / 3) * mp.airyai(w, 1)
        f = mp.besselj
        sgn = 1
    else:
        lead = -C13 * mp.airybi(w)
        dcf = 2 ** (mp.mpf(2) / 3) * mp.airybi(w, 1)
        f = mp.bessely
        sgn = -1
    vals = []
    for nu in (400, 1600, 6400):
        nu = mp.mpf(nu)
        z = nu + t * nu ** (mp.mpf(1) / 3)
        R = nu * (f(nu, z) - lead / nu ** (mp.mpf(1) / 3)) / dcf
        vals.append(R)
    # Richardson in nu^{-2/3} (ratio 4^{2/3} per step)
    r = mp.mpf(4) ** (mp.mpf(2) / 3)
    v01 = (r * vals[1] - vals[0]) / (r - 1)
    v12 = (r * vals[2] - vals[1]) / (r - 1)
    v = (r ** 2 * v12 - v01) / (r ** 2 - 1)
    return float(v), float(v12 - v01)


def main():
    print("== L5 transition first-correction coefficients ==")
    tgrid = [mp.mpf(x) / 10 for x in range(-12, 13, 3)]
    for kind in ('J', 'Y'):
        ts, vs, errs = [], [], []
        for t in tgrid:
            v, e = extract(kind, t)
            ts.append(float(t)); vs.append(v); errs.append(abs(e))
            print(f"  {kind}  t = {float(t):+4.1f}:  B0 = {v:+.9f}   "
                  f"(Richardson gap {abs(e):.1e})")
        c = np.polyfit(ts, vs, 3)
        print(f"  {kind}: cubic fit  B0(t) = "
              f"{c[0]:+.9f} t^3 {c[1]:+.9f} t^2 {c[2]:+.9f} t {c[3]:+.9f}")
        # rational candidates for the leading coefficients
        for name, val in (("t^3 coef", c[0]), ("t^2 coef", c[1]),
                          ("t coef", c[2]), ("const", c[3])):
            best = None
            for pnum in range(-40, 41):
                for pden in (1, 2, 3, 5, 6, 7, 10, 12, 14, 15, 20, 21, 30,
                             35, 42, 70, 105, 210, 225, 450):
                    cand = pnum / pden
                    d = abs(val - cand)
                    if best is None or d < best[0]:
                        best = (d, pnum, pden)
            d, pnum, pden = best
            tag = f"{pnum}/{pden}" if pden > 1 else f"{pnum}"
            print(f"      {name} = {val:+.9f}  nearest simple rational "
                  f"{tag} = {pnum/pden:+.9f}  (diff {d:.1e})")


if __name__ == '__main__':
    main()
