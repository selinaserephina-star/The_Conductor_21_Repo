import os
import numpy as np
import mpmath as mp

src = open('lambda_identity_check2.py').read().replace(
    "if __name__ == '__main__':", "if False:")
g = {'__file__': os.path.abspath('lambda_identity_check2.py')}
exec(compile(src, 'lic', 'exec'), g)
jacobi_mp = g['jacobi_mp']; LOGM = g['LOGM']

k, N = 4, 60
C = np.load(os.path.join(LOGM, f'corr_cache_mirror_k{k}_N{N}.npz'))['C']
M = N - k
with mp.workdps(300):
    zn = [(mp.mpf(n) - mp.mpf(1) / 2) * mp.pi for n in range(k + 1, N + 1)]
    x = [1 / z**2 for z in zn]
    w = [mp.mpf(1) / M] * M
    al, be, P, dP = jacobi_mp(x, w, M)
    F = [[mp.mpf(0)] * M]
    for j in range(1, M):
        F.append([2 * w[n] * be[j - 1] * P[j][n] * dP[j - 1][n] for n in range(M)])
    F.append([mp.mpf(0)] * M)
    bad = []
    for j in range(1, M):
        for sig in range(2, M + 1):
            s_cache = (C[j, sig - 1] - C[j, sig - 2]) + float(P[j][sig - 1]**2) / M
            s_pred = float(F[j + 1][sig - 1] - F[j][sig - 1])
            e = abs(s_cache - s_pred)
            if e > 1e-6:
                bad.append((e, j, sig))
    bad.sort(reverse=True)
    print('worst 10:', [(f'{e:.2e}', j, s) for e, j, s in bad[:10]])
    print('count:', len(bad), ' rows:', sorted(set(j for _, j, _ in bad)))
    print('sites:', sorted(set(s for _, _, s in bad)))
    # also: is the mismatch the site-1 (sig=1) column being off, i.e. a global
    # prefix offset? test the FULL prefix identity per row at a few j:
    for j in (2, 20, 40, 54):
        pref_pred = mp.mpf(0)
        errs = []
        for sig in range(1, M + 1):
            pref_pred += (F[j + 1][sig - 1] - F[j][sig - 1]) - P[j][sig - 1]**2 / M
            errs.append(abs(float(pref_pred) - C[j, sig - 1]))
        print(f'row {j}: max full-prefix err = {max(errs):.2e}  end err = {errs[-1]:.2e}')
