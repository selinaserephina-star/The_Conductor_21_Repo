r"""
lambda_mechanism_probe.py -- mechanism identification for the Lambda(w) and sqrt-M
derivations (first script of LAMBDA_SQRTM_2026-07-26; targets pinned in
LOGM_DEPTH_2026-07-26/FINDINGS_LOGM_DEPTH.md section 6).

[A] CAUSTIC MECHANISM: for the mirror k=4 section at M=296, row j=103 (and 54, 200):
    per-site summand s_sec(j,n) = dalpha_j/dx_n - q_{jn}^2 (recovered from the cstep
    corr cache: s = diff(C) + q^2), vs the infinity summand
    s_inf = Delta_j sigma_n (exact Bessel, the lemmaA' closure form). Where in the
    window do they diverge, and is the deficiency in the OP-VALUE factor or the
    WEIGHT factor? Decompose: q_{jn}^2 = p_j(x_n)^2 kappa_n (kappa = Christoffel
    number of the M-point uniform measure); infinity analog of p_j(x_n)^2*(local
    weight) via the value law 2(4j+3) j_{2j+1}(z_n)^2 [natural weights]. Print all
    factors across the caustic window.
[B] BOUNDARY sqrt-M MECHANISM: rows j = M-1..M-5: where does sup_m|C| sit, what is
    max_n |p_j(x_n)| (uniform weights cap it at sqrt(M)), and does the sup scale
    like the top-OP mass concentration? Print across M = 96/145/296/596 from caches
    + fresh q/p computations. Candidate constants vs 0.3713: 1/e = 0.3679,
    sqrt(2/pi)/2 = 0.3989/... -- displayed, no numerology commitments.
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (LAMBDA_SQRTM session).
"""
import os, math
import numpy as np
import mpmath as mp

mp.mp.dps = 40
PI = mp.pi
HERE = os.path.dirname(os.path.abspath(__file__))
LOGM = os.path.join(HERE, '..', 'LOGM_DEPTH_2026-07-26')
C13 = 2**(1 / 3)

# ---- engines (mirror atoms; uniform-weight Lanczos identical to the ladder) ----
def mirror_atoms(k, N):
    zn = (np.arange(k + 1, N + 1) - 0.5) * math.pi
    return 1.0 / zn**2


def lanczos_full(x):
    n = len(x)
    V = np.empty((n, n))
    v = np.full(n, 1.0 / math.sqrt(n))
    V[0] = v
    al = np.empty(n); be = np.empty(n - 1)
    w = x * v; a = v @ w; al[0] = a; w = w - a * v
    for j in range(1, n):
        b = np.linalg.norm(w)
        be[j - 1] = b
        vn = w / b
        Vj = V[:j]
        vn -= Vj.T @ (Vj @ vn); vn -= Vj.T @ (Vj @ vn)
        vn /= np.linalg.norm(vn)
        V[j] = vn
        w = x * vn - b * V[j - 1]
        a = vn @ w; al[j] = a; w = w - a * vn
    return al, be


def qmat_and_p(x):
    """q matrix (eigenvector convention of the pipeline) and OP values
    p_i(x_n) of the uniform measure: q[i,n] = p_i(x_n)*sqrt(kappa_n),
    sum_i q[i,n]^2 = 1, kappa_n = 1/sum_i p_i(x_n)^2. p_0 = 1 (mass-1 measure
    normalized: weights 1/M, total mass 1 => p_0 = 1, q[0,n] = sqrt(kappa_n)/1?
    -- recovered directly from eigenvectors."""
    al, be = lanczos_full(x)
    J = np.diag(al) + np.diag(be, 1) + np.diag(be, -1)
    ev, U = np.linalg.eigh(J)
    M = len(x)
    q = np.zeros((M, M))
    for r, nn in enumerate(np.argsort(x)):
        col = U[:, r]
        if col[0] < 0:
            col = -col
        q[:, nn] = col
    return q


# ---- infinity summand: exact Bessel sigma (lemmaA' closure form) ----
_DF = {}
def dfact(l):
    if l not in _DF:
        v = mp.mpf(1)
        for i in range(3, 2 * l + 2, 2):
            v *= i
        _DF[l] = v
    return _DF[l]

def j_series(l, z):
    guard = int(0.44 * float(z)) + 30
    with mp.workdps(mp.mp.dps + guard):
        zz = mp.mpf(z); z2 = zz * zz / 2
        t = mp.mpf(1); s = mp.mpf(1); k = 0
        thr = mp.mpf(10)**(-(mp.mp.dps + 10))
        while True:
            k += 1
            t *= -z2 / (k * (2 * l + 1 + 2 * k))
            s += t
            if abs(t) < thr * (abs(s) + 1) and 2 * k > float(z):
                break
        val = s * zz**l / dfact(l)
    return +val

def bessel_rows(z, Lmax, jorders):
    with mp.workdps(80):
        zz = mp.mpf(z)
        y = [-mp.cos(zz) / zz, -mp.cos(zz) / zz**2 - mp.sin(zz) / zz]
        for l in range(1, Lmax):
            y.append((2 * l + 1) / zz * y[-1] - y[-2])
        Lup = min(Lmax, int(float(z)) - 3)
        jup = None
        if any(l <= Lup for l in jorders):
            jup = [mp.sin(zz) / zz, mp.sin(zz) / zz**2 - mp.cos(zz) / zz]
            for l in range(1, Lup):
                jup.append((2 * l + 1) / zz * jup[-1] - jup[-2])
    jv = {}
    for l in jorders:
        if jup is not None and l <= Lup:
            jv[l] = +jup[l]
        elif z < l:
            jv[l] = j_series(l, z)
        else:
            with mp.workdps(60):
                v = mp.sqrt(PI / (2 * z)) * mp.besselj(mp.mpf(l) + mp.mpf(1) / 2, z)
            jv[l] = +v
    return jv, y

def sigma(j, n):
    z = (2 * n - 1) * PI / 2
    Ls = sorted({2 * j - 2, 2 * j - 1, 2 * j + 1})
    jv, y = bessel_rows(z, 2 * j + 2, Ls)
    return float((mp.mpf(2) / (4 * j + 1)) * z**2 * jv[2 * j + 1] * (
        2 * (j - 1) * jv[2 * j - 1] - z * (jv[2 * j - 2] + y[2 * j - 1])))


def probe_caustic(k, N, js):
    C = np.load(os.path.join(LOGM, f'corr_cache_mirror_k{k}_N{N}.npz'))['C']
    M = C.shape[0]
    x = mirror_atoms(k, N)
    q = qmat_and_p(x)
    print(f"== [A] per-site summand, mirror k={k} M={M} ==")
    for j in js:
        nu = 2.0 * j
        mstar = int(round(2 * j / math.pi))
        print(f"  row j={j} (site window around m* = {mstar}; w = caustic coordinate):")
        print("     m    w      s_sec = dC+q^2   s_inf(Bessel)   q^2_sec     "
              "2(4j+3)j_{2j+1}^2(z)  ratio s_sec/s_inf")
        for m in range(mstar - 6, mstar + 7):
            if m < 3 or m > M:
                continue
            w = C13 * nu**(-1 / 3) * (nu - (m + k - 0.5) * math.pi)
            # s_sec: per-site summand at SECTION position m -> prefix index m-2
            s_sec = (C[j, m - 2] - C[j, m - 3]) + q[j, m - 1]**2
            nlat = m + k          # lattice site (z = (nlat - 1/2) pi)
            s_inf = sigma(j + 1, nlat) - sigma(j, nlat)
            vlaw = float(2 * (4 * j + 3) * bessel_rows((2 * nlat - 1) * math.pi / 2,
                          2 * j + 2, [2 * j + 1])[0][2 * j + 1]**2)
            r = s_sec / s_inf if s_inf != 0 else float('nan')
            print(f"   {m:>4} {w:+5.2f}   {s_sec:+12.6f}   {s_inf:+12.6f}   "
                  f"{q[j, m - 1]**2:10.6f}   {vlaw:12.6f}   {r:8.3f}")


def probe_boundary():
    print("\n== [B] boundary rows: sup|C| location + top-OP magnitudes ==")
    print("   M    j      sup_m|C|  at m   m/M     max_n|p_j|   sqrt(M)   "
          "sup|C|/sqrt(M)")
    for N in (100, 149, 300, 600):
        C = np.load(os.path.join(LOGM, f'corr_cache_mirror_k4_N{N}.npz'))['C']
        M = C.shape[0]
        x = mirror_atoms(4, N)
        q = qmat_and_p(x)
        kap = 1.0 / (q**2).sum(axis=0) * 0 + (q[0, :]**2)  # kappa_n = q0n^2 * mass?  p0=1
        # p_i(x_n) = q[i,n]/sqrt(kappa_n) with kappa_n = q[0,n]^2 (since p_0 = 1)
        for j in (M - 1, M - 3, M - 5):
            row = np.abs(C[j, :])
            im = int(row.argmax())
            pj = np.abs(q[j, :] / np.abs(q[0, :]))
            print(f" {M:>4} {j:>5}   {row.max():9.4f}  {im + 2:>4}  {(im + 2) / M:5.2f}"
                  f"   {pj.max():10.2f}   {math.sqrt(M):7.2f}   "
                  f"{row.max() / math.sqrt(M):8.4f}")


if __name__ == '__main__':
    probe_caustic(4, 300, [54, 103, 200])
    probe_boundary()
