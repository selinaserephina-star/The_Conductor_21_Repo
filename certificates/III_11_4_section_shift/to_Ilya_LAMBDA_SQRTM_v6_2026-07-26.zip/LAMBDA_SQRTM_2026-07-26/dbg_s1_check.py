import math
import numpy as np

# S1 closed form check: S1_n = pi^2 (n+A)^2 [ (M-1) + ((n+A)/2)(Hsum1 - Hsum2) ]
# vs brute force, mirror lattice k=4. Exact partial fractions:
#   1/(x_n - x_r) = pi^2 (n+A)^2 [ 1 + ((n+A)/2)(1/(r-n) - 1/(r+n+2A)) ]
# with A = k - 1/2. Then the smooth-log approx Q(u).
k = 4
A = k - 0.5
for N in (3004,):
    n_idx = np.arange(1, N - k + 1)          # local index 1..M
    zn = (n_idx + A) * math.pi
    x = 1.0 / zn**2
    M = len(x)
    for nl in (int(0.5*M), int(0.8336*M), int(0.9*M)):
        d = x[nl-1] - x
        d[nl-1] = np.inf
        S1_brute = (1.0/d).sum()
        # exact partial fraction form
        r = n_idx[n_idx != nl]
        S1_pf = math.pi**2*(nl+A)**2*( (M-1) + ((nl+A)/2)*(np.sum(1.0/(r-nl)) - np.sum(1.0/(r+nl+2*A))) )
        # smooth Q(u)
        u = nl/M
        Q = 1 + (u/2)*math.log(2*(1-u)/(1+u))
        S1_smooth = math.pi**2*(u*M)**2*M*Q
        print(f"M={M} n={nl} (u={u:.3f}): brute {S1_brute:.6e}  partial-frac {S1_pf:.6e} "
              f"(ratio {S1_pf/S1_brute:.10f})  smoothQ {S1_smooth:.6e} (ratio {S1_smooth/S1_brute:.6f})")
