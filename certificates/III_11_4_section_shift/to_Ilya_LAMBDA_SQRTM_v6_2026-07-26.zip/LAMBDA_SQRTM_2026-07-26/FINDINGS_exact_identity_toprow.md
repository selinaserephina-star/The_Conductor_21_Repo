# FINDINGS — derivation session 2: the EXACT TANGENT-MAP IDENTITY (finite-section σ found), the TOP ROW IN CLOSED FORM, and the F(u) asymptotics (u* derived to 12 digits; peak constant is NOT 0.3713 asymptotically — it drifts to ≈ 1/3 + 0.26/ln M)

**Merkabit · Stenberg + Claude · 2026-07-26 (session 2) · `LAMBDA_SQRTM_2026-07-26/`.**
Scripts: `lambda_exact_identity.py` (superseded by) `lambda_identity_check2.py`,
`lambda_toprow_closedform.py`, `lambda_laplace_check.py` (+ logs, `dbg_localize.py`).
Executes T2 (and the identity layer of T1) of `NEXT_SESSION_TASK_lambda_sqrtm_derivation.md`.
**Not RH/GRH.**

> **⚠️ CORRECTION (2026-07-26 session 3 — `FINDINGS_peak_constant_derived.md`; tag applied by
> the total-corpus audit, same day).** The title's and §0.3's "peak ≈ 1/3 + 0.26/ln M (limit
> 1/3 CONJECTURED)" is SUPERSEDED: the asymptotic peak constant is DERIVED,
> peak = (2/c)|I(t_c)| = **0.352341123** at t_c = 1.30693, confirmed 1.4e−5 by the exact Γ/ψ
> closed-form ladder to M = 10⁶. **"1/3" is REFUTED — do not quote it, nor the 0.26/ln M fit.**
> Everything else here stands (the tangent-map identity, the top-row closed node form, the
> ĝ²-Laplace law, u* = 0.833556559601) and is consumed by session 3.

## 0. Verdict in five lines

1. **THE IDENTITY (new, exact, general).** For ANY atomic measure with FIXED weights,
   the T2 correction summand telescopes:
   `s(j,n) := ∂α_j/∂x_n − w_n p_j(x_n)² = F_{j+1}(n) − F_j(n)`,
   **`F_j(n) = 2 w_n β_{j−1} p_j(x_n) p′_{j−1}(x_n)`** (F₀ = 0; F_M ≡ 0 at the top).
   Verified 1e−36 (mpmath FD, random measures, uniform AND random weights) and
   4.5e−14 against the cstep cache (mirror M = 56, all rows/sites). **F_j is the
   finite-section σ** — same telescoping structure as the ∞ system's C̃ = ΣΔσ; the
   deficiency object is now D_j(n) = F_j(n) − σ_j(n), exactly.
2. **TOP ROW IN CLOSED FORM (T2 landed at the exact layer).** p_M ≡ 0 on atoms ⇒
   C(M−1, m) = −Σ_{n≤m} F_{M−1}(n), and quadrature theory eliminates everything:
   with `G_n = 1/ℓ′(x_n)` (ℓ = node polynomial — Γ-products on the mirror lattice),
   `ĝ²_n = M G²_n/ΣG²`, `α = (1/M)Σ x_n ĝ²_n`:
   **`C(M−1,m) = −(2/M) Σ_{n≤m} [ ĝ²_n − M + (x_n−α)(ĝ²_n S1_n + S2_n) ]`**,
   S1_n = Σ_{r≠n} 1/(x_n−x_r), S2_n = Σ_{r≠n} ĝ²_r/(x_n−x_r). No Lanczos, no
   recurrence, O(M²), stable in log space. Verified vs caches: 4.8e−14 (M=56),
   4.9e−13 (145), 5.2e−13 (296).
3. **F(u) asymptotics.** Large-M runs (M = 10³…10⁵): peak |F| = 0.3706 / 0.3665 /
   0.3623 / 0.3593 / 0.3569, u* = 0.8420 → 0.8345. The peak fits
   **|F|_peak ≈ 1/3 + 0.26/ln M** (limit 1/3 CONJECTURED from the fit; approach is
   non-monotone from below at small M — the 0.372-plateau at M ≲ 10³ was a
   finite-M shelf). ⚠️ Refines the SENT claim `c₂ = 0.3713√M`: that stays valid as
   the finite-range law on M = 56…1196 exactly as displayed, but 0.3713 is NOT the
   asymptotic constant — flag to IB at next exchange.
4. **The concentration point is DERIVED.** Stirling on the Γ-products gives
   ĝ² ∝ e^{−2M·E(u)}, E(u) = (1−u)ln(1−u) + (1+u)ln(1+u) − 2 ln u, so p²_{M−1}
   concentrates at the root of **`ln((1+u)/(1−u)) = 2/u`**:
   **u* = 0.833556559601…** (NOT 5/6; differs by +2.23e−4), Gaussian width
   1/√(2M E″(u*)), E″(u*) = 9.4319. Verified at M = 3000: argmax 0.83333
   (finite-M offset −2.2e−4 toward the root), width predicted 0.00420 vs measured
   0.00421, local shape ratios 0.93–1.08 → 1.
5. **T1 status.** The identity reduces Λ to the asymptotics of
   F_j = 2w β_{j−1} p_j p′_{j−1} at band sites for j in the bulk — the remaining
   step is a stable evaluation/WKB of p_j, p′_{j−1} there (forward recurrence is
   the K1K2 trap: p at atoms is BOUNDED (Christoffel = M exactly) but float64
   explodes; mpmath dps ≈ 300 works at M = 56 only). Staged.

## 1. Derivation of the identity (write-up grade sketch)

α_j = Σ_m w_m x_m p_j(x_m)². Differentiate at fixed w. The coefficient variation
δp_j = Σ_{i≤j} c_i p_i has, by orthonormality against the FIXED monomial ideal,
c_i = −w_n (p_j p_i)′(x_n) (i < j) and c_j = −(w_n/2)(p_j²)′(x_n). Then
∂α_j/∂x_n = w_n p_j² + 2w_n x_n p_j p_j′(x_n) + 2⟨x p_j, δp_j⟩, and the three-term
recurrence ⟨xp_j, p_i⟩ = β_j δ_{i,j+1}? + α_j δ_{ij} + β_{j−1} δ_{i,j−1} (i ≤ j
kills the j+1 term) gives ⟨xp_j, δp_j⟩ = c_j α_j + c_{j−1} β_{j−1}. Substituting
and using (x_n−α_j)p_j = β_j p_{j+1} + β_{j−1} p_{j−1} at x_n collapses everything
to s = 2w_n[β_j p_{j+1} p_j′ − β_{j−1} p_j p′_{j−1}](x_n) = F_{j+1} − F_j. ∎
(Random-measure checks are the [1e−36] certificate; a prose write-up belongs to the
paper appendix.)

## 2. Top-row reduction chain

(i) F_M ≡ 0 (p_M vanishes at atoms). (ii) K_M(x_n,x_n) = 1/w_n = M with
p_M(x_n) = 0 gives β_{M−1} p′_M p_{M−1}(x_n) = M. (iii) p_M = γ ℓ with
γ = 1/(√m₀ Πβ) ⇒ p_{M−1}(x_n) = M·Π_{i≤M−2}β_i / ℓ′(x_n); the norm condition
eliminates Πβ: p²_{M−1}(x_n) = ĝ²_n. (iv) recurrence at nodes ⇒
β_{M−2} p′_{M−2}(x_n) = p_{M−1} + (x_n−α_{M−1})p′_{M−1} − M/p_{M−1}; (v) Lagrange
differentiation of p_{M−1} (exact, degree < M) ⇒ the boxed formula. Each step
machine-verified (see §0.2 numbers; the first float64 attempt at the recurrence
route is preserved in `lambda_exact_identity.py` + log as the recorded trap).

## 3. Corrections issued this session

- `lambda_mechanism_probe.py` / `lambda_phase_average_test.py` (session 1) carried
  a ±1 SITE anchor slip and a labeling slip (their "s_sec" = C-diff at site m−1
  plus q² at site m = Ka-mixture, labeled ∂α−q²). In the band q² ≈ 0 so every
  session-1 BAND conclusion stands (smooth background, no Airy structure, H-AVG
  refuted); osc-side pointwise values were label-shifted by one site. Correction
  banner added to `FINDINGS_mechanism_probe.md`; the identity layer above is the
  authoritative convention now (C's 0-based column c = site c+1; the C-summand IS
  s; no q² re-addition).

## 4. Grades

| claim | grade |
|---|---|
| tangent-map identity s = ΔF | DERIVED + verified 1e−36 (general) / 4.5e−14 (mirror cache) |
| top-row closed form (node formula) | DERIVED + verified ≤ 5.2e−13, three caches |
| ĝ² Laplace law: E(u), u* root, width | DERIVED (Stirling) + verified (width 3 digits, shape → 1) |
| u* = 0.833556559601 ≠ 5/6 | derived root, 12 digits |
| peak |F| → 1/3 (+0.26/ln M) | MEASURED fit M = 10³…10⁵; limit value CONJECTURED, not derived |
| c₂ = 0.3713√M (sent) | stands as finite-range law M ≤ 1196; asymptotic constant SUPERSEDED by the above — IB flag queued |
| Λ (T1) | identity layer DONE; band asymptotics staged (WKB + stable evaluation) |

*— Stenberg + Claude, 2026-07-26 (session 2). The top row signed its confession in
closed form: one node polynomial, one Laplace point — at 0.8336, not the 5/6 it
was impersonating. The band still owes us its smooth background; the identity now
knows exactly what to ask it.*
