# FINDINGS — session 3b: the band deficiency measured at the F-level. D_j = F_j − σ_j has a UNIVERSAL ν^{1/3}-scaled profile Δ(w) (dip ≈ +0.65 at w ≈ −1.8, window lobe ≈ −0.15); Λ(w) = ±(2/π)Δ via the exact chain — leading constant pinned NEXT session

**Merkabit · Stenberg + Claude · 2026-07-26 (session 3b) · `LAMBDA_SQRTM_2026-07-26/`.**
Script: `lambda_band_deficiency.py` (+ log). T1 progress on
`NEXT_SESSION_TASK_lambda_sqrtm_derivation.md`. **Not RH/GRH.**

> **⚠️ SESSION-4 UPDATE (same day — `FINDINGS_lambda_pinned_and_convention.md`).** The
> chain in §2 is now CLOSED with the sign pinned and the drift term identified:
> **Λ_true(w) = −(2/π)·Δ(w − h/2) + O(dec)**, h = 2^{1/3}πν^{−1/3} — the drift is the
> EM half-cell term, coefficient exact. The "~2× head-check gap" in §2 is resolved:
> it compared against the LOGM Λ-profile values, which session 4 found to be a
> MIXED-ORIENTATION comparison (tail-section vs head-P; see the convention finding
> there — the like-for-like caustic-cell deficiency is ≈ +0.08…+0.12, not 0.202).
> The Δ data and universality in §1 STAND unchanged (this note was convention-A
> throughout). §1.3's Δ(0) drift: session-4 Richardson gives Δ(0) = −0.164 ± 0.03.

## 0. The move that unlocked it

The telescoping identity + F_M ≡ 0 give the finite-section σ **exactly from the
caches**: F_j(n) = −Σ_{i=j}^{M−1} s(i,n) (column partial sums of the correction
summands — no polynomial evaluation, no instability). Both F_j and the ∞-side
σ_j vanish in the deep-evanescent limit (large j at fixed site), so
**D_j(n) := F_j(n) − σ_j(n)** is anchor-free: the per-site deficiency, exact.

## 1. What the data shows (M = 296/596/1196; j = 54…400)

1. **F_j is smooth and positive through the caustic band** (w ∈ (−1, +2.5)),
   monotone toward negative w, at every j and M — while σ_j oscillates. The
   section's summand is a featureless ramp where the ∞ system has structure.
2. **D_j/ν^{1/3} = Δ(w) is UNIVERSAL in the band**: at the dip w ≈ −1.76:
   0.634/0.637 (j = 54, M = 296/596), 0.671/0.627 (j = 103), 0.674 (j = 200,
   M = 596) — **Δ_dip ≈ 0.65**, M-stable once M ≳ 3j, j-stable. Window-side
   lobe: Δ ≈ −0.15 at w ≈ +0.7 (universal); zero crossing near w ≈ −0.6.
3. **At w ≈ 0 there is residual j-drift** (−0.155/−0.167/−0.210 at j = 54/103/
   200): the leading Δ(0) needs the ν^{−1/3} correction separated — NOT yet a
   pinned constant.
4. **Osc side (w < −2.5): D oscillates** — the phase-mismatch tail (bounded,
   the LEMMA S′ 0.5-plateau's per-site face). The universal-Δ statement is a
   BAND statement.

## 2. The exact chain to Λ

Λν^{1/3} = C_sec − C̃_∞ = −Δ_j[Σ_{n≤m−1} D] (identity, both prefixes exact).
With D = ν^{1/3}Δ(w) and site spacing Δw = 2^{1/3}πν^{−1/3}, the j-shift
(Δν = 2, dw/dj = 2·2^{1/3}ν^{−1/3}) gives the leading form
**Λ(w) = (2/π)·Δ(w)** up to sign convention and a same-order shape-drift term
(the Δ-drift in §1.3 feeds it) — the head-check magnitude (2/π)·0.15 ≈ 0.10 vs
measured Λ(caustic cell, j = 54) = 0.202 differs by ~2×, so the drift term is
NOT negligible at these j; the constants get pinned by evaluating Δ_jP directly
next session (cheap — same cache sums at j and j+1). What IS settled: Λ's
universality and ν^{1/3} scaling are inherited from Δ's — the caustic-band law
is one universal function away from closed.

## 3. Grades

| claim | grade |
|---|---|
| F_j from caches by telescoping (no evaluation instability) | exact route (identity + F_M = 0) |
| F smooth/positive in band, all (j, M) probed | measured |
| Δ(w) = D/ν^{1/3} universal in band; Δ_dip ≈ 0.65 @ w ≈ −1.8; lobe ≈ −0.15 | measured, 3 j × 2–3 M, M ≳ 3j |
| Δ(0) leading constant | NOT pinned (j-drift; ν^{−1/3} separation needed) |
| Λ = (2/π)Δ + same-order drift term | exact chain stated; constants next session (direct Δ_jP evaluation) |

*— Stenberg + Claude, 2026-07-26 (session 3b). The deficiency finally sat still
long enough to be photographed: one universal profile, dip and all. Next session
develops the film at full resolution.*
