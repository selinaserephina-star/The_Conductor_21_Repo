r"""
lambda_display_form.py -- T1 of the Delta closeout: the DISPLAY FORM of Delta(w).

Key exact rewrite (partial fractions on the CD kernel; no approximation):
    rt_i(x) = Abar(x) * r_i(x) + Cbar(x) * r_{i-1}(x)
    Abar(x) = N [ 1 - sum_l beta_l/(y_l - x) ],  beta_l = B_{i-1} a_l r_{i-1}(y_l)
    Cbar(x) = N   sum_l gamma_l/(y_l - x),       gamma_l = B_{i-1} a_l r_i(y_l)
with (a, N) from the tail-Gram Sherman-Morrison solve.  At band x ~ 1/nu^2 the
Taylor coefficients A_p = N[d_{p0} - sum beta_l eps_l^{p+1}],
C_p = N sum gamma_l eps_l^{p+1} organize as polynomials in the band variable
chi := x*(2nu)^2 (chi -> 4(nu/z)^2 ~ 4 at the caustic):
    Abar = sum_p Ahat_p chi^p,  Ahat_p := A_p/(2nu)^{2p}   (expect O(1) limits)
This script:
  [1] re-validates the exact chain with an EQUILIBRATED tail-Gram solve
      (kills the 1e190 entry-range conditioning; j=300+ now feasible at dps ~300)
  [2] checks the exact rewrite against rt_pair at j=54
  [3] extracts Ahat_p(i), Chat_p(i) over an i-ladder for drop-4 (and drop-1
      cross-checks, atoms {1} and {4}, vs the hand-derived law rhat = (2-chi) r_i
      + r_{i-1})
  [4] prints Richardson-style fits of the limits.
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (Delta-closeout session).
"""
import os, math
import mpmath as mp

mp.mp.dps = 300
PI = mp.pi

def sph_jy(l, z):
    fac = mp.sqrt(PI/(2*z))
    return (fac*mp.besselj(mp.mpf(l)+mp.mpf(1)/2, z),
            fac*mp.bessely(mp.mpf(l)+mp.mpf(1)/2, z))

def sph_j(l, z):
    return mp.sqrt(PI/(2*z))*mp.besselj(mp.mpf(l)+mp.mpf(1)/2, z)

def kap(s):
    return mp.sqrt(2*(mp.mpf(4*s)+3))

def r_at(s, n):
    z = (mp.mpf(2*n)-1)*PI/2
    return kap(s)*(-1)**(n+1)*z**2*sph_j(2*s+1, z)

def rp_at(s, n):
    z = (mp.mpf(2*n)-1)*PI/2
    j, y = sph_jy(2*s+1, z)
    jm = sph_j(2*s, z)
    jp = jm - (2*s+2)/z*j
    return -(z**3)/2*kap(s)*(-1)**(n+1)*(2*z*j + z**2*(jp + y))

def Bfull(i):
    return 1/mp.sqrt(mp.mpf(4*i-1)*(4*i+1)**2*(4*i+3))


def head_solve_scaled(i, atoms=(1, 2, 3, 4), tail=14):
    """Equilibrated Sherman-Morrison tail-Gram solve. Returns (a, N, q)."""
    na = len(atoms)
    v = [r_at(i, k) for k in atoms]
    # scale by the leading tail row s = i+1
    s = [abs(r_at(i+1, k)) for k in atoms]
    Tp = mp.zeros(na, na)
    for t in range(i+1, i+1+tail):
        u = [r_at(t, k) for k in atoms]
        for a_ in range(na):
            for b_ in range(na):
                Tp[a_, b_] += (u[a_]/s[a_])*(u[b_]/s[b_])
    vs = mp.matrix([v[k]/s[k] for k in range(na)])
    ws = mp.lu_solve(Tp, vs)
    w = [ws[k]/s[k] for k in range(na)]           # T'^{-1} v
    q = sum(v[k]*w[k] for k in range(na))
    a = [w[k]/(1+q) for k in range(na)]
    N = mp.sqrt(1+q)
    return a, N, q


def rational_coeffs(i, atoms=(1, 2, 3, 4), tail=14):
    """beta_l, gamma_l, N, q for the partial-fraction display form at level i."""
    a, N, q = head_solve_scaled(i, atoms, tail)
    B = Bfull(i)
    beta, gamma, eps = [], [], []
    for idx, k in enumerate(atoms):
        zk = (mp.mpf(2*k)-1)*PI/2
        eps.append(zk**2)
        beta.append(B*a[idx]*r_at(i-1, k))
        gamma.append(B*a[idx]*r_at(i, k))
    return beta, gamma, eps, N, q


def taylor_AC(i, atoms=(1, 2, 3, 4), tail=14, pmax=6):
    beta, gamma, eps, N, q = rational_coeffs(i, atoms, tail)
    A, C = [], []
    for p in range(pmax+1):
        Ap = N*((1 if p == 0 else 0) - sum(b*e**(p+1) for b, e in zip(beta, eps)))
        Cp = N*sum(g*e**(p+1) for g, e in zip(gamma, eps))
        A.append(Ap); C.append(Cp)
    return A, C, N, q


def rt_exact_rational(i, n, atoms=(1, 2, 3, 4), tail=14):
    """rt_i(x_n) via the exact partial-fraction rewrite (validation of the form)."""
    beta, gamma, eps, N, q = rational_coeffs(i, atoms, tail)
    z = (mp.mpf(2*n)-1)*PI/2
    x = 1/z**2
    Abar = N*(1 - sum(b/((1/e) - x) for b, e in zip(beta, eps)))
    Cbar = N*sum(g/((1/e) - x) for g, e in zip(gamma, eps))
    return Abar*r_at(i, n) + Cbar*r_at(i-1, n)


def show_ladder(atoms, ladder, pmax, label):
    print(f"\n=== {label}: Ahat_p = A_p/(2nu)^(2p), Chat_p = C_p/(2nu)^(2p), "
          f"nu := 2i+2 ===")
    rows = {}
    for i in ladder:
        A, C, N, q = taylor_AC(i, atoms=atoms, pmax=pmax)
        nu = mp.mpf(2*i+2)
        Ah = [A[p]/(2*nu)**(2*p) for p in range(pmax+1)]
        Ch = [C[p]/(2*nu)**(2*p) for p in range(pmax+1)]
        rows[i] = (Ah, Ch)
        print(f" i={i:>4} q={mp.nstr(q,4):>10}  Ahat:",
              " ".join(f"{float(x):+10.5f}" for x in Ah))
        print(f"        {'':>16}  Chat:",
              " ".join(f"{float(x):+10.5f}" for x in Ch))
    # crude limit fits from the last three rungs: f = alpha + beta/nu^pow
    ii = ladder[-3:]
    for pow_ in (1.0, 2.0/3.0, 1.0/3.0):
        est_A, est_C = [], []
        for p in range(pmax+1):
            x1, x2 = 1/mp.mpf(2*ii[-2]+2)**pow_, 1/mp.mpf(2*ii[-1]+2)**pow_
            y1, y2 = rows[ii[-2]][0][p], rows[ii[-1]][0][p]
            est_A.append(y2 + (y2-y1)*x2/(x1-x2))
            y1, y2 = rows[ii[-2]][1][p], rows[ii[-1]][1][p]
            est_C.append(y2 + (y2-y1)*x2/(x1-x2))
        print(f"  2-pt limit (corr ~ nu^-{pow_:.2f}): Ahat ->",
              " ".join(f"{float(x):+10.5f}" for x in est_A))
        print(f"                               Chat ->",
              " ".join(f"{float(x):+10.5f}" for x in est_C))
    return rows


def main():
    # [1] anchor: reproduce the frozen-engine q and rt values at j=54
    a1, N1, q1 = head_solve_scaled(53)
    print(f"[1] i=53: q = {mp.nstr(q1, 6)}   (frozen engine: 2.19736e+26)")
    a2, N2, q2 = head_solve_scaled(139)
    print(f"    i=139: q = {mp.nstr(q2, 6)}   (frozen engine: 6.81281e+32)")
    Bt = None
    a2b, N2b, q2b = head_solve_scaled(52)
    Bt = (N2b/N1)*Bfull(53)
    print(f"    B~_(52) = {mp.nstr(Bt, 8)}   (frozen: 1.9064484e-5)")

    # [2] exact rewrite check at j=54 band points
    print("\n[2] exact partial-fraction rewrite vs frozen rt values (j=54):")
    for n, ref in ((33, 15.628706), (35, 332.76049), (37, 2560.2963)):
        val = rt_exact_rational(53, n)
        print(f"    rt_53({n}) = {mp.nstr(val, 8)}   (frozen chain {ref};"
              f" ratio {mp.nstr(val/ref, 8)})")

    # [3] tail-length sensitivity at one rung
    A14, C14, *_ = taylor_AC(53, tail=14)
    A30, C30, *_ = taylor_AC(53, tail=30)
    dmax = max(abs(float((A14[p]-A30[p])/(abs(A30[p])+mp.mpf('1e-30'))))
               for p in range(7))
    print(f"\n[3] tail=14 vs tail=30 at i=53: max rel diff in A_p = {dmax:.2e}")

    # [4] drop-1 cross-check vs the hand law rhat = (2-chi) r_i + r_{i-1}
    show_ladder((1,), [53, 139, 299, 599], 3, "DROP-1, atom {1} "
                "(hand law: Ahat = [2, -1, 0, 0], Chat = [1, 0, 0, 0])")
    show_ladder((4,), [53, 139, 299, 599], 3, "DROP-1, atom {4} (same hand law)")

    # [5] the main event: drop-4 ladder
    show_ladder((1, 2, 3, 4), [53, 99, 139, 199, 299, 449, 599], 6,
                "DROP-4")

if __name__ == '__main__':
    main()
