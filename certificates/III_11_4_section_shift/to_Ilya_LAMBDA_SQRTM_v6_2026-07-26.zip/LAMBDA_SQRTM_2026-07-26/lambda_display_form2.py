r"""
lambda_display_form2.py -- follow-ups to the U-law discovery:
 [A] drop-2 / drop-3 coefficient extraction: test the Chebyshev pattern
     A -> (-1)^m U_m((chi-2)/2),  C -> -(-1)^m U_{m-1}((chi-2)/2)
     predictions: m=2: A = chi^2-4chi+3 = (3,-4,1);       C = (2,-1)... sign: +?
                  m=3: A = -(chi^3-6chi^2+10chi-4) = (4,-10,6,-1); C = (3,-4,1)-signed
     (extractor prints raw Ahat/Chat; compare against U-polynomials)
 [B] j=140 osc-edge cell (n=93, w=-2.04): F_cache vs M across the k4 caches
     N=300/600/1200 -- is the cache M-drifting toward the chain value 0.98?
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (Delta-closeout session).
"""
import os
import numpy as np
import mpmath as mp
from lambda_display_form import show_ladder

LOGM = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..',
                    'LOGM_DEPTH_2026-07-26')

print("U-polynomial predictions in chi (constant..chi^m):")
print("  m=2: A = (3,-4,1)          C = -U1*sign... printed by extractor")
print("  m=3: A = (4,-10,6,-1)-ish  C = (3,-4,1)-ish")

show_ladder((1, 2), [53, 139, 299, 599], 4, "DROP-2 (atoms {1,2})")
show_ladder((3, 4), [53, 139, 299, 599], 4, "DROP-2 (atoms {3,4})")
show_ladder((1, 2, 3), [53, 139, 299, 599], 5, "DROP-3 (atoms {1,2,3})")

print("\n[B] j=140 osc-edge: F_cache(M) at n=93,94 vs chain (0.9800, -1.4330):")
for tag in ('N300', 'N600', 'N1200'):
    f = os.path.join(LOGM, f'corr_cache_mirror_k4_{tag}.npz')
    if not os.path.exists(f):
        print(f"  {tag}: missing"); continue
    C = np.load(f)['C']
    j = 140
    if C.shape[0] <= j:
        print(f"  {tag}: cache too shallow (rows {C.shape[0]})"); continue
    for n in (92, 93, 94):
        col = n - 5
        if col >= C.shape[1]:
            print(f"  {tag} n={n}: beyond cache"); continue
        if col == 0:
            Fc = -float(C[j:, 0].sum())
        else:
            Fc = -float((C[j:, col] - C[j:, col-1]).sum())
        print(f"  {tag} n={n}: F_cache = {Fc:+.4f}")
