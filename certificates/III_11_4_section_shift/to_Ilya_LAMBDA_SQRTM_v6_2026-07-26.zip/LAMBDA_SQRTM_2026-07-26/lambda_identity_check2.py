r"""
lambda_identity_check2.py -- stable verification of the exact telescoping identity
    s(j,n) := d alpha_j / d x_n - w_n p_j(x_n)^2 = F_{j+1}(n) - F_j(n),
    F_j(n) = 2 w_n beta_{j-1} p_j(x_n) p'_{j-1}(x_n),  F_0 = 0, F_M = 0 (top row),
avoiding the float64 forward-recurrence blowup (p_i at atoms is bounded, but the
recurrence's dominant solution overflows -- the K1K2 recurrence trap, again).

 [1] GENERAL identity: random atomic measures (M = 8, 12; uniform AND random fixed
     weights), mpmath dps 60: dalpha/dx_n by central FD (h = 1e-25) vs the formula.
     The derivation used only orthonormality + three-term recurrence, so it must
     hold for arbitrary positive weights.
 [2] MIRROR cache check: mirror k=4 N=60 (M=56), mpmath dps 300 forward recurrence
     (exact-rational atoms would be exacter; high dps suffices), all rows vs the
     cstep cache summands, and the top row vs -prefix F_{M-1}.
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (derivation session).
"""
import os, math
import numpy as np
import mpmath as mp

HERE = os.path.dirname(os.path.abspath(__file__))
LOGM = os.path.join(HERE, '..', 'LOGM_DEPTH_2026-07-26')


def jacobi_mp(x, w, mdeg):
    """Stieltjes: alpha[0..mdeg-1], beta[0..mdeg-2], and P[i][n] = p_i(x_n),
    dP[i][n] = p_i'(x_n) (orthonormal, mass-normalized p_0 = 1/sqrt(m0))."""
    N = len(x)
    m0 = mp.fsum(w)
    P = [[1 / mp.sqrt(m0)] * N]
    dP = [[mp.mpf(0)] * N]
    al, be = [], []
    a0 = mp.fsum(w[n] * x[n] * P[0][n]**2 for n in range(N))
    al.append(a0)
    cur = [(x[n] - a0) * P[0][n] for n in range(N)]
    dcur = [P[0][n] for n in range(N)]
    prev, dprev = P[0], dP[0]
    for kdeg in range(1, mdeg):
        b = mp.sqrt(mp.fsum(w[n] * cur[n]**2 for n in range(N)))
        be.append(b)
        cur = [c / b for c in cur]; dcur = [c / b for c in dcur]
        P.append(cur); dP.append(dcur)
        ak = mp.fsum(w[n] * x[n] * cur[n]**2 for n in range(N))
        al.append(ak)
        nxt = [(x[n] - ak) * cur[n] - b * prev[n] for n in range(N)]
        dnxt = [(x[n] - ak) * dcur[n] + cur[n] - b * dprev[n] for n in range(N)]
        prev, dprev = cur, dcur
        cur, dcur = nxt, dnxt
    return al, be, P, dP


def alphas_only(x, w, mdeg):
    return jacobi_mp(x, w, mdeg)[0]


def check_random(M, uniform, seed):
    rng = np.random.default_rng(seed)
    with mp.workdps(60):
        x = sorted(mp.mpf(float(v)) for v in rng.uniform(0.05, 1.0, M))
        if uniform:
            w = [mp.mpf(1) / M] * M
        else:
            w = [mp.mpf(float(v)) for v in rng.uniform(0.2, 1.0, M)]
        al, be, P, dP = jacobi_mp(x, w, M)
        h = mp.mpf(10)**-25
        worst = mp.mpf(0)
        for n in range(M):
            xp = list(x); xp[n] += h
            xm = list(x); xm[n] -= h
            ap = alphas_only(xp, w, M)
            am = alphas_only(xm, w, M)
            for j in range(M - 1):
                dal = (ap[j] - am[j]) / (2 * h)
                s = dal - w[n] * P[j][n]**2
                Fj = 2 * w[n] * be[j - 1] * P[j][n] * dP[j - 1][n] if j >= 1 else mp.mpf(0)
                Fj1 = (2 * w[n] * be[j] * P[j + 1][n] * dP[j][n]
                       if j + 1 <= M - 1 else mp.mpf(0))
                worst = max(worst, abs(s - (Fj1 - Fj)))
        tag = 'uniform' if uniform else 'random '
        print(f"  [1] M={M:>3} {tag} weights: max |s - (F_j+1 - F_j)| = "
              f"{mp.nstr(worst, 3)}")
        return worst


def check_mirror():
    k, N = 4, 60
    C = np.load(os.path.join(LOGM, f'corr_cache_mirror_k{k}_N{N}.npz'))['C']
    M = N - k
    with mp.workdps(300):
        zn = [(mp.mpf(n) - mp.mpf(1) / 2) * mp.pi for n in range(k + 1, N + 1)]
        x = [1 / z**2 for z in zn]           # descending
        w = [mp.mpf(1) / M] * M
        al, be, P, dP = jacobi_mp(x, w, M)
        # bounded check: sum_i P[i][n]^2 == M (Christoffel at atoms)
        cmax = max(abs(mp.fsum(P[i][n]**2 for i in range(M)) - M) for n in range(M))
        print(f"  [2] mirror M={M}: Christoffel-at-atoms max dev = {mp.nstr(cmax, 3)}")
        F = [[mp.mpf(0)] * M]
        for j in range(1, M):
            F.append([2 * w[n] * be[j - 1] * P[j][n] * dP[j - 1][n] for n in range(M)])
        F.append([mp.mpf(0)] * M)            # F_M = 0
        # identity vs cache: s_cache(j, site m) = C[j,m-2]-C[j,m-3] + q^2, q^2 = P^2/M
        # ANCHOR (the +-1 the task file flagged, now pinned at the identity layer):
        # 0-based column c of C = site c+1 = atom index c in input order, and the
        # C-summand at site sig IS s(j, sig) = dalpha/dx - q^2 (no q^2 re-addition
        # -- the first version of this check double-counted q^2; error was exactly
        # q^2, full-prefix off by the sum rule 1).
        worst = 0.0; worst_top = 0.0
        for j in range(1, M):
            for sig in range(1, M + 1):
                s_cache = (C[j, sig - 1] - C[j, sig - 2]) if sig >= 2 else C[j, 0]
                s_pred = float(F[j + 1][sig - 1] - F[j][sig - 1])
                worst = max(worst, abs(s_cache - s_pred))
        # top row full-prefix
        acc = mp.mpf(0)
        for msite in range(2, M + 1):
            acc = -mp.fsum(F[M - 1][i] for i in range(msite - 1))
            worst_top = max(worst_top, abs(float(acc) - C[M - 1, msite - 2]))
        print(f"      identity vs cstep cache (all rows/sites): max err = {worst:.3e}")
        print(f"      top row C(M-1,.) = -prefix F_(M-1):        max err = {worst_top:.3e}")


if __name__ == '__main__':
    check_random(8, True, 1)
    check_random(8, False, 2)
    check_random(12, False, 3)
    check_mirror()
