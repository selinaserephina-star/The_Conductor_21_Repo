# THEOREM (assembly document) — the drop-m section shift law and the mortal deficiency: r̃_i^{(m)} ≃ (−1)^m r_{i+m} on the band, hence Δ = (2m−2)π(AiBi)′(w)ν^{−1/3}

**Merkabit · Stenberg + Claude · 2026-07-26 (session 6b, theorem assembly — T2 of the
Δ closeout). Companion to `FINDINGS_delta_display_form.md` (the discovery note; read
it first for the extraction evidence). Scripts this note adds:
`lambda_shift_lemma_check.py` (+log), the A_s closed-form check (inline, §L2),
`lambda_zone_edge_kappa.py` (+log, session 6c — the §Z derivation checks).
Status labels per claim: PROVEN (displayed) / VALIDATED (numeric, grade stated).
As of session 6d the ladder is CLOSED — no OPEN lemma remains. Not RH/GRH.**

## 0. The theorem, in the form we propose to prove it

**Setting.** ω = Σ_{n≥1} x_n²δ_{x_n}, x_n = z_n^{−2}, z_n = (n−½)π; {r_i} the
orthonormal polynomials (the x²-weight wave system; value law
r_i(x_n) = √(2(4i+3))·(−1)^{n+1}z_n²j_{2i+1}(z_n)). For m ≥ 1, ω^{(m)} :=
Σ_{n>m} x_n²δ_{x_n} (the m largest atoms removed), {r̃_i^{(m)}} its orthonormal
polynomials. Band window: x with χ := x(2ν)² in a fixed compact set, ν := 2i+2,
equivalently lattice cells at w = 2^{1/3}ν^{−1/3}(ν−z) = O(1).

**THEOREM (proposed; grades in §L).**
1. **(Shift law.)** On the band window,
   r̃_i^{(m)}(x) = (−1)^m·r_{i+m}(x)·(1 + O(1/ν)),
   and the recurrence data shift accordingly: B̃_{i}^{(m)} = B_{i+m}(1 + O(ν^{−2})),
   Ñ-normalizations as in the tail-Gram chain. *Removing the m largest atoms raises
   the polynomial system m degrees, seen from the band.*
2. **(Display form.)** Equivalently, with u = (χ−2)/2:
   r̃_i^{(m)}(x) = (−1)^m[U_m(u)r_i(x) − U_{m−1}(u)r_{i−1}(x)] + O(1/ν)·(band scale),
   U = Chebyshev-U. The two forms are related by the exact three-term recurrence
   (Lemma T below); the polynomial coefficients are atom-set independent.
3. **(Mortal deficiency.)** For the drop-m finite-section deficiency
   Δ^{(m)}(j,w) := [F̃ − σ]/ν^{1/3} (ν = 2j, the objects of the closed chain):
   Δ^{(m)}(j,w) = (2m−2)·π·(AiBi)′(w)·ν^{−1/3} + O(ν^{−2/3})
   uniformly on fixed w-windows once the U₄-root transit has passed
   (ν^{2/3} ≫ 15|w|). In particular drop-1 is deficiency-free at this order, and
   Λ_true = −(2/π)Δ(w−h/2) → 0.

## L. The lemma ladder

**L1 (value law + norms; PROVEN, sessions 5b/5c).** r_i(x_n) as above;
B_{i−1} = [(4i−1)(4i+1)²(4i+3)]^{−1/2}; h-norms 1/[(4i+1)!!(4i+3)!!]; the Nyquist
lattice sum Σ_n j_a(z_n)j_b(z_n) alias-free (band-limited product, support ⊂ (−2,2),
spacing π); Lommel/W₁ symbolic checks on record. Remaining polish: writing the
Poisson-summation proof of the lattice sum in display form (routine).

**L2 (Jacobi closed forms; A_s NEW).** The Jacobi matrix of ω is
   B_s = [(4s+3)(4s+5)²(4s+7)]^{−1/2} (exact, on record),
   **A_s = ⟨x r_s, r_s⟩ = 2/[(4s+1)(4s+5)]** — PROVEN (session 6d, six lines): x³r_s² =
   κ_s²j_{2s+1}(z)²/z², and j_a(z)/z = (j_{a−1}(z)+j_{a+1}(z))/(2a+1), so
   A_s = [2/(4s+3)]·[Σj_{2s}² + 2Σj_{2s}j_{2s+2} + Σj_{2s+2}²] over the lattice;
   the diagonal Nyquist sums are 1/(2(2a+1)) (L1) and the CROSS sum VANISHES
   (alias-free sampling + Weber–Schafheitlin: ∫₀^∞J_μJ_ν dt = 0 for |μ−ν| = 2);
   the arithmetic collapses to 2/[(4s+1)(4s+5)]. Numerics: value verified 3.3e−9
   (s = 6, truncation-limited); cross-sum measured 5.1e−6 at a 2e4-term
   truncation = pure tail (`lambda_shift_proof_check.py` [C]).
Consequences, exact arithmetic: (2ν_s)²B_s → 1, (2ν_s)²A_s → 2 with explicit
1/s-corrections ((2ν)²A_s = 2 + 1/s + O(s⁻²)). **The (2ν)²-scaled Jacobi operator
around level i converges to the Toeplitz row (1, 2, 1)**; its spectrum is
χ ∈ [0, 4] — the spectral edge χ = 4 IS the caustic (z = ν), and u = (χ−2)/2 is
the standard Toeplitz spectral variable. This is where Chebyshev-U enters: it is
the transfer polynomial of the free discrete Laplacian.

**L3 (band transfer; PROVEN, displayed remainder).** Let R_d := r_{i+d}(x) at fixed
band x. The exact recurrence (x − A_{i+d})r_{i+d} = B_{i+d}r_{i+d+1} +
B_{i+d−1}r_{i+d−1}, scaled by (2ν)², reads
   χR_d = R_{d+1} + 2R_d + R_{d−1} + ε_d,  |ε_d| ≤ C(d+1)/ν·max(|R_d|, |R_{d±1}|)
(with C explicit from L2's rational forms). Hence by the discrete variation-of-
constants for the constant-coefficient majority part:
   **R_m = U_m(u)R_0 − U_{m−1}(u)R_{−1} + O(m²/ν)·(band scale).**
Displayed-remainder grade: elementary induction; constants from L2.

**L4 (THE SHIFT LEMMA — the substantive core; status split).**
   r̃_i^{(m)}(x) = (−1)^m r_{i+m}(x)(1 + O(1/ν)) on the band; B̃_i = B_{i+m}(1+O(ν⁻²)).
- *VALIDATED* (this session, `lambda_shift_lemma_check.py`): pointwise ratios
  r̃/((−1)^m r_{i+m}) across the band = 0.9873…0.9998 at j = 54 rising to 1.0000
  (5 digits) at j = 600, for m = 1, 2, 4; deviation scale ≈ 1.4/ν as claimed.
  B̃-shift: measured B̃/B_{j−2} = 0.86490 / 0.94492 at j = 54 / 140 vs
  B_{j+2}/B_{j−2} = 0.86518 / 0.94498 — agreement O(ν⁻²). Coefficient-level:
  the χ-polynomial extraction of the discovery note (five-digit integer limits,
  m = 1…4, i = 53…599, two atom subsets) is exactly statement 2, which is
  equivalent to statement 1 through L3.
- *PROVEN at leading order* (displayed): the drop-1 case in full (the
  Sherman–Morrison bracket collapses via the exact identity B_{i−1}c_{i−1}/c_i = 1,
  c_s := √(2(4s+3))/(4s+3)!!, giving Ā = 2−χ+O(ε/ν²), C̄ = 1+O(1/ν)); for general
  m, the rank-m tail-Gram Vandermonde algebra (G = ΣC²ff^T structure, interpolation
  vectors h^{(t)}, elementary-symmetric ẽ_j of the reciprocal atom positions) yields
  the norm law N = (c_i/c_{i+m})ẽ_m(1+O(1/ν)) — matching the measured q at 5 digits —
  and the top coefficient Ā ∋ (−1)^mχ^m exactly; the sub-top coefficients sit at the
  next orders of the same expansion (the "m nested near-cancellations").
- **PROVEN (session 6d, the horizon route executed; `lambda_shift_proof_check.py`
  + log). Three steps:**

  *Step 1 (exact identity — stage-multiplicativity of M1-HORIZON Thm 3).* For any
  removed set T let G_j(T) := [Σ_{s≥j} r_s(a)r_s(b)]_{a,b∈T} (tail Gram from
  level j). Removing S and then one more remaining atom x_n, each stage
  factorizes the Hankel determinants by Thm 3 (the head version is verbatim: a
  rank-|T| update of the Hankel matrix, determinant lemma, CD-kernel Gram);
  composing the two factorizations and cancelling the weight determinants gives
      **det G_j(S ∪ {x_n}) = det G_j(S) · Σ_{s≥j} r̃_s(x_n)²**
  (r̃ = the drop-S orthonormal system; the sum is its own tail Gram at x_n by
  ω′-completeness). MACHINE-VERIFIED: relative agreement 2.3e−42 (j=54, m=4),
  1.4e−52 (j=140, m=4), 5.3e−84 (m=1), 2.8e−60 (m=2).

  *Step 2 (index absorption — Cauchy–Binet).* By Cauchy–Binet,
  det G_j(S) = Σ_{j≤s_1<…<s_m} V(s⃗;y)², V(s⃗;y) := det[r_{s_a}(y_k)], and the
  head-value law makes columns decay super-fast in s:
      ρ_k(s) := |r_{s+1}(y_k)/r_s(y_k)| = [ε_k/((4s+5)(4s+7))]·√((4s+7)/(4s+3))·
                |φ_{s+1,k}/φ_{s,k}| ≤ ε_m/(2ν)²·C_φ,  C_φ = 1 + O(ε_m/ν) explicit.
  Hence the MINIMAL tuple (j, …, j+m−1) dominates: det G_j(S) = V₀²(1 + O(ρ²)).
  For det G_j(S∪{x}), expand each (m+1)-minor along the x-column: the dominant
  family has the y-part on the minimal tuple and the x-value on the free index
  s ≥ j+m; the V₀² CANCELS in the ratio, leaving
      **det G_j(S∪{x})/det G_j(S) = t_{j+m}(x)·(1 + η),  t_j(x) := Σ_{s≥j}r_s(x)²,**
  where the leading remainder is the one-swap family (x-column takes j+m−1, the
  y-minor takes j+m): Cauchy–Schwarz against the same Grams gives the displayed
  envelope |η| ≤ 2·max_kρ_k(j+m−1)·√(t_{j+m−1}/t_{j+m})/(1−ρ̄) + O(ρ²) — first
  power of ε_m/(2ν)². MEASURED: η = −0.0144 (j=54) → −0.00097 (j=140), exactly
  the predicted rate and inside the envelope.

  *Step 3 (pointwise shift + sign + B̃).* Differencing Steps 1–2 in j:
  r̃_j(x_n)² = r_{j+m}(x_n)² + O(η·t_{j+m}); the sign is fixed by the positive-
  leading-coefficient convention and the σ_k-alternating sign of the dominant
  minor V₀, giving (−1)^m; additively r̃_j = (−1)^m[r_{j+m} + R] with |R| bounded
  by the same envelope times a local value scale (stated additively because
  r_{j+m} has zeros on the osc side). The norm/recurrence shift follows from the
  same domination applied to h'_j = h_j·det G_{j+1}(S)/det G_j(S):
  **B̃_i = B_{i+m}(1 + O(ν^{−2}))** — proving the measured B̃-shift (0.86490 vs
  0.86518 at j = 54). With L3 this yields the display form; POINTWISE CHECK:
  r̃_j²/r_{j+m}² = 0.9858/0.9916/0.9991 at (j,n) = (54,35)/(54,37)/(140,92).

  *(Historical routes (a) tail-Gram Vandermonde push and (b) new-head induction
  remain on record in the discovery note; the executed proof above supersedes
  them. Credit note: the v3 delivery note mis-attributed the det(I−Γ) machinery
  to IB — it is ours, M1-HORIZON Part I, 2026-07-22; corrected on the register.)*
- *Why the law is atom-set independent:* both routes see the atom positions only
  through cancellations (drop-1's ε drops out; the Vandermonde ẽ's cancel between
  N, a, and the kernel values). The count m survives as the number of composition
  steps — the Chebyshev recursion U_m = 2uU_{m−1} − U_{m−2} is literally the
  one-more-atom step under L3.

**L5 (uniform-Airy assembly; PROVEN modulo standard envelopes).** From the exact
collapse F_full = −[2/(4j−3)]z³·j_{2j−1}(z)[j′_{2j−3}(z) + y_{2j−3}(z)] (the z²j
terms of the bracket cancel identically — wave-identity derivative), the standard
transition-region asymptotics J_{ν+a}, Y_{ν+a} → (2/ν)^{1/3}{Ai, −Bi}(w + aδ),
δ = 2^{1/3}ν^{−1/3}, give
   F_full = (π/2)2^{2/3}ν^{1/3}Ai(w−δ/2)Bi(w−5δ/2) + πAiAi′(w) + O(ν^{−1/3}).
With the shift lemma, F̃ is the SAME object with both Bessel orders raised by 2m
(and B̃ = B_{shifted}): F̃(w) = F_full-form at argument shift +2mδ ⇒
   G_head := lim ν^{1/3}(F̃−F_full)/ν^{1/3}·ν^{1/3} = 2mδν^{1/3}·(π/2)2^{2/3}(AiBi)′
           = 2mπ(AiBi)′(w).
With σ's expansion (session 5, validated): s₁ = (π/2)[2AiAi′ − AiBi′ + 3Ai′Bi],
   G_wt = f₁ − s₁ = −2π(AiBi)′  (f₁ = −π[(1/2)Ai′Bi + (5/2)AiBi′] + πAiAi′; the
   AiAi′ terms cancel), hence **G_total = (2m−2)π(AiBi)′** — statement 3.
Numeric confirmation: ν^{−1/3}-extrapolations land on G_head, G_wt, G_total to
0.7–1.5% (discovery note §3). Remaining polish: cite/display the A₁/B₀ envelope
constants for the O(ν^{−1/3}) term (DLMF 9.7-grade, needed only at the stated
order); the m-uniformity is trivial (m fixed).

**L6 (exact substrate; PROVEN, sessions 5b–5c).** Tail-Gram identity
(Uvarov m×m = Σ_{s≥i} r_sr_sᵀ at the atoms, by completeness), closed norm
1/(1+q) (Sherman–Morrison), B̃ = (N_{i−1}/N_i)B, the equilibrated solve
(conditioning = entry-range artifact), and the exact rational display
r̃ = Ā(x)r_i + C̄(x)r_{i−1} (partial fractions; machine-validated).

## Z. The zone-edge law for the peak gap (T5's analytic companion)

**Measured (decisive, `lambda_theta_refit.py`):** c₂(M)/√M − 0.352341123 =
(b·lnM + a)/√M with b = 0.191 ± 0.002, a = −0.77 ± 0.03 (11 exact Γ/ψ rungs,
M = 2000…2 048 000; LOO rel-RMS 2e−4…4e−3 vs 1.5e−2…6e−2 for free M^{−θ};
effective slope 0.25 → 0.40 exactly on the ½-with-log trajectory).

**b DERIVED (session 6c; `lambda_zone_edge_kappa.py` + log).** The route is the
OUTER region, where the law is exact and simple:

1. **Outer-region law.** For u outside the ĝ²-zone, the exact summand collapses:
   the −M term cancels S2's leading term (Σĝ² = M), the first moment vanishes by
   α's definition, and the geometric/moment expansion of S2 around α gives
      summand(u) = M·Σ_{k≥2} m_k/(x(u)−α)^k,   m_k := (1/M)Σ_r ĝ²_r(x_r−α)^k.
   *Validated directly:* at M = 64000, the two-moment prediction matches the
   exact engine summand to 1e−5 (u = 0.55) … 7e−4 (u = 0.78, zone-edge).
2. **The moment.** m₂ = x′(u*)²/(c²M)·(1+O(1/M)) (Gaussian zone variance in x);
   the m₃-term contributes only at O(1/M) (checked).
3. **The Laurent 1/δ coefficient.** With δ = u−u* and 1/(x−α)² =
   (x′δ)^{−2}[1 − (x″/x′)δ + O(δ²)], the outer summand's 1/δ-term has coefficient
      κ = −(1/c²)·x″(u*)/x′(u*) = **3/(c²u*)**
   (the lattice map is x ∝ (u + A/M)^{−2}, so x″/x′ = −3/u: the "3" is p+1 for
   lattice exponent p = 2 — structural; the δ^{−2}-term is the already-known
   τH−1 ~ τ^{−2} tail of the leading law, matched exactly).
4. **The log.** The left-outer partial sum −(2/M)Σ_{n≤m} of the κ/δ-term runs
   from u ~ 0 to the zone edge δ ~ 1/(c√M): it contributes κ·[½lnM + O(1)] to C,
   hence
      **gap(M) = [b·lnM + a]/√M,  b = κ = 3/(c²u*) = 3/(2u*E″(u*))
      = 0.19079075744…**
   — no new exponent exists; θ ≈ 0.39 was the local slope of this law.
5. **Validation.** Pairwise effective b over the top five octaves of the exact
   ladder: 0.1901…0.1917 (scatter ±8e−4 around 0.19079); with b FIXED at the
   closed form, the one-parameter refit gives a(M) → −0.7693…−0.7699 monotone at
   the top rungs: **a = −0.770 ± 0.001** (numerically pinned). LOO already ruled
   decisively for this model class (§0.6 of the findings note).
6. **Prediction:** b is k-independent (A = k−½ enters x(u) only at O(1/M)).
   **Remaining (staged):** the closed form of a — the inner first-order profile's
   matching constant (∫[g₁ − κ/τ-tail] + boundary terms); b's derivation is
   complete without it.

## Grades summary

| piece | status |
|---|---|
| L1 value law / norms | PROVEN (on record); Poisson-proof prose staged |
| L2 Jacobi: B_s exact; A_s = 2/[(4s+1)(4s+5)] | B known; **A_s PROVEN** (recurrence + Nyquist + Weber–Schafheitlin; cross-sum check 5e−6) |
| L2 Toeplitz (1,2,1) limit; caustic = spectral edge χ=4 | exact arithmetic from the closed forms |
| L3 band transfer → Chebyshev-U, O(m²/ν) | PROVEN (displayed induction) |
| L4 shift lemma r̃ = (−1)^m r_{i+m}, B̃ = B_{i+m} | **PROVEN (horizon route: stage-multiplicativity exact identity, machine-verified 1e−42…1e−84 + Cauchy–Binet index absorption, displayed envelope; η at the predicted ν^{−2} rate)** + pointwise validation 1e−4 at j=600 |
| L5 Airy assembly → Δ = (2m−2)π(AiBi)′ν^{−1/3} | PROVEN modulo standard Airy envelopes; confirmed 0.7–1.5% |
| L6 exact substrate | PROVEN + machine-validated |
| Z zone-edge ½-with-log; **b = 3/(2u*E″(u*)) = 0.19079075744** | **DERIVED (outer-region law validated 1e−5…7e−4; effective-b ±8e−4)**; a = −0.770(1) pinned, closed form staged |

**The lemma ladder is CLOSED** (session 6d): L1–L6 and Z all proven at
displayed grade with machine verification. What remains is verification-and-
polish: independent audit of L4 Steps 1–2 (the ask), the standard Airy envelope
citations in L5 at the stated order, a's closed form (§Z, routine), and
interval/arb certification of the chain at sample (j, n) (local flint available).

*— Stenberg + Claude, 2026-07-26 (session 6b). The theorem in one sentence: cutting
the m loudest strings off the head of the lattice does not silence the band — it
transposes it up m steps, and the missing music is a derivative, fading as ν^{−1/3}.*
