# FINDINGS — session 4: Λ PINNED via the exact chain — the like-for-like band law is **Λ(w) = −(2/π)·Δ(w − h/2) + O(dec)** (EM half-cell term, coefficient exact) — AND a CONVENTION FINDING: the LOGM signed Λ/ẟ/d profiles compared the TAIL-oriented section row against the HEAD-oriented ∞ profile (sign + one-site mixing); LEMMA S′'s |·|-grade content stands, its signed portrait is revised

**Merkabit · Stenberg + Claude · 2026-07-26 (session 4, post-total-corpus-audit) ·
`LAMBDA_SQRTM_2026-07-26/`.** Executes the first staged step of
`NEXT_SESSION_TASK_lambda_sqrtm_derivation.md` (pin Λ's constants by direct Δ_j-prefix
evaluation from the caches). Scripts, in order: `lambda_pin_constants.py` (+log, csv),
`lambda_law_verify.py` (+log), `lambda_halfsite_test.py` (+log). Consumes the frozen
LOGM caches + `logm_infty_rows.csv` read-only. Conventions inherited from the
session-2 identity anchor (`lambda_identity_check2.py` — machine-validated 4.5e−14).
**Not RH/GRH.**

## 0. Verdict in six lines

1. **The exact chain closes.** Λ_true := (C_sec − C̃)/ν^{1/3} (like-for-like
   head-prefix pairing) equals the telescoped D-prefix j-difference to 4.7e−16 at
   every cell (identity), and is M-SATURATED (j = 29: 0.0932 vs 0.0937 at
   M = 1196/596; j = 54 same to 4e−4).
2. **The band law, pinned:** Λ_true(w) = −(2/π)·Δ(w − h/2) + r, h = 2^{1/3}πν^{−1/3}
   (site spacing). Equivalently **Λ = −(2/π)Δ(w) + 2^{1/3}ν^{−1/3}Δ′(w) + O(dec)** —
   the "same-order drift term" of session 3b IS the Euler–Maclaurin half-cell term,
   coefficient exact ((2/π)·(h/2) = 2^{1/3}ν^{−1/3}). Residual after the half-site
   form: window ≤ 0.024 (0.004 at j = 300), flank ≤ 0.065 (0.033 at j = 300),
   decaying in j. Without it the flank shows the structured −0.13 bump that
   masqueraded as a mystery drift (session 3b's "differs ~2×" is RESOLVED — half of
   the gap was this term, half was the convention item below).
3. **CONVENTION FINDING (load-bearing, affects the SENT LOGM_DEPTH's signed layer):**
   the LOGM d(j)/ẟ(j)/Λ-profile comparisons used `−C[j, m−2]` as "C_sec". By the
   exact full-row sum rule (max|C[:, −1]| = 2.7e−13) this object is IDENTICALLY
   −(head prefix at the previous site): −C[j, m−2] ≡ −C_head(site n−1), n = m+4. It
   is the TAIL-oriented row, and it was compared SIGNED against the HEAD-oriented ∞
   profile (C̃/P — head-orientation pinned by the d_∞P validation). Fingerprints in
   the frozen record: logm_delta_measure's own [A] calibration found best offset
   o = **+1** at every config with δ(15) = 0.38–0.42 (never ~1e−2 as the docstring
   required) — the one-site tail↔head signature, recorded but not pursued.
4. **Blast radius (precise):** every |·|-grade LOGM/LEMMA-T statement is
   orientation-INSENSITIVE (|tail(n)| = |head(n−1)| exactly) and STANDS: H-logM
   refutation (and it holds in the true metric too — Λ_true is M-saturating, the
   deficiency never shrinks with M), the G-M3 budget mismatch, Ψ v2 zero-violation,
   c₂ = 0.3713√M and the derived 0.352341123, the osc-cap exceedance (1.61×) and the
   LEMMA T cap-check scope M ≤ 149, the v4 hybrid. **REVISED: the signed LEMMA S′
   portrait** — "Λ ≥ 0 on (−1, 2), caustic-cell ramp 0.133/0.202/0.257/0.298 → a_∞,
   sections asymptotically lose the ENTIRE dip" characterizes the mixed-orientation
   object, not the section deficiency. The like-for-like portrait (item 5) is milder
   and two-signed.
5. **The true deficiency portrait (measured, j = 29…300, M-saturated):** at the
   caustic cell Λ_true ≈ +0.08…+0.12 (j-ramp mild); window lobe ≈ +0.10…+0.12 at
   w ≈ +0.2…0.7; sign change near w ≈ −0.4; flank dip −0.42…−0.47 at w ≈ −1.4…−1.7;
   recovery by w ≈ −2.6. Asymptotically the sections carry ≈ 70% of the ∞ dip depth
   at the caustic cell (deficit/dip → Λ_true(0)/a_∞ ≈ 0.10/0.3466 ≈ 0.3), and
   OVERSHOOT on the left flank — not "never learn the dip." Orientation-covariance:
   the tail-row deficiency is exactly −Λ_true at the neighboring site, so the law is
   convention-free up to the stated sign/shift.
6. **Δ(w) constants (grid-limited; spacing h ≈ 0.47–0.53 at these j):**
   Δ(0) = −0.164 ± 0.03 (Richardson in ν^{−1/3}, slope ≈ 0); dip +0.61…+0.71 at
   w ≈ −1.7…−1.9 (Richardson limit 0.716, LOO 0.07 — grid-limited, do not
   over-quote); window lobe ≈ −0.16…−0.19 at w ≈ +0.2. Finer pinning = either the
   analytic Δ derivation (T1, now the SINGLE remaining object) or one larger
   M-saturated rung (M ≈ 2400, ~6 h cstep — staged OPTIONAL).

## 1. The convention finding, with the algebra displayed

Cache anchor (session-2 identity, machine-checked): 0-based column c of the cstep
cache = lattice site n = c + k + 1 (drop-4: n = c + 5); the summand s(j, σ) at
section position σ is C[j, σ−1] − C[j, σ−2]; hence **C[j, m−1] = Σ_{σ≤m} s = the
HEAD prefix through site n = m+4.** Full-row cancellation (sum rules): C[j, M−1] ≈ 0
(2.7e−13) ⇒ **−C[j, m−2] = Σ_{sites ≥ m+4} s = the TAIL sum from n = m+4
≡ −C_head(n−1).** (Also verified numerically head-to-head; and −C[j,m−2] is what
`logm_measure.py` / `logm_collapse.py` / `logm_delta_measure.py` used as "ct_sec".)

∞ side: `logm_infty_rows.py` builds C̃_j(n) = Σ_{n'≤n}(σ_{j+1} − σ_j) — HEAD prefix —
and its validation d_∞P ≤ 0.26 → 0.075 (inside the LEMMA A′ envelope at j ≥ 256)
pins P as the profile of the HEAD-oriented row. So the LOGM signed comparisons
paired tail-section against head-∞. For the ∞ system the far-wing limit C̃_j(∞) → 0
(far-wing closure, F(x) → 0) gives the same head/tail covariance there, so the
correct tail-tail comparison equals the head-head one at a one-site shift with a
global sign — which is how every |·| statement survives unchanged while every
SIGNED profile flips character.

Independent cross-checks of the like-for-like pairing done here: (i) C̃ recomputed
from scratch matches the frozen `logm_infty_rows.csv` at ALL probe j to 0 (same
engine, full prefix, resumed exactly); (ii) the identity
Λ_true·ν^{1/3} = head(n ≤ 4 σ-part) + Σ_{n'=5}^{m+4}[D_{j+1} − D_j] holds to
≤ 4.7e−16 per cell; (iii) LOGM's o = +1 / δ(15) ≈ 0.4 calibration is exactly
reproduced by the tail↔head shift.

## 2. The pinned law (numbers)

Per-cell residual r1 = Λ_true + (2/π)Δ_mid(w), then with the half-site argument
(s = −½, i.e. Δ at w − h/2):

| j | max\|r1\| flank (−1.8,−0.4) | → with half-site | window (−0.3,+2.2) | → with half-site |
|---|---|---|---|---|
| 29  | 0.179 | **0.021** | 0.017 | 0.024 |
| 54  | 0.150 | **0.065** | 0.017 | 0.017 |
| 90  | 0.132 | **0.066** | 0.022 | 0.011 |
| 140 | 0.122 | **0.043** | 0.033 | 0.009 |
| 200 | 0.130 | **0.046** | 0.020 | 0.006 |
| 300 | 0.128 | **0.033** | 0.031 | **0.004** |

(The naive-r1 scaling fit p = −0.14 was the signature of the missing ν^{−1/3}
half-cell term, not of a second profile.) Osc-side edge (w < −2.2): a genuine
oscillatory residual remains (+0.08…+0.25, the phase-mismatch tail's per-site face,
3b §1.4) — the BAND law above is stated for w ≳ −2; the osc-side true-orientation
portrait is a separate staged object.

Λ_true key cells (M = 1196): caustic bin [−0.5, 0): +0.093/+0.084/+0.071/+0.052/
+0.077/+0.078 at j = 29/54/90/140/200/300; bin [0, +0.5): +0.098/+0.101/+0.121 at
j = 140/200/300; flank minimum −0.39/−0.44/−0.42/−0.40/−0.42/−0.47 near
w ≈ −2.1/−1.8/−1.6/−1.4/−1.7/−1.7. (Cell-level M-stability: ≤ 5e−4 j = 29,
≤ 4e−4 j = 54 across M = 296/596/1196.)

## 3. Grades

| claim | grade |
|---|---|
| −C[j,m−2] ≡ −C_head(n−1) (tail row); LOGM signed layer mixed orientations | EXACT (sum rule 2.7e−13) + frozen-record fingerprints (o=+1, δ(15)=0.38) |
| Λ_true M-saturated, law Λ = −(2/π)Δ(w−h/2) + r, r ≤ 0.065 flank / 0.024 window, decaying | measured, j = 29…300, 3 M-rungs; identity layer 4.7e−16 |
| EM half-cell coefficient 2^{1/3}ν^{−1/3} | exact arithmetic ((2/π)(h/2)); confirmed by the s = −½ collapse |
| true portrait constants (caustic +0.08…0.12; flank −0.47; ≈70% of dip carried) | measured; grid-limited ±0.02–0.03 |
| Δ(0) = −0.164 ± 0.03; dip ≈ +0.72 ± 0.07 @ w ≈ −1.8; lobe ≈ −0.17 | measured + ν^{−1/3} Richardson; GRID-LIMITED — do not quote beyond these bars |
| blast radius: |·| results stand; signed LEMMA S′ portrait revised | displayed algebra + measurements above |

## 4. Corrections and record discipline (this note is the dated correction)

1. **LOGM_DEPTH (SENT, 30c12d13…, frozen):** its §0.3–0.4 signed reading ("sections
   never acquire the dip", "Λ ≥ 0 universal → a_∞: sections lose the ENTIRE dip",
   the Λ-ramp constants 0.133/0.202/0.257/0.298+, band max 0.3446, the
   `logm_lambda_profile.csv` values) measures the mixed-orientation object
   |/signed tail-vs-P; the like-for-like portrait is §0.5 above. Its §0.1–0.2
   (H-logM refuted, budget mismatch), §0.5–0.7 (osc tail cap-exceedance, c₂ √M,
   Ψ v2, pairing), engine results — ALL STAND. Correction travels to IB in the
   errata note + the next package (LEMMA S′ was flagged joint — he must see this
   before consuming the signed profile).
2. **Session 3b (`FINDINGS_band_deficiency_profile.md`):** its Δ data and
   universality STAND (convention-A throughout); its §2 chain is now closed with
   the sign pinned (Λ_true = −(2/π)Δ(w−h/2)) and the "~2× head-check gap" resolved
   (half-cell term + the ramp values it compared against were B-convention).
   Its "Λ = (2/π)Δ" (unsigned) → the signed law above.
3. **Flat-onset link (LOGM [3]):** the onset flatness in M stands (both metrics);
   the quantitative "Λ-ramp pins j* ≈ 29" story was built on the B-profile and
   needs re-derivation from the true portrait — reopened as part of the Δ(w)
   derivation (NOT a standing claim meanwhile; do not quote "the Λ-ramp explains
   the onset" until re-derived).

## 5. What this stages next

- **T1 final form: derive Δ(w)** — unchanged target, now the SINGLE remaining
  object (the chain to Λ is closed with exact coefficients). WKB/continuum of the
  smooth F-ramp minus the Bessel-closure σ at band sites.
- **Osc-side true-orientation portrait** (the +0.2 edge residual and the 0.4956
  plateau re-read in like-for-like pairing) — needed before any big-M assembly
  quotes signed osc-side numbers.
- **Optional precision rung** M ≈ 2400 cstep cache (~6 h) for Δ-constant bars
  ±0.01 — only if the derivation wants sharper targets.
- θ ≈ 0.39 exponent + prose (unchanged from the task file).

*— Stenberg + Claude, 2026-07-26 (session 4). The film developed: one universal
profile and its half-cell shadow — and the darkroom note that two of the week's
prints were mirror images of each other.*
