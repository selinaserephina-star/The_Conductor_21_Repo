r"""
lambda_confirm_scaling.py -- confirmation layer for the two mechanisms found in
lambda_mechanism_probe.py.

[C] SUMMAND M-SATURATION: s_sec(j=200, caustic window) at M = 296 vs 596 vs 1196 --
    if the smooth (oscillation-free) shape is M-stable, the deficiency saturation
    is confirmed at the per-site level (not just in the prefix sums).
[D] TOP-ROW SCALING COLLAPSE: C(M-1, m)/sqrt(M) vs u = m/M across
    M = 56...1196 -- the candidate law C(M-1, uM) = sqrt(M) F(u); print the
    profile on a common u-grid, the peak location/height per M, and the spread.
    Also rows M-2, M-3 scaled the same way (do they collapse to their own
    profiles? -- the boundary LAYER structure).
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (LAMBDA_SQRTM session).
"""
import os, math
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
LOGM = os.path.join(HERE, '..', 'LOGM_DEPTH_2026-07-26')
C13 = 2**(1 / 3)


def lanczos_q(x):
    n = len(x)
    V = np.empty((n, n))
    v = np.full(n, 1.0 / math.sqrt(n))
    V[0] = v
    al = np.empty(n); be = np.empty(n - 1)
    w = x * v; a = v @ w; al[0] = a; w = w - a * v
    for j in range(1, n):
        b = np.linalg.norm(w)
        be[j - 1] = b
        vn = w / b
        Vj = V[:j]
        vn -= Vj.T @ (Vj @ vn); vn -= Vj.T @ (Vj @ vn)
        vn /= np.linalg.norm(vn)
        V[j] = vn
        w = x * vn - b * V[j - 1]
        a = vn @ w; al[j] = a; w = w - a * vn
    J = np.diag(al) + np.diag(be, 1) + np.diag(be, -1)
    ev, U = np.linalg.eigh(J)
    q = np.zeros((n, n))
    for r, nn in enumerate(np.argsort(x)):
        col = U[:, r]
        if col[0] < 0:
            col = -col
        q[:, nn] = col
    return q


def mirror_atoms(k, N):
    zn = (np.arange(k + 1, N + 1) - 0.5) * math.pi
    return 1.0 / zn**2


print("== [C] s_sec(j=200) caustic window across M (smoothness / M-stability) ==")
j = 200
nu = 2.0 * j
mstar = int(round(2 * j / math.pi))
qs = {}
for N in (300, 600, 1200):
    C = np.load(os.path.join(LOGM, f'corr_cache_mirror_k4_N{N}.npz'))['C']
    q = lanczos_q(mirror_atoms(4, N))
    qs[N] = (C, q)
print("     m    w      M=296        M=596        M=1196")
for m in range(mstar - 6, mstar + 7):
    w = C13 * nu**(-1 / 3) * (nu - (m + 4 - 0.5) * math.pi)
    line = f"  {m:>4} {w:+5.2f} "
    for N in (300, 600, 1200):
        C, q = qs[N]
        s = (C[j, m - 2] - C[j, m - 3]) + q[j, m - 1]**2
        line += f"  {s:+10.6f}"
    print(line)

print("\n== [D] top-row scaling collapse: C(M-1, uM)/sqrt(M) = F(u) ==")
Ns = (60, 100, 149, 300, 600, 1200)
profs = {}
for N in Ns:
    C = np.load(os.path.join(LOGM, f'corr_cache_mirror_k4_N{N}.npz'))['C']
    M = C.shape[0]
    row = C[M - 1, :] / math.sqrt(M)
    profs[N] = (M, row)
ugrid = np.arange(0.05, 1.0, 0.05)
print("    u    " + "".join(f"  M={profs[N][0]:<5}" for N in Ns) + "  spread")
for u in ugrid:
    vals = []
    for N in Ns:
        M, row = profs[N]
        idx = int(round(u * M)) - 2
        vals.append(row[idx] if 0 <= idx < len(row) else float('nan'))
    arr = [v for v in vals if v == v]
    print(f"  {u:4.2f} " + "".join(f" {v:+8.4f}" for v in vals) +
          f"   {max(arr) - min(arr):7.4f}")
print("\n  peaks: " + "  ".join(
    f"M={profs[N][0]}: {np.abs(profs[N][1]).max():.4f}@u="
    f"{(np.abs(profs[N][1]).argmax() + 2) / profs[N][0]:.3f}" for N in Ns))

print("\n  rows M-2, M-3 (same scaling), peak/sqrt(M):")
for N in (300, 1200):
    C = np.load(os.path.join(LOGM, f'corr_cache_mirror_k4_N{N}.npz'))['C']
    M = C.shape[0]
    for dj in (2, 3):
        row = np.abs(C[M - dj, :]) / math.sqrt(M)
        print(f"   M={M} j=M-{dj}: peak {row.max():.4f} @ u={(row.argmax() + 2) / M:.3f}")
