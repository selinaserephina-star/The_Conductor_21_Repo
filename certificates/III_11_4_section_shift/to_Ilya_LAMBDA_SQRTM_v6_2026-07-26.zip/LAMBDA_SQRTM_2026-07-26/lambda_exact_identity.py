r"""
lambda_exact_identity.py -- THE EXACT IDENTITY LAYER for the Lambda/F(u) derivation
(T1+T2 of NEXT_SESSION_TASK_lambda_sqrtm_derivation.md; derived this session).

CLAIM 1 (fixed-weight Jacobi tangent map, telescoping closed form). For an atomic
measure mu = sum_n w_n delta_{x_n} (weights FIXED), orthonormal OPs p_i, Jacobi
(alpha_i, beta_i):
    s(j,n) := d alpha_j / d x_n - w_n p_j(x_n)^2 = F_{j+1}(n) - F_j(n),
    F_j(n) := 2 w_n beta_{j-1} p_j(x_n) p'_{j-1}(x_n),   F_0 := 0.
Derivation: alpha_j = sum_m w_m x_m p_j^2; d p_j = delta_{mn}-explicit + coefficient
variation sum_{i<=j} c_i p_i with c_i = -w_n (p_j p_i)'(x_n) (i<j), c_j =
-(w_n/2)(p_j^2)'(x_n) [orthonormality]; three-term recurrence kills the alpha_j term.
=> the section's per-site summand telescopes EXACTLY like the infinite system's
sigma-difference: F_j is the finite-section sigma.

CLAIM 2 (top row exact). p_M vanishes at all atoms => F_M == 0 =>
    C(M-1, m) = -sum_{n<=m} F_{M-1}(n),
and by the CD kernel at nodes [K_M(x_n,x_n) = 1/w_n with off-diagonal 0]:
    beta_{M-1} p'_M(x_n) p_{M-1}(x_n) = 1/w_n,
    p_M(x) = (prod_{i<M} beta_i)^{-1} sqrt(m_0)^{-1} * ell(x),  ell = prod_n (x-x_n)
(uniform weights, mass 1: p_0 = 1) => p_{M-1}(x_n) fully explicit via ell'(x_n).

CHECKS (mirror k=4, N=60 and N=149; float64 vs the cstep caches):
 [1] s(j,n) from cache (diff C + q^2) vs F_{j+1}-F_j from OP recurrences: max abs
     error over all j, n -- gate 1e-8 (cache is exact to ~1e-13; p/p' recurrence
     accumulates a bit at high degree).
 [2] top row: C(M-1, m) vs -prefix of F_{M-1}: same gate.
 [3] CD-at-nodes: beta_{M-1} p'_M(x_n) p_{M-1}(x_n) * w_n = 1 -- max deviation.
 [4] ell-route: p_{M-1}(x_n) via ell'(x_n) products vs recurrence values.
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (derivation session).
"""
import os, math
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
LOGM = os.path.join(HERE, '..', 'LOGM_DEPTH_2026-07-26')


def mirror_atoms(k, N):
    zn = (np.arange(k + 1, N + 1) - 0.5) * math.pi
    return 1.0 / zn**2


def lanczos_full(x):
    n = len(x)
    V = np.empty((n, n))
    v = np.full(n, 1.0 / math.sqrt(n))
    V[0] = v
    al = np.empty(n); be = np.empty(n - 1)
    w = x * v; a = v @ w; al[0] = a; w = w - a * v
    for j in range(1, n):
        b = np.linalg.norm(w)
        be[j - 1] = b
        vn = w / b
        Vj = V[:j]
        vn -= Vj.T @ (Vj @ vn); vn -= Vj.T @ (Vj @ vn)
        vn /= np.linalg.norm(vn)
        V[j] = vn
        w = x * vn - b * V[j - 1]
        a = vn @ w; al[j] = a; w = w - a * vn
    return al, be


def op_values(al, be, xs, mdeg):
    """p_i(xs) and p_i'(xs) for i = 0..mdeg via the recurrences (uniform mass 1:
    p_0 = 1). Returns arrays P[i], dP[i] over the grid xs."""
    L = len(xs)
    P = np.zeros((mdeg + 1, L)); dP = np.zeros((mdeg + 1, L))
    P[0] = 1.0
    if mdeg >= 1:
        P[1] = (xs - al[0]) / be[0]
        dP[1] = 1.0 / be[0]
    for i in range(1, mdeg):
        P[i + 1] = ((xs - al[i]) * P[i] - be[i - 1] * P[i - 1]) / be[i]
        dP[i + 1] = ((xs - al[i]) * dP[i] + P[i] - be[i - 1] * dP[i - 1]) / be[i]
    return P, dP


def qmat(x, al, be):
    J = np.diag(al) + np.diag(be, 1) + np.diag(be, -1)
    ev, U = np.linalg.eigh(J)
    M = len(x)
    q = np.zeros((M, M))
    for r, nn in enumerate(np.argsort(x)):
        col = U[:, r]
        if col[0] < 0:
            col = -col
        q[:, nn] = col
    return q


def check(k, N):
    x = mirror_atoms(k, N)
    M = len(x)
    C = np.load(os.path.join(LOGM, f'corr_cache_mirror_k{k}_N{N}.npz'))['C']
    al, be = lanczos_full(x)
    q = qmat(x, al, be)
    P, dP = op_values(al, be, x, M - 1)      # degrees 0..M-1 (p_M needs beta_{M-1},
    wgt = 1.0 / M                            #  not produced by finite Lanczos)
    # F_j(n), j = 0..M  (F_0 = 0; F_M = 0 EXACTLY since p_M(x_n) = 0 at atoms)
    F = np.zeros((M + 1, M))
    for j in range(1, M):
        F[j] = 2 * wgt * be[j - 1] * P[j] * dP[j - 1]
    F[M] = 0.0

    print(f"== mirror k={k} N={N} (M={M}) ==")
    # [1] identity for all rows j = 1..M-2 (cache rows), sites n = 2..M
    err = 0.0
    for j in range(1, M - 1):
        s_cache = np.empty(M - 2)
        for m in range(3, M + 1):
            s_cache[m - 3] = (C[j, m - 2] - C[j, m - 3]) + q[j, m - 1]**2
        s_pred = (F[j + 1] - F[j])[2:M]
        err = max(err, np.abs(s_cache - s_pred).max())
    print(f"  [1] identity s = F_(j+1) - F_j: max err over j=1..{M-2}, all sites = {err:.3e}")
    # [2] top row
    top_meas = C[M - 1, :]
    top_pred = -np.cumsum(F[M - 1])          # prefix over sites 1..m ; C[.,m-2] = prefix(m-1)
    e2 = np.abs(top_meas[1:] - top_pred[:-1]).max()
    print(f"  [2] top row C(M-1,m) = -prefix F_(M-1): max err = {e2:.3e}")
    # [3] CD at nodes needs beta_{M-1} p'_M; get beta_{M-1} from CD normalization itself:
    # instead verify K_M(x_n,x_n) = sum_{i<M} p_i(x_n)^2 = 1/w = M
    kk = (P[:M]**2).sum(axis=0)
    print(f"  [3] Christoffel at nodes: max|sum p_i^2 - M| = {np.abs(kk - M).max():.3e}"
          f"  (M = {M})")
    # [4] ell-route for p_{M-1}(x_n): p_{M-1}(x_n) = 1/(w_n beta_{M-1} p'_M(x_n)),
    # p_M = ell / (prod beta_i * sqrt(m0)); with mass 1 and leading(p_M) = 1/prod(beta),
    # p'_M(x_n) = ell'(x_n)/prod_{i=0}^{M-1} beta_i. beta_{M-1} cancels:
    # p_{M-1}(x_n) = prod_{i<M-1} beta_i * M^{-1}... -- do it via logs numerically:
    logell = np.empty(M)
    for n in range(M):
        d = x[n] - x
        d[n] = 1.0
        logell[n] = np.sum(np.log(np.abs(d)))
    sgnell = np.array([np.prod(np.sign(np.delete(x[n] - x, n))) for n in range(M)])
    logbeta = np.log(be)                      # beta_0..beta_{M-2}
    # p_{M-1}(x_n) = (prod_{i<=M-2} beta_i)/( w_n * ell'(x_n) )  [beta_{M-1} cancels]
    logp = logbeta.sum() - np.log(wgt) - logell
    pred = sgnell * np.exp(logp)
    meas = P[M - 1]
    e4 = np.abs(pred / meas - 1).max()
    print(f"  [4] ell-route p_(M-1)(x_n) vs recurrence: max rel err = {e4:.3e}")
    return F, P, dP, al, be


if __name__ == '__main__':
    check(4, 60)
    check(4, 149)
