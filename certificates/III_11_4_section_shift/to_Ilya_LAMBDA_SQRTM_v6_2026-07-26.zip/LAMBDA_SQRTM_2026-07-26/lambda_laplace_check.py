r"""
lambda_laplace_check.py -- verify the Laplace/Stirling analysis of the top-row
closed form: ghat2(u) concentration.

Claim (derived): with u = n/M and E(u) = (1-u)ln(1-u) + (1+u)ln(1+u) - 2 ln u,
ln ghat2_n = -2M [E(u) - E(u*)] + o(M) locally, so ghat2 concentrates at the root
u* of E'(u) = ln((1+u)/(1-u)) - 2/u = 0  (u* = 0.833471...), with Gaussian width
1/sqrt(2M E''(u*)).
Checks at M = 3000 (k=4): [1] u* root vs argmax ghat2; [2] local shape:
ln[ghat2(u)/ghat2(u_peak)] vs -2M*(E(u)-E(u_peak)) at offsets; [3] E''(u*) vs
measured Gaussian width; [4] report the root to 12 digits + distance from 5/6.
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26.
"""
import math
import numpy as np
from scipy.optimize import brentq

def E(u):
    return (1 - u) * math.log(1 - u) + (1 + u) * math.log(1 + u) - 2 * math.log(u)

def dE(u):
    return math.log((1 + u) / (1 - u)) - 2 / u

def d2E(u):
    return 1 / (1 - u) + 1 / (1 + u) + 2 / u**2

ustar = brentq(dE, 0.7, 0.95, xtol=1e-15)
print(f"[4] u* root of ln((1+u)/(1-u)) = 2/u:  u* = {ustar:.12f}")
print(f"    5/6 = {5/6:.12f}   difference = {ustar - 5/6:+.3e}  (NOT 5/6)")
print(f"    E''(u*) = {d2E(ustar):.6f}")

k, N = 4, 3004
n = np.arange(k + 1, N + 1)
zn = (n - 0.5) * math.pi
x = 1.0 / zn**2
M = len(x)
logG2 = np.empty(M)
for i in range(M):
    d = x[i] - x
    d[i] = 1.0
    logG2[i] = -2.0 * np.log(np.abs(d)).sum()
logG2 -= logG2.max()
G2 = np.exp(logG2)
ghat2 = M * G2 / G2.sum()
ipk = int(ghat2.argmax())
upk = (ipk + 1) / M
print(f"\n[1] M={M}: argmax ghat2 at u = {upk:.5f}  (u* = {ustar:.5f}, "
      f"finite-M offset {upk - ustar:+.5f})")

print("[2] local shape: ln[ghat2(u)/ghat2(peak)] vs -2M*(E(u)-E(u_pk)):")
upk_exact = (ipk + 1) / M
for du in (-0.02, -0.01, -0.005, 0.005, 0.01, 0.02):
    i2 = int(round((upk_exact + du) * M)) - 1
    meas = math.log(ghat2[i2] / ghat2[ipk])
    pred = -2 * M * (E((i2 + 1) / M) - E(upk_exact))
    print(f"    du={du:+.3f}: meas {meas:+9.3f}   pred {pred:+9.3f}   "
          f"ratio {meas / pred if pred else float('nan'):.4f}")

# [3] Gaussian width
sig_pred = 1.0 / math.sqrt(2 * M * d2E(ustar))
# measured: second moment around peak over a +-4 sigma window
w = int(6 * sig_pred * M)
lo, hi = max(0, ipk - w), min(M, ipk + w)
us = (np.arange(lo, hi) + 1) / M
p = ghat2[lo:hi] / ghat2[lo:hi].sum()
mu = (us * p).sum()
sig_meas = math.sqrt(((us - mu)**2 * p).sum())
print(f"[3] width: predicted sigma = {sig_pred:.5f}   measured = {sig_meas:.5f}")
print(f"    total mass in ghat2: (1/M) sum = {ghat2.sum() / M:.6f} (should be 1)")
