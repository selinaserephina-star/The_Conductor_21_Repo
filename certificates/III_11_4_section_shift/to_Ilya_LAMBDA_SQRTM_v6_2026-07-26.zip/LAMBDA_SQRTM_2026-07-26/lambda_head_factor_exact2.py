r"""
lambda_head_factor_exact2.py -- the CLOSED CHAIN for drop-4, stable form
(session 5c, v2; supersedes lambda_head_factor_exact.py whose norm route was
numerically catastrophic -- its SHAPE was already exact, ratio 4.777e-14 const).

Stable identities (derived):
  T(i) = v v^T + T',  T' = sum_{s>i} v^(s) v^(s)T   (tail Gram, s > i)
  q = v^T T'^{-1} v,   a = T'^{-1} v/(1+q)          (Sherman-Morrison)
  ||rt_hat||^2_drop = 1 - a.v = 1/(1+q)  =>  N = sqrt(1+q)     [closed norm]
  gamma~_i = N_i gamma_i  =>  B~_{i-1} = (N_{i-1}/N_i) B_{i-1} [closed B-tilde]
  rt_i = N [ r_i + sum_l a_l K_i(., y_l) ],  same for d/dx (CD-derivative).

VALIDATION TARGETS (j = 54): rt_(j-1) = 15.6009/332.309/2558.36 at n = 33/35/37;
B~_(j-2) = 1.9058984e-5; F_cache column; then the Delta closure table.
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (session 5c).
"""
import os, math
import numpy as np
import mpmath as mp

mp.mp.dps = 500
PI = mp.pi
C13 = 2**(1/3)
LOGM = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..',
                    'LOGM_DEPTH_2026-07-26')
TAIL = 40

def sph_jy(l, z):
    fac = mp.sqrt(PI/(2*z))
    return (fac*mp.besselj(mp.mpf(l)+mp.mpf(1)/2, z),
            fac*mp.bessely(mp.mpf(l)+mp.mpf(1)/2, z))

def sph_j(l, z):
    return mp.sqrt(PI/(2*z))*mp.besselj(mp.mpf(l)+mp.mpf(1)/2, z)

def kap(s):
    return mp.sqrt(2*(mp.mpf(4*s)+3))

def r_at(s, n):
    z = (mp.mpf(2*n)-1)*PI/2
    return kap(s)*(-1)**(n+1)*z**2*sph_j(2*s+1, z)

def rp_at(s, n):
    z = (mp.mpf(2*n)-1)*PI/2
    j, y = sph_jy(2*s+1, z)
    jm = sph_j(2*s, z)
    jp = jm - (2*s+2)/z*j
    return -(z**3)/2*kap(s)*(-1)**(n+1)*(2*z*j + z**2*(jp + y))

def Bfull(i):
    return 1/mp.sqrt(mp.mpf(4*i-1)*(4*i+1)**2*(4*i+3))

def head_solve(i):
    """returns (a, N) via the stable Sherman-Morrison route."""
    v = mp.matrix([r_at(i, k) for k in (1, 2, 3, 4)])
    Tp = mp.zeros(4, 4)
    for s in range(i+1, i+1+TAIL):
        u = [r_at(s, k) for k in (1, 2, 3, 4)]
        for a_ in range(4):
            for b_ in range(4):
                Tp[a_, b_] += u[a_]*u[b_]
    w = mp.lu_solve(Tp, v)           # T'^{-1} v
    q = sum(v[k]*w[k] for k in range(4))
    a = mp.matrix([w[k]/(1+q) for k in range(4)])
    N = mp.sqrt(1+q)
    return a, N, q

def K_dK(i, n, kk):
    z = (mp.mpf(2*n)-1)*PI/2
    x = 1/z**2
    yk = 1/((mp.mpf(2*kk)-1)*PI/2)**2
    B = Bfull(i)
    K = B*(r_at(i, n)*r_at(i-1, kk) - r_at(i-1, n)*r_at(i, kk))/(x - yk)
    dK = B*(rp_at(i, n)*r_at(i-1, kk) - rp_at(i-1, n)*r_at(i, kk))/(x - yk) \
         - K/(x - yk)
    return K, dK

def rt_pair(i, n, a, N):
    val = r_at(i, n); dval = rp_at(i, n)
    for k in range(4):
        K, dK = K_dK(i, n, k+1)
        val += a[k]*K
        dval += a[k]*dK
    return N*val, N*dval

def sigma_exact(j, n):
    z = (mp.mpf(2*n)-1)*PI/2
    jp1, _ = sph_jy(2*j+1, z)
    jm1, ym1 = sph_jy(2*j-1, z)
    jm2, _ = sph_jy(2*j-2, z)
    return (mp.mpf(2)/(4*j+1))*z**2*jp1*(2*(j-1)*jm1 - z*(jm2 + ym1))

def F_full(j, n):
    z = (mp.mpf(2*n)-1)*PI/2
    x = 1/z**2
    B = 1/mp.sqrt(mp.mpf(4*j-5)*(4*j-3)**2*(4*j-1))
    return 2*B*x*r_at(j-1, n)*(r_at(j-2, n) + x*rp_at(j-2, n))

def F_cache(C, j, col):
    if col == 0:
        return -float(C[j:, 0].sum())
    return -float((C[j:, col] - C[j:, col-1]).sum())

def run_j(j, C4=None, truth=None, bt_ref=None):
    nu = 2.0*j; n13 = nu**(1/3)
    a1, N1, q1 = head_solve(j-1)
    a2, N2, q2 = head_solve(j-2)
    Bt = (N2/N1)*Bfull(j-1)
    print(f"\n== j={j}:  q_(j-1) = {mp.nstr(q1, 6)}   q_(j-2) = {mp.nstr(q2, 6)}")
    print(f"   B~_(j-2) closed-chain = {mp.nstr(Bt, 8)}"
          + (f"   (stieltjes: {bt_ref})" if bt_ref else ""))
    if truth:
        for n, tv in truth.items():
            val, _ = rt_pair(j-1, n, a1, N1)
            print(f"   rt_(j-1)({n}) = {mp.nstr(val, 8)}   (stieltjes {tv};"
                  f" ratio {mp.nstr(val/tv, 8)})")
    print("    n     w      F_chain    F_cache    Dtot_pred  Dtot_cache")
    lo = int((nu - 2.6*n13/C13)/math.pi + 0.5)
    hi = int((nu + 2.2*n13/C13)/math.pi + 0.5)
    for n in range(max(5, lo), hi+1):
        z = (mp.mpf(2*n)-1)*PI/2
        x = 1/z**2
        w = C13/n13*(nu - float(z))
        rt1, _ = rt_pair(j-1, n, a1, N1)
        rt2, drt2 = rt_pair(j-2, n, a2, N2)
        Fch = float(2*Bt*x*rt1*(rt2 + x*drt2))
        sg = float(sigma_exact(j, n))
        if C4 is not None and n-5 < C4.shape[1]:
            Fca = F_cache(C4, j, n-5)
            print(f"  {n:>4} {w:+5.2f}  {Fch:+9.4f}  {Fca:+9.4f}  "
                  f"{(Fch-sg)/n13:+9.4f}  {(Fca-sg)/n13:+9.4f}")
        else:
            print(f"  {n:>4} {w:+5.2f}  {Fch:+9.4f}      -      "
                  f"{(Fch-sg)/n13:+9.4f}      -")

def main():
    C4 = np.load(os.path.join(LOGM, 'corr_cache_mirror_k4_N1200.npz'))['C']
    run_j(54, C4, truth={33: 15.600931, 35: 332.3088, 37: 2558.3576},
          bt_ref='1.9058984e-5')
    run_j(140, C4)
    run_j(300, C4)

if __name__ == '__main__':
    main()
