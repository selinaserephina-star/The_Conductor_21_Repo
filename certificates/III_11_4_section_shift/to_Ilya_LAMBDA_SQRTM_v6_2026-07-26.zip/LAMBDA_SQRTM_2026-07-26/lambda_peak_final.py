r"""
lambda_peak_final.py -- the peak constant, closed: after the S1 correction
(Q~(u) = 1 + (u/2)ln((1-u)/(1+u)) VANISHES at u* -- same transcendental as the
Laplace point; structural: S1 = d/dx ln|ell'| balances there), T_C is O(sqrt(M))
and the leading scaling profile is
    F~(t) = -(2/c) I(t),   I(t) = int_{-inf}^t [tau H(tau) - 1] dtau,
    H(t) = sqrt(2) dawsn(t/sqrt2),  c = sqrt(2 E''(u*)).
Peak: at t_c with t_c H(t_c) = 1;  value  (2/c) |I(t_c)|.
This script: [1] the constants to 12 digits; [2] pointwise F_exact - F~ at
M = 1e4/1e5 (expect residual ~0.01-0.05 decaying); [3] verify Q~(u*) = 0 exact.
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (session 3).
"""
import math
import numpy as np
from scipy.optimize import brentq
from scipy.special import dawsn
from scipy.integrate import quad

SQ2PI = math.sqrt(2*math.pi)
phi = lambda t: math.exp(-t*t/2)/SQ2PI
dE  = lambda u: math.log((1+u)/(1-u)) - 2/u
d2E = lambda u: 1/(1-u) + 1/(1+u) + 2/u**2
H   = lambda t: math.sqrt(2.0)*dawsn(t/math.sqrt(2))

ustar = brentq(dE, 0.7, 0.95, xtol=1e-15)
c = math.sqrt(2*d2E(ustar))
Qt = 1 + (ustar/2)*math.log((1-ustar)/(1+ustar))
print(f"[3] u* = {ustar:.12f}   Q~(u*) = {Qt:.3e}  (0 exactly -- same equation)")
print(f"    c = sqrt(2 E'') = {c:.12f}")

tc = brentq(lambda t: t*H(t) - 1, 0.5, 3.0, xtol=1e-14)
I_tc, err = quad(lambda τ: τ*H(τ) - 1.0, 0, tc, limit=500)   # I odd => I(t)=int_0^t
peak = (2/c)*abs(I_tc)
print(f"[1] t_c (tH=1) = {tc:.12f}")
print(f"    I(t_c) = {I_tc:.12f}  (quad err {err:.1e})")
print(f"    PEAK CONSTANT = (2/c)|I(t_c)| = {peak:.9f}")
print(f"    (measured ladder: 0.3706/0.3665/0.3623/0.3593/0.3569 at M=1e3..1e5, decreasing)")

def toprow_F(N, k=4):
    n = np.arange(k+1, N+1); zn = (n-0.5)*math.pi; x = 1.0/zn**2
    M = len(x)
    logG2 = np.empty(M)
    for i in range(M):
        d = x[i]-x; d[i] = 1.0
        logG2[i] = -2.0*np.log(np.abs(d)).sum()
    logG2 -= logG2.max()
    G2 = np.exp(logG2); ghat2 = M*G2/G2.sum()
    alpha = (x*ghat2).sum()/M
    S1 = np.empty(M); S2 = np.empty(M)
    for i in range(M):
        d = x[i]-x; d[i] = np.inf
        S1[i] = (1.0/d).sum(); S2[i] = (ghat2/d).sum()
    Crow = -(2.0/M)*np.cumsum(ghat2 - M + (x-alpha)*(ghat2*S1 + S2))
    return Crow/math.sqrt(M), M

def Ftilde(t):
    s = np.sign(t); v, _ = quad(lambda τ: τ*H(τ)-1.0, 0, abs(t), limit=400)
    return -(2/c)*s*v

print("\n[2] pointwise F_exact - F~ (leading profile, no phi term):")
for N in (10004,):
    Fex, M = toprow_F(N)
    print(f"   M = {M}:  t : diff")
    row = []
    for t in (-2.0,-1.0,0.0,0.5,1.0,1.31,1.5,2.0,3.0):
        u = ustar + t/(c*math.sqrt(M)); idx = int(round(u*M))-1
        row.append(f"{t:+.2f}:{Fex[idx]-Ftilde(t):+.4f}")
    print("     " + "  ".join(row))
    ia = int(np.abs(Fex).argmax())
    print(f"     exact peak {np.abs(Fex).max():.6f} at t = "
          f"{((ia+1)/M-ustar)*c*math.sqrt(M):+.3f}   derived {peak:.6f} at {tc:.3f}")
