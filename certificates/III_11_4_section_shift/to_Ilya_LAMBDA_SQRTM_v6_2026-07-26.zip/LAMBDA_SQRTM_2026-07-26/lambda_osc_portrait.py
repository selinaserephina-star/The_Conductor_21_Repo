r"""
lambda_osc_portrait.py -- T4: the TRUE-ORIENTATION osc-side portrait, from the
EXACT chain (no cache, no M): Delta(j, w) for w in (-8, +1.2) at j = 140, 300,
600.  Read through the display form: the U_4-root transit sits at
w_root = -0.0648 nu^{2/3}; past it the deficiency oscillates and dies as
nu^{-1/3} * 6 pi (AiBi)'(w).  Columns as in lambda_chain_highj.
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (Delta-closeout session).
"""
from lambda_chain_highj import run_j

# NOTE run_j convention: positive-w extent = -wlo, negative-w extent = whi;
# first invocation of this script had them swapped (that output = far-window
# side, kept in the log as bonus validation).  Osc side = w down to -8.2:
for j in (140, 300, 600):
    run_j(j, wlo=1.2, whi=8.2)
