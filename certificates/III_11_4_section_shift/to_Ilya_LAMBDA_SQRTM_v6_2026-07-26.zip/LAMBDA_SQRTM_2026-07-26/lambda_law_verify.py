r"""
lambda_law_verify.py -- harden the caustic-band law found by lambda_pin_constants.py:
    Lambda_true(w) = -(2/pi) Delta(w) + drift,   drift = O(nu^{-2/3})
where Lambda_true = (C_sec - Ctilde)/nu^{1/3} (LIKE-FOR-LIKE head-prefix pairing;
see the convention finding in FINDINGS_lambda_pinned_convention.md) and
Delta(w) = D/nu^{1/3}, D = F - sigma (session 3b, convention-A throughout).

Tests:
 [T1] DISCRETE closure: predict Lambda from the Delta profile ALONE via the exact
      telescope  Lambda_pred*nu^{1/3} = sum_{n'<=n} [ (nu+2)^{1/3} Dhat(w_{j+1}(n'))
      - nu^{1/3} Dhat(w_j(n')) ],  Dhat = spline of the measured mid profile.
      Residual small + shrinking in nu => ONE universal Delta explains Lambda; the
      derivation target collapses to Delta(w).
 [T2] leading-form split: r1 = Lambda_true + (2/pi)*Delta_mid; is max|r1| ~ nu^{-2/3}?
      compare r1 against the continuum drift (2/(3*2^{1/3}*pi)) nu^{-2/3} I(w),
      I(w) = int_w^inf Delta.
 [T3] Delta constants: Delta_j(0), dip (value, location), window lobe, zero crossing
      per j; Richardson in nu^{-1/3} (fit Delta + a*nu^{-1/3}) with LOO.
Uses lambda_pin_constants.csv (M=1196 rows; M-sat asserted j <= 300) + recomputes
nothing heavy. NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (JOB 2 step 1b).
"""
import os, csv, math
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
C13 = 2**(1/3)
TWOPI = 2/math.pi
DRIFTC = 2/(3*C13*math.pi)

rowsd = {}
with open(os.path.join(HERE, 'lambda_pin_constants.csv')) as fh:
    for r in csv.DictReader(fh):
        key = (int(r['M']), int(r['j']))
        rowsd.setdefault(key, []).append(
            (int(r['n']), float(r['w']), float(r['Lambda_true']),
             float(r['Delta_j']), float(r['Delta_j1'])))

try:
    from scipy.interpolate import CubicSpline
    def spline(x, y):
        return CubicSpline(x, y)
except Exception:
    def spline(x, y):
        return lambda t: np.interp(t, x, y)

def wof(j, n):
    nu = 2.0*j
    return C13*nu**(-1/3)*(nu - (n-0.5)*math.pi)

print("== [T1]+[T2] per-j closure and leading-form split (M = 1196) ==")
print("    j    max|r_discrete|   max|r1=L+(2/pi)Dmid|   max|r1 - drift_pred|   nu^-2/3")
scales = []
for (M, j) in sorted(rowsd):
    if M != 1196:
        continue
    data = sorted(rowsd[(M, j)])
    nu = 2.0*j; n13 = nu**(1/3); n13p = (nu+2)**(1/3)
    ns   = np.array([d[0] for d in data])
    ws   = np.array([d[1] for d in data])          # w at j
    lam  = np.array([d[2] for d in data])
    dj   = np.array([d[3] for d in data])          # Delta_j
    dj1  = np.array([d[4] for d in data])          # Delta_{j+1}
    wmid = np.array([C13*(nu+1)**(-1/3)*((nu+1) - (n-0.5)*math.pi) for n in ns])
    dmid = 0.5*(dj + dj1)
    # spline of the mid profile on its own w grid (ascending)
    o = np.argsort(wmid)
    sp = spline(wmid[o], dmid[o])
    lo, hi = wmid[o][0], wmid[o][-1]
    def Dhat(w):
        return float(sp(np.clip(w, lo, hi)))
    # [T1] discrete telescope from Dhat alone, accumulated over the CSV site range
    # (head above the table's w-range contributes the accumulated Lambda at entry --
    #  anchor the prediction to the measured Lambda at the FIRST band site, then
    #  telescope purely with Dhat below it: tests the BAND law, not the wing head)
    r_disc = []
    acc = lam[0]*n13   # anchor at first (highest-w) band cell
    for i in range(1, len(ns)):
        n = ns[i]
        step = (n13p*Dhat(wof(j+1, n)) - n13*Dhat(wof(j, n)))
        acc += step
        r_disc.append(acc - lam[i]*n13)
    r_disc = np.array(r_disc)/n13
    # [T2] leading form + drift
    r1 = lam + TWOPI*dmid
    # I(w) = int_w^inf Delta: from the mid samples, trapezoid on descending w + tail 0
    Iw = np.zeros_like(wmid)
    accI = 0.0
    idx = np.argsort(-wmid)   # from highest w down
    prev_w = None; prev_d = None
    for i in idx:
        if prev_w is not None:
            accI += 0.5*(prev_d + dmid[i])*(prev_w - wmid[i])
        Iw[i] = accI
        prev_w, prev_d = wmid[i], dmid[i]
    drift_pred = DRIFTC*(nu+1)**(-2/3)*Iw
    r2 = r1 - drift_pred
    band = np.abs(ws) <= 2.2
    print(f"  {j:>4}   {np.max(np.abs(r_disc)):14.4f}   "
          f"{np.max(np.abs(r1[band])):18.4f}   {np.max(np.abs(r2[band])):17.4f}   "
          f"{nu**(-2/3):7.4f}")
    scales.append((nu, np.max(np.abs(r1[band]))))

# scaling exponent of max|r1| vs nu
if len(scales) >= 3:
    lx = np.log([s[0] for s in scales]); ly = np.log([s[1] for s in scales])
    A = np.vstack([lx, np.ones_like(lx)]).T
    cf, *_ = np.linalg.lstsq(A, ly, rcond=None)
    print(f"  max|r1| ~ nu^p fit: p = {cf[0]:+.3f}  (drift prediction: -2/3 = -0.667)")

print("\n== [T3] Delta(w) constants per j + Richardson in nu^(-1/3) ==")
print("    j    Delta(0)   dip val @ w      lobe val @ w     zero-x")
feats = {}
for (M, j) in sorted(rowsd):
    if M != 1196:
        continue
    data = sorted(rowsd[(M, j)])
    nu = 2.0*j
    ws  = np.array([d[1] for d in data])
    dj  = np.array([d[3] for d in data])
    o = np.argsort(ws)
    sp = spline(ws[o], dj[o])
    grid = np.linspace(max(ws.min(), -3.0), min(ws.max(), 2.0), 800)
    vals = np.array([float(sp(g)) for g in grid])
    d0 = float(sp(0.0))
    i_dip = int(np.argmax(vals))          # dip of the deficiency = max of Delta
    i_lob = int(np.argmin(vals))
    # zero crossing between lobe and dip
    zx = float('nan')
    for a in range(len(grid)-1, 0, -1):
        if vals[a-1]*vals[a] < 0 and grid[a] < 0.5:
            zx = grid[a-1] + (grid[a]-grid[a-1])*(-vals[a-1])/(vals[a]-vals[a-1])
            break
    feats[j] = (nu, d0, vals[i_dip], grid[i_dip], vals[i_lob], grid[i_lob], zx)
    print(f"  {j:>4}   {d0:+8.4f}   {vals[i_dip]:+7.4f} @ {grid[i_dip]:+5.2f}   "
          f"{vals[i_lob]:+7.4f} @ {grid[i_lob]:+5.2f}   {zx:+6.2f}")

def richardson(name, ix):
    js = sorted(feats)
    x = np.array([feats[j][0]**(-1/3) for j in js])
    y = np.array([feats[j][ix] for j in js])
    A = np.vstack([np.ones_like(x), x]).T
    cf, *_ = np.linalg.lstsq(A, y, rcond=None)
    loo = []
    for i in range(len(x)):
        s = np.arange(len(x)) != i
        c2, *_ = np.linalg.lstsq(A[s], y[s], rcond=None)
        loo.append(abs(y[i] - (c2[0] + c2[1]*x[i])))
    print(f"   {name}: limit = {cf[0]:+.4f}  slope = {cf[1]:+.3f}  "
          f"max LOO err = {max(loo):.4f}")

print("\n  Richardson (value = limit + a*nu^(-1/3), j = 29..300):")
richardson('Delta(0)   ', 1)
richardson('Delta_dip  ', 2)
richardson('lobe       ', 4)
print("\ndone")
