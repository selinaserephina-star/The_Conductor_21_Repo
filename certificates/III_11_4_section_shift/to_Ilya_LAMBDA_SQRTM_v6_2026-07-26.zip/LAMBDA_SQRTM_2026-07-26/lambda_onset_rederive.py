r"""
lambda_onset_rederive.py -- T3: flat-onset re-derivation in the corrected frame.

The LOGM onsets (M-flat, drop-4): j*(0.5) = 28.6 vs the Airy profile P = nu^{1/3}
(pi/2) 2^{2/3} AiBi(w);  j*_delta(0.5) = 20.0 vs the true infinity-row.
New-frame mechanism candidate: the onset is the growth of the U_4-root-transit
profile through the threshold -- an M-FREE property of the drop-4 M=infinity
chain (which is why the measured onset was flat over 21x in M).
This script computes, from the EXACT chain (no cache, no M):
    d_P(j)     = max_band |F~/nu^{1/3} - (pi/2)2^{2/3}AiBi(w)|
    d_inf(j)   = max_band |F~ - sigma|/nu^{1/3}
over the band window w in (-2.6, +2.2) (exact2 grid convention), j = 12..44,
and reports the 0.5-crossings.  Also prints w_root(U4) = -0.0648 nu^{2/3} per j.
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (Delta-closeout session).
"""
import math
import mpmath as mp
from lambda_chain_highj import (level_coeffs, AbarCbar, sph_tables, kap,
                                Bfull, PI)

mp.mp.dps = 120


def band_metrics(j, tail=14):
    nu = mp.mpf(2*j)
    n13 = nu**(mp.mpf(1)/3)
    C13 = 2**(mp.mpf(1)/3)
    i1, i2 = j-1, j-2
    c1 = level_coeffs(i1, tail)
    c2 = level_coeffs(i2, tail)
    Bt = (c2[3]/c1[3])*Bfull(i1)
    lo = int(float((nu - 2.6*n13/C13)/math.pi + 0.5))
    hi = int(float((nu + 2.2*n13/C13)/math.pi + 0.5))
    dP = dI = 0.0
    for n in range(max(5, lo), hi+1):
        z = (mp.mpf(2*n)-1)*PI/2
        x = 1/z**2
        w = C13/n13*(nu - z)
        sj, sy = sph_tables(z, 2*j+3)
        sgn = (-1)**(n+1)

        def rb(s):
            return kap(s)*sgn*z**2*sj[2*s+1]

        def rpb(s):
            jp = sj[2*s] - (2*s+2)/z*sj[2*s+1]
            return -(z**3)/2*kap(s)*sgn*(2*z*sj[2*s+1] + z**2*(jp + sy[2*s+1]))

        A1, C1_, dA1, dC1 = AbarCbar(c1, x)
        A2, C2_, dA2, dC2 = AbarCbar(c2, x)
        rt1 = A1*rb(i1) + C1_*rb(i1-1)
        rt2 = A2*rb(i2) + C2_*rb(i2-1)
        drt2 = A2*rpb(i2) + C2_*rpb(i2-1) + dA2*rb(i2) + dC2*rb(i2-1)
        Fch = 2*Bt*x*rt1*(rt2 + x*drt2)
        sg = (mp.mpf(2)/(4*j+1))*z**2*sj[2*j+1]*(
            2*(j-1)*sj[2*j-1] - z*(sj[2*j-2] + sy[2*j-1]))
        P = (PI/2)*2**(mp.mpf(2)/3)*mp.airyai(w)*mp.airybi(w)
        dP = max(dP, abs(float(Fch/n13 - P)))
        dI = max(dI, abs(float((Fch - sg)/n13)))
    return dP, dI


def main():
    print("   j    d_P(j)   d_inf(j)   w_root(U4)")
    prev = None
    crossings = {}
    for j in range(12, 45, 2):
        dP, dI = band_metrics(j)
        wr = -0.06484*(2*j)**(2/3)
        print(f"  {j:>3}   {dP:6.4f}   {dI:6.4f}     {wr:+.2f}", flush=True)
        if prev is not None:
            jp, dPp, dIp = prev
            for name, a, b in (('P', dPp, dP), ('inf', dIp, dI)):
                if name not in crossings and a < 0.5 <= b:
                    jc = jp + (0.5 - a)/(b - a)*(j - jp)
                    crossings[name] = jc
        prev = (j, dP, dI)
    print("\n0.5-crossings (exact chain, M-free):")
    for name, jc in crossings.items():
        print(f"  d_{name}: j* = {jc:.1f}")
    print("LOGM measured (M-flat): j*(0.5) vs P = 28.6;  j*_delta(0.5) = 20.0")


if __name__ == '__main__':
    main()
