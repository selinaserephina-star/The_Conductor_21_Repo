r"""
lambda_fullF_exact.py -- EXACT full-lattice F via the validated value law (no
Stieltjes, no conditioning): with x = 1/z^2, kappa_i = sqrt(2(4i+3)),

  r_i(x_n)  = s_i kappa_i (-1)^{n+1} z^2 j_{2i+1}(z)                (value law)
  r'_i(x_n) = -(z^3/2) s_i kappa_i (-1)^{n+1} [ 2z j_{2i+1}(z)
              + z^2 ( j'_{2i+1}(z) + y_{2i+1}(z) ) ]                (wave identity)
  B_{i-1}   = [(4i-1)(4i+1)^2(4i+3)]^{-1/2}                          (closed)
  F_full    = 2 B_{j-2} x r_{j-1} [ r_{j-2} + x r'_{j-2} ]

Signs s_i cancel in F if s_{j-1} = s_{j-2} (check both hypotheses against the
trusted j = 54 Stieltjes value F_full(n=35) = +1.0707).
Then Delta_weight(j, w) = (F_full - sigma)/nu^{1/3} on the ladder j = 29...600:
does the weight-mismatch piece decay (~nu^{-1/3}) or is it a standing O(1) law?
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (session 5b).
"""
import math
import mpmath as mp

mp.mp.dps = 50
PI = mp.pi
C13 = 2**(1/3)

def sph_jy(l, z):
    fac = mp.sqrt(PI/(2*z))
    j = fac*mp.besselj(mp.mpf(l)+mp.mpf(1)/2, z)
    y = fac*mp.bessely(mp.mpf(l)+mp.mpf(1)/2, z)
    return j, y

def sph_jp(l, z, jl=None):
    jm1, _ = sph_jy(l-1, z)
    if jl is None:
        jl, _ = sph_jy(l, z)
    return jm1 - (l+1)/z*jl

def F_full_exact(j, n, rel_sign=+1):
    z = (mp.mpf(2*n)-1)*PI/2
    x = 1/z**2
    B = 1/mp.sqrt(mp.mpf(4*j-5)*(4*j-3)**2*(4*j-1))
    k1 = mp.sqrt(2*(mp.mpf(4*(j-1))+3))      # kappa_{j-1}: orders 2j-1
    k2 = mp.sqrt(2*(mp.mpf(4*(j-2))+3))      # kappa_{j-2}: orders 2j-3
    sgn = (-1)**(n+1)
    j1, y1 = sph_jy(2*j-1, z)
    j2, y2 = sph_jy(2*j-3, z)
    jp2 = sph_jp(2*j-3, z, j2)
    r1 = k1*sgn*z**2*j1
    r2 = k2*sgn*z**2*j2
    dr2 = -(z**3)/2*k2*sgn*(2*z*j2 + z**2*(jp2 + y2))
    return float(2*B*x*r1*(rel_sign*r2 + rel_sign*x*dr2)), float(r1), float(r2), float(x*dr2)

# sigma (closure form, direct half-order Bessel at dps 50 -- large z, fine)
def sigma_exact(j, n):
    z = (mp.mpf(2*n)-1)*PI/2
    jp1, _ = sph_jy(2*j+1, z)
    jm1, ym1 = sph_jy(2*j-1, z)
    jm2, _ = sph_jy(2*j-2, z)
    return float((mp.mpf(2)/(4*j+1))*z**2*jp1*(2*(j-1)*jm1 - z*(jm2 + ym1)))

print("== sign/consistency check at j = 54 (trusted Stieltjes: F_full(n=35) = +1.0707,")
print("   r_(j-1)(n=35) = +3216.26; sigma(n=35) = +1.4585) ==")
for rs in (+1, -1):
    F, r1, r2, xdr2 = F_full_exact(54, 35, rs)
    print(f"   rel_sign={rs:+d}: F_full = {F:+.4f}   r1 = {r1:+.1f}   r2 = {r2:+.1f}   x*r2' = {xdr2:+.1f}")
print(f"   sigma(54,35) direct = {sigma_exact(54, 35):+.4f}")

print("\n== Delta_weight(j, w) = (F_full - sigma)/nu^(1/3) -- the ladder ==")
print(f"{'j':>5} " + "".join(f"  w={wt:+4.1f}" for wt in (2.0, 1.0, 0.5, 0.0, -0.5, -1.0, -1.5, -2.0)))
for j in (29, 54, 140, 300, 600):
    nu = 2.0*j; n13 = nu**(1/3)
    row = f"{j:>5} "
    for wt in (2.0, 1.0, 0.5, 0.0, -0.5, -1.0, -1.5, -2.0):
        # nearest site to target w
        n = round((nu - wt*n13/C13)/math.pi + 0.5)
        w_ = C13/n13*(nu - (n-0.5)*math.pi)
        F, *_ = F_full_exact(j, n)
        s = sigma_exact(j, n)
        row += f" {(F-s)/n13:+7.3f}"
    print(row, flush=True)
print("\n(nu^{-1/3} ratios j=54->140->300->600: 0.727, 0.776, 0.794 per step if decaying)")
