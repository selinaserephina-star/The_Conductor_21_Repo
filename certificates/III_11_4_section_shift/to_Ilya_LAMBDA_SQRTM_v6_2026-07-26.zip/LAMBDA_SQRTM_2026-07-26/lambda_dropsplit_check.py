r"""
lambda_dropsplit_check.py -- THE SPLIT TEST: is the measured Delta(w) entirely the
HEAD-DROP effect?

Derived (session 5b): r-system value law r_i(x) = eps*sqrt(2(4i+3)) z^2 [j_{2i+1} sin z
- y_{2i+1} cos z] (FULL lattice; validated 0.2% at band) => full-lattice
  F_full = (pi/2) 2^{2/3} nu^{1/3} Ai(w - d/2) Bi(w - 3d/2) + O(1),  d = 2^{1/3}nu^{-1/3}
whose nu^{1/3} term differs from sigma's only by argument shifts =>
  D_full = F_full - sigma = O(1)   [predicted O(1) form: -pi(2Ai'Bi + AiBi') + ...]
=> the measured Delta ~ O(1)-after-/nu^{1/3} deficiency must come from the DROP-4
head (the four largest atoms removed), i.e. Delta(w) = (F_drop4 - F_full)/nu^{1/3}.

Test at j = 29, 54: build FULL and DROP-4 omega systems (Stieltjes), compute
  F_full(n), F_drop(n), sigma_exact(n), and print
  D_full/nu^{1/3}  vs  D_drop/nu^{1/3} (= measured Delta)  vs (F_drop-F_full)/nu^{1/3},
plus the Airy predictions for F_full and D_full.
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (session 5b).
"""
import os, math
import numpy as np
import mpmath as mp

mp.mp.dps = 40
PI = mp.pi
HERE = os.path.dirname(os.path.abspath(__file__))
C13, C23 = 2**(1/3), 2**(2/3)
NMAX = 2000
DPS = 300
JT = 56

# ---- sigma engine (verbatim) ----
_DF = {}
def dfact(l):
    if l not in _DF:
        v = mp.mpf(1)
        for i in range(3, 2*l+2, 2):
            v *= i
        _DF[l] = v
    return _DF[l]

def j_series(l, z):
    guard = int(0.44*float(z)) + 30
    with mp.workdps(mp.mp.dps + guard):
        zz = mp.mpf(z); z2 = zz*zz/2
        t = mp.mpf(1); s = mp.mpf(1); k = 0
        thr = mp.mpf(10)**(-(mp.mp.dps+10))
        while True:
            k += 1
            t *= -z2/(k*(2*l+1+2*k))
            s += t
            if abs(t) < thr*(abs(s)+1) and 2*k > float(z):
                break
        val = s*zz**l/dfact(l)
    return +val

def rows(z, Lmax, jorders):
    with mp.workdps(80):
        zz = mp.mpf(z)
        y = [-mp.cos(zz)/zz, -mp.cos(zz)/zz**2 - mp.sin(zz)/zz]
        for l in range(1, Lmax):
            y.append((2*l+1)/zz*y[-1] - y[-2])
        Lup = min(Lmax, int(float(z)) - 3)
        jup = None
        if any(l <= Lup for l in jorders):
            jup = [mp.sin(zz)/zz, mp.sin(zz)/zz**2 - mp.cos(zz)/zz]
            for l in range(1, Lup):
                jup.append((2*l+1)/zz*jup[-1] - jup[-2])
    jv = {}
    for l in jorders:
        if jup is not None and l <= Lup:
            jv[l] = +jup[l]
        elif z < l:
            jv[l] = j_series(l, z)
        else:
            with mp.workdps(60):
                v = mp.sqrt(PI/(2*z))*mp.besselj(mp.mpf(l)+mp.mpf(1)/2, z)
            jv[l] = +v
    return jv, y

def sigma_exact(j, n):
    z = (2*n-1)*PI/2
    Ls = sorted({2*j-2, 2*j-1, 2*j+1})
    jv, y = rows(z, 2*j+2, Ls)
    return float((mp.mpf(2)/(4*j+1))*z**2*jv[2*j+1]*(
        2*(j-1)*jv[2*j-1] - z*(jv[2*j-2] + y[2*j-1])))

def stieltjes_omega(nstart):
    z = [(mp.mpf(n) - mp.mpf(1)/2)*mp.pi for n in range(nstart, NMAX+1)]
    x = [1/zz**2 for zz in z]
    w = [xx**2 for xx in x]
    N = len(x)
    m0 = mp.fsum(w)
    P = [[1/mp.sqrt(m0)]*N]; dP = [[mp.mpf(0)]*N]
    al, be = [], []
    a0 = mp.fsum(w[n]*x[n]*P[0][n]**2 for n in range(N))
    al.append(a0)
    cur = [(x[n]-a0)*P[0][n] for n in range(N)]
    dcur = [P[0][n] for n in range(N)]
    prev, dprev = P[0], dP[0]
    for kdeg in range(1, JT+1):
        b = mp.sqrt(mp.fsum(w[n]*cur[n]**2 for n in range(N)))
        be.append(b)
        cur = [c/b for c in cur]; dcur = [c/b for c in dcur]
        P.append(cur); dP.append(dcur)
        ak = mp.fsum(w[n]*x[n]*cur[n]**2 for n in range(N))
        al.append(ak)
        nxt = [(x[n]-ak)*cur[n] - b*prev[n] for n in range(N)]
        dnxt = [(x[n]-ak)*dcur[n] + cur[n] - b*dprev[n] for n in range(N)]
        prev, dprev = cur, dcur
        cur, dcur = nxt, dnxt
    return al, be, P, dP, x

def airy(w):
    return (float(mp.airyai(w)), float(mp.airyai(w, 1)),
            float(mp.airybi(w)), float(mp.airybi(w, 1)))

def main():
    with mp.workdps(DPS):
        print("[stieltjes] omega FULL + DROP-4 ...")
        alF, beF, PF, dPF, xF = stieltjes_omega(1)
        alD, beD, PD, dPD, xD = stieltjes_omega(5)
        print("done")
        for j in (29, 54):
            nu = 2.0*j; n13 = nu**(1/3); d = C13/n13
            print(f"\n== j={j} ==")
            print("    n     w      F_full     F_drop4   sigma     "
                  "Dfull/n13  Ddrop/n13  (Fd-Ff)/n13   Ffull_pred  Dfull_pred/n13")
            for n in range(int((nu-2.6*n13/C13)/math.pi+0.5),
                           int((nu+2.2*n13/C13)/math.pi+0.5)+1):
                iF = n - 1; iD = n - 5
                if iD < 0:
                    continue
                w_ = C13/n13*(nu - (n-0.5)*math.pi)
                Ff = float(2*beF[j-2]*xF[iF]*PF[j-1][iF]*(PF[j-2][iF]
                           + xF[iF]*dPF[j-2][iF]))
                Fd = float(2*beD[j-2]*xD[iD]*PD[j-1][iD]*(PD[j-2][iD]
                           + xD[iD]*dPD[j-2][iD]))
                sg = sigma_exact(j, n)
                ai1, aip1, bi1, bip1 = airy(w_ - d/2)
                ai3, aip3, bi3, bip3 = airy(w_ - 1.5*d)
                ai0, aip0, bi0, bip0 = airy(w_)
                Ff_pred = (math.pi/2)*C23*n13*ai1*bi3 + math.pi*ai0*aip0
                Df_pred = (-math.pi*(2*aip0*bi0 + ai0*bip0))/n13
                print(f"  {n:>4} {w_:+5.2f}  {Ff:+8.4f}  {Fd:+8.4f}  {sg:+8.4f}  "
                      f"{(Ff-sg)/n13:+8.4f}  {(Fd-sg)/n13:+8.4f}  {(Fd-Ff)/n13:+9.4f}  "
                      f"{Ff_pred:+9.4f}  {Df_pred:+9.4f}")

if __name__ == '__main__':
    main()
