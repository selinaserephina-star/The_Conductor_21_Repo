r"""
lambda_pin_constants.py -- JOB: pin Lambda's constants by the DIRECT j-difference
of the D-prefix (the exact chain of FINDINGS_band_deficiency_profile.md section 2),
evaluated from the cstep caches + the owned Bessel sigma engine. No proxy P.

Objects (conventions inherited verbatim from lambda_band_deficiency.py and
LOGM_DEPTH_2026-07-26/logm_infty_rows.py -- the +-1-site trap is closed by using
the SAME maps):
  lattice z_n = (n-1/2)pi (mirror ODD); drop-4 section: site n <-> 0-based cache
  column n-5 (section position m = n-4, col = m-1); nu = 2j;
  w(j,n) = 2^{1/3} nu^{-1/3} (nu - z_n).
  C_sec(j,m)   = C[j, m-1]                       (cache row = correction prefix, exact)
  sigma_j(n)   = Bessel closure form (rows() engine)
  Ctilde_j(n)  = sum_{n'<=n} (sigma_{j+1} - sigma_j)(n')   (TRUE infinity row, full prefix)
  F_j(col)     = -sum_{i>=j} (C[i,col]-C[i,col-1])         (telescoped finite-section sigma)
  D_j(n)       = F_j(n) - sigma_j(n)             (per-site deficiency)
  Lambda_true(j,m) = [C_sec(j,m) - Ctilde_j(m+4)] / nu^{1/3}    <- THE object
  Lambda_P    (j,m) = [C_sec(j,m) - P(j,w)] / nu^{1/3}          (LOGM continuity check)

What is printed/pinned:
 [1] engine validation: Ctilde_j vs logm_infty_rows.csv at the probe j (same engine,
     full prefix -- must agree ~1e-9); identity check Lambda_true*nu^{1/3} ==
     head(-Delta sigma, n<=4) + sum_{n=5}^{m+4} [D_{j+1}-D_j]  (exact chain, machine eps).
 [2] Lambda_true at the caustic cells for j = 29..300 at M-saturated M (the ramp,
     now proxy-free) + Lambda_P alongside (bin [-0.5,0) must reproduce
     logm_lambda_profile.csv: 0.2018/0.2567/0.2984/0.3308 at j=54/90/140/200).
 [3] the ACCUMULATION PROFILE A(w) = cumulative [D_{j+1}-D_j]/nu^{1/3} from the
     evanescent head down -- where does Lambda build? (band shape-shift vs wing mass;
     this decides what the analytic derivation must produce).
 [4] Delta(w) = D/nu^{1/3} key values per j with the nu^{-1/3} drift separated at
     w ~ 0 (Richardson in nu^{-1/3} across j) -> pinned Delta(0), Delta_dip, lobe.
 [5] M-stability: same j at M = 296/596/1196.
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (session: post-audit, JOB 2 step 1).
"""
import os, csv, math, time
import numpy as np
import mpmath as mp

mp.mp.dps = 40
PI = mp.pi
HERE = os.path.dirname(os.path.abspath(__file__))
LOGM = os.path.join(HERE, '..', 'LOGM_DEPTH_2026-07-26')
C13 = 2**(1/3)
K = 4  # drop-4

# ---------------- owned Bessel engine (verbatim port) ----------------
_DF = {}
def dfact(l):
    if l not in _DF:
        v = mp.mpf(1)
        for i in range(3, 2*l+2, 2):
            v *= i
        _DF[l] = v
    return _DF[l]

def j_series(l, z):
    guard = int(0.44*float(z)) + 30
    with mp.workdps(mp.mp.dps + guard):
        zz = mp.mpf(z); z2 = zz*zz/2
        t = mp.mpf(1); s = mp.mpf(1); k = 0
        thr = mp.mpf(10)**(-(mp.mp.dps+10))
        while True:
            k += 1
            t *= -z2/(k*(2*l+1+2*k))
            s += t
            if abs(t) < thr*(abs(s)+1) and 2*k > float(z):
                break
        val = s*zz**l/dfact(l)
    return +val

def rows(z, Lmax, jorders):
    with mp.workdps(80):
        zz = mp.mpf(z)
        y = [-mp.cos(zz)/zz, -mp.cos(zz)/zz**2 - mp.sin(zz)/zz]
        for l in range(1, Lmax):
            y.append((2*l+1)/zz*y[-1] - y[-2])
        Lup = min(Lmax, int(float(z)) - 3)
        jup = None
        if any(l <= Lup for l in jorders):
            jup = [mp.sin(zz)/zz, mp.sin(zz)/zz**2 - mp.cos(zz)/zz]
            for l in range(1, Lup):
                jup.append((2*l+1)/zz*jup[-1] - jup[-2])
    jv = {}
    for l in jorders:
        if jup is not None and l <= Lup:
            jv[l] = +jup[l]
        elif z < l:
            jv[l] = j_series(l, z)
        else:
            with mp.workdps(60):
                v = mp.sqrt(PI/(2*z))*mp.besselj(mp.mpf(l)+mp.mpf(1)/2, z)
            jv[l] = +v
    return jv, y

def sigma_pair(j, n):
    z = (2*n-1)*PI/2
    Ls = sorted({2*j-2, 2*j-1, 2*j+1, 2*j, 2*j+3})
    jv, y = rows(z, 2*j+4, Ls)
    def sig(jj):
        return (mp.mpf(2)/(4*jj+1))*z**2*jv[2*jj+1]*(
            2*(jj-1)*jv[2*jj-1] - z*(jv[2*jj-2] + y[2*jj-1]))
    return sig(j), sig(j+1)

Ai = mp.airyai; Bi = mp.airybi
CBRT2 = mp.cbrt(2)
def profile_P(j, w):
    ai, aip = Ai(w), mp.airyai(w, 1)
    bi, bip = Bi(w), mp.airybi(w, 1)
    Phi1 = CBRT2*(aip*(ai+bi) - 1/(2*PI))
    Psi0 = -2**(mp.mpf(2)/3)*Phi1 + (PI-2)*(aip*bi + ai*bip)
    nu = mp.mpf(2*j)
    return -2**(mp.mpf(2)/3)*mp.cbrt(nu)*ai*bi + Psi0 + (mp.mpf(3)/4 - 2/PI)

def wof(j, n):
    nu = 2.0*j
    return C13*nu**(-1/3)*(nu - (n-0.5)*math.pi)

# ---------------- sigma tables (per j-pair; M-independent) ----------------
SIG = {}  # j -> dict n -> (sigma_j(n), sigma_{j+1}(n))  [mpf]
def build_sigma_table(j, wmin=-8.0):
    nu = 2*j
    nmax = int((nu + abs(wmin)*nu**(1/3)/C13)/math.pi + 0.5) + 2
    t0 = time.time()
    tab = {}
    for n in range(1, nmax+1):
        tab[n] = sigma_pair(j, n)
    SIG[j] = tab
    print(f"  [sigma] j={j}: {nmax} sites in {time.time()-t0:.0f}s "
          f"(head |dsig|(n=1) = {mp.nstr(abs(tab[1][1]-tab[1][0]), 3)})", flush=True)
    return tab

def ctilde_row(j):
    """full-prefix Ctilde_j(n) for all n in the sigma table; returns dict n->float."""
    tab = SIG[j]
    acc = mp.mpf(0); out = {}
    for n in sorted(tab):
        s0, s1 = tab[n]
        acc += s1 - s0
        out[n] = float(acc)
    return out

# ---------------- cache side ----------------
_CACHE = {}
def cacheC(N):
    if N not in _CACHE:
        _CACHE[N] = np.load(os.path.join(LOGM, f'corr_cache_mirror_k4_N{N}.npz'))['C']
    return _CACHE[N]

def F_col(C, j, col):
    if col == 0:
        s = C[j:, 0]
    else:
        s = C[j:, col] - C[j:, col-1]
    return -float(s.sum())

# ---------------- [1] validation vs logm_infty_rows.csv ----------------
def validate_ctilde(j, ct):
    path = os.path.join(LOGM, 'logm_infty_rows.csv')
    worst = None
    with open(path) as fh:
        for r in csv.DictReader(fh):
            if int(r['j']) != j:
                continue
            n = int(r['n'])
            if n in ct:
                d = abs(ct[n] - float(mp.mpf(r['Ctilde'])))
                if worst is None or d > worst:
                    worst = d
    print(f"  [check] Ctilde_{j} vs logm_infty_rows.csv: max|diff| = "
          f"{worst:.2e}" if worst is not None else
          f"  [check] j={j} not in logm_infty_rows.csv", flush=True)

# ---------------- main sweep ----------------
CASES = {1200: [29, 54, 90, 140, 200, 300], 600: [29, 54, 90, 140], 300: [29, 54]}
CHECKPOINTS = [15, 10, 6, 4, 3, 2, 1.5, 1.0, 0.5, 0.0, -0.5, -1.0, -1.5, -2.0,
               -2.5, -3.0, -4.0, -5.0, -6.0]
INFTY_CSV_J = {15, 20, 29, 40, 54, 70, 90, 103, 140, 200, 256, 330, 400, 500, 590, 800, 1000}

all_j = sorted({j for js in CASES.values() for j in js})
print("== building sigma tables (M-independent, one per j-pair) ==")
for j in all_j:
    build_sigma_table(j)
CT = {j: ctilde_row(j) for j in all_j}
for j in all_j:
    if j in INFTY_CSV_J:
        validate_ctilde(j, CT[j])

csv_rows = []
for N in sorted(CASES, reverse=True):
    C = cacheC(N); M = C.shape[0]
    for j in CASES[N]:
        nu = 2.0*j; n13 = nu**(1/3)
        tab = SIG[j]; ct = CT[j]
        nmax = max(tab)
        # accumulation profile: integrand per site, cumulative from n=1
        head = 0.0
        for n in range(1, min(K, nmax)+1):
            s0, s1 = tab[n]
            head -= float(s1 - s0)          # -(Delta sigma) on dropped head sites
        # NOTE sign: Lambda*nu^{1/3} = C_sec - Ctilde = sum[s_cache - Delta sigma]
        #            over section sites + sum[-Delta sigma] over head sites n<=4
        acc = head
        acc_at = {}
        integ = {}
        for n in range(K+1, nmax+1):
            col = n - K - 1
            if col >= C.shape[1]:
                break
            s_cache = C[j, col] - (C[j, col-1] if col > 0 else 0.0)
            s0, s1 = tab[n]
            integ[n] = s_cache - float(s1 - s0)
            acc += integ[n]
            acc_at[n] = acc
        # per-site D at j and j+1 (band region only, for Delta(w))
        print(f"\n== M={M} j={j}  (nu^1/3 = {n13:.3f}) ==")
        # [1b] identity check: acc at site n equals C_sec - Ctilde
        errs = []
        for n in range(K+1, min(nmax, C.shape[1]+K)+1):
            m = n - K
            if m-1 >= C.shape[1] or n not in acc_at:
                continue
            lhs = C[j, m-1] - ct[n]
            errs.append(abs(lhs - acc_at[n]))
        print(f"  identity |C_sec - Ctilde - accum| max = {max(errs):.2e}  "
              f"(head n<=4 contrib = {head:.2e})")
        # [3] accumulation profile at w checkpoints
        prof = []
        for wc in CHECKPOINTS:
            best = None
            for n in acc_at:
                w = wof(j, n)
                if best is None or abs(w - wc) < abs(best[0] - wc):
                    best = (w, n)
            if best and abs(best[0] - wc) < 0.6:
                prof.append((wc, best[0], acc_at[best[1]]/n13))
        print("  accumulation A(w) = Lambda_true down to w  [w_target, w_actual, A]:")
        print("   " + "  ".join(f"{wc:+.1f}:{a:+.3f}" for wc, wa, a in prof))
        # [2]+[4] band table
        print("    m     w     Lam_true   Lam_P      dD/n13     Del_j     Del_j1")
        for n in sorted(acc_at):
            w = wof(j, n)
            if w < -3.2 or w > 2.2:
                continue
            m = n - K
            lam_t = (C[j, m-1] - ct[n])/n13
            lam_p = (C[j, m-1] - float(profile_P(j, w)))/n13
            Fj = F_col(C, j, m-1); Fj1 = F_col(C, j+1, m-1)
            s0, s1 = tab[n]
            Dj = Fj - float(s0); Dj1 = Fj1 - float(s1)
            del_j = Dj/n13; del_j1 = Dj1/((nu+2)**(1/3))
            print(f"  {m:>4} {w:+5.2f}  {lam_t:+8.4f}  {lam_p:+8.4f}  "
                  f"{integ[n]/n13:+8.4f}  {del_j:+8.4f}  {del_j1:+8.4f}")
            csv_rows.append([M, j, n, m, round(w, 4), lam_t, lam_p,
                             integ[n]/n13, del_j, del_j1])
        # caustic-cell bins (LOGM continuity + the pinned ramp)
        for lo, hi in [(-0.5, 0.0), (0.0, 0.5)]:
            cells_t = [ (C[j, n-K-1] - ct[n])/n13 for n in acc_at
                        if lo <= wof(j, n) < hi ]
            cells_p = [ (C[j, n-K-1] - float(profile_P(j, wof(j, n))))/n13
                        for n in acc_at if lo <= wof(j, n) < hi ]
            if cells_t:
                print(f"  bin [{lo:+.1f},{hi:+.1f}): Lam_true = "
                      f"{np.mean(cells_t):+.4f}  Lam_P = {np.mean(cells_p):+.4f}  "
                      f"(cells: {len(cells_t)})")

with open(os.path.join(HERE, 'lambda_pin_constants.csv'), 'w', newline='') as fh:
    w = csv.writer(fh)
    w.writerow(['M', 'j', 'n', 'm', 'w', 'Lambda_true', 'Lambda_P',
                'dD_per_site', 'Delta_j', 'Delta_j1'])
    w.writerows(csv_rows)
print("\nsaved lambda_pin_constants.csv")
