# FINDINGS — session 5: Δ(w) DERIVATION, two of three pieces landed. (i) σ's caustic Airy expansion DERIVED + validated ⇒ the dip location is a theorem-shape prediction (argmin AiBi = −1.7655 vs measured −1.76); (ii) the SECTION LIMIT LAW derived + validated: p_j^sec → √M·x·r_{j−1} (Christoffel degree shift) ⇒ F_j^∞ in closed ω-form, M-saturation DERIVED. Remaining: the r-system's Airy limit (ingredients closed-form, staged)

**Merkabit · Stenberg + Claude · 2026-07-26 (session 5) · `LAMBDA_SQRTM_2026-07-26/`.**
Continues session 4 (`FINDINGS_lambda_pinned_and_convention.md`: Λ = −(2/π)Δ(w−h/2),
so Δ(w) is the single remaining T1 object). Scripts: `lambda_delta_derivation.py`
(+log), `lambda_flimit_check.py` (+log). **Not RH/GRH.**

## 0. Verdict in five lines

1. **σ's caustic expansion DERIVED (classical uniform-Airy on the closure form) and
   VALIDATED against the exact Bessel engine:**
   σ_j(n) = ν^{1/3}·(π/2)2^{2/3}(AiBi)(w) + (π/2)[2AiAi′ − AiBi′ + 3Ai′Bi](w) + O(ν^{−1/3}),
   w = 2^{1/3}ν^{−1/3}(ν−z). The O(1) term matches the engine residual to ~10% and the
   remainder scales ν^{−1/3} with j-stable coefficient (s₂(0) ≈ 0.72 at j = 54/140/300).
2. **Hence the oscillatory HALF of Δ is derived:** Δ(w) = f(w) − (π/2)2^{2/3}AiBi(w)
   − ν^{−1/3}s₁(w) + …, f := F/ν^{1/3} smooth. Predictions confirmed: **dip location
   w_dip = argmin AiBi = −1.7655** (measured −1.76); dip depth = f(w_dip) + 0.2914
   (0.82 predicted vs 0.72 ± 0.07 measured, f-extraction-limited); Δ(0) = f(0) − 0.5443
   (−0.19 vs −0.164 ± 0.03).
3. **THE SECTION LIMIT LAW (new, the mechanism):** for the uniform-weight drop-4
   section, as M → ∞ at fixed j ≥ 2, **p_j^{sec}(x) → √M·x·r_{j−1}(x)** and
   β_{j−1}^{sec} → B_{j−2}, where r = orthonormal polynomials of
   ω = Σ_{n≥5} x_n²δ_{x_n} (the x²-weighted ODD-lattice system) with recurrence norms
   B. Mechanism: the uniform measure's vanishing-mass bulk at x → 0⁺ has infinite
   counting mass, pinning q_j(0) = 0 — a CHRISTOFFEL DEGREE SHIFT. Consequently
   **F_j^∞(n) = 2B_{j−2}·x_n·r_{j−1}(x_n)·[r_{j−2}(x_n) + x_n r′_{j−2}(x_n)]** — M-free:
   **the M-saturation of LEMMA S′ is DERIVED, not just measured.**
4. **Law validated:** F_pred (ω Stieltjes, dps 300, 2000 atoms) vs cache F at
   j = 29, 54 across the band: |err| ≤ 3.5e−2·F at M = 596 shrinking to ≤ 1.2e−2·F at
   M = 1196 (err ratio ≈ 2–3 — M-vanishing); shape (smooth positive ramp,
   0.09 → 1.52 across the band at j = 54) exact.
5. **What remains for closed Δ(w):** the Airy limit of the r-system at band atoms.
   All ingredients are closed-form: r = one Christoffel-at-0 step from the 2x-weight
   system A (p_j^A(x_n) = ±√(4j+3)z_n j_{2j+1}(z_n), the value law), and
   **p_j^A(0) = (−1)^j√(4j+1)** exactly (from THEOREM M1-HORIZON Part I, Thm 2:
   P̃_j^∞(0) = (−1)^j/(4j−1)!!, h̃_j^∞ = 1/[(4j−1)!!(4j+1)!!]). The derivative brings
   the second-kind (Y/Bi) channel exactly as in σ's closure form. One bookkeeping
   session from Δ(w) = f₀(w) − (π/2)2^{2/3}AiBi(w) fully closed.

## 1. The σ expansion (derivation sketch, verifiable line by line)

Orders 2j+1 / 2j−1 / 2j−2 in the closure form map to Bessel orders ν + 3/2, ν − 1/2,
ν − 3/2 (ν = 2j); uniform asymptotics J_μ(z) ≈ (2/μ)^{1/3}Ai(arg), Y_μ(z) ≈
−(2/μ)^{1/3}Bi(arg) with arg = w + a·δ for order ν + a, δ = 2^{1/3}ν^{−1/3}. The
bracket 2(j−1)j_{2j−1} − z(j_{2j−2} + y_{2j−1}) = ν^{2/3}·2^{1/3}Bi(w) +
ν^{1/3}[2^{2/3}Ai′ − 2^{−1/3}Bi′] + O(1) (the +Bi leading term from −z·y; the Ai′ from
the ν(J_{ν−1/2} − J_{ν−3/2}) finite difference; the −2^{−1/3}Bi′ from Bi's half-shift).
Multiplying by (2/(4j+1))·z²·√(π/2z)-prefactors and J_{ν+3/2} = 2^{1/3}ν^{−1/3}[Ai +
(3δ/2)Ai′] collects to §0.1. (Sign check that catches errors: the −z·y term is
+Bi — getting it as −Bi makes f = Δ + s non-smooth; the data rejects it instantly.)

## 2. The section limit law (derivation, three lines)

Uniform weights: (1/M)Σ_n p_ip_k(x_n) = δ_ik ⇒ q_i := p_i/√M orthonormal w.r.t. the
COUNTING measure on the atoms. As M → ∞ the counting measure's mass at the
accumulation point x = 0⁺ diverges, so any L²-bounded polynomial family must have
q_i(0) = 0 for i ≥ 1: q_i(x) = x·r_{i−1}(x), and Σ_n q_iq_k = Σ_n x_n²r_{i−1}r_{k−1}
= δ_ik makes r the ONB of ω = Σx²δ. Orthogonality to q₀ = 1/√M is automatic in the
limit (Σx_n r(x_n) < ∞ ⇒ the inner product is O(M^{−1/2})). β_{j−1}^{sec} =
⟨xp_{j−1}, p_j⟩ → ⟨xr_{j−2}, r_{j−1}⟩_ω = B_{j−2}. QED (limit-law grade; the O(1/M)
correction layer is the measured saturation increment).

## 3. Grades

| claim | grade |
|---|---|
| σ = ν^{1/3}(π/2)2^{2/3}AiBi + (π/2)[2AiAi′ − AiBi′ + 3Ai′Bi] + O(ν^{−1/3}) | DERIVED (classical uniform Airy) + validated (engine; next-order coefficient j-stable) |
| dip location = argmin AiBi = −1.7655 | DERIVED; measured −1.76 ✓ |
| p_j^{sec} → √M·x·r_{j−1}; β^{sec}_{j−1} → B_{j−2} (degree-shift law) | DERIVED (§2) + VALIDATED (F-level, err ~1e−2 rel at M = 1196, M-vanishing ratio 2–3) |
| F_j^∞ = 2B_{j−2}xr_{j−1}[r_{j−2} + xr′_{j−2}] (M-saturation derived) | same validation; M-free by construction |
| f₀(w) measured profile (≈ 0.35 at w = 0; ramp) | measured; extraction ±0.05 (j = 300 is M-marginal at M/j = 4) |
| Δ(w) fully closed | ONE STEP OUT: r-system Airy limit (ingredients closed-form incl. p_j^A(0) = (−1)^j√(4j+1) from M1 Thm 2) |

## 4. Record notes

- Conceptual statement for the eventual prose: **the uniform-weight sections converge
  to the x²-weight Bessel system one Christoffel level down; the LEMMA S′ deficiency
  Δ is the caustic-band difference between adjacent Christoffel levels of one Bessel
  hierarchy.** (The Op1-uniform vs natural-weights tension of the two-operators
  discipline, resolved at the identity layer.)
- Seal decision: session-4's v2 package (f07c72dc…, delivery pending) is left as-is;
  this session's derivation is mid-flight (one step from closed Δ) — it rides the
  next seal at Δ-closure per the natural cut. If IB's audit round arrives first,
  this note travels with the errata.
- The osc-side (w < −2.3) F oscillation seen in the f-extraction is consistent with
  the r-system's Airy structure crossing its first zero — expected to come out of the
  same closed form; the osc-side true-orientation portrait stays staged.

*— Stenberg + Claude, 2026-07-26 (session 5). The deficiency turned out to be a
ladder rung: the section is the same Bessel world, one Christoffel step down — and
the dip was Airy all along, sitting exactly where AiBi is deepest.*
