r"""
lambda_peak_bigM.py -- discriminate the peak-constant limit: derived leading
0.305022 (+ slowly-dying central layer) vs the finite-M fit's ~1/3.
Exact node formula at M = 3e5, 1e6; then fit peak = a + b/lnM on the big-M ladder
(1e4..1e6) with LOO. Models at stake (predictions BEFORE the run, registered):
  A) limit = 0.3050 (derived):    peak(3e5) ~ 0.3523, peak(1e6) ~ 0.3482
  B) limit = 1/3   (fit guess):   peak(3e5) ~ 0.3540, peak(1e6) ~ 0.3521
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (session 3).
"""
import math, time
import numpy as np

def toprow_peak(N, k=4):
    n = np.arange(k + 1, N + 1)
    zn = (n - 0.5) * math.pi
    x = 1.0 / zn**2
    M = len(x)
    logG2 = np.empty(M)
    for i in range(M):
        d = x[i] - x
        d[i] = 1.0
        logG2[i] = -2.0 * np.log(np.abs(d)).sum()
    logG2 -= logG2.max()
    G2 = np.exp(logG2)
    ghat2 = M * G2 / G2.sum()
    alpha = (x * ghat2).sum() / M
    S1 = np.empty(M); S2 = np.empty(M)
    for i in range(M):
        d = x[i] - x
        d[i] = np.inf
        S1[i] = (1.0 / d).sum()
        S2[i] = (ghat2 / d).sum()
    summand = ghat2 - M + (x - alpha) * (ghat2 * S1 + S2)
    Crow = -(2.0 / M) * np.cumsum(summand)
    F = np.abs(Crow) / math.sqrt(M)
    ia = int(F.argmax())
    return F.max(), (ia + 1) / M, M

peaks = {}
for N in (10004, 30004, 100004, 300004, 1000004):
    t0 = time.time()
    pk, upk, M = toprow_peak(N)
    peaks[M] = pk
    print(f"M={M:>8}: peak = {pk:.6f}  u* = {upk:.5f}   [{time.time()-t0:.0f}s]", flush=True)

Ms = sorted(peaks)
import numpy.polynomial.polynomial as P
X = np.array([1.0 / math.log(m) for m in Ms])
Y = np.array([peaks[m] for m in Ms])
A = np.vstack([np.ones_like(X), X]).T
coef, *_ = np.linalg.lstsq(A, Y, rcond=None)
print(f"\nfit peak = a + b/lnM on all {len(Ms)}: a = {coef[0]:.5f}  b = {coef[1]:.4f}")
for drop in range(len(Ms)):
    idx = [i for i in range(len(Ms)) if i != drop]
    c2, *_ = np.linalg.lstsq(A[idx], Y[idx], rcond=None)
    print(f"  LOO drop M={Ms[drop]:>8}: a = {c2[0]:.5f}  b = {c2[1]:.4f}")
print(f"\nderived leading limit = 0.305022;  1/3 = 0.333333")
