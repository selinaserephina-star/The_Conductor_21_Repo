r"""
lambda_peak_derivation.py -- THE PEAK CONSTANT DERIVED: scaling-zone analysis of
the top-row closed form.

Derivation (this session; steps at the blackboard, each validated below):
 [S1 closed form]  (r+A)^2 = (r-n)(r+n+2A) + (n+A)^2  (A = k - 1/2) gives, with
   harmonic/digamma sums, S1_n ~= pi^2 u^2 M^3 Q(u),
   Q(u) = 1 + (u/2) ln(2(1-u)/(1+u)).
 [zone variables]  t = (u - u*) c sqrt(M), c = sqrt(2 E''(u*)); ghat2 = c sqrt(M)
   phi(t); x' = -2/(pi^2 u^3 M^2); alpha = x(u*) + O(M^-3).
 [S2 -> Hilbert]   S2_n ~= (c M^{3/2}/x') H(t),  H(t) = PV int phi(tau)/(t-tau).
 [assembly]        T ~= M[tH(t) - 1] - (2M/u*) Q* t phi(t) + c sqrt(M) phi(t),
   C = -(2/M) prefix  =>  **F~(t) = -(2/c) I(t) - (4 Q*/(c u*)) phi(t)**,
   I(t) = int_{-inf}^t [tau H - 1] dtau;  I odd, I(inf) = 0 (Hilbert mean-zero)
   => F~(+-inf) = 0: reproduces the off-peak flatness AND the sum rule C(.,M)=0.
 => peak constant = max_t F~(t): explicit, no free parameters.

CHECKS:
 [0] H normalization: dawsn relation vs direct PV quadrature.
 [1] evaluate F~(t): peak value + location; compare vs the conjectured 1/3 and
     the measured ladder 0.3706/0.3665/0.3623/0.3593/0.3569 (M = 1e3..1e5).
 [2] POINTWISE: F_exact(t) from the exact node formula at M = 1e4 and 1e5,
     mapped to t via u = u* + t/(c sqrt(M)), vs F~(t) on a t-grid -- the real
     test of the scaling analysis (not just the peak).
 [3] finite-M correction structure: (F_exact - F~) scaling with M at fixed t.
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (session 3).
"""
import math
import numpy as np
from scipy.optimize import brentq
from scipy.special import dawsn
from scipy.integrate import quad

SQ2PI = math.sqrt(2 * math.pi)


def phi(t):
    return math.exp(-t * t / 2) / SQ2PI


def dE(u):
    return math.log((1 + u) / (1 - u)) - 2 / u


def d2E(u):
    return 1 / (1 - u) + 1 / (1 + u) + 2 / u**2


ustar = brentq(dE, 0.7, 0.95, xtol=1e-15)
c = math.sqrt(2 * d2E(ustar))
Qs = 1 + (ustar / 2) * math.log(2 * (1 - ustar) / (1 + ustar))
print(f"u* = {ustar:.12f}   c = {c:.8f}   Q(u*) = {Qs:.8f}")

# [0] H(t) = PV int phi(tau)/(t-tau) dtau ; candidate: sqrt(2/pi)?? * dawsn(t/sqrt2)
def H_pv(t, eps=1e-7):
    f = lambda tau: phi(tau) / (t - tau)
    a1, _ = quad(f, -40, t - eps, limit=400)
    a2, _ = quad(f, t + eps, 40, limit=400)
    # symmetric excision -> PV
    return a1 + a2

for t in (0.5, 1.0, 2.0):
    hd = math.sqrt(2.0) * dawsn(t / math.sqrt(2))
    print(f"[0] t={t}: PV = {H_pv(t):.8f}   sqrt(2)*dawsn(t/sqrt2) = {hd:.8f}")


def H(t):
    return math.sqrt(2.0) * dawsn(t / math.sqrt(2))


def integrand(tau):
    return tau * H(tau) - 1.0


# I(t): integrate from -inf; use evenness: I(t) = int_0^t even + I(0), I(0)=0
# (I odd). So I(t) = int_0^t [tau H - 1] dtau.
def I(t):
    s = np.sign(t); t = abs(t)
    v, _ = quad(integrand, 0, t, limit=400)
    return s * v


def Ftilde(t):
    return -(2 / c) * I(t) - (4 * Qs / (c * ustar)) * phi(t)


ts = np.linspace(-4, 6, 1001)
Fv = np.array([Ftilde(t) for t in ts])
imax = int(Fv.argmax())
print(f"\n[1] derived profile: max F~ = {Fv[imax]:.6f} at t = {ts[imax]:.3f}")
print(f"    F~(0) = {Ftilde(0):+.6f}   F~(-2) = {Ftilde(-2):+.6f}   "
      f"F~(3) = {Ftilde(3):+.6f}")
print(f"    1/3 = 0.333333;  measured peaks: 0.3706(1e3) 0.3665(3e3) 0.3623(1e4) "
      f"0.3593(3e4) 0.3569(1e5)")

# [2] exact node-formula profile mapped to t
def toprow_F(N, k=4):
    n = np.arange(k + 1, N + 1)
    zn = (n - 0.5) * math.pi
    x = 1.0 / zn**2
    M = len(x)
    logG2 = np.empty(M)
    for i in range(M):
        d = x[i] - x
        d[i] = 1.0
        logG2[i] = -2.0 * np.log(np.abs(d)).sum()
    logG2 -= logG2.max()
    G2 = np.exp(logG2)
    ghat2 = M * G2 / G2.sum()
    alpha = (x * ghat2).sum() / M
    S1 = np.empty(M); S2 = np.empty(M)
    for i in range(M):
        d = x[i] - x
        d[i] = np.inf
        S1[i] = (1.0 / d).sum()
        S2[i] = (ghat2 / d).sum()
    summand = ghat2 - M + (x - alpha) * (ghat2 * S1 + S2)
    Crow = -(2.0 / M) * np.cumsum(summand)
    return Crow / math.sqrt(M), M


print("\n[2] pointwise F_exact(t) vs F~(t):")
for N in (10004, 100004):
    Fex, M = toprow_F(N)
    print(f"   M = {M}:")
    print("      t     F_exact     F~       diff      diff*sqrt(M)")
    for t in (-2.0, -1.0, 0.0, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0):
        u = ustar + t / (c * math.sqrt(M))
        idx = int(round(u * M)) - 1
        fe = Fex[idx]
        ft = Ftilde(t)
        print(f"   {t:+5.1f}  {fe:+9.5f}  {ft:+9.5f}  {fe - ft:+9.5f}  "
              f"{(fe - ft) * math.sqrt(M):+8.3f}")
    ia = int(np.abs(Fex).argmax())
    tpk = ((ia + 1) / M - ustar) * c * math.sqrt(M)
    print(f"      exact peak {np.abs(Fex).max():.6f} at t = {tpk:+.3f} "
          f"(derived peak {Fv[imax]:.6f} at t = {ts[imax]:.3f})")
