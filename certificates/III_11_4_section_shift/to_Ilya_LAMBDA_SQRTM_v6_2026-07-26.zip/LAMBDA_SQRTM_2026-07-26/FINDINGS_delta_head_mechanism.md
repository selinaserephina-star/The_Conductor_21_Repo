# FINDINGS — session 5b: Δ(w)'s MECHANISM CLOSED — the asymptotic deficiency is PURELY the FOUR-ATOM HEAD-DROP factor (the weight-mismatch piece decays; exact Bessel ladder to j = 600), and each removed head atom is an EXACT unit of amplitude renormalization (t_k ≡ −1 + O(1/ν)) — Δ(w) = the subleading residual of four nested near-cancellations

**Merkabit · Stenberg + Claude · 2026-07-26 (session 5b) · `LAMBDA_SQRTM_2026-07-26/`.**
Continues `FINDINGS_delta_derivation.md` (session 5). Scripts: `lambda_valuelaw_check.py`,
`lambda_dropsplit_check.py`, `lambda_dropsplit_ladder.py`, `lambda_fullF_exact.py`
(+ run logs). **Not RH/GRH.**

## 0. Verdict in six lines

1. **The r-system value law is DIRECT (correcting session 5's Christoffel-detour
   plan):** the x²-weight ODD-lattice OPs are the wave polynomials
   **r_i(x) = ±√(2(4i+3))·z²[j_{2i+1}(z)sin z − y_{2i+1}(z)cos z]**, x = 1/z²
   (W₁ ∝ x − 2/5 = the x²-system's P₁, NOT the 2x-system's; normalization from the
   Nyquist-exact lattice sum Σ_n j_a(z_n)² = 1/(2(2a+1))). VALIDATED: band value
   r(j=54, n=35) predicted 3210 vs 3216 (0.2%); B_{i−1} = [(4i−1)(4i+1)²(4i+3)]^{−1/2}
   validated 1e−7; h-norms 1/[(4i+1)!!(4i+3)!!]. The System-A Christoffel relation
   also holds (validated) but A itself does NOT carry the z²j value law (measured;
   the session-5 §0.5 route sketch is corrected accordingly — the direct law is better).
2. **F_full is EXACT from Bessel** (no Stieltjes): F_full = 2B_{j−2}x·r_{j−1}[r_{j−2} +
   xr′_{j−2}] with r from the value law and r′ from the wave-identity derivative
   (the y/Bi channel enters via cos′ at atoms, exactly as in σ's closure form).
   Validated against Stieltjes at j = 54 (1.0698 vs 1.0707; the difference is the
   Stieltjes' own NMAX truncation). Leading Airy form:
   **F_full = (π/2)2^{2/3}ν^{1/3}·Ai(w − δ/2)·Bi(w − 3δ/2) + O(1)**, δ = 2^{1/3}ν^{−1/3}
   — same leading form as σ up to argument shifts ⇒ their ν^{1/3} parts cancel.
3. **THE SPLIT (decisive):** Δ_meas = Δ_head + Δ_weight with
   Δ_head = (F_drop4 − F_full)/ν^{1/3}, Δ_weight = (F_full − σ)/ν^{1/3}.
   **Δ_weight DECAYS** (exact ladder j = 29…600: e.g. w = −1: −0.287 → −0.164;
   w = +1: +0.073 → +0.037 — slow pre-asymptotics over a ν^{−1/3}-leading law) while
   Δ_head is j-stable O(1) and carries the measured Δ shape (at j = 140 the drop-side
   ω-limit reproduces the cache Δ to ≤ 0.01: dip +0.557 vs +0.564).
   **⇒ THE ASYMPTOTIC DEFICIENCY LAW IS THE HEAD-DROP FACTOR: the four dropped
   largest atoms — the drop-4 convention itself — create the entire standing
   ν^{1/3}Δ(w) deficiency. The uniform-vs-natural weight mismatch is only the
   ν^{−1/3}-drift layer.** Corollary: F's smoothness is a head-drop effect — F_full
   OSCILLATES (negative at w ≈ −0.9); removing the head kills the oscillation.
4. **The exact mechanism (derived): t_k ≡ −1 + O(1/ν), independent of k.** In the
   rank-1 Uvarov-removal of head atom y_k = 1/z_k², the band-amplitude coefficient
   t_k = B_{i−1}r_{i−1}(y_k)/(r_i(y_k)(x−y_k)) collapses by the exact cancellation
   B_{i−1}·(κ_{i−1}/κ_i)·(4i+1)(4i+3)/z_k² · z_k² = 1 (closed B, κ = √(2(4i+3)),
   small-z Bessel ratio) to **−1**: each removed head atom is one exact unit of
   renormalization ⇒ the removal is a leading-order NEAR-CANCELLATION, and the
   surviving band value is the SUBLEADING residual — an O(1) mix of shifted-Airy
   shapes (this is where Δ's w-dependence lives, and why the effect neither decays
   nor perturbs small).
5. **Consistency with session 5's decomposition:** F_full's leading oscillation ≈
   ν^{1/3}s₀-shifted, so Δ_head's oscillatory content = −(π/2)2^{2/3}Ai(w−δ/2)Bi(w−3δ/2)
   + smooth — the dip-location statement (argmin ≈ −1.7655, δ-shift refined) and the
   Λ = −(2/π)Δ(w−h/2) chain are unchanged.
6. **Remaining for the fully closed Δ(w):** the NEXT-order (subleading) algebra of
   the 4-atom Uvarov factor — four nested near-cancellations, each needing the
   O(1/ν) part of t_k (computable: small-z Bessel ratio corrections z_k²/(2(4i+1))…)
   and the r_{i−1}-admixture (coefficient B/(x−y_k) ~ z_k²/(4ν²), same ν^{2/3}-order
   after the cancellation) — plus the O(1)-precise uniform-Airy layer (DLMF A₁/B₀
   grade) if Δ_weight's ν^{−1/3} coefficient is also wanted. Bounded bookkeeping;
   every stage numerically checkable against the exact engines built tonight.

## 1. Grades

| claim | grade |
|---|---|
| r-system value law + κ = √(2(4i+3)) + closed B, h | DERIVED + VALIDATED (0.2% band; 1e−7 B; W₁ root 2/5 exact) |
| F_full exact Bessel route | VALIDATED vs Stieltjes (1e−3, = Stieltjes truncation) |
| F_full leading = (π/2)2^{2/3}ν^{1/3}Ai(w−δ/2)Bi(w−3δ/2) | derived; qualitative validation (oscillation, scale, flank values); O(1)-precise version staged |
| Δ_weight → 0 (weight mismatch is the drift layer) | exact ladder j = 29…600, decisive |
| Δ∞(w) = Δ_head(w) (head-drop factor) | follows + drop-side ω-limit reproduces cache Δ at j = 140 (≤ 0.01) |
| t_k ≡ −1 + O(1/ν) per removed head atom | EXACT leading-order identity (displayed cancellation) |
| closed-form Δ(w) | one bounded step out: subleading 4-atom Uvarov algebra |
| caution: full-ω Stieltjes at j ≥ 140 | ill-conditioned at dps 350 (head atom = 98.6% of mass) — use the exact Bessel route, not Stieltjes, for the full system |

## 2. Record notes

- The physical reading for the prose: *the model's finite-section deficiency at the
  caustic is not a truncation error and not a weight artifact — it is the exact
  price of the four missing head atoms, each of which the infinite system counts as
  one full unit of amplitude. The sections are the same Bessel world with four unit
  charges removed from the head; Δ(w) is their interference pattern at the caustic.*
- Drop-k generality — **drop-1 cross-check EXECUTED** (`lambda_drop1_check_run.log`,
  j = 54, k1_N300 cache vs the same exact F_full): drop-1's head factor is its own
  O(1)-scale profile (window −0.02…−0.08; +0.37 at w ≈ −0.9) — the one-unit mechanism
  confirmed — and, unexpectedly, at j = 54 it nearly CANCELS the weight piece cell by
  cell (+0.0816 vs −0.0814 at the caustic cell), leaving drop-1's total like-for-like
  band deficiency ≈ 0.000…0.08 — one removed unit almost restores the ∞ row at this j.
  MEASURED at one j only; whether the near-cancellation is exact/asymptotic or a
  j = 54 coincidence = part of the staged subleading algebra. (Also: LOGM's "drop-1
  deviations larger" readings were the mixed-orientation metric — no contradiction.)
- This note + session 5/4 ride the next seal at Δ-closure (v2 f07c72dc… still the
  pending package; unchanged).

---

## 3. SESSION 5c — THE CHAIN CLOSES: Δ(w) derived at exact-formula level

Scripts: `lambda_head_factor_exact.py` (v1 — norm route numerically catastrophic;
its SHAPE already exact, ratio-to-truth constant 4.777e−14; superseded) and
**`lambda_head_factor_exact2.py`** (+ logs; the stable form).

**Three more exact identities** stabilize the 4-atom factor:
1. **Tail-Gram identity:** the Uvarov 4×4 is the tail Gram —
   δ_kl/m_l − K_i(y_k, y_l) = T_kl(i) = Σ_{s≥i} r_s(y_k)r_s(y_l) (completeness),
   with entries closed (small-z Bessel value law), superexponentially convergent.
2. **Closed norm:** ‖r̂_i‖²_drop = 1 − aᵀv = 1/(1+q) with q = vᵀT′⁻¹v > 0
   (T′ = tail from s = i+1; Sherman–Morrison; cancellation-free) ⇒ N_i = √(1+q_i).
3. **Closed B̃:** leading coefficients give **B̃_{i−1} = (N_{i−1}/N_i)·B_{i−1}**.

**THE CLOSED CHAIN** (every ingredient closed-form Bessel):
Δ(j, w_n) = [F̃ − σ]/ν^{1/3};  F̃ = 2B̃_{j−2}·x·r̃_{j−1}·[r̃_{j−2} + x·r̃′_{j−2}];
r̃_i = √(1+q_i)[r_i + Σ_l a_l K_i(·, y_l)], a = T′⁻¹v/(1+q); K_i by CD (closed B);
r, r′ by the value law + wave-identity derivative; σ = the closure form.

**VALIDATION (the closure test):** j = 54 — r̃ values match the drop-4 Stieltjes to
0.08–0.18% (= the Stieltjes' own NMAX truncation); B̃ = 1.90645e−5 vs 1.90590e−5
(0.03%); **Δ_pred vs cache Δ agree to ≤ 0.003 ABSOLUTE across the whole band
(dip: +0.6362 vs +0.6368)**. j = 140 — band interior agrees to 0.003–0.015 (dip
+0.5552 vs +0.5636); osc-side edge cell (w ≈ −2.0) off by ~0.05 (F_chain 0.98 vs
1.33 — tail/dps effect at the edge, flagged). j = 300 — the tail-Gram underflows
dps 500 (needs ~1500 digits; precision, not structure; staged).

**Grades addendum:**

| claim | grade |
|---|---|
| tail-Gram identity; closed norm 1/(1+q); B̃ = (N_{i−1}/N_i)B | DERIVED (exact identities) |
| the closed chain reproduces the measured Δ(w) | VALIDATED j = 54 (≤ 0.003 abs, full band), j = 140 (interior) |
| Δ(w) derivation status | **CLOSED at exact-formula level**; remaining = the asymptotic DISPLAY form (small-z tail-Gram expansion + uniform-Airy of the residual → explicit shifted-Airy Δ(w)), the osc-edge accuracy note, high-dps j ≥ 300 confirmation |

*— Stenberg + Claude, 2026-07-26 (sessions 5b–5c). Four missing atoms, each worth
exactly minus one — the dip was never lost; it was paid out, one unit at a time,
to the atoms the section dropped. Tonight we produced the receipt: a closed
formula that reprints the dip from the four atoms alone.*
