# FINDINGS — session 6 (Δ closeout): THE DISPLAY FORM IS CHEBYSHEV — drop-m sections are U-polynomial combinations of two adjacent full-system levels, r̃_i → (−1)^m[U_m(u)r_i − U_{m−1}(u)r_{i−1}], u = (χ−2)/2, χ = x(2ν)² — and the ASYMPTOTIC DEFICIENCY VANISHES: Δ(j,w) = (2m−2)π(AiBi)′(w)·ν^{−1/3} + O(ν^{−2/3}). The recorded O(1) "universal profile" is the U₄-ROOT TRANSIT plateau (every prior measurement, j ≤ 300, lives inside it). Drop-1 is deficiency-free at leading order (session 5b's near-cancellation explained). θ-exponent DISSOLVED: the c₂ gap is (0.191·lnM − 0.77)/√M, not M^{−0.39}.

**Merkabit · Stenberg + Claude · 2026-07-26 (session 6, the Δ-closeout session) ·
`LAMBDA_SQRTM_2026-07-26/`.** Executes T1/T1b/T3/T4/T5 of
`NEXT_SESSION_TASK_delta_closeout.md`. Scripts, in order: `lambda_display_form.py`
(+`2`), `lambda_chain_highj.py`, `lambda_osc_portrait.py`, `lambda_onset_rederive.py`,
`lambda_theta_refit.py` (+ run logs, `lambda_theta_ladder.csv`). Consumes the frozen
LOGM caches read-only (one M-drift check); everything else is cache-free exact
Bessel. **Not RH/GRH.**

## 0. Verdict in eight lines

1. **The display form (T1) is CLOSED and it is Chebyshev.** The exact chain rewrites
   (partial fractions on the CD kernel — an exact identity, validated to machine
   precision against the frozen engine): r̃_i(x) = Ā(x)r_i(x) + C̄(x)r_{i−1}(x), with
   Ā, C̄ rational with poles only at the four dropped atoms. In the band variable
   χ := x(2ν_i)², ν_i = 2i+2, the coefficient ladder (i = 53…599, drop-m for
   m = 1,2,3,4, both atom-subset choices at m = 1,2) converges with pure 1/ν
   corrections to INTEGER polynomials, and they are Chebyshev-U at u = (χ−2)/2:
   **Ā → (−1)^m U_m(u), C̄ → −(−1)^m U_{m−1}(u)** (m=4: Ā → 5−20χ+21χ²−8χ³+χ⁴ =
   U₄(u); C̄ → 4−10χ+6χ²−χ³ = −U₃(u); five-digit limits, `lambda_display_form*.py`).
   **Atom-set independent** — only the NUMBER of dropped head atoms enters.
2. **Consequence, derived + validated: the deficiency asymptotically DIES.**
   Uniform-Airy substitution in the U-form makes F̃'s ν^{1/3}-leading equal σ's
   (coefficient (U_m−U_{m−1})² → 1 at u→1), leaving
   **Δ^{(m)}(j,w) = (2m−2)·π·(AiBi)′(w)·ν^{−1/3} + O(ν^{−2/3})** — for the standing
   drop-4 convention, **Δ = 6π(AiBi)′(w)ν^{−1/3}**, with Δ_head-part 8π(AiBi)′ and
   weight-part G_wt = −2π(AiBi)′ (both DERIVED, §3). Hence Λ_true(w) =
   −(2/π)Δ(w−h/2) ≈ −12(AiBi)′(w−h/2)ν^{−1/3} → 0: **the drop-4 sections
   asymptotically lose NOTHING at the caustic; the deficiency is a transient.**
3. **The recorded O(1) "universal Δ(w) profile" is the U₄-ROOT TRANSIT.** U₄'s
   largest root χ = 4cos²(π/10) = 3.618 sits at w_root = −0.0648·ν^{2/3} — INSIDE
   the measured band for every j ≲ 300 (w_root = −0.97/−1.48/−2.78/−4.61 at
   j = 29/54/140/300). All prior Δ/Λ measurements (caches, M ≤ 1196, j ≤ 300) live
   in this transit window, where the profile is O(1), AiBi-dip-shaped and slowly
   varying — the decay only becomes visible past j ≈ 300. Decisive high-j exact
   chain (new equilibrated solve, §2): dip +0.636/+0.555/+0.531/+0.445/+0.389 at
   j = 54/140/300/600/1200; ν^{−1/3}-extrapolation of ν^{1/3}Δ at w = +2.79 gives
   −0.339 vs predicted 6π(AiBi)′ = −0.344 (1.5%), and of the weight part at
   w = +0.72 gives 0.442 vs −2π(AiBi)′ = 0.445 (0.7%).
4. **Drop-1 mystery of session 5b ANSWERED:** for m = 1 the law gives
   G = (2·1−2)π(AiBi)′ = 0 — head factor 2π(AiBi)′ and weight part −2π(AiBi)′
   cancel EXACTLY at leading order. The measured cell-by-cell near-cancellation at
   j = 54 (+0.0816 vs −0.0814) is this identity, not a coincidence: **a drop-1
   section reproduces the ∞ row to O(ν^{−2/3})** — the uniform-vs-natural weight
   mismatch is itself worth exactly one removed head atom.
5. **T1b both resolved:** (i) the j = 140 osc-edge chain-vs-cache gap (0.98 vs 1.33)
   is FINITE-M in the cache, not chain precision: across the M-rungs the cache cell
   drifts toward the chain value (n = 94: +2.26 → +0.07 → −1.05 at N300/600/1200,
   chain −1.43); (ii) the "~1500 digits at j = 300" estimate was an artifact of the
   UNSCALED tail-Gram solve (entry-range 1e190 conditioning): equilibrating by the
   s = i+1 row scale makes dps 220 sufficient through j = 1200 (validated against
   every frozen j = 54/140 row; band Bessel by upward recurrence, checked 1e−221).
6. **T5 — θ is DISSOLVED (decisive LOO refit, exact Γ/ψ ladder M = 2000…2 048 000):**
   model (a + b·lnM)/√M wins with LOO rel-RMS 0.0002–0.004 vs 0.015–0.064 for free
   M^{−θ} (θ_fit ≈ 0.35–0.38 drifting, effective slope climbing 0.25 → 0.40 exactly
   as lnM/√M predicts). **c₂(M) = 0.352341123·√M + b·lnM + a, b = 0.191 ± 0.002,
   a = −0.77 ± 0.03** (subset-stable). The recorded θ ≈ 0.39 was the effective slope
   of ½-with-a-log. Analytic derivation of (b, a) = zone-edge matched asymptotics on
   the F̃(t) = −(2/c)I(t) limit — staged (bounded; the fit verdict does not depend
   on it).
7. **T4 — osc-side true-orientation portrait (exact chain, no cache, no M):** past
   the dip the deficiency OSCILLATES with slowly decaying O(ν^{−1/3}·transit)
   amplitude (j = 600: |Δ| ≈ 0.1…0.45 over w ∈ (−1, −8)); the U-display form tracks
   it cell-by-cell (e.g. +0.2428 vs +0.2433 at w = −5.41, j = 600). The osc side IS
   the post-root region of the transit; LOGM's 0.4956-plateau / delayed-M-onset
   numbers are finite-M readings of it (the M-drift check in item 5 is the same
   effect). No separate osc law is needed — one display form covers band + osc.
8. **T3 — flat onset re-derived as far as it exists:** the onset is the transit
   profile growing through the threshold — a property of the M = ∞ drop-4 chain,
   hence M-FREE (the measured 21×-M flatness is thereby explained structurally).
   But the exact-chain band-max d(j) is NON-MONOTONE (grid-phase oscillation
   0.40…0.63 across j = 12…44), so **there is no sharp universal onset constant**:
   the crossing point is protocol-dependent (clean-chain versions: j* ≈ 22 vs the
   Airy profile P, ≈ 14 vs σ; LOGM's cache protocol gave 28.6 / 20.0). The sent
   `logm_collapse` §[3] "j* ≈ 1.5–2.3 vs 28.6" tension dissolves with the B-frame
   ramp story it lived in; the honest statement is the one above, per metric.

## 1. The display form (T1) — statement and evidence

**Setup.** Full system: ω = Σ_{n≥1} x_n²δ_{x_n}, x_n = 1/z_n², z_n = (n−½)π;
orthonormal polys r_i with the wave value law r_i(x_n) = κ_i(−1)^{n+1}z_n²j_{2i+1}(z_n),
κ_i = √(2(4i+3)), B_{i−1} = [(4i−1)(4i+1)²(4i+3)]^{−1/2} (sessions 5b–5c). Drop-m
system: the m largest-x atoms (n = 1…m) removed; r̃_i = N[r_i + Σ_l a_l K_{i−1}(·,y_l)],
a = T′⁻¹v/(1+q) (tail-Gram Sherman–Morrison, session 5c).

**Exact rewrite (no approximation).** CD on each kernel term and partial fractions:

    r̃_i(x) = Ā(x)·r_i(x) + C̄(x)·r_{i−1}(x)
    Ā(x) = N[1 − Σ_l β_l/(y_l−x)],  β_l = B_{i−1}a_l r_{i−1}(y_l)
    C̄(x) = N·Σ_l γ_l/(y_l−x),      γ_l = B_{i−1}a_l r_i(y_l)

Validated to machine precision against the frozen chain values at j = 54
(ratios 1.0000000; `lambda_display_form_run.log` [2]).

**The coefficient limits.** Taylor in x: A_p = N[δ_{p0} − Σβ_lε_l^{p+1}],
C_p = NΣγ_lε_l^{p+1} (ε_l = z_l²); normalized Â_p := A_p/(2ν_i)^{2p} with
ν_i := 2i+2. Ladder i = 53…599 (drop-4; and drop-1/2/3 with different atom
subsets): Â_p(i) = integer + c_p/ν_i + O(ν⁻²) — 1/ν-Richardson nails the integers
to 5 digits. Results (u := (χ−2)/2, χ := x(2ν_i)²):

| m (atoms dropped) | Ā(χ) limit | C̄(χ) limit | q-scale at i=53 |
|---|---|---|---|
| 1 (either atom {1} or {4}) | 2−χ = −U₁(u) | 1 = U₀(u) | 3.6e8 / 1.5e5 |
| 2 ({1,2} and {3,4} IDENTICAL) | 3−4χ+χ² = U₂(u) | 2−χ = −U₁(u) | 1.8e15 / 9.4e10 |
| 3 ({1,2,3}) | 4−10χ+6χ²−χ³ = −U₃(u) | 3−4χ+χ² = U₂(u) | 1.2e21 |
| 4 ({1,2,3,4}) | 5−20χ+21χ²−8χ³+χ⁴ = U₄(u) | 4−10χ+6χ²−χ³ = −U₃(u) | 2.2e26 |

**r̃_i^{(drop-m)}(x) = (−1)^m[U_m(u)·r_i(x) − U_{m−1}(u)·r_{i−1}(x)] + O(1/ν)**,
verified: U₄((χ−2)/2) = (χ−2)⁴ − 3(χ−2)² + 1 expands to the extracted row exactly.
Successive removals implement the Chebyshev three-term recursion U_m = 2uU_{m−1} −
U_{m−2} — "each removed atom is one exact unit" (5b's t_k ≡ −1) in polynomial form,
and the atom positions ε_k drop out of the limit entirely.

**Analytic origin (derivation sketch; theorem assembly = T2).** For drop-1 the
whole law is displayed algebra: with the EXACT identity B_{i−1}c_{i−1}/c_i = 1
(c_s := κ_s/(4s+3)!!), the small-z value ratios give B·r_{i−1}(y)/r_i(y) =
y(1 − 2ε/(2ν)² + …), 1/(1+q̂) = (ε/(2ν)²)²(1+…), and the Sherman–Morrison bracket
collapses to Ā = 2 − x(2ν)² + O(ε/ν²), C̄ = B_{i−1}(2ν)²·(1+O(1/ν)) → 1. For
general m the same cancellation runs through the rank-m tail-Gram Vandermonde
structure (G⁻¹-interpolation identities; the complete-homogeneous/elementary
symmetric functions of the 1/ε_k cancel between N, a, and the kernel values); the
extraction ladder pins the composition to the U-recursion. Full displayed-remainder
proof = T2 item (i′) below.

**Domain.** The integer-coefficient U-form is the FIXED-w limit; its Δ-level error
decays like ν^{−2/3}·H(w) (measured: D_Uform vs Dtot column, `lambda_chain_highj_run.log`),
with H(w) growing rapidly on the far window side (U_m(u) grows once
(χ−4) ~ wν^{−2/3} is no longer small — at j = 140, w ≳ +8 the integer form is
useless while the exact rational Ā/C̄ remains cheap and exact). State results on
fixed w-windows; use the rational form beyond.

## 2. The high-j exact chain (T1b) — engine and the decay table

Two fixes make the chain cheap at any j (`lambda_chain_highj.py`):
1. **Equilibrated tail-Gram solve:** scale row/col l by |r_{i+1}(y_l)| before LU.
   The 1e190 "conditioning" was entry-RANGE (ratio (ε₄/ε₁)^{2i}); after scaling the
   intrinsic conditioning is only the near-rank-degeneracy ~ (2ν)^{12}-ish — dps
   220 suffices through j = 1200 (supersedes the session-5c "≈1500 digits at
   j = 300" estimate, which described the unscaled solve).
2. **Band Bessel by upward recurrence** (j_ℓ, y_ℓ from ℓ = 0,1 up; stable here
   since all needed ℓ ≤ 1.06z): validated 1e−221 vs mp.besselj; head-atom values
   by the explicit small-z series (1e−39).

Reproduces every frozen j = 54/140 row to all printed digits, then:

| j | ν^{1/3} | dip of Δ_tot (w at dip) | trough (w) |
|---|---|---|---|
| 54 | 4.76 | +0.636 (−1.76) | — |
| 140 | 6.54 | +0.555 (−1.44) | −0.21 (−2.65) |
| 300 | 8.43 | +0.531 (−1.65) | −0.31 (−2.59) |
| 600 | 10.63 | +0.445 (−1.31) | −0.25 (−2.43) |
| 1200 | 13.39 | +0.389 (−1.35) | −0.33 (−2.53) |

The profile morphs from the transit's AiBi-dip shape toward the (AiBi)′ shape of
the limit law, and ν^{1/3}Δ_head converges to 8π(AiBi)′(w) (window side shown;
extrapolation quality in §0.3).

## 3. The Airy assembly (the limit law, derived)

**F_full collapses.** In the bracket r_{i₂} + xr′_{i₂} the z²j-terms cancel
exactly (wave-identity derivative), leaving

    F_full = −[2/(4j−3)]·z³·j_{2j−1}(z)·[j′_{2j−3}(z) + y_{2j−3}(z)]

(cylindrical orders ν−1/2 and ν−5/2, ν = 2j). Uniform-Airy (J_μ → (2/ν)^{1/3}Ai(ζ),
Y_μ → −(2/ν)^{1/3}Bi(ζ), ζ = w + (μ−ν)δ, δ = 2^{1/3}ν^{−1/3}):

    F_full = (π/2)2^{2/3}ν^{1/3}·Ai(w−δ/2)Bi(w−5δ/2) + π·AiAi′(w) + O(ν^{−1/3})
    f₁ := O(1)-term of F_full = −π[(1/2)Ai′Bi + (5/2)AiBi′] + πAiAi′

With session 5's σ-expansion O(1)-term s₁ = (π/2)[2AiAi′ − AiBi′ + 3Ai′Bi]:
**G_wt := lim ν^{1/3}Δ_weight = f₁ − s₁ = −2π(AiBi)′(w)** (the AiAi′-terms cancel).

**F̃ vs F_full.** The U-form makes each F̃-factor (m+1)·[level] − m·[level−1] with
argument shift −2δ per level: factor differences are +2mδ·(derivative), so

    G_head := lim ν^{1/3}Δ_head = (π/2)2^{2/3}·2^{1/3}·2m·[Ai′Bi + AiBi′] = 2mπ(AiBi)′

(the B̃/B = 1−16/ν factor and the U′-chain-rule terms enter at O(ν^{−2/3}) and
O(ν^{−1/3}) respectively — not in G). Total:

    **G^{(m)}(w) = (2m−2)π·(AiBi)′(w);   drop-4: Δ ≃ 6π(AiBi)′(w)·ν^{−1/3};
    drop-1: G ≡ 0.**

Numeric confirmations (ν^{−1/3}-extrapolation of the j = 600/1200 pair):
G_head(+2.79): −0.456 vs 8π(AiBi)′ = −0.458; G_wt(+0.72): +0.442 vs −2π(AiBi)′ =
+0.445; G_tot(+2.79): −0.339 vs 6π(AiBi)′ = −0.344. Sanity anchors: (AiBi)′(0) = 0
exactly (Wronskian pair), consistent with the small measured |Δ(0)|-transit values;
the transit dip sits at argmin AiBi = −1.7655 while the LIMIT profile peaks where
(AiBi)′ is extremal — the dip location migrates accordingly (visible in §2's table).

## 4. Grades

| claim | grade |
|---|---|
| exact rewrite r̃ = Ār_i + C̄r_{i−1} (rational, 4 poles) | EXACT identity; machine-validated vs frozen engine |
| coefficient limits = Chebyshev U-polynomials in u = (χ−2)/2; atom-set independent; 1/ν first correction | extracted i = 53…599, 5-digit Richardson; m = 1,2,3,4; two atom-subsets at m = 1,2 |
| drop-1 law displayed-algebra derivation (B_{i−1}c_{i−1}/c_i = 1 backbone) | DERIVED (leading order); general-m displayed proof = T2 |
| equilibrated solve kills the 1e190 conditioning; dps 220 to j = 1200 | validated (frozen rows reproduced; recurrence 1e−221; supersedes "~1500 digits" note) |
| Δ decays: dip +0.636 → +0.389 over j = 54 → 1200 | computed, exact chain, M-free |
| G_head = 2mπ(AiBi)′, G_wt = −2π(AiBi)′, G_tot = (2m−2)π(AiBi)′ | DERIVED (uniform-Airy + σ-expansion) + extrapolation-confirmed (0.7–1.5%) |
| drop-1 asymptotically deficiency-free; 5b's j = 54 cancellation = this identity | DERIVED (m = 1 in the law) + the 5b measurement |
| the O(1) universal profile = U₄-root transit (w_root = −0.0648ν^{2/3}) | derived location + full-chain portraits j = 54…1200 |
| j = 140 osc-edge gap = cache finite-M drift | measured (3 M-rungs, drift toward chain values) |
| θ dissolved: gap = (0.191lnM − 0.77)/√M | measured, 11-rung exact ladder, LOO decisive (rel-RMS 0.0002 vs 0.015); analytic (b,a) staged |
| onset = transit-through-threshold, M-free; no sharp universal j* (protocol-dependent, non-monotone d(j)) | computed j = 12…44 exact chain; explains measured M-flatness |
| osc portrait = post-root transit; U-form tracks osc cells | computed j = 140/300/600, w to −8 |

## 5. Corrections and blast radius (record discipline — this note is the dated correction)

1. **Superseded (was v3 content): the "standing deficiency" reading.** Session 5b's
   "the drop-4 convention creates the entire STANDING ν^{1/3}Δ(w) deficiency" and
   "Δ_head is j-stable O(1)" — j-stability was measured j ≤ 140 and is a transit
   property; asymptotically Δ_head = 8π(AiBi)′ν^{−1/3} → 0. Likewise session 4's
   portrait constants read as limits — **Δ(0) = −0.164 ± 0.03 and dip = 0.716
   (ν^{−1/3}-Richardson) are TRANSIT-WINDOW artifacts** (extrapolations taken inside
   the non-asymptotic regime; the true limits are 0). The measured VALUES at each
   (j, M) stand; their ν→∞ reading changes. "Sections asymptotically carry ≈70% of
   the dip" → sections asymptotically carry ALL of it; the deficiency dies as
   ν^{−1/3}·6π(AiBi)′(w−…). Do-not-quote list gains: "Δ(0) = −0.164 as a limit",
   "dip → 0.716", "Δ_head j-stable O(1) asymptotically", "sections lose ≈30% of
   the dip forever".
2. **Λ-layer corollary:** Λ_true = −(2/π)Δ(w−h/2) (session 4, unchanged as an
   identity) now reads: the like-for-like section deficiency at fixed w decays like
   ν^{−1/3} beyond the transit. Session 4's measured Λ-portrait (j ≤ 300, M ≤ 1196)
   is the transit + finite-M window — correct as measured, not a limit law.
3. **LOGM osc-side numbers** (0.4956-plateau, 0.7431-global, delayed M-onset):
   finite-M readings of the post-root transit (T4). The |·|-grade cap-scoping
   conclusions (LEMMA T scope M ≤ 149, v4 hybrid) are UNTOUCHED.
4. **The "~1500 digits at j ≥ 300" caution** (session 5c, task file): superseded by
   the equilibrated solve (item §2.1). Keep the caution ONLY for the unscaled route.
5. **What stands unchanged:** every exact identity of sessions 4–5c (value laws,
   tail-Gram/Sherman–Morrison chain, B̃-ratio, Λ-pinning chain, the convention
   finding, M-saturation law and its derivation), the j = 54/140 validations, the
   peak constant 0.352341123, H-logM refutation, Ψ v2, the v4 hybrid, all |·|-grade
   LOGM content. The 0.3713√M finite-range c₂ stands as finite-range; its gap law
   is now the ½-with-log above.

## 6. What this stages next (T2 refresh)

- **T2 theorem assembly, updated core:** (i′) the U-law with displayed remainder
  (rank-m tail-Gram Vandermonde algebra; the drop-1 case is already displayed);
  (ii) uniform-Airy layers with explicit envelopes (DLMF A₁/B₀ machinery — now
  needed only at O(ν^{−1/3}) relative, since the leading law is the U-form);
  (iii) tail-Gram truncation bound (superexponential — easy); (iv) the exact
  identities (done). Then interval/arb certification at sample (j, n).
- **O(ν^{−2/3})-layer of Δ** (the transit-to-limit corrections) — only if a
  quantitative finite-j certificate is wanted; the exact rational chain already
  computes any (j, n) cheaply.
- **Zone-edge matched asymptotics for (b, a) = (0.191, −0.77)** in the c₂ gap.
- **Errata/delivery:** this note supersedes v3's constants-layer claims ⇒ v4
  re-seal (same folder), delivery note updated; IB sees the correction with the
  package (LEMMA S′ signed-portrait revision of session 4 now composes with this:
  the deficiency is not only two-signed and milder — it is mortal).

---

## 7. SESSION 6b ADDENDUM — the theorem assembly (T2) is drafted, and the U-law has a cleaner equivalent: THE SHIFT LEMMA

See **`THEOREM_delta_display_form.md`** (the assembly document). Headlines:

1. **Shift lemma (the U-law's true face):** r̃_i^{(m)}(x) = (−1)^m·r_{i+m}(x)·
   (1+O(1/ν)) on the band, AND B̃_i = B_{i+m}(1+O(ν⁻²)) — *removing the m largest
   atoms raises the system m degrees.* Validated pointwise (`lambda_shift_lemma_check.py`):
   ratios 0.9873…1.0000 (j = 54 → 600; m = 1, 2, 4); B̃-shift: 0.86490 vs 0.86518
   (j=54), 0.94492 vs 0.94498 (j=140). Equivalent to the U-form via the band
   transfer lemma.
2. **New closed form:** the Jacobi diagonal **A_s = 2/[(4s+1)(4s+5)]** (verified
   3.3e−9, truncation-limited; proof = one routine lattice sum). With
   B_s = [(4s+3)(4s+5)²(4s+7)]^{−1/2}: the (2ν)²-scaled Jacobi operator → the
   Toeplitz row (1,2,1); **the caustic is its spectral edge χ = 4**, u = (χ−2)/2
   the Toeplitz spectral variable — this is where Chebyshev-U comes from.
3. **Proof status (updated session 6d): THE LADDER IS CLOSED.** The shift lemma
   is PROVEN via the horizon route (stage-multiplicativity of M1-HORIZON Thm 3 —
   NEW exact identity det G_j(S∪x) = det G_j(S)·Σ_{s≥j}r̃_s(x)², machine-verified
   1e−42…1e−84 — plus Cauchy–Binet index absorption with a displayed envelope;
   `lambda_shift_proof_check.py`); A_s is proven (Nyquist + Weber–Schafheitlin);
   remaining = verification/polish only (see the THEOREM note's closing list).
4. **Zone-edge law (T5 analytic companion) — b CLOSED (session 6c):**
   **b = 3/(c²u*) = 3/(2u*E″(u*)) = 0.19079075744…** — derived via the
   outer-region law summand = M·Σ_{k≥2}m_k/(x−α)^k (validated 1e−5…7e−4 against
   the exact engine at M = 64000) whose Laurent 1/(u−u*) coefficient is
   −(1/c²)x″/x′(u*) = 3/(c²u*) (lattice x ∝ u^{−2} ⇒ the "3"); left-outer partial
   sum ⇒ κ·½lnM. Effective-b on the ladder: ±8e−4 around the closed form;
   a = −0.770 ± 0.001 with b fixed (closed form of a = inner matching constant,
   staged). Prediction: b is k-independent. `lambda_zone_edge_kappa.py`.

*— Stenberg + Claude, 2026-07-26 (session 6). The four missing atoms turned out to
be playing Chebyshev's tune: one polynomial degree per atom, the band listening at
u = 1. And the dip that looked eternal was a slow chord change — by j a thousand it
is already resolving to the derivative of the melody, at amplitude ν^{−1/3}.
Session 6b's coda: the tune was a transposition all along — cut m strings from the
head and the band simply plays m steps higher.*
