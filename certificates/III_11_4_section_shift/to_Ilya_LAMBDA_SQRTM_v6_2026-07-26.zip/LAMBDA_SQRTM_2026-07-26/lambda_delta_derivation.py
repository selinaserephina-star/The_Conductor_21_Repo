r"""
lambda_delta_derivation.py -- the analytic attack on Delta(w) (T1 final object).

DERIVED (this session, classical uniform Airy asymptotics on the closure form):
with w = 2^{1/3} nu^{-1/3} (nu - z), nu = 2j, orders 2j+1 / 2j-1 / 2j-2 mapping to
Airy-argument shifts (order nu+a -> w + a*delta, delta = 2^{1/3}nu^{-1/3}),
J_{mu}(z) ~ (2/mu)^{1/3} Ai(arg), Y_{mu}(z) ~ -(2/mu)^{1/3} Bi(arg):

  sigma_j(n) = (pi/2) 2^{2/3} nu^{1/3} (AiBi)(w)
             + (pi/2) [ 2 Ai Ai' - Ai Bi' + 3 Ai' Bi ](w)  +  O(nu^{-1/3}).

Consequences (the derivation's structure):
  Delta(w) = f(w) - (pi/2) 2^{2/3} (AiBi)(w) - nu^{-1/3} s1(w) + ...,
  f(w) := F_j / nu^{1/3}  (the SECTION side -- smooth ramp, exact from caches).
The ENTIRE oscillation of Delta (dip location/depth) is the -(pi/2)2^{2/3}AiBi
term; only the smooth f(w) remains to derive.

Tests here:
 [A] sigma formula vs the exact Bessel engine at j = 54/140/300, band sites:
     residual after leading term ~ O(1)?; after s1 ~ O(nu^{-1/3})? (print scaled)
 [B] f_meas(j, w) = F/nu^{1/3} from the N1200 cache, j = 29..300: universality
     + smoothness + Richardson limit f0(w) on a common w grid.
 [C] dip prediction: w_dip = argmin over the flank of (AiBi) (with f' correction
     estimate) vs the measured Delta dip at w ~ -1.8; Delta(0) = f0(0) - 0.5443.
 [D] candidate fits for f0(w): const / linear / a + b*w + c*w^2 (report rms).
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (session 5: Delta derivation).
"""
import os, math
import numpy as np
import mpmath as mp

mp.mp.dps = 40
PI = mp.pi
HERE = os.path.dirname(os.path.abspath(__file__))
LOGM = os.path.join(HERE, '..', 'LOGM_DEPTH_2026-07-26')
C13, C23 = 2**(1/3), 2**(2/3)

# ---- exact sigma engine (verbatim) ----
_DF = {}
def dfact(l):
    if l not in _DF:
        v = mp.mpf(1)
        for i in range(3, 2*l+2, 2):
            v *= i
        _DF[l] = v
    return _DF[l]

def j_series(l, z):
    guard = int(0.44*float(z)) + 30
    with mp.workdps(mp.mp.dps + guard):
        zz = mp.mpf(z); z2 = zz*zz/2
        t = mp.mpf(1); s = mp.mpf(1); k = 0
        thr = mp.mpf(10)**(-(mp.mp.dps+10))
        while True:
            k += 1
            t *= -z2/(k*(2*l+1+2*k))
            s += t
            if abs(t) < thr*(abs(s)+1) and 2*k > float(z):
                break
        val = s*zz**l/dfact(l)
    return +val

def rows(z, Lmax, jorders):
    with mp.workdps(80):
        zz = mp.mpf(z)
        y = [-mp.cos(zz)/zz, -mp.cos(zz)/zz**2 - mp.sin(zz)/zz]
        for l in range(1, Lmax):
            y.append((2*l+1)/zz*y[-1] - y[-2])
        Lup = min(Lmax, int(float(z)) - 3)
        jup = None
        if any(l <= Lup for l in jorders):
            jup = [mp.sin(zz)/zz, mp.sin(zz)/zz**2 - mp.cos(zz)/zz]
            for l in range(1, Lup):
                jup.append((2*l+1)/zz*jup[-1] - jup[-2])
    jv = {}
    for l in jorders:
        if jup is not None and l <= Lup:
            jv[l] = +jup[l]
        elif z < l:
            jv[l] = j_series(l, z)
        else:
            with mp.workdps(60):
                v = mp.sqrt(PI/(2*z))*mp.besselj(mp.mpf(l)+mp.mpf(1)/2, z)
            jv[l] = +v
    return jv, y

def sigma_exact(j, n):
    z = (2*n-1)*PI/2
    Ls = sorted({2*j-2, 2*j-1, 2*j+1})
    jv, y = rows(z, 2*j+2, Ls)
    return float((mp.mpf(2)/(4*j+1))*z**2*jv[2*j+1]*(
        2*(j-1)*jv[2*j-1] - z*(jv[2*j-2] + y[2*j-1])))

def airy_all(w):
    ai = float(mp.airyai(w)); aip = float(mp.airyai(w, 1))
    bi = float(mp.airybi(w)); bip = float(mp.airybi(w, 1))
    return ai, aip, bi, bip

def s0(w):
    ai, aip, bi, bip = airy_all(w)
    return (math.pi/2)*C23*ai*bi

def s1(w):
    ai, aip, bi, bip = airy_all(w)
    return (math.pi/2)*(2*ai*aip - ai*bip + 3*aip*bi)

def wof(j, n):
    nu = 2.0*j
    return C13*nu**(-1/3)*(nu - (n-0.5)*math.pi)

print("== [A] sigma Airy formula vs exact engine ==")
print("    j     w      sig_exact   lead=nu^(1/3)s0   (ex-lead)   s1(w)   (ex-lead-s1)*nu^(1/3)")
for j in (54, 140, 300):
    nu = 2.0*j; n13 = nu**(1/3)
    nlo = int((nu - 2.5*n13/C13)/math.pi + 0.5)
    nhi = int((nu + 2.5*n13/C13)/math.pi + 0.5)
    worst1 = worst2 = 0.0
    for n in range(nlo, nhi+1):
        w = wof(j, n)
        se = sigma_exact(j, n)
        lead = n13*s0(w)
        r1 = se - lead
        r2 = r1 - s1(w)
        worst1 = max(worst1, abs(r1)); worst2 = max(worst2, abs(r2))
        if n % 2 == 0 or abs(w) < 0.6:
            print(f"  {j:>4} {w:+5.2f}  {se:+10.4f}  {lead:+10.4f}  {r1:+8.4f}  "
                  f"{s1(w):+8.4f}  {r2*n13:+8.4f}")
    print(f"   -> j={j}: max|ex-lead| = {worst1:.4f} (O(1) check);  "
          f"max|ex-lead-s1|*nu^(1/3) = {worst2*n13:.4f} (O(1) if next order nu^-1/3)")

print("\n== [B] f(w) = F_j/nu^{1/3} from the N1200 cache: universality + Richardson ==")
C = np.load(os.path.join(LOGM, 'corr_cache_mirror_k4_N1200.npz'))['C']
def F_col(j, col):
    if col == 0:
        s = C[j:, 0]
    else:
        s = C[j:, col] - C[j:, col-1]
    return -float(s.sum())

try:
    from scipy.interpolate import CubicSpline
    def spline(x, y): return CubicSpline(x, y)
except Exception:
    def spline(x, y): return lambda t: np.interp(t, x, y)

JS = [29, 54, 90, 140, 200, 300]
WGRID = [-2.5, -2.0, -1.5, -1.0, -0.5, 0.0, 0.5, 1.0, 1.5, 2.0]
ftab = {}
for j in JS:
    nu = 2.0*j; n13 = nu**(1/3)
    pts = []
    nlo = int((nu - 3.4*n13/C13)/math.pi + 0.5)
    nhi = int((nu + 3.0*n13/C13)/math.pi + 0.5)
    for n in range(max(5, nlo), nhi+1):
        col = n - 5
        if col >= C.shape[1]:
            break
        pts.append((wof(j, n), F_col(j, col)/n13))
    pts.sort()
    xs = np.array([p[0] for p in pts]); ys = np.array([p[1] for p in pts])
    sp = spline(xs, ys)
    ftab[j] = {wg: float(sp(wg)) for wg in WGRID if xs.min() <= wg <= xs.max()}
print("    w   " + "".join(f"   j={j:<4}" for j in JS) + "   f0 (Richardson)  slope")
F0 = {}
for wg in WGRID:
    vals = [ftab[j].get(wg, float('nan')) for j in JS]
    xs = np.array([(2.0*j)**(-1/3) for j in JS])
    ys = np.array(vals)
    m = ~np.isnan(ys)
    if m.sum() >= 3:
        A = np.vstack([np.ones(m.sum()), xs[m]]).T
        cf, *_ = np.linalg.lstsq(A, ys[m], rcond=None)
        F0[wg] = (cf[0], cf[1])
    row = "".join(f" {v:+7.3f}" if v == v else "    -   " for v in vals)
    ex = f"   {F0[wg][0]:+7.3f}        {F0[wg][1]:+6.2f}" if wg in F0 else ""
    print(f"  {wg:+4.1f}" + row + ex)

print("\n== [C] structure predictions from the derived decomposition ==")
# dip: minimize AiBi on the flank
grid = np.linspace(-3.0, 0.0, 3001)
aibi = np.array([float(mp.airyai(g))*float(mp.airybi(g)) for g in grid])
i0 = int(np.argmin(aibi))
print(f"  argmin AiBi on (-3,0): w = {grid[i0]:+.3f}, AiBi = {aibi[i0]:+.5f}")
print(f"  predicted Delta_dip (f0 flat approx) = f0({grid[i0]:+.2f}) - "
      f"(pi/2)2^(2/3)*AiBi_min")
if -1.5 in F0 or -2.0 in F0:
    f_at = F0.get(-1.5, F0.get(-2.0))[0]
    print(f"    = {f_at:+.3f} - {2.4931*aibi[i0]:+.4f} = "
          f"{f_at - 2.4931*aibi[i0]:+.4f}   (measured dip ~ +0.72 +/- 0.07 @ w ~ -1.8)")
if 0.0 in F0:
    print(f"  Delta(0) = f0(0) - (pi/2)2^(2/3)AiBi(0) = {F0[0.0][0]:+.4f} - 0.5443 = "
          f"{F0[0.0][0]-0.5443:+.4f}   (measured -0.164 +/- 0.03)")

print("\n== [D] candidate forms for f0(w) ==")
ws = np.array(sorted(F0)); f0s = np.array([F0[w][0] for w in ws])
for name, cols in [("const", [np.ones_like(ws)]),
                   ("linear", [np.ones_like(ws), ws]),
                   ("quad", [np.ones_like(ws), ws, ws**2])]:
    A = np.vstack(cols).T
    cf, res, *_ = np.linalg.lstsq(A, f0s, rcond=None)
    fit = A @ cf
    rms = float(np.sqrt(np.mean((f0s - fit)**2)))
    print(f"   {name:<7}: coeffs = {np.round(cf, 4)}   rms = {rms:.4f}")
print("\ndone")
