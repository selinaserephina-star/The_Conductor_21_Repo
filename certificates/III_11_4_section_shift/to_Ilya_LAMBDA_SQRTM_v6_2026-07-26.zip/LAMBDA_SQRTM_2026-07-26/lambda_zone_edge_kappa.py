r"""
lambda_zone_edge_kappa.py -- session 6c: the zone-edge log coefficient DERIVED.

Claim (derivation in THEOREM_delta_display_form.md SZ, updated):
  OUTER-REGION LAW: for u outside the ghat^2 zone, the exact summand collapses to
      summand(u) = M [ m2/(x(u)-alpha)^2 + m3/(x(u)-alpha)^3 + ... ]
  (moment expansion of S2 around alpha; first moment = 0 by alpha's definition;
  the -M term cancels S2's leading M).  With m2 = x'(u*)^2/(c^2 M) and
  x proportional to u^{-2} (so x''/x' = -3/u), the Laurent 1/(u-u*) coefficient is
      kappa = -(1/c^2) x''(u*)/x'(u*) = 3/(c^2 u*),
  and the left-outer partial sum contributes kappa*lnM + O(1) to C, i.e.
      gap(M) = peak(M) - 0.352341123 = [b lnM + a]/sqrt(M),
      b = 3/(c^2 u*) = 3/(2 u* E''(u*))  -- CLOSED FORM.
Checks here:
  [1] b closed form to 12 digits vs the ladder's pairwise effective b and a
      one-parameter refit of a with b FIXED (csv from lambda_theta_refit.py).
  [2] direct outer-summand law: exact engine summand at u = 0.55..0.78 vs the
      two-moment prediction at M = 64000 (mechanism validation).
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (session 6c).
"""
import math, os
import numpy as np
from scipy.special import gammaln, digamma
import mpmath as mp

HERE = os.path.dirname(os.path.abspath(__file__))
CINF = 0.352341123

# ---- closed-form constants ----
mp.mp.dps = 30
ustar = mp.findroot(lambda u: mp.log((1+u)/(1-u)) - 2/u, mp.mpf('0.8335')).real
Epp = 1/(1-ustar) + 1/(1+ustar) + 2/ustar**2
c2 = 2*Epp
b_closed = 3/(c2*ustar)
print(f"u* = {mp.nstr(ustar, 15)}")
print(f"E''(u*) = {mp.nstr(Epp, 15)}   c = {mp.nstr(mp.sqrt(c2), 15)}")
print(f"b = 3/(2 u* E''(u*)) = {mp.nstr(b_closed, 12)}")
bf = float(b_closed)

# ---- [1] ladder comparison ----
csv = os.path.join(HERE, 'lambda_theta_ladder.csv')
rows = [l.split(',') for l in open(csv).read().splitlines()[1:] if l.strip()]
Ms = np.array([int(r[0]) for r in rows], float)
gaps = np.array([float(r[1]) - CINF for r in rows])
D = gaps*np.sqrt(Ms)
print("\n[1] pairwise effective b vs closed form:")
for i in range(len(Ms)-1):
    beff = (D[i+1]-D[i])/math.log(Ms[i+1]/Ms[i])
    print(f"   M {int(Ms[i]):>8} -> {int(Ms[i+1]):>8}: b_eff = {beff:.5f}"
          f"   (closed {bf:.5f})")
print("   a(M) with b FIXED at closed form:")
for i, M in enumerate(Ms):
    print(f"   M={int(M):>8}: a = {D[i] - bf*math.log(M):+.5f}")

# ---- [2] outer-summand mechanism check at M = 64000 ----
M = 64000
k = 4
A = k - 0.5
n = np.arange(1, M + 1, dtype=np.float64)
zn = (n + A) * math.pi
lnz = np.log(zn)
Slnz = lnz.sum()
lnell = (gammaln(n) + gammaln(M - n + 1) + gammaln(M + n + 2*A + 1)
         - gammaln(n + 2*A + 1) - np.log(2*n + 2*A)
         + 2*(M - 1)*math.log(math.pi) - 2*(M - 1)*lnz - 2*(Slnz - lnz))
logG2 = -2.0 * lnell
logG2 -= logG2.max()
G2 = np.exp(logG2)
ghat2 = M * G2 / G2.sum()
x = 1.0 / zn**2
alpha = (x * ghat2).sum() / M
m2 = ((x - alpha)**2 * ghat2).sum() / M
m3 = ((x - alpha)**3 * ghat2).sum() / M
S1 = math.pi**2 * (n + A)**2 * ((M - 1) + ((n + A)/2)*(
    digamma(M - n + 1) - digamma(n) - digamma(M + n + 2*A + 1)
    + digamma(n + 2*A + 1) + 1.0/(2*n + 2*A)))
zi = np.where(ghat2 > 1e-280)[0]
xz = x[zi]; gz = ghat2[zi]
print(f"\n[2] outer-summand law at M = {M} (zone = n {zi[0]+1}..{zi[-1]+1}):")
print("      u      summand_exact     M*m2/(x-a)^2   +m3 term      ratio")
for u0 in (0.55, 0.60, 0.65, 0.70, 0.74, 0.78):
    i0 = int(u0*M) - 1
    d = x[i0] - xz
    S2i = (gz/d).sum()
    sm = ghat2[i0] - M + (x[i0]-alpha)*(ghat2[i0]*S1[i0] + S2i)
    p2 = M*m2/(x[i0]-alpha)**2
    p3 = p2 + M*m3/(x[i0]-alpha)**3
    print(f"   {u0:.2f}  {sm:+15.6f}  {p2:+14.6f}  {p3:+14.6f}   {sm/p3:.6f}")

# Laurent check: kappa from the exact rational function vs 3/(c^2 u*)
xp = -2/(math.pi**2 * 1.0)  # x'(u) up to the common scale; use ratio-free form
us = float(ustar)
kappa_pred = 3.0/(float(c2)*us)
print(f"\n   kappa = 3/(c^2 u*) = {kappa_pred:.6f}  (= b)")
