r"""
lambda_chain_highj.py -- the DECISIVE high-j run for the Delta closeout (T1/T1b).

Question on trial: the U-display form (lambda_display_form.py:
  rt_i -> U_4(u) r_i - U_3(u) r_{i-1},  u = (chi-2)/2, chi = x(2nu)^2)
forces, under uniform-Airy substitution, F~'s nu^{1/3}-leading to EQUAL sigma's
(coefficients (5-4)(5-4) = 1), hence
  Delta(j, w) = nu^{-1/3} G(w) + O(nu^{-2/3}),   G_head = 8 pi (AiBi)'(w),
i.e. the measured O(1) universal profile would be the PRE-ASYMPTOTIC plateau of
the U_4-root transit (root chi = 4cos^2(pi/10) at w_root = -0.0648 nu^{2/3},
inside the band for all j <= 300 measured so far).  This script runs the EXACT
chain (no cache, no Stieltjes) at j = 54, 140, 300, 600, 1200 with
  - equilibrated tail-Gram solve (kills the 1e190 entry-range conditioning)
  - band spherical j/y by upward recurrence (stable here: orders <= 1.06 z)
  - head-atom values by the explicit small-z series (no besselj needed)
and prints Delta_tot, Delta_head, Delta_weight, the U-form Delta, and the
scaled tests nu^{1/3}*Delta_head vs 8 pi (AiBi)'(w).
Frozen-log validation targets: j=54 n=37: Dtot +0.6362, F 1.5185;
j=140 n=92: +0.5552, F 2.3342; n=93 (w=-2.04) chain 0.98 vs cache 1.33.
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (Delta-closeout session).
"""
import math
import mpmath as mp

mp.mp.dps = 220
PI = mp.pi


# ---------- band values: upward recurrence for spherical j, y ----------
def sph_tables(z, Lmax):
    j = [mp.sin(z)/z, mp.sin(z)/z**2 - mp.cos(z)/z]
    y = [-mp.cos(z)/z, -mp.cos(z)/z**2 - mp.sin(z)/z]
    for l in range(1, Lmax):
        j.append((2*l+1)/z*j[l] - j[l-1])
        y.append((2*l+1)/z*y[l] - y[l-1])
    return j, y


# ---------- head values: explicit small-z series ----------
def dfact_log(n):
    # ln n!! for odd n = 2m+1:  (2m+1)!! = 2^{m+1} Gamma(m+3/2)/sqrt(pi)
    m = (n-1)//2
    return (m+1)*mp.log(2) + mp.loggamma(m+mp.mpf(3)/2) - mp.log(PI)/2


def sph_j_small(l, z, terms=24):
    # j_l(z) = z^l/(2l+1)!! * sum_m (-z^2/2)^m / (m! (2l+3)(2l+5)...(2l+2m+1))
    s = mp.mpf(1)
    t = mp.mpf(1)
    for m_ in range(1, terms):
        t *= (-z**2/2) / (m_ * (2*l + 2*m_ + 1))
        s += t
        if abs(t) < mp.mpf(10)**(-mp.mp.dps-5)*abs(s):
            break
    return mp.e**(l*mp.log(z) - dfact_log(2*l+1)) * s


def kap(s):
    return mp.sqrt(2*(mp.mpf(4*s)+3))


def r_head(s, k):
    z = (mp.mpf(2*k)-1)*PI/2
    return kap(s)*(-1)**(k+1)*z**2*sph_j_small(2*s+1, z)


def Bfull(i):
    return 1/mp.sqrt(mp.mpf(4*i-1)*(4*i+1)**2*(4*i+3))


def head_solve_scaled(i, atoms=(1, 2, 3, 4), tail=14):
    na = len(atoms)
    v = [r_head(i, k) for k in atoms]
    s = [abs(r_head(i+1, k)) for k in atoms]
    Tp = mp.zeros(na, na)
    for t in range(i+1, i+1+tail):
        u = [r_head(t, k) for k in atoms]
        for a_ in range(na):
            for b_ in range(na):
                Tp[a_, b_] += (u[a_]/s[a_])*(u[b_]/s[b_])
    vs = mp.matrix([v[k]/s[k] for k in range(na)])
    ws = mp.lu_solve(Tp, vs)
    w = [ws[k]/s[k] for k in range(na)]
    q = sum(v[k]*w[k] for k in range(na))
    a = [w[k]/(1+q) for k in range(na)]
    N = mp.sqrt(1+q)
    return a, N, q


def level_coeffs(i, tail=14):
    """(beta_l, gamma_l, y_l, N) for the exact rational display form."""
    a, N, q = head_solve_scaled(i, tail=tail)
    B = Bfull(i)
    beta, gamma, ys = [], [], []
    for idx, k in enumerate((1, 2, 3, 4)):
        zk = (mp.mpf(2*k)-1)*PI/2
        ys.append(1/zk**2)
        beta.append(B*a[idx]*r_head(i-1, k))
        gamma.append(B*a[idx]*r_head(i, k))
    return beta, gamma, ys, N


def AbarCbar(coeffs, x):
    beta, gamma, ys, N = coeffs
    Abar = N*(1 - sum(b/(yl - x) for b, yl in zip(beta, ys)))
    Cbar = N*sum(g/(yl - x) for g, yl in zip(gamma, ys))
    dAbar = -N*sum(b/(yl - x)**2 for b, yl in zip(beta, ys))
    dCbar = N*sum(g/(yl - x)**2 for g, yl in zip(gamma, ys))
    return Abar, Cbar, dAbar, dCbar


def U_cheb(m, u):
    if m == 0:
        return mp.mpf(1)
    a, b = mp.mpf(1), 2*u
    for _ in range(m-1):
        a, b = b, 2*u*b - a
    return b


def run_j(j, tail=14, wlo=-2.7, whi=2.7):
    nu = mp.mpf(2*j)
    n13 = nu**(mp.mpf(1)/3)
    dlt = 2**(mp.mpf(1)/3)/n13
    i1, i2 = j-1, j-2
    c1 = level_coeffs(i1, tail)
    c2 = level_coeffs(i2, tail)
    N1, N2 = c1[3], c2[3]
    Bt = (N2/N1)*Bfull(i1)
    print(f"\n== j={j}:  B~/B = {mp.nstr(N2/N1, 8)}   "
          f"w_root(U4) = {float(-0.06484*nu**(mp.mpf(2)/3)):+.2f}")
    lo = int(float((nu - (-wlo)*n13/2**(mp.mpf(1)/3))/math.pi + 0.5))
    hi = int(float((nu + whi*n13/2**(mp.mpf(1)/3))/math.pi + 0.5))
    print("    n     w      F~       F_full    sigma    Dtot     Dhead    "
          "Dwt      D_Uform  n13*Dh   8pi(AiBi)'")
    for n in range(max(5, lo), hi+1):
        z = (mp.mpf(2*n)-1)*PI/2
        x = 1/z**2
        w = float(2**(mp.mpf(1)/3)/n13*(nu - z))
        sj, sy = sph_tables(z, 2*j+3)
        sgn = (-1)**(n+1)

        def rb(s):
            return kap(s)*sgn*z**2*sj[2*s+1]

        def rpb(s):
            jp = sj[2*s] - (2*s+2)/z*sj[2*s+1]
            return -(z**3)/2*kap(s)*sgn*(2*z*sj[2*s+1] + z**2*(jp + sy[2*s+1]))

        # exact chain
        A1, C1, dA1, dC1 = AbarCbar(c1, x)
        A2, C2, dA2, dC2 = AbarCbar(c2, x)
        rt1 = A1*rb(i1) + C1*rb(i1-1)
        rt2 = A2*rb(i2) + C2*rb(i2-1)
        drt2 = A2*rpb(i2) + C2*rpb(i2-1) + dA2*rb(i2) + dC2*rb(i2-1)
        Fch = 2*Bt*x*rt1*(rt2 + x*drt2)
        # full system
        B12 = Bfull(i1)
        Ffull = 2*B12*x*rb(i1)*(rb(i2) + x*rpb(i2))
        # sigma closure form
        sg = (mp.mpf(2)/(4*j+1))*z**2*sj[2*j+1]*(
            2*(j-1)*sj[2*j-1] - z*(sj[2*j-2] + sy[2*j-1]))
        # U display form (integer-limit coefficients, exact chi)
        u1 = (x*(2*(2*i1+2))**2 - 2)/2
        u2 = (x*(2*(2*i2+2))**2 - 2)/2
        rtU1 = U_cheb(4, u1)*rb(i1) - U_cheb(3, u1)*rb(i1-1)
        rtU2 = U_cheb(4, u2)*rb(i2) - U_cheb(3, u2)*rb(i2-1)
        dU4 = 0  # x-derivative of U-coeffs enters via chain rule below
        # d/dx of U_m(u(x)): U_m'(u) * (2nu_i)^2/2
        def dU(m, u, nui):
            # derivative of Chebyshev U_m via (m U_{m+1} - (m+2) u U_m)/(2(u^2-1))... use direct
            h = mp.mpf(10)**(-30)
            return (U_cheb(m, u+h) - U_cheb(m, u-h))/(2*h)
        sc2 = (2*(2*i2+2))**2/mp.mpf(2)
        drtU2 = (U_cheb(4, u2)*rpb(i2) - U_cheb(3, u2)*rpb(i2-1)
                 + dU(4, u2, None)*sc2*rb(i2) - dU(3, u2, None)*sc2*rb(i2-1))
        FU = 2*Bt*x*rtU1*(rtU2 + x*drtU2)

        Dtot = (Fch - sg)/n13
        Dhead = (Fch - Ffull)/n13
        Dwt = (Ffull - sg)/n13
        DU = (FU - sg)/n13
        ai, aip = mp.airyai(w), mp.airyai(w, 1)
        bi, bip = mp.airybi(w), mp.airybi(w, 1)
        gh = 8*PI*(aip*bi + ai*bip)
        print(f"  {n:>5} {w:+5.2f}  {float(Fch):+8.4f} {float(Ffull):+8.4f} "
              f"{float(sg):+8.4f} {float(Dtot):+8.4f} {float(Dhead):+8.4f} "
              f"{float(Dwt):+8.4f} {float(DU):+8.4f} {float(n13*Dhead):+8.4f} "
              f"{float(gh):+8.4f}")


def main():
    # recurrence validation: j=54 band value vs direct besselj
    z = (mp.mpf(2*35)-1)*PI/2
    sj, sy = sph_tables(z, 111)
    ref = mp.sqrt(PI/(2*z))*mp.besselj(mp.mpf(107)+mp.mpf(1)/2, z)
    print(f"[val] recurrence j_107(z_35) rel err = "
          f"{mp.nstr(abs(sj[107]-ref)/abs(ref), 3)}")
    refy = mp.sqrt(PI/(2*z))*mp.bessely(mp.mpf(107)+mp.mpf(1)/2, z)
    print(f"[val] recurrence y_107(z_35) rel err = "
          f"{mp.nstr(abs(sy[107]-refy)/abs(refy), 3)}")
    hs = r_head(53, 4)
    href = kap(53)*(-1)**5*((mp.mpf(7))*PI/2)**2 * mp.sqrt(PI/(2*(mp.mpf(7))*PI/2)) \
        * mp.besselj(mp.mpf(107)+mp.mpf(1)/2, (mp.mpf(7))*PI/2)
    print(f"[val] small-z series r_53(y_4) rel err = "
          f"{mp.nstr(abs(hs-href)/abs(href), 3)}")

    for j in (54, 140, 300, 600, 1200):
        run_j(j)


if __name__ == '__main__':
    main()
