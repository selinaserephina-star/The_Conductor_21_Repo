r"""
lambda_shift_lemma_check.py -- T2 core reformulation test (session 6b).

CLAIM A (shift lemma): at band points, the drop-m orthonormal polynomial equals
the FULL system's polynomial m degrees up, to sign:
    rt_i^{drop-m}(x_n) = (-1)^m r_{i+m}(x_n) (1 + O(1/nu)).
This is EQUIVALENT to the Chebyshev display form via the band transfer lemma,
because r_{i+d} satisfies the 3-term recurrence whose (2nu)^2-scaled Jacobi
coefficients tend to the Toeplitz row (1, 2, 1):  chi r_s = r_{s+1} + 2 r_s +
r_{s-1} + O(1/nu), whose m-step solution is R_m = U_m(u)R_0 - U_{m-1}(u)R_{-1},
u = (chi-2)/2.  (Spectral edge chi = 4 <-> the caustic.)

CLAIM B (Jacobi asymptotics): B_s = [(4s+3)(4s+5)^2(4s+7)]^{-1/2} exact (known);
A_s = <x r_s, r_s> satisfies (2nu_s)^2 A_s -> 2.  A_s computed here by exact
lattice summation (value law, superexponentially convergent in n after the band).

Checks: m = 1, 4 at j = 54, 140, 600 across the band; A_s scaling for s up to 599.
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (session 6b, theorem assembly).
"""
import math
import mpmath as mp
from lambda_chain_highj import (level_coeffs, AbarCbar, sph_tables, kap, Bfull,
                                r_head, PI)

mp.mp.dps = 160


def A_diag(s, nmax=None):
    """A_s = sum_n x_n^3 r_s(x_n)^2 (measure weight x^2, plus one x)."""
    # value law r_s(x_n) = kap sgn z^2 j_{2s+1}(z); series converges: sum over n
    # until terms negligible.  Use recurrence tables per n (cheap at these s).
    tot = mp.mpf(0)
    n = 1
    while True:
        z = (mp.mpf(2*n)-1)*PI/2
        if 2*s+1 < 0.9*float(z) and n > (2*s+2)/math.pi + 40*(2*s+2)**(1/3):
            break
        sj, _ = sph_tables(z, 2*s+2)
        r = kap(s)*z**2*sj[2*s+1]
        x = 1/z**2
        tot += x**3 * r**2
        n += 1
    return tot


def main():
    print("[B] Jacobi diagonal scaling  (nu_s := 2s+2):")
    for s in (10, 25, 53, 139, 299):
        A = A_diag(s)
        nu = mp.mpf(2*s+2)
        print(f"   s={s:>4}: (2nu)^2 A_s = {mp.nstr((2*nu)**2*A, 8)}   "
              f"(target 2)")

    print("\n[A] shift lemma: rt_i^(drop-m) vs (-1)^m r_(i+m) at band")
    for (j, m) in ((54, 4), (140, 4), (600, 4), (140, 1), (140, 2)):
        nu = mp.mpf(2*j)
        n13 = nu**(mp.mpf(1)/3)
        C13 = 2**(mp.mpf(1)/3)
        i = j-1
        # drop-m solve at level i
        import lambda_display_form as ldf
        atoms = tuple(range(1, m+1))
        beta, gamma, eps, N, q = ldf.rational_coeffs(i, atoms=atoms, tail=14)
        lo = int(float((nu - 2.4*n13/C13)/math.pi + 0.5))
        hi = int(float((nu + 2.4*n13/C13)/math.pi + 0.5))
        print(f"   j={j}, m={m}:   w    rt_dropm    (-1)^m r_(i+m)   ratio")
        for n in range(max(m+1, lo), hi+1, 2):
            z = (mp.mpf(2*n)-1)*PI/2
            x = 1/z**2
            w = float(C13/n13*(nu - z))
            sj, sy = sph_tables(z, 2*i+2*m+3)
            sgn = (-1)**(n+1)
            rb = lambda s: kap(s)*sgn*z**2*sj[2*s+1]
            Abar = N*(1 - sum(b/((1/ep) - x) for b, ep in zip(beta, eps)))
            Cbar = N*sum(g/((1/ep) - x) for g, ep in zip(gamma, eps))
            rt = Abar*rb(i) + Cbar*rb(i-1)
            tgt = (-1)**m * rb(i+m)
            print(f"      {w:+5.2f}  {float(rt):+12.4f}  {float(tgt):+12.4f}"
                  f"   {float(rt/tgt):+8.4f}")


if __name__ == '__main__':
    main()
