# FINDINGS — Λ(w)/√M derivation, session 1 (mechanism identification): the √M law is a TOP-ROW scaling profile F(u); the band deficiency is the DERIVATIVE PART's smooth background (the section never resolves the caustic structure); naive phase-averaging REFUTED

> **⚠️ CORRECTION (session 2, same day — `FINDINGS_exact_identity_toprow.md` §3).**
> The probe scripts here carry a ±1 site anchor slip and a labeling slip: their
> "s_sec" is the C-summand at site m−1 PLUS q² at site m (a Ka-mixture), not
> ∂α−q² as labeled. In the caustic band q² ≈ 0, so every BAND conclusion below
> stands unchanged (smooth background, no Airy structure at any M, H-AVG refuted);
> osc-side pointwise values are label-shifted by one site (w by ≈ 0.5–0.7). The
> authoritative conventions and the exact per-site object are now fixed by the
> session-2 identity: the C-summand at site σ IS s(j,σ) = F_{j+1}(σ) − F_j(σ).
> Also superseded below: "peak 0.372 stable" — session 2's closed form shows the
> peak drifts (≈ 1/3 + 0.26/ln M asymptotically) and u* → 0.833557 (derived), so
> the 0.372/0.85 numbers are the M ≲ 10³ shelf, not the limit.
>
> **⚠️ SECOND UPDATE (session 3 — `FINDINGS_peak_constant_derived.md`; tag applied by the
> total-corpus audit, same day):** the line above is itself superseded — the asymptotic peak
> constant is DERIVED: **0.352341123** ("1/3" REFUTED; the 1/3 + 0.26/ln M reading was a
> fit artifact of the finite-M window).

**Merkabit · Stenberg + Claude · 2026-07-26 (late) · `LAMBDA_SQRTM_2026-07-26/`**
(opens the derivation program staged in `LOGM_DEPTH_2026-07-26/FINDINGS_LOGM_DEPTH.md`
§6; LOGM_DEPTH is SENT and frozen — this is the continuation folder). Scripts:
`lambda_mechanism_probe.py`, `lambda_confirm_scaling.py`,
`lambda_phase_average_test.py` (+ run logs). Consumes the frozen LOGM caches
(cstep corr matrices) read-only. **Not RH/GRH.**

## 0. Verdict in five lines

1. **The c₂ = 0.3713√M law is a TOP-ROW phenomenon with a scaling profile:** the
   binding row is exactly j = M−1 at every rung, and C(M−1, ⌈uM⌉)/√M collapses to
   a profile F(u) with peak |F| = 0.3694/0.3726/0.3739/0.3730/0.3724/0.3700 at
   u* = 0.875 → 0.842 (M = 56 → 1196) — peak height stable ≈ **0.372**, location
   drifting slowly (possibly → 5/6 or a nearby limit; NOT pinned). Rows M−2, M−3
   form a boundary-layer family (scaled peaks ≈ 0.305, 0.275, M-stable). The √M
   derivation target is now: derive F(u) (one row, one profile), not a sup over
   an M-dependent set.
2. **The caustic-band deficiency mechanism:** the section's per-site summand
   s_sec(j, m) = ∂α_j/∂x_m − q²_{jm} in the band |w| ≲ 1.5 is a SMOOTH negative
   background with NO Airy structure at ANY M (M = 296/596/1196 compared at
   j = 200), while the ∞ summand Δ_jσ oscillates with O(1) amplitude. The
   prefix-sum of the missing structure is the measured Λ. Band q²_{jm} ≈ 0
   (≤ 1e-6) for j ≳ 100 at these M ⇒ **the band background is the derivative part
   ∂α_j/∂x_m ALONE** — the clean analytic target for Λ.
3. **The osc-side delayed onset, mechanically:** past M ≈ 3–6·j the section
   summand REGAINS an oscillation on the osc side (w ≲ −2) — with comparable
   amplitude but SHIFTED PHASE vs Δ_jσ (e.g. at (j=200, m=129): s_inf = −1.25 vs
   s_sec = +1.37 at M=1196) — which is exactly why the osc-side deviation is
   bounded (~0.5ν^{1/3}) but nonzero: coherent mismatch, not absence. The band
   never regains structure; the osc side regains it wrong.
4. **H-AVG refuted:** the natural first guess — s_sec = local phase-average of
   s_inf — FAILS at every averaging width h = 2…5 (mean pointwise error ~0.5,
   sign mismatches in the band; cumulative prediction wrong shape). The section
   summand is not a smoothing of the ∞ summand; it is a different smooth object.
5. **Not OP-magnitude saturation:** max_n|p_{M−1}(x_n)| = 4.0…6.5 across
   M = 96…596 — far below the uniform-weight cap √M — so F(u) is a mass-location
   effect (where the top rows put their q²/Ka weight), not a value blow-up.

## 1. What the derivation program now looks like (staged, next session)

- **Λ(w) route (band):** derive ∂α_j/∂x_n for the uniform-weight mirror section
  at caustic sites — the fixed-weight Jacobi tangent map (inverse-eigenvalue
  derivative: eigenvalues = atoms, first-component weights fixed). In the band
  the q² term is negligible and s_sec is smooth ⇒ a WKB/continuum treatment of
  the tangent map should give the background; then
  Λ(w) = ν^{−1/3}·prefix[Δ_jσ − background] with the Airy cumulative from the
  LEMMA A′ closure form (the a_∞ scale falls out of ∫(AiBi)′ as in the flagship
  derivation — the conjecture Λ(0) → a_∞ = the background's prefix being O(1)).
- **F(u) route (top row):** the top row of an M-atom uniform-weight Jacobi —
  spectral-edge/horizon object; candidate machinery = M1-HORIZON Part II (chirp →
  sine-kernel scaling, our uniform-weight variant of the tail Grams), or a direct
  Christoffel–Darboux computation of Σ_{n≤m}[∂α_{M−1}/∂x_n − q²_{M−1,n}] using
  the exactness of M-point quadrature at the top degree. The measured targets:
  F peak 0.372, u* ≈ 0.85 (slow drift), the u < u* negative lobe (non-collapsed —
  finite-M transient, quantify), layer family 0.372/0.305/0.275.
- Validation data for both: the frozen LOGM caches + `logm_lambda_profile.csv`
  (Λ), this folder's logs (F(u) tables).

## 2. Grades

| claim | grade |
|---|---|
| c₂ binding row = M−1; F(u) collapse, peak 0.372, u* 0.875→0.842 | measured, 6 rungs |
| boundary-layer family (M−2: ≈0.305, M−3: ≈0.275) | measured, 2 rungs each |
| band summand smooth/no Airy structure at any M; q² ≤ 1e-6 there (j ≳ 100) | measured (j = 200 × 3 rungs; j = 54/103 partial-structure cases displayed) |
| osc-side phase-shifted re-oscillation past onset | measured (j = 200, M = 596/1196) |
| H-AVG (s_sec = ⟨s_inf⟩_h) | REFUTED (h = 2…5, two (j, M) cases) |
| band background = derivative part alone | measured implication (q² ≈ 0 there); derivation staged |

*— Stenberg + Claude, 2026-07-26 (late). The boundary's √M law turned out to be one
row's portrait, drawn to scale; and the missing dip is not blur — the section paints
a different, smoother picture at the caustic, and never had the oscillation to lose.
Next session: derive the two portraits.*
