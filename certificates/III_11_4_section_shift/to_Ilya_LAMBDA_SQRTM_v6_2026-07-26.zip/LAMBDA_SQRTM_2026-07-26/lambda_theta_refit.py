r"""
lambda_theta_refit.py -- T5 of the Delta closeout: decisive refit of the peak-gap
exponent theta.  Dense exact Gamma/psi ladder c2(M)/sqrt(M) (engine copied from
lambda_peak_fastM.py, validated there vs the brute engine at 1e4/1e5), then fit
   gap(M) = peak(M) - 0.352341123
against the candidate laws with LOO discipline:
   A: a*lnM/sqrt(M)      B: a/sqrt(M)      C: a/M^theta (free theta)
   D: (a + b*lnM)/sqrt(M)   [the 'theta dissolves into 1/2 with a log' full model]
If A/D beat C cleanly, theta ~ 0.39 is an effective slope of lnM/sqrt(M), not a
new exponent (task file T5; recorded candidate slope -0.42 over M=1e3..1e6).
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (Delta-closeout session).
"""
import math, time, os, sys
import numpy as np
from scipy.special import gammaln, digamma

CINF = 0.352341123
HERE = os.path.dirname(os.path.abspath(__file__))
CSV = os.path.join(HERE, 'lambda_theta_ladder.csv')


def peak_fast(M, k=4):
    A = k - 0.5
    n = np.arange(1, M + 1, dtype=np.float64)
    zn = (n + A) * math.pi
    lnz = np.log(zn)
    Slnz = lnz.sum()
    lnell = (gammaln(n) + gammaln(M - n + 1) + gammaln(M + n + 2*A + 1)
             - gammaln(n + 2*A + 1) - np.log(2*n + 2*A)
             + 2*(M - 1)*math.log(math.pi) - 2*(M - 1)*lnz - 2*(Slnz - lnz))
    logG2 = -2.0 * lnell
    logG2 -= logG2.max()
    G2 = np.exp(logG2)
    ghat2 = M * G2 / G2.sum()
    x = 1.0 / zn**2
    alpha = (x * ghat2).sum() / M
    S1 = math.pi**2 * (n + A)**2 * ((M - 1) + ((n + A)/2)*(
        digamma(M - n + 1) - digamma(n) - digamma(M + n + 2*A + 1)
        + digamma(n + 2*A + 1) + 1.0/(2*n + 2*A)))
    zi = np.where(ghat2 > 1e-280)[0]
    xz = x[zi]; gz = ghat2[zi]
    S2 = np.empty(M)
    CH = max(500, int(4e8 / max(1, len(zi))))
    for lo in range(0, M, CH):
        hi = min(lo + CH, M)
        d = x[lo:hi, None] - xz[None, :]
        with np.errstate(divide='ignore', invalid='ignore'):
            qq = gz[None, :] / d
        qq[np.isinf(qq)] = 0.0
        qq = np.nan_to_num(qq, nan=0.0, posinf=0.0, neginf=0.0)
        S2[lo:hi] = qq.sum(axis=1)
    summand = ghat2 - M + (x - alpha) * (ghat2 * S1 + S2)
    Crow = -(2.0 / M) * np.cumsum(summand)
    F = np.abs(Crow) / math.sqrt(M)
    ia = int(F.argmax())
    return F.max(), (ia + 1) / M


LADDER = [2000, 4000, 8000, 16000, 32000, 64000, 128000, 256000,
          512000, 1024000, 2048000]


def build_ladder():
    done = {}
    if os.path.exists(CSV):
        for line in open(CSV).read().splitlines()[1:]:
            if line.strip():
                m, pk, u = line.split(',')
                done[int(m)] = (float(pk), float(u))
    else:
        with open(CSV, 'w') as f:
            f.write('M,peak,ustar\n')
    for M in LADDER:
        if M in done:
            print(f"M={M:>8}: peak = {done[M][0]:.7f}  (cached)", flush=True)
            continue
        t0 = time.time()
        pk, u = peak_fast(M)
        done[M] = (pk, u)
        with open(CSV, 'a') as f:
            f.write(f"{M},{pk:.9f},{u:.7f}\n")
        print(f"M={M:>8}: peak = {pk:.7f}  u* = {u:.6f}  gap = {pk-CINF:+.6f}"
              f"  [{time.time()-t0:.0f}s]", flush=True)
    return done


def fit_models(Ms, gaps, label):
    Ms = np.array(Ms, float); g = np.array(gaps, float)
    L = np.log(Ms)
    print(f"\n--- fits on {label} ({len(Ms)} pts, M = {int(Ms[0])}..{int(Ms[-1])}) ---")

    def loo(pred_fn):
        errs = []
        for i in range(len(Ms)):
            m = np.ones(len(Ms), bool); m[i] = False
            p = pred_fn(Ms[m], g[m], Ms[~m])
            errs.append((p[0] - g[i]) / g[i])
        return math.sqrt(np.mean(np.square(errs))), np.array(errs)

    # A: a lnM/sqrt(M)
    def fA(Mt, gt, Mo):
        bas = np.log(Mt)/np.sqrt(Mt)
        a = (bas*gt).sum()/(bas*bas).sum()
        return a*np.log(Mo)/np.sqrt(Mo)
    # B: a/sqrt(M)
    def fB(Mt, gt, Mo):
        bas = 1/np.sqrt(Mt)
        a = (bas*gt).sum()/(bas*bas).sum()
        return a/np.sqrt(Mo)
    # C: a M^-theta  (fit in log space)
    def fC(Mt, gt, Mo):
        A_ = np.vstack([np.ones(len(Mt)), -np.log(Mt)]).T
        c, *_ = np.linalg.lstsq(A_, np.log(gt), rcond=None)
        return np.exp(c[0] - c[1]*np.log(Mo))
    # D: (a + b lnM)/sqrt(M)
    def fD(Mt, gt, Mo):
        A_ = np.vstack([np.ones(len(Mt)), np.log(Mt)]).T
        c, *_ = np.linalg.lstsq(A_, gt*np.sqrt(Mt), rcond=None)
        return (c[0] + c[1]*np.log(Mo))/np.sqrt(Mo)

    for nm, fn in (('A: a lnM/sqrt(M)   ', fA), ('B: a/sqrt(M)        ', fB),
                   ('C: a/M^theta       ', fC), ('D: (a+b lnM)/sqrt(M)', fD)):
        r, errs = loo(fn)
        worst = np.abs(errs).max()
        print(f"  {nm}: LOO rel-RMS = {r:.4f}   worst = {worst:.4f}")

    # fitted parameters on the full subset, for the record
    basA = L/np.sqrt(Ms); aA = (basA*g).sum()/(basA*basA).sum()
    Ac = np.vstack([np.ones(len(Ms)), -L]).T
    cC, *_ = np.linalg.lstsq(Ac, np.log(g), rcond=None)
    Ad = np.vstack([np.ones(len(Ms)), L]).T
    cD, *_ = np.linalg.lstsq(Ad, g*np.sqrt(Ms), rcond=None)
    print(f"  params: A a={aA:.4f} | C a={math.exp(cC[0]):.4f} theta={cC[1]:.4f}"
          f" | D a={cD[0]:+.4f} b={cD[1]:+.4f}")
    # pairwise effective slopes for the record
    sl = -(np.diff(np.log(g))/np.diff(L))
    print("  effective theta between rungs:",
          " ".join(f"{s:.3f}" for s in sl))


def main():
    done = build_ladder()
    Ms = sorted(done)
    gaps = [done[M][0] - CINF for M in Ms]
    print("\ngap table:")
    for M, gp in zip(Ms, gaps):
        print(f"  M={M:>8}  gap = {gp:+.6f}  gap*sqrt(M)/lnM = "
              f"{gp*math.sqrt(M)/math.log(M):.4f}  gap*sqrt(M) = {gp*math.sqrt(M):.4f}")
    for mmin in (2000, 16000, 64000):
        sel = [(M, gp) for M, gp in zip(Ms, gaps) if M >= mmin]
        if len(sel) >= 5:
            fit_models([m for m, _ in sel], [gp for _, gp in sel], f"M >= {mmin}")
    print("\nDone.", flush=True)


if __name__ == '__main__':
    main()
