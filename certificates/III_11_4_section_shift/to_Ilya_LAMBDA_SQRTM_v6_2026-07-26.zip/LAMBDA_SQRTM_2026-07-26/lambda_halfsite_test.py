r"""
lambda_halfsite_test.py -- residual anatomy for the like-for-like band law.
[1] r1(w) = Lambda_true + (2/pi)*Delta_mid(w) per site: window side tiny+decaying;
    structured flank residual ~ -0.13 near w ~ -1.2, osc-edge +0.2 near w ~ -2.5.
[2] the half-site test: evaluating Delta at w + s*h (h = site spacing at nu+1,
    s in {-1/2, 0, +1/2}) -- s = -1/2 collapses the flank residual at every j
    => the drift term is the Euler-Maclaurin half-cell term:
       Lambda(w) = -(2/pi) Delta(w - h/2) + O(dec)
                 = -(2/pi) Delta(w) + 2^{1/3} nu^{-1/3} Delta'(w) + O(dec),
    coefficient EXACT (h = 2^{1/3} pi nu^{-1/3}; (2/pi)(h/2) = 2^{1/3} nu^{-1/3}).
Input: lambda_pin_constants.csv (M = 1196 rows). NOT RH/GRH.
-- Stenberg + Claude, 2026-07-26 (JOB 2 step 1c).
"""
import csv, math
import numpy as np
try:
    from scipy.interpolate import CubicSpline
    def spline(x, y): return CubicSpline(x, y)
except Exception:
    def spline(x, y): return lambda t: np.interp(t, x, y)

C13 = 2**(1/3); TWOPI = 2/math.pi
rowsd = {}
with open('lambda_pin_constants.csv') as fh:
    for r in csv.DictReader(fh):
        key = (int(r['M']), int(r['j']))
        rowsd.setdefault(key, []).append(
            (int(r['n']), float(r['w']), float(r['Lambda_true']),
             float(r['Delta_j']), float(r['Delta_j1'])))

print("== [1] r1(w) = Lambda_true + (2/pi)*Delta_mid  (M = 1196) ==")
for (M, j) in sorted(rowsd):
    if M != 1196:
        continue
    data = sorted(rowsd[(M, j)], key=lambda d: -d[1])
    nu = 2.0*j
    line, inner = [], []
    for n, w, lam, dj, dj1 in data:
        r1 = lam + TWOPI*0.5*(dj + dj1)
        line.append(f"{w:+5.2f}:{r1:+7.4f}")
        if abs(w) <= 1.5:
            inner.append(abs(r1))
    print(f" j={j:>3}: max|r1| (|w|<=1.5) = {max(inner):.4f}")
    print("   " + "  ".join(line))

print("\n== [2] half-site test: r1(s) with Delta_mid at w + s*h ==")
print("  (max|r1| over flank w in (-1.8,-0.4); window w in (-0.3,+2.2))")
for (M, j) in sorted(rowsd):
    if M != 1196:
        continue
    data = sorted(rowsd[(M, j)], key=lambda d: d[1])
    nu = 2.0*j
    h = C13*math.pi*(nu+1)**(-1/3)
    ws   = np.array([d[1] for d in data])
    lam  = np.array([d[2] for d in data])
    dmid = np.array([0.5*(d[3]+d[4]) for d in data])
    wmid = np.array([C13*(nu+1)**(-1/3)*((nu+1)-(d[0]-0.5)*math.pi) for d in data])
    o = np.argsort(wmid)
    sp = spline(wmid[o], dmid[o]); lo, hi = wmid[o][0], wmid[o][-1]
    out = []
    for s in (-0.5, 0.0, +0.5):
        flank, win = [], []
        for i in range(len(ws)):
            r1 = lam[i] + TWOPI*float(sp(np.clip(wmid[i] + s*h, lo, hi)))
            if -1.8 < ws[i] < -0.4:
                flank.append(abs(r1))
            if -0.3 < ws[i] < 2.2:
                win.append(abs(r1))
        out.append((s, max(flank), max(win)))
    print(f" j={j:>3}: " + "   ".join(f"s={s:+.1f}: flank {f:.4f} win {w:.4f}"
                                      for s, f, w in out))
print("\ndone")
