r"""
lambda_band_deficiency.py -- T1 attack via the telescoped F_j: since F_M = 0 and
s(j,n) = F_{j+1} - F_j (the exact identity), the finite-section sigma is
    F_j(n) = - sum_{i=j}^{M-1} s(i, n)   [s(i,n) = C[i,n-1] - C[i,n-2], 0-based]
-- exact from the cstep caches, NO polynomial evaluation. The infinity sigma_j(n)
(Bessel closure form) also vanishes as j -> inf (evanescent), so
    D_j(n) = F_j(n) - sigma_j(n)
is the per-site deficiency, convention-free. The caustic-band law is then
Lambda nu^{1/3} = Delta_j [prefix of D]. This script maps D:
 [1] D_j(n) across the window w in (-8, +3) for j = 54,103,200 at M = 296/596/1196
     (M-saturation at the F-level?); j = 300,400 at M = 1196.
 [2] scaling: D vs nu^{1/3}*shape(w)? print D/nu^{1/3} columns for universality.
 [3] smoothness: is D free of the Airy oscillation (the section's F is smooth,
     sigma oscillates => D should carry the FULL oscillation of -sigma in the band
     + smooth part)? Establish which decomposition is clean.
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (session 3b).
"""
import os, math
import numpy as np
import mpmath as mp

mp.mp.dps = 40
PI = mp.pi
HERE = os.path.dirname(os.path.abspath(__file__))
LOGM = os.path.join(HERE, '..', 'LOGM_DEPTH_2026-07-26')
C13 = 2**(1/3)

_DF = {}
def dfact(l):
    if l not in _DF:
        v = mp.mpf(1)
        for i in range(3, 2*l+2, 2):
            v *= i
        _DF[l] = v
    return _DF[l]

def j_series(l, z):
    guard = int(0.44*float(z)) + 30
    with mp.workdps(mp.mp.dps + guard):
        zz = mp.mpf(z); z2 = zz*zz/2
        t = mp.mpf(1); s = mp.mpf(1); k = 0
        thr = mp.mpf(10)**(-(mp.mp.dps+10))
        while True:
            k += 1
            t *= -z2/(k*(2*l+1+2*k))
            s += t
            if abs(t) < thr*(abs(s)+1) and 2*k > float(z):
                break
        val = s*zz**l/dfact(l)
    return +val

def bessel_rows(z, Lmax, jorders):
    with mp.workdps(80):
        zz = mp.mpf(z)
        y = [-mp.cos(zz)/zz, -mp.cos(zz)/zz**2 - mp.sin(zz)/zz]
        for l in range(1, Lmax):
            y.append((2*l+1)/zz*y[-1] - y[-2])
        Lup = min(Lmax, int(float(z)) - 3)
        jup = None
        if any(l <= Lup for l in jorders):
            jup = [mp.sin(zz)/zz, mp.sin(zz)/zz**2 - mp.cos(zz)/zz]
            for l in range(1, Lup):
                jup.append((2*l+1)/zz*jup[-1] - jup[-2])
    jv = {}
    for l in jorders:
        if jup is not None and l <= Lup:
            jv[l] = +jup[l]
        elif z < l:
            jv[l] = j_series(l, z)
        else:
            with mp.workdps(60):
                v = mp.sqrt(PI/(2*z))*mp.besselj(mp.mpf(l)+mp.mpf(1)/2, z)
            jv[l] = +v
    return jv, y

def sigma(j, n):
    z = (2*n-1)*PI/2
    Ls = sorted({2*j-2, 2*j-1, 2*j+1})
    jv, y = bessel_rows(z, 2*j+2, Ls)
    return float((mp.mpf(2)/(4*j+1))*z**2*jv[2*j+1]*(
        2*(j-1)*jv[2*j-1] - z*(jv[2*j-2] + y[2*j-1])))

def F_from_cache(C, j, col):
    """F_j at 0-based column col: -sum_{i=j}^{M-1} (C[i,col]-C[i,col-1])."""
    M = C.shape[0]
    if col == 0:
        s = C[j:M, 0]
    else:
        s = C[j:M, col] - C[j:M, col-1]
    return -float(s.sum())

CASES = [(300, [54, 103, 200]), (600, [54, 103, 200]), (1200, [54, 103, 200, 300, 400])]
for N, js in CASES:
    C = np.load(os.path.join(LOGM, f'corr_cache_mirror_k4_N{N}.npz'))['C']
    M = C.shape[0]
    for j in js:
        nu = 2.0*j
        n13 = nu**(1/3)
        mstar = 2*j/math.pi
        out = []
        for m in range(max(2, int(mstar-2.4*n13)), min(M, int(mstar+1.4*n13))+1):
            w = C13*n13**(-1)*(nu - (m+4-0.5)*math.pi)*n13*n13/nu*nu/n13/n13  # recompute cleanly below
            w = C13/n13*(nu - (m+4-0.5)*math.pi)
            if w < -8 or w > 3:
                continue
            Fj = F_from_cache(C, j, m-1)     # site m = 0-based col m-1
            sg = sigma(j, m+4)               # lattice site n = m+k
            out.append((m, w, Fj, sg, Fj-sg))
        print(f"== M={M} j={j} (nu^(1/3) = {n13:.2f}) ==")
        print("    m     w      F_j        sigma_j     D=F-sigma   D/nu^(1/3)")
        for m, w, Fj, sg, D in out:
            print(f"  {m:>4} {w:+5.2f}  {Fj:+9.4f}  {sg:+9.4f}  {D:+9.4f}  {D/n13:+8.4f}",
                  flush=True)
