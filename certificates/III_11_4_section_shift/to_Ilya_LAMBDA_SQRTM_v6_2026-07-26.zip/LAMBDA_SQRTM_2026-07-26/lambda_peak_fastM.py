r"""
lambda_peak_fastM.py -- closed-form O(M)-ish engine for the top-row peak at huge M
(replaces the O(M^2) brute pairwise sums; AWS unnecessary).
Exact ingredients on the mirror lattice (A = k - 1/2, z_n = (n+A)pi local index):
  ln|ell'(x_n)| = lgamma(n) + lgamma(M-n+1) + lgamma(M+n+2A+1) - lgamma(n+2A+1)
                  - ln(2n+2A) + 2(M-1) ln pi - 2(M-1) ln z_n - 2 sum_{m!=n} ln z_m
  S1_n = pi^2 (n+A)^2 [ (M-1) + ((n+A)/2)( psi(M-n+1) - psi(n)
           - psi(M+n+2A+1) + psi(n+2A+1) + 1/(2n+2A) ) ]        [EXACT digammas]
  S2_n = sum over the ghat^2 zone only (Gaussian tail < 1e-300 outside).
Validation: peaks at M = 1e4 / 1e5 vs brute engine (0.362264 / 0.356852).
Then M = 3e5, 1e6, 3e6, 1e7. Registered predictions (peak = 0.352341 + 0.215/M^{1/3}):
  3e5: 0.35556   1e6: 0.35449   3e6: 0.35383   1e7: 0.35334
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (session 3).
"""
import math, time
import numpy as np
from scipy.special import gammaln, digamma

def peak_fast(M, k=4):
    A = k - 0.5
    n = np.arange(1, M + 1, dtype=np.float64)
    zn = (n + A) * math.pi
    lnz = np.log(zn)
    Slnz = lnz.sum()
    lnell = (gammaln(n) + gammaln(M - n + 1) + gammaln(M + n + 2*A + 1)
             - gammaln(n + 2*A + 1) - np.log(2*n + 2*A)
             + 2*(M - 1)*math.log(math.pi) - 2*(M - 1)*lnz - 2*(Slnz - lnz))
    logG2 = -2.0 * lnell
    logG2 -= logG2.max()
    G2 = np.exp(logG2)
    ghat2 = M * G2 / G2.sum()
    x = 1.0 / zn**2
    alpha = (x * ghat2).sum() / M
    S1 = math.pi**2 * (n + A)**2 * ((M - 1) + ((n + A)/2)*(
        digamma(M - n + 1) - digamma(n) - digamma(M + n + 2*A + 1)
        + digamma(n + 2*A + 1) + 1.0/(2*n + 2*A)))
    # S2: zone truncation
    zi = np.where(ghat2 > 1e-280)[0]
    xz = x[zi]; gz = ghat2[zi]
    S2 = np.empty(M)
    CH = 4000
    for lo in range(0, M, CH):
        hi = min(lo + CH, M)
        d = x[lo:hi, None] - xz[None, :]
        # exclude self-terms: where d == 0
        with np.errstate(divide='ignore', invalid='ignore'):
            q = gz[None, :] / d
        q[np.isinf(q)] = 0.0
        q = np.nan_to_num(q, nan=0.0, posinf=0.0, neginf=0.0)
        S2[lo:hi] = q.sum(axis=1)
    summand = ghat2 - M + (x - alpha) * (ghat2 * S1 + S2)
    Crow = -(2.0 / M) * np.cumsum(summand)
    F = np.abs(Crow) / math.sqrt(M)
    ia = int(F.argmax())
    return F.max(), (ia + 1) / M

for M in (10000, 100000, 300000, 1000000, 3000000, 10000000):
    t0 = time.time()
    pk, upk = peak_fast(M)
    pred = 0.352341 + 0.215 / M**(1/3)
    print(f"M={M:>9}: peak = {pk:.6f}  u* = {upk:.6f}  "
          f"[pred {pred:.5f}]  [{time.time()-t0:.0f}s]", flush=True)
