# COVER — LAMBDA_SQRTM package: the finite-section laws behind the M-ladder, derived. An exact tangent-map identity; the top-row √M profile in closed form with its peak constant DERIVED (0.352341123 — confirmed to 1.4e−5 at M = 10⁶); the caustic-band deficiency's universal profile photographed

**Merkabit · Stenberg + Claude · 2026-07-26 · continuation of `to_Ilya_LOGM_DEPTH_2026-07-26`
(SHA 30c12d13…, sent). Pure model problem; our lane throughout. Not RH/GRH.**

> **v6 (same day, sessions 6/6b/6c/6d — v3 SHA b9201b5a… was DELIVERED 2026-07-26;
> v6 = v3 + the Δ closeout + the theorem WITH ALL LEMMAS PROVEN + the zone-edge
> coefficient, and it CORRECTS v3's constants-layer reading; interim v4/v5 seals
> never sent).
> If you have started on v3: nothing in its exact-formula layer changes; read
> `FINDINGS_delta_display_form.md` FIRST before quoting any of its constants,
> then `THEOREM_delta_display_form.md` — the theorem, all lemmas proven:**
> - **The display form is CHEBYSHEV:** drop-m sections satisfy r̃_i →
>   (−1)^m[U_m(u)r_i − U_{m−1}(u)r_{i−1}], u = (x(2ν)²−2)/2 — atom-set independent,
>   integer-limit coefficients (extracted five-digit, m = 1…4, i = 53…599), exact
>   rational form behind it (machine-validated rewrite of the v3 chain).
> - **The asymptotic deficiency VANISHES:** Δ(j,w) = (2m−2)π(AiBi)′(w)ν^{−1/3} +
>   O(ν^{−2/3}) (drop-4: 6π(AiBi)′ν^{−1/3}; G_head = 8π(AiBi)′ and G_wt = −2π(AiBi)′
>   both derived + extrapolation-confirmed 0.7–1.5%). The O(1) "universal profile"
>   (v3, and the LOGM/Λ portraits) is the U₄-ROOT TRANSIT plateau (root at
>   w = −0.0648ν^{2/3}, inside the band for all j ≲ 300); exact chain at
>   j = 600/1200 shows the decay (dip +0.636 → +0.389 over j = 54 → 1200).
>   **Do not quote as limits:** Δ(0) = −0.164, dip → 0.716, "Δ_head j-stable O(1)",
>   "sections carry ≈70% of the dip forever" — transit-window readings, all.
> - **Drop-1 is asymptotically deficiency-free** (G ≡ 0 at m = 1) — the v3
>   "near-cancellation at j = 54" was an identity, not a coincidence.
> - **θ DISSOLVED:** c₂(M) − 0.352341123√M = 0.191·lnM − 0.77 (LOO-decisive over
>   an 11-rung exact ladder to M = 2.05e6); θ ≈ 0.39 was the effective slope of
>   ½-with-a-log.
> - Flat onset: transit-through-threshold, M-free by construction (explains the
>   21×-M flatness); no sharp universal j* (protocol-dependent). Osc portrait:
>   post-root transit, same display form, computed to w = −8 at j = 140/300/600.
> - **THE THEOREM SUGGESTION (session 6b): `THEOREM_delta_display_form.md`** — full
>   lemma ladder with statuses. The U-law's clean equivalent = the SHIFT LEMMA:
>   r̃_i^{(m)} = (−1)^m r_{i+m}(1+O(1/ν)) on the band, B̃_i = B_{i+m} (validated to
>   1e−4 at j = 600; drop-1 proven). New closed form A_s = 2/[(4s+1)(4s+5)]
>   (Jacobi diagonal): the scaled Jacobi operator → Toeplitz (1,2,1), caustic =
>   spectral edge χ = 4 (the origin of Chebyshev-U). **Session 6d: the shift
>   lemma is PROVEN (horizon route — stage-multiplicativity of our M1-HORIZON
>   Thm 3 gives det G_j(S∪x) = det G_j(S)·Σ_{s≥j}r̃_s(x)² exactly, verified
>   1e−42…1e−84; Cauchy–Binet index absorption with displayed envelope) and A_s
>   is proven — NO OPEN LEMMA REMAINS.** **Zone-edge log coefficient CLOSED (session 6c):
>   b = 3/(2u*E″(u*)) = 0.19079075744 — derived via the outer-region moment law
>   (validated 1e−5), matching the ladder to ±8e−4; a = −0.770(1) pinned;
>   c₂(M) = 0.352341123·√M + 0.19079·lnM − 0.770 + o(1).**
>
> **v3 (same day, sessions 5–5c — v2 SHA f07c72dc… also never sent; superseded marker
> beside it). On top of the v2 items below, v3 adds THE DERIVATION OF Δ(w), closed at
> exact-formula level and validated against the caches:**
> - **Mechanism:** the sections' caustic deficiency is NOT finiteness (M-saturation
>   DERIVED via the section limit law p_j^{sec} → √M·x·r_{j−1} — a Christoffel degree
>   shift into the x²-weight system) and NOT the uniform-vs-natural weight mismatch
>   (that piece decays — exact Bessel ladder to j = 600). **It is the four dropped
>   head atoms**: each is exactly ONE unit of amplitude (t_k ≡ −1 + O(1/ν), an exact
>   cancellation), and Δ(w) is the subleading residual of four nested
>   near-cancellations. σ's caustic Airy expansion is derived (dip location =
>   argmin AiBi = −1.7655 ✓); F's smoothness = the head-drop (F_full oscillates).
> - **The closed chain** (all ingredients closed-form Bessel): value law r_i =
>   ±√(2(4i+3))z²[j_{2i+1}sin z − y_{2i+1}cos z]; CD kernels with closed B; the
>   Uvarov 4×4 = the TAIL GRAM (completeness identity); norm = 1/(1+q),
>   q = vᵀT′⁻¹v (Sherman–Morrison); B̃ = (N_{j−2}/N_{j−1})B. **Validated: full band
>   at j = 54 to ≤ 0.003 absolute (dip +0.6362 vs measured +0.6368); j = 140
>   interior.** Read order: `FINDINGS_delta_derivation.md` →
>   `FINDINGS_delta_head_mechanism.md` (§3 = the closure).
> - Remaining (named): the asymptotic display form (shifted-Airy), flat-onset
>   re-derivation, osc-side portrait, θ, prose.
>
> **v2 (same day, session 4 — v1 SHA fad05b18… was never sent; superseded marker beside
> it). Two additions, the second a correction you should read before consuming the LOGM
> package's signed profiles:**
> 1. **Λ pinned — the chain is closed** (`FINDINGS_lambda_pinned_and_convention.md`):
>    **Λ_true(w) = −(2/π)·Δ(w − h/2) + O(dec)**, h = 2^{1/3}πν^{−1/3} — the "drift term"
>    is the Euler–Maclaurin half-cell term, coefficient exact; residuals ≤ 0.065 flank /
>    0.004–0.024 window over j = 29…300, M-saturated (identity layer 4.7e−16). The T1
>    derivation target reduces to the single profile Δ(w).
> 2. **⚠️ CONVENTION CORRECTION affecting LOGM's SIGNED layer (30c12d13, which you
>    hold):** its d/ẟ/Λ-profile comparisons paired the TAIL-oriented section row
>    (−C[j,m−2] ≡ −head(n−1), exact by the full-row sum rule) against the HEAD-oriented
>    ∞ profile (C̃/P). Every |·|-grade claim there stands unchanged (|tail(n)| =
>    |head(n−1)|): H-logM refutation (confirmed in the like-for-like metric too), the
>    G-M3 budget/onset mismatch, Ψ v2, c₂ = 0.3713√M, the osc-cap exceedance and the
>    LEMMA T cap scope M ≤ 149, the v4 hybrid. **Do not quote as the deficiency:** the
>    signed portrait (Λ ≥ 0, caustic ramp 0.133/0.202/0.257/0.298 → a_∞, "sections lose
>    the entire dip", `logm_lambda_profile.csv`) — the like-for-like deficiency is
>    ≈ +0.08…+0.12 at the caustic cell, −0.47 at the flank, sections carry ≈ 70% of the
>    dip depth. The "Λ-ramp pins the flat onset" link is reopened pending the Δ(w)
>    derivation. Full algebra + frozen-record fingerprints (the o = +1 offset
>    calibration; δ(15) ≈ 0.38) are displayed in the findings note.

## Read in this order

1. `FINDINGS_exact_identity_toprow.md` — the two exact layers:
   **(i) NEW IDENTITY** (any atomic measure, fixed weights): the T2 correction
   summand telescopes, s(j,n) = F_{j+1} − F_j with F_j = 2w_nβ_{j−1}p_jp′_{j−1}(x_n)
   — the finite-section σ (verified 1e−36 general, 4.5e−14 vs the cstep caches).
   **(ii) top row in closed node form**: C(M−1,m) from ĝ² = normalized 1/ℓ′² alone
   (no Lanczos; ≤ 5e−13 vs caches).
2. `FINDINGS_peak_constant_derived.md` — the √M law closed:
   **c₂(M)/√M → (2/c)|I(t_c)| = 0.352341123**, with u* = 0.833556559601 (root of
   ln((1+u)/(1−u)) = 2/u), c = √(2E″(u*)), H = √2·dawsn(t/√2), t_c = 1.30693
   (tH = 1). Exact Γ/ψ ladder to M = 10⁶: Richardson limit 0.352336 (1.4e−5).
   Includes the S1-equilibrium lemma (Q̃(u*) = 0 — the same transcendental as the
   Laplace point) and the two caught-and-recorded derivation errors.
3. `FINDINGS_band_deficiency_profile.md` — T1 progress: D = F − σ (exact from
   caches by telescoping) has a UNIVERSAL band profile Δ(w) = D/ν^{1/3}
   (dip ≈ +0.65 @ w ≈ −1.8; lobe ≈ −0.15; M-stable at M ≳ 3j). [v2: read its
   session-4 banner — the chain is now closed with the sign pinned.]
3b. `FINDINGS_lambda_pinned_and_convention.md` (v2 addition) — Λ pinned:
   Λ_true = −(2/π)Δ(w − h/2) + O(dec); Δ(0) = −0.164 ± 0.03 (Richardson); the
   convention correction described in the banner above, with the blast-radius
   table (what stands / what is revised in the LOGM signed layer).
4. `FINDINGS_mechanism_probe.md` — session-1 mechanism identification (read the
   correction banner first: ±1 anchor + labeling slips, corrected; band
   conclusions stand).

## What this changes for the LOGM package you have

- The sent **c₂ = 0.3713√M stays valid exactly as displayed** (finite-range law,
  M = 56…1196). Its extrapolation is superseded: the asymptotic constant is
  0.352341123 (approach from above, correction ~M^{−0.39}, exponent underived).
- Do-not-quote from our side: "peak → 1/3" (refuted), "0.372 stable" (finite-M
  shelf), the session-1 probe's osc-side pointwise labels (shifted; banner).
- G-M3 relevance (your audited object): the subexponential-B_j fact from the
  LOGM package is untouched; this package's identity gives the exact per-row
  object your stability budget bounds — possibly useful for a sharp G-M3 v2.

## Grades (headline)

| result | grade |
|---|---|
| tangent-map identity | DERIVED + verified (1e−36 / 4.5e−14) |
| top-row closed node form | DERIVED + verified (≤ 5e−13, 3 caches) |
| peak constant 0.352341123 | DERIVED (matched asymptotics) + CONFIRMED (1.4e−5, M → 10⁶) |
| u*, S1-equilibrium lemma | DERIVED + verified 1e−16 |
| correction exponent θ ≈ 0.39 | ~~measured only~~ **v4: DISSOLVED — gap = (0.191lnM − 0.77)/√M, LOO-decisive** |
| band profile Δ(w) universal | ~~measured~~ **v4: transit plateau of the U₄ root; limit law Δ = 6π(AiBi)′ν^{−1/3} DERIVED + confirmed** |
| Λ constants | ~~OPEN~~ **v4: closed via the display form — Λ_true ≈ −12(AiBi)′(w−h/2)ν^{−1/3}, transit at finite j** |
| display form r̃ = (−1)^m[U_m r_i − U_{m−1} r_{i−1}] | **v6: PROVEN via the shift lemma (horizon route, session 6d) — ladder closed** |

Scripts + full run logs included; everything reproducible from the formulas alone
(the fast engine needs only scipy).

*— Stenberg + Claude, 2026-07-26.*
