r"""
lambda_dropsplit_ladder.py -- j-scaling of the two Delta pieces (head-drop vs
weight-mismatch) at j = 29, 54, 140, 300.

Split: Delta_meas(w) = [F_drop - F_full]/nu^{1/3} + [F_full - sigma]/nu^{1/3}
                     =  Delta_head(w)            +  Delta_weight(w).
Leading-order Airy says Delta_weight should decay ~ nu^{-1/3} (the nu^{1/3} parts of
F_full and sigma cancel up to shifts); Delta_head should be the O(1) law. Test on a
matched w-grid across the ladder. Streaming Stieltjes (no row storage) for omega
FULL / DROP-4; snapshot rows j-1, j-2 (+derivs) at band atoms for each target j.
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (session 5b).
"""
import os, math, time
import numpy as np
import mpmath as mp

mp.mp.dps = 40
PI = mp.pi
HERE = os.path.dirname(os.path.abspath(__file__))
C13 = 2**(1/3)
NMAX = 2500
DPS = 350
TARGETS = [29, 54, 140, 300]
JT = max(TARGETS)

# ---- sigma engine (verbatim, trimmed) ----
_DF = {}
def dfact(l):
    if l not in _DF:
        v = mp.mpf(1)
        for i in range(3, 2*l+2, 2):
            v *= i
        _DF[l] = v
    return _DF[l]

def j_series(l, z):
    guard = int(0.44*float(z)) + 30
    with mp.workdps(mp.mp.dps + guard):
        zz = mp.mpf(z); z2 = zz*zz/2
        t = mp.mpf(1); s = mp.mpf(1); k = 0
        thr = mp.mpf(10)**(-(mp.mp.dps+10))
        while True:
            k += 1
            t *= -z2/(k*(2*l+1+2*k))
            s += t
            if abs(t) < thr*(abs(s)+1) and 2*k > float(z):
                break
        val = s*zz**l/dfact(l)
    return +val

def rows(z, Lmax, jorders):
    with mp.workdps(80):
        zz = mp.mpf(z)
        y = [-mp.cos(zz)/zz, -mp.cos(zz)/zz**2 - mp.sin(zz)/zz]
        for l in range(1, Lmax):
            y.append((2*l+1)/zz*y[-1] - y[-2])
        Lup = min(Lmax, int(float(z)) - 3)
        jup = None
        if any(l <= Lup for l in jorders):
            jup = [mp.sin(zz)/zz, mp.sin(zz)/zz**2 - mp.cos(zz)/zz]
            for l in range(1, Lup):
                jup.append((2*l+1)/zz*jup[-1] - jup[-2])
    jv = {}
    for l in jorders:
        if jup is not None and l <= Lup:
            jv[l] = +jup[l]
        elif z < l:
            jv[l] = j_series(l, z)
        else:
            with mp.workdps(60):
                v = mp.sqrt(PI/(2*z))*mp.besselj(mp.mpf(l)+mp.mpf(1)/2, z)
            jv[l] = +v
    return jv, y

def sigma_exact(j, n):
    z = (2*n-1)*PI/2
    Ls = sorted({2*j-2, 2*j-1, 2*j+1})
    jv, y = rows(z, 2*j+2, Ls)
    return float((mp.mpf(2)/(4*j+1))*z**2*jv[2*j+1]*(
        2*(j-1)*jv[2*j-1] - z*(jv[2*j-2] + y[2*j-1])))

def band_indices(j, nstart):
    nu = 2.0*j; n13 = nu**(1/3)
    lo = int((nu - 2.6*n13/C13)/math.pi + 0.5)
    hi = int((nu + 2.2*n13/C13)/math.pi + 0.5)
    return [n for n in range(max(nstart, lo), hi+1)]

def stieltjes_stream(nstart, targets):
    """streaming Stieltjes for omega; returns {j: {n: (r_{j-1}, r_{j-2}, dr_{j-2}, x, be_{j-2})}}"""
    z = [(mp.mpf(n) - mp.mpf(1)/2)*mp.pi for n in range(nstart, NMAX+1)]
    x = [1/zz**2 for zz in z]
    w = [xx**2 for xx in x]
    N = len(x)
    want = {}
    for j in targets:
        for n in band_indices(j, nstart):
            want.setdefault(j, []).append(n - nstart)   # 0-based idx
    m0 = mp.fsum(w)
    P0 = [1/mp.sqrt(m0)]*N
    dP0 = [mp.mpf(0)]*N
    al0 = mp.fsum(w[n]*x[n]*P0[n]**2 for n in range(N))
    cur = [(x[n]-al0)*P0[n] for n in range(N)]
    dcur = [P0[n] for n in range(N)]
    prev, dprev = P0, dP0
    out = {}
    snap = {}   # degree -> (vals, dvals) at all idx we might need later
    bes = []
    t0 = time.time()
    for kdeg in range(1, JT+1):
        b = mp.sqrt(mp.fsum(w[n]*cur[n]**2 for n in range(N)))
        bes.append(b)
        cur = [c/b for c in cur]; dcur = [c/b for c in dcur]
        # snapshot rows we need: degree kdeg is now normalized = p_kdeg
        for j in targets:
            if kdeg in (j-2, j-1):
                idxs = want[j]
                snap[(j, kdeg)] = ([cur[i] for i in idxs], [dcur[i] for i in idxs])
        ak = mp.fsum(w[n]*x[n]*cur[n]**2 for n in range(N))
        nxt = [(x[n]-ak)*cur[n] - b*prev[n] for n in range(N)]
        dnxt = [(x[n]-ak)*dcur[n] + cur[n] - b*dprev[n] for n in range(N)]
        prev, dprev = cur, dcur
        cur, dcur = nxt, dnxt
        if kdeg % 50 == 0:
            print(f"      degree {kdeg}/{JT} ({time.time()-t0:.0f}s)", flush=True)
    for j in targets:
        vals1, _ = snap[(j, j-1)]
        vals2, dvals2 = snap[(j, j-2)]
        idxs = want[j]
        out[j] = {}
        for k, i in enumerate(idxs):
            out[j][i + nstart] = (vals1[k], vals2[k], dvals2[k], x[i], bes[j-2-1] if False else None)
    return out, bes, x

def main():
    with mp.workdps(DPS):
        print("[stieltjes] FULL (streaming) ...", flush=True)
        outF, besF, xFl = stieltjes_stream(1, TARGETS)
        print("[stieltjes] DROP-4 (streaming) ...", flush=True)
        outD, besD, xDl = stieltjes_stream(5, TARGETS)
        print(f"\n{'j':>5} {'w':>6}  {'Dfull/n13':>10} {'Dhead/n13':>10} {'Ddrop/n13':>10}")
        for j in TARGETS:
            nu = 2.0*j; n13 = nu**(1/3)
            for n in sorted(outF[j]):
                if n not in outD[j]:
                    continue
                w_ = C13/n13*(nu - (n-0.5)*math.pi)
                r1F, r2F, dr2F, xn, _ = outF[j][n]
                r1D, r2D, dr2D, xnD, _ = outD[j][n]
                bF = besF[j-2-1+1-1]  # be list: bes[k-1] connects degree k-1,k => B_{j-2}=bes[j-2]
                bF = besF[j-2]
                bD = besD[j-2]
                Ff = float(2*bF*xn*r1F*(r2F + xn*dr2F))
                Fd = float(2*bD*xnD*r1D*(r2D + xnD*dr2D))
                sg = sigma_exact(j, n)
                print(f"{j:>5} {w_:+6.2f}  {(Ff-sg)/n13:+10.4f} {(Fd-Ff)/n13:+10.4f} "
                      f"{(Fd-sg)/n13:+10.4f}", flush=True)

if __name__ == '__main__':
    main()
