r"""
lambda_valuelaw_check.py -- layer-by-layer numeric validation for the r-system
Airy limit (the last third of the Delta(w) derivation). Layers:

 [1] System A (weights 2x_n, FULL lattice n>=1): value law
       p^A_j(x_n) = c_j^A (-1)^{n+1} z_n^2 j_{2j+1}(z_n),
     candidate c_j^A = sqrt(4j+1)/((j+1)(2j+1)) from p^A_j(0) = (-1)^j sqrt(4j+1)
     (M1-HORIZON Part I Thm 2). Verify p^A_j(0), the value law, and c_j^A.
 [2] Christoffel step: r_i (ONB of omega = sum x^2 delta, FULL lattice) vs
       r_i(x) = sqrt2 [ p^A_{i+1}/sqrt((4i+3)(4i+5)) + p^A_i/sqrt((4i+1)(4i+3)) ]/x,
     and B_{i-1} vs closed form [(4i-1)(4i+1)^2(4i+3)]^{-1/2}.
 [3] DROP-4 omega system (the validated F system) vs FULL omega at band atoms:
     size of the head-drop effect on r, B at j ~ 54.
 [4] ground truth magnitudes: r_{j-1}, r_{j-2}, x r'_{j-2} at band atoms (j = 54)
     with w labels -- the targets any Airy formula must hit.
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (session 5b).
"""
import os, math
import numpy as np
import mpmath as mp

HERE = os.path.dirname(os.path.abspath(__file__))
NMAX = 2000
DPS = 300
JT = 56

def stieltjes(weight_pow, nstart):
    """OPs of sum_{n>=nstart} x_n^{weight_pow-ish} ... weight function w(x_n):
       weight_pow = ('A' -> 2x), ('O' -> x^2). Returns al, be, P, dP, x (mpf)."""
    z = [(mp.mpf(n) - mp.mpf(1)/2)*mp.pi for n in range(nstart, NMAX+1)]
    x = [1/zz**2 for zz in z]
    if weight_pow == 'A':
        w = [2*xx for xx in x]
    else:
        w = [xx**2 for xx in x]
    N = len(x)
    m0 = mp.fsum(w)
    P = [[1/mp.sqrt(m0)]*N]
    dP = [[mp.mpf(0)]*N]
    al, be = [], []
    a0 = mp.fsum(w[n]*x[n]*P[0][n]**2 for n in range(N))
    al.append(a0)
    cur = [(x[n]-a0)*P[0][n] for n in range(N)]
    dcur = [P[0][n] for n in range(N)]
    prev, dprev = P[0], dP[0]
    for kdeg in range(1, JT+1):
        b = mp.sqrt(mp.fsum(w[n]*cur[n]**2 for n in range(N)))
        be.append(b)
        cur = [c/b for c in cur]; dcur = [c/b for c in dcur]
        P.append(cur); dP.append(dcur)
        ak = mp.fsum(w[n]*x[n]*cur[n]**2 for n in range(N))
        al.append(ak)
        nxt = [(x[n]-ak)*cur[n] - b*prev[n] for n in range(N)]
        dnxt = [(x[n]-ak)*dcur[n] + cur[n] - b*dprev[n] for n in range(N)]
        prev, dprev = cur, dcur
        cur, dcur = nxt, dnxt
    return al, be, P, dP, x

def p_at_zero(P, x, w, jdeg):
    """evaluate p_j(0) by polynomial extrapolation? -- instead reconstruct from
    three-term recurrence at x=0 using al/be."""
    raise NotImplementedError

def eval_p0(al, be, jdeg):
    """p_j(0) via the recurrence p_{k+1}(0) = (-al[k] p_k(0) - be[k-1] p_{k-1}(0))/be[k]."""
    p_prev = mp.mpf(0)
    p0 = None
    vals = []
    # p_0 = 1/sqrt(m0) -- but we normalized P[0] = 1/sqrt(m0) constant; recurrence
    # needs the same starting value. We pass it in via closure below instead.
    return None

def main():
    with mp.workdps(DPS):
        print("[stieltjes] building A (full), O_full, O_drop4 ...")
        alA, beA, PA, dPA, xA = stieltjes('A', 1)
        alF, beF, PF, dPF, xF = stieltjes('O', 1)
        alD, beD, PD, dPD, xD = stieltjes('O', 5)
        print("done")

        # ---- [1] p^A_j(0) and the value law ----
        m0A = mp.fsum(2*xx for xx in xA)
        p0 = [1/mp.sqrt(m0A)]
        p1 = [(mp.mpf(0) - alA[0])*p0[0]/beA[0]]
        vals0 = [p0[0], p1[0]]
        for k in range(1, JT):
            nxt = ((0 - alA[k])*vals0[k] - beA[k-1]*vals0[k-1])/beA[k]
            vals0.append(nxt)
        print("\n== [1a] p^A_j(0) vs (-1)^j sqrt(4j+1) ==")
        for j in (0, 1, 2, 3, 5, 8, 20, 54):
            pred = (-1)**j*math.sqrt(4*j+1)
            print(f"   j={j:>2}: p(0) = {mp.nstr(vals0[j], 10)}   pred = {pred:+.6f}   "
                  f"ratio = {mp.nstr(vals0[j]/pred, 8)}")
        print("\n== [1b] value law p^A_j(x_n) = c_j (-1)^(n+1) z^2 j_{2j+1}(z) ==")
        for j in (5, 20, 54):
            cj = math.sqrt(4*j+1)/((j+1)*(2*j+1))
            for n in (3, 12, int(2*j/math.pi)+1, int(2.4*j/math.pi)):
                z = (mp.mpf(n) - mp.mpf(1)/2)*mp.pi
                bes = mp.besselj(mp.mpf(2*j+1)+mp.mpf(1)/2, z)*mp.sqrt(mp.pi/(2*z))
                pred = cj*(-1)**(n+1)*z**2*bes
                act = PA[j][n-1]
                print(f"   j={j:>2} n={n:>3}: p = {mp.nstr(act, 8)}   "
                      f"c*z2j = {mp.nstr(pred, 8)}   ratio = {mp.nstr(act/pred, 8)}")

        # ---- [2] Christoffel step: r from p^A ----
        print("\n== [2] r_i (FULL omega) vs sqrt2[gam p^A_{i+1} + del p^A_i]/x ==")
        for i in (20, 53):
            gam = 1/math.sqrt((4*i+3)*(4*i+5))
            dl = 1/math.sqrt((4*i+1)*(4*i+3))
            for n in (12, int((2*(i+1))/math.pi)+1):
                pred = mp.sqrt(2)*(gam*PA[i+1][n-1] + dl*PA[i][n-1])/xA[n-1]
                act = PF[i][n-1]
                print(f"   i={i:>2} n={n:>3}: r = {mp.nstr(act, 8)}   "
                      f"pred = {mp.nstr(pred, 8)}   ratio = {mp.nstr(act/pred, 8)}")
        print("\n   B_{i-1} (FULL omega be) vs [(4i-1)(4i+1)^2(4i+3)]^(-1/2):")
        for i in (5, 20, 53):
            pred = 1/math.sqrt((4*i-1)*(4*i+1)**2*(4*i+3))
            print(f"   i={i:>2}: be = {mp.nstr(beF[i-1], 8)}   closed = {pred:.8e}   "
                  f"ratio = {mp.nstr(beF[i-1]/pred, 8)}")

        # ---- [3] drop-4 vs full omega at band (j = 54) ----
        print("\n== [3] drop-4 vs FULL omega r at band atoms (j = 54) ==")
        j = 54
        for n in (33, 35, 37):
            idxF = n - 1; idxD = n - 5
            print(f"   n={n}: r_(j-1) full = {mp.nstr(PF[j-1][idxF], 8)}   "
                  f"drop4 = {mp.nstr(PD[j-1][idxD], 8)}   "
                  f"ratio = {mp.nstr(PD[j-1][idxD]/PF[j-1][idxF], 8)}")
        print(f"   B_(j-2): full = {mp.nstr(beF[j-2], 8)}  drop4 = {mp.nstr(beD[j-2], 8)}"
              f"  ratio = {mp.nstr(beD[j-2]/beF[j-2], 8)}")

        # ---- [4] ground-truth magnitudes at band (drop-4, j = 54) ----
        print("\n== [4] drop-4 ground truth at j = 54 band ==")
        C13 = 2**(1/3)
        nu = 108.0
        print("    n     w        r_(j-1)        r_(j-2)        x*r'_(j-2)")
        for n in range(31, 39):
            idx = n - 5
            w = C13*nu**(-1/3)*(nu - (n-0.5)*math.pi)
            xr = xD[idx]*dPD[j-2][idx]
            print(f"  {n:>4} {w:+5.2f}  {mp.nstr(PD[j-1][idx], 8):>13}  "
                  f"{mp.nstr(PD[j-2][idx], 8):>13}  {mp.nstr(xr, 8):>13}")

if __name__ == '__main__':
    main()
