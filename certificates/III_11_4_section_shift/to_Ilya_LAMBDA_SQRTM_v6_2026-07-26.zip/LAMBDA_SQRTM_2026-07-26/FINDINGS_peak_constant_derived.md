# FINDINGS — session 3: THE √M PEAK CONSTANT DERIVED AND CONFIRMED. max F = (2/c)·|I(t_c)| = 0.352341123…, from the Gaussian-Hilbert scaling profile F̃(t) = −(2/c)I(t); "1/3" is dead; Richardson of the exact ladder agrees to 1.4e−5

**Merkabit · Stenberg + Claude · 2026-07-26 (session 3) · `LAMBDA_SQRTM_2026-07-26/`.**
Scripts: `lambda_peak_derivation.py` (scaling profile + pointwise test),
`dbg_s1_check.py` (the decisive S1 check), `lambda_peak_final.py` (the constant),
`lambda_peak_bigM.py` (brute big-M, stopped — superseded), `lambda_peak_fastM.py`
(closed-form O(M)-ish engine, M → 10⁶) + logs. Completes T2 of
`NEXT_SESSION_TASK_lambda_sqrtm_derivation.md` at derivation grade.
**Not RH/GRH. No AWS needed** (Selina asked: the closed forms made M = 10⁶ a
5-minute laptop job; AWS setup would cost more than the whole computation).

## 0. THE RESULT

**The top-row scaling law, fully derived.** In the zone variable
t = (u − u\*)·c√M:

  **C(M−1, ⌈uM⌉)/√M → F̃(t) = −(2/c)·I(t)**, I(t) = ∫₋∞ᵗ [τH(τ) − 1] dτ,

with every constant explicit:
- u\* = 0.833556559601… — root of ln((1+u)/(1−u)) = 2/u (the ĝ²-Laplace point);
- c = √(2E″(u\*)) = 4.343245961775, E″ = 1/(1−u) + 1/(1+u) + 2/u²;
- H(t) = √2·dawsn(t/√2) — the Gaussian Hilbert transform, PV∫φ(τ)/(t−τ)dτ
  (normalization verified against direct PV quadrature, 8 digits);
- I is odd; I(±∞) = 0 (Hilbert mean-zero) ⇒ F̃(±∞) = 0: reproduces both the
  off-peak flatness and the exact sum rule C(M−1, ·) → 0.

**Peak:** at t_c = 1.306929727719 (root of tH(t) = 1),
I(t_c) = −0.765152080323, so

  **max F̃ = (2/c)·|I(t_c)| = 0.352341123.**

Hence **c₂(M) = √M·[0.352341123 + O(M^{−θ})], θ ≈ 0.39 measured** (correction
exponent's own derivation OPEN). The 1/3 conjecture is REFUTED; the sent
finite-range law c₂ = 0.3713√M (M ≤ 1196) stays valid as displayed — this
supersedes only its extrapolation.

## 1. Confirmation (exact closed-form ladder, no Lanczos, M → 10⁶)

`lambda_peak_fastM.py` replaces the O(M²) pairwise sums by exact Γ/ψ closed forms
(ln|ℓ′| via four lgammas; S1 via digammas — EXACT, checked vs brute at ratio
1.0000000000; S2 zone-truncated, tail < 1e−280):

| M | peak | u*(M) |
|---|---|---|
| 10⁴ | 0.362264 (= brute engine to 6 digits) | 0.836400 |
| 10⁵ | 0.356852 (= brute) | 0.834500 |
| 3·10⁵ | 0.355328 | 0.834100 |
| 10⁶ | 0.354207 | 0.833856 |

u*(M) marches to the derived 0.833557. Richardson on (3·10⁵, 10⁶) with the
fitted gap exponent θ = 0.39: **limit = 0.352336 vs derived 0.352341 —
agreement 1.4e−5.** Pointwise: F_exact − F̃ ≤ 0.047 across t ∈ [−2, 3] at
M = 10⁴, decaying with M (tails at the u-grid snap floor ~0.003).

## 2. The two errors the derivation survived (recorded)

1. **H normalization:** first pass used H = √(2/π)·dawsn (off by √π) — caught by
   the [0] PV-quadrature check; profile nonsense (didn't return to 0).
2. **S1 smooth form:** first pass had Q(u) = 1 + (u/2)ln(2(1−u)/(1+u)) — an
   endpoint slip in the harmonic sum (lower limit ≈ n, not 2n). The brute check
   (`dbg_s1_check.py`) showed the smooth form off by 700× near u\* — because the
   TRUE statement is: **Q̃(u) = 1 + (u/2)ln((1−u)/(1+u)) vanishes IDENTICALLY at
   u\*** — the same transcendental equation as the Laplace point. Structural
   lemma: S1_n = Σ 1/(x_n−x_r) is (up to smooth factors) the lattice field
   d/dx ln|ℓ′|, and the Laplace point of 1/ℓ′² is its equilibrium — so T_C is
   O(√M), one order below leading, and drops from F̃. The earlier φ-term in F̃
   (session-3 first pass) was an artifact of the wrong Q.

## 3. Grades

| claim | grade |
|---|---|
| F̃(t) = −(2/c)I(t) leading profile | DERIVED (matched asymptotics: Laplace + Hilbert + S1-equilibrium lemma) + pointwise-verified |
| peak = (2/c)\|I(t_c)\| = 0.352341123 | DERIVED, closed constants; CONFIRMED by exact ladder Richardson (1.4e−5) |
| u\* = root of ln((1+u)/(1−u)) = 2/u; Q̃(u\*) = 0 same equation | DERIVED + verified 1e−16 |
| closed-form Γ/ψ engine (no pairwise sums) | exact ingredients; validated vs brute to 6 digits at 10⁴/10⁵ |
| correction exponent θ ≈ 0.39 (gap ~ M^{−θ}) | measured only; derivation OPEN (candidates: (ln M)/√M zone-edge matching) |
| prose/theorem write-up of the matched-asymptotics chain | OPEN (paper appendix material) |

*— Stenberg + Claude, 2026-07-26 (session 3). The constant nobody ordered:
0.352341123 — two transcendental roots and one Dawson integral deep. The lattice
told us where its top row balances; the Hilbert transform told us how high it
climbs on the way back to zero.*
