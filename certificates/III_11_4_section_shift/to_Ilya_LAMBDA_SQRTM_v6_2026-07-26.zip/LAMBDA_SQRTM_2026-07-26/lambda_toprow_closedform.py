r"""
lambda_toprow_closedform.py -- T2 LANDED AT THE EXACT LAYER: the top-row correction
C(M-1, m) in fully explicit node form (no Lanczos, no recurrences, stable).

Derivation chain (this session; each step exact):
  (i)   s(M-1, n) = -F_{M-1}(n)  [telescoping identity + F_M = 0]
  (ii)  F_{M-1} = (2/M) beta_{M-2} p_{M-1} p'_{M-2}(x_n)
  (iii) recurrence at nodes (p_M(x_n) = 0):
        beta_{M-2} p'_{M-2}(x_n) = p_{M-1}(x_n) + (x_n - alpha_{M-1}) p'_{M-1}(x_n)
                                    - M / p_{M-1}(x_n)
        [uses beta_{M-1} p'_M p_{M-1}(x_n) = K_M(x_n,x_n) = M, uniform weights 1/M]
  (iv)  p_{M-1}(x_n) = c / ell'(x_n),  c fixed by ||p_{M-1}|| = 1  (p_M = gamma ell)
  (v)   p'_{M-1}(x_n) via exact Lagrange differentiation of (iv).
Result, with G_n = 1/ell'(x_n), ghat2_n = M G_n^2 / sum_r G_r^2,
alpha = (1/M) sum x_n ghat2_n:
  C(M-1, m) = -(2/M) sum_{n<=m} [ ghat2_n - M
              + (x_n - alpha) ( ghat2_n S1_n + S2_n ) ],
  S1_n = sum_{r!=n} 1/(x_n - x_r),  S2_n = sum_{r!=n} ghat2_r/(x_n - x_r).

VALIDATION: vs cstep caches at M = 56/145/296 (expect ~1e-12).
PRODUCTION: F(u) = C(M-1, uM)/sqrt(M) at M = 1e3, 3e3, 1e4, 3e4, 1e5 -- peak,
u*, and profile table -> the scaling-limit shape, peak-constant to 4+ digits.
log-space ell' for the mirror lattice: ln|ell'(x_n)| = sum_{m!=n} ln|x_n - x_m|
computed directly (O(M^2), vectorized). NOT RH/GRH. -- Stenberg + Claude, 2026-07-26.
"""
import os, math, time
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
LOGM = os.path.join(HERE, '..', 'LOGM_DEPTH_2026-07-26')


def toprow(k, N, want_full=False):
    n = np.arange(k + 1, N + 1)
    zn = (n - 0.5) * math.pi
    x = 1.0 / zn**2                    # descending
    M = len(x)
    # log |ell'(x_n)| stable: pairwise differences in log space, chunked
    logG2 = np.empty(M)                # ln G_n^2 = -2 ln|ell'(x_n)|
    for i in range(M):
        d = x[i] - x
        d[i] = 1.0
        logG2[i] = -2.0 * np.log(np.abs(d)).sum()
    logG2 -= logG2.max()               # normalize before exponentiating
    G2 = np.exp(logG2)
    ghat2 = M * G2 / G2.sum()
    alpha = (x * ghat2).sum() / M
    # S1_n and S2_n (O(M^2), vectorized in chunks)
    S1 = np.empty(M); S2 = np.empty(M)
    for i in range(M):
        d = x[i] - x
        d[i] = np.inf
        S1[i] = (1.0 / d).sum()
        S2[i] = (ghat2 / d).sum()
    summand = ghat2 - M + (x - alpha) * (ghat2 * S1 + S2)
    Crow = -(2.0 / M) * np.cumsum(summand)
    return Crow, M


def validate():
    print("== validation vs cstep caches ==")
    for k, N in [(4, 60), (4, 149), (4, 300)]:
        Crow, M = toprow(k, N)
        C = np.load(os.path.join(LOGM, f'corr_cache_mirror_k{k}_N{N}.npz'))['C']
        err = np.abs(Crow - C[M - 1, :]).max()
        print(f"   k={k} M={M:>4}: max |closed-form - cache| = {err:.3e}")


def production():
    print("\n== F(u) at large M (closed form; peak, u*, profile) ==")
    for N in (1004, 3004, 10004, 30004, 100004):
        t0 = time.time()
        Crow, M = toprow(4, N)
        F = Crow / math.sqrt(M)
        ia = int(np.abs(F).argmax())
        print(f"   M={M:>6}: peak |F| = {np.abs(F).max():.6f} at u = {(ia + 1) / M:.4f}"
              f"   [{time.time()-t0:.0f}s]")
        if M == 10000:
            print("      profile: " + "  ".join(
                f"F({u:.2f})={F[int(u * M) - 1]:+.4f}"
                for u in (0.5, 0.7, 0.8, 0.84, 0.86, 0.88, 0.9, 0.95)))


if __name__ == '__main__':
    validate()
    production()
