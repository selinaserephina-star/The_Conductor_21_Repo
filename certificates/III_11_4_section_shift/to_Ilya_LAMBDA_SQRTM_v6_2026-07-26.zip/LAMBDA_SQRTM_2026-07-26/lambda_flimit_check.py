r"""
lambda_flimit_check.py -- validate the DERIVED M->infinity limit of the section side:

CLAIM (derived, session 5): for the uniform-weight drop-4 section, as M -> inf at
fixed j >= 2,
    p_j^{sec}(x) -> sqrt(M) * x * r_{j-1}(x),     beta_{j-1}^{sec} -> B_{j-2},
where r_i = orthonormal polynomials of omega = sum_{n>=5} x_n^2 delta_{x_n}
(x_n = 1/z_n^2, z_n = (n-1/2)pi; the x^2-weighted ODD-lattice system) and B_i its
recurrence norms. Mechanism: the uniform measure's vanishing-mass bulk at x -> 0+
pins q_j(0) = 0 (counting measure has infinite mass at the accumulation point), so
q_j = x*r_{j-1} after renormalization -- a Christoffel DEGREE SHIFT. Consequently

    F_j^inf(n) = 2 B_{j-2} x_n r_{j-1}(x_n) [ r_{j-2}(x_n) + x_n r'_{j-2}(x_n) ]

M-free -- this IS the M-saturation, derived. Test: F_pred vs F_from_cache at
j = 29, 54, band sites, M = 596 and 1196 (error should be ~1/M and halve).
Build r by Stieltjes at high dps on the truncated lattice (tail x^2 ~ n^-4).
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (session 5).
"""
import os, math, time
import numpy as np
import mpmath as mp

HERE = os.path.dirname(os.path.abspath(__file__))
LOGM = os.path.join(HERE, '..', 'LOGM_DEPTH_2026-07-26')
C13 = 2**(1/3)
K = 4
NMAX = 2000     # omega truncation (tail of moments ~ n^-4; plenty for j <= 54)
DPS = 300

def jacobi_r(jmax):
    """Stieltjes for omega = sum_{n=5}^{NMAX} x_n^2 delta_{x_n}; returns
    (al, be, P, dP) with P[i][idx], dP[i][idx] at the first NBAND atoms."""
    N = NMAX - K
    z = [(mp.mpf(n) - mp.mpf(1)/2)*mp.pi for n in range(K+1, NMAX+1)]
    x = [1/zz**2 for zz in z]
    w = [xx**2 for xx in x]
    m0 = mp.fsum(w)
    P = [[1/mp.sqrt(m0)]*N]
    dP = [[mp.mpf(0)]*N]
    al, be = [], []
    a0 = mp.fsum(w[n]*x[n]*P[0][n]**2 for n in range(N))
    al.append(a0)
    cur = [(x[n]-a0)*P[0][n] for n in range(N)]
    dcur = [P[0][n] for n in range(N)]
    prev, dprev = P[0], dP[0]
    for kdeg in range(1, jmax+1):
        b = mp.sqrt(mp.fsum(w[n]*cur[n]**2 for n in range(N)))
        be.append(b)
        cur = [c/b for c in cur]; dcur = [c/b for c in dcur]
        P.append(cur); dP.append(dcur)
        ak = mp.fsum(w[n]*x[n]*cur[n]**2 for n in range(N))
        al.append(ak)
        nxt = [(x[n]-ak)*cur[n] - b*prev[n] for n in range(N)]
        dnxt = [(x[n]-ak)*dcur[n] + cur[n] - b*dprev[n] for n in range(N)]
        prev, dprev = cur, dcur
        cur, dcur = nxt, dnxt
    return al, be, P, dP, x

def F_col(C, j, col):
    if col == 0:
        s = C[j:, 0]
    else:
        s = C[j:, col] - C[j:, col-1]
    return -float(s.sum())

def wof(j, n):
    nu = 2.0*j
    return C13*nu**(-1/3)*(nu - (n-0.5)*math.pi)

def main():
    t0 = time.time()
    with mp.workdps(DPS):
        JT = 54
        al, be, P, dP, x = jacobi_r(JT)
        print(f"[stieltjes] omega system to degree {JT} in {time.time()-t0:.0f}s "
              f"(NMAX={NMAX}, dps={DPS})")
        caches = {N: np.load(os.path.join(LOGM, f'corr_cache_mirror_k4_N{N}.npz'))['C']
                  for N in (600, 1200)}
        for j in (29, 54):
            nu = 2.0*j; n13 = nu**(1/3)
            print(f"\n== j={j}: F_pred (omega closed form) vs cache F (M=596/1196) ==")
            print("    n     w      F_pred      F(M=596)   F(M=1196)   "
                  "err596      err1196   ratio")
            for n in range(int((nu-2.6*n13/C13)/math.pi+0.5),
                           int((nu+2.2*n13/C13)/math.pi+0.5)+1):
                idx = n - (K+1)          # 0-based position in omega atom list
                col = n - K - 1          # 0-based cache column
                if idx < 0 or col < 0:
                    continue
                xn = x[idx]
                # F_pred = 2 B_{j-2} x r_{j-1}(x) [ r_{j-2}(x) + x r'_{j-2}(x) ]
                Fp = 2*be[j-2]*xn*P[j-1][idx]*(P[j-2][idx] + xn*dP[j-2][idx])
                Fp = float(Fp)
                w_ = wof(j, n)
                vals = {}
                for N, C in caches.items():
                    vals[N] = F_col(C, j, col)
                e596 = vals[600] - Fp
                e1196 = vals[1200] - Fp
                ratio = e596/e1196 if e1196 != 0 else float('nan')
                print(f"  {n:>4} {w_:+5.2f}  {Fp:+9.4f}  {vals[600]:+9.4f}  "
                      f"{vals[1200]:+9.4f}  {e596:+9.5f}  {e1196:+9.5f}  {ratio:5.2f}")

if __name__ == '__main__':
    main()
