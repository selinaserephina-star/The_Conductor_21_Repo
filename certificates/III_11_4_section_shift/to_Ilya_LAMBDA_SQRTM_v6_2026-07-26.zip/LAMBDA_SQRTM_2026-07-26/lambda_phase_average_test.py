r"""
lambda_phase_average_test.py -- THE hypothesis test for the Lambda mechanism:
    H-AVG: in the caustic band (and pre-onset osc zone) the section's per-site
    summand equals the LOCAL PHASE-AVERAGE of the infinity summand,
        s_sec(j, m)  ~=  <s_inf>_h(m)  (centered moving average, half-width h),
    so the deficiency C_sec - C_inf = -prefix of the mean-free part, and
        Lambda_j(w) = nu^{-1/3} * sum_{n<=m(w)} [ <s_inf> - s_inf ](n)
    is DERIVED from the infinity summand alone (no section quantities).
Assumption-free version: <.>_h is a plain centered moving average over sites,
h chosen from the local oscillation scale (half-period of Delta_j sigma; we
sweep h = 2..5 and report). Checks at j = 200 (M = 1196) and j = 103 (M = 596):
  [1] pointwise: s_sec vs <s_inf>_h across w in (-6, +2);
  [2] cumulative: -sum_{n<=m}[s_inf - <s_inf>_h] / nu^{1/3}  vs the measured
      deficiency (C_sec - C_inf)/nu^{1/3} = Lambda-profile (from the caches +
      logm_infty_rows.csv where available; else recomputed sigma prefix).
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (LAMBDA_SQRTM session).
"""
import os, math, csv
import numpy as np
import mpmath as mp

mp.mp.dps = 40
PI = mp.pi
HERE = os.path.dirname(os.path.abspath(__file__))
LOGM = os.path.join(HERE, '..', 'LOGM_DEPTH_2026-07-26')
C13 = 2**(1 / 3)

_DF = {}
def dfact(l):
    if l not in _DF:
        v = mp.mpf(1)
        for i in range(3, 2 * l + 2, 2):
            v *= i
        _DF[l] = v
    return _DF[l]

def j_series(l, z):
    guard = int(0.44 * float(z)) + 30
    with mp.workdps(mp.mp.dps + guard):
        zz = mp.mpf(z); z2 = zz * zz / 2
        t = mp.mpf(1); s = mp.mpf(1); k = 0
        thr = mp.mpf(10)**(-(mp.mp.dps + 10))
        while True:
            k += 1
            t *= -z2 / (k * (2 * l + 1 + 2 * k))
            s += t
            if abs(t) < thr * (abs(s) + 1) and 2 * k > float(z):
                break
        val = s * zz**l / dfact(l)
    return +val

def bessel_rows(z, Lmax, jorders):
    with mp.workdps(80):
        zz = mp.mpf(z)
        y = [-mp.cos(zz) / zz, -mp.cos(zz) / zz**2 - mp.sin(zz) / zz]
        for l in range(1, Lmax):
            y.append((2 * l + 1) / zz * y[-1] - y[-2])
        Lup = min(Lmax, int(float(z)) - 3)
        jup = None
        if any(l <= Lup for l in jorders):
            jup = [mp.sin(zz) / zz, mp.sin(zz) / zz**2 - mp.cos(zz) / zz]
            for l in range(1, Lup):
                jup.append((2 * l + 1) / zz * jup[-1] - jup[-2])
    jv = {}
    for l in jorders:
        if jup is not None and l <= Lup:
            jv[l] = +jup[l]
        elif z < l:
            jv[l] = j_series(l, z)
        else:
            with mp.workdps(60):
                v = mp.sqrt(PI / (2 * z)) * mp.besselj(mp.mpf(l) + mp.mpf(1) / 2, z)
            jv[l] = +v
    return jv, y

def sigma(j, n):
    z = (2 * n - 1) * PI / 2
    Ls = sorted({2 * j - 2, 2 * j - 1, 2 * j + 1})
    jv, y = bessel_rows(z, 2 * j + 2, Ls)
    return float((mp.mpf(2) / (4 * j + 1)) * z**2 * jv[2 * j + 1] * (
        2 * (j - 1) * jv[2 * j - 1] - z * (jv[2 * j - 2] + y[2 * j - 1])))


def lanczos_q(x):
    n = len(x)
    V = np.empty((n, n))
    v = np.full(n, 1.0 / math.sqrt(n))
    V[0] = v
    al = np.empty(n); be = np.empty(n - 1)
    w = x * v; a = v @ w; al[0] = a; w = w - a * v
    for j in range(1, n):
        b = np.linalg.norm(w)
        be[j - 1] = b
        vn = w / b
        Vj = V[:j]
        vn -= Vj.T @ (Vj @ vn); vn -= Vj.T @ (Vj @ vn)
        vn /= np.linalg.norm(vn)
        V[j] = vn
        w = x * vn - b * V[j - 1]
        a = vn @ w; al[j] = a; w = w - a * vn
    J = np.diag(al) + np.diag(be, 1) + np.diag(be, -1)
    ev, U = np.linalg.eigh(J)
    q = np.zeros((n, n))
    for r, nn in enumerate(np.argsort(x)):
        col = U[:, r]
        if col[0] < 0:
            col = -col
        q[:, nn] = col
    return q


def mirror_atoms(k, N):
    zn = (np.arange(k + 1, N + 1) - 0.5) * math.pi
    return 1.0 / zn**2


def run_case(j, N, k=4):
    C = np.load(os.path.join(LOGM, f'corr_cache_mirror_k{k}_N{N}.npz'))['C']
    M = C.shape[0]
    q = lanczos_q(mirror_atoms(k, N))
    nu = 2.0 * j
    # site range: w in (-7, +3)
    def m_of_w(w):
        return (nu - w * nu**(1 / 3) / C13) / math.pi + 0.5 - k
    mlo = max(3, int(m_of_w(3.0)))
    mhi = min(M, int(m_of_w(-7.0)) + 1)
    ms = list(range(mlo, mhi + 1))
    s_sec = {m: (C[j, m - 2] - C[j, m - 3]) + q[j, m - 1]**2 for m in ms}
    # infinity summand on lattice sites n = m + k, extended margin for averaging
    pad = 6
    s_inf = {}
    for m in range(mlo - pad, mhi + pad + 1):
        nlat = m + k
        s_inf[m] = sigma(j + 1, nlat) - sigma(j, nlat)
    print(f"\n== case j={j}, M={M} ==")
    print("  [1] pointwise s_sec vs centered moving averages <s_inf>_h:")
    print("     m     w     s_sec      h=2        h=3        h=4        h=5")
    best = {h: [] for h in (2, 3, 4, 5)}
    for m in ms:
        w = C13 * nu**(-1 / 3) * (nu - (m + k - 0.5) * math.pi)
        line = f"  {m:>4} {w:+5.2f} {s_sec[m]:+9.5f}"
        for h in (2, 3, 4, 5):
            av = np.mean([s_inf[m + d] for d in range(-h, h + 1)])
            line += f"  {av:+9.5f}"
            best[h].append(abs(av - s_sec[m]))
        if abs(w) < 2.5 or m % 3 == 0:
            print(line)
    for h in (2, 3, 4, 5):
        print(f"   h={h}: mean|s_sec - <s_inf>_h| over window = {np.mean(best[h]):.4f}")
    print("  [2] cumulative: deficiency vs mean-free prefix (nu^{-1/3} units)")
    # measured deficiency prefix: (C_sec_tail - C_inf_tail); C_tail(m) = -C[j, m-2]
    acc_inf = 0.0
    accs = {}
    for m in sorted(s_inf):
        if m < 1:
            continue
        acc_inf += s_inf[m]
        accs[m] = acc_inf
    # anchor both prefixes at mlo (differences only)
    print("     m     w    meas (C_sec-C_inf)/nu^(1/3)   -sum(s_inf-<s_inf>_3)/nu^(1/3)")
    acc_dev = 0.0
    for m in ms:
        w = C13 * nu**(-1 / 3) * (nu - (m + k - 0.5) * math.pi)
        av = np.mean([s_inf[m + d] for d in range(-3, 4)])
        acc_dev += (av - s_inf[m])
        ct_sec = -C[j, m - 2]
        ct_inf = -(accs[m - 1]) if (m - 1) in accs else float('nan')
        # NOTE: conventions -- C_tail(m) = -prefix(m-1); inf prefix likewise
        meas = (ct_sec - (-accs[m - 1])) / nu**(1 / 3) if (m - 1) in accs else float('nan')
        pred = acc_dev / nu**(1 / 3)
        if abs(w) < 2.5 or m % 3 == 0:
            print(f"  {m:>4} {w:+5.2f}   {meas:+12.4f}                {pred:+12.4f}")


if __name__ == '__main__':
    run_case(200, 1200)
    run_case(103, 600)
