r"""
lambda_head_factor_exact.py -- the CLOSED CHAIN for the drop-4 head factor
(session 5c; the last derivation piece of Delta(w)).

DERIVED STRUCTURE (all entries closed-form Bessel):
 removal of the 4 head atoms y_k = 1/z_k^2 (masses m_k = y_k^2) from the full
 x^2-lattice system gives, for the drop-4 orthonormal polynomials,
    rt_i(x) = N_i [ r_i(x) + sum_l a_l K_i(x, y_l) ],
    a = T(i)^{-1} v,   v_k = r_i(y_k),
    T(i)_kl = sum_{s>=i} r_s(y_k) r_s(y_l)      <-- the TAIL GRAM
 (identity: 1/m_k delta_kl - K_i(y_k,y_l) = T_kl by completeness), with
    r_s(atoms) from the value law  r_s(x_n) = kappa_s (-1)^{n+1} z_n^2 j_{2s+1}(z_n),
    kappa_s = sqrt(2(4s+3)),  K_i via Christoffel-Darboux (B closed),
    derivatives via the wave identity (y-channel).
 N_i from ||rt||^2_drop = 1 + 2a.v + a.Ka - sum_k m_k rt_hat(y_k)^2.

TESTS:
 [1] rt_{j-1}(x_n) vs the drop-4 Stieltjes ground truth (j = 54: 15.6009 / 332.309 /
     2558.36 at n = 33/35/37).
 [2] F_drop assembled from the chain (B~ from the validated drop Stieltjes) vs the
     cstep cache F; Delta_head_pred = (F_drop_pred - F_full_exact)/nu^{1/3} vs
     measured; total Delta_pred vs cache Delta.
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (session 5c).
"""
import os, math
import numpy as np
import mpmath as mp

mp.mp.dps = 400
PI = mp.pi
C13 = 2**(1/3)
LOGM = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..',
                    'LOGM_DEPTH_2026-07-26')
TAIL = 40   # tail-Gram truncation (terms decay superexponentially)

def sph_jy(l, z):
    fac = mp.sqrt(PI/(2*z))
    return (fac*mp.besselj(mp.mpf(l)+mp.mpf(1)/2, z),
            fac*mp.bessely(mp.mpf(l)+mp.mpf(1)/2, z))

def sph_j(l, z):
    return mp.sqrt(PI/(2*z))*mp.besselj(mp.mpf(l)+mp.mpf(1)/2, z)

def kap(s):
    return mp.sqrt(2*(mp.mpf(4*s)+3))

def r_at_atom(s, n):
    z = (mp.mpf(2*n)-1)*PI/2
    return kap(s)*(-1)**(n+1)*z**2*sph_j(2*s+1, z)

def rp_at_atom(s, n):
    """r_s'(x_n) via the wave identity."""
    z = (mp.mpf(2*n)-1)*PI/2
    j, y = sph_jy(2*s+1, z)
    jm = sph_j(2*s, z)
    jp = jm - (2*s+2)/z*j
    return -(z**3)/2*kap(s)*(-1)**(n+1)*(2*z*j + z**2*(jp + y))

def Bfull(i):
    """B_{i-1} = <x r_{i-1}, r_i>_omega, closed."""
    return 1/mp.sqrt(mp.mpf(4*i-1)*(4*i+1)**2*(4*i+3))

def head_solve(i):
    """a-vector, plus data for norms: v, K4 (=1/m - T), rt_hat(y)."""
    v = mp.matrix([r_at_atom(i, k) for k in (1, 2, 3, 4)])
    T = mp.zeros(4, 4)
    for s in range(i, i+TAIL):
        u = [r_at_atom(s, k) for k in (1, 2, 3, 4)]
        for a_ in range(4):
            for b_ in range(4):
                T[a_, b_] += u[a_]*u[b_]
    a = mp.lu_solve(T, v)
    m = [ (1/((mp.mpf(2*k)-1)*PI/2)**2)**2 for k in (1, 2, 3, 4) ]
    K4 = mp.zeros(4, 4)
    for a_ in range(4):
        for b_ in range(4):
            K4[a_, b_] = (1/m[a_] if a_ == b_ else 0) - T[a_, b_]
    rthat_y = mp.matrix([v[k] + sum(K4[k, l]*a[l] for l in range(4)) for k in range(4)])
    # ||rt_hat||^2_drop = 1 + 2 a.v + a.K4.a - sum m rt_hat(y)^2
    aKa = sum(a[k]*K4[k, l]*a[l] for k in range(4) for l in range(4))
    nrm2 = 1 + 2*sum(a[k]*v[k] for k in range(4)) + aKa \
           - sum(m[k]*rthat_y[k]**2 for k in range(4))
    return a, m, nrm2

def K_and_dK(i, n, yk_n):
    """K_i(x_n, y_k) and d/dx K_i(x, y_k)|_{x_n} via CD (closed)."""
    z = (mp.mpf(2*n)-1)*PI/2
    x = 1/z**2
    yk = 1/((mp.mpf(2*yk_n)-1)*PI/2)**2
    B = Bfull(i)
    ri_x, rim_x = r_at_atom(i, n), r_at_atom(i-1, n)
    ri_y, rim_y = r_at_atom(i, yk_n), r_at_atom(i-1, yk_n)
    rpi_x, rpim_x = rp_at_atom(i, n), rp_at_atom(i-1, n)
    K = B*(ri_x*rim_y - rim_x*ri_y)/(x - yk)
    dK = B*(rpi_x*rim_y - rpim_x*ri_y)/(x - yk) - K/(x - yk)
    return K, dK

def rt_and_deriv(i, n, a, nrm2):
    """drop-4 rt_i(x_n) and rt_i'(x_n) from the closed chain."""
    N = 1/mp.sqrt(nrm2)
    val = r_at_atom(i, n)
    dval = rp_at_atom(i, n)
    for k in range(4):
        K, dK = K_and_dK(i, n, k+1)
        val += a[k]*K
        dval += a[k]*dK
    return N*val, N*dval

def F_full_exact(j, n):
    z = (mp.mpf(2*n)-1)*PI/2
    x = 1/z**2
    B = 1/mp.sqrt(mp.mpf(4*j-5)*(4*j-3)**2*(4*j-1))
    r1 = r_at_atom(j-1, n); r2 = r_at_atom(j-2, n); dr2 = rp_at_atom(j-2, n)
    return 2*B*x*r1*(r2 + x*dr2)

def sigma_exact(j, n):
    z = (mp.mpf(2*n)-1)*PI/2
    jp1, _ = sph_jy(2*j+1, z)
    jm1, ym1 = sph_jy(2*j-1, z)
    jm2, _ = sph_jy(2*j-2, z)
    return (mp.mpf(2)/(4*j+1))*z**2*jp1*(2*(j-1)*jm1 - z*(jm2 + ym1))

def F_cache(C, j, col):
    if col == 0:
        return -float(C[j:, 0].sum())
    return -float((C[j:, col] - C[j:, col-1]).sum())

def main():
    j = 54
    nu = 2.0*j; n13 = nu**(1/3)
    print(f"== [solve] tail-Gram head factors for i = {j-1}, {j-2} ==")
    a1, m1, nrm1 = head_solve(j-1)
    a2, m2, nrm2 = head_solve(j-2)
    print("   i = j-1: a =", [mp.nstr(a1[k], 6) for k in range(4)],
          "  ||rt||^2_drop =", mp.nstr(nrm1, 8))
    print("   i = j-2: a =", [mp.nstr(a2[k], 6) for k in range(4)],
          "  ||rt||^2_drop =", mp.nstr(nrm2, 8))

    print("\n== [1] rt_(j-1)(x_n) vs drop-4 Stieltjes ground truth ==")
    truth = {33: 15.600931, 35: 332.3088, 37: 2558.3576}
    for n in (33, 35, 37):
        val, _ = rt_and_deriv(j-1, n, a1, nrm1)
        print(f"   n={n}: chain = {mp.nstr(val, 8)}   stieltjes = {truth[n]}   "
              f"ratio = {mp.nstr(val/truth[n], 8)}")

    print("\n== [2] F_drop from the chain vs cache; Delta closure ==")
    Btilde = mp.mpf('1.9058984e-5')   # drop-4 B_{j-2} (validated Stieltjes value)
    C4 = np.load(os.path.join(LOGM, 'corr_cache_mirror_k4_N1200.npz'))['C']
    print("    n     w      F_chain    F_cache    Dhead_pred  Dhead_meas  "
          "Dtot_pred  Dtot_cache")
    for n in range(31, 39):
        z = (mp.mpf(2*n)-1)*PI/2
        x = 1/z**2
        w = C13/n13*(nu - float(z))
        rt1, _ = rt_and_deriv(j-1, n, a1, nrm1)
        rt2, drt2 = rt_and_deriv(j-2, n, a2, nrm2)
        Fch = float(2*Btilde*x*rt1*(rt2 + x*drt2))
        Fca = F_cache(C4, j, n-5)
        Ff = float(F_full_exact(j, n))
        sg = float(sigma_exact(j, n))
        print(f"  {n:>4} {w:+5.2f}  {Fch:+9.4f}  {Fca:+9.4f}  "
              f"{(Fch-Ff)/n13:+9.4f}  {(Fca-Ff)/n13:+9.4f}  "
              f"{(Fch-sg)/n13:+9.4f}  {(Fca-sg)/n13:+9.4f}")

if __name__ == '__main__':
    main()
