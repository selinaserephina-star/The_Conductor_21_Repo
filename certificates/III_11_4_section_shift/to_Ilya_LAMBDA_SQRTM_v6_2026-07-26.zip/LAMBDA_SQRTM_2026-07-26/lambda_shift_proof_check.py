r"""
lambda_shift_proof_check.py -- session 6d: machine checks for the SHIFT LEMMA
PROOF via the horizon route (M1-HORIZON Part I Thm 3 pointed at the head).

Proof chain being verified:
 [A] STAGE-MULTIPLICATIVITY (exact; Thm 3 removal-in-stages):
       det G_j(S u {x_n}) = det G_j(S) * sum_{s>=j} rt_s(x_n)^2
     where G_j(T) := [sum_{s>=j} r_s(a) r_s(b)]_{a,b in T} (tail Gram from level
     j), S = the m head atoms, x_n a remaining atom, rt = drop-m orthonormal.
 [B] INDEX ABSORPTION (the shift): the head atoms absorb the m lowest tail
     indices (Cauchy-Binet minimal-tuple domination; the dominant y-minors
     CANCEL in the ratio):
       det G_j(S u {x})/det G_j(S) = t_{j+m}(x) * (1 + eta),
       t_j(x) := sum_{s>=j} r_s(x)^2,  |eta| = O((eps_max/(2nu)^2)^2)-grade.
     Consequently rt_j(x)^2 = t-difference = r_{j+m}(x)^2 (1 + O(1/nu)).
 [C] A_s cross-sum: A_s = 2/[(4s+1)(4s+5)] <=> Sigma_n j_{2s}(z_n) j_{2s+2}(z_n)
     = 0 (via j_a/z = (j_{a-1}+j_{a+1})/(2a+1) + the Nyquist lattice sums +
     Weber-Schafheitlin off-diagonal vanishing).
NOT RH/GRH. -- Stenberg + Claude, 2026-07-26 (session 6d).
"""
import math
import mpmath as mp
from lambda_chain_highj import sph_tables, kap, r_head, PI
from lambda_display_form import rt_exact_rational

mp.mp.dps = 300


def r_band(s, n, tabs):
    sj, _ = tabs
    z = (mp.mpf(2*n)-1)*PI/2
    return kap(s)*(-1)**(n+1)*z**2*sj[2*s+1]


def gram_det(points_vals, j, T):
    """det [sum_{s=j}^{j+T} vals[s][a] vals[s][b]] with equilibration."""
    npts = len(points_vals[j])
    G = mp.zeros(npts, npts)
    for s in range(j, j+T):
        v = points_vals[s]
        for a in range(npts):
            for b in range(npts):
                G[a, b] += v[a]*v[b]
    sc = [mp.sqrt(G[a, a]) for a in range(npts)]
    Gs = mp.zeros(npts, npts)
    for a in range(npts):
        for b in range(npts):
            Gs[a, b] = G[a, b]/(sc[a]*sc[b])
    return mp.det(Gs)*mp.fprod(sc)**2


def check_AB(j, n, m=4, T=90, Trt=70):
    atoms = tuple(range(1, m+1))
    z = (mp.mpf(2*n)-1)*PI/2
    tabs = sph_tables(z, 2*(j+T)+4)
    # values table: s -> [r_s(y_1..y_m), r_s(x_n)]
    valsSx, valsS = {}, {}
    for s in range(j, j+T):
        hv = [r_head(s, k) for k in atoms]
        valsSx[s] = hv + [r_band(s, n, tabs)]
        valsS[s] = hv
    DSx = gram_det(valsSx, j, T)
    DS = gram_det(valsS, j, T)
    ratio = DSx/DS
    # RHS of [A]: sum of drop-m squared values at x_n
    ssum = mp.mpf(0)
    for s in range(j, j+Trt):
        ssum += rt_exact_rational(s, n, atoms=atoms, tail=14)**2
    # [B]: t_{j+m}(x)
    t = mp.mpf(0)
    for s in range(j+m, j+T):
        t += r_band(s, n, tabs)**2
    print(f"  j={j}, n={n}: ")
    print(f"    [A] detG(S+x)/detG(S) = {mp.nstr(ratio, 12)}")
    print(f"        sum rt_s(x)^2      = {mp.nstr(ssum, 12)}"
          f"   rel diff = {mp.nstr(abs(ratio-ssum)/ratio, 3)}")
    print(f"    [B] t_(j+m)(x)         = {mp.nstr(t, 12)}"
          f"   eta = {mp.nstr(ratio/t - 1, 3)}")
    # pointwise consequence
    rt2 = rt_exact_rational(j, n, atoms=atoms, tail=14)**2
    rj = r_band(j+m, n, tabs)**2
    print(f"    [B'] rt_j(x)^2 = {mp.nstr(rt2, 8)}  vs r_(j+m)(x)^2 = "
          f"{mp.nstr(rj, 8)}   ratio = {mp.nstr(rt2/rj, 6)}")


def check_C(s, NMAX=20000):
    tot = mp.mpf(0)
    with mp.workdps(40):
        for n in range(1, NMAX+1):
            z = (mp.mpf(2*n)-1)*PI/2
            sj, _ = sph_tables(z, 2*s+4)
            tot += sj[2*s]*sj[2*s+2]
    # tail bound ~ integral of 1/z^2-scale envelope
    print(f"  s={s}: Sigma_(n<={NMAX}) j_(2s) j_(2s+2)(z_n) = {mp.nstr(tot, 4)}"
          f"   (target 0; tail O(1/NMAX))")


def main():
    print("[A]+[B] stage-multiplicativity and index absorption:")
    check_AB(54, 35)
    check_AB(54, 37)
    check_AB(140, 92, T=110, Trt=80)
    print("\n[A]+[B] drop-1 and drop-2 sanity (m = 1, 2), j = 54, n = 35:")
    check_AB(54, 35, m=1)
    check_AB(54, 35, m=2)
    print("\n[C] A_s cross-sum vanishing:")
    check_C(6)
    check_C(10)


if __name__ == '__main__':
    main()
