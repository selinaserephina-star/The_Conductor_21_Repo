r"""
a1_stirling_g1.py -- STEP 1 of the a-closed-form session (task file
NEXT_SESSION_TASK_a_closedform_and_inverse_design.md, TASK 1): the Stirling
expansion of the top-row lattice density to FIRST SUBLEADING order.

Object: logG2(n) = -2 ln|ell'(x_n)| (n-dependent part), the exact closed form
(lambda_peak_fastM.py, sealed folder, read-only):
  f(n) = -2[lgam(n) + lgam(M-n+1) + lgam(M+n+2A+1) - lgam(n+2A+1)]
         + 2 ln(2n+2A) + (4M-8) ln((n+A)pi)   + n-independent,   A = k-1/2 = 7/2.

CLAIM (derived at the blackboard this session, Stirling to O(1/M)):
  f(n) = M G0(u) - 6 lnM + G1(u) + const + O(1/M),  u = n/M, with
    G0(u) = -2[(1-u)ln(1-u) + (1+u)ln(1+u)] + 4 ln u          [= -2E(u):
            G0' = -2E', E'(u) = ln((1+u)/(1-u)) - 2/u -- the session-3 dE]
    G1(u) = (4A-4) ln u - ln(1-u) - (4A+1) ln(1+u) + 4A/u     [A=7/2: 10,15,14]
    (the 4A/u term: from (4M-8) ln(uM+A) -> 4A/u; the first hand pass MISSED
    it -- caught by the sympy check below, session-3-style lesson repeated)
  The -6 lnM is n-INDEPENDENT (drops in normalization): no (lnM)^2 pollution
  of the zone law -- consistent with the +/-8e-4 validation of b.

Consequences (the eta_1 density correction): with tau = (u-u*) c sqrt(M),
  ghat^2(tau) = c sqrt(M) phi(tau) [1 + eta_1(tau)/sqrt(M) + O(1/M)],
  eta_1(tau) = p1 tau + p3 tau^3,  p1 = G1'(u*)/c,  p3 = G0'''(u*)/(6 c^3)
  (G0'' (u*) = -c^2 is the session-3 Gaussian; G0''' = -2 E''').

CHECKS:
 [1] sympy: series of the exact Stirling forms in 1/M reproduces G0, -6lnM, G1
     exactly (symbolic, A symbolic).
 [2] numeric: f(n) - f(n0) via mp.loggamma at M = 1e6 and 4e6 vs
     [M G0 + G1](u) - [M G0 + G1](u0): residual must be O(1/M) (scale 1/4).
 [3] constants to 25 digits: u*, c, E''', G1'(u*), p1, p3, beta, kappa, q.
NOT RH/GRH. -- Stenberg + Claude, 2026-07-27 (a-closed-form session).
"""
import mpmath as mp
import sympy as sp

mp.mp.dps = 40
A_NUM = mp.mpf(7) / 2

# ---------- [1] symbolic Stirling ----------
u, M, Asym = sp.symbols('u M A', positive=True)
eps = sp.symbols('eps', positive=True)

def lgam_stirling(z):
    # lgamma(z) = (z-1/2) ln z - z + ln(2 pi)/2 + 1/(12 z)  (enough for O(1/M))
    return (z - sp.Rational(1, 2)) * sp.log(z) - z + sp.log(2 * sp.pi) / 2 \
        + 1 / (12 * z)

# lgamma(w+1) handled by passing w+1 directly.
f_expr = (-2 * (lgam_stirling(u * M)
                + lgam_stirling((1 - u) * M + 1)
                + lgam_stirling((1 + u) * M + 2 * Asym + 1)
                - lgam_stirling(u * M + 2 * Asym + 1))
          + 2 * sp.log(2 * u * M + 2 * Asym)
          + (4 * M - 8) * sp.log((u * M + Asym) * sp.pi))

# expand in 1/M: substitute M = 1/eps, series in eps
f_eps = f_expr.subs(M, 1 / eps)
ser = sp.series(f_eps, eps, 0, 2).removeO()
ser = sp.expand(sp.logcombine(sp.expand_log(ser, force=True), force=True))

# collect orders: 1/eps (=M), log(eps) (=-lnM), const
coeff_M = sp.simplify(ser.coeff(eps, -1))
coeff_logM = sp.simplify(-ser.coeff(sp.log(eps), 1))     # ln M coefficient
# order-1 term without logs of eps:
rest = sp.expand(ser - coeff_M / eps - (-coeff_logM) * sp.log(eps))
coeff_1 = sp.simplify(rest.coeff(eps, 0))

G0_claim = -2 * ((1 - u) * sp.log(1 - u) + (1 + u) * sp.log(1 + u)) \
    + 4 * sp.log(u)
G1_claim = (4 * Asym - 4) * sp.log(u) - sp.log(1 - u) \
    - (4 * Asym + 1) * sp.log(1 + u) + 4 * Asym / u

dM = sp.simplify(sp.expand(coeff_M - G0_claim))
print("[1] symbolic Stirling:")
print(f"    M-coefficient - G0_claim      = {dM}   (const in u expected)")
print(f"    d/du of that                  = {sp.simplify(sp.diff(dM, u))}")
print(f"    lnM coefficient               = {sp.simplify(coeff_logM)}")
d1 = sp.simplify(sp.expand(coeff_1 - G1_claim))
print(f"    O(1)-coefficient - G1_claim   = {sp.simplify(d1)}   (const in u expected)")
print(f"    d/du of that                  = {sp.simplify(sp.diff(d1, u))}")

# ---------- [3] constants ----------
ustar = mp.findroot(lambda x: mp.log((1 + x) / (1 - x)) - 2 / x,
                    mp.mpf('0.8335')).real
Epp = 1 / (1 - ustar) + 1 / (1 + ustar) + 2 / ustar ** 2
c2 = 2 * Epp
c = mp.sqrt(c2)
Eppp = 1 / (1 - ustar) ** 2 - 1 / (1 + ustar) ** 2 - 4 / ustar ** 3
G1p = (4 * A_NUM - 4) / ustar + 1 / (1 - ustar) \
    - (4 * A_NUM + 1) / (1 + ustar) - 4 * A_NUM / ustar ** 2
p1 = G1p / c
p3 = -2 * Eppp / (6 * c ** 3)          # G0''' = -2 E'''
beta = -3 / (2 * ustar * c)
kappa = 3 / (c2 * ustar)
Qp = mp.log((1 - ustar) / (1 + ustar)) / 2 - ustar / (1 - ustar ** 2)
q = 2 * Qp / (ustar * c)
print("\n[3] constants (25 digits):")
for nm, v in [("u*", ustar), ("c", c), ("E''", Epp), ("E'''", Eppp),
              ("G1'(u*)", G1p), ("p1", p1), ("p3", p3), ("beta", beta),
              ("kappa=b", kappa), ("Q~'(u*)", Qp), ("q=2Q~'/(u*c)", q),
              ("<tau eta1> = p1+3p3", p1 + 3 * p3)]:
    print(f"    {nm:<18} = {mp.nstr(v, 25)}")

# ---------- [2] numeric validation of G0/G1 vs exact lgammas ----------
def f_exact(n, Mv):
    n = mp.mpf(n); Mv = mp.mpf(Mv); A = A_NUM
    return (-2 * (mp.loggamma(n) + mp.loggamma(Mv - n + 1)
                  + mp.loggamma(Mv + n + 2 * A + 1)
                  - mp.loggamma(n + 2 * A + 1))
            + 2 * mp.log(2 * n + 2 * A)
            + (4 * Mv - 8) * mp.log((n + A) * mp.pi))

def G_model(uv, Mv):
    uv = mp.mpf(uv)
    G0 = -2 * ((1 - uv) * mp.log(1 - uv) + (1 + uv) * mp.log(1 + uv)) \
        + 4 * mp.log(uv)
    G1 = (4 * A_NUM - 4) * mp.log(uv) - mp.log(1 - uv) \
        - (4 * A_NUM + 1) * mp.log(1 + uv) + 4 * A_NUM / uv
    return Mv * G0 + G1

print("\n[2] f(n)-f(n0) vs model differences (residual, should scale 1/M):")
for Mv in (10 ** 6, 4 * 10 ** 6):
    n0 = int(round(float(ustar) * Mv))
    print(f"    M = {Mv}:")
    for du in (-0.15, -0.05, 0.02, 0.10, 0.14):
        n1 = int(round((float(ustar) + du) * Mv))
        ex = f_exact(n1, Mv) - f_exact(n0, Mv)
        md = G_model(mp.mpf(n1) / Mv, Mv) - G_model(mp.mpf(n0) / Mv, Mv)
        print(f"      du={du:+.2f}: exact-model = {mp.nstr(ex - md, 6):>14}"
              f"   (times M: {mp.nstr((ex - md) * Mv, 6)})")
