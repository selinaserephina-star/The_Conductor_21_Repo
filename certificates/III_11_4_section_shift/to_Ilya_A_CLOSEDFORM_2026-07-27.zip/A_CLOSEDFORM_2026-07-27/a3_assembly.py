r"""
a3_assembly.py -- STEP 3 of the a-closed-form session: THE MATCHING ASSEMBLY.

Derivation chain (a1: density to O(1/sqrt M); a2: sigma1 validated pointwise):
  P := (c/M^{3/2}) Sum_{n<=m} summand = model-part + (summand - model)-part,
  model(n) = M sigma0(tau_n) + sqrt(M) sigma1(tau_n), tau spacing c/sqrt(M).

  Zone (model) part, midpoint EM (endpoint terms vanish at t_c since
  sigma0(t_c) = 0):
    int_{-T}^{t_c} sigma0 = I(t_c) - 1/T + O(T^-3),  T = u* c sqrt(M),
    I(t) == -H(t)  [NEW: the session-3 quadrature I(t) is exactly -H(t);
                    hence the peak constant C_inf = 2/(c t_c)],
    (1/sqrt M) int_{-T}^{t_c} sigma1 = (1/sqrt M)[J1 + kappa c (Y(t_c) - lnT)],
    Y(t) := (1/2) ln(1+t^2)  [regulator tau/(1+tau^2) antiderivative],
    J1 := int_{-inf}^{t_c} [sigma1 - kappa c tau/(1+tau^2)] dtau
        = (c/2)[Phi(t_c) + t_c phi(t_c)] + p3 + kappa c * HR(t_c)   [CLOSED:
          all tau^k H antiderivatives reduce via H' = 1 - tau H; the p1
          dependence CANCELS -- a is independent of G1'(u*)],
    HR(t) := int_{-inf}^{t} [H(tau) - tau/(1+tau^2)] dtau  [the one surviving
          special constant: the regularized Dawson integral].

  Outer (difference) part -> -2 A_out at D-level, with
    W_inf(u) = 4u^4/(c^2 u*^2 (u*-u)^2 (u+u*)^2) - 1/(c^2(u-u*)^2) - kappa/(u-u*)
    A_out = int_0^{u*} W_inf du = (9/2 - 3 ln 2)/(c^2 u*)   [ELEMENTARY; the
          partial fractions REDERIVE kappa = 3/(c^2 u*) independently].

  ASSEMBLY (D(M) = sqrt(M)(peakF - C_inf) = b lnM + a):
    b = kappa  (reconfirmed),
    a = -Phi(t_c) - t_c phi(t_c) - (2/c) p3 - 2 kappa HR(t_c)
        + 2 kappa ln(u* c) - kappa ln(1 + t_c^2) + (6 ln2 - 7)/(c^2 u*).

CHECKS:
 [1] J1 closed form vs direct quadrature of sigma1 - kappa c rho (validates
     the antiderivative algebra AND the p1 cancellation).
 [2] A_out closed form vs direct quadrature of W_inf (and sympy integrate).
 [3] a vs the ladder: a(M) with b fixed marches -0.7536 -> -0.76988
     (lambda_theta_ladder.csv, sealed folder, read-only); target -0.770(1).
 [4] mp.identify attempts on HR(t_c) and on a.
NOT RH/GRH. -- Stenberg + Claude, 2026-07-27 (a-closed-form session).
"""
import os, math
import mpmath as mp
import sympy as sp

mp.mp.dps = 40
HERE = os.path.dirname(os.path.abspath(__file__))
SEALED = os.path.join(os.path.dirname(HERE), 'LAMBDA_SQRTM_2026-07-26')

# ---------- constants ----------
ustar = mp.findroot(lambda x: mp.log((1 + x) / (1 - x)) - 2 / x,
                    mp.mpf('0.8335')).real
Epp = 1 / (1 - ustar) + 1 / (1 + ustar) + 2 / ustar ** 2
Eppp = 1 / (1 - ustar) ** 2 - 1 / (1 + ustar) ** 2 - 4 / ustar ** 3
c2 = 2 * Epp
c = mp.sqrt(c2)
kappa = 3 / (c2 * ustar)
p3 = -Eppp / (3 * c ** 3)
G1p = 10 / ustar + 1 / (1 - ustar) - 15 / (1 + ustar) - 14 / ustar ** 2
p1 = G1p / c
beta = -3 / (2 * ustar * c)

def H(t):
    t = mp.mpf(t)
    if abs(t) > 25:
        # asymptotic (2k-1)!! series, terms added while decreasing
        s = mp.mpf(0); term = 1 / t; k = 0
        while True:
            s += term
            k += 1
            nxt = term * (2 * k - 1) / (t * t)
            if abs(nxt) >= abs(term) or abs(nxt) < mp.mpf(10) ** (-mp.mp.dps - 5):
                s += nxt
                break
            term = nxt
        return s
    return mp.sqrt(2) * mp.sqrt(mp.pi) / 2 * mp.exp(-t * t / 2) \
        * mp.erfi(t / mp.sqrt(2))

def phi(t):
    return mp.exp(-mp.mpf(t) ** 2 / 2) / mp.sqrt(2 * mp.pi)

def Phi(t):
    return mp.ncdf(t)

tc = mp.findroot(lambda t: t * H(t) - 1, mp.mpf('1.3069')).real
Cinf = 2 / (c * tc)
print(f"u*  = {mp.nstr(ustar, 25)}")
print(f"c   = {mp.nstr(c, 25)}")
print(f"t_c = {mp.nstr(tc, 25)}")
print(f"C_inf = 2/(c t_c) = {mp.nstr(Cinf, 20)}   (session-3: 0.352341123; "
      f"I(t_c) = -H(t_c) = {mp.nstr(-H(tc), 15)})")

# ---------- HR(t_c) ----------
def hr_integrand(t):
    return H(t) - t / (1 + t * t)

HR = mp.quad(hr_integrand, [-mp.inf, -30, -8, 0, tc])
# independent route: total integral of the odd integrand over R is 0, so
# HR(t) = -int_t^inf [H - rho]
HR2 = -mp.quad(hr_integrand, [tc, 8, 30, mp.inf])
print(f"\nHR(t_c) = {mp.nstr(HR, 25)}")
print(f"HR check (odd-total route) = {mp.nstr(HR2, 25)}   "
      f"diff = {mp.nstr(HR - HR2, 5)}")

# ---------- [1] J1: closed form vs quadrature ----------
J1_closed = (c / 2) * (Phi(tc) + tc * phi(tc)) + p3 + kappa * c * HR

def sigma1(t):
    t = mp.mpf(t); h = H(t); f = phi(t)
    return (c * f
            + t * (p1 * (t * h - 1) + p3 * (t ** 3 * h - t * t - 1))
            + beta * (t - h - t * t * h)
            - (p1 + 3 * p3) * h
            - (c / 2) * t * t * f)          # q + c = c/2 (q = -c/2 exact)

# finite range + analytic tail (integrand ~ s3/tau^3 + s5/tau^5)
T0 = mp.mpf(100000)
J1_fin = mp.quad(lambda t: sigma1(t) - kappa * c * t / (1 + t * t),
                 [-T0, -1000, -50, -10, 0, tc])
f1 = sigma1(-T0) - kappa * c * (-T0) / (1 + T0 * T0)
f2 = sigma1(-2 * T0) - kappa * c * (-2 * T0) / (1 + 4 * T0 * T0)
# fit f = s3/t^3 (s5 beyond reach at this T0): tail = -s3/(2 T0^2)
s3 = f1 * (-T0) ** 3
J1_quad = J1_fin - s3 / (2 * T0 ** 2)
print(f"\n[1] J1 closed = {mp.nstr(J1_closed, 18)}")
print(f"    J1 quad   = {mp.nstr(J1_quad, 18)}   "
      f"diff = {mp.nstr(J1_closed - J1_quad, 5)}   (tail s3 = {mp.nstr(s3, 6)})")

# ---------- [2] A_out: closed form vs quadrature vs sympy ----------
A_out_closed = (mp.mpf(9) / 2 - 3 * mp.log(2)) / (c2 * ustar)

def W_inf(u):
    u = mp.mpf(u)
    with mp.workdps(mp.mp.dps + 60):
        V = 4 * u ** 4 / (c2 * ustar ** 2 * (ustar - u) ** 2 * (u + ustar) ** 2)
        r = V - 1 / (c2 * (u - ustar) ** 2) - kappa / (u - ustar)
    return +r

def W_pf(u):
    # exact partial fractions: c2*W = -（3/u*)/(u+u*) + 1/(u+u*)^2 + 4/u*^2
    u = mp.mpf(u)
    return (-(3 / ustar) / (u + ustar) + 1 / (u + ustar) ** 2
            + 4 / ustar ** 2) / c2

print("\n[2] W_inf original vs partial-fraction form (algebra check):")
for uv in ('0.05', '0.3', '0.6', '0.8', '0.8335'):
    d = W_inf(mp.mpf(uv)) - W_pf(mp.mpf(uv))
    print(f"    u={uv}: diff = {mp.nstr(d, 5)}")
A_out_quad = mp.quad(W_pf, [0, ustar / 2, ustar])
print(f"    A_out closed = {mp.nstr(A_out_closed, 18)}")
print(f"    A_out quad   = {mp.nstr(A_out_quad, 18)}   "
      f"diff = {mp.nstr(A_out_closed - A_out_quad, 5)}")

us, uu, cc2, kk = sp.symbols('us u c2 k', positive=True)
Vs = 4 * uu ** 4 / (cc2 * us ** 2 * (us - uu) ** 2 * (uu + us) ** 2)
integrand = sp.simplify(Vs - 1 / (cc2 * (uu - us) ** 2)
                        - 3 / (cc2 * us) / (uu - us))
Aout_sym = sp.simplify(sp.integrate(integrand, (uu, 0, us)))
print(f"    sympy A_out  = {Aout_sym}")

# ---------- assembly ----------
a_derived = (-Phi(tc) - tc * phi(tc) - (2 / c) * p3 - 2 * kappa * HR
             + 2 * kappa * mp.log(ustar * c) - kappa * mp.log(1 + tc ** 2)
             + (6 * mp.log(2) - 7) / (c2 * ustar))
print(f"\n=== a_derived = {mp.nstr(a_derived, 15)} ===")
print(f"    (target: -0.770 +/- 0.001, ladder march -> -0.76988 at M=2.05e6)")

pieces = [("-Phi(t_c)", -Phi(tc)),
          ("-t_c phi(t_c)", -tc * phi(tc)),
          ("-(2/c) p3", -(2 / c) * p3),
          ("-2 kappa HR(t_c)", -2 * kappa * HR),
          ("+2 kappa ln(u* c)", 2 * kappa * mp.log(ustar * c)),
          ("-kappa ln(1+t_c^2)", -kappa * mp.log(1 + tc ** 2)),
          ("(6ln2-7)/(c^2 u*)", (6 * mp.log(2) - 7) / (c2 * ustar))]
for nm, v in pieces:
    print(f"      {nm:<22} = {mp.nstr(v, 12)}")

# ---------- [3] ladder comparison ----------
csv = os.path.join(SEALED, 'lambda_theta_ladder.csv')
if os.path.exists(csv):
    rows = [l.split(',') for l in open(csv).read().splitlines()[1:] if l.strip()]
    print("\n[3] ladder a(M) with b FIXED (vs a_derived):")
    bf = float(kappa)
    for r in rows:
        Mv = int(r[0]); pk = float(r[1])
        D = (pk - float(Cinf)) * math.sqrt(Mv)
        aM = D - bf * math.log(Mv)
        print(f"    M={Mv:>8}: a(M) = {aM:+.5f}   a(M)-a_derived = "
              f"{aM - float(a_derived):+.5f}")

# ---------- [4] closed-form hunting ----------
print("\n[4] identify attempts:")
print(f"    HR(t_c) = {mp.nstr(HR, 25)}")
cands = ['ln(2)', 'euler', 'ln(pi)', 'pi']
r1 = mp.identify(HR, cands)
print(f"    mp.identify(HR, [ln2, gamma, lnpi, pi]) = {r1}")
# PSLQ with the session transcendentals in the basis
vec = [mp.mpf(1), HR, mp.log(tc), mp.log(ustar), mp.log(c), mp.euler,
       mp.log(2), tc * tc, H(tc)]
names = ['1', 'HR', 'ln t_c', 'ln u*', 'ln c', 'gamma', 'ln2', 't_c^2',
         'H(t_c)']
rel = mp.pslq(vec, maxcoeff=10 ** 6, maxsteps=10 ** 4)
print(f"    pslq({names}) = {rel}")
r3 = mp.identify(a_derived, cands)
print(f"    mp.identify(a, [ln2, gamma, lnpi, pi]) = {r3}")
