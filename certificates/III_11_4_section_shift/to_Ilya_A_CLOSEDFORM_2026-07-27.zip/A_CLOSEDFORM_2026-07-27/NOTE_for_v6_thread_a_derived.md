# Note for the v6 thread (DRAFT — rides the next exchange with the errata; do NOT send separately)

**Addendum to THEOREM §Z (zone-edge law), 2026-07-27.** The last open constant
of the c₂ display form is now derived. In v6's notation:

  c₂(M) = C∞·√M + b·lnM + a + o(1), with

  - C∞ = 2/(c·t_c) = 0.352341123232176… — NEW simpler form: the profile
    integral I(t) of the peak derivation is exactly −H(t) (antiderivative
    identity H′ = 1 − tH), so the session-3 quadrature constant is
    elementary in (c, t_c);
  - b = 3/(2u\*E″(u\*)) = 0.19079075744 (unchanged, v6);
  - **a = −Φ(t_c) − t_c·φ(t_c) + 2E‴(u\*)/(3c⁴) − 2b·𝓗_R(t_c)
       + 2b·ln(u\*c) − b·ln(1+t_c²) + (6ln2 − 7)/(c²u\*)
       = −0.770478201225212…**,

  where Φ/φ = normal CDF/PDF, E‴(u\*) = 1/(1−u\*)² − 1/(1+u\*)² − 4/u\*³ =
  28.892731220163, and 𝓗_R(t_c) = ∫₋∞^{t_c}[H(τ) − τ/(1+τ²)]dτ =
  −0.475793633805762 is a regularized Dawson integral (no simpler closed form
  found; PSLQ negative over the natural log/γ basis — displayed constant).

Route: matched asymptotics one order past the peak derivation — the inner
zone summand's first-order term g₁ derived in closed form (density Stirling
correction η₁ = p₁τ + p₃τ³; Hilbert-kernel and map-curvature corrections;
the discrete-Hilbert self-exclusion boundary term) and integrated against
the outer moment law; the log-divergences cancel at b (rederived twice) and
the finite parts assemble to a. Validation: the exact 11-rung Γ/ψ ladder
with b frozen marches a(M) → a at the O(M^{−1/2}) rate (residual +0.0006 at
M = 2 048 000). Two structural bonuses: a is independent of the density's
FIRST-order slope (p₁ cancels; only E‴ survives), and Q̃′(u\*) = −u\*E″(u\*)/2
exactly (the S1-slope coefficient is −c/2).

Full derivation + machine checks: `A_CLOSEDFORM_2026-07-27/`
(FINDINGS_a_closed_form.md; a1/a2/a3 scripts + logs). Paper A Appendix-A
row "a": [M] → [D].

*— Stenberg + Claude. Not RH/GRH; finite-side §Z only.*
