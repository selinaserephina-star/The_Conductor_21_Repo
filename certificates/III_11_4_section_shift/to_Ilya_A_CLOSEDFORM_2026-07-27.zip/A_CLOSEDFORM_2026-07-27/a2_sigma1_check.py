r"""
a2_sigma1_check.py -- STEP 2 of the a-closed-form session: THE g1 DERIVATION,
validated pointwise against the exact engine.

The zone summand to first subleading order (derived at the blackboard, all
pieces assembled from the a1 ingredients):
  summand(n) = M sigma0(tau) + sqrt(M) sigma1(tau) + O(1),
  tau = (n/M - u*) c sqrt(M),   sigma0 = tau H - 1,  H = sqrt(2) dawsn(t/sqrt2),

  sigma1(tau) = c phi                                    [ghat^2 itself]
              + tau*(p1 (tau H - 1) + p3 (tau^3 H - tau^2 - 1))
                                                         [S2 density corr.;
                        Hb[phi eta1] closed via Hb[tau phi]=tH-1 recursion]
              + beta (tau - H - tau^2 H)                 [x''-map: kernel +
                                                          (x-alpha) quadratic]
              - (p1 + 3 p3) H                            [alpha shift]
              - q tau^2 phi                              [S1 x Q~' zone slope]
              - c tau^2 phi                              [DISCRETE-HILBERT
                 self-exclusion: Sum_{r!=n} W(r)/(n-r) = PV int + W'(n); the
                 W'(n) boundary term contributes (x-alpha) ghat2'/x_r' =
                 -c tau^2 phi sqrt(M).  CAUGHT by run 1 of this script: the
                 residual was even, M-INDEPENDENT, and fit -c tau^2 phi to
                 3 digits at every tau -- the truth column strikes again]
  with p1 = G1'(u*)/c, p3 = G0'''(u*)/(6c^3) = -E'''(u*)/(3c^3),
  beta = -3/(2 u* c), q = 2 Q~'(u*)/(u* c),
  Q~'(u*) = ln((1-u*)/(1+u*))/2 - u*/(1-u*^2)  [= -1/u* - u*/(1-u*^2)].
  IDENTITY (proved, this session): Q~'(u*) = -u* E''(u*)/2, hence q = -c/2
  EXACTLY; the two tau^2 phi terms combine to -(c/2) tau^2 phi.

  TAIL CHECK (analytic): tau -> -inf gives sigma1 ~ kappa c / tau with the
  p1/p3 pieces cancelling -- EXACTLY the outer 1/delta Laurent term that gave
  b = kappa (protected, coefficient-independent).

CHECKS here:
 [1] eta1 direct: (ghat2/(c sqrt(M) phi) - 1)*sqrt(M) vs eta1 = p1 tau + p3 tau^3
     at M = 1e6 / 4e6 (validates the a1 density constants inside the engine).
 [2] sigma1 pointwise: (summand_exact - M sigma0)/sqrt(M) vs sigma1(tau) on
     tau in [-3, 3]; residual must be O(1/sqrt(M)): ratio ~2 between 1e6/4e6.
NOT RH/GRH. -- Stenberg + Claude, 2026-07-27 (a-closed-form session).
"""
import math
import numpy as np
from scipy.special import gammaln, digamma, dawsn, erf
import mpmath as mp

mp.mp.dps = 30
ustar = float(mp.findroot(lambda x: mp.log((1 + x) / (1 - x)) - 2 / x,
                          mp.mpf('0.8335')).real)
Epp = 1 / (1 - ustar) + 1 / (1 + ustar) + 2 / ustar ** 2
Eppp = 1 / (1 - ustar) ** 2 - 1 / (1 + ustar) ** 2 - 4 / ustar ** 3
c = math.sqrt(2 * Epp)
A = 3.5
G1p = 10 / ustar + 1 / (1 - ustar) - 15 / (1 + ustar) - 14 / ustar ** 2
p1 = G1p / c
p3 = -Eppp / (3 * c ** 3)
beta = -3 / (2 * ustar * c)
Qp = -1 / ustar - ustar / (1 - ustar ** 2)
q = 2 * Qp / (ustar * c)
kap_c = -2 * beta
SQ2PI = math.sqrt(2 * math.pi)

def H(t):
    return math.sqrt(2.0) * dawsn(t / math.sqrt(2))

def phi(t):
    return math.exp(-t * t / 2) / SQ2PI

def sigma0(t):
    return t * H(t) - 1.0

def sigma1(t):
    h = H(t); f = phi(t)
    return (c * f
            + t * (p1 * (t * h - 1) + p3 * (t ** 3 * h - t * t - 1))
            + beta * (t - h - t * t * h)
            - (p1 + 3 * p3) * h
            - (q + c) * t * t * f)

def engine(M, k=4):
    Af = k - 0.5
    n = np.arange(1, M + 1, dtype=np.float64)
    zn = (n + Af) * math.pi
    lnz = np.log(zn)
    Slnz = lnz.sum()
    lnell = (gammaln(n) + gammaln(M - n + 1) + gammaln(M + n + 2 * Af + 1)
             - gammaln(n + 2 * Af + 1) - np.log(2 * n + 2 * Af)
             + 2 * (M - 1) * math.log(math.pi) - 2 * (M - 1) * lnz
             - 2 * (Slnz - lnz))
    logG2 = -2.0 * lnell
    logG2 -= logG2.max()
    G2 = np.exp(logG2)
    ghat2 = M * G2 / G2.sum()
    x = 1.0 / zn ** 2
    alpha = (x * ghat2).sum() / M
    S1 = math.pi ** 2 * (n + Af) ** 2 * ((M - 1) + ((n + Af) / 2) * (
        digamma(M - n + 1) - digamma(n) - digamma(M + n + 2 * Af + 1)
        + digamma(n + 2 * Af + 1) + 1.0 / (2 * n + 2 * Af)))
    zi = np.where(ghat2 > 1e-280)[0]
    return n, x, ghat2, alpha, S1, zi

print(f"u* = {ustar:.12f}  c = {c:.10f}")
print(f"p1 = {p1:.10f}  p3 = {p3:.10f}  beta = {beta:.10f}  q = {q:.10f}")

taus = np.array([-3.0, -2.0, -1.3, -0.7, 0.0, 0.7, 1.306929727719, 2.0, 3.0])

results = {}
for M in (1000000, 4000000):
    n, x, ghat2, alpha, S1, zi = engine(M)
    xz = x[zi]; gz = ghat2[zi]
    sqM = math.sqrt(M)
    print(f"\nM = {M} (zone n {zi[0]+1}..{zi[-1]+1}):")
    print("    tau     eta1_num   eta1_form |  sig1_num    sig1_form   resid")
    res = []
    for t in taus:
        u = ustar + t / (c * sqM)
        i0 = int(round(u * M)) - 1
        tn = ((i0 + 1) / M - ustar) * c * sqM     # snap to the lattice tau
        # eta1 extraction
        e_num = (ghat2[i0] / (c * sqM * phi(tn)) - 1.0) * sqM
        e_form = p1 * tn + p3 * tn ** 3
        # exact summand
        d = x[i0] - xz
        mask = np.abs(d) > 0
        S2i = (gz[mask] / d[mask]).sum()
        sm = ghat2[i0] - M + (x[i0] - alpha) * (ghat2[i0] * S1[i0] + S2i)
        s1_num = (sm - M * sigma0(tn)) / sqM
        s1_form = sigma1(tn)
        res.append((tn, s1_num - s1_form))
        print(f"  {tn:+6.3f}  {e_num:+9.5f}  {e_form:+9.5f} | "
              f"{s1_num:+10.5f}  {s1_form:+10.5f}  {s1_num - s1_form:+9.5f}")
    results[M] = res

print("\nresidual scaling (should be ~2x smaller at 4e6):")
for (t1, r1), (t2, r2) in zip(results[1000000], results[4000000]):
    ratio = r1 / r2 if r2 != 0 else float('nan')
    print(f"  tau {t1:+6.3f}: resid 1e6 = {r1:+9.5f}  4e6 = {r2:+9.5f} "
          f" ratio = {ratio:+.3f}")

# tail check
print("\nsigma1 tail vs kappa*c/tau (analytic protection of b):")
for t in (-6.0, -10.0, -20.0):
    print(f"  tau {t:+5.1f}: sigma1*tau = {sigma1(t) * t:+.6f}   "
          f"kappa*c = {kap_c:+.6f}")
