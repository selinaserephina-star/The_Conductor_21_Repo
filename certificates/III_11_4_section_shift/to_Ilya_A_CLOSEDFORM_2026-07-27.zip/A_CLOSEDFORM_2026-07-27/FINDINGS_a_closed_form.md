# FINDINGS — a's CLOSED FORM DERIVED AND VALIDATED: a = −0.770478201225212…, the §Z inner–outer matching constant, landing on the ladder pin −0.770(1); §Z CLOSES FULLY

**Merkabit · Stenberg + Claude · 2026-07-27 (a-closed-form session) ·
`A_CLOSEDFORM_2026-07-27/`.** Scripts: `a1_stirling_g1.py` (density to first
subleading order), `a2_sigma1_check.py` (g₁ derived + validated pointwise),
`a3_assembly.py` (matching assembly + all cross-checks), `a_final_digits.log`
(dps-60 constants) + logs. Executes TASK 1 of
`NEXT_SESSION_TASK_a_closedform_and_inverse_design.md`. Sealed
`LAMBDA_SQRTM_2026-07-26/` untouched (read-only inputs). **Not RH/GRH.**

## 0. THE RESULT

The zone-edge law (THEOREM §Z) is now fully derived:

  **c₂(M) = 0.352341123·√M + b·lnM + a**, with every constant closed:

  - peak constant **C∞ = 2/(c·t_c) = 0.352341123232176…** (NEW simpler form:
    the session-3 integral I(t) is exactly −H(t), see §2.1),
  - **b = κ = 3/(c²u\*) = 3/(2u\*E″(u\*)) = 0.19079075744** (session 6c),
  - **a = −Φ(t_c) − t_c·φ(t_c) + 2E‴(u\*)/(3c⁴) − 2κ·𝓗_R(t_c)
       + 2κ·ln(u\*c) − κ·ln(1+t_c²) + (6ln2 − 7)/(c²u\*)
       = −0.770478201225212464529189896…**

with u\* = 0.833556559600965 (root of ln((1+u)/(1−u)) = 2/u), c = √(2E″(u\*))
= 4.343245961775, t_c = 1.306929727719281 (root of tH(t) = 1,
H(t) = √2·dawsn(t/√2)), Φ/φ the normal CDF/PDF, E‴(u\*) = 28.892731220163,
and **𝓗_R(t_c) = ∫₋∞^{t_c}[H(τ) − τ/(1+τ²)]dτ = −0.475793633805762** — the
one surviving special constant (a regularized Dawson integral; PSLQ finds no
small relation over {ln t_c, ln u\*, ln c, γ, ln2, π}: displayed-quadrature
constant, the honest closed form, per the task file's stated fallback — every
OTHER piece is elementary in the session's constants).

**Validation (the task's gate): the derived a lands on the pinned −0.770 ±
0.001** — and the exact 11-rung ladder (b frozen at the closed form) marches
INTO it monotonically: a(M) − a = +0.0169 (M = 2000) → +0.0006 (M = 2 048 000),
consistent with a clean O(M^{−1/2}) next correction (0.0169/32 ≈ 0.0005 ✓ —
the march ratio equals the √M ratio). **§Z closes; Paper A Appendix-A row "a"
flips [M] → [D].**

## 1. The derivation chain (matched asymptotics, second order)

Object: D(M) := √M·(peak F − C∞) = b·lnM + a. Route: the exact top-row prefix
sum split as model + remainder, model(n) = M·σ₀(τ_n) + √M·σ₁(τ_n),
τ = (n/M − u\*)·c√M, σ₀ = τH − 1 (session 3).

1. **Density to first subleading order** (`a1`): logG2(n) = M·G₀(u) − 6lnM +
   G₁(u) + O(1/M) with G₀ = −2[(1−u)ln(1−u) + (1+u)ln(1+u)] + 4lnu (= −2E,
   Laplace point u\* ✓) and **G₁(u) = 10lnu − ln(1−u) − 15ln(1+u) + 14/u**
   (A = 7/2). The −6lnM is n-independent — no (lnM)² pollution, consistent
   with b's ±8e−4 validation. Hence ĝ² = c√M·φ(τ)[1 + η₁(τ)/√M],
   η₁ = p₁τ + p₃τ³, p₁ = G₁′(u\*)/c = −2.377299, p₃ = −E‴(u\*)/(3c³) =
   −0.117550. Validated: residual×M is M-independent at M = 10⁶/4·10⁶.
2. **g₁ ≡ σ₁ derived** (`a2`): assembling ĝ²-direct, S2 (density correction
   via Hb[τ^kφ] closed forms; kernel x″-correction; α-shift), the S1×Q̃′ zone
   slope, and the discrete-Hilbert boundary term:
     **σ₁(τ) = cφ − (c/2)τ²φ + τ[p₁(τH−1) + p₃(τ³H−τ²−1)]
               + β(τ − H − τ²H) − (p₁+3p₃)H**,  β = −3/(2u\*c).
   Pointwise validation vs the exact Γ/ψ engine: residual 3e−3…8e−3 at
   M = 10⁶, halving at 4·10⁶ (ratio 1.96…2.04 at every τ) — clean O(1/√M).
   Tail: σ₁ → κc/τ with the p₁/p₃ pieces cancelling — reconfirms b and
   protects it from the density corrections (structural).
3. **Assembly** (`a3`): zone integral (σ₀-tail gives +2/(c²u\*); σ₁'s κc/τ
   tail gives κ·lnM + the ln(u\*c), ln(1+t_c²) matching constants; J₁ =
   (c/2)[Φ(t_c) + t_cφ(t_c)] + p₃ + κc𝓗_R(t_c) in closed form — validated vs
   quadrature to 8e−20) + outer integral (W∞ elementary by partial fractions:
   A_out = (9/2 − 3ln2)/(c²u\*), sympy-confirmed; its 1/δ² and 1/δ
   coefficients independently REDERIVE the leading tail and κ = 3/(c²u\*) —
   b twice-derived). Endpoint/EM terms vanish at t_c because σ₀(t_c) = 0.

## 2. Structural findings along the way (new, worth recording)

1. **I(t) ≡ −H(t).** The session-3 profile integral I(t) = ∫[τH−1]dτ has the
   elementary antiderivative −H (H′ = 1 − τH). So F̃ = (2/c)H(t) and the peak
   constant is simply **C∞ = 2/(c·t_c)** with t_cH(t_c) = 1. (Session 3
   computed I by quadrature — equal to 15 digits.)
2. **Q̃′(u\*) = −u\*E″(u\*)/2 exactly** (one-line proof from ln((1−u\*)/(1+u\*))
   = −2/u\*). Hence the S1 zone-slope coefficient q = 2Q̃′/(u\*c) = −c/2: the
   S1 term and the discrete-Hilbert term combine into −(c/2)τ²φ.
3. **a is independent of G₁′(u\*)**: the density-slope p₁ cancels identically
   in the prefix integral at the peak (the α-shift term eats it). Only the
   CUBIC density correction p₃ (i.e. E‴) survives into a.
4. **b is doubly protected**: the κc/τ tail of σ₁ is p₁/p₃-independent, and
   the outer partial fractions rederive κ — the log coefficient cannot be
   moved by any density-detail error.

## 3. Two traps caught by the machine checks (register-worthy)

1. **The 4A/u Stirling term** (a1, sympy check): the O(1) expansion of
   (4M−8)·ln(uM+A) contributes 4A/u to G₁ — the first hand pass missed it
   (would have shifted p₁; harmless for a by §2.3, but wrong η₁). Same lesson
   as session 3's Q: never trust the hand expansion without the symbolic or
   truth column.
2. **Discrete-Hilbert self-exclusion** (a2, exact-engine check): converting
   S2 = Σ_{r≠n}·/(x_n−x_r) to a PV integral needs the boundary term
   Σ_{r≠n}W(r)/(n−r) = PV∫ + **W′(n)** — the excluded-diagonal derivative.
   It contributes −c·τ²φ·√M to the summand (O(√M), NOT small). Diagnostic
   signature that found it: an even, M-INDEPENDENT residual fitting −cτ²φ to
   3 digits at every τ. The Poisson "discreteness is exponentially small"
   argument covers the smooth part only — **the excluded point is not
   exponentially small.** NEW TRAP for the register.

## 4. Grades

| claim | grade |
|---|---|
| G₀/−6lnM/G₁ expansion (incl. 4A/u) | DERIVED (sympy-verified symbolically) + numeric residual×M M-independent |
| η₁ = p₁τ + p₃τ³; p₁, p₃ closed | DERIVED + validated in-engine (1e6/4e6) |
| σ₁ (g₁) closed form | **DERIVED + pointwise-validated, residual O(1/√M) ratio 2.00 ± 0.04** |
| I ≡ −H; C∞ = 2/(c t_c); Q̃′(u\*) = −u\*E″/2; q = −c/2 | PROVEN (one-line identities, machine-confirmed) |
| J₁ closed form; p₁-cancellation | DERIVED; quadrature cross-check 8e−20 |
| A_out = (9/2 − 3ln2)/(c²u\*) | PROVEN (partial fractions + sympy + quadrature) |
| **a closed form (§0), = −0.770478201225212…** | **DERIVED; lands on the −0.770(1) pin; ladder marches into it at the O(1/√M) rate** |
| 𝓗_R(t_c) elementary closed form | NOT FOUND (PSLQ negative over the natural basis) — displayed quadrature constant, 30 digits |
| O(1/√M) correction to D(M) | measured only (the march); derivation not attempted |

*— Stenberg + Claude, 2026-07-27. The last constant of §Z surrendered to the
same two-step every constant here has: expand one order deeper than feels
necessary, then let the exact engine vote. The bill for the log was b; the
tip, it turns out, was a Dawson integral.*
