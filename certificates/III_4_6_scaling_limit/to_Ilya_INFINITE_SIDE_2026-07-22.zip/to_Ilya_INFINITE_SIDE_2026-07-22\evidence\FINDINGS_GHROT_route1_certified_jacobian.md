# FINDINGS — G-HROT route 1: the certified atom→Jacobi Jacobian (T2a-QT ceiling)

**Merkabit · Stenberg + Claude · 2026-07-22 (INFINITE_SIDE campaign, item 1).** Executes
route 1 of `NEXT_SESSION_TASK_GHROT_khat_lemma.md`: replace the float-FD sensitivity
value (52.667) by a CERTIFIED ceiling via per-direction first-order arb jets at the exact
frozen centers. Scripts `ghrot_route1_jacobian_arb.py`, `ghrot_route1_curvature_arb.py`
(+ logs). Not RH/GRH.

## The certificate structure

For each ladder (drop-4/drop-1 × D/F), the full Jacobian ∂α_j/∂x_m, ∂β_j/∂x_m is
enclosed in arb balls by M per-direction first-order jet passes through the fixed-weight
Lanczos map, value parts EXACT at the frozen centers (the configuration G-P2 proved
stable; ball-radius value parts are the recorded dead end and are not used). Two layers
of validation, both exact:

- **Sum rules** (from `J(x+ε𝟙) = J(x)+εI` exactly): every row must satisfy
  `Σ_m ∂α_j/∂x_m = 1` and `Σ_m ∂β_j/∂x_m = 0`. Checked per row against accumulated ball
  radii + float slop — a JOINT certificate of all M columns of a system at once.
- **N=60 cross-check** against an independent float64 forward-difference Jacobian:
  certified max L1(α) = 23.1005 vs FD 23.1007 (1e-5 rel), radii 0.

## Toolchain discovery: reorthogonalization was the instability

- WITH full reorth (the G-P2/κ̂-script pattern): prec 8192 at N=149 → jet radii **inf**
  (the reorth c-coefficient subtractions inject the dependency noise); needs prec 16000,
  ~206 s/direction.
- WITHOUT reorth (plain three-term recurrence — an exact-arithmetic no-op, so rigor is
  unaffected): prec 8192 at N=149 → **all radii 0.0**, ~5 s/direction. **40× cheaper at
  equal (better) certification.** Reusable for every future arb-jet campaign on this
  toolchain (G-P2 reruns, F-lattice work).

## Certified results (prec 8192, no reorth, radii 0 throughout)

**First-order Jacobian ceilings** (production, N=149 ladders; sum-rule deviations all
≤ 9e-16, jet radii all 0.0):

| system | max_j L1(α) certified | max_j L1(β) certified | box-worst ‖dJ‖∞(1st) ≤ |
|---|---|---|---|
| drop-4 D | **52.6670** (FD: 52.667) | 25.3708 (FD: 25.371) | 6.0074e-11 |
| drop-4 F | 64.7129 | 30.6788 | 6.5013e-11 |
| drop-1 D | 52.7277 | 25.3533 | 2.4641e-10 |
| drop-1 F | 64.5998 | 30.5071 | 1.7213e-10 |

**Pencil assembly** (as in the Abel close, ‖dM‖ ≤ |a+sgn|·dJ_D + dJ_F):

| pencil | ‖dM‖∞(1st) ≤ | δ_center | verdict | headroom |
|---|---|---|---|---|
| drop-4 aJ_D+bI−V | 1.431e-10 | 5.820e-5 | POSITIVE | 4.07e5× |
| drop-4 aJ_D+bI+V | 1.071e-10 | 4.220e-4 | POSITIVE | 3.94e6× |
| drop-1 aJ_D+bI−V | 4.925e-10 | 1.088e-2 | POSITIVE | 2.21e7× |
| drop-1 aJ_D+bI+V | 3.446e-10 | 1.257e-3 | POSITIVE | 3.65e6× |

**Box-edge robustness exhibit** (`corner4` mode; drop-4 D re-certified at the exact
dyadic sample points γ ± 1e-10, i.e. both ℓ∞ box edges): max_j L1(α) = **52.6670**,
L1(β) = **25.3708** at BOTH edges — identical to the center to every printed digit,
radii 0.0, sum rules ≤ 9e-16. (Finitely many points, so the grade is unchanged — but
the Jacobian is flat across the box at ball grade, exactly as the ~1e-20 curvature
predicts.)

**Certified center curvature** (2nd-order jets along box-scaled adversarial directions,
drop-4 D; direction chosen by FD sign-alignment oracle, certification independent of the
choice): worst sampled `max_j |α_j''| = 2.9e-20` (random ±), sign-aligned ≤ 2.3e-21,
uniform 1.1e-22 — all dd-radii 0.0. Taylor remainder `(1/2)|α''| ≤ 1.5e-20`, i.e. **9
orders below the first-order term (~3e-11) and 15 below the binding margin (5.8e-5).**

## Grade statement (the honest accounting)

- The first-order sensitivity constant is now **ball-certified with NO unproven lemma at
  the center** — the Abel close's κ̂-excess allowance (derivative-pairing part certified
  numerically, not proven) is ELIMINATED from the first-order term. Exact sum rules
  validate every column jointly.
- What remains for a fully-PROVEN uniform theorem is ONLY the box-uniformity of the
  curvature (the Taylor remainder is `(1/2)α''(t*)` at an unknown t* in the box; we
  certify t=0 and sample adversarial directions). NB the residual class per the ledger's
  in-place correction: NOT "P1" (the uniform-in-j growth law is a THEOREM — caustic
  theorem G-D2b/F10); this is the finite-config certified-numeric allowance class. Now
  QUANTIFIED: for the ceiling to fail, the curvature would have to grow by >15 orders of
  magnitude inside a box of ℓ∞-radius 2.25e-11 — while α_j(ξ) ∈ [0, x_max] remains a
  priori bounded at every real box configuration (any ξ in the box is a valid positive
  atomic measure; min atom gap 9e-5 ≫ 1e-10, weights fixed).
- **T2a-QT grade: CERTIFIED-as-computed (Abel; κ̂-excess + transport allowances) →
  CERTIFIED-first-order-exact, curvature-residual only.** The residual set strictly
  shrinks; the task's success criterion (any rigorous ceiling < 7.4e5 vs measured 53) is
  met at first order by direct ball computation.

## Files

`ghrot_route1_jacobian_arb.py` + `ghrot_route1_jacobian_{validate,pilot,prod4,prod1}_run.log`;
`ghrot_route1_curvature_arb.py` + `ghrot_route1_curvature_run.log`. Builds on:
`T2_gap_closure_2026-07-22/CLOSURE_T2a_QT_abel.md` (the prior grade),
`FINDINGS_GHROT_reduction.md` (the reduction + dead ends), `t2_gp2_jet_hessian_arb.py`
(the jet pattern). Ledger: EVIDENCE_CHAIN §9 entry this session.
