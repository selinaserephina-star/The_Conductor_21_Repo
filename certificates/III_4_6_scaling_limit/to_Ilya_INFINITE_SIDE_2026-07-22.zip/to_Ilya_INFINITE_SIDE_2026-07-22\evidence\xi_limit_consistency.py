# xi_limit_consistency.py — INFINITE-SIDE item 2 (xi-operator limit), 2026-07-22.
# Consistency numerics for the layer limit-dynamics identification:
#   (1) ALTERNATION: sign(g_j) = (-1)^j at finite N (proven via Thm-1 Step 5 sign chain;
#       verified here to the float noise floor).
#   (2) EXACT DIRICHLET DECOMPOSITION (algebra, any alternating vector, finite N):
#       <e0, J e0> = sum_j be_j (gam_j - gam_{j+1})^2 + sum_j (b_j - be_{j-1} - be_j) gam_j^2,
#       gam_j = |g_j|  ==  (1/N) sum_{n<=N} x_n   (machine identity check).
#   (3) THE NEW LIMIT TEST: on layer windows [xi1, xi2],
#       N * sum_{j in window} be_j (gam_j - gam_{j+1})^2  -->  int (sqrtG)'(xi)^2/(16 xi^2) dxi
#       with G from the PROVEN Fredholm closed form (Nystrom, m1_horizon_fredholm_profile
#       pattern). This tests the operator-side limit against the horizon density G —
#       the mandated nontrivial moment identity of item 2.
#   (4) two-scale split: N*A_N (Dirichlet part) and N*B_N (potential part) totals,
#       N-stability; N(A+B) = sum_{n<=N} x_n -> 1/2 exactly.
# Not RH/GRH.
import numpy as np, math, time
from numpy.polynomial.legendre import leggauss

def odd_system(N):
    n = np.arange(1, N + 1)
    z = (n - 0.5) * np.pi
    x = z ** -2.0
    u = x ** 2 / np.sum(x ** 2)          # ODD weights u_n = x_n^2/M2
    return x, u

def lanczos_modes(x, u):
    """Lanczos on mult-by-x in L2(nu), start = the function 1 (vector sqrt(u)).
    Returns Jacobi data (al, be) and mode matrix W with W[j,n] = w_j[n]."""
    N = len(x)
    v = np.sqrt(u); V = [v]
    al = []; be = []
    w = x * v; a = v @ w; al.append(a); w = w - a * v
    for j in range(1, N):
        b = math.sqrt(w @ w); be.append(b)
        vn = w / b
        for q in V: vn = vn - (q @ vn) * q
        vn /= math.sqrt(vn @ vn)
        V.append(vn)
        w = x * vn - b * V[-2]
        a = vn @ w; al.append(a); w = w - a * vn
    return np.array(al), np.array(be), np.array(V)

# ---- Fredholm closed form for G (proven; Nystrom pattern from m1_horizon_fredholm_profile) ----
def logG(xi, M=240):
    if xi <= 0: return -np.inf
    L = 2.0 * xi * xi / np.pi
    x, w = leggauss(M)
    t = 0.5 * (x + 1.0); wt = 0.5 * w
    tu = t[:, None] + t[None, :]; tv = t[:, None] - t[None, :]
    Sd = np.where(np.abs(tv) < 1e-14, L, np.sin(L * tv) / np.where(np.abs(tv) < 1e-14, 1.0, tv))
    Ss = np.sin(L * tu) / tu
    A = np.sqrt(wt)[:, None] * np.sqrt(wt)[None, :] / np.pi
    lp = np.linalg.slogdet(np.eye(M) - A * (Sd + Ss))[1]
    lm = np.linalg.slogdet(np.eye(M) - A * (Sd - Ss))[1]
    return np.log(2.0 * xi) + 2.0 * (lp - lm)

def dirichlet_integral(x1, x2, h=0.02):
    """int_{x1}^{x2} (sqrtG)'^2 / (16 xi^2) dxi via central differences of sqrt(G)."""
    xs = np.arange(x1 - h, x2 + 2 * h, h)
    sq = np.array([math.exp(0.5 * logG(x)) for x in xs])
    d = (sq[2:] - sq[:-2]) / (2 * h)
    xin = xs[1:-1]
    mask = (xin >= x1) & (xin <= x2)
    return np.trapezoid(d[mask] ** 2 / (16 * xin[mask] ** 2), xin[mask])

LOG = open(__file__.replace('.py', '_run.log'), 'a')
def log(s):
    print(s, flush=True); LOG.write(s + '\n'); LOG.flush()

log(f"=== xi-limit consistency @ {time.strftime('%Y-%m-%d %H:%M:%S')} ===")
WINDOWS = [(1.0, 2.0), (1.5, 2.5), (0.8, 3.0)]
for N in (400, 1600):
    t0 = time.time()
    x, u = odd_system(N)
    al, be, V = lanczos_modes(x, u)
    e0 = np.full(N, 1.0 / math.sqrt(N))
    g = V @ e0
    # (1) alternation vs noise floor
    sgn = np.sign(g) * ((-1.0) ** np.arange(N))
    noise = 1e-11
    bad = np.sum((sgn < 0) & (np.abs(g) > noise))
    jmax_ok = np.max(np.where(np.abs(g) > noise)[0])
    log(f"[N={N}] alternation sign(g_j)=(-1)^j: {'OK' if bad == 0 else f'{bad} FAIL'} "
        f"(all j with |g_j| > {noise:.0e}; usable modes j <= {jmax_ok}, xi <= {jmax_ok/math.sqrt(N):.2f})")
    # (2) exact decomposition identity
    gam = np.abs(g)
    A = float(np.sum(be * (gam[:-1] - gam[1:]) ** 2))
    pot = al.copy(); pot[:-1] -= be; pot[1:] -= be
    B = float(np.sum(pot * gam ** 2))
    lhs = float(g @ (al * g) + 2 * np.sum(be * g[:-1] * g[1:]))
    rhs = float(np.mean(x))
    log(f"[N={N}] identity <e0,Je0> = A+B: |A+B-lhs| = {abs(A+B-lhs):.2e}, "
        f"|lhs-(1/N)Sum x| = {abs(lhs-rhs):.2e}")
    # (4) two-scale totals
    Sx = float(np.sum(x))
    log(f"[N={N}] N*A = {N*A:.6f}   N*B = {N*B:.6f}   N(A+B) = {N*(A+B):.6f} "
        f"(exact Sum_n x_n = {Sx:.6f}; -> 1/2 as N -> inf)")
    # (3) layer-window Dirichlet vs the Fredholm-G integral
    for x1, x2 in WINDOWS:
        j1, j2 = int(x1 * math.sqrt(N)), min(int(x2 * math.sqrt(N)), N - 2)
        Aw = N * float(np.sum(be[j1:j2] * (gam[j1:j2] - gam[j1 + 1:j2 + 1]) ** 2))
        Iw = dirichlet_integral(x1, x2)
        log(f"[N={N}]   window [{x1},{x2}]: N*A_window = {Aw:.6f}   "
            f"int (sqrtG)'^2/(16 xi^2) = {Iw:.6f}   ratio {Aw/Iw:.4f}")
    log(f"[N={N}] ({time.time()-t0:.0f}s)")
log("done.")
LOG.close()
