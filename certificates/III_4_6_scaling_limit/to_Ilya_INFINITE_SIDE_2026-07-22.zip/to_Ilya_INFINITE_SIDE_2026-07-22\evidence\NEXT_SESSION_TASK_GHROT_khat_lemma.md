# NEXT-SESSION TASK — G-HROT: the explicit κ̂-conditioning constant (the T2a-QT ceiling)

> **STATUS 2026-07-22 (same day, later session): ROUTE 1 EXECUTED — first-order ceiling
> CERTIFIED.** See `FINDINGS_GHROT_route1_certified_jacobian.md`: per-direction arb jets
> at the exact centers give the full Jacobian at ball grade (radii 0.0, exact sum rules
> Σ∂α=1/Σ∂β=0 as joint validation), max_j L1(α) = 52.6670 (d4-D) … 64.71 (d4-F) vs the
> required < 7.4e5 — criterion met with 4 orders of slack; all four pencils POSITIVE at
> true quantiles (headroom ≥ 4.07e5×). Curvature companion: center remainder ≤ 1.5e-20.
> Toolchain: NO-reorth three-term recursion is the stable+40×-cheaper jet configuration.
> Remaining for the fully-PROVEN uniform tag: box-uniformity of the curvature only
> (finite-config numeric allowance class — NOT "P1", per the ledger's G-D2b/F10
> correction). Route 2 (Uvarov/Fredholm structural Lipschitz) stays open as the
> theorem-grade close.

**Staged 2026-07-22 (Stenberg + Claude). Goal: prove the ONE remaining lemma that
upgrades T2a-QT from CERTIFIED-modulo-ceiling to fully CERTIFIED — a rigorous ceiling
on the quantile→Jacobi sensitivity. Ledger item 3.8. Not RH/GRH.**

## The object and what is ALREADY PROVEN (do not re-derive)

Frozen chi8 production pair: atoms x_n (298 certified quantile enclosures @ 1e-10),
Jacobi matrix J from Lanczos with FIXED first-component weights. The reduction is
PROVEN and verified (`T2_gap_closure_2026-07-22/FINDINGS_GHROT_reduction.md` +
`ghrot_reduction_check.py`; both SENT in to_Ilya_T2a_gap_closure_2026-07-22):

  **‖J′ − J‖₂ ≤ max_n|Δx_n| + 2·x_max·‖U − U′‖**

where U = the Jacobi eigenvector matrix (columns φ_n, first components √w_n FIXED).
So the entire ceiling reduces to an ε-Lipschitz bound on the frame rotation:

  **PROVE: ‖U − U′‖ ≤ C′·max_n|Δx_n| with ANY explicit C′ < 1.6e6.**

Measured truth: C′ ≈ 10–85 (bounded, O(10¹)); operator-norm sensitivity ‖ΔJ‖₂/max|Δx|
≈ 1.0–1.5. So there are ~4 ORDERS OF MAGNITUDE of slack. The certified inputs that
exist: κ̂ = 5.5956 strict enclosure [±2e-20] (to_Ilya_T2a_khat_addendum + gap-closure
packages); box-worst ‖ΔJ‖∞ ≤ 6.69e-11; all four PSD margins with headroom ≥ 4,265×.

## Known dead ends (recorded — do not repeat)

- Davis–Kahan: CIRCULAR + VACUOUS (min atom gap ~9e-5 ≪ 2x_max ≈ 0.47).
- Trivial ‖U−U′‖ ≤ 2: does not shrink with ε.
- The ε-Lipschitz property holds ONLY because the norming constants w_n are FIXED
  while eigenvalues move — i.e., this IS the inverse-spectral / κ̂-conditioning
  structure (κ̂ = 5.5956 is this constant's scale). A generic eigenvector-perturbation
  argument cannot work; the fixed-first-row structure must be used.

## Attack routes (in order of promise)

1. **Validated forward-AD / jet route (the pragmatic close).** The G-P2 session built
   exact ball-grade 2nd-order jets THROUGH Lanczos (flint-arb, prec 16000, all rows
   radius 0: `t2_gp2_jet_hessian_arb.py`, sent). The same machinery gives a CERTIFIED
   first-order Jacobian ∂J/∂x_n at the center plus a certified 2nd-derivative bound
   over the 1e-10 box ⇒ a rigorous interval ceiling on the sensitivity over the box.
   Any value < 7.4e5 closes T2a-QT. This is finite, mechanical, and entirely in our
   certified toolchain. (AWS not needed — single-threaded arb job.)
2. **Inverse-spectral lemma via the Uvarov/Fredholm dictionary (the structural close).**
   NEW since the horizon theorem: finite-section quantities are EXACT Fredholm-factor
   deformations of explicit infinite-system data (to_Ilya_THEOREM_M1_HORIZON, Part I).
   The map x → (J with fixed weights) is a composition of Hankel/CD-kernel objects
   whose x-derivatives are rank-structured; a displayed Lipschitz constant in terms of
   κ̂ and the Christoffel functions may fall out. Uniform statement (OUR K1/κ̂ lane —
   Theorems 1–2 era-2; NOT pre-assigned to IB).
3. **λ-side / Lambert route:** the uniform measure in λ = 1/x is the Lambert S-fraction
   system directly; sensitivity of S-fraction coefficients to atom perturbations at
   fixed masses may have classical Stieltjes-continued-fraction bounds.

## Success criteria

- Any explicit, rigorous C′ < 1.6e6 (route 1 gives a number; route 2 gives a formula).
- Then: flip T2a-QT to CERTIFIED (full), ledger item 3.8 closed, §9 entry, and the
  T2a lane is DONE end-to-end at production grade.

## Files to build on

`T2_gap_closure_2026-07-22/CLOSURE_T2a_QT_abel.md` — the close that SET the current grade
(T2a-QT CERTIFIED-as-computed via certified-κ̂ Abel, headroom 4,265×); its "honest
residual" paragraph defines exactly what this task buys (the uniform κ̂ proof / rigorous
ceiling). Read it first to avoid re-deriving or mis-grading the Abel route.
`T2_gap_closure_2026-07-22/FINDINGS_GHROT_reduction.md`, `ghrot_reduction_check.py`
(+log); `T2_gap_closure_2026-07-22/t2_gp2_jet_hessian_arb.py` (the arb-jet pattern);
κ̂ enclosure: `t2a_khat_enclosure.py` (+log); the T2a working folder
`T2a_pencil_certification_2026-07-21/`. Ledger: EVIDENCE_CHAIN §9 entries of 2026-07-22
(G-HROT reduction; T2a-QT close).
