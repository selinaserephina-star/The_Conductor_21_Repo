# FINDINGS — the ξ-operator limit: isometry, alternation, and the two-scale Dirichlet dynamics

**Merkabit · Stenberg + Claude · 2026-07-22 (INFINITE_SIDE campaign, item 2, first
session).** Executes the construction task `NEXT_SESSION_TASK_xi_operator_limit.md`. The
limit object is IDENTIFIED and every prediction passes its consistency check; the naive
candidate ("N·J → multiplication by 1/(4ξ²)") is REFUTED and replaced by the correct
two-scale structure. Scripts `xi_limit_consistency.py`, `xi_limit_coeff_profile.py`
(+ logs). Model lattice z_n = (n−½)π only; no production/chi8 claims. Not RH/GRH.

## A. Alternation is a THEOREM at finite N

`sign(g_j) = (−1)^j` for every j < N. Proof chain (all pieces in
`WRITEUP_M1_HORIZON_exact_layer_theorem.md` §1): `g_j = √(M2/N)·⟨1/x, p_j⟩_ν`,
`p_j = Q_j/‖Q_j‖`, and Step 5 gives `⟨1/x, Q_j⟩ = h̃_j/(2M2·P̃_j(0))`, so
`sign(g_j) = sign(P̃_j(0)) = (−1)^j` (monic OPs of a measure on (0,∞) alternate at 0 —
classical, and explicit here via the (4j−1)!! law). Verified: all usable modes, N ≤ 6400.
**Consequence: e₀'s mode profile is an alternating (band-top) wave times a positive
envelope γ_j = |g_j| — this kills the naive multiplication limit and makes the layer
dynamics a second-difference (Dirichlet) object.**

## B. The boundary-layer isometry (part 1 of the task) — proof assembled

With `(T_N e)(ξ) = N^{1/4}⟨e, w_{⌊ξ√N⌋}⟩` on the ENVELOPE (signs removed):
`‖T_N e₀‖² = Σ_j g_j² = 1` EXACTLY for every N; the certified scaling law gives
`(T_N e₀)²(ξ) → G(ξ)` pointwise (rate C(ξ)/√N on compacts, Part II); norms equal and
pointwise convergence ⇒ **T_N e₀ → √G in L²(0,∞)** by Riesz–Scheffé — no domination
argument needed, though the Gaussian tail 4ξe^{−4ξ²/π} supplies an explicit rate.
Grade: proof COMPLETE conditional on the Part II scaling-lemma constants (displayed
grade); unconditional at certified-numeric grade. √G(ξ) is THE infinite
uniform-normalization vector, living on the caustic scale.

## C. The dynamics is TWO-SCALE (the naive candidate refuted, replaced)

Exact algebraic decomposition (any alternating vector; machine-checked to 2e-19):
  `⟨e₀, J e₀⟩ = A_N + B_N`,
  `A_N = Σ_j a_{j+1}(γ_j − γ_{j+1})²` (Dirichlet part),
  `B_N = Σ_j (b_j − a_j − a_{j+1})γ_j²` (potential part),
and `N⟨e₀, Je₀⟩ = Σ_{n≤N} x_n → 1/2` exactly.

**C1. Fixed-mode scale (j = O(1)) carries ALL the energy.** With the exact infinite
Lambert data (`b_j = α_{2j+1}+α_{2j+2}`, `a_j² = α_{2j}α_{2j+1}`, `α_m = 1/((2m−1)(2m+1))`)
and `ĝ_j = √((4j+3)/2)`:
  `A_∞ = 0.023093`, `B_∞ = 0.476907`, **`A_∞ + B_∞ = 0.500000`** (JMAX = 2e6),
matching the measured `N·A_N = 0.0228`, `N·B_N = 0.4771` (N=1600, trending in). The
identity `A_∞ + B_∞ = m̃_0/2 = 1/2` is provable outright via the measure representation
(e₀ ↔ √(M2/N)·(1/x), so ⟨e₀,Je₀⟩ = ∫x·(1/x²)·M2/N dν = m̃_0-algebra); both series
converge absolutely (terms O(j⁻³)). **This is the evanescent/fixed side of the dynamics —
an exact infinite-system identity, no layer content.**

**C2. Layer scale (j = ξ√N): the Dirichlet form, at order N⁻².** The band-collapse
property of the Lambert data (`b_j = 2a_j + O(j⁻³)`, exactly
`b_j − a_j − a_{j+1} = −16/((4j+1)²(4j+5)²) + …`) makes the layer see only the
second-difference energy. CONFIRMED limit identity (windows [1,2], [1.5,2.5]; N = 1600 →
6400, error halving per 4×N as O(1/√N)):

  **`N² Σ_{j∈[ξ₁√N, ξ₂√N]} a_{j+1}(γ_j − γ_{j+1})² → ∫_{ξ₁}^{ξ₂} (√G)′(ξ)²/(16ξ²) dξ`**

  ratios 0.98956/0.94347 (N=1600) → 0.99792/0.97227 (N=6400). The coefficient
deformation probe ρ_a(ξ) = 16ξ²N·a_{ξ√N} → 1 like c/(ξ√N) (0.969 at ξ=1, N=6400):
**the finite-N Fredholm deformation of the Jacobi coefficients DIES in the limit; the
limit Dirichlet coefficient is exactly 1/(16ξ²).**

## D. The limit object (the Gate A answer, construction grade)

The N→∞ uniform-normalization object is the triple
  **( L²(0,∞), 𝔇, √G )**, `𝔇(φ) = ∫₀^∞ φ′(ξ)²/(16ξ²) dξ`,
together with the fixed-mode ledger `1/2 = A_∞ + B_∞` at the ξ = 0 boundary. The uniform
vector √G has finite Dirichlet energy 𝔇(√G) = 0.0168 (window [0.8,3] value; the ξ→0
divergence of the naive integrand belongs to the fixed-mode scale, not the layer). "Gate
A: sections not nested" is resolved STRUCTURALLY: e₀ travels with N (the layer), its
envelope converges to √G isometrically (B), and the operator content splits into an exact
evanescent identity (C1) plus a layer Dirichlet form (C2). **What survives of the finite
pencil data: the alternating sign structure (band-top position), the envelope G, and the
1/(16ξ²) Dirichlet coefficient; what dies: the O(1/(ξ√N)) Fredholm coefficient
deformations.**

## E. Honest boundaries

- B is a proof (conditional as stated); A is a proof; C1's identity is provable and its
  numeric value confirmed; C2 is at CONSISTENCY-CHECK grade (two windows, two N, right
  rate) — the write-up-grade proof of C2 (discrete-to-continuum Γ-convergence of the
  form, with the certified g-profile rate) is the natural next step of item 2.
- Model lattice only; nothing here transfers to production/chi8 (that lane is closed
  separately — see FINDINGS_GHROT_route1_certified_jacobian.md).
- The task's route-2 connection (uniform conditioning bound from the same
  Fredholm-factor structure) is now concretely posed: the conditioning question lives in
  the SAME two-scale split — the fixed-mode identity is exact, so uniformity is a
  layer-Dirichlet question. Not attacked this session.
- Attribution: answers the Gate A question IB posed; construction and proofs above are
  this session's (Stenberg + Claude); flag in any send. Shared by default.

## Files

`xi_limit_consistency.py` (+log): alternation, decomposition identity (2e-19), two-scale
totals, window tests. `xi_limit_coeff_profile.py` (+log): A_∞/B_∞ series, ρ_a/ρ_b
profiles. Full-precision window ratios in the session transcript (N=1600/6400, inline
run). Builds on: `WRITEUP_M1_HORIZON_exact_layer_theorem.md` (Theorems 1–3),
`m1_horizon_fredholm_profile.py` (Nyström G). Ledger: EVIDENCE_CHAIN §9 this session.
