# k1k2_normal_form_probe.py — INFINITE_SIDE items 1+3 shared target, 2026-07-22.
# (A) R1 normal form on the MODEL lattice z_n=(n-1/2)pi, x=z^-2, uniform w=1/M:
#     reconstruct excess C_j(m) = sum_i hhat_i chat_i(m) (identity check), then measure
#     ||hhat||_2 (CS closes uniformity if bounded), sum|hhat_i|/(1+i), max_m|C_j(m)|.
# (B) anti-alignment: overlap of the band-derivative vector c_L with top eigvecs of K+-_L.
import numpy as np, math
from numpy.polynomial.legendre import leggauss
M = 100; JMAX = 48
n = np.arange(1, M+1); x = ((n-0.5)*np.pi)**-2.0; w = 1.0/M
v = np.full(M, math.sqrt(w)); V=[v]; al=[]; be=[]
wk = x*v; a = v@wk; al.append(a); wk -= a*v
for j in range(1, M):
    b = math.sqrt(wk@wk); be.append(b); vn = wk/b
    for q in V: vn -= (q@vn)*q
    vn /= math.sqrt(vn@vn); V.append(vn); wk = x*vn - b*V[-2]
    a = vn@wk; al.append(a); wk -= a*vn
V = np.array(V); P = V/math.sqrt(w)              # p_i(x_n)
D = np.zeros_like(P)                             # p_i'(x_n)
D[1] = 1.0/be[0]
for j in range(1, M-1):
    D[j+1] = (P[j] + (x-al[j])*D[j] - be[j-1]*D[j-1])/be[j]
print("j | recon_err | max_m|C_j| | ||hhat||_2 | sum|hhat_i|/(1+i)")
for j in (2, 4, 8, 16, 24, 32, 40, JMAX):
    Phip = be[j]*(D[j]*P[j+1]+P[j]*D[j+1]) - be[j-1]*(D[j-1]*P[j]+P[j-1]*D[j])
    Ka = w*Phip                                  # kernel row
    h = Phip - P[j]**2
    hhat = (V @ (h*math.sqrt(w)))                # <h, p_i>_mu
    chat = np.cumsum(V*math.sqrt(w), axis=1)     # chat_i(m)
    Cdir = np.cumsum(Ka) - np.cumsum(w*P[j]**2)
    Crec = hhat @ chat
    err = np.max(np.abs(Cdir - Crec))
    print(f"{j:3d} | {err:.2e} | {np.max(np.abs(Cdir)):.4f} | {np.linalg.norm(hhat):.4f} | "
          f"{np.sum(np.abs(hhat)/(1+np.arange(M))):.4f}")
print()
print("(B) anti-alignment: |<v_top,c_L>|^2/||c_L||^2 for K+ and K-, and delta_+- values")
def probe(L, Mq=240):
    xg,wg = leggauss(Mq); t=0.5*(xg+1); wt=0.5*wg
    tu=t[:,None]+t[None,:]; tv=t[:,None]-t[None,:]
    Sd=np.where(np.abs(tv)<1e-14,L,np.sin(L*tv)/np.where(np.abs(tv)<1e-14,1.0,tv))
    Ss=np.sin(L*tu)/tu; A=np.sqrt(wt)[:,None]*np.sqrt(wt)[None,:]/np.pi
    out=[]
    for s,cf in ((+1,np.cos),(-1,np.sin)):
        K=A*(Sd+s*Ss); ev,U=np.linalg.eigh(K)
        c=np.sqrt(2/np.pi)*cf(L*t)*np.sqrt(wt)
        ov=(U[:,-1]@c)**2/(c@c)
        delta=c@np.linalg.solve(np.eye(Mq)-K,c)
        out.append((1-ev[-1],ov,delta))
    return out
for L in (3.0, 5.0, 7.14, 9.0):
    (gp,ovp,dp),(gm,ovm,dm) = probe(L)
    print(f"L={L}: gap+={gp:.2e} overlap+={ovp:.2e} delta+={dp:.3f} (L/2+.5={L/2+.5:.2f}) | "
          f"gap-={gm:.2e} overlap-={ovm:.2e} delta-={dm:.3f}")
