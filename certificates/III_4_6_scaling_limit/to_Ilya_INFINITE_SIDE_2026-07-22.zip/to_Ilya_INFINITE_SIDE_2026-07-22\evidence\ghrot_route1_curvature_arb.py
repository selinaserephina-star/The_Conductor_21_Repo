# ghrot_route1_curvature_arb.py — INFINITE-SIDE item 1, curvature companion, 2026-07-22.
# Certified SECOND-order directional derivatives of the fixed-weight Lanczos map at the
# EXACT frozen centers, along box-scaled adversarial directions d_m = r_x(m)*sigma_m
# (|sigma_m| = 1). This is the Taylor-remainder scale for the route-1 ceiling:
#   |Delta alpha_j - sum_m K_jm dx_m| <= (1/2) sup_{t in [0,1]} |d2/dt2 alpha_j(x + t*dx)|.
# The jets certify the t=0 (center) value exactly; the sup over t is the known structural
# residual (box uniformity; finite-config numeric allowance class, NOT "P1" — see the
# ledger's G-D2b/F10 correction) — what this script delivers is the certified center
# curvature at the true box scale, expected ~1e-20, i.e. ~10 orders below the first-order
# term and ~15 below the margins. 2nd-order jets, no reorth (exact-arithmetic no-op;
# radii certified per row), prec 8192 — the configuration validated in the Jacobian run.
# Not RH/GRH.
import os, sys, time, math, random
from flint import arb, ctx

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from ghrot_route1_jacobian_arb import load_quantiles, fd_jacobian_float, box_radii

class Jet:
    __slots__ = ('v', 'd', 'dd')
    def __init__(s, v, d, dd): s.v = v; s.d = d; s.dd = dd
    def __add__(s, o): return Jet(s.v + o.v, s.d + o.d, s.dd + o.dd)
    def __sub__(s, o): return Jet(s.v - o.v, s.d - o.d, s.dd - o.dd)
    def __mul__(s, o):
        return Jet(s.v * o.v, s.d * o.v + s.v * o.d, s.dd * o.v + 2 * s.d * o.d + s.v * o.dd)
    def __truediv__(s, o):
        v = s.v / o.v
        d = (s.d - v * o.d) / o.v
        dd = (s.dd - 2 * d * o.d - v * o.dd) / o.v
        return Jet(v, d, dd)
    def sqrt(s):
        v = s.v.sqrt(); d = s.d / (2 * v); dd = (s.dd - 2 * d * d) / (2 * v)
        return Jet(v, d, dd)

def jsum(seq, z):
    av = z; ad = z; add = z
    for t in seq: av = av + t.v; ad = ad + t.d; add = add + t.dd
    return Jet(av, ad, add)

def lanczos_jets2(cs, dirs, prec):
    """cs: center strings; dirs: direction floats (exact dyadics ok at this grade,
    entered as arb(repr) — the direction is OUR choice, any exact vector is valid)."""
    ctx.prec = prec
    zero = arb(0)
    xs = [arb(c) ** -2 for c in cs]
    M = len(xs)
    xj = [Jet(xs[i], arb(repr(dirs[i])), zero) for i in range(M)]
    inv = Jet(arb(1) / arb(M).sqrt(), zero, zero)
    v = [inv] * M
    al, be = [], []
    prev = None
    w = [xj[i] * v[i] for i in range(M)]
    a0 = jsum((v[i] * w[i] for i in range(M)), zero); al.append(a0)
    w = [w[i] - a0 * v[i] for i in range(M)]
    for j in range(1, M):
        b = jsum((t * t for t in w), zero).sqrt(); be.append(b)
        vn = [t / b for t in w]
        prev, v = v, vn
        w = [xj[i] * vn[i] - b * prev[i] for i in range(M)]
        aj = jsum((vn[i] * w[i] for i in range(M)), zero); al.append(aj)
        w = [w[i] - aj * vn[i] for i in range(M)]
    return al, be

def main():
    prec = 8192
    drop = 4
    gD, gF = load_quantiles()
    centers = gD[drop:149]
    M = len(centers)
    cs = [repr(c) for c in centers]
    rx = box_radii(centers)
    log_path = os.path.join(HERE, 'ghrot_route1_curvature_run.log')
    lf = open(log_path, 'a')
    def log(s):
        print(s, flush=True); lf.write(s + '\n'); lf.flush()
    log(f"=== curvature probe drop-{drop} D, M={M}, prec {prec} @ {time.strftime('%Y-%m-%d %H:%M:%S')} ===")
    log(f"box radii: max r_x = {max(rx):.3e}, min r_x = {min(rx):.3e}")

    # adversarial sign patterns from the (non-rigorous, direction-choice-only) FD Jacobian
    t0 = time.time()
    Ka, Kb = fd_jacobian_float(centers)
    import numpy as np
    ja = int(np.abs(Ka).sum(axis=1).argmax())
    jb = int(np.abs(Kb).sum(axis=1).argmax())
    log(f"FD direction oracle: worst alpha row j={ja}, worst beta row j={jb} ({time.time()-t0:.0f}s)")
    random.seed(20260722)
    DIRS = [
        ('uniform+',        [rx[m] for m in range(M)]),
        ('sign(Ka[worst])', [rx[m] * (1.0 if Ka[ja, m] >= 0 else -1.0) for m in range(M)]),
        ('sign(Kb[worst])', [rx[m] * (1.0 if Kb[jb, m] >= 0 else -1.0) for m in range(M)]),
        ('random+-',        [rx[m] * random.choice((-1.0, 1.0)) for m in range(M)]),
    ]
    for name, d in DIRS:
        t0 = time.time()
        al, be = lanczos_jets2(cs, d, prec)
        wa = max(range(M), key=lambda j: abs(float(al[j].dd.mid())))
        wb = max(range(M - 1), key=lambda j: abs(float(be[j].dd.mid())))
        sup_a = abs(al[wa].dd); sup_b = abs(be[wb].dd)
        worst_rad = max(max(float(a.dd.rad()) for a in al), max(float(b.dd.rad()) for b in be))
        # first-order term along this direction, for scale comparison
        fo = max(abs(float(a.d.mid())) for a in al)
        log(f"[{name}] max|alpha''| = {sup_a.str(5)} at j={wa}; max|beta''| = {sup_b.str(5)} at j={wb}; "
            f"remainder (1/2)|a''| <= {0.5*(abs(float(sup_a.mid()))+float(sup_a.rad())):.3e}; "
            f"first-order |Delta alpha| along dir ~ {fo:.3e}; worst dd-radius {worst_rad:.1e} "
            f"({time.time()-t0:.0f}s)")
    log("done. (center curvature certified; box-sup over t remains the P1-class residual)")
    lf.close()

if __name__ == '__main__':
    main()
