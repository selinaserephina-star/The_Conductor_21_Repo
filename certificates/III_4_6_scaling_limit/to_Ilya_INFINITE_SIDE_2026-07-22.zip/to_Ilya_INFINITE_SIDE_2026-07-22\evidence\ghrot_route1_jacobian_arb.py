# ghrot_route1_jacobian_arb.py — INFINITE-SIDE item 1 (G-HROT / T2a-QT ceiling), 2026-07-22.
# Route 1 of NEXT_SESSION_TASK_GHROT_khat_lemma.md: certified first-order Jacobian
# d(alpha_j)/d(x_m), d(beta_j)/d(x_m) of the fixed-weight Lanczos map at the EXACT frozen
# centers, by per-direction first-order arb jets (the G-P2 configuration proven stable:
# exact value parts, radius-0 rows). Ball-radius inputs are a recorded dead end
# (interval dependency, FINDINGS_T2a_QT_reduction.md route 1) and are NOT used.
#
# Per-system certificate (system = lattice ladder, e.g. drop-4 D):
#   columns K^a[:,m] = al[j].d, K^b[:,m] = be[j].d  (arb balls, direction e_m)
#   SUM RULES (exact, from J(x+eps*1) = J(x)+eps*I): sum_m K^a[j,m] = 1, sum_m K^b[j,m] = 0
#     -> checked per row against accumulated ball radii: a joint certificate of all columns.
#   box-worst first-order row bound: R_j = sum_m (|K^a_jm|)*r_x(m) etc., with the rigorous
#     per-atom radii r_x(m) from the 1e-10 quantile enclosures (same construction as
#     t2a_qt_abel_certificate.py). ||dJ||_inf(1st order) <= max_j [ Ra_j + Rb_{j-1} + Rb_j ].
#   L1 ceiling: max_j sum_m |K^a_jm| (the certified replacement of the float-FD 52.667).
# Pencil assembly (as in the Abel close): ||dM||_inf <= |a+sgn|*dJ_D + dJ_F vs margins.
#
# Parent accumulation is float64 with OUTWARD inflation (factor 1+1e-9 on every |mid|+rad
# upper bound, + n*1e-15 additive fsum slop): rigorous as an upper bound; the certificate
# only needs ~3 digits (ceiling target < 7.4e5 vs measured ~53 — 4 orders of slack).
# Not RH/GRH.
import os, sys, csv, time, math
from multiprocessing import Pool

HERE = os.path.dirname(os.path.abspath(__file__))
KB = os.path.join(HERE, '..', 'T2_K1K2_kernel_bounds_2026-07-18')
RHO = 1e-10          # quantile enclosure radius (certified, sealed T2a inputs)
INFL = 1 + 1e-9      # outward inflation on every parsed upper bound

def load_quantiles():
    gD, gF = [], []
    with open(os.path.join(KB, 'quantiles_production.csv')) as fh:
        for row in csv.DictReader(fh):
            gD.append(float(row['gamma_D'])); gF.append(float(row['gamma_fwd']))
    return gD, gF

# ---------------- worker: one direction, one system ----------------
def jet_column(task):
    """task = (centers_as_strings, m, prec). First-order jets (v,d) through Lanczos with
    full reorthogonalization (identical structure to validated t2_gp2_jet_hessian_arb.py,
    dd-part dropped). Returns (m, alpha_col, beta_col, worst_rad, secs) where cols are
    lists of (mid_float, rad_float)."""
    from flint import arb, ctx
    cs, m, prec, reorth = task
    ctx.prec = prec
    t0 = time.time()
    xs = [arb(c) ** -2 for c in cs]
    M = len(xs)
    one, zero = arb(1), arb(0)
    # jets as parallel lists (v_list, d_list) to avoid object overhead
    class J:
        __slots__ = ('v', 'd')
        def __init__(s, v, d): s.v = v; s.d = d
        def __add__(s, o): return J(s.v + o.v, s.d + o.d)
        def __sub__(s, o): return J(s.v - o.v, s.d - o.d)
        def __mul__(s, o): return J(s.v * o.v, s.d * o.v + s.v * o.d)
        def __truediv__(s, o):
            v = s.v / o.v
            return J(v, (s.d - v * o.d) / o.v)
        def sqrt(s):
            v = s.v.sqrt()
            return J(v, s.d / (2 * v))
    def jsum(seq):
        av = zero; ad = zero
        for t in seq: av = av + t.v; ad = ad + t.d
        return J(av, ad)
    xj = [J(xs[i], one if i == m else zero) for i in range(M)]
    inv = J(one / arb(M).sqrt(), zero)
    v = [inv] * M
    al, be, Vs = [], [], [v[:]]
    w = [xj[i] * v[i] for i in range(M)]
    a0 = jsum(v[i] * w[i] for i in range(M)); al.append(a0)
    w = [w[i] - a0 * v[i] for i in range(M)]
    for j in range(1, M):
        b = jsum(t * t for t in w).sqrt(); be.append(b)
        vn = [t / b for t in w]
        if reorth:      # exact-arithmetic no-op (tightens balls); rigor holds either way
            for u in Vs:
                c = jsum(u[i] * vn[i] for i in range(M))
                vn = [vn[i] - c * u[i] for i in range(M)]
            nv = jsum(t * t for t in vn).sqrt()
            vn = [t / nv for t in vn]
        Vs.append(vn)
        w = [xj[i] * vn[i] - b * Vs[-2][i] for i in range(M)]
        aj = jsum(vn[i] * w[i] for i in range(M)); al.append(aj)
        w = [w[i] - aj * vn[i] for i in range(M)]
    acol = [(float(a.d.mid()), float(a.d.rad())) for a in al]
    bcol = [(float(b.d.mid()), float(b.d.rad())) for b in be]
    worst = 0.0
    for _, r in acol + bcol:
        worst = max(worst, r if math.isfinite(r) else float('inf'))
    return (m, acol, bcol, worst, time.time() - t0)

# ---------------- rigorous per-atom box radii ----------------
def box_radii(centers, prec=256):
    from flint import arb, ctx
    ctx.prec = prec
    rho = arb('1e-10')
    out = []
    for c in centers:
        cc = arb(c)
        hi = (cc - rho) ** -2 - cc ** -2
        out.append((float(hi.mid()) + float(hi.rad())) * INFL)
    return out

# ---------------- per-system assembly ----------------
def run_system(tag, centers, prec, workers, log, reorth=True):
    M = len(centers)
    cs = [repr(c) for c in centers]
    tasks = [(cs, m, prec, reorth) for m in range(M)]
    t0 = time.time()
    if workers > 1:
        with Pool(workers) as p:
            results = p.map(jet_column, tasks, chunksize=1)
    else:
        results = [jet_column(t) for t in tasks]
    results.sort(key=lambda r: r[0])
    worst_rad = max(r[3] for r in results)
    bad = sum(1 for r in results if not (r[3] < 1e-3))
    # sum rules per row (float outward: |sum mid - target| <= sum rad + slop)
    slop = M * 1e-15
    sr_a = 0.0; sr_b = 0.0
    for j in range(M):
        s = math.fsum(results[m][1][j][0] for m in range(M))
        r = math.fsum(results[m][1][j][1] for m in range(M)) * INFL + slop
        sr_a = max(sr_a, abs(s - 1.0) - r if abs(s - 1.0) > r else 0.0, abs(s - 1.0))
    for j in range(M - 1):
        s = math.fsum(results[m][2][j][0] for m in range(M))
        r = math.fsum(results[m][2][j][1] for m in range(M)) * INFL + slop
        sr_b = max(sr_b, abs(s), 0.0 if abs(s) <= r else abs(s))
    # L1 rows and box-worst rows (upper bounds, outward)
    rx = box_radii(centers)
    L1a = [0.0] * M; Ra = [0.0] * M
    L1b = [0.0] * (M - 1); Rb = [0.0] * (M - 1)
    for j in range(M):
        ub = [(abs(results[m][1][j][0]) + results[m][1][j][1]) * INFL for m in range(M)]
        L1a[j] = math.fsum(ub) * INFL + slop
        Ra[j] = math.fsum(ub[m] * rx[m] for m in range(M)) * INFL + slop * RHO
    for j in range(M - 1):
        ub = [(abs(results[m][2][j][0]) + results[m][2][j][1]) * INFL for m in range(M)]
        L1b[j] = math.fsum(ub) * INFL + slop
        Rb[j] = math.fsum(ub[m] * rx[m] for m in range(M)) * INFL + slop * RHO
    dJ = 0.0
    for j in range(M):
        row = Ra[j] + (Rb[j - 1] if j >= 1 else 0.0) + (Rb[j] if j < M - 1 else 0.0)
        dJ = max(dJ, row)
    ceilL1 = max(max(L1a), max(L1b))
    log(f"[{tag}] M={M} prec={prec}: worst jet radius {worst_rad:.2e} "
        f"({'ALL CERTIFIED' if bad == 0 else f'{bad} BAD COLUMNS'}); "
        f"sum-rule dev: alpha {sr_a:.2e}, beta {sr_b:.2e}")
    log(f"[{tag}] CERTIFIED ceilings: max_j L1(alpha) = {max(L1a):.4f}, "
        f"max_j L1(beta) = {max(L1b):.4f}  (float-FD comparison: 52.667 / 25.371 drop-4 D)")
    log(f"[{tag}] box-worst first-order ||dJ||_inf <= {dJ:.4e}   ({time.time()-t0:.0f}s)")
    return {'tag': tag, 'dJ': dJ, 'L1': ceilL1, 'bad': bad, 'worst_rad': worst_rad,
            'sr': max(sr_a, sr_b)}

# ---------------- float64 FD cross-check (validation only, non-rigorous) ----------------
def fd_jacobian_float(centers, h=1e-8):
    import numpy as np
    x0 = np.array([c ** -2.0 for c in centers])
    M = len(x0)
    def lanczos(x):
        v = np.full(M, 1.0 / math.sqrt(M)); V = [v]
        al = []; be = []
        w = x * v; a = v @ w; al.append(a); w = w - a * v
        for j in range(1, M):
            b = math.sqrt(w @ w); be.append(b)
            vn = w / b
            for u in V: vn = vn - (u @ vn) * u
            vn = vn / math.sqrt(vn @ vn)
            V.append(vn)
            w = x * vn - b * V[-2]
            a = vn @ w; al.append(a); w = w - a * vn
        return np.array(al), np.array(be)
    a0, b0 = lanczos(x0)
    Ka = np.zeros((M, M)); Kb = np.zeros((M - 1, M))
    for m in range(M):
        x = x0.copy(); x[m] += h
        a1, b1 = lanczos(x)
        Ka[:, m] = (a1 - a0) / h; Kb[:, m] = (b1 - b0) / h
    return Ka, Kb

MARGIN = {(4, +1): 5.82e-5, (4, -1): 4.22e-4, (1, +1): 1.088e-2, (1, -1): 1.257e-3}

def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else 'validate'
    logf = open(os.path.join(HERE, f'ghrot_route1_jacobian_{mode}_run.log'), 'a')
    def log(s):
        print(s, flush=True); logf.write(s + '\n'); logf.flush()
    gD, gF = load_quantiles()
    log(f"=== mode {mode} @ {time.strftime('%Y-%m-%d %H:%M:%S')} ===")

    if mode == 'validate':          # N=60 drop-4 D, prec 2048, serial + FD cross-check
        centers = gD[4:60]
        res = run_system('validate d4-D N=60', centers, 2048, 1, log, reorth=False)
        Ka, Kb = fd_jacobian_float(centers)
        import numpy as np
        l1a = float(np.abs(Ka).sum(axis=1).max()); l1b = float(np.abs(Kb).sum(axis=1).max())
        log(f"[validate] float-FD cross-check: max L1(alpha) = {l1a:.4f}, max L1(beta) = {l1b:.4f}"
            f"  (certified: see above; agreement expected ~1e-4 rel)")

    elif mode == 'pilot':           # timing/precision ladder, one direction at N=149
        centers = gD[4:149]
        for prec, reorth in [(8192, False), (16000, False), (16000, True)]:
            m, ac, bc, worst, secs = jet_column(([repr(c) for c in centers], 70, prec, reorth))
            log(f"[pilot] prec {prec} reorth={reorth}: dir m=70, worst radius {worst:.2e}, "
                f"{secs:.0f}s -> est full system {secs*len(centers)/3600:.1f} core-h")

    elif mode == 'corner4':         # robustness exhibit: certified Jacobian at exact
        # off-center box points (any exact dyadic in the box is a valid sample; the sum
        # rules hold at every real configuration). Does NOT change the grade (finitely
        # many points) — shows the L1 ceiling is flat across the box at ball grade.
        for shift, tag in [(-1e-10, 'corner(-rho)'), (+1e-10, 'corner(+rho)')]:
            centers = [c + shift for c in gD[4:149]]
            run_system(f'drop4-D {tag}', centers, 8192, 4, log, reorth=False)

    elif mode in ('prod4', 'prod1'):
        drop = 4 if mode == 'prod4' else 1
        prec = int(sys.argv[2]) if len(sys.argv) > 2 else 8192
        workers = int(sys.argv[3]) if len(sys.argv) > 3 else 4
        rD = run_system(f'drop{drop}-D', gD[drop:149], prec, workers, log, reorth=False)
        rF = run_system(f'drop{drop}-F', gF[drop:149], prec, workers, log, reorth=False)
        a = 0.3
        for sgn, tag in [(+1, 'aJ_D+bI-V'), (-1, 'aJ_D+bI+V')]:
            dM = abs(a + sgn) * rD['dJ'] + rF['dJ']
            delta = MARGIN[(drop, sgn)]
            log(f"[drop{drop}] {tag}: ||dM||_inf(1st) <= {dM:.3e}  delta={delta:.3e}  "
                f"lambda_min(true) >= {delta - dM:.3e} -> "
                f"{'POSITIVE' if delta > dM else 'FAIL'} (headroom {delta/dM:.2e}x)")
        ok = rD['bad'] == 0 and rF['bad'] == 0
        log(f"[drop{drop}] first-order ceiling status: "
            f"{'CERTIFIED (all columns, sum rules within radii)' if ok else 'INCOMPLETE'}")
    logf.close()

if __name__ == '__main__':
    main()
