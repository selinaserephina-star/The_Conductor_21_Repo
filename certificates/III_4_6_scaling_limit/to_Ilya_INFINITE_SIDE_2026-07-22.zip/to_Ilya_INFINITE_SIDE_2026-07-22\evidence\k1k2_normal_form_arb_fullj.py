# k1k2_normal_form_arb_fullj.py — full-j R1 normal-form check on the MODEL lattice,
# 2026-07-22. Retarget of the SENT khat-enclosure engine (to_Ilya_T2a_gap_closure_
# 2026-07-22/t2a_khat_enclosure.py: same kernel class, all-j, ball grade) to
# z_n=(n-1/2)pi, x=z^-2, uniform w; no-reorth Lanczos (this session's toolchain).
from flint import arb, ctx
import math, time
ctx.prec = 4096
M = 100
t0 = time.time()
xs = [ (arb(2*n-1)*arb.pi()/2)**-2 for n in range(1, M+1) ]
w = arb(1)/M; sw = w.sqrt()
v = [sw]*M; V=[v[:]]; al=[]; be=[]
wk = [xs[i]*v[i] for i in range(M)]
a = sum((v[i]*wk[i] for i in range(M)), arb(0)); al.append(a)
wk = [wk[i]-a*v[i] for i in range(M)]
for j in range(1, M):
    b = sum((t*t for t in wk), arb(0)).sqrt(); be.append(b)
    vn = [t/b for t in wk]; V.append(vn)
    wk = [xs[i]*vn[i]-b*V[-2][i] for i in range(M)]
    a = sum((vn[i]*wk[i] for i in range(M)), arb(0)); al.append(a)
    wk = [wk[i]-a*vn[i] for i in range(M)]
P = [[V[j][n]/sw for n in range(M)] for j in range(M)]
D = [[arb(0)]*M, [arb(1)/be[0]]*M]
for j in range(1, M-1):
    D.append([(P[j][n]+(xs[n]-al[j])*D[j][n]-be[j-1]*D[j-1][n])/be[j] for n in range(M)])
print(f"setup {time.time()-t0:.0f}s; prec {ctx.prec}, M={M}, no-reorth")
print("j | recon_err(ball) | max_m|C_j| | ||hhat||_2 | sum|hhat_i|/(1+i) | worst rad")
for j in (8, 16, 32, 64, 90, 98):
    Phip = [ be[j]*(D[j][n]*P[j+1][n]+P[j][n]*D[j+1][n])
           - be[j-1]*(D[j-1][n]*P[j][n]+P[j-1][n]*D[j][n]) for n in range(M) ]
    h = [Phip[n]-P[j][n]**2 for n in range(M)]
    hhat = [ sum((w*h[n]*P[i][n] for n in range(M)), arb(0)) for i in range(M) ]
    err = arb(0); Cmax = arb(0); acc_d = arb(0); acc_r = arb(0)
    chat_acc = [arb(0)]*M
    for m in range(M):
        acc_d += w*Phip[m] - w*P[j][m]**2
        r = arb(0)
        for i in range(M):
            chat_acc[i] += sw*V[i][m]
        r = sum((hhat[i]*chat_acc[i] for i in range(M)), arb(0))
        d = abs(acc_d - r)
        if float(d.mid())+float(d.rad()) > float(err.mid())+float(err.rad()): err = d
        c = abs(acc_d)
        if float(c.mid()) > float(Cmax.mid()): Cmax = c
    n2 = sum((t*t for t in hhat), arb(0)).sqrt()
    wsum = sum((abs(hhat[i])/(1+i) for i in range(M)), arb(0))
    wr = max(float(t.rad()) for t in hhat)
    print(f"{j:3d} | {float(err.mid())+float(err.rad()):.1e} | {float(Cmax.mid()):.4f} | "
          f"{float(n2.mid()):.3f} | {float(wsum.mid()):.4f} | {wr:.1e}")
print(f"total {time.time()-t0:.0f}s")
