﻿# EVIDENCE CHAIN — the T2 pin program, full proof ledger

**Merkabit · Stenberg + Claude (era 2, "middle Claude") · opened 2026-07-19.**
**[MOVED 2026-07-19 (Selina's reorganization): this living ledger now lives in
`LEDGER/`, next to `AUDIT_REGISTER.md` — the cross-stream record of receipts, audits,
and sends. From this move on, §9 below stays a PROOF log; package traffic goes to the
register. Relative paths in older entries are relative to the era-3 working folder
`T2_P1_completion_2026-07-19/`, where a pointer file remains. Snapshots of this ledger
inside sealed packages are frozen as-sent.]**
This is the LIVING master ledger of the T2 pin proof chain across its three eras:

- **Era 1** — operator program & stage 2.6 (first Claude: the operator skeleton was built
  in the COMPLETENESS-ENGINE session, the T2 stages ran in the skeleton/pin sessions, and
  stage 2.6 in the volhard worktree session); frozen record:
  `to_Ilya_operator_program_2026-07-18/` (zip SHA 16cd0374…521944).
- **Era 2** — K1/K2 → P1 → string/Bessel → D1 (this ledger's author);
  frozen record: `to_Ilya_K1K2_P1_program_2026-07-18/` (zip SHA 3b17a4f0…bb9cf)
  + working folder `T2_K1K2_kernel_bounds_2026-07-18/` (on main, complete).
- **Era 3** — D2 and onward (current sessions); working folder `T2_P1_completion_2026-07-19/`
  (this folder). **Era-3 sessions: append status updates in §9 and flip tags IN PLACE with
  a date — never edit the frozen packages; this file is the only living summary.**

**Primary working folders (on main; these hold the scripts/logs/tables the tags cite):**
- `Operator_program_addendum/` — the OPERATOR-DEFINITION home (reorganized 2026-07-19 from
  loose scripts): `operator_skeleton_hdv.py` — the script that CONSTRUCTS D and V, i.e.
  the object every layer below is about — plus `operator_skeleton_twin.py`,
  `gen_an_chi8.py` (Dirichlet coefficients), the 40-zero list, T3 twin table/log copies,
  and `resonance_spectrum_2026-07-18/` (moved here from `unbounded/`).
- `T2_pin_conjecture_2026-07-17/` — era-1 home: the T2 RESULTS ledger (all stage entries
  2.1–2.6 + K1/K2 + P1 session entries), `kato_pencil.py`, stage-22/22b/26 scripts, kato
  and frontier tables, `window_norm_knee.py`, `quantiles_production.csv` (original).
- `T2_K1K2_kernel_bounds_2026-07-18/` — era-2 home: all four era-2 notes (K1K2, R-, B-,
  D1), the t2_k1/k2/p1 scripts + run logs, `t2_k1_partial_sums.csv`, `t2_p1_model_zoo.csv`,
  and the mp-certified kernel caches `k1_kernels_k{k}_N{N}.npz` (regenerable).
- `T3_twin_skeleton_2026-07-17/` — era-1 control home: the twin experiment
  (`operator_skeleton_twin.py`, `zeros_twin_21_from_0628run.csv`, T3 comparison note/table)
  — supplies the twin local factors used by stage 2.4 and the object-identification verdict.
- `T2_P1_completion_2026-07-19/` — era-3 home: PLAN, RESULTS, D2 note + scripts, this ledger.
- The two `to_Ilya_*_2026-07-18/` folders are FROZEN snapshots for exchange, not working
  homes; cite them only for what was sent (SHAs above).

Not RH/GRH anywhere in this chain (see item 7.9 for where the wall stands).

## 0. Tag conventions

- **[PROVEN]** written proof exists at the cited location.
- **[PROVEN+VER]** proof + independent numerical verification (tolerance quoted).
- **[VERIFIED]** machine-verified identity at stated tolerance (proof mechanical/classical
  or given in-line; distinguishes from measured constants).
- **[MEASURED]** numerical value/profile, float64 or mp grade; no proof claimed.
- **[CERTIFIED]** interval/ball-arithmetic certificate (first entries 2026-07-21: the
  T2a session — sup|S_P|, sup|S_P'|, and the four PSD margins; see §9).
- **[REFUTED]** negative result — statement or route is false; measured or proven.
- **[GAP]** open statement, precisely posed at the cited location.
- **[LANE:IB]** with Ilya per the K1K2/P1 package menu (his priorities first).

Format per item: ID · statement · tag · where (file §) · evidence (script/log, tolerance).

## 1. Layer 0 — setting and data (era 1)

- **0.0** The operator itself: D = diag(x_n) and V = J(μ_F) − J(μ_D) constructed by
  `Operator_program_addendum/operator_skeleton_hdv.py` (imported by `kato_pencil.py` and
  the stage scripts) from the ladders of 0.1 and the Euler data of `gen_an_chi8.py`.
  [DEFINITION — the artifact every tag below refers to; twin variant
  `operator_skeleton_twin.py` for item 1.5.]
- **0.1** Quantile ladders: γ_n^D solves θ/π = n−½; γ_n^F solves θ/π + S_P = n−½ (P = 2×10⁵,
  18,120 terms); atoms x = 1/γ², uniform masses 1/M; production N = 149.
  [MEASURED — float64 ladder; THESE DEFINITIONS ARE THE FROZEN CERTIFICATE HYPOTHESES.]
  `to_Ilya_operator_program…/tables/quantiles_production.csv` (copies in both era-2 folders).
- **0.2** Data grade: production zeros numerical_anchored (γ1–24 certified separately,
  CHI8_FIRST24 closure); zeros used NOWHERE in the T2 ladder (Euler side only). [MEASURED]
- **0.3** κ(P) stability ~1% (stage 2.3). [MEASURED]

## 2. Layer 1 — the pin at production scale (era 1)

All layer-1 items: `T2_pin_conjecture_2026-07-17/RESULTS.md` (the stage ledger) + its
scripts/tables (`t2_stage22_production.py`, `t2_stage22b_frontier.py`,
`kato_table_production_drop{0,1,2,4}.csv`, `frontier_*.csv`, `window_knee_production.csv`):

- **1.1** Original pin (form-bound < 1 for FULL V): κ_full = 1.1822, flat m = 20..149.
  **[REFUTED]** stage-2.2 entry.
- **1.2** Tail pin: drop-k κ ∈ {0.431, 0.294, 0.309} flat in m. [MEASURED]
- **1.3** κ_tail(N) growth is b-TYPE (absorbable): fixed pairs (a,b) = (0.3, 0.011) drop-1,
  (0.3, 0.0001) drop-4 PSD-verified for all N ≤ 149; b_needed non-increasing in N; knee at
  b ~ D_min. [MEASURED — float64 eigenchecks] stage-2.2b-frontier entry.
- **1.4** Window-knee elbow at w ≈ 3, saturation < 1 for tail V; no S-norm can bound the
  top block (pointwise C = 1.37 > 1). [MEASURED] stage-2.5/2.2 entries; see gap G-E.
- **1.5** Twin control (stage 2.4): same D (Γ_ℂ⁴, N = 21¹⁰ preserved ⇒ D_twin ≡ D_genome),
  twin local factors ⇒ κ^twin = 0.3233 flat; genome/twin ratio 2.35 independently
  reproduces T3's ~2.4× twist-decoherence. **V is object-identifying (carries the
  arithmetic content); D is genome-blind.** [MEASURED — two independent routes agreeing]
  Home: `T3_twin_skeleton_2026-07-17/` (+ `kato_table_twin21.csv` in the era-1 home;
  T3 verdict note `T3_twin_V_comparison_2026-07-17.md`, copy in the operator package).
  Interpretive weight: this is why bounding V (not discarding it) is the program — the
  perturbation IS the genome signal, and the pin must tame it without erasing it.

## 3. Layer 2 — stage 2.6 trichotomy (era 1)

Note: `unbounded/LEMMA_tail_KLMN_attempt_2026-07-18.md` (on main; copies in both packages);
scripts + logs: `T2_pin_conjecture_2026-07-17/t2_stage26{,b,c,d}_*.py` and tables there:

- **2.1 Theorem A** (atom-map KLMN): a = ε_k, b = 0, positivity-transferring; ε₄ = 0.0569;
  per-n analytic bound 149/149. **[PROVEN+VER]**
- **2.2 Theorem B** (pencil factorization): V = Wᵀ(T(J_D)−J_D)W + R; ‖T(J_D)−J_D‖ =
  max|x^F−x^D| exact. **[PROVEN+VER 1.1e−15]**; ‖R‖ ≈ 0.009 drop-4, flat in N [MEASURED].
- **2.3 Theorem C** (basis-free/test-function route): κ_Q ≥ 1 from degree 3–5, ~1e31 full.
  **[REFUTED]** — do not revive.
- **2.4** Kernel sum rules ΣK^α = 1, ΣK^β = 0, x-weighted = α_j, β_j. **[PROVEN+VER 1e−6 FD]**
- **2.5** Identification-dependence of the KLMN pair (I/II/III table). [PROVEN by 2.1–2.3]
  → program question G4.

## 4. Layer 3 — K1/K2 kernel session (era 2)

`T2_K1K2_kernel_bounds_2026-07-18/K1K2_kernel_bounds_2026-07-18.md`:

- **3.1 Theorem 1** (exact kernel closed forms, uniform weights): K_j^α = w·Φ_j′(x_n),
  K_j^β = w·Ψ_j′(x_n); Φ_j = β_jp_jp_{j+1} − β_{j−1}p_{j−1}p_j, Ψ_j = (β_j/2)(p_{j+1}²−p_j²);
  boundary row via r′(x_n) = M/p_{M−1}(x_n). **[PROVEN+VER 5e−9…1e−7 (FD floor), ALL j,
  5 sections; sum rules 3e−15; column rule 4.4e−15]**
- **3.2** Naive conjecture K^α = q², K^β = qq: sum-rule-invisible but false pointwise
  (dev → 1.72). **[REFUTED]**
- **3.3 Theorem 2** (partial sums = projection ∈ [0,1] + derivative pairings). **[PROVEN]**
- **3.4** Cauchy–Schwarz route to K1: ν_j = β_j‖p_j′‖ ~ e^{cj} (9e73 at j = 54) vs partial
  sums ≤ 4.7. **[REFUTED]** — K1 is pure oscillation cancellation.
- **3.5** K1 with absolute constant: false beyond j ≈ 12; per-j flat in M; bulk ~0.5–0.6
  log(2+j) + ≤5-row boundary layer; range certificate κ̂ = 5.5956 (α) / 2.8598 (β), all
  j,m, both drops, N ≤ 149. [MEASURED — the T2a-range constants]
  [FLAG 2026-07-21 → RESOLVED-CONFIRMED same day (T2a session 3,
  `t2a_khat_regrade.py`): **κ̂ = 5.5956 CONFIRMED AT CERTIFIED BALL GRADE** — deep
  rows j = 135..144 match the frozen npz to 4 decimals; boundary row via the exact
  trace identity K_M = 1 − Σ_{j<M}K_j reproduces 5.5956; sum rules ball-zero on ALL
  rows; shallow validation 2.7e−15. The float64 record was RIGHT: the sum-rule
  structure protects the kernels even where raw entries sit at the noise floor.
  NEW CERTIFIED FACT: production boundary (5.60 at ℓ = 1) is ~8× milder than the
  generic Chebyshev law (46.15) — quantile-structure mildness certified. Item 3.5
  upgrades: κ̂ [MEASURED → CERTIFIED].]
  [CAVEAT 2026-07-22 (IB audit): [CERTIFIED] here = high-precision ball-DERIVED value
  confirmation, NOT a strict interval enclosure — the final cumulative sums/max were
  taken from Arb midpoints (float conversions), not accumulated as Arb balls. A
  publication-grade tag needs an enclosure κ̂ ∈ [κ₋, κ₊]. Read κ̂ = 5.5956 as
  confirmed-to-4-decimals; the strict enclosure is OPEN.]
  [CAVEAT RESOLVED 2026-07-22 (`T2_gap_closure_2026-07-22/t2a_khat_enclosure.py`):
  head-sums accumulated in arb end-to-end → **κ̂ ∈ [5.59564988046657624 ± 2×10⁻²⁰]**
  (argmax j=145, k=120; a-posteriori non-overlap margin 0.102 ≫ radius). κ̂
  [CERTIFIED-value → CERTIFIED strict enclosure]; enclosure now CLOSED. Note
  `CLOSURE_T2a_khat_enclosure.md`.]
- **3.6 Theorem 3 / (L-ORD)**: linear transport segments preserve atom ordering
  (gap_n(s) ≥ min endpoint gaps); replaces the |S| < 1 safety condition. **[PROVEN]**
- **3.7** K2 remainder: ‖V − V^lin‖ ≤ ½sup_s|J″| per entry. **[PROVEN structure;
  MEASURED constants, ≥2× margin, quality 8–25%; stencil consistency 1e−3]**
- **3.8** Abel assembly |dα_j| ≤ κ_j(TV(dx)+|dx_M|) + ½sup|α_j″|: holds all j, 3 sections.
  **[PROVEN inequality; VERIFIED on data]** Loss 5× (peak rows) to 26× (uniform).

## 5. Layer 4 — spectral reduction and models (era 2)

`…/P1_spectral_reduction_2026-07-18.md`:

- **4.1 Theorem R1** (cut eliminated): C_j(m) = Σ_{i≤min(2j,M−1)}ĥ_i^{(j)}ĉ_i(m); ĥ_0 = 0;
  Σĉ² = m/M. **[PROVEN+VER 1.3e−15 bandwidth, 2.7e−15 reconstruction]**
- **4.2 Theorem R2** (assembly): κ_j ≤ 1 + a₃W_j; (P1a) + (P1b) ⇒ log-law. **[PROVEN]**
  (Caveat: absolute-value assembly not order-sharp for arcsine-type measures.)
- **4.3 Theorem R3** (Chebyshev model SOLVED): p_j = √2T_j exact; K_j = [(2j−1)T_{2j} +
  U_{2j}]/M (ver 3.7e−13); bulk |PS| < 2.77 via Fejér–Jackson (measured = 1.000);
  boundary κ_{M−ℓ} ≍ M/(πℓ) — blow-up PROVEN (measured 41.02 vs M/π = 40.74).
  **[PROVEN+VER]** ⇒ mild boundary is quantile structure, NOT generic.
- **4.4** Zoo: 1/n² hard-edge model reproduces production to 3 digits (a₃ 2.223/2.225,
  boundary resonance i* 60/59, bulk slope 0.50/0.57). [MEASURED]
- **4.5** (P1a) uniform-system constant a₃ = 2.225 (N=149). [MEASURED]
- **4.6** Verified per-section bound κ_j ≤ 1 + Σ|ĥ_i|sup_m|ĉ_i| within 1.76× of κ̂.
  **[PROVEN inequality; VERIFIED]**

## 6. Layer 5 — the string, the companion, D1 (era 2)

`…/P1_string_bessel_2026-07-18.md`, `…/P1a_companion_theorem_2026-07-18.md`:

- **5.1** The pure model is the uniform Neumann–Dirichlet string: θ/π = n−½ ⇒ z_n = (n−½)π;
  sharpened model matches production (a₃ 2.221/2.225, i* 60/59). [MEASURED]
- **5.2 Theorem B1** (companion EXACTLY SOLVED): μ_L = Σ2x_nδ (mass 1 exact);
  G_L(y) = tan(1/y); Lambert CF ⇒ β_k = 1/√((2k−1)(2k+1)) exact; value law
  ŝ_k(1/z_n) = √((2k+1)π/2)(−1)^{n+1}√z_nJ_{k+½}(z_n); normalization via Poisson +
  Parseval in string eigenbases (Dini sum = 1/((2k+1)π)). **[PROVEN+VER: b₁√3 = 1.00000000;
  value law rel std 9.5e−7, constant 1.000010; Dini 1e−10 odd k; truncation drift ≈ 0.33k/2M
  measured]**
- **5.3 Theorem B2** (Christoffel transfer x·μ_U ∝ μ_L): p^L_i = c_i[p^U_{i+1} − r_ip^U_i]/x.
  **[PROVEN+VER 2.6e−14, i ≤ 45]**; transfer sequences r_i → −1.15…−1.19, c_i ≈ 0.013/i
  [MEASURED].
- **5.4 Lemma A** (cut regimes): |ĉ_i(m)| ≤ min(√(m/M),√(1−m/M)); super-polynomial decay
  for i ≳ Cm² (Jackson through the cut gap). **[PROVEN]**
- **5.5 THEOREM D1** ((P1a)-companion): exact representation ĉ^L_i(m) = (−1)^{m+i+1}/√(4i+1)
  ·∫₀¹[sin(mπt)/cos(πt/2)](P_{2i+1}−P_{2i−1})dt; L¹ bound L(k) ≤ 3/k + 10c₁/√k ⇒
  **sup_m(1+i)|ĉ^L_i(m)| ≤ 1.263.** **[PROVEN+VER: representation 2.3e−15; √k·L(k) ≤ 3.065;
  true constant 0.783 measured (theorem not sharp — data ~ (1+i)^{−1.45})]**

## 7. Layer 6 — D2, era 3 (ACTIVE — `T2_P1_completion_2026-07-19/`)

`D2_progress_bessel_kernels_2026-07-19.md` + RESULTS.md this folder:

- **6.1 Theorem 1′** (kernel closed forms, GENERAL fixed weights — uniformity never used).
  **[PROVEN (verbatim carry) + VER 4e−7/1.3e−6 FD floor; sum rules 1.6e−15]**
- **6.2** (P1b) as W-log for the companion: W_j ≈ 0.85j LINEAR while κ_j stays log.
  **[REFUTED]** — the ĥ/ĉ absolute split discards companion sign cancellation; W-log is a
  uniform-weights phenomenon. D2 retargeted to direct C_j bound.
- **6.3** V1 global value law ŝ_k = √(2k+1)R_{k,½}(1/y), Bessel form
  √(πz/2)[J_{k+½}sin z − Y_{k+½}cos z]. **[VERIFIED 3.1e−14; derivation in note §1]**
- **6.4** V2 derivative law at atoms (second-kind Y enters). **[VERIFIED 1.8e−6 FD floor;
  derivation in note §1, hand-checked k=1 exact]**
- **6.5** V3 kernel closed form K_j(n) = 2πμJ_μ²/z − (π/2)z²[W_j − W_{j−1}], and the
  RATIONAL form (A_k = R_{k,½}, B_k = R_{k−1,3/2} values; no oscillatory evaluation).
  **[VERIFIED: finite-M deviation halves 64→128 (= 1/M truncation); derivation from
  6.1 + 5.2 in note §1]** The e^{cj} cancellation = J_{μ−1} + Y_μ = O(z^{−3/2}), one line.
- **6.6** Infinite-system profile κ_j = 0.386 + 0.382·log(2+j), j ≤ 192; sup at turning
  point (m* ≈ 0.66j); per-row drift flags ≤ 4e−2; unscanned tail ≈ 0.231 const (away from
  sup). [MEASURED → SUPERSEDED 2026-07-19 (F7/F8): the log fit was pre-asymptotic; the
  certified-row law is κ_j = 1 + E_j, E_j ≈ 0.131·j^{1/3}(ln j)^{1/2} (flat ±2%,
  j = 256–8192, m* = 2j/π exactly); tail constant → 2/π² = 0.2026 exactly; the j ≤ 192
  table VALUES stand, the fit line and the 256–512 hybrid extensions do not (fourth
  float-trap). See D2 note §7 (F7)/(F8) + §9 entries below.]
  [SECOND SUPERSESSION same day, (F9)/(F10): the √log refinement above was ITSELF a
  finite-size mimic (refuted out-of-sample at j = 16384) — the FINAL law is the
  THEOREM κ_j = 1 + a_∞μ^{1/3} + R_j, a_∞ = 2^{2/3}3^{−5/6}/Γ(2/3)² derived,
  −1.1 ≤ R_j ≤ 0.5 explicit (j ≥ 512). No log anywhere, in leading OR subleading
  order. Read (F10); this line is the end of 6.6's chain of corrections.]
- **6.7** Zone-(ii) toolbox, all machine-exact: **Z1** product-comb lemma j_aj_b =
  (±½)∫₀²(P_a∗P_b)·cos/sin(zτ)dτ, {cos(z_nτ)} orthonormal on (0,2) (4.8e−16);
  **Z2** Wronskian telescope cancellation (5e−18); **Z3** Casoratian A_{k+1}B_k − A_kB_{k+1}
  = −1 (2.8e−16 rel); **N0** Y_ν = −J_{−ν} (0.0); **N1/N2** second elementary cancellation
  (1e−18) — Y-content = J_{ν+1}Y_ν, J_νY_ν only; **N3** Neumann reps with FIXED J₀/J₁
  kernels, j-dependence only in cosine frequency (9e−16); **N4** doubled-string Dirichlet
  kernel (1.1e−13). **[VERIFIED; proofs classical/one-line, assembled in note §5–6]**
- **6.8** Z4: the JJ/Y split re-introduces the cancellation (parts ~2485 vs total ~0.5):
  E_ν = J_{ν−1} + Y_ν is ATOMIC. **[REFUTED route — binding constraint on any proof]**
- **6.9** F_j(τ) := Σz²ΔW·cos(z_nτ) reconstructed (j = 4, 8): antisymmetric about τ = 1
  (2e−15); **boundary values vanish** (⇒ boundary-free IBP applies, as in D1); amplitude
  decays in j; NOT low-degree polynomial (fit resid ~0.9). [MEASURED/VERIFIED]
- **6.10** Numerical-stability lemma-of-experience: far-tail trig evaluation accumulates
  ~1e−9·z phase noise (spurious κ ~ 240 caught); the rational form is both the provable
  and the stable representation. [RECORDED]

## 7b. Adjacent evidence lines (feed the chain; not on the pin's critical path)

- **T1 — finite-range positivity** (`t1_hankel_ledger.py`, `t1_li_positivity.py` + note in
  the operator package): Hankel m ≤ 40 all > 0; Li LB(n) > 0 for n ≤ 150, 270× margin.
  [MEASURED] This is what the pin's positivity-transfer (G4, atom map b = 0) would connect
  to in the limit — the REASON identification matters.
- **Completeness/Turing line** (`chi8_certified_zeros_MASTER…`, CHI8_FIRST24 closure,
  rescaled-FFT engine): certified γ1–24, B = 57.89 Turing constant, certified-∫S machinery.
  [CERTIFIED (Ilya's pipeline) / MEASURED] Supplies the unconditional-S inputs for G-C1/C2
  and the future longer-list frontier reruns (2.2b(ii)) — the latter gated UPSTREAM by two
  pending engine items from the turing24 gate response: the (26, 28] amplitude-guard patch
  and the second-η channel. 2.2b(ii) does not open until those land.
- **Resonance spectrum** (`Operator_program_addendum/resonance_spectrum_2026-07-18/`;
  moved from `unbounded/` in the 2026-07-19 reorganize): overtone lines resolve at
  production scale, Frobenius coefficients at ~1%. [MEASURED] Independent evidence the
  production list carries the genome's arithmetic — same role as 1.5, from the spectral
  side.
- **Margin/Li-fluctuation identity** (`unbounded/MARGIN_curve_geometry_vs_primes_2026-07-17.md`
  + `MARGIN_curve_UPDATE_40zeros_tailcorrected_2026-07-17.md`; copies in the operator
  package): the exact split ∫w_n dΦ = λ_n^arch ⇒ λ_n^fin = ∫w_n dS, with the 21-vs-140
  internal cross-validation (0.00–0.07%) and the n²-artifact resolution. [PROVEN identity
  + MEASURED margins] **The conceptual bridge between the completeness machinery and
  V-as-fluctuation — the motivating result for why the pin targets S-transport at all.**
- **Structural/exploratory notes** (`unbounded/` — octonion frame, doubling test, J₃(𝕆)
  motivation for the w ≈ 3 question): motivation layer; feeds G-E's question, carries no
  tags in this chain.

## 8. THE GAPS (all of them, precisely; owner lanes per the K1K2/P1 package menu)

- **G-D2a [GAP → DONE 2026-07-19]** Closed form of F_j(τ): DERIVED AND VERIFIED (parts
  8.6e−10, TOTAL 8e−13; JJ comb collapse certified EXACT in rational arithmetic).
  → `D2_progress` §7 (F1)/(F2). Unblocked G-D2b.
- **G-D2b [GAP → THEOREM 2026-07-19 (F10)]** κ_j = 1 + a_∞μ^{1/3} + R_j,
  −1.1 ≤ R_j ≤ 0.5 explicit (j ≥ 512), lemmas (L-a)/(L-b) closed with graded
  ingredients; caustic lower bound E_j ≥ 0.3466μ^{1/3} − 1.1 (exact constant).
  Historical text below stands as the day's record:
  *(old)* The zone-(ii) estimate. Old target
  κ_j ≤ c₀ + c₁log(2+j) is FALSE (measured law: κ_j = 1 + E_j, E_j ≈ 0.131·j^{1/3}·
  (ln j)^{1/2}, certified rows to j = 8192; log/√j/pure-power all rejected). NEW target:
  **κ_j ≤ C·j^{1/3}(log j)^{1/2}** (+ caustic lower bound ≥ c·j^{1/3}, which refutes
  log-K1 permanently) via Olver/Airy at the caustic n/j = 2/π, σ-calculus remainders.
  The naive IBP+L¹ routes are REFUTED (D2 note §7 (F4)). WITH zones (i)/(iii) (G-D2c)
  ⇒ **companion-K1 proven at the j^{1/3}√log growth class** (program-safe per
  `CONSUMER_CHECK_j13_2026-07-19.md`). → staged: `NEXT_SESSION_TASK_caustic_profile.md`.
- **G-D2c [GAP → DONE 2026-07-19 (F10)]** Zones (i)/(iii): zone (iii) closes
  via the exact σ-calculus (C_m = −(1/π)Σg_kρ_k(m), alternating-dominated, r ≤ 0.04,
  g₁/μ² → −8/π) — lemma written into (F10) (S_m = −(π/2)C_m exact; far partial sums
  pinned ≤ 0.211); zone (i) closed as lemma (L-b) (fixed x₀ = 1/2 split, envelope 8×
  slack, C_b = 0.066).
- **G-M1 [GAP → CLOSED 2026-07-21: THEOREM-M1 ASSEMBLED (derivation+verification
  grade; two classical write-ups pending, no research content)]** →
  `T2_M1_weight_transfer_2026-07-19/M1_THEOREM_note_2026-07-21.md` (8 parts,
  grades itemized). Historical record: Weight transfer
  companion → uniform: the λ-side Lambert route CONFIRMED and the inverse telescope
  BYPASSED. **J_N(uniform) = head row (α₁ = m₁/N exact, β₁ ≈ √(m₂/N)) ⊕ ODD-Lambert
  block (closed form: α^O_j = 1/((4j−3)(4j−1)) + 1/((4j−1)(4j+1)), β^O_j =
  1/((4j+1)√((4j−1)(4j+3)))) + O(1/N) FLAT in j** (measured ratios 1.999/1.999 over
  two octaves; ODD form = x²-system at 7.7e−10). Moments m_k = (2^{2k}−1)ζ(2k)/π^{2k}
  = tan-series EXACT (the (F5) rationals); CF-contraction = EVEN(companion-x) block
  exact; all N-dependence isolated in m₀ = N (renormalized-transform identity). The
  Q2-audit's α₁(N) ~ c/N is now c = m₁ = 1/2 identified. REMAINING: (a) the
  bordered-perturbation lemma (O(1/N) flat — perturbative, same genus as G-M3, likely
  close together); (b) the K1-kernel consequence through the bordering (next session).
  → `T2_M1_weight_transfer_2026-07-19/M1_lambert_pattern_note_2026-07-19.md`.
  Historical route text: telescope cancellation-laden (|r_i| ≈ 1.15) — now bypassed;
  CD-kernel Christoffel / uniform V-transform routes no longer needed.
- **G-M3 [GAP → CLOSED at lemma grade 2026-07-21 → CONSTANT-GAP RE-OPENED 2026-07-22
  (IB audit): `up`-nonexpansiveness step FALSE → PROVEN 2026-07-22 (Frobenius repair,
  `T2_gap_closure_2026-07-22/`): fixed point re-run in ‖·‖_F (up IS Frobenius-
  nonexpansive), giving C_GS(j)=16·x₁·(j+2) (leading 9), LINEAR in (j+2) — no √(j+2)
  penalty; rates unchanged; measured envelope 0.065. See §9 2026-07-22 + CLOSURE note]**
  the unified
  tail-measure-removal lemma: |Δα_j|+|Δβ_j| ≤ C_GS(j)·‖τ_N‖·B_j², rates EXACT
  (‖τ_ODD‖ = 1/(3π⁴N³) — M⁻³ scaling confirmed over a decade, constant 3.5e3
  stable; ‖τ_comp‖ = 2/(π²N) — the 0.33k/2M drift's shape); edge values geometric
  (rate → 1). Also answers the Q2-audit Task-1 residue (sections → canonical
  completions at explicit rates). GS-stability write-up pending (mechanical).
  Historical: Finite-M truncation lemma (drift ≈ 0.33k/2M measured; residuals
  halve M→2M).
- **G-P2 [GAP → K2 CONSTANT CERTIFIED 2026-07-22; closed-form p″ identity offerable]**
  Second-order kernel identity (differentiate Theorem 1′ along the transport flow) —
  upgrades K2 from stencil-verified to identity-verified.
  [2026-07-22 (`T2_gap_closure_2026-07-22/t2_gp2_jet_hessian_arb.py` + CLOSURE note):
  K2's Theorem-3 transport-remainder constant sup_s|J″(s)| upgraded from float64 STENCIL
  (consistency 1e-3) to EXACT ball-grade 2nd derivative via 2nd-order jets through Lanczos
  (flint-arb, prec 16000, ALL rows radius 0). Certified: drop-4 sup|α″|=0.011368 (j=23,s=1),
  sup|β″|=0.004128; drop-1 sup|α″|=0.091768 (j=3,s=1), sup|β″|=0.035860; max at the s=1
  (F-config) endpoint. Validated vs the sealed note's stencil (1.06e-2@23 / 8.46e-2@3) and
  vs an mpmath jet. Feeds the T2a-QT 2nd-order term (sup|α″| scale now certified). Residual
  (offerable): continuous-s |α‴| bridge + the closed-form p″ kernel identity.]
- **G-HROT [GAP, composed; constants improved 2026-07-19 (F11); REDUCTION + CONFIG-GRADE
  CONSTANT DELIVERED 2026-07-22 (certified-κ̂ Abel via T2a-QT, §9); uniform-in-j version ⇐
  caustic κ_j theorem G-D2b/F10, NOT an open "P1"]** The rotation-bound packaging (LEMMA
  note §8): ‖J(μ′) − J(μ)‖ ≤ C·max_n|x′_n − x_n| for quantile-type configurations, fixed
  weights; measured C_rot = 1.04–1.18, flat in N (item 2.2's ‖R‖).
  [2026-07-22 REDUCTION (`T2_gap_closure_2026-07-22/FINDINGS_GHROT_reduction.md`): the
  rigorous split ‖J′−J‖₂ ≤ max_n|Δx_n| + 2·x_max·‖U−U′‖ reduces the explicit constant to
  an ε-Lipschitz bound on the ON-frame rotation ‖U−U′‖ (= the fixed-norming-constant
  inverse-spectral / κ̂ conditioning). This is exactly T2a-QT's remaining ceiling. Explicit
  constant still [GAP]; clean hand-off = prove ‖U−U′‖ ≤ C′·max_n|Δx_n| (any C′<1.6e6).]
  [2026-07-22 (same day, after searching era-1/era-2): the OVER-PESSIMISM ABOVE IS
  WITHDRAWN. Prior work supplies the rigorous mechanism: stage26c's exact unitary
  decomposition V = Wᵀ(T(J_D)−J_D)W + R (‖first term‖ = max|Δx| exact; C_rot=1.045–1.175
  flat in N), and the K1K2 note's **Theorem 1** (exact sensitivity kernels, PROVEN) +
  **Theorem 2** (PROVEN: Σ_{n∈A}K_j^α = ⟨p_j,P_A p_j⟩ + derivative pairings, projection
  part ∈[0,1]) give the ABEL bound |Δα_j| ≤ κ̂_j(TV(Δx)+|Δx_M|) — turning the e^{cj} ℓ1
  into κ̂·TV. The κ̂ here IS the constant certified in the T2a-KHAT close (5.5956). Not yet
  a uniform theorem: the pairing-excess bound (κ̂≤5.6) is proven only in its [0,1]
  projection part — the excess is certified-numerically at the config (the uniform κ_j
  GROWTH law is itself a THEOREM: the caustic theorem G-D2b/F10, κ_j = 1 + a_∞μ^{1/3} + R_j
  via Olver/Airy — so "P1 [GAP]" as I wrote it 2026-07-22 was WRONG; only the finite-M
  boundary constant is numeric); + the 2nd-order transport remainder (G-P2-level). But BOTH are handled for
  T2a-QT: κ̂ CERTIFIED at the frozen config (ball, stable), and the 10⁻¹¹ perturbation
  makes the 2nd-order term negligible. So T2a-QT is closeable at CERTIFIED-as-computed
  grade (matching the sealed T2a cert's own grade) via the certified-κ̂ Abel assembly —
  NOT blocked on a new research lemma.]
  [2026-07-22 later session (INFINITE_SIDE item 1, route 1): the first-order ceiling is
  now CERTIFIED DIRECTLY at ball grade — full atom→Jacobi Jacobian by per-direction arb
  jets at the exact centers, all four ladders, radii 0.0, exact sum rules as joint
  column validation; max_j L1(α) = 52.6670 (d4-D, = the float-FD value) ≪ the required
  1.6e6/7.4e5. The measured C_rot ~ O(1) is thereby a certified O(10¹) Jacobian ceiling
  at the config. Residual for the uniform theorem: box-uniformity of the curvature only
  (certified 1.5e-20 at center; box-edge Jacobian samples identical to center).
  `INFINITE_SIDE_open_items_2026-07-22/FINDINGS_GHROT_route1_certified_jacobian.md`.]

- 2026-07-22 (GAP-CLOSURE — **T2a-QT CLOSED at CERTIFIED-as-computed grade**; the
  certified-κ̂ Abel assembly delivers it. `T2_gap_closure_2026-07-22/t2a_qt_abel_certificate.py`
  + `CLOSURE_T2a_QT_abel.md`). Route (found by the era-1/era-2 folder search): Abel
  summation against the Theorem-2 partial-sum bound κ̂ beats the e^{cj} ℓ1 —
  ‖ΔJ‖∞ ≤ (κ̂^α+2κ̂^β)(TV(Δx)+|Δx_M|). Certified inputs: κ̂ at ball grade prec 16384
  (κ̂^α(D)=5.5956 — reproduces the T2a-KHAT strict enclosure EXACTLY, cross-validating the
  kernel computation; κ̂^β(D)=2.8598, κ̂^α(F)=9.4916, κ̂^β(F)=6.0075), boundary rows via the
  trace identity; TV(Δx) rigorous from the 1e-10 quantile enclosures; 2× safety on the
  (≈10⁻²¹, 13-orders-subdominant) 2nd-order transport term. WEYL: λ_min(true) ≥ δ − ‖ΔM‖ > 0
  for **all four pencils** — drop-4 −V/+V headroom 4,265× / 38,080×; drop-1 −V/+V 294,500× /
  43,090×. **⇒ the KLMN form bound holds at the TRUE quantiles, not just the frozen
  centers.** GRADE: T2A_TRUE_QUANTILE_FORM_BOUND OPEN → **CERTIFIED-as-computed** (same grade
  as the sealed T2a cert). Rests on PROVEN Theorems 1–2 + certified κ̂ + rigorous TV + Weyl.
  Honest residual for a fully-PROVEN *uniform* theorem (NOT needed for this grade): the
  pairing-excess bound κ̂≤5.6/9.5 is proven only in its [0,1] projection part (the uniform-in-j
  κ_j growth law is a THEOREM — caustic theorem G-D2b/F10, NOT the open "P1" I wrote; only
  the finite-M boundary constant is numeric); 2nd-order transport = G-P2-level (here: measured sup|α″| + 2× margin) — exactly
  the certified-as-computed allowances the sealed cert already uses. The G-HROT explicit
  constant is thereby delivered for this config (κ̂-Abel), in our own lane — correcting the
  "hand to IB" framing of the two entries above (that was deference-drift: Theorems 1–2 and
  the κ̂ machinery are era-2 ours; P1/G-P2/M1-HORIZON/T2a-SP carry no [LANE:IB] marker).)
  NOT independently attacked: it is COMPOSED from model-K1 + K2 via the Abel/row
  assembly (item 3.8). Constants: the raw-Abel route was 5–26× vs truth; **the (F11)
  profile-pairing accounting delivers 4.8× (0.0622 vs 0.0129·C_rot-truth on the actual
  drop-4 field), with NO j^{1/3} anywhere** — the remaining ~4.5× is in-window sign
  cancellation, i.e. exactly G-E's window norm. The j^{1/3} tolerance question is
  ANSWERED (F11); G-E's window norm is now DERIVED [2026-07-19: ‖S‖*_3 signed, the
  caustic scale of the j = 2–3 rows]; the field-side lemma is NUMERICS-STAGED
  [2026-07-19 (F12): τ ≤ u_n(sup|ΔS| + (q/n)sup|S|), u_n ≤ C_geo n⁻² geometric
  (exponents measured 2.36/2.05); window term ≤ 0.044 at every j]. What remains for
  the sharp C ≈ 1.1: the classical u-decay write-up (quantile-class, ρ increasing —
  IB lane) + the certified S scalars (sup|S| = 0.862, sup|ΔS| = 0.676, ‖S‖*_3 =
  0.6295 measured at production spec; certification = G-C1/G-C2).
  Any spine reference to "H-ROT" resolves HERE.
- **G-E [GAP → DERIVED 2026-07-19]** The w ≈ 3 elbow IS the caustic scale of the
  maximizing kernel rows: w*_j = 2j/π + μ_j^{1/3} = 2.9/3.8 at j = 2/3 (where |dα|
  peaks, structurally by the (F11) runaway); sign-change clusters match in model AND
  production; the operational tolerance curve (window-averaged dx vs fixed kernels)
  reproduces the empirical C_needed knee interval [2,3] exactly. Precise norm:
  **‖S‖*_w = max over windows of w spacings of |signed avg S|, w = 3** ("w ≤ 2 safe,
  w = 3 marginal, w ≥ 4 dead"). → `ELBOW_kernel_scale_note_2026-07-19.md`. Feeds G4;
  the field-side lemma is numerics-staged [(F12) 2026-07-19; ‖S‖*_3 = 0.6295 measured
  at production spec]; remaining = classical u-decay write-up + certified S scalars.
- **G-C1 (= G2) [LANE:IB → SPLIT 2026-07-21: mechanical core taken into our lane
  (Selina's decision), θ-module remains offerable]** Session 1 delivered
  (`T2a_pencil_certification_2026-07-21/`): **CERTIFIED sup|S_P| ≤ 0.901946 and
  sup|S_P′| ≤ 188.804** (interval, explicit budgets); **all four PSD certificates
  aJ_D + bI ∓ V ⪰ 0 CERTIFIED-as-computed with margins** (drop-1: 5.5e−3/6.9e−4;
  drop-4: 5.0e−5/4.0e−4; interval Cholesky, dps 40; cross-checks vs frozen CSV
  3.6e−15 and frozen npz 8.3e−17). Remaining = ONE module: rigorous θ/θ′ enclosure
  (Stirling-remainder iv or arb port) → γ-enclosures; ~25 orders of headroom
  (tolerated |dγ| ≈ 1.1e−5 vs mp residuals ~1e−30). When it lands: the first
  rigorous finite-range self-adjointness certificate for χ8. Original statement:
  Interval certification: sup|S_P| on tail range, quantile
  enclosures, the two PSD checks for (0.3, 0.011) at N = 149 ⇒ first rigorous finite-range
  self-adjointness certificate for χ₈. Hypotheses frozen at item 0.1.
- **G-C2 (= G3) [LANE:IB]** Palojärvi–Zhao pointwise-S constants c₁, c₂ for χ₈ (Selberg
  data as in the B = 57.89 script) ⇒ Theorem A unconditional in true S.
  **Rounding discipline for BOTH C-items:** ceil-to-12dp-BEFORE-inequality (adopted in the
  turing24 exchange after the stored B = 56.94 was found rounded the unsafe way) — every
  constant entering a certified inequality in G-C1/G-C2 must follow it.
- **G4 [PROGRAM QUESTION, LANE:IB; REFRAMED 2026-07-21]** Which identification does
  the m→∞ limit need: atom map (b = 0, transfers positivity — proven) vs pencil map
  (all measurements + the T2a certificate; b ~ D_min)? REFRAMING on record: at
  finite range BOTH hold simultaneously — they are two gauges of one object,
  related by the measured rotation W_N (Theorem B; ‖R‖ ≈ 0.009, FLAT in N) — so G4
  reduces to the CONVERGENCE of the gauge W_N (a computation-adjacent question;
  FORCING campaign stage 5). Proposed architecture: hybrid "assembly ⊕ marker"
  (pencil supplies the machinery/bulk, atom map carries the invariant
  positivity piece) — same shape as the TURNING_THE_KEY assembly theorem. The
  literal trit-gauge reading stays CONJECTURE across the open Q2 bridge.
- **G5 [standing]** All production constants float64-grade, P = 2×10⁵ (upgrade via G-C1).

**Dependency spine:** T2a certificate ⇐ G-C1 (+frozen 0.1). Companion-K1 ⇐ G-D2a→b→c
**[ALL THREE CLOSED 2026-07-19 — companion-K1 is a THEOREM, (F10)]**.
Uniform/model-K1 ⇐ companion-K1 + G-M1 + G-M3 **[G-M1 CLOSED 2026-07-21; G-M3 PROVEN
2026-07-22 — RE-OPENED by the IB audit (false `up`-nonexpansiveness) then closed by the
Frobenius-route repair: C_GS(j)=16·x₁·(j+2), rates unchanged. Both closed; the caustic
theorem transfers to the uniform normalization at the kappa-level with an explicit
constant. Remaining M-lane item: M1-HORIZON (3.2√N uniform-in-j) still MEASURED]**.
G-HROT (the rotation bound, defined above)
⇐ model-K1 + K2 (3.7) [G-E window DERIVED 2026-07-19; + G-P2 (K2 sup|J″| constant now
CERTIFIED at ball grade 2026-07-22, exact 2nd-derivative jets); j^{1/3}
tolerance answered (F11); field-side lemma numerics-staged (F12) 2026-07-19; remaining
input = classical u-decay write-up + certified S scalars ⇐ G-C1/G-C2.
2026-07-22: the G-HROT explicit constant is DELIVERED at config grade via the certified-κ̂
Abel close (T2a-QT) — see §9 2026-07-22; the uniform-in-j version rests on the caustic κ_j
theorem G-D2b/F10, not on any open "P1"].
Pin-in-the-limit ⇐ uniform KLMN pair (1.3, supported) + G4 decision. The ‖S‖*-question to
IB is now POSED PRECISELY [2026-07-19: ‖S‖*_3 = max |signed 3-spacing window avg of S|,
from `ELBOW_kernel_scale_note_2026-07-19.md`] ⇐ Turing/PZ inputs (G-C2) for the certified
evaluation.

## 9. Status updates (era 3 appends here; newest last)

- 2026-07-19 (ledger opened, middle Claude): chain current through item 6.10 / gaps as
  listed. Era-3 session active on G-D2a.
- 2026-07-19 (audit by era-3 Claude; fixes applied by middle Claude): both package SHAs
  re-verified ✓; five findings fixed — G-HROT defined with its own gap entry (spine
  reference resolved); margin/Li-fluctuation identity added to §7b; ceil-to-12dp-before-
  inequality rounding discipline recorded on G-C1/C2; 2.2b(ii) upstream gates named
  (amplitude-guard patch + second-η channel); era-1 attribution corrected (skeleton =
  completeness-engine session).

- 2026-07-19 (G-D2a closed-form session): F_j(τ) closed form DERIVED+VERIFIED (parts
  8.6e−10, total 8e−13; JJ comb collapse certified EXACT in rational arithmetic — Lidstone
  resummation ≡ δ-form); C_m = ∫F_jD_m verified; naive one-IBP L¹ REFUTED (~j, Z4 recurs
  at kernel level); Γ_j = ∫|F|g ≈ 0.47√j; S_true = −0.174+0.216log(2+j) (j ≤ 64). Two new
  float-trap lessons (sub-turning-point Lommel recurrence; mpmath-lambdify float args).
  D2 note §7; commit fb54e9b.
- 2026-07-19 (G-D2a σ-calculus session): C_m now EXACT per m — πc_n = even rational
  Laurent (A·B/A·A Lommel products ≡ T/U calculus, cross-checked exactly); g₋₁ = g₀ = 0
  and the row-sum C_∞ = 0 all EXACT-RATIONAL identities (j = 2,3,4,8); zone (iii) closes
  numerics-first (alternating domination r ≤ 0.04, g₁/μ² → ≈ −8/π) [G-D2c: GAP → 
  VERIFIED-shape 2026-07-19]; log localized AT the turning point (envelope peak O(1) at
  n/j = 2/π; m*/j → 2/π); Y-side finite-m double-integral rep verified (stationary-phase
  object). Third float-trap lesson: sympy nsimplify truncates unevaluated exact Adds
  through float64 (phantom 7/(μ+1)z^{−(4j−2)}). **OPEN FLAG: §2 κ-table not reproduced at
  j ≥ 8 from verified rows — κ-slope 0.382 is fit-range-only until resolved vs
  `t2_d2_kappa_infinite.csv`; all variants stay polylog (program-safe).** D2 note §7
  (F5)/(F6).

- 2026-07-19 (G-D2a κ-resolution session): OPEN FLAG resolved — no bug; §2's κ =
  max(fwd, rev-tail-branch), CSV reproduced to all digits on verified rows. Extension to
  j = 512: **κ_j ≈ 0.46·j^{1/3} (flat ±3% over j = 64–512); the §2 log fit was
  pre-asymptotic — K1-as-log is FALSE for the companion model** [companion-K1 target:
  log → C·j^{1/3}, 2026-07-19]. Mechanism = Airy caustic window (~μ^{1/3} atoms, O(1)
  amplitude) at the turning point n/j = 2/π. Universal-tail constant corrected:
  (π/2)|C_cap| → 2/π² = 0.2026 exactly (0.231 was pre-asymptotic). NEW GATE for G-D2b/c:
  consumer check — does the K1K2 tail assembly tolerate κ_j ~ j^{1/3}? (If not:
  program-level question for IB.) Finite-range κ̂ = 5.60 (N ≤ 149) unaffected. D2 note
  §7 (F7); RESULTS entry.

- 2026-07-19 (consumer-check session): **j^{1/3} does not break the chain** — verdict note
  `CONSUMER_CHECK_j13_2026-07-19.md`. Production bulk κ_j refit from the frozen certified
  kernels: c·j^{1/3} fits with c ≈ 0.52 (≈ model's 0.46; N = 149 is pre-asymptotic, model
  arbitrates). Per consumer: finite chain (N ≤ 149) UNAFFECTED; **P1 RESTATED [log target
  → C·j^{1/3}, 2026-07-19]** (log-P1 was unprovable — explains the D2 estimate failures);
  H-ROT unchanged (raw Abel was already the gap; NEW IB-menu question: windowed-S pairing
  with j^{1/3} row constants); KLMN/G4 unchanged. D2 proof goal now: κ_j ≤ Cj^{1/3} upper
  + caustic lower bound (lower bound kills log-K1 permanently).

- 2026-07-19 (caustic-ladder session): ladder to j = 8192 on CERTIFIED pure-rational rows
  (backward-Miller A + forward B, log-mantissa; mp/ktop/scipy triple-checked). **Law
  refines: κ_j = 1 + E_j, E_j ≈ 0.131·j^{1/3}(ln j)^{1/2}, flat ±2% over five octaves;
  m*_E/j = 2/π at every j** [companion-K1 target: C·j^{1/3} → C·j^{1/3}(log j)^{1/2},
  2026-07-19]. FOURTH float-trap: garbage-FINITE rows at the scipy underflow boundary (no
  NaN; one row carried 0.085 at j = 512) — (F7)'s κ(256–512) corrected (κ(512) = 3.6159);
  j ≤ 192 CSV values clean. Consumer verdicts unchanged. IB side-note draft updated.
  D2 note §7 (F8).


- 2026-07-19 (caustic-profile derivation session): **the zone-(ii) law is now CLOSED
  FORM: kappa_j = 1 + E_j, E_j = a_inf mu^(1/3) + O(1), a_inf = 2^(2/3) 3^(-5/6) /
  Gamma(2/3)^2 = 0.34656 (i.e. 0.43663 j^(1/3))** [companion-K1 target:
  C j^(1/3)(log j)^(1/2) -> 1 + a_inf mu^(1/3) + O(1), DERIVED constant, 2026-07-19].
  (F8)'s sqrt(log) refinement is REFUTED by an out-of-sample test at j = 16384 (sqrt(ln)
  law misses by +2.06%, the offset law by -0.18%) - it was a finite-size mimic of the
  additive O(1) constant. Mechanism derived via the Olver/Airy telescope:
  Phi_inf(s) = -4(AiBi)'(-2^(1/3)s), verified 8.0e-5 (Richardson) with the first
  correction confirmed (0.998); oscillatory envelope (4/pi)(1-sin theta) at 1.8e-3; the
  excursion is the CONVERGENT integral of Phi_inf (B(S) saturates; osc side DC ~ 0).
  Caustic lower bound E_j >= 0.1212 mu^(1/3) - O(1) on a fixed verified window -
  **log-K1 refuted permanently** (theorem-grade modulo (L-a) Olver-remainder
  accumulation + (L-b) zone-(i) Debye lemma, both classical machinery). Full-kappa
  ladder corrected on Miller rows (far block bitwise = rows()): kappa(384) = 3.2393,
  kappa(512) = 3.6159 (F7 values contaminated), extended kappa(768/1024) =
  4.1141/4.5116; sup = rev = 1 + E_j exactly. Authoritative table
  `t2_d2_kappa_full_ladder.csv`. D2 note section 7 (F9); RESULTS entry; IB side-note
  draft updated to the closed-form law (still DRAFT/unsent).
- 2026-07-19 (zone-(ii) closure session, sixth of the day): **THE ZONE-(ii) THEOREM
  CLOSES — kappa_j = 1 + E_j, E_j = a_inf mu^(1/3) + R_j, -1.1 <= R_j <= 0.5 explicit,
  j >= 512** [G-D2b: GAP -> THEOREM; G-D2c: -> DONE]. Lemma (L-a): fixed split
  x0 = 1/2; two-piece residual envelope vs certified rows (C2 = 5.5 caustic piece,
  C3 = 2.7 deep piece; j-stable 256/1024/4096, 50% headroom); the pure-Airy model
  constant closes: C_model_inf = -D_inf + 2Ai(0)Ai'(0) + Jac_inf = -0.5770 (D_inf =
  2^(2/3)/(2 pi (3W0/2)^(1/3)) EXACT, j-independent to 6 digits). Lemma (L-b): zone-(i)
  envelope |c_n| <= 1.2 * 2/(3 pi mu W(x)), sup ratio 0.130 (8x slack), C_b = 0.066;
  gamma >= arccosh 2 on the whole zone so the u1-warning never bites. Zone-(iii) lemma
  written (S_m = -(pi/2)C_m exact, far tails pinned <= 0.211). NEGATIVE result
  recorded: proj-drop fails beyond the caustic (c-only drift ~0.5 mu^(1/3)) — theorem
  uses measured sup-at-m* + P* = sum proj below m* <= 0.02 (prop. to eps) instead.
  Ledger-balance check E - E_W = zone-i - P* closes to 1e-4 at three j. **Caustic
  lower bound with the exact constant: E_j >= 0.3466 mu^(1/3) - 1.1 — log-K1 refuted
  at a_inf itself.** Subleading drift resolved structurally (every component
  convergent; no genuine ln mu; -0.934 limit matches the 16384 residual to 0.001;
  32768 test considered and rejected — separation inside EM jitter). Grades per (F10):
  classical-cited / exact / quadrature / finite-numeric-with-margins, itemized.
  Scripts `t2_d2_lemma_La.py`, `t2_d2_lemma_Lb.py` + logs; D2 note (F10); RESULTS
  entry; IB side-note draft updated to theorem-grade (still DRAFT/unsent). Folder
  ready to cut into a dated send (Selina decides).
- 2026-07-19 (windowed-S pairing session, seventh of the day): **THE MENU QUESTION
  ANSWERED — the windowed-S pairing TOLERATES j^(1/3) row constants** (model +
  production, note (F11)). Mechanism 1, localization: explicit majorant Psi_j =
  min(1.10 kappa_j, 1 + 0.50 mu^(1/3)|shat|^(-1/2)) >= |ps_m| pointwise (0 violations,
  margin +0.178, three octaves); equidistributed-TV pairing 0.66*TV CONSTANT in j
  (kappa 2.9 -> 7.1); oscillating fields <= 0.014*TV; SHARP at a caustic step (= E_j).
  Mechanism 2, runaway (frozen production kernels, cross-checks exact; kappa-hat
  convention identified = worst-step 5.5956): the actual dx has TV density ~ n^(-3/2)
  and the caustic window n* = 0.64j runs past it — kappa_j*TV_window peaks 0.054 at
  j ~ 10 and falls two orders; the dangerous corner is empty for quantile fields.
  Actual-field accountings: TRUE 0.0106 / pairing 0.0622 / Abel 0.2847; H-ROT budget
  4.8x truth vs Abel 22x. RETARGET for the IB menu: only the FIELD-side TV-density
  bound remains to formalize (kernel side is (F10)-grade). Scripts
  `t2_d2_pairing_windowedS.py`, `t2_d2_pairing_production.py`; RESULTS entry; frozen
  folders read-only, untouched.
- 2026-07-19 (Stage-E elbow session, eighth of the day): **G-E DERIVED — the w ~ 3
  window elbow IS the caustic scale of the maximizing kernel rows**: w*_j = 2j/pi +
  mu^(1/3) = 2.9/3.8 at j = 2/3 (where |dalpha| peaks; structural via the F11
  runaway); production first sign change at n = 4 matches the model's near-caustic
  cluster; operational tolerance (window-averaged dx vs fixed kernels) loses
  0/76/101% of the aggregate pairing at w = 1/2/3, reproducing the frozen empirical
  C_needed knee interval [2,3]. Deliverable norm: ||S||*_w = max over w-spacing
  windows of |SIGNED avg S|, w = 3; honest reading "w <= 2 safe, w = 3 marginal,
  w >= 4 dead". The J3(O)-nominated w = 3 = the caustic scale of the j = 2-3 rows.
  Note `ELBOW_kernel_scale_note_2026-07-19.md`; script + log; G-E flipped in §8;
  RESULTS entry. Feeds G-HROT sharp constant and G4.
- 2026-07-19 (field-side TV-density session, ninth of the day): **the pairing story's
  last piece STAGED (F12)** — tau(n) = |Ddx| decays at p = 2.36 (envelope 2.60), the
  S-part dominates the split, and the provable shape is tau <= u_n(sup|DS| +
  (q/n)sup|S|) with u_n <= C_geo n^-2 GEOMETRIC (u-exponent measured 2.05; classical
  quantile-class lemma, IB-lane write-up). Composed: **the window term
  1.10 a_inf mu^(1/3) TV_Wj <= 0.044 at every j** (peak j = 10, decay j^(-1.69);
  separated-regime law TV_Wj <= 78 mu^(1/3) n*^(-2.36) TV for j >~ 40, full-TV
  fallback below — mu^(1/3) small there). Matches (F11)/X4's independent 0.054: the
  runaway is now an inequality. Certified-side scalars measured at production spec
  (Euler-product S_P, P = 2e5, zeros nowhere): sup|S| = 0.862, per-spacing sup|DS| =
  0.676, ||S||*_3 = 0.6295 (signed = abs at the maximizing window — sign-pure run).
  Linearization honesty: dx = -u*S only median-22% at product level; all tau
  measurements on the actual field. Script `t2_f_field_tv_density.py` + log; note
  (F12); RESULTS entry. Remaining in the whole pairing story: the classical u-decay
  write-up + the certified S scalars (G-C1/G-C2 lane).
- 2026-07-19 (send): **package CUT AND SEALED: `to_Ilya_CAUSTIC_THEOREM_2026-07-19`**
  (COVER + promoted orientation note + evidence/ = the full working-folder record:
  notes F1–F12, ledger snapshot, all scripts + logs + the authoritative κ CSV;
  62-file SHA256SUMS manifest inside). Zip SHA256 =
  284d21b50996dc76bf74e86567c7c53c6ef5ef78f344860ba90fa440769326b7.
  Lineage pinned to the two 2026-07-18 packages (SHAs in the COVER). The sent folder
  is FROZEN from this commit; continuation work goes to a NEW dated folder per
  standing hygiene. This working folder remains the era-3 home for the ledger only.
- 2026-07-19 (received): **IB's Q2 ↔ operator-bridge audit package filed:**
  `Q2_OPERATOR_BRIDGE_received_2026-07-19/` (zip SHA 0e9a35ed…1688 verified OK;
  extracted alongside the sealed original; his prompt preserved as-received). Ten
  input files incl. his six exact-QQ Q2/T50019 certificates and snapshots of our two
  07-18 packages (byte-verify before citing). Audit STAGED, not run:
  `NEXT_SESSION_TASK_Q2_operator_bridge_audit.md` (our holdings pre-answering his
  Tasks 1/3/4/9: companion Carleman exact ⟹ e.s.a.; production atoms bounded;
  sections NOT nested per G-M3; non-circularity receipts incl. (F12) zeros-nowhere;
  m₀ = ∞ moment caveat). Expected Gate A: boundary-extension route refuted for the
  class ⟹ pivot to his Tasks 5–8 (derive Q2 as dark-channel/rank-drop). Audit
  outputs → new folder `Q2_OPERATOR_BRIDGE_audit_<date>/` when run. Adjacent stream
  (§7b), not on the pin's critical path.
- 2026-07-19 (G-M1 pattern-check session, new folder `T2_M1_weight_transfer_2026-07-19/`):
  **G-M1 PATTERN CONFIRMED — the λ-side Lambert route works and the inverse telescope
  is BYPASSED.** Renormalized-transform identity (exact): all N-dependence of the
  uniform-N system sits in m₀ = N; higher moments = (2^{2k}−1)ζ(2k)/π^{2k} EXACT
  (= tan(√λ)/(2√λ) Taylor = Lambert 1,3,5,7 = the (F5) rationals). Squared Lambert
  splits: EVEN block = companion-x (= the CF contraction, sympy-exact), ODD block =
  x²-weighted system in closed form (α^O_j = 1/((4j−3)(4j−1)) + 1/((4j−1)(4j+1)),
  β^O_j = 1/((4j+1)√((4j−1)(4j+3))); verified 7.7e−10 vs M = 20000 truncation).
  **J_N(uniform) = head(m₀ = N) ⊕ ODD block + O(1/N) FLAT in j** (dev ratios
  1.999/1.999 over N = 200/400/800; head identities at 1e−18; head laws α₁ = m₁/N,
  β₁ = √(m₂/N) — the Q2-audit's c/N constant identified as m₁ = 1/2). G-M1 tag
  flipped + spine updated; remaining = bordered-perturbation lemma (genus of G-M3)
  + the K1-kernel consequence. Note `M1_lambert_pattern_note_2026-07-19.md`, script
  + log in the new folder.
- 2026-07-19 (M1 Stage-B session, same folder): **kappa-level kernel transfer
  CONFIRMED — matched rows (unif j+1 <-> ODD j) agree to 0.9-2.6% at N = 400,
  improving in j; the caustic window is CLEAN (PS-diff decays ~N^(-1/2) there:
  0.31/0.20/0.14 at j = 16)** — the head coupling does not reach the caustic, so the
  (F10) constant transfers where it matters. HONEST SURPRISE recorded: an O(0.7),
  N-stable PS-difference component localized mid/deep (the head-projector mass
  redistribution; n_sup = 25/82/255 at j = 8/16/32, N = 400) — never moves the
  kappa-sup, but the row-uniform O(N^(-1/2)) transfer statement is TOO STRONG;
  Stage-A lemma must carry the split (caustic + sup-location transfer, O(1) smooth
  redistribution elsewhere). **SIXTH FLOAT-TRAP recorded (recurrence genus):**
  forward-recurrence OP evaluation explodes in float64 at the spectrum edge/deep
  cluster (1e26+ vs the provable sqrt(N) bound from Lanczos orthogonality) and the
  first FD spot-checks missed it by probing only the safe zone — spot-checks must
  cover the EDGES; fix = kernels as centered FD of the Lanczos map (two-h verified
  4e-5; true kernels O(1), max 1.41). Scripts + RESULTS in the campaign folder.
- 2026-07-19 (M1 Stage-A session, same folder): **THE ARROWHEAD IDENTITY IS EXACT —
  J_N(uniform) = tri(Q^T diag(x) Q) over the frame [e0 | V2] (e0 = 1/sqrt(N), V2 =
  ODD Lanczos basis), verified MACHINE ZERO (3.3e-16) at N = 100/200/400; proof =
  degree filtration, two lines.** The bordered-perturbation lemma is now explicit
  algebra on a proven finite-N identity. Coupling profile g_j = <e0, V2_j>: sum = 1
  exactly, mass at j ~ 0.8 sqrt(N), tail ~ j^(-3) — item 1b ANSWERED (the Stage-B
  O(0.7) redistribution = the head state's Fourier profile in the ODD basis; its
  sqrt(N) mass location explains the kernel PS-diff localization). J(N) breakdown
  measured: 1/N plateau for j <~ sqrt(N), rise past (2-5) sqrt(N); two separated
  deviation sources (ODD-truncation moment tails = the G-M3 twin; g-coupling at
  sqrt(N)). SPLIT LEMMA statement fixed by the data; remaining proof work:
  (a) downdate algebra (mechanical), (b) g_j closed form (Bessel-summable
  candidate), (c) the ODD-truncation moment lemma = G-M3 precisely twinned.
  Script `t2_m1_stageA_arrowhead.py` + log; RESULTS session-3 entry.
- 2026-07-19 (M1 session 4 — item (a) DONE): **the downdate algebra is WRITTEN OUT
  and machine-verified (1e-13, three N, all pre-horizon rows).** Exact structure:
  GS = two-term (w_j, ehat_j) recursion driven by s_{j+1}^2 = s_j^2 - g_j^2, with
  the collapse X e0 = sqrt(m2/N) w0; exact entries alpha^U_1 = m1/N, beta^U_1 =
  sqrt(m2/N) s_1, alpha/beta^U_{j+2} explicit in {g, a, b, m1, m2}. **The transfer
  horizon is SHARP: s^2-floor at j = 3.2/3.25/3.3 sqrt(N) — J(N) = 3.2 sqrt(N).**
  Deviation identity verified per-point: alpha^U_{j+2} - a_j = [g_j^2(a_j + eta_j)
  + 2 g_j g_{j-1} b_{j-1}]/s_{j+1}^2; crude absolute-value bound explicit with
  measured 9-27x slack = the alternating-sign cancellation (g_j alternate:
  sign = (-1)^j measured everywhere). **The sharp bound is reduced to ONE fact —
  the g-alternation lemma (Chebyshev-like positivity of sum x_n p^O_j(x_n) in the
  elementary ODD system) = item (b), which now carries both the decay law and the
  cancellation.** One transcription sign error caught by per-point verification.
  Script `t2_m1_stageA2_downdate_algebra.py` + log; RESULTS session-4 entry.

- 2026-07-19 (Q2 operator-bridge AUDIT RUN, tenth session of the day; adjacent
  stream §7b): IB's 18-deliverable audit executed →
  `Q2_OPERATOR_BRIDGE_audit_2026-07-19/` (14 notes + RESULT.json + scripts/logs +
  SHA256SUMS). **Gate A fired both ways as staged:** boundary-extension route
  REFUTED for the class (every canonical completion bounded/compact, deficiency
  (0,0); companion e.s.a. PROVEN twice over) + uniform-normalization infinite
  operator OPEN (nestedness REFUTED with six-N drift table; α₁(N) ~ c/N — G-M3
  quantified). **Pivot substance: Q2 DERIVED, never inserted** — Lemma S:
  scar = maximal F-invariant subspace of Row(B) (2-line proof); Q2 divides the
  ω-dark-channel determinant det(B(F−ωI)X) SYMBOLICALLY over ℚ(ω) (cofactor =
  rank-B cubic); drop-exactly-1 verified mod two primes at all four strata;
  σ_min ≈ 4.19|Q2| linear opening. Negatives recorded: no b-space F-action
  (span{B5..B8} not F-stable); F not orthogonal; canonical couplings W_sym and
  G⁻¹W_sym do NOT reduce on the scar ([H,P]=0 refuted for these). New structure
  flagged to IB: ordinary pairwise intersections all = scar; dim(R0+R1+R2) =
  13/8/5/8. b_χ8: centralizer no-go (character-level data GL₂-invariant) —
  missing datum = canonical marking of the 2χ8 multiplicity plane. His
  certificates independently reproduced (rule 10, incl. A-identities as
  polynomial identities over ℚ[a,c,p,q]). His snapshot of our operator package =
  deliberate zero-strip (2 CSVs + 1 COVER ¶; 57/57 rest byte-identical) — cite
  sealed originals. Non-circularity: operator_uses_zero_locations = false, with
  receipts. Variable-discipline note: item 5.2's exact β-law lives in the
  SYMMETRIZED ξ = 1/z frame (x-frame impossible: supp 0.405 < β₁ = 0.577);
  companion β-truncation rate 0.008·k/2M (≠ 5.2's value-law 0.33·k/2M — two
  observables, recorded to prevent misreading). String-weighted production tails
  β_n ~ 1.48n^{−1.49} (D) / 1.78n^{−1.54} (F). T2 pin critical path unaffected.
- 2026-07-19 (send): **audit package CUT: `to_Ilya_Q2_OPERATOR_BRIDGE_audit_2026-07-19`**
  (38 members: 15 notes incl. the reply + RESULT.json + all scripts/logs/tables +
  SHA256SUMS; `extracted/` excluded — byte-identical copies of IB's own certified
  packages, covered by his manifests). Zip SHA256 =
  930b3315c7dcd5a86db5f7dd3eebd36ada93fb6718603b92c3be9212d982ccd8.
  The audit folder is FROZEN from the send per standing hygiene; continuation work
  (2×2 Gram realization, all-b drop-1 identity, canonical-coupling search,
  multiplicity-marking datum) goes to a NEW dated folder.

- 2026-07-21 (T2a certification session 1, new folder
  `T2a_pencil_certification_2026-07-21/`): **THE CHAIN'S FIRST [CERTIFIED] ENTRIES.**
  CERTIFIED sup|S_P| <= 0.901946 on [0.5, 27.79] (dense scan + interval Lipschitz
  sup|S_P'| <= 188.804 + explicit float budget 4.3e-11 — every step rigorous; Euler
  side = finite explicit sum). All FOUR PSD certificates aJ_D + bI -+ V >= 0
  CERTIFIED-as-computed by interval Cholesky (dps 40, construction allowance 1e-30)
  at the frozen pairs: drop-1 margins 5.5e-3/6.9e-4, drop-4 margins 5.0e-5/4.0e-4.
  Cross-checks: dps-40 ladders vs frozen quantiles CSV at 3.6e-15; mp-built drop-4
  J_D vs the FROZEN npz at 8.3e-17. ONE pending module, exactly specified:
  rigorous theta/theta' interval enclosure (8 loggamma terms; Stirling-remainder in
  iv, or the arb port on the box) delivering both the Newton residual AND the local
  f' lower bound; headroom ~25 orders (tolerated |dgamma| ~ 1.1e-5 vs mp residuals
  ~1e-30). G-C1 split: mechanical core in our lane (done), theta-module offerable to
  IB. When it lands: the first rigorous finite-range self-adjointness certificate
  for chi8. Note `T2a_CERTIFICATE_note_2026-07-21.md`; script + log; tag-conventions
  line updated (CERTIFIED no longer 'none yet').

- 2026-07-21 (T2a session 2, same folder): **T2a COMPLETE — the full finite-range
  KLMN certificate at ball grade, end to end, delivered LOCALLY** (python-flint/arb
  was already installed; the theta-module = 8 ball lgammas + digamma, no AWS, no
  FFT engine needed). [CERTIFIED] 298/298 quantile enclosures at 1e-10 (interval
  Newton; ball theta/theta'/S_P/S_P'; prec 4096). [CERTIFIED] the COMPLETE frozen
  matrices at full dimension (prec 16384 ball Lanczos, all 148/145 rows, radii
  below 1e-308-display) and ALL FOUR PSD statements with margins drop-1
  5.500e-3/6.875e-4, drop-4 5.000e-5/4.000e-4. **THE KLMN FORM BOUND FOR THE
  FROZEN PRODUCTION PAIR IS NOW A CERTIFICATE — the first rigorous finite-range
  self-adjointness statement for the chi8 operator family (G-C1's deliverable,
  mechanical core + theta-module both closed in our lane).** AUDIT FINDINGS:
  (i) Krylov-conditioning wall ~10^13/step — prior float64/dps-40 values of rows
  j >~ 94 were below their own noise floors; chain consumers all live in the easy
  region; **kappa-hat = 5.5956 (attained j = 145) FLAGGED for re-grading** [bracket
  added at item 3.5]; (ii) prec-16384 wide-ball quirk recorded (M2 regresses to
  66/149 at 16k while clean at 4096; mechanism unresolved, certificates taken at
  4096 — equally valid). Remaining OPTIONAL polish: certified sensitivity bound
  (needs <= 5e5; measured 0.76-50) to transfer margins from the frozen-as-computed
  object to the true-quantile object — astronomic slack, staged.
  Note `T2a_CERTIFICATE_note_2026-07-21.md` session-2 section; scripts + logs.

- 2026-07-21 (T2a session 3, kappa-hat re-grade): **the audit flag RESOLVES —
  kappa-hat = 5.5956 CONFIRMED at certified ball grade** (prec-16384 ball Lanczos
  with basis; ball derivative recurrence — the e^cj growth, max |p'| = 2.9e+291,
  now RESOLVED rigorously; Theorem-1 kernel rows; PROVEN sum rule = ball-zero
  per-row certificate on all rows; boundary row via the exact trace identity
  K_M = 1 - sum_{j<M} K_j after the naive truncated formula produced a 144.0
  artifact — caught by the M-1 signature and fixed same run). Deep rows 135..144
  match the frozen npz to 4 decimals; kappa-hat attained at j = 145 exactly as
  recorded. NEW certified fact: the production boundary layer (5.60 at l = 1) is
  ~8x MILDER than generic Chebyshev (M/pi = 46.15) — the quantile-structure
  mildness claim upgrades to certified. Item 3.5: kappa-hat [MEASURED ->
  CERTIFIED]. Script + log in the T2a folder.

- 2026-07-21 (M1 session 5, V-head-free + production arrowhead): **(i) the
  arrowhead identity CONFIRMED VERBATIM on production atoms** (machine zero for
  mu_D and mu_F — the measure-agnostic claim holds; all M1 structural results
  apply to the production operator directly). **(ii) V = J(muF) - J(muD) is
  HEAD-SUPPRESSED, not head-free** (the flagged conjecture refined): head entries
  5-9% of ||V||-scale, V_11 = (m1F - m1D)/N exact identity (~1/N); deep block =
  shifted ODD-difference at leading order with 15-30% median corrections, all
  given exactly by the downdate algebra. The escaping-state pathology does NOT
  dominate the pin's object. G4 guidance recorded: build the V-limit on the
  ODD-difference principal term. Script + RESULTS session-5 entry in the M1
  campaign folder.

- 2026-07-21 (M1 session 6 — THE g-LEMMA): **item (b) of THEOREM-M1 closes at
  derivation+verification grade.** THE IDENTITY: sum_{n>=1}(-1)^{n+1} j_{2j+1}(z_n)
  = (-1)^j/2 for every j (deviations = computable tails at every j tested; j = 0
  case exactly proven: = m_1 = 1/2). THE MAP: g_j(N) = sqrt(2(4j+3)/N) x truncated
  sum — six decimals at low j; residue = ODD-Lanczos truncation (SAME genus as
  G-M3: the two remainders are one object). CONSEQUENCES: g_j ~ (-1)^j
  sqrt((4j+3)/2N) closed form; ALTERNATION sign(g_j) = (-1)^j over the whole clean
  range; the sqrt(N) mass hump DERIVED (predicted 50% at j = 20 vs measured 23,
  N = 800). Formal write-up = two classical steps (Poisson sign; pointwise endpoint
  convergence of the Neumann-at-1 sine series for C^1) — no research content left.
  Remaining for THEOREM-M1: the unified truncation lemma (item c = G-M3) +
  assembly. Script `t2_m1_glemma.py` + log; RESULTS session-6 entry.

- 2026-07-21 (M1 session 7 — THE ASSEMBLY): **THEOREM-M1 ASSEMBLED — G-M1 CLOSED,
  G-M3 CLOSED at lemma grade** (`M1_THEOREM_note_2026-07-21.md`, 8 parts, grades
  itemized). New in this session: (IV) the unified truncation lemma — tail masses
  exact to 4 digits (ODD 1/(3 pi^4 N^3); companion 2/(pi^2 N) = the 0.33k/2M
  shape), M^-3 deviation scaling confirmed over a decade with the effective
  constant 3.5e3 STABLE across M; edge-value growth geometric with rate -> 1.
  (V) the deviation law in closed form: alternation cancellation leaves
  ~1/(4jN)-class residual predicting the true uniform-vs-ODD deviations at 8-30%
  from PURE closed forms (one indexing bug in the cross-check caught by the
  per-point discipline, fixed same run) — session 1's "flat 1.2e-3 rel dev"
  DERIVED. Remaining polish (no research content): two classical write-ups
  (g-lemma steps) + the GS-stability constant + the production-constants ball run.
  Scripts `t2_m1_truncation_lemma.py` + log; RESULTS session-7 entry; spine
  updated.

- 2026-07-21 (M1 session 8 — write-up 1 of 3): **g-lemma step (a), the Poisson
  sign, WRITTEN AND LINE-VERIFIED** (`M1_glemma_stepA_Poisson_sign_2026-07-21.md`):
  Poisson rep 1.4e-16 (zero imaginary leak), parity reduction + sign bookkeeping
  ((-i)^{2j+1} i = (-1)^j — where the alternation is minted) verified 1.25e-15,
  sympy-EXACT anchors at j = 0, 1, and the finite-N assembly IDENTITY at 1.1e-14
  (machine; no convergence). Part (III)'s pending list shrinks to step (b) alone
  (endpoint convergence, classical). Remaining THEOREM-M1 polish: step (b),
  GS-stability write-out, optional production ball run.

- 2026-07-21 (M1 session 9 — write-up 2 of 3): **g-lemma step (b) WRITTEN —
  THEOREM-M1 PART (III) IS PROVEN.** Reflection construction (half-range string
  series = period-4 odd-harmonic Fourier series of the odd/even extension; machine
  identity 4.4e-15; even harmonics vanish); regularity inputs sympy-exact
  (P_(2j+1)(0) = 0, P'_k(1) = k(k+1)/2); Dirichlet-Jordan cited; quantitative rate
  k(k+1)/(pi^2 N) matches measurement to 4 significant figures. **The identity
  sum(-1)^{n+1} j_{2j+1}(z_n) = (-1)^j/2 is PROVEN with explicit finite-N rate;
  the alternation and closed form of the g-profile hold at PROVEN grade.**
  Remaining THEOREM-M1 polish: the GS-stability write-out (part IV) + the optional
  production ball run. Notes + scripts + logs in the campaign folder.

- 2026-07-21 (M1 session 10 — write-up 3 of 3): **GS-stability WRITTEN — THEOREM-M1
  PART (IV) PROVEN; NO PENDING WRITE-UPS REMAIN.** Lemma: |Delta alpha|+|Delta beta|
  <= 6 x1 (j+2) ||tau|| B_j^2 (Gram/Cholesky chain; two-line fixed point ||S|| <=
  2||E|| verified at 0.944 max ratio; ODD instantiation covered with 6.5e5 STABLE
  headroom across a decade of M). G-M3's grade: CLOSED at lemma grade -> PROVEN
  (crude explicit constants). THEOREM-M1 parts (I)-(VI) proven/exact; only the
  OPTIONAL production ball run remains (grade upgrade). The M-lane's mathematical
  content is COMPLETE. Note + script + log in the campaign folder.

- 2026-07-21 (FORCING campaign STAGED — the run's closing act): new folder
  `FORCING_campaign_2026-07-21/` (commit ee719ea), the last wall decomposed into
  certifiable pieces. Structural fact on record: with the TRUE S the F-ladder's
  crossings ARE the zeros — forcing = S_P -> S at the crossings; the infinite-P
  limit is the honest wall (never to be claimed), the finite-range version is
  certifiable. Five staged stages: (1) certified forcing-gap table (per-zero ball
  |gamma_F - gamma_true|, T2a pipeline x the 152 certified brackets);
  (2) P-scaling law (1e6/1e7); (3) Weil-smoothed ladder (prime-sum convergence a
  THEOREM for the Hecke L-function); (4) the finite-range forcing theorem — last
  input = G-C2/PZ certified |S - S_P| <= delta ==> "the prime-built string
  provably sounds the 152 certified zeros"; (5) G4 gauge convergence (W_N
  explicit via Theorem B; R ~ 0.009 flat in N; measure the Cauchy rate).

- 2026-07-22 (IB INDEPENDENT AUDIT of T2a + κ̂ + THEOREM-M1 — reconciled; register
  `INDEPENDENT_AUDIT_received_2026-07-22/`, ext SHA b4f509b2…, inner manifest 3/3 OK;
  all three audited-package SHAs re-verified against our copies, source integrity
  confirmed BOTH ways). The audit is friendly and largely CONFIRMS our honest scope,
  with one real re-open. **CONFIRMS:** T2a frozen-center form bound CERTIFIED —
  independent 60-digit Lanczos+shifted-Cholesky rebuild from the frozen CSV found
  smallest-eigenvalue thresholds MORE conservative than our reported margins
  (drop-1: aJ+bI∓V ≥ 1.088e-2 / 1.257e-3; drop-4: 5.821e-5 / 4.227e-4 — vs our
  5.5e-3/6.9e-4 and 5.0e-5/4.0e-4), so our margins are corroborated and conservative;
  M1 bordered/arrowhead identity + odd-Lambert block EXACT; Bessel endpoint-sum
  identity Σ(-1)^{n+1} j_{2j+1}(z_n)=(-1)^j/2 and the fixed-j tail rate
  (2j+1)(2j+2)/(π²N) PROVEN (each fixed j). **CORRECTLY GUARDS a scope line to keep
  explicit:** T2a is a finite-range relative form bound on two frozen sections — it
  does NOT newly prove infinite-operator self-adjointness (the infinite Jacobi ops
  were already bounded/self-adjoint via compact support of the atomic measure); the
  KLMN upgrade needs a uniform limit + infinite form bound (our own T2-lane framing,
  now on record from the audit side too). **RE-OPENS (the one substantive finding) —
  G-M3 / THEOREM-M1 part IV, `M1_truncation_GS_stability_2026-07-21.md` step (S2):**
  the parenthetical "up = strictly-upper + half-diagonal, a norm-nonexpansive
  projection on symmetric arguments" is FALSE in spectral norm. Verified our side:
  A = [[-1,2,2],[2,-1,2],[2,2,-1]] has ‖A‖₂ = 3 while ‖up(A)‖₂ ≈ 3.16908 > 3, so the
  contraction step ‖up(E+SᵀS)‖ ≤ ‖E‖+‖S‖² and hence ‖S‖ ≤ (4/3)‖E‖ is not
  established, and the explicit constant C_GS(j)=6x₁(j+2) is UNCERTIFIED as written.
  **Impact bounded — a constant repair, not a refutation:** `up` IS
  Frobenius-nonexpansive (‖up(A)‖_F ≈ 3.571 < 5.196 = ‖A‖_F), so re-running the
  fixed point in ‖·‖_F and converting back in (S3) costs a √(j+2) dimension factor,
  giving C_GS(j) = O(x₁(j+2)^{3/2}) — still explicit, polynomial in j; the ‖τ‖·B_j²
  structure is untouched, so the ODD 1/(3π⁴N³) and companion 2/(π²N) tail-mass RATES
  survive (audit concurs). ACTION: G-M3 tag flipped [lemma-grade close → CONSTANT-GAP
  RE-OPENED] at item G-M3 and on the dependency spine; THEOREM-M1 part IV re-graded
  PROVEN → constant-gap-pending; identities/tail-rate parts (I–III) stand PROVEN.
  Next step queued: Frobenius-route GS-stability rewrite (mechanical; the Cholesky/GS
  perturbation is classical — no research content). **Two milder grading
  corrections:** (i) κ̂ = 5.5956 [CERTIFIED] caveated at item 3.5 — ball-DERIVED
  value confirmation, not a strict interval enclosure (final accumulation used Arb
  midpoints); enclosure OPEN. (ii) horizon 3.2√N (session-4 log, "SHARP"): MEASURED,
  not proven — a proof needs estimates uniform in j∼√N, not supplied; the fixed-j
  g-alternation (proven session 9) does not deliver the full-horizon sign pattern by
  itself. sup|S_P'| ≤ 188.804 stands on interval termwise bounds; sup|S_P| ≤ 0.901946
  rests on a dense binary64 scan + Lipschitz/float budget (useful; an Arb-grid
  evaluation would be publication-clean). NOT RH/GRH (audit states so explicitly).
  Reply-verify note to IB pending Selina.

- 2026-07-22 (GAP-CLOSURE campaign opened — `T2_gap_closure_2026-07-22/`, continuation
  home for the sealed T2a/M1 packages). `GAP_LIST.md` inventories the six live
  T2/T2a/M1 gaps (audit's 5 + G-P2), tiered by grade target; five are mechanical
  ("re-run the script at the right grade"), one (M1-HORIZON 3.2√N uniform in j) is
  flagged as possibly-real. FIRST CLOSURE — **T2a-KHAT: κ̂ strict interval enclosure
  DONE** (`t2a_khat_enclosure.py`): the re-grade's float64 cumsum replaced by
  end-to-end arb ball accumulation → κ̂ ∈ [5.59564988046657624 ± 2×10⁻²⁰], argmax
  (j=145,k=120), non-overlap margin 0.102 ≫ radius (argmax rigorously unambiguous).
  Grade OPEN → CERTIFIED strict enclosure; item 3.5 caveat resolved above.

- 2026-07-22 (GAP-CLOSURE — **G-M3 / THEOREM-M1 part IV RE-CLOSED at PROVEN grade**,
  `T2_gap_closure_2026-07-22/t2_m1_GS_frobenius_repair_check.py` + note
  `CLOSURE_G-M3_frobenius_repair.md`). The audit's re-open resolved: `up` is
  spectral-EXPANSIVE (verified, ratio 1.055 > 1) but ‖·‖_F-NONEXPANSIVE (≤ 0.707), so
  the Cholesky/GS fixed point S ↦ −up(E+SᵀS) is re-run in the Frobenius norm.
  Self-map + contraction on {‖S‖_F ≤ 2‖E‖_F} for ‖E‖_F ≤ ¼ (Banach) → ‖S‖_F ≤ 2‖E‖_F
  (measured 0.74·), ‖R⁻¹−I‖ ≤ 4‖E‖_F; assembly via ‖·‖_F-nonexpansive tri/up gives
  **C_GS(j) = 16·x₁·(j+2)** (leading 9). KEY: the entrywise |E_ik| ≤ ‖τ‖B² gives
  ‖E‖_F ≤ (j+2)‖τ‖B² DIRECTLY → **no √(j+2) penalty; order stays LINEAR in (j+2)**
  (correcting the initial GAP_LIST guess of (j+2)^{3/2}); constant 6→~16. Rates
  (ODD N⁻³, companion N⁻¹) untouched; measured envelope 0.065 over 400 random atomic
  (μ, μ̃). Note: the original spectral S-bound ‖S‖₂ ≤ (4/3)‖E‖₂ HOLDS empirically
  (1.073 < 1.333) — the theorem was true, only its proof broke. G-M3 tag + spine
  flipped PROOF_GAP → PROVEN. THEOREM-M1 parts (I)–(IV) now all proven; only the
  separate M1-HORIZON (3.2√N uniform in j) remains MEASURED. Next targets (complex
  tier): T2a-QT sensitivity transfer, T2a-SP Arb-grid sup|S_P|, G-P2, M1-HORIZON.

- 2026-07-22 (GAP-CLOSURE — **T2a-QT ATTEMPTED, NOT closed; precisely REDUCED to the
  κ̂/K1 lane**; `T2_gap_closure_2026-07-22/FINDINGS_T2a_QT_reduction.md` + two scripts).
  The true-quantile transfer is subtler than the audit's "likely large slack" and than
  our GAP_LIST "closes by a Lipschitz bound" (that guess was WRONG). Findings: (1) direct
  ball propagation of the 1e-10 quantile balls through Lanczos is UNSTABLE (interval
  dependency → entry radii inf). (2) The rigorous first-order kernel bound |Δα_j| ≤
  Σ_n|K_j(n)|r_x(n) is VACUOUS — the α-kernel L1 norms grow like e^{cj} (≤ 2.97e89 at
  drop-4; the derivative kernels inherit max|p'_j|~1e291), i.e. the K1 oscillation-
  cancellation wall (items 3.4/3.5) re-encountered: the unsigned L1 discards exactly the
  cancellation κ̂ encodes. (3) Stable dps-60 point-FD over the ±-uniform corners shows the
  transfer DOES hold with 1.4e6–2.2e7× headroom (‖ΔJ‖ ~ 1e-11 vs margins 5e-5…5.5e-3) —
  real, but not a rigorous sup over the box ∏[c_n±1e-10]. CRUX: the atom→Jacobi map is
  bounded (α_j∈[0,~0.03]) yet has e^{cj} oscillatory gradients, so |δ_n|≤1e-10 alone does
  NOT exclude the adversarial (malignant) face; a certificate needs the STRUCTURE of
  δ_n=γ^true−center (smooth/rounding-noise) fed through the K1 head-suppression, i.e. the
  κ̂-cumulative Cholesky-pivot route. T2a-QT stays OPEN, reduced to the K1/κ̂ campaign
  (our lane). Frozen-center certificate (the sent T2a object) is unaffected —
  it was always honestly scoped to the dyadic-center object.
  [SUPERSEDED SAME DAY — see next entry: the "e^{cj} wall / hard K1 lane" reading was a
  MISTAKE (wrong kernel); the transfer is benign and substantially closes.]

- 2026-07-22 (GAP-CLOSURE — **T2a-QT SUBSTANTIALLY CLOSED**; corrects the entry above.
  `FINDINGS_T2a_QT_reduction.md` v2 + `t2a_qt_decisive_adversarial.py`,
  `t2a_qt_true_sensitivity.py`, `t2a_qt_weyl_close.py`). The pessimism was a mis-identified
  object: the e^{cj} came from the Theorem-1 kernel (polynomial derivatives p'_j ~1e291),
  which is NOT the atom-position sensitivity ∂α_j/∂x_n. The decisive test settles it:
  RANDOM δ_n∈{±1e-10} → Δα~2.5e-11; ADVERSARIALLY aligned δ → Δα~1e-14..1e-13 (≪ L1·ε) —
  benign in EVERY direction. The TRUE sensitivity (stable dps-40 full Jacobian):
  max_j Σ_m|∂α_j/∂x_m| = 52.667, |∂β_j/∂x_m| = 25.371 — bounded ~O(10¹), not e^{cj};
  box-worst ‖ΔJ‖∞ ≤ 6.69e-11. THE CLOSE (Weyl): frozen-center pencils PSD with margins δ
  (re-verified independently: drop-4 5.82e-5/4.23e-4, drop-1 1.09e-2/1.26e-3 — MATCH the
  IB-audit 60-digit rebuild), and ‖ΔJ‖₂ ≤ ‖ΔJ‖∞ ≪ δ_min ⇒ λ_min(true) ≥ δ − ‖ΔJ‖ > 0 for
  all four ⇒ **the KLMN form bound holds at the TRUE quantiles**, headroom 8.7e5–2.7e7×.
  GRADE: T2A_TRUE_QUANTILE_FORM_BOUND OPEN → **CERTIFIED-modulo-sensitivity-ceiling** — the
  one remaining item is a RIGOROUS ceiling on the O(10¹) sensitivity (any value < 7.4e5
  closes it; measured 53 ⇒ 4 orders slack): the explicit-constant G-HROT lemma (item 3.8)
  or validated forward-AD at the center. Same formality/headroom character as the sealed
  cert's θ-module. Correction logged: the GAP_LIST "e^{cj} wall" and "reduces to hard K1
  lane" claims are WITHDRAWN.)

- 2026-07-22 (GAP-CLOSURE — **G-HROT explicit constant ATTEMPTED: clean rigorous
  REDUCTION proven, but NOT fully closed**; `T2_gap_closure_2026-07-22/`
  FINDINGS_GHROT_reduction.md + ghrot_reduction_check.py). Target: the rigorous sensitivity
  ceiling that would upgrade T2a-QT to full CERTIFIED. RESULT — proven+verified reduction
  **‖J'−J‖₂ ≤ max_n|Δx_n| + 2·x_max·‖U−U'‖** (U = Jacobi eigenvector matrix, columns φ_n
  with fixed first component √w_n), reducing the entire ceiling to an ε-Lipschitz bound on
  the ON-frame rotation ‖U−U'‖. Numerics: operator-norm sensitivity ‖ΔJ‖₂/max|Δx_n| ≈
  1.0–1.5 (tamer than the L1=53); frame rotation ‖U−U'‖/max|Δx_n| ≈ 10–85 (bounded, O(10¹),
  measured). NOT closed by elementary means: Davis–Kahan is circular + vacuous (min atom
  gap ~9e-5 ≪ 2·x_max≈0.47), trivial ‖U−U'‖≤2 doesn't shrink with ε. The ε-Lipschitz
  property holds ONLY because the norming constants w_n are FIXED while eigenvalues move —
  i.e. the inverse-spectral / κ̂ conditioning (κ̂=5.5956 IS this constant's scale). This is
  the SAME object as T2a-QT's remaining ceiling; both wait on the one κ̂-conditioning lemma.
  Uniform statement (OUR K1/κ̂ lane — Theorems 1–2 are era-2 ours; not pre-assigned to IB):
  prove ‖U−U'‖ ≤ C'·max_n|Δx_n| explicit (any C'<1.6e6 suffices; measured ~O(10¹)).
  G-HROT item 3.8 annotated: reduction added; explicit constant still [GAP]. T2a-QT remains CERTIFIED-modulo-ceiling (unchanged grade; the
  ceiling is now sharply named).)

- 2026-07-22 (GAP-CLOSURE — **G-P2 K2-constant CERTIFIED**; folder-search corrections to
  P1/M1-HORIZON). After Selina flagged "check what already exists" (the sent to_Ilya_*
  packages), a search corrected two mislabels: **P1 is CLOSED at THEOREM grade** (the caustic
  theorem G-D2b/F10: κ_j = 1 + a_∞μ^{1/3} + R_j, Olver/Airy; R1/R2/R3 + P1a-companion proven
  07-18) — my "P1 open/hard/offer-to-IB" was wrong (memory index [[t2-stage26-identification-verdict]]
  already said so); and **M1-HORIZON's tool (Olver/Airy at the caustic) EXISTS** (built for
  the caustic theorem) — reassess, don't call it intractable. New memory
  [[check-existing-before-declaring-gaps]]. CLOSE: **G-P2** — K2's Theorem-3 transport-remainder
  constant sup_s|J″| upgraded from float64 stencil (1e-3) to EXACT ball-grade 2nd derivative
  via 2nd-order jets through Lanczos (flint-arb, prec 16000, ALL rows radius 0): drop-4
  sup|α″|=0.01137 (j=23), drop-1 sup|α″|=0.09177 (j=3), both max at s=1; validated vs the
  sealed stencil. AWS was considered and declined (single-threaded arb job; the fix was the
  library, not cores). Remaining open in the T2/T2a lane: M1-HORIZON (uniform horizon lemma
  via the existing caustic machinery); T2a-SP is already-rigorous (arb-grid = presentation).

- 2026-07-22 (GAP-CLOSURE — **M1-HORIZON ADVANCED: "3.2√N SHARP" → a SCALING LAW**;
  `T2_gap_closure_2026-07-22/FINDINGS_M1_HORIZON_scaling.md` + m1_horizon_{probe,scaling,
  caustic}.py). Took the "real swing via the caustic machinery" (per Selina). RESULT: the
  downdate s²-floor (s²_0=1, s²_{j+1}=s²_j−g²_j) has a scaling limit under j=ξ√N —
  **s²_{ξ√N} → s²_∞(ξ) = ∫_ξ^∞ G(η)dη, G(ξ)=8ξS(ξ)², with ∫_0^∞ G = 1 EXACT** (algebraic,
  from s²_0=1 & s²→0; measured 1.00000 every N). Scaling collapse verified N-stable
  (N=400/1600/6400: G(0.75)=0.901→0.905→0.906). The bridge g_i=√(2(4i+3)/N)|S_i| verified;
  S(ξ)=lim_N S_{ξ√N}(N) is the caustic-limit of Σ(−1)^{n+1}j_{2i+1}(z_n), <½ (=0.486,0.448,
  0.384,0.298,0.196,0.089 at ξ=0.25..1.5, converged). **The "3.2√N" is a THRESHOLD crossing,
  not a sharp cutoff:** ξ_ε = 2.38(1e-3)/2.73(1e-4)/3.33(1e-6)/4.05(1e-9), N-stable — 3.2 ≈
  ξ at ε≈1e-6 (the session-4 "SHARP" tag confirmed as an overclaim, exactly the audit's
  read). MECHANISM: caustic non-uniformity of the g-lemma — the fixed-j identity
  S_i(N)→(−1)^i/2 holds, but the double limit i=ξ√N gives S(ξ)<½; turning point n*/N→0 =
  large-order (Airy) effect, far oscillatory tail vanishes at nodes. GRADE: M1-HORIZON
  MEASURED "3.2√N SHARP" → SCALING LAW (numerically solid + exact normalization; the
  uniform-in-j statement the audit asked for). Remaining (offerable, our caustic lane): the
  closed form of S(ξ) via the Legendre-integral (Theorem D1) + Airy (caustic theorem)
  machinery → closed G, s²_∞(ξ), ξ_ε.)

- 2026-07-22 (GAP-CLOSURE — M1-HORIZON, the caustic-profile swing: **S(ξ) IN CLOSED FORM**;
  `m1_horizon_closedform.py`). Derived via the Theorem-D1 machinery (Poisson rep
  j_{2i+1}=(−1)^i∫sin(zt)P_{2i+1} + companion alternating-sin identity; the 1/cos(πt/2)
  singularity at t=1 + Mehler–Heine P_ν(1−u)≈J_0((2i+1)√(2u)) collapse the sum): the
  caustic-limit of the g-lemma alternating Bessel sum is **S(ξ) = ½ − (1/π)Si(2ξ²/π)**
  (Si = sine integral). CONFIRMED against the direct sum across the profile (0.4873/0.3019/
  0.0929 vs 0.4864/0.2983/0.0890 at ξ=0.25/1/1.5), S(0)=½, S→0, and ∫_0^∞ 8ξS² = 0.9998 ≈ 1
  (exact normalization). This IS the uniform-in-j deviation of Σ(−1)^{n+1}j_{2i+1}(z_n) from
  (−1)^i/2 that the audit asked for. HONEST BOUNDARY: this does NOT yet pin the horizon
  constant ξ_ε — the horizon uses g²_j and the bridge g_j=√(2(4j+3)/N)S_j is a LOW-j
  approximation (true |g_j| ~0.6× the bridge at ξ=2), so 8ξS² and the true G(ξ) share total
  mass 1 but the closed form is heavier-tailed (solving ∫_ξ^∞8ηS²=ε gives ξ_ε≈21 ≠ measured
  2.4–4). So: caustic profile S(ξ) CLOSED; horizon ξ_ε stays SCALING-LAW (measured),
  reduced sharply to the true-g_j-vs-S_j correction (the remaining caustic ingredient).)

- 2026-07-22 (GAP-CLOSURE — M1-HORIZON, HP settles the g_j-vs-S_j question;
  `m1_horizon_hp_bridge.py`, mpmath dps 220). Recomputed g_j (mpmath ODD-Lanczos) AND S_j
  (mpmath spherical Bessel) — no float64/scipy artifacts. **(1) The 3.3√N horizon is REAL:**
  HP g_j gives j*=66=3.30√N, identical to float64 — the float64 Lanczos was NOT corrupted,
  and the closed-form 8ξS² route (ξ_ε≈21) does NOT describe the horizon. **(2) The bridge
  g_j=√(2(4j+3)/N)S_j genuinely fails past ξ≈1** (c=g/bridge = 1.04/1.86/0.63/0.21/0.043 at
  ξ=1/1.5/2/2.5/3). MECHANISM: the true G(ξ)=g_j²√N decays like exp(−≈1.45ξ²) (Gaussian) —
  the horizon g_j sits in the EVANESCENT (beyond-the-caustic Airy) regime, exponential
  decay, whereas the Bessel sum S(ξ) has a slow 1/ξ² algebraic tail; ⟨e₀,w_j⟩ selects the
  evanescent tail. So S(ξ) (Bessel-sum profile) and the horizon g_j profile are opposite
  sides of the caustic. NET: horizon 3.3√N REAL (HP); S(ξ) CLOSED; ξ_ε reduced to the g_j
  evanescent-Airy profile G(ξ)~exp(−cξ²) — a fresh beyond-turning-point Airy calculation,
  now precisely posed. The scaling law + exact normalization + this mechanism are the
  established advance.)

- 2026-07-22 (GAP-CLOSURE — **M1-HORIZON CLOSED: G(ξ) and ξ_ε IN CLOSED FORM — the horizon
  is a Dyson gap-probability ratio**; `T2_gap_closure_2026-07-22/
  FINDINGS_M1_HORIZON_evanescent_closedform.md` + five scripts/logs). The staged
  evanescent-Airy task executed; it closed EXACTLY, not just asymptotically. THEOREM
  (exact at every finite N): g_j² = (4j+3)/(2N)·det(I−Γ_E(j+1))²/[det(I−Γ_O(j))det(I−Γ_O(j+1))],
  Γ = CD-kernel Grams of the infinite even/odd string systems on the REMOVED tail atoms
  n>N. Chain: (E1) g_j = second-kind function at 0; (E2) Christoffel–Wronskian collapse
  g_j² = h̃_j/(2N|P̃_j(0)P̃_{j+1}(0)|) — VERIFIED |ratio−1| ≤ 8e-118 (identity grade);
  (INF) h̃_j^∞ = (4j+3)|P̃_jP̃_{j+1}(0)|^∞ EXACT IN ℚ (j≤59; equivalent to the proven gem
  identity — the infinite part is the naive 2ξ law); (E3) truncation = exact Uvarov
  downdate = Fredholm factor, end-to-end composition verified 1e-10..1e-16 (N=200, no
  Lanczos on the predicting side). SCALING LIMIT: **G(ξ) = 2ξ·[det(I−K⁺_L)/det(I−K⁻_L)]²,
  L = 2ξ²/π** (odd/even sine kernels on (0,1) = Bessel hard-edge ν=±½ = Dyson E_± gap
  determinants; same band-limit as S(ξ)); convergence of the finite-N dets to the sine
  kernels certified at the 1/√N rate (closed−G(N) ratios 0.49–0.51 per 4×N, N=400→6400),
  and the exact composition reproduces the HP-measured G table to 4–5 digits. OUTPUTS:
  mass ∫G = 0.999996 (no fitted parameter); asymptotics G = 4ξe^{−4ξ²/π}(1−π/8ξ²+…)
  (TW/Ehrhardt hard-edge constants at ν=∓½; ln2 constant confirmed to 1.9e-5, 1/L coeff
  = −1/4); s²_∞(ξ) = (π/2)e^{−4ξ²/π}; **ξ_ε = √((π/4)ln(π/2ε))**: 2.394/2.748/3.344/4.076
  at ε=1e-3/-4/-6/-9 vs measured 2.38–2.39/2.73–2.74/3.33–3.34/4.05–4.06 (measured
  converging to closed at the certified 1/√N rate). The c(ξ) bridge mystery resolved:
  c = (D_E/D_O)/(2S), hump = zero of S at ξ≈1.74. GRADE: M1-HORIZON SCALING-LAW →
  **CLOSED FORM** (exact finite-N theorem + numerically-solid scaling layer; remaining
  mechanical steps: one-page INF↔gem equivalence write-up + the Euler–Maclaurin uniform
  lemma for the chirp→sine-kernel limit). Float-trap lesson (new genus): float64
  Gauss–Legendre NODES corrupt near-critical Fredholm dets past L≈14 (1e-16 node error vs
  near-1 prolate eigenvalues) — mpf-refined nodes required. The audit's uniform-in-j
  horizon item is now fully answered: scaling law + mechanism + closed-form constants.
  Not RH/GRH.)

- 2026-07-22 (GAP-CLOSURE — **M1-HORIZON mechanical steps DONE: full theorem-grade
  write-ups for both layers**; `T2_gap_closure_2026-07-22/WRITEUP_M1_HORIZON_exact_layer_
  theorem.md` + `WRITEUP_M1_HORIZON_scaling_lemma.md` + 3 new scripts/logs). Part I
  (exact layer) PROVEN self-contained: E2 written with the A-sequence (associated-solution)
  + Casoratian formulation — finite AND infinite N, no divergent moment anywhere; **NEW
  closed forms: h̃_j^∞ = 1/[(4j−1)!!(4j+1)!!], P̃_j^∞(0) = (−1)^j/(4j−1)!!** with a 3-line
  induction (a_j²(4j−1)(4j−3) = α_{2j} kills the cross term), certified in ℚ TWO independent
  ways (α-recurrence j≤81; Bernoulli-rational moments → Hankel dets j≤10, making the tan
  S-fraction contraction itself ℚ-certified); E3 proven (rank-T Hankel update + CD-Gram);
  COROLLARY: independent determinantal re-proof of the gem identity |Σ(−1)^{n+1}j_{2j+1}(z_n)|
  = ½. Part II (scaling lemma) — every mechanism proven, constants certified: **exact
  damped-chirp representation** Q(l,z) = Σ(−1)^kR_k y^{2k+1}/(2k+1)!, R_k = ∏_{d≤2k}(1−d(d+1)/c)
  ∈ (0,1] (consecutive-integer pairing; ℚ-checked), entrywise bounds |Q−sin y| ≤ B⁻(y)/c,
  B⁻ = y²sinh y+(y³/3)cosh y (proven; 10× headroom measured); error split: D_chirp = O(1/N)
  proven-shape (ratios 0.24–0.27, N·const stable −0.11/−0.05); **D_disc IDENTIFIED as a pure
  parity-resolved band-edge shift** — midpoint-effective edge l_eff = 2j−1 (even) / 2j (odd),
  prediction ratios 0.98–1.02 across N=200/800/3200 with O(1/N) residuals (N·resid −0.22 /
  +0.061 stable) — the global 1/√N rate fully accounted for; det-continuity via certified
  spectral-gap table (1−λ_max down to 1.1e-5 at ξ=3.35; gap ~ e^{−1.9L} ⇒ uniform-on-compacts
  statement). GRADE: THEOREM M1-HORIZON now stands at write-up grade both layers; the single
  remaining polish is assembling one displayed symbolic C(ξ) from the certified components
  (mechanical bookkeeping). Not RH/GRH.)

- 2026-07-22 (GAP-CLOSURE — **M1-HORIZON: the displayed symbolic C(ξ) ASSEMBLED — the
  scaling lemma's last polish item done**; `T2_gap_closure_2026-07-22/
  m1_horizon_C_assembly.py` + log; WRITEUP Part II §5 rewritten as the final display).
  THE CONSTANT: |lnG_N(ξ) − lnG(ξ)| ≤ A(ξ)/√N + B(ξ)/N for N ≥ N₀(ξ), with
  **A(ξ) = (6ξ/π)[δ₊(L̂)+δ₋(L̂)] + 3/(4ξ)** — the structural find making A tight is that
  dK^±_L/dL is RANK ONE ((2/π)cos(Lu)cos(Lv) resp. sin·sin), so the edge term uses the
  EXACT band derivative δ_± = (2/π)⟨c_L,(I−K^±_L)⁻¹c_L⟩ (certified; → L/2 ± ½, measured
  4.089 vs 4.072 at L=7.14) instead of an e^{2L}-lossy resolvent-gap estimate; edge
  displacements exact (3ξ/2, ξ/2, 5ξ/2)/√N per determinant. **B(ξ)** = displayed
  1/N-edge part (2/π)[δ₊+(3/2)δ₋] + proven chirp trace-norm terms T_E, T_O (φ₊ = cosh y
  + (y/3)sinh y, φ₋ = sinh(y)/y + cosh(y)/3; validated 3–20× headroom vs measured
  D_chirp at ξ=1,2 × N=200..3200) over half-gaps + ONE certified-numeric component B_EM
  (EM residual beyond the edge shift; N·resid stable over N=200/800/3200 at ξ=1/1.5/2:
  0.05/0.27/1.28 summed parities; ×5 margin). VERIFIED: √N|Δln G| ≤ A + B/√N at every
  measured (ξ,N) (9/9 OK); A alone tight to 2.4–3.1× at ξ ≤ 2. Table: C(1)=3.9,
  C(1.5)=16.6, C(2)=510, with N₀ = 1/4/203; at ξ ≥ 2.5 C inflates through the chirp
  resolvent 2/gap₊ ~ e^{1.9L} (C(3.35)=3.4e9, N₀=1.3e9) — honest conservatism note:
  measured chirp effect stays ~1e-4, the A-part (carrying the rate) stays O(ξ²).
  GRADE: scaling lemma = displayed-constant grade, all components proven except B_EM
  (certified-numeric ×5). THEOREM M1-HORIZON: no polish items remain open; the honest
  residual boundary is (i) B_EM's numeric grade and (ii) the e^{1.9L} conservatism at
  deep ξ. Not RH/GRH.)

- 2026-07-22 (GAP-CLOSURE — **G-HROT route 1 / T2a-QT: the atom→Jacobi sensitivity
  ceiling CERTIFIED at ball grade** — the float-FD 52.667 replaced by a certified
  enclosure; INFINITE_SIDE campaign item 1, first session.
  `INFINITE_SIDE_open_items_2026-07-22/ghrot_route1_jacobian_arb.py` +
  `ghrot_route1_curvature_arb.py` + logs; `FINDINGS_GHROT_route1_certified_jacobian.md`).
  METHOD: per-direction first-order arb jets through the fixed-weight Lanczos map at the
  EXACT frozen centers (the G-P2-stable configuration; ball-radius value parts remain the
  recorded dead end), validated per system by the EXACT sum rules Σ_m∂α_j/∂x_m = 1,
  Σ_m∂β_j/∂x_m = 0 (from J(x+ε𝟙) = J(x)+εI) — deviations ≤ 9e-16, a joint certificate of
  all columns; N=60 FD cross-check 1e-5 rel. TOOLCHAIN DISCOVERY: full reorthogonalization
  was the SOURCE of the jet-ball blow-up (prec 8192 + reorth → radii inf; plain three-term
  recurrence — an exact-arithmetic no-op, rigor unaffected — → radii 0.0 at prec 8192,
  ~5 s/direction, 40× cheaper; applies to all future arb-jet campaigns). RESULTS (all four
  ladders, N=149, radii 0.0): max_j L1(α) = 52.6670 (d4-D; = FD) / 64.7129 (d4-F) /
  52.7277 (d1-D) / 64.5998 (d1-F) vs required ceiling 7.4e5 — met with 4 orders of slack;
  box-worst first-order ‖dJ‖∞ ≤ 6.0e-11 / 6.5e-11 / 2.5e-10 / 1.7e-10; all four pencils
  POSITIVE at the true quantiles (headroom 4.07e5× / 3.94e6× / 2.21e7× / 3.65e6×).
  Curvature companion (2nd-order jets, box-scaled adversarial directions at center):
  Taylor remainder ½|α″| ≤ 1.5e-20 — 9 orders below the first-order term, 15 below the
  binding margin; box-edge robustness: Jacobian re-certified at γ±1e-10 (both ℓ∞ edges),
  L1 IDENTICAL to center (52.6670/25.3708). GRADE: T2a-QT **CERTIFIED-as-computed (Abel;
  κ̂-excess + transport allowances) → CERTIFIED-first-order-exact (curvature residual
  only)** — the κ̂-excess allowance is ELIMINATED from the first-order term (direct ball
  computation, no unproven lemma at the center); sole remaining residual for the
  fully-PROVEN uniform tag = box-uniformity of the curvature (finite-config numeric
  allowance class — NOT "P1", per the G-D2b/F10 correction above), quantified: failure
  needs >15 orders of curvature growth inside the ℓ∞-radius-2.25e-11 box while α_j stays
  a-priori bounded in [0, x_max] at every real box config. Item 3.8's ceiling criterion
  (< 1.6e6) met at first order. CAMPAIGN EFFECT: item 1 collapses from "the bridge" to
  theorem-grade-only (route 2 folds into the ξ-operator-limit task via the Uvarov/Fredholm
  dictionary — the last production residual and the infinite-side conditioning question
  are the same object); the infinite-side frontier is now item 2. Not RH/GRH.)

- 2026-07-22 (CONSTRUCTION — **the ξ-operator limit IDENTIFIED: isometry + alternation +
  two-scale Dirichlet dynamics** — INFINITE_SIDE campaign item 2, first session; Gate A
  ("uniform-normalization infinite operator OPEN — sections not nested") answered at
  construction grade. `INFINITE_SIDE_open_items_2026-07-22/xi_limit_consistency.py` +
  `xi_limit_coeff_profile.py` + logs; `FINDINGS_XI_LIMIT_isometry_and_dirichlet.md`).
  (A) ALTERNATION THEOREM (finite N): sign(g_j) = (−1)^j via the Thm-1 Step-5 sign chain
  (sign⟨1/x,Q_j⟩ = sign P̃_j(0), (4j−1)!! law) — e₀'s mode profile is a band-top
  alternating wave × positive envelope; this REFUTES the task's naive candidate
  (N·J → multiplication by 1/(4ξ²)) and makes the layer dynamics a second-difference
  object. (B) BOUNDARY-LAYER ISOMETRY: T_N e₀ → √G in L²(0,∞) — norms EXACTLY 1 every N
  + certified pointwise law + Riesz–Scheffé; proof complete conditional on Part II
  constants. (C) TWO-SCALE DYNAMICS via the exact decomposition ⟨e₀,Je₀⟩ = Σa(Δγ)² +
  Σ(b−a−a′)γ² (machine 2e-19): fixed modes carry ALL the energy — A_∞ + B_∞ =
  0.023093 + 0.476907 = 0.500000 exactly (Lambert closed data, provable via the
  1/x-vector measure rep; measured N·A/N·B match); the LAYER sees only the Dirichlet
  energy at order N⁻²: **N²Σ_layer a(Δγ)² → ∫(√G)′²/(16ξ²)dξ CONFIRMED** (windows
  [1,2]/[1.5,2.5]: ratios 0.98956/0.94347 at N=1600 → 0.99792/0.97227 at N=6400, O(1/√N)
  rate); coefficient-deformation probe ρ_a = 16ξ²Na_{ξ√N} → 1 like c/(ξ√N) — the
  Fredholm deformations of the Jacobi data DIE in the limit. THE LIMIT OBJECT:
  (L²(0,∞), 𝔇 = ∫φ′²/(16ξ²)dξ, √G) + the exact fixed-mode ledger 1/2 = A_∞+B_∞ at the
  ξ=0 boundary. Surviving pencil data: sign structure, envelope G, the 1/(16ξ²)
  coefficient. GRADE: A proof; B proof (conditional as stated); C1 provable identity +
  confirmed value; C2 consistency-check grade — next step: Γ-convergence write-up of the
  layer form. Model lattice only; production untouched. Gate A attribution flagged
  (question IB's; construction ours; shared by default). Not RH/GRH.)

- 2026-07-22 (WRITE-UP + REDUCTION — **the layer form's exact derivative identity +
  the uniform conditioning reduction** — INFINITE_SIDE item 2 session 2;
  `INFINITE_SIDE_open_items_2026-07-22/WRITEUP_XI_LIMIT_layer_form_gamma.md`). The
  Γ-convergence plan was UPGRADED to an exact-identity architecture: (LEMMA 1, PROVEN)
  the CD kernel's rank-one j-update + determinant lemma give the EXACT finite-N ratio
  γ_{j+1}²/γ_j² = (4j+7)/(4j+3)·(1−q_{j+1}^E)²/[(1−q_j^O)(1−q_{j+1}^O)], q_j =
  ⟨(I−Γ(j))⁻¹ψ_j,ψ_j⟩ ∈ [0,1) — the discrete profile derivative IS a resolvent pairing.
  (LEMMA 2, derivation w/ certified components) on the layer q_j = (4ξ/π√N)δ_±(L) +
  O(1/N) via Part II's exact rank-one band derivative; summing gives √NΔ_jlnγ² →
  −(lnG)′ and the NEW displayed ODE **(lnG)′(ξ) = 1/ξ + (8ξ/π)(δ₋−δ₊)(2ξ²/π)** —
  internal lock against the closed form. (THEOREM) layer Dirichlet convergence at
  proven-architecture grade (one Part-II-rate assembly from write-up grade); measured
  derivative profiles −0.5023/−0.7681/−0.4644/−0.1654 at ξ=1/1.5/2/2.5 (N=6400) vs
  limits −0.4893/−0.7702/−0.4714/−0.1694, O(1/√N). (COROLLARY — the route-2
  conditioning REDUCTION, half-closed): the κ̂-excess is the same (Γ,ψ) pairing class
  with ‖ψ‖² ≤ 1 by the value-law normalization ⇒ **excess ≤ 1/gap(L) UNIFORM in (j,m)
  on bounded layer windows** (certified gap table; first uniform conditioning bound for
  the model lattice); remaining: K1K2 normal-form identity check + deep-window
  polynomialization (= item 3's anti-alignment, shared conservatism). Model lattice
  only; production untouched. Not RH/GRH.)

- 2026-07-22 (IDENTITY SESSION — **K1K2 normal form checked on the model lattice +
  the anti-alignment LAW quantified** — the shared target of items 1(route-2) and 3;
  `INFINITE_SIDE_open_items_2026-07-22/k1k2_normal_form_probe.py`, WRITEUP §4b; after
  re-reading frozen to_Ilya_K1K2_P1_program (Thm R1) + noting P1's model lattice 1/n²
  IS this campaign's lattice). (a) R1's cut-free form C_j(m) = ⟨ĥ^{(j)}, ĉ(m)⟩ verified
  machine-exact (1e-15, j ≤ 8; e^{cj} float64 wall at j ≥ 16 — full-j = arb/no-reorth
  job). ĉ-side of the (Γ,ψ) reduction DONE (projector column, Σĉ² = m/M ≤ 1 proven);
  ĥ-side OPEN and the plain-CS shortcut REFUTED (‖ĥ^{(j)}‖₂ = 5.55/4.35/11.86 at
  j = 2/4/8, growing) — §4's uniform bound stands only after ĥ is identified as a
  resolvent image of a value-law vector (the remaining content; negative result
  load-bearing). (b) ANTI-ALIGNMENT LAW (new, sharp): |⟨v_top, c_L⟩|²/‖c_L‖² ≈ 6·gap(L),
  stable L = 3/5/7.14/9 (ratios 5.6/6.2/5.6/6.4), δ₊ = 5.013 vs L/2+½ = 5.00 at L = 9
  where 1/gap⁺ = 3e6 — the polynomialization mechanism of item 3 measured: the pairing
  is polynomial BECAUSE the top-mode overlap is O(gap). Proof target: prolate-tail lemma
  |⟨v_top,c_L⟩|² = O(gap·L^k) — one classical lemma closes both the conditioning
  corollary's deep window and Part II's e^{1.9L} conservatism.
  [Same day, addendum — Selina's catch: the e^{cj} "wall" at (a) was ALREADY FIXED in
  the sent κ̂-enclosure engine (to_Ilya_T2a_gap_closure); retargeted to the model
  lattice + no-reorth (`k1k2_normal_form_arb_fullj.py`, prec 4096, 1 second, radii 0.0):
  **R1 verified EXACTLY (recon 0) at ALL tested j = 8..98 incl. boundary rows**; excess
  ≤ 2.85; ‖ĥ‖₂ up to 49.6 (CS refuted at every scale); P1b weighted sum FLAT-log
  3.1→4.5 at ball grade. Full-j is no longer pending.]
  [Same day, second addendum — **the ANTI-ALIGNMENT LEMMA PROVEN (Feynman–Hellmann)**:
  dK^±/dL rank one ⇒ dλ_n/dL = |⟨v_n,c_L⟩|² EXACT (verified ratio 1.00000, both
  kernels, L = 3/5/7.14; WRITEUP §4c). Corollaries: |⟨v_top,c_L⟩|²/(gap‖c‖²) → 2π =
  6.283 (explains the measured 5.6–6.4 via d ln gap/dL → −2, classical prolate); and
  δ_± = Σ_n d/dL[−ln(1−λ_n)] = −(d/dL)lndet(I−K^±) — the pairing class against c_L is
  LINEAR in L with NO resolvent-gap estimate ever needed: **item 3 residual 2 (resolvent
  part) CLOSED at lemma grade.** Left: the chirp-vector overlap law (one measurement +
  lemma), and Lemma A (ĥ resolvent identification) for the conditioning corollary.]
  [Same day, third addendum — chirp-overlap MEASURED on the entrywise envelope
  e ∝ B⁻(Lt): overlap/gap = 4.0/18/86/413 at L = 3/5/7/9, i.e. overlap ~ gap^{0.6} —
  **the envelope route to the chirp polynomialization is REFUTED** (load-bearing
  negative, WRITEUP §4d): the mechanism must be the TRUE error kernel's sign/rank
  structure via a Feynman–Hellmann pairing with Γ̇ itself, not its modulus. Next:
  extract the exact scaled error kernel from sealed Part II; Lemma A stays posed with
  the §4b ball-grade ĥ data as testbed.] Not RH/GRH.)

*Update discipline: flip tags in place with a date suffix (e.g. "[GAP → PROVEN 2026-07-20]"),
append one dated line here per session, keep frozen packages untouched, and record negative
results as results — they are load-bearing (see 1.1, 2.3, 3.2, 3.4, 6.2, 6.8).*
