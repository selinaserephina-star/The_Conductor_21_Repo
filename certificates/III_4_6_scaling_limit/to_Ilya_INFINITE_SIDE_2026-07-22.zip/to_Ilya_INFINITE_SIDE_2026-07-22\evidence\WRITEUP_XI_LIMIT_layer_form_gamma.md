# WRITE-UP — the layer Dirichlet form: exact discrete derivative, its limit, and the conditioning corollary

**Merkabit · Stenberg + Claude · 2026-07-22 (INFINITE_SIDE item 2, session 2).** Upgrades
finding C2 of `FINDINGS_XI_LIMIT_isometry_and_dirichlet.md` from consistency-check grade
toward write-up grade. The route is NOT abstract Γ-convergence: the profile has an exact
closed form (master formula), and the CD kernel's rank-one j-update makes the discrete
derivative an EXACT resolvent-pairing identity whose layer limit is Part II's certified
δ_± machinery. Model lattice only. Not RH/GRH.

## 0. Statement

**THEOREM (layer Dirichlet convergence).** For every window [ξ₁, ξ₂] ⊂ (0,∞),
  `N² Σ_{j∈[ξ₁√N, ξ₂√N]} a_{j+1}^{(N)} (γ_j − γ_{j+1})² → ∫_{ξ₁}^{ξ₂} (√G)′(ξ)²/(16ξ²) dξ`,
with error O(1/√N). (Numerics: ratios 0.98956/0.94347 at N=1600 → 0.99792/0.97227 at
N=6400 on [1,2]/[1.5,2.5]; derivative-level check §3.)

## 1. Lemma 1 — the exact discrete log-derivative (PROVEN)

The CD kernel satisfies `K̃_{j+1} = K̃_j + p̃_j ⊗ p̃_j`, so the tail Grams of Theorem 3
(exact-layer write-up) update by rank one: `Γ_E(j+1) = Γ_E(j) + ψ_j^E ⊗ ψ_j^E`,
`ψ_j^E[n] = √(2x_n) p̃_j^∞(x_n)` (n > N); likewise Γ_O with the ODD data. By the
determinant lemma, with
  **`q_j^E := ⟨(I − Γ_E(j))^{-1} ψ_j^E, ψ_j^E⟩ ∈ [0,1)`**  (PSD contraction, I−Γ ≻ 0
  proven in Theorem 3; q < 1 since det(I−Γ(j+1)) > 0):
  `det(I−Γ_E(j+1)) = det(I−Γ_E(j)) · (1 − q_j^E)`, same for O. Hence, from the master
formula `γ_j² = (4j+3)/(2N) · det_E(j+1)²/[det_O(j) det_O(j+1)]`:

  **`γ_{j+1}²/γ_j² = (4j+7)/(4j+3) · (1 − q_{j+1}^E)² / [(1 − q_j^O)(1 − q_{j+1}^O)]`**

— exact for every finite N and j. ∎ (Pure algebra on proven ingredients; no new
verification load beyond Theorem 3's.)

## 2. Lemma 2 — layer limit of the pairings (derivation grade; components certified)

On the layer j = ξ√N with L(j) = 2(j/√N)²/π: dL/dj = 4ξ/(π√N), and the scaled tail
Grams converge to the sine-kernel operators (Part II, with the certified rate). The
rank-one increment converges to Part II's EXACT band derivative — `dK^±_L/dL` is rank
one, `(2/π) c_L ⊗ c_L` (cos·cos for E, sin·sin for O) — so
  **`q_j^{E/O} = (4ξ/(π√N)) · δ_{+/−}(L) + O(1/N)`,  δ_± = (2/π)⟨c_L, (I−K^±_L)^{-1} c_L⟩**
(the certified objects of the C-assembly; δ_± → L/2 ± 1/2). Summing Lemma 1:
  `√N · Δ_j ln γ² → −[ 1/ξ + (8ξ/π)(δ₊ − δ₋)(L(ξ)) ] = −(d/dξ) ln G(ξ)`,
which is EXACTLY the log-derivative of the proven closed form
`ln G = ln 2ξ + 2[ln det₊ − ln det₋]` — an internal consistency lock (the identity
`(lnG)′ = 1/ξ + (8ξ/π)(δ₋ − δ₊)` is a **displayed ODE for G**, new in itself).
Uniformity on windows: same grade as Part II's det-continuity (certified spectral-gap
table); the O(1/N) remainder needs the Part II rate constants — the one assembly step
below write-up grade today.

## 3. Assembly and verification

`Δγ = γ_j(√(ratio) − 1) ≈ ½ γ_j Δln γ²`, so
`N^{3/4}(γ_j − γ_{j+1}) = ½ (N^{1/4}γ_j)(√N·(−Δ_j ln γ²)) + O(1/√N) → ½√G·(lnG)′ = (√G)′`
— the derivative-level convergence, MEASURED (N=1600→6400, 2-step symmetric):
ξ=1: −0.5147→−0.5023 (limit −0.4893); ξ=1.5: −0.7656→−0.7681 (−0.7702);
ξ=2: −0.4576→−0.4644 (−0.4714); ξ=2.5: −0.1616→−0.1654 (−0.1694) — O(1/√N) throughout.
Coefficient convergence `16ξ²N a_j^{(N)} → 1`: `a_j^{(N)2} = h_j^{(N)}/h_{j-1}^{(N)}`,
and by Theorem 3 the deformation ratio is a SECOND j-difference of ln det(I−Γ_O), i.e.
`ln(1−q_j^O) − ln(1−q_{j-1}^O) = O(1/N)` by Lemma 2 — plus the elementary infinite-part
`16j² a_j^∞ = 1 + O(1/j)`; both O(1/(ξ√N)), matching the measured ρ_a profile. The
window sum is then a Riemann sum of `(√G)′²/(16ξ²)` with O(1/√N) errors. ∎(modulo the
Lemma-2 uniformity constants)

**Grade: Lemma 1 PROVEN; Lemma 2 derivation with certified components; Theorem at
proven-architecture grade, one uniformity-constant assembly from write-up grade.** The
missing piece is bookkeeping of Part II's displayed rates through Lemma 2 — mechanical,
same character as the C-assembly.

## 4. The conditioning corollary (route 2 of item 1 — the reduction, posed and half-closed)

The κ̂-excess (K1K2 Theorem 2's derivative pairings — the ONE unproven-uniform component
of the Abel/κ̂ machinery) is, on the model lattice, the same object class as q_j: a
pairing `⟨(I−Γ)^{-1}ψ, ψ⟩` with Γ a PSD contraction Gram and ψ a value-law vector with
`‖ψ‖² ≤ 1` (the value-law normalization `Σ_n 2(4i+3) j_{2i+1}(z_n)² = 1` bounds every
partial/tail norm by 1). Hence the REDUCTION:

  **`excess ≤ ‖ψ‖² · ‖(I−Γ)^{-1}‖ ≤ 1/gap(L)`**

— UNIFORM in the mode index j and the atom cut m, on every bounded layer window, with
gap(L) from the certified spectral-gap table (1−λ_max ≥ 1.1e-5 to ξ = 3.35). This is a
genuine uniform conditioning bound for the model lattice — the first — at the price of
the e^{1.9L} deep-window growth (the SAME conservatism as Part II's chirp resolvent;
item 3's anti-alignment program would polynomialize both at once). What remains for the
full theorem: (i) write the K1K2 derivative pairings verbatim in the (Γ, ψ) normal form
(one identity-checking session); (ii) the deep-window polynomialization (item 3). NOT
claimed: any production/chi8 transfer (that lane is closed separately at certified grade,
FINDINGS_GHROT_route1_certified_jacobian.md).

## 4b. The identity session (same day): normal form checked; anti-alignment quantified

`k1k2_normal_form_probe.py` (+ this section), after re-reading the frozen
`to_Ilya_K1K2_P1_program_2026-07-18` (Theorem R1) and noting P1's model lattice
x_n = 1/n² IS (up to the half-shift) this campaign's lattice:

- **(Γ,ψ) status, honest:** R1's cut-free form `C_j(m) = ⟨ĥ^{(j)}, ĉ(m)⟩` is VERIFIED
  machine-exact on the model lattice (1e-15, j ≤ 8; float64 overflows at j ≥ 16 — the
  e^{cj} intermediates; the full-j probe is an arb job, cheap with the no-reorth
  toolchain). The ψ-side is DONE: ĉ(m) is a spectral-projector column with
  `Σ_i ĉ_i(m)² = m/M ≤ 1` proven (R1). **FULL-j BALL-GRADE CHECK (same day,
  `k1k2_normal_form_arb_fullj.py` — the SENT κ̂-enclosure engine of
  to_Ilya_T2a_gap_closure retargeted to the model lattice + no-reorth; 1 s, prec 4096,
  all radii 0.0):** recon error exactly 0 at j = 8/16/32/64/90/98 — R1 exact at ball
  grade through the boundary rows. Excess max_m|C_j| = 0.55 → 2.85 (j=98) bounded-mild;
  ‖ĥ^{(j)}‖₂ = 11.9 → 49.6 → 39.3 GROWS (15–20× above the true excess), so plain
  Cauchy–Schwarz (excess ≤ ‖ĥ‖‖ĉ‖) is REFUTED as the closing step at every scale;
  the weighted P1b sum Σ|ĥ_i|/(1+i) = 3.09/2.66/3.30/4.51/4.39/4.47 is FLAT-log on the
  model lattice at ball grade — (P1a) + this measured (P1b) reproduce the κ_j envelope; §4's `excess ≤ 1/gap` claim stands only once
  ĥ^{(j)} is identified as a resolvent image of a value-law vector — that identification
  (via the Bessel value laws + rank-one calculus of §1) is the remaining content of the
  corollary, NOT the norm bookkeeping. Correcting §4 accordingly: the reduction is
  (i)-complete on the ĉ side, open on the ĥ side.
- **Anti-alignment LAW (measured, sharp):** for the band-derivative vector c_L vs the top
  eigenmode of K^±_L: `|⟨v_top, c_L⟩|²/‖c_L‖² ≈ 6 · gap^±(L)`, stable across L = 3, 5,
  7.14, 9 (ratios 5.6/6.2/5.6/6.4 for K⁺; same law for K⁻), while δ_± stay exactly
  linear (δ₊ = 5.013 vs L/2+½ = 5.00 at L = 9, gap⁺ = 3.1e-7). **This is the
  polynomialization mechanism of item 3, quantified:** the resolvent pairing is
  polynomial because the top-mode overlap is itself O(gap). Concrete target for the
  proof: prolate-mode tail asymptotics ⇒ |⟨v_top, c_L⟩|² = O(gap·L^k) — one classical
  lemma, shared by the conditioning corollary and Part II's deep-ξ constant.

## 4c. The anti-alignment lemma — PROVEN (Feynman–Hellmann; same day)

**LEMMA.** For K^±_L with the exact rank-one band derivative dK^±_L/dL = c_L ⊗ c_L,
c_L(t) = √(2/π)cos(Lt) resp. sin(Lt), and any simple eigenvalue λ_n(L) with unit
eigenvector v_n: **`dλ_n/dL = |⟨v_n, c_L⟩|²` exactly** (first-order perturbation of a
simple eigenvalue against a rank-one derivative; simplicity classical for prolate
spectra). VERIFIED: ratio = 1.00000 at L = 3/5/7.14, both kernels
(`dλ/dL = 4.12e-2 … 9.71e-4` matching `|⟨v,c⟩|²` to all digits).

**COROLLARY 1 (the measured law explained).** `|⟨v_top, c_L⟩|² = −d(gap)/dL =
2·gap·(1+O(log L/L))` by the classical prolate asymptotic d ln gap/dL → −2; with
‖c_L‖² = (1/π)(1 + sin2L/2L) this gives `overlap/(gap·‖c‖²) → 2π = 6.283` — the
measured 5.6–6.4 of §4b.

**COROLLARY 2 (polynomialization of the pairing class — item 3 residual 2, resolvent
part, CLOSED).** `δ_± = ⟨c_L, (I−K^±_L)^{-1} c_L⟩ = Σ_n |⟨v_n,c_L⟩|²/(1−λ_n) =
Σ_n d/dL[−ln(1−λ_n)] = −(d/dL) ln det(I−K^±_L)` — each near-1 mode contributes the
log-derivative of its own Fredholm factor, a BOUNDED quantity; the sum is the derivative
of the Dyson log-det, hence LINEAR in L (δ_± → L/2 ± ½, the certified values), despite
1/gap = e^{~2L}. **No resolvent-gap estimate is ever needed for pairings against c_L.**
Remaining exponential conservatism in Part II sits ONLY in the chirp-error vector
(different ψ); its overlap law |⟨v_top, ψ_chirp⟩|² ≲ gap·poly is the one measurement +
lemma left of item 3 residual 2. Lemma A (ĥ^{(j)} resolvent identification, §4b) stays
the open half of the conditioning corollary.

## 4d. Chirp-overlap measurement (same day) — the ENVELOPE route REFUTED (load-bearing)

Measured |⟨v_top(K⁺_L), e_L⟩|² for the normalized entrywise chirp envelope
e_L(t) ∝ B⁻(Lt) = (Lt)²sinh + ((Lt)³/3)cosh: overlap/gap = 3.99 / 18.3 / 85.7 / 413 at
L = 3/5/7/9 — overlap ~ gap^{0.6}, NOT O(gap). **The entrywise envelope does NOT satisfy
the c_L anti-alignment law; the polynomialization of Part II's chirp term cannot come
from envelope bounds** — it must use the TRUE error kernel's sign/rank structure (rank
≤ 2j, oscillatory), i.e. a Feynman–Hellmann-type pairing with the actual Γ̇, not its
modulus. Next session: extract the exact scaled error kernel from the sealed Part II
write-up and measure |⟨v_top, ·⟩| on it directly. Lemma A (ĥ^{(j)} resolvent
identification) remains POSED, with the full-j ball-grade ĥ data of §4b as its testbed.

## 5. Manifest

Derivative-level check: inline session run (logged in
`xi_limit_consistency_run.log` addendum + this file §3). Window ratios:
`xi_limit_consistency_run.log`. Coefficient profile: `xi_limit_coeff_profile_run.log`.
Lemma 1 needs no new machine check (determinant lemma on Theorem-3-proven objects);
Lemma 2's δ_± are the certified C-assembly values. Next session: assemble Lemma-2
uniformity constants (→ write-up grade end-to-end); K1K2 normal-form identity for §4(i).
