# xi_limit_coeff_profile.py — INFINITE-SIDE item 2, coefficient-profile probe, 2026-07-22.
# The window test found N^2 * A_window / int (sqrtG)'^2/(16 xi^2) = 0.96, N-stable —
# so the limit Dirichlet coefficient is NOT the naive infinite-system 1/(16 xi^2).
# Probe: rho_a(xi) = 16 xi^2 * N * a_{j=xi sqrtN}^{(N)}  and same for b/(8 xi^2 N):
# if rho deviates from 1 with a stable profile, the limit form is
#   D(phi) = int (sqrtG-profile)'^2 * rho_a(xi)/(16 xi^2) dxi
# and the deformation rho_a is the surviving pencil datum. Also: fixed-mode limits
# A_inf = sum a^inf_{j+1}(ghat_j - ghat_{j+1})^2, B_inf (closed Lambert data) vs the
# measured N*A, N*B totals. Not RH/GRH.
import numpy as np, math
from xi_limit_consistency import odd_system, lanczos_modes, logG

LOG = open(__file__.replace('.py', '_run.log'), 'a')
def log(s):
    print(s, flush=True); LOG.write(s + '\n'); LOG.flush()

# ---- infinite Lambert data ----
def alpha(m): return 1.0 / ((2 * m - 1) * (2 * m + 1))
def b_inf(j): return alpha(2 * j + 1) + alpha(2 * j + 2)
def a_inf(j): return math.sqrt(alpha(2 * j) * alpha(2 * j + 1))   # j >= 1

# fixed-mode series with ghat_j = sqrt((4j+3)/2)
JMAX = 2_000_000
j = np.arange(JMAX)
gh = np.sqrt((4 * j + 3) / 2.0)
av = np.array([a_inf(k) for k in range(1, JMAX)])
bv = np.array([b_inf(k) for k in range(JMAX)])
A_inf = float(np.sum(av * (gh[:-1] - gh[1:]) ** 2))
pot = bv.copy(); pot[:-1] -= av; pot[1:] -= av
B_inf = float(np.sum(pot * gh ** 2))
log(f"fixed-mode infinite series: A_inf = {A_inf:.6f}  B_inf = {B_inf:.6f}  "
    f"A+B = {A_inf + B_inf:.6f}  (must -> 1/2; tail O(1/JMAX^2))")

for N in (400, 1600, 6400):
    x, u = odd_system(N)
    al, be, V = lanczos_modes(x, u)
    log(f"[N={N}] rho_a(xi) = 16 xi^2 N a_j  /  rho_b(xi) = 8 xi^2 N b_j  at j = xi sqrtN:")
    row = []
    for xi in (0.5, 1.0, 1.5, 2.0, 2.5, 3.0):
        jj = int(xi * math.sqrt(N))
        if jj + 1 >= len(be): continue
        ra = 16 * xi * xi * N * be[jj]
        rb = 8 * xi * xi * N * al[jj]
        row.append(f"xi={xi}: {ra:.4f}/{rb:.4f}")
    log("   " + "   ".join(row))
LOG.close()
