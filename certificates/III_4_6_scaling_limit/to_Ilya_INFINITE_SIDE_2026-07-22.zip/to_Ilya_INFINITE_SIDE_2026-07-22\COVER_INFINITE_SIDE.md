# COVER — the INFINITE-SIDE day: certified bridge, the ξ-limit object, and the lemma layer

**Merkabit · Stenberg + Claude · sealed 2026-07-22.** One day, three campaigns of
`INFINITE_SIDE_open_items_2026-07-22/` (the living folder stays active; this package is
the frozen record). Ledger snapshot included (`LEDGER_SNAPSHOT_EVIDENCE_CHAIN_T2_pin.md`)
— §9's five dated 2026-07-22 entries are the forensic spine of everything below.
Not RH/GRH anywhere.

## How the pieces relate to the operator program

**1. The production bridge is closed (T2a-QT, item 3.8).** The atom→Jacobi sensitivity
ceiling is CERTIFIED at ball grade by direct per-direction arb jets at the exact frozen
centers — max_j L1(α) = 52.6670 vs required 7.4e5, all four ladders, radii 0.0, exact sum
rules (Σ∂α = 1, Σ∂β = 0) as joint validation; all four pencils positive at the true
quantiles (headroom ≥ 4.07e5×); curvature ≤ 1.5e-20 at center, box-edge Jacobians
identical to center. Grade: CERTIFIED-first-order-exact (curvature residual only — the
κ̂-excess allowance is eliminated). **The finite/production side no longer waits on any
infinite-side mathematics.** Toolchain: reorthogonalization was the CAUSE of arb-jet ball
blow-up; the no-reorth three-term recursion certifies at half precision, 40× cheaper.

**2. The infinite uniform-normalization operator EXISTS (Gate A answered, construction
grade).** The limit object is the triple **(L²(0,∞), 𝔇, √G)**, 𝔇(φ) = ∫φ′²/(16ξ²)dξ:
isometry T_N e₀ → √G PROVEN (norms exactly 1 + certified pointwise law + Riesz–Scheffé);
alternation sign(g_j) = (−1)^j a THEOREM at finite N (band-top wave — refutes the naive
multiplication limit); dynamics TWO-SCALE: exact fixed-mode energy identity
1/2 = A_∞ + B_∞ = 0.023093 + 0.476907 (Lambert data), layer Dirichlet identity
N²Σa(Δγ)² → ∫(√G)′²/(16ξ²)dξ confirmed at O(1/√N). "Sections not nested" was structure,
not obstruction: e₀ travels with N; what survives the limit is the sign structure, the
envelope G, and the 1/(16ξ²) coefficient.

**3. The lemma layer (the write-up engine).** Exact rank-one discrete derivative
identity (PROVEN — the profile's log-derivative IS a resolvent pairing q_j ∈ [0,1));
its layer limit is Part II's certified δ_± (derivation grade), yielding the displayed
ODE **(lnG)′ = 1/ξ + (8ξ/π)(δ₋ − δ₊)(2ξ²/π)**. K1K2/R1 normal form verified EXACTLY at
ball grade for ALL j (the sent κ̂-enclosure engine + no-reorth: 1 second). The
**anti-alignment lemma is PROVEN** (Feynman–Hellmann on the rank-one band derivative:
dλ_n/dL = |⟨v_n,c_L⟩|² exactly; measured ratio 1.00000) with two corollaries: the 2π
overlap law, and δ_± = −(d/dL)lndet — the resolvent-pairing class is LINEAR in L, no
gap estimate ever needed: **Part II's deep-ξ conservatism is closed for that class.**
Two load-bearing negatives: plain Cauchy–Schwarz on ĥ refuted at every scale (ball
grade); the entrywise chirp ENVELOPE refuted (overlap ~ gap^0.6, not O(gap)).

## How the pieces become proof (the remaining list, sharply)

| # | statement | status | what closes it |
|---|---|---|---|
| 1 | ξ-limit theorem (C2) at write-up grade | proven-architecture | thread Part II's displayed rate constants through Lemma 2 (mechanical) |
| 2 | uniform conditioning (κ̂) on the model lattice | reduction half-done | **Lemma A**: identify ĥ^{(j)} as a resolvent image of a value-law vector (full-j ball testbed ready) |
| 3 | Part II chirp term → polynomial C(ξ) | mechanism identified | extract the TRUE scaled error kernel from sealed Part II; measure/prove |⟨v_top, Γ̇⟩| via the same Feynman–Hellmann pairing |
| 4 | B_EM constant → proven | untouched (item 3 residual 1) | second-order Euler–Maclaurin on the rank-one chirp families |

Everything above the line is finished mathematics at its stated grade; everything below
is a posed, bounded target with its tools already built. Production/chi8 claims: none
beyond the sealed T2a lane. Attribution: Gate A question is IB's; all constructions,
lemmas, certificates and negatives here are this collaboration's (shared by default).

## Contents

`evidence/` — 5 findings/write-ups, 6 scripts, all run logs; the stamped PLAN and task
files of the campaign folder; `LEDGER_SNAPSHOT_EVIDENCE_CHAIN_T2_pin.md` (full ledger
as of seal). SHA256 alongside the zip.
