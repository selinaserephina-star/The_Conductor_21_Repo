# NEXT-SESSION TASK — THEOREM M1-HORIZON: upgrade the two numeric-grade residuals

**Staged 2026-07-22 (Stenberg + Claude). Goal: remove the two flagged, bounded,
non-blocking numeric-grade components inside the sealed horizon theorem
(to_Ilya_THEOREM_M1_HORIZON_2026-07-22, COVER "honest boundaries"). Polish lane —
pick up when a session wants a well-posed bounded target. Not RH/GRH.**

## Residual 1: B_EM — the Euler–Maclaurin constant (certified-numeric ×5 → PROVEN)

**Where it sits:** Part II §5 (`WRITEUP_M1_HORIZON_scaling_lemma.md`): the displayed
constant's one numeric component — the discretization residual BEYOND the identified
band-edge shift. Measured N·resid, stable over N = 200/800/3200:
ξ=1: −0.03/+0.02 (even/odd); ξ=1.5: −0.21/+0.061; ξ=2: −1.25/−0.02. Carried ×5.

**The task:** write out second-order Euler–Maclaurin/midpoint for the two quadratures
(i-sum → s-integral with the parity-offset lattice s̃_i = l(l+1)/4N; n-lattice →
ρ-integral, exact midpoint lattice) applied to the rank-one chirp families
u_s u_sᵀ. Structure that makes it tractable: the first-order boundary terms ARE the
band-edge shift (already displayed and certified 0.98–1.02); what remains is the
interior second-order term = (1/24N)·∫(second ξ-derivative of the rank-one family) —
a displayed trace-norm integral of explicitly differentiable kernels. Success = a
displayed B_EM(ξ) formula whose values at ξ = 1/1.5/2 dominate the measured constants
(headroom factor to report), replacing the ×5-margin table entry.

**Components already isolated:** `m1_horizon_scaling_lemma_components.py` +
`m1_horizon_lemma_addendum.py` (+logs) — chirp/edge/residual split with rates.

## Residual 2: the deep-ξ chirp-resolvent conservatism (e^{1.9L} → polynomial)

**Where it sits:** B(ξ)'s chirp term uses |Δlndet| ≤ ‖ΔΓ‖_tr·(2/gap₊), and
gap₊(L) ~ e^{−1.9L}: C(2.5) = 7.5e4, C(3.35) = 3.4e9, N₀(3.35) = 1.3e9 — while the
MEASURED chirp effect on lndet stays ~1e-4 at all tested (ξ, N). The inflation is in
one bounding step, not in reality.

**The task:** replace the resolvent-gap bound by a structured one. Routes:
1. **Log-derivative along the interpolation:** d/dt lndet(I−Γ_t) = −tr[(I−Γ_t)⁻¹Γ̇]
   with Γ̇ = Γ^chirp-error, which is CONCENTRATED (rank ≤ 2j, entries ∝ B∓(y)/c) —
   bound the trace against the eigenvector localization of the near-1 modes (the top
   prolate modes live at small φ = 1/ρ, i.e., LARGE n, where the chirp error is
   SMALLEST — quantify this anti-alignment; that is why reality is 1e-4).
2. **Determinant-ratio route:** bound lndet(I−Γ) − lndet(I−Γ^ch) =
   lndet(I − (I−Γ^ch)^{-1/2}ΔΓ(I−Γ^ch)^{-1/2}) and split ΔΓ by the spectral projector
   of Γ^ch at threshold 1/2: the near-1 block is low-dimensional (# ≈ 2L/π modes) —
   handle it by exact finite-dimensional determinant with certified entries; the rest
   pays only factor 2.
   Success = C(ξ) polynomial in ξ (target O(ξ⁶) or better) uniformly to ξ = 4.1
   (covers ξ_ε at ε = 1e-9), with N₀(ξ) brought to ≤ 1e4 throughout.

## Grade target and scope

Both residuals: displayed-symbolic grade, verified against the existing measured
tables (no new measurement campaigns needed). This upgrades THEOREM M1-HORIZON Part II
from "all mechanisms proven + one numeric constant" to fully displayed. If sent,
package as an ADDENDUM to to_Ilya_THEOREM_M1_HORIZON_2026-07-22 (SHA 4edb5168…),
frozen-package discipline: new dated folder, never edit the sent one.

## Files to build on

`T2_gap_closure_2026-07-22/WRITEUP_M1_HORIZON_scaling_lemma.md` (§5 = the current
display), `m1_horizon_C_assembly.py` (+log; δ_±, gaps, EM measurements, T-bounds),
`m1_horizon_scaling_lemma_components.py`, `m1_horizon_lemma_addendum.py` (+logs).
Float-trap: GL nodes at working precision for any near-critical det (see
`m1_horizon_constant_hp.py`).
