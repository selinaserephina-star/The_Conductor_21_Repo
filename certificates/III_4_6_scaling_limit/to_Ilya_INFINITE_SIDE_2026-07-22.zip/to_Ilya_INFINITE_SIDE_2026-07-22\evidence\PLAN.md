# INFINITE-SIDE OPEN ITEMS — staging folder (opened 2026-07-22, post M1-HORIZON seal)

**State of play when this folder was opened:** THEOREM M1-HORIZON is closed and sealed
(`to_Ilya_THEOREM_M1_HORIZON_2026-07-22.zip`, SHA 4edb5168…, delivery pending Selina).
The T2/T2a audit lane has NO open proof items on the finite side. What remains open is
the infinite side, exactly three items, staged as the three task files here. Ledger:
`LEDGER/EVIDENCE_CHAIN_T2_pin.md` §9 (proof log) + `LEDGER/AUDIT_REGISTER.md` (traffic).
Not RH/GRH anywhere.

## The three tasks (priority order)

1. **`NEXT_SESSION_TASK_GHROT_khat_lemma.md`** — the G-HROT explicit constant /
   κ̂-conditioning lemma. HIGHEST VALUE: it is the ONE bridge between model-exact and
   production-exact results (the T2a-QT ceiling). 4 orders of magnitude of slack
   available; a validated-numerics route exists.
   **[2026-07-22 later session: route 1 EXECUTED — first-order ceiling CERTIFIED at ball
   grade (L1 = 52.667 certified vs required 7.4e5); curvature residual quantified
   (≤1.5e-20 at center). See FINDINGS_GHROT_route1_certified_jacobian.md. Open here:
   route 2 (structural Lipschitz) for the theorem-grade uniform close.]**
2. **`NEXT_SESSION_TASK_xi_operator_limit.md`** — the infinite uniform-normalization
   operator, re-posed in ξ-coordinates by the horizon theorem. Fresh, well-defined
   construction; the deepest structural item (Gate A's open point).
   **[2026-07-22 later session: LIMIT OBJECT IDENTIFIED — (L²(0,∞), 𝔇 = ∫φ′²/(16ξ²)dξ,
   √G); isometry PROVEN, alternation THEOREM, two-scale energy split exact
   (1/2 = 0.023093 + 0.476907), layer Dirichlet identity CONFIRMED at O(1/√N). See
   FINDINGS_XI_LIMIT_isometry_and_dirichlet.md. Open: Γ-convergence write-up + the
   route-2 conditioning corollary.]**
3. **`NEXT_SESSION_TASK_horizon_residuals.md`** — upgrade the two numeric-grade
   residuals inside THEOREM M1-HORIZON (B_EM constant; deep-ξ conservatism). Polish,
   not blocking; do when a session wants a bounded, well-posed target.
   **[2026-07-22 later session: residual 2's mechanism QUANTIFIED — anti-alignment law
   |⟨v_top,c_L⟩|² ≈ 6·gap(L) measured (WRITEUP_XI_LIMIT §4b); proof target = one
   prolate-tail lemma, shared with item 1's conditioning corollary.]**

## Discipline reminders (standing)

- Check existing before declaring gaps: consult the memory index + grep sent
  `to_Ilya_*` packages before calling anything open/hard/offerable.
- Sent folders are FROZEN; this folder is the living home for these three campaigns;
  new results → dated findings files here; ledger §9 entry per session.
- Collaboration credit: shared by default; do NOT pre-assign lanes to IB.
