# NEXT-SESSION TASK — the infinite uniform-normalization object in ξ-coordinates

> **STATUS 2026-07-22 (same day, later session): LIMIT OBJECT IDENTIFIED — see
> `FINDINGS_XI_LIMIT_isometry_and_dirichlet.md`.** Route-1 candidate as posed is
> REFUTED-and-replaced: alternation sign(g_j) = (−1)^j is a finite-N THEOREM (band-top
> wave), so the limit dynamics is NOT multiplication — it is TWO-SCALE: exact fixed-mode
> energy identity 1/2 = A_∞ + B_∞ (= 0.023093 + 0.476907, Lambert data) + the layer
> Dirichlet form 𝔇(φ) = ∫φ′²/(16ξ²)dξ at order N⁻² (confirmed, O(1/√N) rate; coefficient
> deformations die). Isometry T_N e₀ → √G PROVEN (Riesz–Scheffé, conditional on Part II
> constants). The limit object: (L²(0,∞), 𝔇, √G).
> **Session 2 (same day): `WRITEUP_XI_LIMIT_layer_form_gamma.md`** — Lemma 1 (exact
> rank-one discrete derivative identity) PROVEN; Lemma 2 (q_j = (4ξ/π√N)δ_± + O(1/N))
> derivation grade; the displayed ODE (lnG)′ = 1/ξ + (8ξ/π)(δ₋−δ₊); conditioning
> reduction: κ̂-excess ≤ 1/gap(L) uniform in (j,m) on bounded windows. OPEN: Lemma-2
> uniformity-constant assembly (mechanical); K1K2 (Γ,ψ) normal-form identity; deep-window
> polynomialization (= item 3).

**Staged 2026-07-22 (Stenberg + Claude). Goal: build, rigorously, the N→∞ limit object
for the uniform-normalization side — the item Gate A of the Q2-operator-bridge audit
left OPEN ("uniform-normalization infinite operator OPEN — sections not nested") —
using the re-posing that THEOREM M1-HORIZON makes available. Fresh construction, now
well-defined. Not RH/GRH.**

## What is ESTABLISHED (do not re-derive; all in to_Ilya_THEOREM_M1_HORIZON_2026-07-22)

- The infinite COMPANION operator is the healthy object: deficiency (0,0), companion
  Carleman PROVEN (Q2-bridge audit 2026-07-19); its Jacobi data is explicit
  (odd-Lambert; now also h̃_j = 1/[(4j−1)!!(4j+1)!!], P̃_j(0) = (−1)^j/(4j−1)!!).
- The uniform vector e₀^{(N)} has NO fixed-mode limit in companion coordinates:
  g_j = ⟨e₀, w_j⟩ ≈ √((4j+3)/2N) → 0 for every fixed j. Its mass lives ENTIRELY in the
  boundary layer j = ξ√N with exact density **G(ξ) = 2ξ·[det(I−K⁺_L)/det(I−K⁻_L)]²**,
  L = 2ξ²/π, total mass exactly 1 (nothing at fixed j, nothing past the layer —
  Gaussian tail 4ξe^{−4ξ²/π}). So "sections not nested" is STRUCTURAL: e₀^{(N)} travels
  with N. Rate of approach: |lnG_N − lnG| ≤ C(ξ)/√N, displayed constant.
- The finite⇄infinite dictionary is EXACT: every finite-section Hankel-derived quantity
  = infinite-system closed form × CD-kernel Fredholm determinants on the removed tail
  (Uvarov downdate, Part I Theorem 3).

## THE TASK

Formulate and prove the limit statement. Candidate formulation (route 1 = the natural
one; refine as the mathematics dictates):

1. **The boundary-layer isometry.** Define T_N : ℝ^N → L²(0,∞) by
   (T_N e)(ξ) = N^{1/4}·⟨e, w_{⌊ξ√N⌋}⟩ (per-mode rescaling of the companion frame).
   PROVE: T_N e₀^{(N)} → √G in L²(0,∞) (norms → 1 already exact; the profile
   convergence is the certified scaling law — upgrade pointwise→L² with the C(ξ)/√N
   rate + Gaussian domination). This makes √G(ξ) THE infinite uniform-normalization
   vector, living on the caustic scale.
2. **The limit dynamics.** Identify the operator the rescaled companion Jacobi matrix
   induces on the layer: under j = ξ√N the three-term recurrence contracts to a
   differential/multiplication structure in ξ (the Jacobi coefficients b_j ≈ 1/(8j²),
   a_j ≈ 1/(16j²) at the critical point — the layer sees x ~ 1/(ξ²N)·(π²/4-scale);
   expect: multiplication by the spectral parameter rescaled as x = t/N, i.e., the
   limit pairing lives on (spectral t) × (mode ξ) with kernel structure = the sine
   kernels again). Success = a precisely stated limit operator/quadratic form with the
   uniform vector √G cyclic for it, and the statement of WHAT of the finite pencil
   data survives the limit.
3. **Consistency checks (must pass):** ∫G = 1 exact; the second moment identity
   Σ g_j² x-weights ↔ ∫ G·(known) — derive at least one nontrivial moment identity of
   G from the operator formulation and verify against the Fredholm closed form
   numerically (K⁺/K⁻ Nyström code exists: `m1_horizon_fredholm_profile.py` pattern).

## Honest scope and dangers

- This is a CONSTRUCTION task, not a certificate task — the deliverable is a
  theorem-statement + proof at write-up grade, with numerics only as consistency checks.
- Do not claim operator-theoretic consequences for the production/chi8 side; the model
  lattice z_n = (n−½)π only. Production transfer stays in the κ̂ lane (separate task).
- Do not pre-assign to IB ([[collaboration-credit-principle]]); but note this answers
  the Gate A question HE posed — flag in any send.

## Files to build on

`to_Ilya_THEOREM_M1_HORIZON_2026-07-22/evidence/` (both WRITEUPs + the Fredholm profile
script); `Q2_OPERATOR_BRIDGE_audit_2026-07-19/` (Gate A verdicts: deficiency (0,0),
Carleman, the OPEN wording); `to_Ilya_THEOREM_M1_2026-07-21` (bordered odd-Lambert).
Ledger: EVIDENCE_CHAIN §9, 2026-07-22 M1-HORIZON entries.
