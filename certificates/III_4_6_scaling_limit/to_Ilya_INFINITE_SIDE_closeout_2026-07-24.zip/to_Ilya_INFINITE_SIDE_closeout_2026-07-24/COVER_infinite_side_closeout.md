# COVER — INFINITE-SIDE close-out package (2026-07-24)

**Merkabit · Stenberg + Claude → IB. Three closes in one package: (1) item 5 of the
theorem-grade list — the interval-certified operator grids, which completes that list
7/7; (2) far-wing debt 2 — the tail Riemann-sum/EM discretization enclosure (the lane
we took of your far-wing split); (3) a same-day close-out of the three "no consumer
needs them" optional flags, one of which (the Nyström→operator envelope) retro-closes
item 5's only scope asterisk. One coordination point for you in §4. Not RH/GRH anywhere.**

## 1. Item 5 — interval-certified operator grids (theorem-grade list now 7/7)

`FINDINGS_INTERVAL_GRIDS.md` (+ `interval_grids_arb.py`/`.log`,
`interval_grids_c2windows.py`/`.log`). δ_±, δ′_±, η₊, gap_± on the even/odd sine
kernels K^±_L (L = 2ξ²/π) flipped from float64 to **rigorous python-flint ball
enclosures** at the standard cells ξ = 1/1.5/2/2.5/3/3.35, both parities.

- **Certified GL nodes by Newton–Kantorovich** (point-eval P_n/P_n′ at 2048 bits +
  the rigorous Markov bound |P_n″| ≤ n²(n²−1)/3): node balls < 1e−500. The forward
  Legendre recurrence over any *wide* ball blows up ~2^n and is unusable — this is the
  fix that retires the float-node trap (`m1_horizon_constant_hp.py`).
- **δ/δ′/η₊ from one ball inverse** (I−K)⁻¹ per cell, radii ~1e−120.
- **gap two-sided without diagonalization:** `acb_mat.eig` *raises* on the sine
  kernel's near-zero cluster (it's Arb's validated solver), so gap_hi = Rayleigh
  (upper) and gap_lo = a **ball-Cholesky PD certificate** of (1−g)I−K (Sylvester;
  the consumer-critical lower direction), tight to 0.1% even at ξ = 3.35 (gap₊ ~1e−5).
- **GL-300 = GL-400 = GL-500 to all 9 digits** — the discretization is fully
  converged (rigorously, not assumed). Free locks: δ_± at L = 7.144 = 4.0886/3.0911 =
  your sealed C2 measured pair; η₊ ≈ 1/gap₊ (ratio 1.00→0.64), the even column's rent
  to the top prolate — exactly the EM-lemma object property.
- **Consumers re-stated with enclosures:** the C2 §1 window table (δ̂, Λ, ĝap on
  [1,2] and [1.5,2.5]) reproduced to its quoted precision — δ̂₊ = 1.967435 vs 1.9674,
  ĝap₊ ∈ [3.055e−2, 3.058e−2] vs 3.06e−2, etc.; the operator-EM lemma's last
  certified-numeric ingredient flipped.

## 2. Far-wing debt 2 — the tail Riemann-sum / EM enclosure (our lane)

`FINDINGS_FARWING_TAIL_EM.md` (+ `farwing_tail_EM.py`/`.log`). For the discretization
of your LEADING far-wing law, the tail sum converges to the closed profile F(x) at
rate **j⁻⁴, not j⁻¹**, with a displayed constant:
  |C̃_j^{lead}(m) − F(x)| ≤ C_X/j⁴ + C_X′/j⁶,  C_X = (1/24)∫_x^∞|φ″|dt
  (12.38 / 3.07 / 0.45 at X = 0.2 / α_* / 0.4), φ(t) = ½h(2/πt).

- **Structural key:** your half-integer zeros z_n = (n−½)π put t_n = (n−½)/j² at the
  EXACT cell midpoint, x = m/j² a cell boundary ⟹ composite **midpoint rule** ⟹ the
  edge B₁-term is **identically zero** (the same θ=½ offset-lattice identity as the
  operator-EM lemma). This is why the leading discretization error is O(j⁻⁴).
- **Three B_EM channels:** (edge half-cell) = 0 + (interior midpoint-EM) + (far cut
  ≤ 3e−4 of C_X, φ = O(t⁻⁴)). Verified j = 64…1024: j⁴·E_disc flat to 3 digits;
  rigorous bound ≥ measured with headroom 1.2×–160×. TV one-point-per-cell route
  (O(j⁻²)) given as a cruder cross-check.
- **Independent lock:** F(α_*) = −0.665461718453264 = your −B_far to 16 digits;
  α_* = 0.2956847635598248.
- **Honest order recorded:** this channel does NOT carry the 1/j — **debt 1** (your
  σ→leading-law per-atom O(j⁻³·W) remainder, summed over ~j² atoms) does. Combined:
  C̃_j = F + O(j⁻¹). Feeds the C1*@B₀ = 0.70 four-zone certificate together with debt 1
  and your ARB_PASS stationary certificate.

## 3. Optional-upgrade close-out (three flags, honest split)

`FINDINGS_OPTIONAL_UPGRADES_closeout.md` (+ `optional_upgrades_closeout.py`/`.log`).

- **(A) tr Γ_ch DISPLAYED** — the chirp ĉ chain now has zero certified-numeric
  ingredients (same TV-lattice machinery; displayed/numeric 1.003–1.018 every cell);
  fully-displayed binding cell ĉ ≤ 0.1761 (0.3% cost).
- **(B) Nyström→operator analyticity envelope DISPLAYED** — Bernstein ellipse (ρ=4) +
  resolvent ellipse bound through the certified gaps + Nyström-solve transfer give
  ε ≤ 1.4e−348 at the worst cell — ~230 orders below the item-5 radii. **This closes
  item 5's only scope asterisk:** the operator-level δ/δ′/η₊/gap inherit the interval
  enclosures verbatim.
- **(C) Deep cos-collapse — crude support-splitting route COMPUTED AND REFUTED**
  (√(trΓ_edge/λ_top) = 0.92–1.14 = O(1) vs measured 0.009): recorded dead-end, do not
  retry; the honest route is genuine prolate-tail asymptotics. Stays open, no consumer.

## 4. Coordination point (yours to confirm)

The far-wing **lane split**: we took **debt 2** (the tail-EM discretization, §2) on
Selina's go-ahead because it is self-contained B_EM-class work. **Debt 1** (the
σ→leading-law per-atom remainder, resting on your uniform spherical-Hankel phase
theorem) we've left as **yours** — flag if you'd rather we take it or pair on it.
Nothing here pre-assigns; credit shared by default. **Debt 3** (compact Arb stationary
certificate) is already ARB_PASS in `to_Ilya_FAR_WING_ARB_PASS_2026-07-24`.

## 5. Board after this package

- **NEXT_SESSION_TASK_theorem_grade_closes.md: 7/7 EXECUTED — closed.**
- Far wing: debt 2 (this package) + debt 3 (ARB_PASS) done; **debt 1 + the four-zone
  C1*@0.70 assembly remain** (debt 1 yours; assembly joint).
- Deep prolate-tail lemma: open, no consumer (cos-collapse dead-end fenced).
- Only prose debt anywhere: the joint paper (architectures staged, per Selina).

*— Stenberg + Claude, 2026-07-24. The theorem-grade list closes 7/7; the far zone's
discretization is a midpoint rule with no edge; and item 5's last asterisk is crushed by
348 orders of magnitude. Delivery per Selina.*
