# farwing_tail_EM.py -- far-wing debt 2 (presumptively ours): the tail Riemann-sum /
# Euler-Maclaurin enclosure. Turn the tail sum of IB's LEADING far-wing law into the
# closed profile F(x) with a DISPLAYED discretization constant, in B_EM style.
#
# Object (FAR_WING_ASYMPTOTIC_THEOREM_NOTE.md sec.2-3):
#   sigma_{j+1}(n)-sigma_j(n) = (1/(2 j^2)) h(lambda_n) + O_x(j^{-3})   [debt-1 remainder]
#   h(l) = -2 l^2 cos2l + (3/2) l sin2l + (1/2)cos2l - 1/2,   h(l)=O(l^4) as l->0
#   lambda_n = 2/(pi t_n),   t_n = (n-1/2)/j^2   (the HALF-INTEGER lattice z_n=(n-1/2)pi)
#   Ctilde_j(m) = -sum_{n>m}(sigma_{j+1}-sigma_j)  -> F(x) = -int_x^inf (1/2)h(2/(pi t)) dt
#   F(x) = [2L sin2L - L Si(2L) + cos2L - 1]/(2 pi L),  L = 2/(pi x)   (closed form).
#
# DEBT 2 = the discretization error of the LEADING law only:
#   E_disc(j) = | -sum_{n>m} dt*phi(t_n)  -  F(x) |,  phi(t)=(1/2)h(2/(pi t)), dt=1/j^2.
# STRUCTURE: t_{m+1}=(m+1/2)/j^2 is the MIDPOINT of [m/j^2,(m+1)/j^2] and x=m/j^2 is a
# cell boundary -> composite MIDPOINT rule, so the edge B1 term is EXACTLY ZERO (the
# z_n=(n-1/2)pi offset is what makes this a midpoint rule). Hence
#   E_disc <= (dt^2/24) int_x^inf |phi''| + (dt^3/24) TV(phi'')   = O(j^{-4}),
# far below the C_X/j target (that 1/j lives in debt 1's W-term, per the task).
# Channels (B_EM style): (edge half-cell = 0) + (interior midpoint-EM) + (far cut).
# Not RH/GRH.
import time, math
import mpmath as mp
mp.mp.dps = 40

def hf(l):   # float64 h
    return -2*l*l*math.cos(2*l) + 1.5*l*math.sin(2*l) + 0.5*math.cos(2*l) - 0.5
def phif(t): # float64 phi
    return 0.5*hf(2.0/(math.pi*t))

def h(l):
    return -2*l*l*mp.cos(2*l) + mp.mpf(3)/2*l*mp.sin(2*l) + mp.cos(2*l)/2 - mp.mpf(1)/2
def phi(t):
    return h(2/(mp.pi*t))/2
def F(x):
    L = 2/(mp.pi*x)
    return (2*L*mp.sin(2*L) - L*mp.si(2*L) + mp.cos(2*L) - 1)/(2*mp.pi*L)

def ddphi(t):
    return mp.diff(phi, t, 2)

LOG = open(__file__.replace('.py', '_run.log'), 'w')
def log(s):
    print(s, flush=True); LOG.write(s + '\n'); LOG.flush()
log(f"=== far-wing debt 2 (tail Riemann-sum / midpoint-EM) @ {time.strftime('%Y-%m-%d %H:%M:%S')} ===")

# ---- sanity: h=O(l^4), F reproduces IB's baseline at alpha_* ----
Lst = mp.mpf('2.1530354310555348147430601898')
alpha = 2/(mp.pi*Lst)
log(f"\n-- locks --")
log(f"h(l)/l^4 -> 7/3 = {mp.nstr(h(mp.mpf('1e-6'))/mp.mpf('1e-6')**4, 8)}  (7/3={mp.nstr(mp.mpf(7)/3,8)})")
log(f"F(alpha_*) = {mp.nstr(F(alpha), 16)}   (IB -B_far = -0.6654617184532640)")
log(f"alpha_* = {mp.nstr(alpha,16)}   (IB 0.2956847635598248)")

# ---- displayed constant C_X = (1/24) int_x^inf |phi''| dt, + TV(phi'') ----
def CX_and_TV(x, tcut=60):
    absint = mp.quad(lambda t: abs(ddphi(t)), [x, tcut])
    # TV(phi'') on [x,tcut]: integral of |phi'''| (phi'' smooth) -- crude but fine
    tv = mp.quad(lambda t: abs(mp.diff(phi, t, 3)), [x, tcut])
    return absint/24, tv, absint

# ---- numeric verification of the O(j^-4) law + headroom ----
def measure(x, jj, xb=3.0):
    """finite-window midpoint error over [x, xb]; both endpoints on the lattice.
    E_win(j) = sum_{n=m+1}^{M} dt*phi(t_n) - (F(xb)-F(x))   (= int_x^xb phi via F).
    Sum in float64 with math.fsum (exact rounding ~1e-16); F in mpmath dps 40."""
    j = int(jj); xf = float(x)
    m = int(round(xf*j*j)); M = int(round(xb*j*j))
    j2 = float(j*j); dt = 1.0/j2
    terms = [dt*phif((n-0.5)/j2) for n in range(m+1, M+1)]
    s = math.fsum(terms)
    xa = mp.mpf(m)/(j*j); xbb = mp.mpf(M)/(j*j)
    integ = F(xbb) - F(xa)     # int_{xa}^{xbb} phi (closed form)
    return abs(mp.mpf(s) - integ), xa, xbb

log(f"\n-- displayed constants C_X = (1/24) int_x^inf |phi''| dt (far cut at t=60) --")
XS = [mp.mpf('0.2'), alpha, mp.mpf('0.4')]
CXv = {}
for x in XS:
    CX, tv, absint = CX_and_TV(x)
    CXv[str(x)] = (CX, tv)
    # far-cut tail contribution to the constant (t>3, the verification window edge):
    tailc = mp.quad(lambda t: abs(ddphi(t)), [3, 60])/24
    # route-b (cruder TV one-point-per-cell): |sum-int| <= dt*TV(phi), TV(phi)=int|phi'|
    tvphi = mp.quad(lambda t: abs(mp.diff(phi, t, 1)), [x, 60])
    log(f"x={mp.nstr(x,6)}: C_X = {mp.nstr(CX,8)}  (int|phi''|={mp.nstr(absint,6)}); "
        f"TV(phi'')~{mp.nstr(tv,6)}; far-cut(t>3) share of C_X = {mp.nstr(tailc/CX,3)}; "
        f"route-b TV(phi)={mp.nstr(tvphi,6)} (bound TV/j^2)")

log(f"\n-- verification: finite-window midpoint error vs bound, j=64..1024 --")
log(f"{'x':>8} {'j':>6} {'E_win':>14} {'E*j^4':>14} {'C_X':>12} {'bound=C_X/j^4':>14} {'headroom':>9}")
for x in XS:
    CX, tv = CXv[str(x)]
    for j in (64, 128, 256, 512, 1024):
        t0 = time.time()
        E, xa, xbb = measure(x, mp.mpf(j))
        # rigorous displayed bound: (1/24)(int|phi''| + (1/j^2) TV)  /j^4
        bound = (CX + tv/24/(mp.mpf(j)**2))/(mp.mpf(j)**4)
        head = bound/E if E > 0 else mp.inf
        log(f"{mp.nstr(x,5):>8} {j:>6} {mp.nstr(E,6):>14} {mp.nstr(E*j**4,8):>14} "
            f"{mp.nstr(CX,6):>12} {mp.nstr(bound,6):>14} {mp.nstr(head,4):>9}  ({time.time()-t0:.0f}s)")

log("\ndone.")
LOG.close()
