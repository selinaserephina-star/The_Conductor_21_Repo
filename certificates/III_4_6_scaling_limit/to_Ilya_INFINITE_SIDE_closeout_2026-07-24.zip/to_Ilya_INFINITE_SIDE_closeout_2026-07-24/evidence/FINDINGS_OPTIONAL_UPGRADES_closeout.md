# FINDINGS — the three flagged optional upgrades CLOSED OUT: trΓ_ch displayed (chirp chain now ingredient-free), Nyström→operator envelope displayed, cos-collapse crude route refuted-and-recorded

**Merkabit · Stenberg + Claude · 2026-07-24 (post-7/7 close-out of the three
"no consumer needs them" flags). Script + log §4. Not RH/GRH.**

## 0. Executive verdict

1. **(A) tr Γ_ch is now DISPLAYED — the chirp chain's last certified-numeric
   ingredient is gone.** Per cell, with the SAME lattice-to-integral + TV
   machinery as the sealed oscillation lemma (one point per π-cell):
     tr Γ_ch ≤ Σ_i pref²_i[(2/(πc_i))·(Y_i/2 ± sin(2Y_i)/4) + (4/c_i²)(Y_i² + Y_i³/3)]
     (+ the exact l = 0 column 2/(π²(2N−1)) and the E-parity ztail trace
     (Σpref²)·ztail; + for sin: minus sign in the integral).
   Displayed/numeric trace ratio 1.003–1.018 at every cell; the FULLY-DISPLAYED
   ĉ table costs ≤ 0.9% over the sealed values — **binding cell (O, ξ=2):
   ĉ ≤ 0.1761 fully displayed** (was 0.1758 with numeric trΓ). The chain is now
   Prop-1 products → signed second-order lemma → TV lattice step → displayed
   trΓ → assembly: no Bessel evaluation, no certified-numeric scalar anywhere.
2. **(B) The Nyström→operator analyticity envelope is displayed — item 5's
   scope asterisk closes.** Lemma chain: (i) the sine kernels are entire; one
   application of K maps L¹[0,1] into entire functions with Bernstein-ellipse
   bound sup_{E_ρ}|K| ≤ e^{2Lb_eff}, b_eff = (ρ−1/ρ)/4 ([0,1] scaling);
   (ii) the resolvent solution h = (I−K)⁻¹c inherits an ellipse bound
   M_h ≤ e^{2Lb}(1 + 1/gap)-class with the CERTIFIED gap; (iii) GL-n error of
   analytic integrands (Trefethen ATAP Thm 19.3 displayed form)
   ≤ (64/15)M/((1−ρ⁻²)ρ²ⁿ); (iv) the Nyström-solve transfer
   (I−K_n)(h−h_n) = (K−K_n)h bounds ‖h−h_n‖ by ε_q·M_h/gap_n (gap_n certified).
   At ρ = 4, n = 300: **ε ≤ 1.4e−348 at the worst cell (ξ = 3.35)** — ~230
   orders below the certified enclosure radii (~1e−120). The operator-level
   δ/δ′/η₊/gap inherit the item-5 interval enclosures verbatim.
3. **(C) Deep cos-collapse: the crude route is REFUTED, honestly recorded, item
   stays open (no consumer).** The support-splitting bound
   |cos∠(p,q)| ≤ √(trΓ_edge/λ_top) (q's carrier support i ≥ 0.65j, measured)
   computes to 0.92/1.03/1.14 at ξ = 2.5/3.0/3.35 — O(1), blind to the measured
   collapse 0.70 → 0.062 → 0.009. The collapse is oscillatory ORTHOGONALITY of
   the top prolate mode against the error direction, not a support effect; the
   only honest route is genuine prolate-tail asymptotics. ASSESSED-AND-LEFT-OPEN
   — do not retry support splitting (recorded dead-end).

## 1. What changed upstream

- FINDINGS_CHIRP_oscillation_column_norms §1's "optional: displayed trΓ_ch" —
  DONE; its §2 proof-surface note upgrades to "no certified-numeric ingredient".
- FINDINGS_INTERVAL_GRIDS' honest-scope paragraph — the "separate flagged
  upgrade" is now displayed; grade of the grid consumers upgrades from
  "certified at fixed GL order" to "certified, operator-level, with displayed
  transfer envelope".
- The cos-collapse stays exactly where it was, now with the dead-end fenced.

## 4. Manifest

`optional_upgrades_closeout.py` + `optional_upgrades_closeout_run.log`:
(A) per-cell displayed vs numeric traces + the fully-displayed ĉ table;
(B) the envelope table per cell; (C) the crude-route computation and verdict.
Inputs (read-only): the sealed oscillation-lemma NF_B values; the item-5
findings' certified gaps (envelope arithmetic only).

*— Stenberg + Claude, 2026-07-24. Three asterisks: one erased, one crushed by
348 orders of magnitude, one honestly fenced off.*
