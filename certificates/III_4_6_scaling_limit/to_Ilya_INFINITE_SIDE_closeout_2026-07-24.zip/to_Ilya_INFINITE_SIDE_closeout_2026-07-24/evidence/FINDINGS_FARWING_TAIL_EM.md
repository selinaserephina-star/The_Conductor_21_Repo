# FINDINGS — far-wing debt 2: the tail Riemann-sum / Euler–Maclaurin enclosure (discretization step)

**Merkabit · Stenberg + Claude · 2026-07-24 (INFINITE_SIDE far-wing debt 2, executed as
staged in `NEXT_SESSION_TASK_farwing_tail_EM.md`; the presumptively-ours lane of IB's
far-wing split — debt 1 = the Hankel/σ per-atom remainder, naturally IB's). Machine
verification `farwing_tail_EM.py` (+ `_run.log`). Not RH/GRH.**

## 0. Result

For the discretization of IB's LEADING far-wing law
(`FAR_WING_ASYMPTOTIC_THEOREM_NOTE.md` §§2–3), the tail sum converges to the closed
profile at rate **j⁻⁴, not j⁻¹** — with a displayed constant. Writing
φ(t) = ½·h(2/(πt)), h(λ) = −2λ²cos2λ + (3/2)λsin2λ + ½cos2λ − ½ (so h(λ) = O(λ⁴)),
the leading-law tail sum and the profile are

  C̃_j^{lead}(m) = −Σ_{n>m} (1/2j²) h(λ_n),  λ_n = 2/(πt_n), t_n = (n−½)/j²;
  F(x) = −∫_x^∞ φ(t) dt = [2Λsin2Λ − ΛSi(2Λ) + cos2Λ − 1]/(2πΛ),  Λ = 2/(πx), x = m/j².

**THEOREM (discretization enclosure).** For every X > 0 and x = m/j² ≥ X,
  **|C̃_j^{lead}(m) − F(x)| ≤ C_X / j⁴ + C_X′ / j⁶**,
  C_X = (1/24) ∫_x^∞ |φ″(t)| dt,  C_X′ = (1/24) TV_{[x,∞)}(φ″),
both finite and displayed. This is the pure discretization channel; combined with debt
1's per-atom O(j⁻³·W)-remainder (summed over ~j² atoms → O(j⁻¹)) it closes
**C̃_j(m) = F(x) + O_x(j⁻¹)** on the far zone, the 1/j carried entirely by debt 1.

## 1. Why it is a midpoint rule with NO edge term (the structural point)

The half-integer zeros z_n = (n−½)π put the lattice point t_n = (n−½)/j² at the EXACT
midpoint of the cell [(n−1)/j², n/j²], and the sum starts at n = m+1 with x = m/j² an
exact cell boundary. So Σ_{n>m} (1/j²) φ(t_n) is the composite **midpoint rule** for
∫_x^∞ φ, and the boundary Euler–Maclaurin B₁-term is **identically zero** — the same
θ = ½ offset-lattice identity as the operator-EM lemma
(`WRITEUP_OPERATOR_EM_lemma.md` (i), there θ_E = ¼/θ_O = ¾; here pure ½). This is why
the naive "edge half-cell" channel vanishes and the leading discretization error is
O(Δt²) = O(j⁻⁴) rather than O(Δt) = O(j⁻²).

## 2. The three channels (B_EM style)

- **(edge half-cell) = 0.** The midpoint alignment above; no B₁. (Were x not on the
  lattice, a fractional cell would give an O(Δt) edge term; with m, j integers x = m/j²
  is always exact.)
- **(interior midpoint-EM).** Per cell |∫_cell φ − Δt·φ(mid)| ≤ (Δt³/24)·max_cell|φ″|;
  summed with a right/left-sum bound on |φ″|: |Σ − ∫| ≤ (Δt²/24)(∫|φ″| + Δt·TV(φ″)) =
  C_X/j⁴ + C_X′/j⁶. (φ″ rigorous via ∫|φ‴| for the TV term.)
- **(far cut).** φ(t) = O(t⁻⁴) (from h = O(λ⁴)), so both the discrete and continuous
  tails beyond any T are O(T⁻³) and their difference is again midpoint-O(j⁻⁴) with
  constant (1/24)∫_T^∞|φ″|; at T = 3 this is ≤ 3e−4 of C_X (measured), fully absorbed.

## 3. Displayed constants and verification (`farwing_tail_EM_run.log`)

Locks: h(λ)/λ⁴ → 7/3 ✓; α_* = 0.2956847635598248 and F(α_*) = −0.665461718453264 =
IB's −B_far, to all 16 digits ✓ (independent reproduction of the far baseline).

Displayed discretization constants (far cut t = 60 ≈ ∞):

| X | C_X = (1/24)∫_X^∞\|φ″\| | route-b TV(φ) = ∫_X^∞\|φ′\| | measured lim j⁴·E_disc |
|---|---|---|---|
| 0.20 | 12.3795 | 13.8932 | 0.07624 |
| α_* = 0.29568 | 3.06756 | 3.99337 | 2.52460 |
| 0.40 | 0.44787 | 1.98153 | 0.09508 |

Verification (finite-window midpoint error over [x, 3], both ends on the lattice; sum
in float64 `math.fsum`, integral via the closed F; j = 64…1024): **j⁴·E_disc is flat
in j** at each x (0.0762 / 2.525 / 0.0951 across the five orders — the O(j⁻⁴) law
confirmed to 3 digits), and the rigorous bound C_X/j⁴ + C_X′/j⁶ ≥ E_disc with
**headroom 1.2×–160×** (worst 1.2× at α_*, where φ″ barely changes sign so ∫|φ″| ≈
the signed midpoint coefficient; ≥50%+ everywhere else, and ≥3.6× everywhere if the
crude Peano coefficient 1/8 is used instead of the sharp 1/24). The far-cut share at
t = 3 is ≤ 3e−4 of C_X.

**Route (b) (TV fallback), if oscillation bookkeeping is preferred cruder:** the
one-point-per-cell lemma (`FINDINGS_CHIRP_oscillation_column_norms.md`) gives
|Σ − ∫| ≤ Δt·TV(φ) = TV(φ)/j² — O(j⁻²), a decade cruder than route (a) but still
≪ the C_X/j target; TV(φ) displayed above.

## 4. Honest grade and scope

- **Established:** the discretization step is O(j⁻⁴) with a displayed, verified
  constant; the edge term is exactly zero (midpoint identity); route (a) sharp, route
  (b) as a cruder cross-check. The task's C_X/j target is comfortably beaten — and the
  honest order is recorded: **this channel does NOT carry the 1/j; debt 1 does.**
- **Scope:** this bounds the discretization of the LEADING law only. The σ-to-leading
  step (h-law from the exact Bessel row, the O(j⁻³·W) per-atom remainder with
  integrable W) is **debt 1** (IB's lane; his uniform spherical-Hankel phase remainder
  theorem is the ingredient) and is NOT claimed here. Combined: C̃_j = F + O(j⁻¹).
- **Feeds:** the C1*@B₀ = 0.70 four-zone certificate (finite head + Airy zone +
  Debye zone + far-F zone), together with debt 1 and debt 3 (the compact Arb stationary
  certificate, already ARB_PASS in `to_Ilya_FAR_WING_ARB_PASS_2026-07-24`).

## 5. Files

`farwing_tail_EM.py` (+ `farwing_tail_EM_run.log`): locks, displayed constants (both
routes), the O(j⁻⁴) verification table. Inputs (read-only): received
`FAR_WING_received_2026-07-24/FAR_WING_ASYMPTOTIC_THEOREM_NOTE.md` (IB's h-law, F,
α_*, B_far); `WRITEUP_OPERATOR_EM_lemma.md` (the θ-offset midpoint identity);
`FINDINGS_CHIRP_oscillation_column_norms.md` (the TV one-point-per-cell lemma).

*— Stenberg + Claude, 2026-07-24. The half-integer zeros make the tail a midpoint rule;
the edge term vanishes, the interior is one-over-twenty-four times the curvature mass,
and the far wing's discretization is j⁻⁴ — the 1/j the far zone owes is debt 1's, not
this step's.*
