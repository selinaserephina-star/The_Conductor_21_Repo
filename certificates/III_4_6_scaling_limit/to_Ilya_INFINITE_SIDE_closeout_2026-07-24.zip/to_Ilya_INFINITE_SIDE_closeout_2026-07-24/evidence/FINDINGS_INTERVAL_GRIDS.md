# FINDINGS — interval-certified operator grids (δ_±, δ′_±, η₊, gap_±): item 5, the last theorem-grade close

**Merkabit · Stenberg + Claude · 2026-07-24 (INFINITE_SIDE item 5, executed as staged in
`NEXT_SESSION_TASK_interval_grids.md` — the only surviving item of the theorem-grade
list). Machine certificate `interval_grids_arb.py` (+ `_run.log`) and consumer
restatement `interval_grids_c2windows.py` (+ log). Not RH/GRH.**

## 0. What is certified

The four Nyström operator grid quantities on the even/odd sine kernels K^±_L on
L²(0,1), L = 2ξ²/π, are flipped from sealed float64 numerics (WRITEUP_XI_LIMIT_C2
§1; WRITEUP_OPERATOR_EM_lemma §0(iii)) to **rigorous ball enclosures** at the
standard cells ξ = 1, 1.5, 2, 2.5, 3, 3.35:

- **δ_X(L) = (2/π)⟨c_L, (I−K^X_L)^{−1} c_L⟩** — the exact rank-one band derivative,
  c^+ = √w·cos(Lt), c^- = √w·sin(Lt);
- **δ′_X = (4/π)⟨ċ_L, (I−K)^{−1} c_L⟩ + δ²** — exact rank-one calculus (no finite
  differences), ċ^+ = √w·(−t sin Lt), ċ^- = √w·(t cos Lt);
- **η₊ = ⟨1, (I−K^+)^{−1} 1⟩** — the even-EM residual growth scalar (1 → √w);
- **gap_X = 1 − λ_max(K^X_L) = λ_min(I−K^X_L)** — two-sided.

All from one rigorous ball inverse A^{−1} = (I−K)^{−1} per (cell, parity); gap by an
independent PD certificate (below). Everything is `python-flint` 0.8.0 ball
arithmetic, working precision 424 bits, node precision 2048 bits.

## 1. Method (each step rigorous)

**(a) Certified Gauss–Legendre nodes — Newton–Kantorovich, not interval recurrence.**
The known float trap (float64 nodes corrupt determinants past L≈14,
`m1_horizon_constant_hp.py`) is retired by certifying each node. The forward Legendre
recurrence over any *wide* ball blows up ~2^n (dependency/wrapping) and is useless for
n≥300; instead each root is certified from **point-evaluations** of P_n, P_n′ at 2048
bits (stable — no wrapping, only rounding) plus the rigorous global Markov bound
|P_n″| ≤ n²(n²−1)/3 on [−1,1]. NK: with h = |P_n(x)|·M/|P_n′(x)|² < ½ a unique root
sits in a ball of radius 2|P_n(x)|/(|P_n′(x)|(1+√(1−2h))); h ~ 10^{−290} here, so the
certified node balls have radius < 10^{−500} (printed as 0.0). Weights
w = 2/((1−x²)P_n′(x)²) then follow over those astronomically small balls (recurrence
over a 10^{−500} ball is safe).

**(b) δ, δ′, η₊ — one ball inverse.** A = I−K built entrywise in balls; A^{−1} via
`arb_mat.inv` (rigorous enclosure); the three pairings fall out directly. Radii on
δ, δ′, η₊ are ~10^{−120} (the resolvent is well conditioned at these cells).

**(c) gap — the one design decision (two-sided, no full diagonalization).**
`acb_mat.eig` is Arb's *validated* solver (it raises rather than return an
un-isolated enclosure — the near-zero eigenvalue cluster of the sine kernel makes it
raise), so gap is certified two-sided without it:
- **gap_hi** (rigorous upper bound): Rayleigh quotient ⟨v,(I−K)v⟩/⟨v,v⟩ on a float
  hint bottom eigenvector v of A — since gap = λ_min(A), any Rayleigh quotient is an
  upper bound. Matches the float gap to all digits.
- **gap_lo** (rigorous lower bound — the consumer-critical direction, since consumers
  read 2/gap): a **ball-Cholesky positive-definiteness certificate** of (1−g)I − K.
  If every pivot is enclosed strictly > 0 then λ_max(K) < 1−g, i.e. gap > g (Sylvester
  — the interval-Cholesky the ledger already uses at §9). g is pushed to within 0.1%
  of the Rayleigh value; the certificate holds even at ξ = 3.35 (gap₊ ~ 10^{−5}).

An independent looser rigorous cross-check gap ≥ 1/‖A^{−1}‖_∞ (from the same inverse)
brackets 0.71–0.86 × gap and agrees — a second witness the enclosure is honest.

## 2. The certified standard-cell table (GL-400; radii in parentheses)

| ξ | par | δ | δ′ | η₊ | gap ∈ [lo, hi] |
|---|---|---|---|---|---|
| 1.00 | E | +0.909664148 (1e−124) | +0.447773421 (3e−124) | +1.633114620 (2e−124) | [6.11621e−1, 6.12233e−1] |
| 1.00 | O | +0.080698985 (7e−126) | +0.239409820 (2e−125) | — | [9.81631e−1, 9.82613e−1] |
| 1.50 | E | +1.277412063 (2e−124) | +0.473060730 (8e−124) | +3.840962693 (7e−124) | [2.58368e−1, 2.58626e−1] |
| 1.50 | O | +0.343969432 (4e−125) | +0.398254417 (6e−125) | — | [8.36026e−1, 8.36863e−1] |
| 2.00 | E | +1.813709988 (1e−123) | +0.487323078 (5e−123) | +18.336200799 (5e−123) | [5.13436e−2, 5.13950e−2] |
| 2.00 | O | +0.835938128 (1e−124) | +0.468714733 (3e−124) | — | [4.38960e−1, 4.39400e−1] |
| 2.50 | E | +2.517241636 (3e−122) | +0.493869939 (2e−121) | +193.861797120 (1e−121) | [4.27144e−3, 4.27571e−3] |
| 2.50 | O | +1.525691291 (6e−124) | +0.489302146 (3e−123) | — | [9.03521e−2, 9.04425e−2] |
| 3.00 | E | +3.384829160 (1e−119) | +0.496796050 (8e−119) | +4342.632713830 (4e−119) | [1.63708e−4, 1.63872e−4] |
| 3.00 | O | +2.388747836 (2e−122) | +0.495381954 (1e−121) | — | [6.18128e−3, 6.18747e−3] |
| 3.35 | E | +4.088573539 (3e−117) | +0.497866820 (2e−116) | +58364.100792511 (1e−116) | [1.10131e−5, 1.10241e−5] |
| 3.35 | O | +3.091065293 (1e−120) | +0.497155881 (1e−119) | — | [5.49286e−4, 5.49836e−4] |

**Internal locks (landed automatically):**
- δ_± at ξ = 3.35 (L = 7.144) = 4.0886 / 3.0911 — reproduces the sealed C2 lock's
  *measured* pair "δ_± → L/2 ± ½ at L = 7.144 (4.088 / 3.091 vs asymptote 4.072 / 3.072)"
  (WRITEUP_XI_LIMIT_C2 §6) exactly.
- δ′_± ≈ ½ throughout (0.448 → 0.498), consistent with δ_± → L/2 ± ½.
- **η₊ ≈ 1/gap₊** confirmed as an object property (η₊ / (1/gap₊) = 1.00, 0.99, 0.94,
  0.83, 0.71, 0.64 across the cells) — the even bottom column leaning on the top
  prolate mode, exactly the e^{1.9L} growth the EM lemma §4 flags for deep consumers.

## 3. GL-order stability (the discretization evidence)

Every δ, δ′, η₊ value above is **identical to all 9 displayed digits at GL-300,
GL-400 and GL-500**, and the gap enclosures coincide to the printed digits. The
quadrature is fully converged at these cells (all L ≤ 7.14, inside the float-safe
zone; the certificate makes the convergence rigorous rather than assumed). Radii grow
mildly with GL order (more arithmetic) but stay ≤ 10^{−116} throughout.

## 4. Consumer restatement (quoted constants, now with enclosures)

**(a) C2 rate-constant write-up §1 window table** (its ingredients are defined as grid
extrema — "grid over W with 0.12 margin, step 0.02"): δ̂_X = max_grid δ_X,
Λ_X = max_grid|δ′_X|, ĝap_X = min_grid gap_X. Re-certified (`interval_grids_c2windows.py`):

| window | δ̂₊ | δ̂₋ | Λ₊ | Λ₋ | ĝap₊ ∈ | ĝap₋ ∈ |
|---|---|---|---|---|---|---|
| [1.0, 2.0] | 1.967435 (r 2e−123) | 0.984730 | 0.489411 | 0.476297 | [3.05467e−2, 3.05773e−2] | [3.32041e−1, 3.32373e−1] |
| [1.5, 2.5] | 2.710601 (r 8e−122) | 1.717515 | 0.494794 | 0.491427 | [2.08661e−3, 2.08869e−3] | [5.22052e−2, 5.22574e−2] |
| (sealed ref) | 1.9674 / 2.7106 | 0.9847 / 1.7175 | 0.4894 / 0.4948 | 0.4763 / 0.4914 | 3.06e−2 / 2.09e−3 | 3.32e−1 / 5.23e−2 |

Every sealed float value is reproduced to its quoted precision, now with an enclosure.
All extrema sit at the deep window endpoint (ξ = 2.12, resp. 2.62), confirming the
grid's monotonicity; these are grid extrema exactly as the C2 write-up defines them.

**(b) Operator-EM lemma §0(iii)/§4** — δ_X, δ′_X, η₊ on the same cells are now
interval-certified; this flips the lemma's last non-classical ingredient
(§4: "Grid quantities δ, δ′, η₊ are certified-numeric … their interval-certification
is the staged grids task"). B_EM's closed δ-form now evaluates on a certified grid.

**(c) Part II §§4–5 / chirp-horizon assemblies** quoting gap_± and δ_± inherit the
enclosures directly.

## 5. Honest scope (stated, not silently claimed)

This certificate flips the **finite Nyström objects at fixed GL order** from float64
to interval-certified, with the GL-300/400/500 agreement as the discretization
evidence. The **Nyström-to-operator analyticity envelope** — the fully displayed
quadrature-truncation error bounding |δ_X^{Nyström,n} − δ_X^{operator}| — is a
SEPARATE upgrade and is NOT claimed here. It is flagged as the remaining step to a
fully operator-level statement; the 9-digit GL-order invariance is strong evidence the
envelope is small but is not a substitute for the displayed bound.

**[UPDATE 2026-07-24, same-day: this asterisk is now CLOSED — the envelope is
displayed in `FINDINGS_OPTIONAL_UPGRADES_closeout.md` (B), riding in this same
package: Bernstein-ellipse (ρ=4) + resolvent ellipse bound through the certified
gaps + Nyström-solve transfer give transfer error ε ≤ 1.4e−348 at the worst cell
(ξ=3.35) — ~230 orders below the enclosure radii above. The operator-level δ/δ′/η₊/gap
inherit the interval enclosures verbatim. This §5 is retained as written for the
record; read it together with that closeout.]**

## 6. Files

`interval_grids_arb.py` (+ `interval_grids_arb_run.log`): certified nodes, the
standard-cell table, GL-300/400/500 stability. `interval_grids_c2windows.py`
(+ `interval_grids_c2windows_run.log`): the C2 window restatement. Inputs (read-only): sealed `WRITEUP_XI_LIMIT_C2_rate_constants.md`,
`WRITEUP_OPERATOR_EM_lemma.md`, `xi_limit_C2_assembly.py` (the float engine this
certifies), `m1_horizon_constant_hp.py` (the float-trap note).

*— Stenberg + Claude, 2026-07-24. The band derivative, its own derivative, the constant
column's rent to the top prolate, and the spectral gap — the four grid quantities every
displayed constant leans on, now each an honest ball at fixed quadrature order, with the
operator-limit envelope named as the one flagged step still owed.*
