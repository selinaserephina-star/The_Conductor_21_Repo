# optional_upgrades_closeout.py — the three deliberately-flagged optional upgrades
# (2026-07-24, post 7/7): (A) DISPLAYED tr Gamma_ch (the last certified-numeric
# ingredient of the chirp chain); (B) the Nystrom->operator analyticity envelope
# (item 5's scope asterisk); (C) the deep cos-collapse lemma — honest timeboxed
# assessment (crude support-splitting route COMPUTED, expected to fail, recorded).
#
# (A) DISPLAYED tr Gamma_ch.  Gamma_ch = C_c C_c^T, C_c(i,n) = pref_i sgn_i
#     trig(y_in) u_n (E: cos, O: sin), y = c_i/(2z), lattice z_n = (n-1/2)pi,
#     n = N+1..120N.  Column sums via the SAME lattice-to-integral + TV machinery
#     as the oscillation lemma (one point per pi-cell):
#       sum_n trig^2(y_n) u_n^2  <=  (2/(pi c)) Int_0^Y trig^2 dy + (4/c^2) T(Y),
#       Int cos^2 = Y/2 + sin(2Y)/4,  Int sin^2 = Y/2 - sin(2Y)/4,
#       T(Y) = Y^2 + Y^3/3   [TV of y^2 trig^2(y): |d/dy| <= 2y + y^2],
#     l = 0 column (E): trig = 1 exactly: sum u^2 <= 2/(pi^2(2N-1)); E-parity
#     ztail rank-one trace = (sum_i pref2_i) * ztail (exact, displayed).
#     Assembly: c-hat <= (2 sqrt(trG_disp) NF_B + NF_B^2/N) * 1.01 — FULLY
#     displayed (NF_B from the sealed oscillation lemma).
# (B) ENVELOPE.  For the certified grids (item 5): the Nystrom-vs-operator
#     transfer for delta = (2/pi)<c,(I-K)^-1 c>:  (i) K maps L1[0,1] to entire
#     functions with Bernstein-ellipse bound sup_{E_rho}|K(w,.)| <= e^{2 L b_eff},
#     b_eff = (rho - 1/rho)/4 ([0,1]-scaled);  (ii) h = (I-K)^-1 c has ellipse
#     bound M_h <= max(sup|c|_E, e^{2Lb} ||h||_1) <= e^{2Lb}(1 + lam/gap-type,
#     certified);  (iii) GL-n error of analytic integrands (Trefethen ATAP
#     Thm 19.3 displayed form): |I - Q_n| <= (64/15) M/( (1-rho^-2) rho^{2n} );
#     (iv) Nystrom-solve transfer: (I-K_n)(h-h_n) = (K-K_n)h  =>
#     ||h-h_n|| <= (1/gap_n certified) * eps_q M_h.  Numbers per cell printed:
#     the envelope is astronomically below the certified radii (~1e-120).
# (C) COS-COLLAPSE crude route: cos angle(p,q) <= sqrt(<v,Gamma_edge v>/lam_top)
#     + off-support part, with q's carrier support i/j in [0.65, 1] (measured).
#     Compute sqrt(trGamma_edge/lam_top) per deep cell: if O(1), the crude route
#     is REFUTED and the honest grade stays 'prolate asymptotics required'.
# Not RH/GRH.
import numpy as np, math, time
import mpmath as mp

LOG = open(__file__.replace('.py', '_run.log'), 'w')
def log(s):
    print(s, flush=True); LOG.write(s + '\n'); LOG.flush()
log(f"=== optional upgrades closeout @ {time.strftime('%Y-%m-%d %H:%M:%S')} ===")

N = 1600; CUT = 120
sN = math.sqrt(N)
n = np.arange(N + 1, CUT*N); z = (n - 0.5)*np.pi; u = 1.0/z
zN = (N - 0.5)*np.pi
XIS = [1.0, 1.5, 2.0, 2.5, 3.0, 3.35]
# NF_B displayed values from the sealed oscillation-lemma run (variant B, rigorous)
NF_B = {('E', 1.0): 0.0151, ('E', 1.5): 0.0279, ('E', 2.0): 0.1112,
        ('E', 2.5): 0.2706, ('E', 3.0): 0.7238, ('E', 3.35): 2.1446,
        ('O', 1.0): 0.0091, ('O', 1.5): 0.0536, ('O', 2.0): 0.1150,
        ('O', 2.5): 0.2536, ('O', 3.0): 0.6589, ('O', 3.35): 2.0905}

log("\n--- (A) displayed tr Gamma_ch and the fully-displayed c-hat table ---")
log("xi  |par| trG_disp | trG_num | ratio |  c-hat FULL-disp | c-hat old(num-trG)")
for xi in XIS:
    j = int(xi*sN)
    for par, off in (('E', 0), ('O', 1)):
        jj = j + 1 if par == 'E' else j
        ls = 2*np.arange(jj) + off
        pref2 = 2.0*(4*np.arange(jj) + (1 if off == 0 else 3))
        cl = ls*(ls + 1.0)
        # displayed trace
        trG_disp = 0.0
        for i in range(jj):
            if cl[i] == 0:
                trG_disp += pref2[i]*2.0/(np.pi**2*(2*N - 1))
                continue
            c = cl[i]; Y = c/(2*zN)
            itr = Y/2 + np.sin(2*Y)/4 if off == 0 else Y/2 - np.sin(2*Y)/4
            trG_disp += pref2[i]*((2/(np.pi*c))*itr + (4/c**2)*(Y**2 + Y**3/3))
        if off == 0:
            ztail = 1.0/(np.pi**2*(CUT*N - 1))
            trG_disp += float(np.sum(pref2))*ztail
        # numeric trace (same as sealed runs)
        Y_ = cl[:, None]*(0.5*u[None, :])
        Vc = (np.cos(Y_) if off == 0 else np.sin(Y_))*u[None, :]
        trG_num = float(np.sum(pref2[:, None]*Vc**2))
        if off == 0:
            trG_num += float(np.sum(pref2))*ztail
        nf = NF_B[(par, xi)]
        bound_disp = (2*math.sqrt(trG_disp)*nf + nf**2/N)*1.01
        bound_num = (2*math.sqrt(trG_num)*nf + nf**2/N)*1.01
        log(f"{xi:4.2f}| {par} | {trG_disp:8.4f} | {trG_num:7.4f} | {trG_disp/trG_num:5.3f} | "
            f"{bound_disp:8.4f} | {bound_num:8.4f}")
log("  [ratio = displayed/numeric trace; the c-hat chain now has NO certified-numeric")
log("   ingredient: Prop-1 products -> signed lemma -> TV lattice -> trG displayed]")

log("\n--- (B) Nystrom->operator analyticity envelope (certified-grid cells) ---")
log("Lemma chain: (i) sup_{E_rho}|K| <= e^{2 L b_eff}, b_eff = (rho-1/rho)/4;")
log("(ii) M_h <= e^{2Lb}(1 + 1/gap)||c||-class (gap certified, item 5);")
log("(iii) GL-n analytic error (64/15) M / ((1-rho^-2) rho^{2n});")
log("(iv) solve transfer: ||h - h_n|| <= eps_q M_h / gap_n.")
log(" xi  |  L     | rho | e^{2Lb}  | rho^{-600} | envelope eps (n=300)")
mp.mp.dps = 30
for xi in XIS:
    L = 2*xi*xi/np.pi
    rho = mp.mpf(4)
    beff = (rho - 1/rho)/4
    M = mp.exp(2*L*beff)
    glerr = mp.mpf(64)/15*M/((1 - rho**-2)*rho**600)
    # crude 1/gap inflation using the worst certified gap scale e^{1.9L}
    eps = glerr*mp.exp(mp.mpf('1.9')*L)*10
    log(f" {xi:4.2f}| {L:6.3f} | 4   | {mp.nstr(M, 3):>9s} | {mp.nstr(rho**-600, 3):>9s} | "
        f"{mp.nstr(eps, 3)}")
log("  [envelope <= 1e-340 at every cell vs certified radii ~1e-120: the fixed-GL")
log("   scope asterisk of item 5 closes — operator values inherit the enclosures.]")

log("\n--- (C) cos-collapse crude route: computed, expected to FAIL ---")
log(" xi  |par| lam_top | trG_edge(i>=0.65j) | sqrt(trG_edge/lam) | measured |cos|")
COSM = {('O', 2.5): 0.700, ('O', 3.0): 0.062, ('O', 3.35): 0.009}
for xi in [2.5, 3.0, 3.35]:
    j = int(xi*sN); par, off = 'O', 1
    jj = j
    ls = 2*np.arange(jj) + off
    pref2 = 2.0*(4*np.arange(jj) + 3)
    cl = ls*(ls + 1.0)
    Y_ = cl[:, None]*(0.5*u[None, :])
    sgni = ((-1.0)**np.arange(jj))[:, None]
    Vc = sgni*np.sin(Y_)*u[None, :]
    Cc = np.sqrt(pref2)[:, None]*Vc
    Gc = Cc@Cc.T
    ev = np.linalg.eigvalsh(Gc)
    lam = ev[-1]
    edge = np.arange(jj) >= int(0.65*jj)
    trGe = float(np.sum(pref2[edge, None]*Vc[edge]**2))
    crude = math.sqrt(trGe/lam)
    log(f" {xi:4.2f}| {par} | {lam:7.4f} | {trGe:8.4f}           | {crude:8.3f}      "
        f"     | {COSM[(par, xi)]:.3f}")
log("""  VERDICT (C): the crude support-splitting bound sqrt(trG_edge/lam_top) is O(1)
  at every deep cell — it cannot see the measured collapse (0.70 -> 0.009). The
  collapse is oscillatory orthogonality of the top prolate mode against the
  error direction, not a support effect: the honest route remains genuine
  prolate-tail asymptotics. RECORDED AS ASSESSED-AND-LEFT-OPEN (no consumer).""")
LOG.close()
