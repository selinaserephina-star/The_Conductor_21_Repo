# WRITE-UP — C2 corollary: quantitative spectral convergence of the layer operator

**Merkabit · Stenberg + Claude · 2026-07-25.** The quantitative face of the Γ+Mosco
convergence already written (`WRITEUP_XI_LIMIT_gamma_convergence.md`): the low
eigenvalues of the finite-N layer Dirichlet form converge to those of an explicit
Sturm–Liouville operator **at rate 1/√N**, the rate inherited from the displayed C2
constants. Pure assembly (min-max over the recovery sequences) + a displayed table.
Machine verification `xi_limit_C2_spectral.py` (+log). Not RH/GRH.

## 0. Why this exists

C2 displays A/B rate constants for the *energy* convergence
`|N²Σ_W a_{j+1}(γ_j−γ_{j+1})² − ∫_W(√G)′²/16ξ²| ≤ C_W^A/√N + C_W^B/N`, and the Γ+Mosco
write-up notes as a *standard consequence* that "resolvents and window ground energies
converge" — but only **qualitatively**. This corollary joins the two: it attaches the
displayed 1/√N rate to the **eigenvalue** convergence. It is the natural payoff of having
bothered to display A and B, and it upgrades Paper A's Mosco theorem from "the spectra
converge" to "the spectra converge at the displayed rate."

## 1. The two operators

Let `Q_N^{lay}[φ] = N² Σ_{j=j₁}^{j₂−1} a_{j+1}^{(N)} (φ_j − φ_{j+1})²` be the layer
Dirichlet form on the window index set `[j₁,j₂] = [⌊ξ₁√N⌋, ⌊ξ₂√N⌋]`, with free (Neumann)
ends and plain ℓ² mass `Σφ_j²`. Because the √N powers cancel in the Rayleigh quotient
(numerator `N²·a_{j+1}·(Δφ)²`, and `a_{j+1} ≈ 1/(16ξ²N)` by S3, against `Σφ_j²`), one has
for any fixed smooth ψ

  `Q_N^{lay}[ψ(ξ_·)] / Σ ψ(ξ_j)²  →  𝔇[ψ]/‖ψ‖²_{L²(W)},   𝔇[ψ] = ∫_W ψ′²/(16ξ²) dξ.`

The limit form 𝔇 is associated with the explicit self-adjoint Sturm–Liouville operator

  **`A = −(1/16)(ξ^{−2} φ′)′`   on L²(W), Neumann BC at ξ₁, ξ₂.**

**Note (the G-drop).** The det-ratio profile `G(ξ)` does **not** appear in 𝔇 or in A — it
governs the ground *vector* √G, not the *form*. So the limit spectrum is G-independent:
the model-lattice layer operator's low spectrum is governed by a plain weighted Laplacian.

## 2. Statement

**COROLLARY (quantitative spectral convergence).** Let `λ_k^N` be the (k+1)-st eigenvalue
of `(Q_N^{lay}, ℓ²)` on the window and `λ_k = λ_k(A)`. Then for each fixed k,

  `|λ_k^N − λ_k| ≤ c_k/√N + O(1/N),   N ≥ N₁(W),`

with `c_k` displayed below. The mechanism is min-max: the upper bound on `λ_k^N` uses the
recovery sequence of the k-th limit eigenfunction (Γ-limsup) carrying the C2 energy rate;
the lower bound uses Mosco liminf.

**The 1/√N constant decomposes into three elementary pieces (`xi_limit_C2_spectral_analytic`).**
[CORRECTION 2026-07-25: an earlier draft attributed the whole rate to the S3 coefficient error
and stated it is "not a discretization error" — that was WRONG. Replacing the measured coupling
`a_{j+1}` by the *exact* limit coefficient `1/(16ξ²N)` does NOT collapse the rate to O(1/N): the
exact-coefficient operator still converges at 1/√N. So most of the rate is a finite-window
discretization effect.] The relative rate `c_k/λ_k` (mode-independent) is the sum of:
- **(i) grid / finite-window** — the free-end (Neumann O(h)) + the O(1/√N) mismatch between the
  discrete window `[ξ_{j₁},ξ_{j₂}]` and `[ξ₁,ξ₂]` (Hadamard domain-derivative), for the *explicit
  G-free* operator A. Measured baseline **≈ 1.37/√N** (exact coeff, ξ at nodes). Classical, analytic.
- **(ii) coupling placement** — `a_{j+1}` lives at the edge ξ_{j+½}; a half-step Taylor term.
  Lifts (i) to **≈ 2.00/√N** (exact coeff at edges). Elementary.
- **(iii) S3 coefficient error** — `|16ξ²N a_{j+1} − 1| ≤ 5/(2ξ√N) + K_a/N` (leading 5/2 PROVEN,
  C2 §4). Lifts to the measured **≈ 2.97/√N**.

So the leading rate is analytically available — but as **(i)+(ii)+(iii)**, not S3 alone; only (iii)
was already in hand. Deriving (i)+(ii) as displayed constants would lift this corollary from
[D+disp] to [D] (analytical); the measured 2.97 is then the validation. Each piece is O(1/√N) and
mode-independent, which is why `c_k ≈ 3λ_k`.

**Sharper empirical form.** `c_k ≈ 3 λ_k` across the tested band, i.e. the *relative* error
is nearly mode-independent:

  `|λ_k^N − λ_k| / λ_k ≈ 𝒞_W / √N,   𝒞_{[1,2]} ≈ 2.98,   𝒞_{[1.5,2.5]} ≈ 2.74,`

the sum of the three §2 pieces (grid ≈1.37 + edge ≈0.63 + S3-coefficient ≈0.97 on [1,2]).
(Rigorous min-max gives the per-mode `c_k`; the uniform relative constant is the observed,
displayed value — to be replaced by the derived (i)+(ii)+(iii) sum in the [D] upgrade.)

## 3. Displayed table (`xi_limit_C2_spectral_run.log`)

Limit eigenvalues (independent fine FD of A, Neumann, converged in M to ~1e-4; λ_0 = 0 is
the constant Neumann mode, recovered to machine precision):

| window | λ_0 | λ_1 | λ_2 | λ_3 | λ_4 |
|---|---|---|---|---|---|
| [1.0, 2.0] | 0 | 0.265248 | 1.085817 | 2.455695 | 4.374059 |
| [1.5, 2.5] | 0 | 0.151321 | 0.613528 | 1.384313 | 2.463498 |

Rate constants `c_k = √N·(λ_k^N − λ_k)`, measured at N = 1600 / 6400 / 25600 (each 4×);
the deviation **halves per 4×N** (ratio 0.50 ⇒ exact 1/√N law) and `c_k` is stable:

| window | c_1 | c_2 | c_3 | c_4 | ratio/4×N (k=1..4) |
|---|---|---|---|---|---|
| [1.0, 2.0] | −0.79 | −3.22 | −7.33 | −13.22 | 0.50 / 0.50 / 0.49 / 0.49 |
| [1.5, 2.5] | −0.41 | −1.67 | −3.80 | −6.85 | 0.50 / 0.50 / 0.49 / 0.48 |

`c_k/λ_k` (relative rate): [1,2] → 2.97, 2.97, 2.99, 3.02; [1.5,2.5] → 2.72, 2.72, 2.74,
2.78 — mode-independent to ~2%. (Sign: `λ_k^N < λ_k`, the finite section under-resolves.)

## 4. Grade and boundaries

- **Grade [D+disp]** — matches its C2 neighbors: the min-max/Mosco *structure* is rigorous
  given the (proven) Γ+Mosco convergence; the constants `c_k` are displayed/measured on the
  same finite-N engine as C2's A/B constants.
- **Scope.** Per-fixed-k convergence (tested k ≤ 4). The uniform *relative* rate is
  empirical over the low band; for k growing with N (wavelength ↓ grid spacing) the discrete
  operator ceases to resolve the mode — no uniform-in-k claim is made. Full norm-resolvent
  convergence stays at the qualitative Mosco grade; only the low eigenvalues carry the rate.
- **ξ→0 excluded** (as in C2): the window is ⊂ (0,∞); the endpoint belongs to the fixed-mode
  scale, and 𝔇 = ∫φ′²/16ξ² is singular there.
- **Does NOT touch the wall.** This is the Op1 (uniform-normalization) operator, self-adjoint
  both sides [M1-HORIZON + this Dirichlet limit]. The open essential-self-adjointness /
  deficiency-(0,0) question is Op2 = H = D+V — a different operator; nothing here advances it.

## 5. Manifest

`xi_limit_C2_spectral.py` + `_run.log` (limit eigs via fine FD in M; layer eigs via the
verified `odd_system`+`lanczos` of `xi_limit_C2_assembly.py`; rate table). Inputs
(read-only): `WRITEUP_XI_LIMIT_C2_rate_constants.md` (S3 coefficient rate),
`WRITEUP_XI_LIMIT_gamma_convergence.md` (Γ+Mosco, the qualitative consequence upgraded here).

*— Stenberg + Claude, 2026-07-25. The displayed constants finally spend themselves on a
spectral statement: the layer operator's low spectrum converges to −(1/16)(ξ⁻²·)′ at rate
1/√N, uniform relative constant ≈3, G nowhere in the limit.*
