# xi_limit_C2_spectral.py -- the C2 spectral-convergence COROLLARY (2026-07-25).
# Validates: the layer Dirichlet form's low eigenvalues converge to the limit
# Sturm-Liouville operator A = -(1/16)(xi^-2 phi')' on the window (Neumann/free ends)
# at rate 1/sqrtN, with mode-dependent constants c_k. This is the quantitative face
# of the Gamma+Mosco convergence already written (WRITEUP_XI_LIMIT_gamma_convergence),
# using the displayed C2 rate. Reuses the verified odd_system + lanczos from
# xi_limit_C2_assembly.py (be[j] = a_{j+1}^{(N)}; S3 there validated 16 xi^2 N be ~ 1).
#
# Discrete layer eigenproblem on window index set [j1,j2]:
#   energy  E[phi] = N^2 sum_{j=j1}^{j2-1} be[j] (phi_j - phi_{j+1})^2     (free ends)
#   mass    M[phi] = sum_{j=j1}^{j2} phi_j^2                               (plain l^2)
# The sqrtN powers cancel in E/M, so lambda_k^N -> lambda_k(A). Limit A computed by an
# independent fine finite-difference of the SAME form on a uniform xi-grid.
# Not RH/GRH.
import numpy as np, math, time
LOG = open(__file__.replace('.py', '_run.log'), 'w')
def log(s):
    print(s, flush=True); LOG.write(s + '\n'); LOG.flush()
log(f"=== C2 spectral corollary @ {time.strftime('%Y-%m-%d %H:%M:%S')} ===")

def odd_system(N):
    n = np.arange(1, N+1); z = (n-0.5)*np.pi; x = z**-2.0
    return x, x**2/np.sum(x**2)

def lanczos(x, u, jtop):
    N = len(x); v = np.sqrt(u)
    V = np.zeros((jtop+2, N)); V[0] = v
    al = np.zeros(jtop+1); be = np.zeros(jtop+1)
    w = x*v; al[0] = v@w; w = w - al[0]*v
    for j in range(1, jtop+2):
        b = math.sqrt(w@w); vn = w/b
        vn -= V[:j].T@(V[:j]@vn); vn -= V[:j].T@(V[:j]@vn)
        vn /= math.sqrt(vn@vn); V[j] = vn
        if j <= jtop:
            be[j-1] = b; w = x*vn - b*V[j-1]
            a = vn@w; al[j] = a; w = w - a*vn
        else:
            break
    return al, be

def layer_eigs(be, j1, j2, N, kmax):
    """Low eigenvalues of the windowed layer Dirichlet form (free ends, l^2 mass)."""
    idx = np.arange(j1, j2+1); m = len(idx)
    w = (N*N) * be[j1:j2]           # couplings on edges (j,j+1), j=j1..j2-1
    d = np.zeros(m)
    d[:-1] += w; d[1:] += w         # free ends: end nodes get one coupling only
    A = np.diag(d) + np.diag(-w, 1) + np.diag(-w, -1)
    ev = np.linalg.eigvalsh(A)
    return ev[:kmax+1]

def limit_eigs(x1, x2, M, kmax):
    """lambda_k of A = -(1/16)(xi^-2 phi')' on [x1,x2], Neumann, via fine FD of the
    same generalized form:  E = (1/16) sum (dphi)^2/xi_mid^2 / h ;  Mass = sum phi^2 h."""
    eta = np.linspace(x1, x2, M); h = eta[1]-eta[0]
    xm = 0.5*(eta[:-1]+eta[1:])                    # edge midpoints
    w = (1.0/16.0)/(xm*xm) / h                     # edge weights (energy)
    d = np.zeros(M); d[:-1] += w; d[1:] += w
    E = np.diag(d) + np.diag(-w, 1) + np.diag(-w, -1)
    Mass = np.diag(np.full(M, h))                  # lumped mass (uniform)
    from scipy.linalg import eigh
    ev = eigh(E, Mass, eigvals_only=True)
    return ev[:kmax+1]

KMAX = 4
NS = [1600, 6400, 25600]
WINS = [(1.0, 2.0), (1.5, 2.5)]

# ---- limit eigenvalues (independent fine FD; convergence in M reported) ----
log("\n-- limit operator A = -(1/16)(xi^-2 phi')' eigenvalues (Neumann), FD in M --")
LIM = {}
for (x1, x2) in WINS:
    prev = None
    for M in (2000, 4000, 8000):
        lam = limit_eigs(x1, x2, M, KMAX)
        tag = "" if prev is None else "  (dM: " + " ".join(f"{a-b:+.2e}" for a,b in zip(lam,prev)) + ")"
        log(f"  [{x1},{x2}] M={M}: " + " ".join(f"{v:.7f}" for v in lam) + tag)
        prev = lam
    LIM[(x1,x2)] = lam     # richest grid
log("  (FD converges O(1/M^2); M=8000 values used as lambda_k^inf reference)")

# ---- finite-N layer eigenvalues ----
LAY = {w: {} for w in WINS}
for N in NS:
    t0 = time.time()
    x, u = odd_system(N); sN = math.sqrt(N)
    jtop = int(2.6*sN) + 5
    al, be = lanczos(x, u, jtop)
    # be sanity vs S3 (16 xi^2 N be ~ 1) at window centers
    for (x1, x2) in WINS:
        j1, j2 = int(x1*sN), min(int(x2*sN), len(be)-1)
        lam = layer_eigs(be, j1, j2, N, KMAX)
        LAY[(x1,x2)][N] = lam
        jc = (j1+j2)//2; xic = jc/sN
        log(f"[N={N}] window [{x1},{x2}] (j={j1}..{j2}, {j2-j1+1} nodes; "
            f"16xi^2 N be at center = {16*xic*xic*N*be[jc]:.4f}): "
            + " ".join(f"{v:.7f}" for v in lam))
    log(f"[N={N}] lanczos+eigs {time.time()-t0:.0f}s")

# ---- the rate table: |lambda_k^N - lambda_k^inf| and c_k = sqrtN * dev ----
log("\n=== SPECTRAL CONVERGENCE: |lambda_k^N - lambda_k^inf|, c_k = sqrtN*dev, ratio per 4xN ===")
for (x1, x2) in WINS:
    lim = LIM[(x1,x2)]
    log(f"\nwindow [{x1},{x2}]  (lambda_k^inf = " + ", ".join(f"{v:.6f}" for v in lim) + ")")
    log(f"  {'k':>2} " + "".join(f"|  N={N:<6d}          " for N in NS))
    for k in range(KMAX+1):
        row = f"  {k:>2} "
        devs = []
        for N in NS:
            dev = LAY[(x1,x2)][N][k] - lim[k]; devs.append(dev)
            row += f"| dev={dev:+.2e} c={math.sqrt(N)*dev:7.3f} "
        log(row)
        # 1/sqrtN law: dev should halve per 4x N
        ratios = [devs[i+1]/devs[i] for i in range(len(devs)-1) if devs[i] != 0]
        log(f"       ratio(dev) per 4xN = " + " ".join(f"{r:.3f}" for r in ratios)
            + "   (1/sqrtN law => 0.500);  c_k stable => "
            + ("YES" if ratios and all(0.42<r<0.58 for r in ratios) else "see values"))

log("\ndone.")
LOG.close()
