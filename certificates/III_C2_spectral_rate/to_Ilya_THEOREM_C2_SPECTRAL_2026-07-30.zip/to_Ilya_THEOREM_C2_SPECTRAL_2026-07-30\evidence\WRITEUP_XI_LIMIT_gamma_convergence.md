# WRITE-UP — Γ-convergence of the layer Dirichlet forms: the ξ-limit object as a variational limit

**Merkabit · Stenberg + Claude · 2026-07-23 (the pending write-up of the ξ-limit
campaign — the one derivation-grade result that had no document; assembles
FINDINGS_XI_LIMIT_isometry_and_dirichlet.md (constructions A–D),
WRITEUP_XI_LIMIT_layer_form_gamma.md (Lemmas 1–2, the layer theorem) and
WRITEUP_XI_LIMIT_C2_rate_constants.md (the displayed A/B rate constants). No new
numerics; every constant cited is from a sealed or logged run. Model lattice only.
Not RH/GRH.**

## 0. Statement

Let Q_N(e) = N⟨e, J_N e⟩ be the uniform-normalization quadratic form of the finite
pencil, e₀ its normalized ground vector (alternating: sign(g_j) = (−1)^j — a THEOREM
at finite N, §1), γ_j = |g_j| the envelope, and for a window [ξ₁, ξ₂] ⊂ (0, ∞) let

  Q_N^{lay}[φ] := N² Σ_{j ∈ [ξ₁√N, ξ₂√N]} a_{j+1}^{(N)} (φ_j − φ_{j+1})²

be the layer Dirichlet form acting on mode profiles φ = (φ_j).

**THEOREM (two-scale Γ-structure of the ξ-limit).**
(a) *Exact split:* ⟨e₀, J e₀⟩ = A_N + B_N with A_N = Σ a_{j+1}(γ_j − γ_{j+1})²
    (Dirichlet part), B_N = Σ (b_j − a_j − a_{j+1})γ_j² (potential part) — an
    algebraic identity (machine-checked to 2e−19), and
    N⟨e₀, Je₀⟩ = Σ_{n≤N} x_n = (1/π²)Σ_{n≤N}(n−½)^{−2} → 1/2 EXACTLY.
(b) *Fixed-mode ledger:* the j = O(1) scale carries all the energy:
    A_∞ + B_∞ = 1/2 with A_∞ = 0.023093, B_∞ = 0.476907 (absolutely convergent
    series in the exact Lambert data; identity provable by the measure
    representation, §2).
(c) *Γ-convergence of the layer forms:* on every window [ξ₁, ξ₂] ⊂ (0, ∞), the
    forms Q_N^{lay} Γ-converge (and Mosco-converge) with respect to L²(ξ₁, ξ₂) to
      **𝔇(φ) = ∫_{ξ₁}^{ξ₂} φ′(ξ)² / (16ξ²) dξ**,
    with the two halves proven in §3 from the displayed coefficient law
    |16ξ²N a_{j+1}^{(N)} − 1| ≤ (5/2)/(ξ√N) + K_a/N (C2, Lemma 2′-family; the 5/2
    is sharp — measured 2.52).
(d) *Convergence of the ground state and its energy:* T_N e₀ → √G in L²(0,∞)
    (isometry: ‖T_Ne₀‖ = 1 exactly for every N; pointwise convergence at the Part-II
    certified rate; Riesz–Scheffé), and the layer energy converges with DISPLAYED
    rate: |Q_N^{lay}[γ] − 𝔇(√G)| ≤ 2.12/√N + 245/N on [1,2] (C2 theorem; measured
    0.009/√N). The limit object is the triple (L²(0,∞), 𝔇, √G), with the ξ = 0
    boundary owned by the fixed-mode ledger (b).

Grades: (a) exact; (b) exact series + provable identity (proof displayed §2);
(c) write-up grade — classical Γ-convergence arguments with all model-specific
inputs displayed; (d) proof complete conditional on the Part-II scaling-lemma
constants (displayed grade), unconditional at certified-numeric grade.

## 1. Setup and the alternation input

Model lattice z_n = (n−½)π, x = z⁻². The pencil data (a_j, b_j) are the Jacobi
coefficients of the uniform system; the exact infinite-system values are the Lambert
data b_j = α_{2j+1} + α_{2j+2}, a_j² = α_{2j}α_{2j+1}, α_m = 1/((2m−1)(2m+1)).
Alternation (FINDINGS §A, proof via the exact-layer Theorem-3 chain and P̃_j(0)
signs): sign(g_j) = (−1)^j for all j < N — so e₀ = (alternating wave) × (positive
envelope γ), and the quadratic form of an alternating vector splits EXACTLY as in
(a): the cross terms reassemble into second differences of γ (two-line algebra,
verified to 2e−19 at N = 1600). The envelope map is
(T_N e)(ξ) = N^{1/4}⟨e, w_{⌊ξ√N⌋}⟩.

## 2. The fixed-mode identity (b)

N⟨e₀, Je₀⟩ = Σ_{n≤N}x_n is exact (the J-form telescopes against the flat weight),
and Σ_{n=1}^∞ x_n = (1/π²)·Σ(n−½)^{−2} = (1/π²)(π²/2) = 1/2. On the other side,
A_∞ + B_∞ evaluated in the Lambert data converges absolutely (terms O(j⁻³); JMAX =
2×10⁶ gives 0.023093 + 0.476907 = 0.500000). The identity A_∞ + B_∞ = 1/2 is the
m̃₀-algebra of the measure representation (e₀ ↔ √(M2/N)·(1/x), so ⟨e₀, Je₀⟩ =
(M2/N)∫ x·x⁻² dν = (M2/N)·m̃₋₁, and the Step-5 moment law evaluates it to Σx_n —
the same exact sum). The band-collapse property b_j − a_j − a_{j+1} =
−16/((4j+1)²(4j+5)²) + … (exact expansion of the Lambert data) is what expels the
potential part from the layer scale: on j ~ ξ√N it is O(N⁻²·ξ⁻⁴·)-summable and
contributes 0 to any window limit — the layer sees ONLY the Dirichlet part.

## 3. Γ-convergence of the layer forms (c)

Fix [ξ₁, ξ₂] ⊂ (0, ∞). Embed mode profiles into L²(ξ₁, ξ₂) by piecewise-linear
interpolation on the grid ξ_j = j/√N (mesh 1/√N). Coefficient input (displayed, C2):
  (\*)  a_{j+1}^{(N)} = (1 + ε_j)/(16ξ_j²N),  |ε_j| ≤ (5/2)/(ξ_j√N) + K_a/N,
so on the window, uniformly, (1 − ε̄_N) ≤ 16ξ²N a ≤ (1 + ε̄_N) with
ε̄_N = (5/2)/(ξ₁√N) + K_a/N → 0.

*(Γ-limsup: recovery sequences.)* For φ ∈ C²[ξ₁, ξ₂] take the sampling recovery
φ_j := φ(ξ_j). Then N(φ_j − φ_{j+1})² = φ′(ξ_j)²·(1 + O(‖φ″‖/‖φ′‖·N^{−1/2}))
per cell, and by (\*),
  Q_N^{lay}[φ] = Σ_j (1/√N)·φ′(ξ_j)²/(16ξ_j²)·(1 + ε_j + O(N^{−1/2}))
              → ∫ φ′²/(16ξ²) dξ = 𝔇(φ),
a midpoint Riemann sum with error ≤ [(5/2)/(ξ₁) + C_φ]·𝔇-scale/√N — every constant
displayed. Density of C² in the form domain (H¹ with the bounded weight) extends
the recovery to all φ with 𝔇(φ) < ∞ by diagonalization. ∎

*(Γ-liminf: lower bound.)* Let φ^{(N)} → φ in L²(ξ₁, ξ₂) (interpolants) with
liminf Q_N^{lay}[φ^{(N)}] < ∞. By (\*), Q_N^{lay}[φ^{(N)}] ≥ (1 − ε̄_N)·
∫ (φ̂^{(N)})′(ξ)²/(16ξ²) dξ where φ̂^{(N)} is the piecewise-linear interpolant
(whose derivative is exactly √N(φ_{j+1} − φ_j) on each cell, and the weight
1/(16ξ²) is continuous, bounded above and below on the window — replacing it by its
per-cell infimum costs a further (1 − C/√N) factor). Bounded energy ⇒ (φ̂^{(N)})
bounded in H¹(ξ₁, ξ₂) ⇒ weak-H¹ convergence along subsequences to φ, and the
functional ψ ↦ ∫ψ′²/(16ξ²) is convex and strongly-L²-lower-semicontinuous ⇒
  liminf Q_N^{lay}[φ^{(N)}] ≥ 𝔇(φ). ∎

Together: Γ-convergence; and since the recovery sequences converge STRONGLY and the
forms are quadratic with uniformly comparable coefficients, the same two halves give
Mosco convergence on the window. Consequences (standard): convergence of resolvents
and of window ground energies of the layer problem — the variational face of the
scaling limit, with the caveat that our boundary data at ξ₁, ξ₂ enter as on any
window statement (we claim window-interior convergence; the ξ → 0 junction belongs
to the fixed-mode scale (b) and is NOT part of the layer claim).

## 4. The ground state (d)

Isometry: ‖T_Ne₀‖² = Σg_j² = 1 exactly for every N; pointwise (T_Ne₀)²(ξ) → G(ξ)
at rate C(ξ)/√N (Part II scaling lemma; C ~ inverse-gap on compacts); equal norms +
pointwise ⇒ L²-convergence (Riesz–Scheffé), with the Gaussian envelope
4ξe^{−4ξ²/π} available for an explicit-rate variant. Energy: the C2 theorem gives
|Q_N^{lay}[γ] − ∫(√G)′²/16ξ² | ≤ 2.12/√N + 245/N on [1,2] (A-part alone covers the
measured deviation; measured rate exactly 1/√N), consistent with (c)'s Γ-limit
evaluated AT the recovery of √G — the ground state converges together with its
energy, which is what Γ-convergence + equicoercivity are for.

## 5. Grades and honest boundaries

- (a), (b): exact algebra + absolutely convergent exact series; the 1/2 identity
  displayed above.
- (c): the two Γ-halves are classical arguments (midpoint Riemann/EM + convexity);
  every model-specific ingredient is the DISPLAYED coefficient law (\*) — write-up
  grade. Not claimed: any uniformity in the window endpoints as ξ₁ → 0 (the weight
  degenerates; the fixed-mode scale owns that boundary), nor any statement at
  ξ > the certified-grid range for the constants' consumers.
- (d): conditional-on-Part-II displayed constants as stated; B_EM inside those
  constants now carries the closed form (WRITEUP_OPERATOR_EM_lemma.md, same day).
- Attribution: Gate-A question posed by IB; construction, proofs, and this
  assembly ours (Stenberg + Claude); shared by default.

## 6. Files

No new runs. Cited: xi_limit_consistency.py/_run.log (alternation, split identity,
window ratios), xi_limit_coeff_profile.py/_run.log (A_∞/B_∞, ρ_a profile),
xi_limit_C2_assembly.py + xi_limit_C2_constants_refresh.py (+logs) (the displayed
A/B constants and N₁ = 402/1192), m1_horizon_fredholm_profile.py (Nyström G),
sealed WRITEUP_M1_HORIZON_scaling_lemma.md (Part II rates).

*— Stenberg + Claude, 2026-07-23. The limit was never a matrix: it is a Dirichlet
form with weight 1/16ξ², a ground state √G, and a ledger at zero that pays 1/2
exactly — and now it is a Γ-limit, not just a fit.*
