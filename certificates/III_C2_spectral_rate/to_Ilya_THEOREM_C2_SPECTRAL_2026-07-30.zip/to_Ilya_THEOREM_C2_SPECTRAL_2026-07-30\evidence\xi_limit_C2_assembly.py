# xi_limit_C2_assembly.py — C2 rate constants (INFINITE_SIDE task 3), 2026-07-22.
# Threads Part II's displayed rate constants through Lemma 2 of
# WRITEUP_XI_LIMIT_layer_form_gamma.md, producing DISPLAYED window constants for:
#   (S1) |q_j^X - (4 xi_j/(pi sqrtN)) delta_X(L_j)| <= K_q,X / N          (X = E/O)
#   (S2) |sqrtN D_j ln gam^2 - (lnG)'(xi_j)|        <= C_2 / sqrtN
#        |N^{3/4}(gam_{j+1}-gam_j) - (sqrtG)'(xi_j)| <= C_3 / sqrtN
#   (S3) |16 xi_j^2 N a_{j+1}^{(N)} - 1|            <= (5/2)/(xi sqrtN) + K_a/N
#   (S4) |N^2 Sum_W a_{j+1}(gam_j-gam_{j+1})^2 - int_W (sqrtG)'^2/(16 xi^2)| <= C_W/sqrtN
# Ingredients: delta_pm, delta_pm' (exact rank-one calculus: delta' = (4/pi)<cdot,Rc>+delta^2),
# gaps, G/(lnG)'/(sqrtG)'/(sqrtG)'' on certified grids (Nystrom GL-240, well inside the
# float-safe L <= 14 zone); Part II edge displacements, T-norms, B_EM (x5, the one
# certified-numeric component, carried at its Part II grade); elementary expansions with
# exact remainder sups. Finite-N verification at N = 1600, 6400 (full-reorth Lanczos)
# + direct q_j spot-check from Bessel column Grams. Sign of the (lnG)' limit is
# ARBITRATED numerically (sealed sec.2/3 prose has one inconsistent bracket).
# Not RH/GRH.
import numpy as np, math, time
from numpy.polynomial.legendre import leggauss

LOG = open(__file__.replace('.py', '_run.log'), 'w')
def log(s):
    print(s, flush=True); LOG.write(s + '\n'); LOG.flush()
log(f"=== C2 assembly @ {time.strftime('%Y-%m-%d %H:%M:%S')} ===")

MGL = 240
_x, _w = leggauss(MGL)
T = 0.5*(_x+1.0); WT = 0.5*_w; SW = np.sqrt(WT)
TU = T[:,None]+T[None,:]; TV = T[:,None]-T[None,:]
def kmats(L):
    Sd = np.where(np.abs(TV)<1e-14, L, np.sin(L*TV)/np.where(np.abs(TV)<1e-14,1.0,TV))
    Ss = np.sin(L*TU)/TU
    A = SW[:,None]*SW[None,:]/np.pi
    return A*(Sd+Ss), A*(Sd-Ss)          # K+, K- symmetrized
def spectral(L):
    """returns dict: lndet_pm, delta_pm, ddelta_pm, gap_pm at this L."""
    out = {}
    Kp, Km = kmats(L)
    for sgn, K in (('+',Kp), ('-',Km)):
        I = np.eye(MGL)
        s, ld = np.linalg.slogdet(I-K); assert s > 0
        ev = np.linalg.eigvalsh(K); gap = 1.0-ev[-1]
        c  = SW*(np.cos(L*T) if sgn=='+' else np.sin(L*T))
        cd = SW*((-T*np.sin(L*T)) if sgn=='+' else (T*np.cos(L*T)))
        y  = np.linalg.solve(I-K, c)
        d  = (2/np.pi)*float(c@y)
        dp = (4/np.pi)*float(cd@y) + d*d
        out[sgn] = dict(lndet=ld, delta=d, ddelta=dp, gap=gap)
    return out

# ---- S0: locks -------------------------------------------------------------
log("\n-- S0 locks (rank-one calculus vs finite differences) --")
for L in (0.637, 1.432, 2.546, 3.979, 7.144):
    h = 1e-5
    a0, ap, am = spectral(L), spectral(L+h), spectral(L-h)
    for sgn in ('+','-'):
        fd_delta  = -(ap[sgn]['lndet']-am[sgn]['lndet'])/(2*h)
        fd_ddelta = (ap[sgn]['delta']-am[sgn]['delta'])/(2*h)
        log(f"L={L:6.3f} K{sgn}: delta={a0[sgn]['delta']:+.6f} vs -d lndet/dL={fd_delta:+.6f} "
            f"(dev {abs(a0[sgn]['delta']-fd_delta):.1e}); delta'={a0[sgn]['ddelta']:+.6f} vs FD "
            f"{fd_ddelta:+.6f} (dev {abs(a0[sgn]['ddelta']-fd_ddelta):.1e}); gap={a0[sgn]['gap']:.3e}")
log(f"asymptotic check delta_pm -> L/2 pm 1/2 at L=7.144: "
    f"{spectral(7.144)['+']['delta']:.4f} / {spectral(7.144)['-']['delta']:.4f} vs 4.072 / 3.072")

def logG(xi):
    s = spectral(2.0*xi*xi/np.pi)
    return math.log(2.0*xi) + 2.0*(s['+']['lndet'] - s['-']['lndet'])
def lnGp(xi):    # (lnG)'(xi) = 1/xi + (8 xi/pi)(delta_- - delta_+)
    s = spectral(2.0*xi*xi/np.pi)
    return 1.0/xi + (8.0*xi/np.pi)*(s['-']['delta'] - s['+']['delta'])
def sqrtG(xi):  return math.exp(0.5*logG(xi))
def sqrtGp(xi): return 0.5*sqrtG(xi)*lnGp(xi)
def lnGpp(xi):
    s = spectral(2.0*xi*xi/np.pi)
    return (-1.0/xi**2 + (8.0/np.pi)*(s['-']['delta']-s['+']['delta'])
            + (32.0*xi*xi/np.pi**2)*(s['-']['ddelta']-s['+']['ddelta']))
def sqrtGpp(xi): return 0.5*sqrtGp(xi)*lnGp(xi) + 0.5*sqrtG(xi)*lnGpp(xi)

log("\n-- ODE lock: (lnG)' analytic vs FD of logG --")
for xi in (1.0, 1.5, 2.0, 2.5):
    h = 1e-4; fd = (logG(xi+h)-logG(xi-h))/(2*h)
    log(f"xi={xi}: (lnG)'={lnGp(xi):+.6f} vs FD {fd:+.6f} (dev {abs(lnGp(xi)-fd):.1e}); "
        f"(sqrtG)'={sqrtGp(xi):+.5f}  G={math.exp(logG(xi)):.5f}")

# ---- S1/S2: displayed window constants ------------------------------------
# Part II inputs (sealed WRITEUP_M1_HORIZON_scaling_lemma sec.5):
#  edge displacements (in s = pi L/2 units): E(j+1): 3xi/(2sqrtN)+1/(2N);
#  O(j): xi/(2sqrtN); O(j+1): 5xi/(2sqrtN)+3/(2N).
#  T-norms: T_E(k), T_O(k) with phi_pm; B_EM per parity (x5 margin), grid xi=1/1.5/2,
#  beyond 2 extrapolated prop. xi^2 (flagged EXTRAPOLATED, Part II convention).
def phip(y): return math.cosh(y) + (y/3.0)*math.sinh(y)
def phim(y): return math.sinh(y)/y + math.cosh(y)/3.0 if y > 0 else 4.0/3.0
def T_E(k, N):
    Yh = (2*k+1)*(2*k+2)/((2*N+1)*np.pi)
    return (6*phip(Yh)*k**2*(k+1)**2/(math.sqrt(5)*np.pi**4*(N-0.5)**3)
            + (2/3)*phip(Yh)**2*(k+1)**6/(5*np.pi**6*(N-0.5)**5))
def T_O(k, N):
    Yh = (2*k+1)*(2*k+2)/((2*N+1)*np.pi)
    return (8*phim(Yh)*(k+1)**6/(math.sqrt(7)*np.pi**5*(N-0.5)**4)
            + (4/21)*phim(Yh)**2*(k+1)**8/(np.pi**8*(N-0.5)**7))
def b_EM(xi, parity):   # x5-margin per-parity EM residual bounds (Part II sec.5)
    grid = {1.0: (0.03, 0.02), 1.5: (0.24, 0.061), 2.0: (1.25, 0.03)}
    if xi <= 2.0:
        ks = min(k for k in grid if k >= xi - 1e-9) if xi <= 2.0 else 2.0
        v = grid[ks]
    else:
        v = (grid[2.0][0]*(xi/2.0)**2, grid[2.0][1]*(xi/2.0)**2)   # EXTRAPOLATED
    return 5.0*(v[0] if parity == 'E' else v[1])

def window_constants(x1, x2, N0, Nref):
    """Assemble displayed constants for window [x1,x2] in Part II's A/B convention:
    every bound is  A-part/rate + B-part/(next order),  the A-part carrying the rate
    (O(1-20), resolvent-free) and the B-part absorbing the chirp/EM/resolvent
    inflation. Validity N >= N1 (N0 = Part II T<=half-gap threshold; N1 additionally
    forces qhat <= 1/2). N-dependent leftovers in B-parts displayed at Nref
    (Part II sec.5 table convention)."""
    marg = 0.12
    xis = np.arange(max(x1-marg, 0.3), x2+marg+1e-9, 0.02)
    sp = {xi: spectral(2*xi*xi/np.pi) for xi in xis}
    dhat = {s: max(sp[xi][s]['delta'] for xi in xis) for s in '+-'}
    Lam  = {s: max(abs(sp[xi][s]['ddelta']) for xi in xis) for s in '+-'}
    ghat = {s: min(sp[xi][s]['gap'] for xi in xis) for s in '+-'}
    # S1: K_q per parity (deviation bound K_q/N). Edge offset Omega in L-units x sqrtN.
    Omega = (2/np.pi)*(2.5*x2 + 1.5/math.sqrt(N0)) + (4*x2 + 3/math.sqrt(N0))/np.pi
    Kq = {}
    kmax = int(x2*math.sqrt(Nref)) + 2
    for s, par in (('+','E'), ('-','O')):
        Kq[par] = ((3/np.pi)*dhat[s]
                   + (4*x2/np.pi)*Lam[s]*Omega
                   + 0.5*(4*x2*dhat[s]/np.pi)**2
                   + 2*Nref*(T_E(kmax,Nref) if par=='E' else T_O(kmax,Nref))*(2/ghat[s])
                   + 2*b_EM(x2, par))
    # validity: main q-term <= 1/4 and K_q/N <= 1/4  =>  qhat <= 1/2
    N1 = max(N0, int((16*x2*max(dhat.values())/np.pi)**2)+1, int(4*max(Kq.values()))+1)
    qhat = (4*x2/np.pi)*max(dhat.values())/math.sqrt(N1) + max(Kq.values())/N1
    # S2 (A/B): shift terms S_X = (4/pi) dhat + (16 x2^2/pi^2) Lam  (1/sqrtN-level)
    S_X = {par: (4/np.pi)*dhat[s] + (16*x2*x2/np.pi**2)*Lam[s] for s,par in (('+','E'),('-','O'))}
    C2A = (5/4)/x1**2 + 2*S_X['E'] + S_X['O']
    C2B = 2*Kq['E'] + 2*Kq['O'] + 2*(4*x2*max(dhat.values())/np.pi)**2/(1-qhat)
    C2  = C2A + C2B/math.sqrt(Nref)
    # C_3 (A/B): Part II scaling constant at x2 (A_PII rate part, B_PII inflation part)
    Lh = 2*x2*x2/np.pi + 0.05
    sph = spectral(Lh)
    A_PII = (6*x2/np.pi)*(sph['+']['delta']+sph['-']['delta']) + 3/(4*x2)
    B_PII = ((2/np.pi)*(sph['+']['delta']+1.5*sph['-']['delta'])
             + Nref*(2*T_E(kmax,Nref)*(2/sph['+']['gap'])
                     + 2*T_O(kmax,Nref)*(2/sph['-']['gap']))
             + b_EM(x2,'E') + b_EM(x2,'O'))
    xg = np.arange(x1, x2+1e-9, 0.01)
    sG  = max(sqrtG(x) for x in xg);  sGp = max(abs(sqrtGp(x)) for x in xg)
    sLp = max(abs(lnGp(x)) for x in xg)
    # envelope relative error: |N^{1/4}gam/sqrtG - 1| <= exp(C_PII/2sqrtN)-1
    #   A-level: A_PII/2; second-order + B_PII fold into B-level at Nref.
    u1 = (A_PII + B_PII/math.sqrt(Nref))/(2*math.sqrt(Nref))
    envB = B_PII/2 + (math.exp(u1)-1-u1)*Nref/max(1.0, math.sqrt(Nref)/1.0)
    # exp-remainder of sqrt(ratio): u <= (sLp + C2/sqrtN)/sqrtN
    M1 = sLp + C2/math.sqrt(Nref)
    C3A = sG*(0.5*C2A + sLp**2/8) + sG*sLp*A_PII/4
    C3B = (sG*(0.5*C2B + (M1**2/8 - sLp**2/8)*math.sqrt(Nref)
               + sLp*envB/2) + (math.exp(u1)-1)*math.sqrt(Nref)*sG*(0.5*sLp + 0.5*C2/math.sqrt(Nref)))
    C3  = C3A + C3B/math.sqrt(Nref)
    # S3 (A/B): elementary remainder sup |16 j^2 a_{j+1}^inf - 1 + 5/(2j)| <= c_a/j^2
    ca = max(abs((16*j*j/((4*j+5)*math.sqrt((4*j+3)*(4*j+7))) - 1 + 5/(2*j)))*j*j
             for j in range(2, 4000))
    K_a = ca/x1**2 + (0.5*S_X['O'] + Kq['O'])/(1-qhat)     # deviation <= 2.5/(xi sqrtN) + K_a/N
    # S4 (A/B):
    fs  = max((sqrtGp(x)**2)/(16*x*x) for x in xg)
    fps = max(abs(2*sqrtGp(x)*sqrtGpp(x)/(16*x*x) - 2*sqrtGp(x)**2/(16*x**3)) for x in xg)
    CWA = (x2-x1)*(fs*2.5/x1 + (1/(16*x1*x1))*2*sGp*C3A) + (x2-x1)*fps + 2*fs
    CWB = (x2-x1)*(fs*K_a*x2 + (1/(16*x1*x1))*(2*sGp*C3B + (C3A+C3B/math.sqrt(Nref))**2)
                   *(1 + (2.5/x1 + K_a/math.sqrt(Nref))/math.sqrt(Nref)))
    CW  = CWA + CWB/math.sqrt(Nref)
    return dict(dhat=dhat, Lam=Lam, ghat=ghat, Kq=Kq, S_X=S_X, C2A=C2A, C2B=C2B, C2=C2,
                C3A=C3A, C3B=C3B, C3=C3, A_PII=A_PII, B_PII=B_PII, ca=ca, K_a=K_a,
                CWA=CWA, CWB=CWB, CW=CW, N1=N1, Nref=Nref)

log("\n-- S1/S2/S3/S4 displayed window constants (A/B convention, B-parts at Nref=6400) --")
WINS = [(1.0, 2.0, 203), (1.5, 2.5, 31000)]
CONST = {}
for x1, x2, N0 in WINS:
    c = window_constants(x1, x2, N0, Nref=6400)
    CONST[(x1,x2)] = c
    log(f"window [{x1},{x2}] (validity N >= N1 = {c['N1']}; Part II N0 = {N0}):")
    log(f"  ingredients: delta_hat +/-: {c['dhat']['+']:.4f}/{c['dhat']['-']:.4f}   "
        f"Lambda +/-: {c['Lam']['+']:.4f}/{c['Lam']['-']:.4f}   gap_hat +/-: "
        f"{c['ghat']['+']:.3e}/{c['ghat']['-']:.3e}")
    log(f"  S1: K_q,E = {c['Kq']['E']:.1f}   K_q,O = {c['Kq']['O']:.1f}   (|q - main| <= K_q/N)")
    log(f"  S2: C_2 = {c['C2A']:.2f} + {c['C2B']:.0f}/sqrtN   (dev <= C_2A/sqrtN + C_2B/N)")
    log(f"  S2b: C_3 = {c['C3A']:.2f} + {c['C3B']:.0f}/sqrtN   (Part II A_PII = {c['A_PII']:.2f}, "
        f"B_PII = {c['B_PII']:.0f})")
    log(f"  S3: c_a = {c['ca']:.3f}, K_a = {c['K_a']:.1f}   (dev <= (5/2)/(xi sqrtN) + K_a/N)")
    log(f"  S4: C_W = {c['CWA']:.3f} + {c['CWB']:.0f}/sqrtN   (dev <= C_WA/sqrtN + C_WB/N)"
        + ("   [B_EM beyond xi=2 EXTRAPOLATED prop. xi^2 - Part II convention]" if x2 > 2 else ""))

# ---- S3: finite-N verification --------------------------------------------
def odd_system(N):
    n = np.arange(1, N+1); z = (n-0.5)*np.pi; x = z**-2.0
    return x, x**2/np.sum(x**2)
def lanczos(x, u, jtop):
    N = len(x); v = np.sqrt(u)
    V = np.zeros((jtop+2, N)); V[0] = v
    al = np.zeros(jtop+1); be = np.zeros(jtop+1)
    w = x*v; al[0] = v@w; w = w - al[0]*v
    for j in range(1, jtop+2):
        b = math.sqrt(w@w)
        vn = w/b
        vn -= V[:j].T@(V[:j]@vn); vn -= V[:j].T@(V[:j]@vn)   # two reorth passes
        vn /= math.sqrt(vn@vn)
        V[j] = vn
        if j <= jtop:
            be[j-1] = b
            w = x*vn - b*V[j-1]
            a = vn@w; al[j] = a; w = w - a*vn
        else:
            break
    return al, be, V

log("\n-- finite-N verification (N = 1600, 6400) --")
for N in (1600, 6400):
    t0 = time.time()
    x, u = odd_system(N)
    sN = math.sqrt(N)
    jtop = int(2.6*sN)+3
    al, be, V = lanczos(x, u, jtop)
    e0 = np.full(N, 1.0/sN)
    g = V[:jtop+2]@e0
    gam = np.abs(g)
    for (x1, x2, N0) in WINS:
        j1, j2 = int(x1*sN), min(int(x2*sN), N-2)
        js = np.arange(j1, j2)
        xij = js/sN
        # analytic references on the j-grid
        ref_lnGp  = np.array([lnGp(xi) for xi in xij])
        ref_sqGp  = np.array([sqrtGp(xi) for xi in xij])
        # measured step-2 quantities
        dlng2 = sN*(np.log(gam[js+1]**2) - np.log(gam[js]**2))
        dev2  = np.max(np.abs(dlng2 - ref_lnGp))
        dgam  = N**0.75*(gam[js+1] - gam[js])
        dev2b = np.max(np.abs(dgam - ref_sqGp))
        # step-3
        rho   = 16*xij**2*N*be[js]      # be[j] = a_{j+1}
        dev3  = np.max(np.abs(rho - 1.0)*xij*sN)
        # step-4
        S = N*N*float(np.sum(be[j1:j2]*(gam[j1:j2]-gam[j1+1:j2+1])**2))
        xg = np.arange(x1, x2+1e-9, 0.005)
        fg = np.array([(sqrtGp(xx)**2)/(16*xx*xx) for xx in xg])
        I  = float(np.trapezoid(fg, xg))
        dev4 = abs(S - I)
        c = CONST[(x1,x2)]
        b2  = c['C2A'] + c['C2B']/sN
        b2b = c['C3A'] + c['C3B']/sN
        b3  = 2.5 + c['K_a']*x2/sN          # dev3 is xi*sqrtN-scaled: bound = 5/2 + K_a*xi/sqrtN
        b4  = c['CWA'] + c['CWB']/sN
        ok2 = b2 >= dev2*sN; ok2b = b2b >= dev2b*sN; ok3 = b3 >= dev3; ok4 = b4 >= dev4*sN
        log(f"[N={N}] window [{x1},{x2}]"
            + ("   (N < N1: bound formally out of validity, checked anyway)" if N < c['N1'] else ""))
        log(f"   S2 : sup|sqrtN Dlng^2 - (lnG)'| = {dev2:.4f} = {dev2*sN:.2f}/sqrtN  "
            f"vs C_2A + C_2B/sqrtN = {b2:.1f}   {'OK' if ok2 else 'FAIL'}  (A-part alone: "
            f"{c['C2A']:.1f}, {'covers' if c['C2A'] >= dev2*sN else 'x'+format(dev2*sN/c['C2A'],'.2f')})")
        log(f"   S2b: sup|N^0.75 Dgam - (sqrtG)'| = {dev2b:.4f} = {dev2b*sN:.2f}/sqrtN  "
            f"vs C_3A + C_3B/sqrtN = {b2b:.1f}   {'OK' if ok2b else 'FAIL'}  (A-part alone: "
            f"{c['C3A']:.1f}, {'covers' if c['C3A'] >= dev2b*sN else 'x'+format(dev2b*sN/c['C3A'],'.2f')})")
        log(f"   S3 : sup|16xi^2 N a - 1|*xi*sqrtN = {dev3:.3f}  vs 5/2 + K_a*xi2/sqrtN = "
            f"{b3:.3f}   {'OK' if ok3 else 'FAIL'}")
        log(f"   S4 : N^2 Sum = {S:.6f}  int = {I:.6f}  |dev| = {dev4:.2e} = "
            f"{dev4*sN:.4f}/sqrtN  vs C_WA + C_WB/sqrtN = {b4:.2f}   {'OK' if ok4 else 'FAIL'}  "
            f"(A-part alone: {c['CWA']:.3f}, "
            f"{'covers' if c['CWA'] >= dev4*sN else 'x'+format(dev4*sN/c['CWA'],'.2f')})")
    # sign arbitration at xi = 1 (once per N)
    j = int(1.0*sN)
    log(f"[N={N}] sign arbitration at xi=1: measured sqrtN*Dlng^2 = "
        f"{sN*(math.log(gam[j+1]**2)-math.log(gam[j]**2)):+.4f}, analytic (lnG)'(1) = {lnGp(1.0):+.4f} "
        f"-> LIMIT IS +(lnG)' (sealed sec.2 bracket display has the sign slip, values unaffected)")
    log(f"[N={N}] ({time.time()-t0:.0f}s)")

# ---- S4: direct q_j spot check ---------------------------------------------
log("\n-- direct q_j spot check (N = 1600; column Grams from Bessel value laws) --")
try:
    from scipy.special import spherical_jn
    N = 1600; sN = math.sqrt(N)
    for MULT in (100, 200):
        Ntail = MULT*N
        n = np.arange(N+1, Ntail+1); z = (n-0.5)*np.pi
        outs = []
        for xi in (1.0, 1.5, 2.0):
            j = int(xi*sN)
            # EVEN: columns i < j+2, weights 2x: G[i,k] = 2 sqrt((4i+1)(4k+1)) S_{2i,2k}
            # ODD:  columns i < j+2, weights 2x^2: 2 sqrt((4i+3)(4k+3)) S_{2i+1,2k+1}
            q = {}
            for par, off in (('E',0), ('O',1)):
                jj = j+2
                B = np.array([spherical_jn(2*i+off, z) for i in range(jj)])
                pref = np.sqrt(4*np.arange(jj)+ (1 if off==0 else 3))
                Gc = 2.0*np.outer(pref,pref)*(B@B.T)
                if off == 0:
                    # analytic leading tail for the EVEN Gram: j_{2i}(z_n) ~ (-1)^{n+1+i}/z_n,
                    # so sum_{n>Ntail} j_{2i} j_{2k} ~ (-1)^{i+k} sum z^-2 (next order 1/z^4).
                    ztail = float(np.sum((np.arange(Ntail+1, 40*Ntail)-0.5)**-2.0))/np.pi**2 \
                            + 1.0/(np.pi**2*(40*Ntail-1))
                    sgnv = (-1.0)**np.arange(jj)
                    Gc = Gc + 2.0*np.outer(pref*sgnv, pref*sgnv)*ztail
                s2, ld2 = np.linalg.slogdet(np.eye(jj)   - Gc)
                s1, ld1 = np.linalg.slogdet(np.eye(jj-1) - Gc[:jj-1,:jj-1])
                q[par] = 1.0 - math.exp(ld2-ld1)    # q_{j+1}^X (top column index j+1)
            sp = spectral(2*xi*xi/np.pi)
            for par, s in (('E','+'), ('O','-')):
                pred = (4*xi/(np.pi*sN))*sp[s]['delta']
                outs.append((xi, par, q[par], pred, abs(q[par]-pred)*N))
        log(f"  tail cutoff {MULT}N:")
        for xi, par, qv, pred, devN in outs:
            log(f"   xi={xi} {par}: q = {qv:.6e}  (4xi/pi sqrtN) delta = {pred:.6e}  "
                f"|dev|*N = {devN:.3f}  vs K_q = {CONST[(1.0,2.0)]['Kq'][par]:.2f}"
                if xi <= 2.0 else "")
except ImportError:
    log("  scipy not available - q spot check skipped (S2-level verification covers it)")
log("\ndone.")
LOG.close()
