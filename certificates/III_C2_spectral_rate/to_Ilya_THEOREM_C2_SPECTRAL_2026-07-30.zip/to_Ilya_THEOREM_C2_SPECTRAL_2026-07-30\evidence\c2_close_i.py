import numpy as np, math
from scipy.linalg import eigh

def odd_system(N):
    n=np.arange(1,N+1); z=(n-0.5)*np.pi; x=z**-2.0
    return x, x**2/np.sum(x**2)
def lanczos(x,u,jtop):
    N=len(x); v=np.sqrt(u); V=np.zeros((jtop+2,N)); V[0]=v
    al=np.zeros(jtop+1); be=np.zeros(jtop+1); w=x*v; al[0]=v@w; w=w-al[0]*v
    for j in range(1,jtop+2):
        b=math.sqrt(w@w); vn=w/b; vn-=V[:j].T@(V[:j]@vn); vn-=V[:j].T@(V[:j]@vn)
        vn/=math.sqrt(vn@vn); V[j]=vn
        if j<=jtop: be[j-1]=b; w=x*vn-b*V[j-1]; a=vn@w; al[j]=a; w=w-a*vn
        else: break
    return al,be
def layer_eigs_w(w,m,kmax):
    d=np.zeros(m); d[:-1]+=w; d[1:]+=w
    return np.linalg.eigvalsh(np.diag(d)+np.diag(-w,1)+np.diag(-w,-1))[:kmax+1]
def limit_eig_vec(x1,x2,M,kmax):
    eta=np.linspace(x1,x2,M); h=eta[1]-eta[0]; xm=0.5*(eta[:-1]+eta[1:])
    w=(1/16.0)/(xm*xm)/h; d=np.zeros(M); d[:-1]+=w; d[1:]+=w
    E=np.diag(d)+np.diag(-w,1)+np.diag(-w,-1); Mass=np.diag(np.full(M,h))
    val,vec=eigh(E,Mass); return eta,val[:kmax+1],vec[:,:kmax+1]

KMAX=4; NS=[1600,6400,25600]
for (x1,x2) in [(1.0,2.0)]:
    eta,lam,vec=limit_eig_vec(x1,x2,2500,KMAX)
    # per-mode displayed pieces
    bmass=[]; rbar=[]
    for k in range(KMAX+1):
        ph=vec[:,k]; nrm=np.trapezoid(ph**2,eta)
        bmass.append((ph[0]**2+ph[-1]**2)/(2*nrm))
        dph=np.gradient(ph,eta); mid=0.5*(eta[:-1]+eta[1:]); dphm=0.5*(dph[:-1]+dph[1:])
        rbar.append(np.trapezoid(dphm**2/mid**3,mid)/np.trapezoid(dphm**2/mid**2,mid))
    # isolated constants (richest N)
    N=6400; x,u=odd_system(N); sN=math.sqrt(N); jtop=int(2.6*sN)+5
    al,be=lanczos(x,u,jtop); j1,j2=int(x1*sN),int(x2*sN); m=j2-j1+1; j=np.arange(j1,j2)
    def C(wfn): ev=layer_eigs_w(wfn,m,KMAX); return [sN*(ev[k]-lam[k])/lam[k] for k in range(1,KMAX+1)]
    Cnode=C(N/(16*(j/sN)**2)); Cedge=C(N/(16*((j+0.5)/sN)**2)); Call=C(N*N*be[j])
    print(f"\n=== window [{x1},{x2}] ===")
    print(f"  {'k':>2} {'(i+ii)edge':>11} {'-bmass pred':>12}  | {'(all)':>8} {'pred:-(bmass+1.5 r)':>20}  | {'(i)node':>8} {'pred:-bmass+r':>13}")
    for k in range(1,KMAX+1):
        bm,rb=bmass[k],rbar[k]
        print(f"  {k:>2} {Cedge[k-1]:>11.3f} {-bm:>12.3f}  | {Call[k-1]:>8.3f} {-(bm+1.5*rb):>20.3f}  | {Cnode[k-1]:>8.3f} {-bm+rb:>13.3f}")
    print(f"  displayed constants: bmass_k={[round(b,3) for b in bmass[1:]]}  r_k={[round(r,3) for r in rbar[1:]]}")
