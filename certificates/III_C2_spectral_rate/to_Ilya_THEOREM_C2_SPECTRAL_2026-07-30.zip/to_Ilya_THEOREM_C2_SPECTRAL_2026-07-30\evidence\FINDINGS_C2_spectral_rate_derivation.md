# FINDINGS — C2 spectral rate: (ii) DERIVED, (iii) = proven-S3 × displayed integral; (i) reduced to a boundary-layer constant

**Merkabit · Stenberg + Claude (Opus) · 2026-07-30. Closing the [D+disp]→[D] gap in
the C2 spectral-convergence corollary (`WRITEUP_XI_LIMIT_spectral_convergence.md` §2).
Script `c2_derive_i_ii.py`. Not RH/GRH — Op1 analysis, no wall contact.**

## Goal

The corollary `|λ_k^N − λ_k| ≤ c_k/√N + O(1/N)` had its 1/√N constant only *measured*
(relative constant 𝒞_{[1,2]} ≈ 2.97), decomposed into three named pieces (i) grid/
finite-window ≈1.37, (ii) coupling placement ≈0.63, (iii) S3 coefficient ≈0.97. The
[D] upgrade = derive (i) and (ii) as displayed constants ((iii) was tied to the proven
S3 5/2). Done below except the exact value of (i).

## 1. The three pieces isolated (reproducible, N = 1600/6400/25600)

Built the layer eigenproblem with three controlled couplings vs the fine-FD limit A:
| variant | coupling w_j | relative constant c_k/λ_k (mean k=1..4) | writeup |
|---|---|---|---|
| (i) node | N/(16 ξ_j²) | **−1.356** | 1.37 |
| (i+ii) edge | N/(16 ξ_{j+½}²) | **−2.008** | 2.00 |
| (all) actual | N²·be_j | **−2.985** | 2.97 |

⇒ **(ii) = −0.652, (iii) = −0.977** (isolated, matching the writeup's 0.63 / 0.97).
The measured 2.97 is now three separately-computed constants.

**Key displayed integral:** r̄ := ⟨(φ_k′)²/ξ³⟩ / ⟨(φ_k′)²/ξ²⟩ over the window,
computed on the limit eigenfunctions = **0.658** (mode-independent to ~0.5%, k=1..4).

## 2. (ii) DERIVED — the half-step, first-order perturbation

Moving the coefficient c(ξ)=1/(16ξ²) from node ξ_j to edge ξ_{j+½} is δc/c = −h/ξ
(h=1/√N, c′=−1/(8ξ³)). First-order eigenvalue perturbation with weight r̄:
> **(ii) = −r̄ = −0.658**  vs isolated **−0.652** — match to <1%. ✓ **DISPLAYED.**

## 3. (iii) = proven S3 × r̄ — and the clean combined form

S3 (PROVEN, C2 §4): 16ξ_j²N·be_j = 1 − 5/(2ξ_j√N) + O(1/N). Relative to the **edge**
coefficient, be_j deviates by ε_edge = h/ξ − 5/(2ξ√N) = **−(3/2)/(ξ√N)**, so
> **(iii) = −(3/2) r̄ = −0.987**  vs isolated **−0.977**. ✓

Even cleaner — the **entire coefficient contribution** (relative to node) is
> **(ii) + (iii) = −(5/2)·r̄ = −1.645**  vs isolated (all − node) **−1.629**. ✓✓

i.e. the whole coupling-and-coefficient part of the C2 spectral rate is the **proven
S3 constant 5/2** times the **displayed window integral r̄** — both factors known.
**This half of the [D] upgrade is CLOSED at displayed-constant grade.**

## 4. (i) DERIVED — boundary mass-lumping, minus the half-step (baseline error fixed)

**Domain-mismatch VANISHES at these N:** for N a perfect square (1600=40², 6400=80²,
25600=160²) and integer endpoints, ξ_{j1}=x1, ξ_{j2}=x2 *exactly* (verified) — the
Hadamard domain-derivative term is **0**. So (i) is the pure grid/boundary FD error.

**The fix:** the boundary mass-lumping is an O(h) error *of the correctly-placed (edge-
coefficient) operator*, so it must be compared to **(i+ii) = −2.008, not (i) = −1.356.**
With the edge coefficients (the correct midpoint rule) the interior is O(h²) and the sole
O(h) term is the mass-lumping:
> **(i+ii) = −bmass, bmass := (φ(x1)² + φ(x2)²)/(2‖φ‖²)** — plain ℓ² over-weights the two
> Neumann-boundary half-cells (proper trapezoid gives them weight h/2, not h).

Validated at the well-converged mode k=3: **(i+ii) = −2.008 vs −bmass = −2.011** ✓
(k=1,2,4 agree to ~2–5%, the residual = first-order-perturbation error since the Neumann
boundary values φ(x)² ≈ 2–2.7 are O(1), + finite N/M). Then, since (ii) = −r̄:
> **(i) = (i+ii) − (ii) = −bmass + r̄** — validated k=3: **−1.358 vs −1.348** ✓.

So (i) is the boundary mass-lumping term offset by the half-step — both displayed.

## 5. Net — the C2 spectral rate is now a fully displayed constant

**All three pieces derived** (window integrals against the limit eigenfunction; the only
proven external input is the S3 constant 5/2):

| piece | displayed form | value [1,2] | isolated |
|---|---|---|---|
| (i+ii) grid = boundary mass-lump | −bmass = −(φ(x1)²+φ(x2)²)/(2‖φ‖²) | −2.01 | −2.008 |
| (ii) half-step | −r̄ = −⟨(φ')²/ξ³⟩/⟨(φ')²/ξ²⟩ | −0.66 | −0.652 |
| (iii) coeff (S3 5/2, edge-rel −3/2) | −(3/2)r̄ | −0.99 | −0.977 |

**Total displayed rate constant:**
> **𝒞 = −[ (φ(x1)²+φ(x2)²)/(2‖φ‖²) + (3/2)·r̄ ]**,  r̄ = ⟨(φ′)²/ξ³⟩/⟨(φ′)²/ξ²⟩,

reproducing the measured 𝒞_{[1,2]} ≈ −2.98 (k=3: −2.982 vs −3.006). **The C2 spectral
corollary rate is upgraded [D+disp] → [D]:** every constant is now an explicit integral
of the limit eigenfunction, no measured input left. Residual to a *sealed* proof: bound
the first-order-perturbation remainders (standard O(h²) corrections) — rigor polish, not
a new constant.

Honest boundary: leading-order displayed constants, validated on perfect-square N at the
converged mode; the remainder bounds are the write-up's proof polish. Op1 only — nothing
here touches Op2 / the wall.

*— Stenberg + Claude (Opus), 2026-07-30. C2 spectral rate fully displayed:
𝒞 = −[bmass + (3/2)r̄], all three pieces (grid mass-lump, half-step, proven-S3 coefficient)
derived as eigenfunction integrals. [D+disp] → [D]. One rigor-polish (remainder bounds)
from sealed. Not RH/GRH.*
