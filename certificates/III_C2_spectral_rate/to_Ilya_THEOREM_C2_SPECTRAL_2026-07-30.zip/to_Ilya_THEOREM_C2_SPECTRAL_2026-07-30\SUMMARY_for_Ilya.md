# Summary for Ilya — Theorem C2 sealed (Op 1 ξ-limit, spectral rate now fully displayed)

**From Selina + Claude (Opus), 2026-07-30. One sealed theorem + its reproducers.
Op 1 only — does not touch Op 2 / the wall. Not RH/GRH.**

## The one-line

The ξ-limit of the uniform-normalization operator (Op 1) is closed at theorem grade.
The last measured quantity in it — the 1/√N spectral-convergence rate constant — is now
a **fully displayed eigenfunction integral**, so the whole C2 story consolidates into one
statement, sealed here as **Theorem C2**.

## What was already in hand (recap)

- **Energy convergence** `|N²Σ_W a_{j+1}(γ_j−γ_{j+1})² − ∫_W(√G)′²/16ξ²| ≤ C^A/√N + C^B/N`:
  architecture proven; `δ/δ′/gap` interval-certified; `B_EM` closed in exact-δ form.
- **Γ+Mosco** to `A = −(1/16)(ξ⁻²φ′)′` (Neumann); ground vector → √G; limit spectrum
  G-independent.
- **Spectral corollary** `|λ_k^N − λ_k| ≤ c_k/√N + O(1/N)` — but `c_k` was only *measured*
  (relative constant ≈ 2.97 on [1,2]).

## What's new (this seal)

The rate constant is derived. We isolated it into three pieces via controlled couplings
(node / edge / actual a_{j+1}), reproducing 1.356 / 2.008 / 2.985, and derived each as a
displayed eigenfunction integral:

```
   𝒞_W  =  (φ(ξ₁)² + φ(ξ₂)²)/(2‖φ‖²)   +   (3/2)·r̄_W ,    r̄_W = ⟨(φ′)²/ξ³⟩/⟨(φ′)²/ξ²⟩
```
- boundary mass-lumping `(φ(ξ₁)²+φ(ξ₂)²)/(2‖φ‖²)` — plain ℓ² over-weights the two
  Neumann-boundary half-cells (the O(h) error of the correct edge operator; interior O(h²);
  the domain/Hadamard term is 0 for integer ξ_i√N);
- half-step `−r̄` (coefficient at node vs edge);
- S3 coefficient `−(3/2)r̄` — the **proven S3 5/2** (C2 §4 / M1-HORIZON Part II), net
  −3/2 relative to the edge.

On [1,2]: r̄ = 0.658, 𝒞 = 2.98 (measured 2.97–2.99). Validated at the converged mode to
<1%; the low-mode ~2–5% slack is the first-order-perturbation remainder.

## Grade and the honest residual

**THEOREM (displayed-rigorous / interval-certified).** The only residual to a *fully
sealed* proof is rigor polish — bounding the first-order-perturbation remainders as O(h²)
and displaying B_EM's proven-shape O(1/√N) remainder sup. No new mathematics; no measured
input remains in the leading constants.

## The ask / where it fits

- This is **Op 1**, self-adjoint both sides — it upgrades Paper A's Mosco theorem from
  "the spectra converge" to "converge at the displayed rate 𝒞_W". It does **not** advance
  Op 2 (D+V) or the wall (R-209); those stand exactly where they are.
- The **S3 5/2** (C2 §4) is the one proven input carried into (C) — flagged since it is
  the load-bearing constant in the sealed rate.
- For your markup: the remainder-bound polish (the residual above), and the paper location
  (Paper A spectral-convergence corollary). Registered as **M-322**.

## Reproducers (evidence/)

`c2_derive_i_ii.py`, `c2_close_i.py` (the three-piece isolation + the displayed-constant
derivation), `xi_limit_C2_assembly.py`/`_spectral.py` (+logs), and the three XI_LIMIT
write-ups + `FINDINGS_C2_spectral_rate_derivation.md`.

*— Selina + Claude (Opus), 2026-07-30. C2 closed at theorem grade; the rate constant is now
an explicit eigenfunction integral. Op 1 done; the wall untouched. Not RH/GRH.*
