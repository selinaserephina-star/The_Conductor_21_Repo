# WRITE-UP — C2 at write-up grade: the ξ-limit layer Dirichlet theorem with displayed rate constants

**Merkabit · Stenberg + Claude · 2026-07-23 (INFINITE_SIDE task 3, executed as staged in
`NEXT_SESSION_TASK_C2_rate_constants.md`).** Pure assembly: Part II's displayed rate
constants (`WRITEUP_M1_HORIZON_scaling_lemma.md` §5) threaded through Lemma 2 of
`WRITEUP_XI_LIMIT_layer_form_gamma.md`, in Part II's A/B constant convention. One new
certified-numeric ingredient (the δ-Lipschitz grid Λ_±, same grade and engine as δ_±
itself). Machine verification `xi_limit_C2_assembly.py` (+log). Not RH/GRH.

## 0. Statement

**THEOREM (layer Dirichlet convergence, displayed constants).** For the model-lattice
ν-system (z_n = (n−½)π, x = z⁻², weights ∝ x², γ_j = |⟨e₀, w_j⟩|-envelope,
a_{j+1} = Jacobi couplings) and every window W = [ξ₁, ξ₂] ⊂ (0, ∞):

  `| N² Σ_{j∈[ξ₁√N, ξ₂√N)} a_{j+1}^{(N)} (γ_j − γ_{j+1})² − ∫_W (√G)′(ξ)²/(16ξ²) dξ |
   ≤ C_W^A/√N + C_W^B/N`   for N ≥ N₁(W),

with G(ξ) = 2ξ·[det(I−K⁺_L)/det(I−K⁻_L)]², L = 2ξ²/π (the proven closed form), and
C_W^{A,B}, N₁ displayed below through four intermediate displayed bounds (S1–S3). The
A-parts carry the 1/√N rate and are free of resolvent inflation; the B-parts absorb
Part II's chirp/EM/resolvent constants (Part II §5 convention; B-parts' N-dependent
leftovers quoted at N_ref = 6400).

| window | C_W^A | C_W^B | N₁ | measured √N·dev (N=1600 / 6400) |
|---|---|---|---|---|
| [1.0, 2.0] | 2.12 | 245 | 3 351 | 0.0092 / 0.0089 |
| [1.5, 2.5] | 1.14 | 1.10e7 | 611 241 | 0.0121 / 0.0121 |

(Original same-day values — B-parts and N₁ SUPERSEDED by the §0b refresh below; A-parts unchanged.)

## 0b. CONSTANTS REFRESH (2026-07-23, pre-seal item 1 — `xi_limit_C2_constants_refresh.py` + log)

The B-parts above consumed Part II's ×5-margin B_EM table and the T-norm chirp route;
both were superseded the same day by `FINDINGS_BEM_closed_form.md` (B_EM in exact
δ-form, 4-decimal match at ξ ≤ 2, ≤8% truncation-limited agreement at 2 < ξ ≤ 2.65,
carried with a ×1.10 allowance there; NO ∝ξ² extrapolation needed) and
`FINDINGS_CHIRP_true_kernel_verdict.md` (honest chirp bound N·|D_chirp^X| ≤ ĉ_X/gap_X,
ĉ_E = 0.04, ĉ_O = 0.16, measured-range grade ξ ≤ 3/3.35). Refreshed constants
(A-parts UNCHANGED — fully displayed, rate-carrying; B-parts now certified-numeric
envelope grade throughout, which B_EM already was):

| window | K_q,E | K_q,O | C_2^B | C_3^B | C_W^B | N₁ |
|---|---|---|---|---|---|---|
| [1.0, 2.0] | 28.6 (was 838) | 12.4 (was 54) | 156 (12×) | 109 (13×) | 42 (6×) | **402** (was 3 351) |
| [1.5, 2.5] | 124.5 (was 152 810) | 36.2 (was 3 510) | 552 (567×) | 243 (4 916×) | 35 (315 000×) | **1 192** (was 611 241) |

All refreshed bounds re-verified ≥ measured deviations at every (window, N) cell
(§C of the refresh log). GRADING TRADE, stated plainly: the old chirp term was
proven-shape (T-norms) × resolvent and grossly conservative; the new term is a
measured-envelope constant at its honest value. The Part II T-route validity
thresholds (N₀ = 203/31 000) no longer bind the refreshed chirp step; N₁ is now set
by the q̂ ≤ ½ condition alone. The [1.5, 2.5] extrapolation flag of §0/§7 is RETIRED
(the B_EM formula evaluates directly on the whole grid).

**C2 is hereby flipped from consistency-check to write-up grade**: every convergence
step of the ξ-limit theorem now carries a displayed constant, and every displayed bound
is verified against measured finite-N deviations (§6). Grading inherited from Part II
(§7): all components proven except B_EM (certified-numeric, ×5, unchanged — its proof
is the separate B_EM task) and the Nyström grid quantities δ_±, Λ_±, gap (certified-
numeric, same grade as the sealed C-assembly).

## 1. Conventions and one sign arbitration

Lemma 1 (PROVEN, sealed): `γ_{j+1}²/γ_j² = (4j+7)/(4j+3) · (1−q_{j+1}^E)² /
[(1−q_j^O)(1−q_{j+1}^O)]` with `q_j^X = ⟨(I−Γ_X(j))^{-1}ψ_j^X, ψ_j^X⟩ ∈ [0,1)` and
`1−q_j^X = det(I−Γ_X(j+1))/det(I−Γ_X(j))`.

**Sign arbitration (numeric, both N):** the forward difference converges to **+(lnG)′**:
`√N·Δ_j ln γ² → (lnG)′(ξ) = 1/ξ + (8ξ/π)(δ₋ − δ₊)(L(ξ))` — measured −1.229 (N=1600) →
−1.170 (N=6400) vs (lnG)′(1) = −1.1109, O(1/√N) approach. The sealed §2's first
bracket display carries a benign sign slip (its ODE display and all values are correct);
likewise §3's derivative table lists the values of the FORWARD difference
N^{3/4}(γ_{j+1} − γ_j) → (√G)′. G-profile per the closed form: G(1/1.5/2/2.5) =
0.776/0.282/0.0443/0.0033, (√G)′ = −0.489/−0.770/−0.471/−0.169 (Nyström GL-240; the
(lnG)′-ODE lock holds to 1.7e-9; δ = −d lndet/dL and δ′ = (4/π)⟨ċ_L, Rc_L⟩ + δ² lock to
FD at ≤ 1.3e-7).

Window ingredients (grid over W with 0.12 margin, step 0.02; certified-numeric):

| window | δ̂₊ | δ̂₋ | Λ₊ | Λ₋ | ĝap₊ | ĝap₋ |
|---|---|---|---|---|---|---|
| [1.0, 2.0] | 1.9674 | 0.9847 | 0.4894 | 0.4763 | 3.06e-2 | 3.32e-1 |
| [1.5, 2.5] | 2.7106 | 1.7175 | 0.4948 | 0.4914 | 2.09e-3 | 5.23e-2 |

Λ_± := sup_W |δ_±′| is the ONE new ingredient (rank-one calculus: `δ′ = (4/π)⟨ċ_L,
(I−K)^{-1}c_L⟩ + δ²` — exact, no finite differences; values ≈ 1/2, consistent with
δ_± → L/2 ± ½).

## 2. Step S1 — Lemma 2 at displayed grade (the q-centering bound)

**LEMMA 2′.** For ξ_j = j/√N ∈ W and N ≥ N₁(W):
  `| q_j^X − (4ξ_j/(π√N))·δ_X(L(ξ_j)) | ≤ K_q,X / N`,   X = E (δ₊) / O (δ₋),
  K_q,E = 837.6, K_q,O = 53.8 on [1,2];  152 810 / 3 510 on [1.5,2.5].

*Proof (assembly).* `−ln(1−q_j^X) = ln det_X(j) − ln det_X(j+1)`. By Part II §3 each
det factors as sine-kernel det at the EXACT effective edge plus chirp and EM residuals:
`ln det_X(k) = ln det(I−K^±_{L_eff,X(k)}) + D_chirp + D_EM`. The consecutive difference
of the main terms is the exact rank-one integral `∫ δ_X(L′) dL′` over the effective-edge
interval, whose length is `ΔL_eff = (4j+1)/(πN)` (E) resp. `(4j+3)/(πN)` (O) — the
Lemma 2 coefficient `4ξ/(π√N)` is exactly the edge-interval length to O(1/N). Errors:
(interval-length surplus) ≤ (3/π)δ̂_X/N; (δ-variation over interval + edge offset) ≤
(4ξ₂/π)Λ_X·Ω/N with Ω = (2/π)(5ξ₂/2 + 3/(2√N₀)) + (4ξ₂ + 3/√N₀)/π from Part II's
displaced edges; (exp/log second order) ≤ ½(4ξ₂δ̂_X/π)²/N; (chirp) ≤ 2N·T_X·(2/ĝap_X)/N
with Part II's proven T-norms; (EM) ≤ 2·B_EM,X/N (certified-numeric ×5; beyond ξ = 2
extrapolated ∝ ξ², flagged). Sum = K_q,X. Validity N₁ = max(N₀, (16ξ₂δ̂/π)², 4·max K_q)
forces every q̂ ≤ ½ along the way. ∎

**Verified directly at q-level** (N = 1600, column Grams from the Bessel value laws,
analytic leading tail, cutoff-stable to 6 digits at 100N vs 200N):
|q − main|·N = 1.67/0.92 (ξ=1, E/O), 1.12/3.19 (ξ=1.5), 4.00/4.80 (ξ=2) — inside
K_q with factors 11–500.

## 3. Step S2 — the log-derivative and derivative bounds

**PROPOSITION.** For ξ_j ∈ W, N ≥ N₁:
  `| √N·Δ_j ln γ² − (lnG)′(ξ_j) | ≤ C_2^A/√N + C_2^B/N`,
  `| N^{3/4}(γ_{j+1} − γ_j) − (√G)′(ξ_j) | ≤ C_3^A/√N + C_3^B/N`.

Assembly: the elementary prefactor `|√N ln((4j+7)/(4j+3)) − 1/ξ_j| ≤ (5/4)/(ξ₁²√N)`;
the q-terms via Lemma 2′ (entering at 1/N) plus the index-shift terms
`S_X = (4/π)δ̂_X + (16ξ₂²/π²)Λ_X` (entering at 1/√N: q_{j+1} recentered from ξ_{j+1});
`C_2^A = (5/4)/ξ₁² + 2S_E + S_O`; C_2^B collects 2K_q,E + 2K_q,O + the r-remainder.
For C_3: multiply the envelope `N^{1/4}γ_j = √G·exp(ε/2)` (Part II scaling lemma,
|ε| ≤ (A_PII + B_PII/√N)/√N) by `√N(√ρ−1) = ½[(lnG)′ + dev] + exp-remainder`;
`C_3^A = √Ĝ·(½C_2^A + (sup|lnG′|)²/8) + √Ĝ·sup|lnG′|·A_PII/4`, C_3^B per script.

| window | C_2^A | C_2^B | C_3^A | C_3^B |
|---|---|---|---|---|
| [1.0, 2.0] | 16.95 | 1 858 | 20.21 | 1 435 |
| [1.5, 2.5] | 24.65 | 312 842 | 24.46 | 1.19e6 |

(B-parts superseded by §0b: 156/109 and 552/243.)

Measured: √N·dev = 4.72/4.72 (S2, N=1600/6400 — the 1/√N law exact to three digits)
and 1.68/1.71 (S2b) on [1,2]; 4.22/4.21 and 0.93/0.93 on [1.5,2.5]. **The A-part alone
covers every measured deviation** (factors 3.6/12 on [1,2] — Part II's A-part tightness
class).

## 4. Step S3 — the coefficient bound

**PROPOSITION.** `| 16ξ_j²N·a_{j+1}^{(N)} − 1 | ≤ (5/2)/(ξ_j√N) + K_a/N`, K_a = 89.1
on [1,2] (4 757 on [1.5,2.5]).

Elementary part (exact expansion, remainder sup ℚ-checked to j = 4000):
`16j²a_{j+1}^∞ = 16j²/[(4j+5)√((4j+3)(4j+7))] = 1 − 5/(2j) + O(c_a/j²)`, c_a = 4.81.
The measured ρ_a deficit ≈ 2.5/(ξ√N) is EXACTLY this elementary term — the prior
session's "c ≈ 2.4–2.7" profile is the a_{j+1} index convention (2/j) plus the
√-expansion (1/(2j)); **the Fredholm deformation enters only at 1/N** (Hankel-downdate
telescope: `a^{(N)2}/a^{∞2} = (1−q_j^O)/(1−q_{j−1}^O)`, a consecutive q-difference =
(S_O/2 + K_q,O)/N by Lemma 2′). Measured: ξ√N·dev = 2.52–2.66 vs 5/2 + K_a ξ₂/√N —
the elementary constant 5/2 is essentially sharp.

## 5. Step S4 — the theorem

Per-term: `N^{5/2} a_{j+1}(γ_j−γ_{j+1})² = f(ξ_j)·(1+e_a)(1+e_d)²` with f =
(√G)′²/(16ξ²), |e_a| ≤ S3, |e_d| ≤ S2b/|…|; Riemann block `|(1/√N)Σf(ξ_j) − ∫_W f| ≤
[(ξ₂−ξ₁)·sup_W|f′| + 2 sup_W f]/√N` with f′ from (√G)″ (= ½(√G)′(lnG)′ + ½√G(lnG)″,
(lnG)″ from δ′ — all on the certified grid). Collecting:
`C_W^A = (ξ₂−ξ₁)[f̂·(5/2)/ξ₁ + (2 sup|(√G)′|·C_3^A)/(16ξ₁²) + sup|f′|] + 2f̂` and C_W^B
per script. Values and verification in §0/§6. ∎

## 6. Verification summary (`xi_limit_C2_assembly_run.log`)

- Locks: δ = −d lndet/dL (≤ 4.8e-8), δ′ rank-one formula vs FD (≤ 1.3e-7), (lnG)′ ODE
  vs FD of ln G (≤ 1.7e-9), δ_± → L/2 ± ½ at L = 7.144 (4.088/3.091 vs 4.072/3.072 ✓).
- Every displayed bound ≥ its measured deviation at every (window, N) tested — with the
  A-part alone sufficient in all eight S2/S2b/S4 cells and the elementary 5/2 sharp at
  S3. Deviations scale as exact 1/√N (S2: 4.72 → 4.72; S4: 0.0092 → 0.0089 and
  0.0121 → 0.0121 per 4×N).
- N² window sums vs the analytic integral (trapezoid h = 0.005 on the δ-based
  integrand): 0.014130/0.014250 vs 0.014361 ([1,2], N=1600/6400) and 0.005101 vs
  0.005253 ([1.5,2.5], N=6400). (The sealed findings' integral values 0.014280/0.005247
  were h = 0.02 FD-of-√G quadrature; the analytic integrand shifts the reference by
  0.6/0.1% — ratios restated here against the better reference.)
- Direct q-level check: §2.

## 7. Honest grades and boundaries

- **Proven:** Lemma 1 (sealed); the det-telescope + rank-one-integral architecture of
  Lemma 2′; all elementary expansions with displayed remainders; Part II's T-norms and
  edge displacements (sealed, proven there).
- **Certified-numeric (Part II grade, unchanged):** δ_±, Λ_±, gaps on window grids
  (Nyström GL-240, well inside the float-safe zone; rank-one-calculus locks at 1e-7+);
  B_EM (×5 margin; **the one remaining numeric-grade component — its proof is the
  standing B_EM task, §1 of the horizon-residuals file**). Beyond ξ = 2, B_EM ∝ ξ²
  EXTRAPOLATED (Part II convention) — the [1.5,2.5] B-parts inherit this flag.
- **Conservatism, located:** B-parts and N₁ on [1.5,2.5] inflate through 2/ĝap₊ ~
  e^{1.9L} (Part II's known chirp-resolvent conservatism; measured deviations show
  reality is ~10⁴× milder). The caustic re-scope of the conditioning corollary
  (FINDINGS_LEMMA_A_closure_and_caustic_reconciliation.md) does NOT touch this
  theorem: all pairings here are against c_L (the polynomial class, §4c Corollary 2);
  no sharp-cut suprema enter.
- With C2 at write-up grade, the ξ-limit object (isometry B + dynamics C2 + fixed-mode
  identity C1) stands complete at write-up grade, conditional only on the itemized
  certified-numeric ingredients. Candidate ADDENDUM package for the limit-object
  construction: ready to stage on request (new dated folder, frozen-send discipline).

## 8. Manifest

`xi_limit_C2_assembly.py` + `xi_limit_C2_assembly_run.log` (this session): locks,
window constants, finite-N verification (N = 1600, 6400; full-reorth Lanczos), direct
q-check. Inputs (read-only): sealed `WRITEUP_M1_HORIZON_scaling_lemma.md` §§3–5,
`WRITEUP_M1_HORIZON_exact_layer_theorem.md`, living `WRITEUP_XI_LIMIT_layer_form_gamma.md`
§§1–3, `FINDINGS_XI_LIMIT_isometry_and_dirichlet.md`, `xi_limit_consistency_run.log`,
`xi_limit_coeff_profile_run.log`.

*— Stenberg + Claude, 2026-07-23. Four steps, four displayed bounds, every bound
measured against; the one numeric-grade residue (B_EM) is exactly where Part II left
it, now load-bearing for one displayed constant instead of a lemma's grade.*
