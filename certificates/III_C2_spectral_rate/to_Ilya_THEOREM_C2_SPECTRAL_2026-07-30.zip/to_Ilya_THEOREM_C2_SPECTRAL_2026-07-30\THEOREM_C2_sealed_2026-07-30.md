# THEOREM C2 — quantitative ξ-limit of the uniform-normalization (Op 1) layer operator

**Merkabit · Stenberg + Claude (Opus) · sealed 2026-07-30. The consolidated
ξ-limit theorem for Op 1 (the model-lattice uniform-normalization operator):
energy convergence with displayed rate, Γ+Mosco spectral convergence, and the
now-fully-displayed 1/√N rate constant. Op 1 only — self-adjoint both sides;
this does NOT touch Op 2 = D+V or the de Branges wall. Not RH/GRH.**

---

## 0. Setup

Model lattice `z_n = (n−½)π`, `x_n = z_n^{−2}`, cyclic vector `u_n = x_n²/Σx_n²`.
Lanczos on `(x,u)` gives the odd Jacobi coefficients `a_{j+1}^{(N)}` (off-diagonal)
and the ground vector `γ_j = |⟨V_j, e_0⟩|`, `e_0 = N^{−1/2}𝟙`. On a window
`W = [ξ₁,ξ₂] ⊂ (0,∞)`, index set `[j₁,j₂] = [⌊ξ₁√N⌋, ⌊ξ₂√N⌋]`, uniform ξ-grid
`ξ_j = j/√N` (spacing `h = 1/√N`). Define the **layer Dirichlet form**
`Q_N^{lay}[φ] = N² Σ_{j=j₁}^{j₂−1} a_{j+1}^{(N)} (φ_j − φ_{j+1})²` with free (Neumann)
ends and plain ℓ² mass `Σ φ_j²`. Let `G(ξ)` be the det-ratio profile
`G = 2ξ·[det(I−K⁺)/det(I−K⁻)]²` (M1-HORIZON), and

  **`A = −(1/16)(ξ^{−2} φ′)′`  on L²(W), Neumann BC** — the limit Sturm–Liouville operator.

## 1. Theorem C2

**(A) Energy convergence with displayed rate.** For `N ≥ N₁(W)`,
```
| N² Σ_W a_{j+1}^{(N)} (γ_j − γ_{j+1})²  −  ∫_W (√G)′(ξ)² / (16 ξ²) dξ |
        ≤  C_W^A / √N  +  C_W^B / N,
```
with `C_W^A, C_W^B` the displayed window constants of the S1–S4 chain
(`xi_limit_C2_assembly.py`): every ingredient at displayed-or-interval grade —
`δ_±, δ_±′, gap_±` interval-certified (item-5 arb engine, ξ=1…3.35, GL-300/400/500
to 9 digits); `B_EM` in **closed exact-δ form** `B_EM^X(ξ) = (1/24)[(4/π)δ_X +
(16ξ*²/π²)(δ_X′−δ_X²)] − [E](1/3π²)η₊` (the one former ×5 certified-numeric residue,
now displayed, matching measured residuals to 4 decimals, proven-shape O(1/√N)
remainder); S3 coefficient rate `|16ξ²N a_{j+1} − 1| ≤ (5/2)/(ξ√N) + K_a/N`
(leading 5/2 PROVEN). A-parts alone cover every measured deviation at N=1600/6400.

**(B) Γ+Mosco spectral convergence.** `Q_N^{lay}` Γ-converges (with the Mosco
liminf/limsup) to `𝔇[ψ] = ∫_W ψ′²/(16ξ²) dξ`; the ground vector `√N^{1/2}γ → √G`
in the window; and for each fixed `k` the `(k+1)`-st eigenvalue of `(Q_N^{lay}, ℓ²)`
satisfies `λ_k^N → λ_k(A)` at rate `1/√N`:
```
| λ_k^N − λ_k(A) |  ≤  c_k / √N  +  O(1/N).
```
The limit spectrum is **G-independent** — `G` governs the ground *vector* √G, not the
*form* `𝔇`.

**(C) The 1/√N rate constant, fully displayed.** The relative rate
`c_k/λ_k → 𝒞_W` (mode-independent to ~2% across the low band) is the explicit
eigenfunction functional
```
   𝒞_W  =  (φ(ξ₁)² + φ(ξ₂)²) / (2 ‖φ‖²_{L²(W)})   +   (3/2) · r̄_W,
   r̄_W  =  ⟨(φ′)²/ξ³⟩_W / ⟨(φ′)²/ξ²⟩_W ,
```
with three derived, physically-named pieces:
- **boundary mass-lumping** `(φ(ξ₁)²+φ(ξ₂)²)/(2‖φ‖²)` — plain ℓ² over-weights the two
  Neumann-boundary half-cells (the O(h) error of the correctly-placed edge operator;
  interior is O(h²); the domain-mismatch/Hadamard term is 0 for integer ξ_i·√N);
- **coefficient half-step** `−r̄` (node vs edge placement of `1/16ξ²`, first-order Taylor);
- **S3 coefficient** `−(3/2)r̄` (the proven 5/2, net −3/2 relative to the edge).

On `W=[1,2]`: `r̄ = 0.658`, `𝒞 = 2.98` (measured 2.97–2.99); on `[1.5,2.5]`: `𝒞 ≈ 2.74`.

## 2. Proof chain (ingredients, all pointer-verified)

1. **Architecture** — Lemma 1 (exact rank-one log-derivative `δ′ = (4/π)⟨·,Rc⟩ + δ²`),
   Lemma 2′ (det-telescope + rank-one integral), S1–S4 elementary expansions with exact
   remainder sups. ℤ[x]-certified closure identities. [PROVEN]
2. **Displayed constants** — `xi_limit_C2_assembly.py`: S1 K_q, S2 C₂, S2b C₃, S3 K_a,
   S4 C_W in the A/B convention; finite-N verification N=1600/6400 (full-reorth Lanczos),
   A-part covers all deviations. `δ/δ′/gap` interval-certified (item-5). `B_EM` exact-δ.
   [D / interval-certified]
3. **Γ+Mosco** — recovery sequence (Γ-limsup) + Mosco liminf on the window; ξ→0 excluded
   (`𝔇` singular there); the √N powers cancel in the Rayleigh quotient. [D / classical]
4. **Spectral rate (C)** — min-max over recovery sequences carries the C2 energy rate to
   the eigenvalues; the three constants isolated by controlled couplings (node / edge /
   actual `a_{j+1}`), reproducing 1.356 / 2.008 / 2.985 = (i)/(i+ii)/(all), and each
   derived as an eigenfunction integral (`c2_derive_i_ii.py`, `c2_close_i.py`). [D]

## 3. Grade and honest boundaries

- **Grade: THEOREM (displayed-rigorous / interval-certified).** (A) energy bound with
  displayed+interval constants; (B) Γ+Mosco classical given (A); (C) rate constant now
  fully displayed (this seal upgrades it [D+disp] → [D]).
- **Residual to a *fully sealed* proof (rigor polish, not new constants):** bound the
  first-order-perturbation remainders in (C) as O(h²) (the low-mode ~2–5% mismatch is
  exactly that slack); state `B_EM`'s proven-shape O(1/√N) remainder as a displayed sup.
  No new mathematics; no measured input remains in the leading constants.
- **Scope.** Per-fixed-`k` (tested `k ≤ 4`); uniform *relative* rate empirical over the
  low band; no uniform-in-`k`. Full norm-resolvent convergence stays qualitative Mosco;
  the low eigenvalues carry the displayed rate. `ξ→0` excluded.
- **Two-operator discipline.** This is **Op 1** (uniform-normalization), self-adjoint both
  sides. The open essential-self-adjointness / deficiency-(0,0) problem is **Op 2 = D+V**
  — a different operator; **nothing here advances or touches the wall (R-209).**

## 4. Manifest

`evidence/`: `xi_limit_C2_assembly.py` (+log), `xi_limit_C2_spectral.py` (+log),
`c2_derive_i_ii.py`, `c2_close_i.py`, `FINDINGS_C2_spectral_rate_derivation.md`,
`WRITEUP_XI_LIMIT_C2_rate_constants.md`, `WRITEUP_XI_LIMIT_gamma_convergence.md`,
`WRITEUP_XI_LIMIT_spectral_convergence.md`.

*— Stenberg + Claude (Opus), sealed 2026-07-30. Op 1's ξ-limit closed at theorem grade:
energy convergence (displayed/interval), Γ+Mosco, and the spectral rate constant
𝒞_W = (φ(ξ₁)²+φ(ξ₂)²)/(2‖φ‖²) + (3/2)r̄ — every piece an explicit eigenfunction integral.
The wall (Op 2) stands untouched. Not RH/GRH.*
