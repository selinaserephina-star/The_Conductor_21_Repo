import numpy as np, math
from scipy.linalg import eigh
np.set_printoptions(suppress=True)

def odd_system(N):
    n=np.arange(1,N+1); z=(n-0.5)*np.pi; x=z**-2.0
    return x, x**2/np.sum(x**2)
def lanczos(x,u,jtop):
    N=len(x); v=np.sqrt(u); V=np.zeros((jtop+2,N)); V[0]=v
    al=np.zeros(jtop+1); be=np.zeros(jtop+1)
    w=x*v; al[0]=v@w; w=w-al[0]*v
    for j in range(1,jtop+2):
        b=math.sqrt(w@w); vn=w/b
        vn-=V[:j].T@(V[:j]@vn); vn-=V[:j].T@(V[:j]@vn); vn/=math.sqrt(vn@vn); V[j]=vn
        if j<=jtop: be[j-1]=b; w=x*vn-b*V[j-1]; a=vn@w; al[j]=a; w=w-a*vn
        else: break
    return al,be

def layer_eigs_w(w, m, kmax):
    d=np.zeros(m); d[:-1]+=w; d[1:]+=w
    A=np.diag(d)+np.diag(-w,1)+np.diag(-w,-1)
    return np.linalg.eigvalsh(A)[:kmax+1]

def limit_eig_vec(x1,x2,M,kmax):
    eta=np.linspace(x1,x2,M); h=eta[1]-eta[0]; xm=0.5*(eta[:-1]+eta[1:])
    w=(1/16.0)/(xm*xm)/h; d=np.zeros(M); d[:-1]+=w; d[1:]+=w
    E=np.diag(d)+np.diag(-w,1)+np.diag(-w,-1); Mass=np.diag(np.full(M,h))
    val,vec=eigh(E,Mass); return eta,val[:kmax+1],vec[:,:kmax+1]

KMAX=4; NS=[1600,6400,25600]; x1,x2=1.0,2.0
# limit reference + eigenfunctions
eta,lam_inf,vec=limit_eig_vec(x1,x2,8000,KMAX)
print("lambda_inf [1,2]:",", ".join(f"{v:.6f}" for v in lam_inf))

# integral ratio r_k = int (phi')^2/xi^3 / int (phi')^2/xi^2   (the first-order-perturbation weight)
h=eta[1]-eta[0]; r=[]
for k in range(KMAX+1):
    ph=vec[:,k]; dph=np.gradient(ph,eta); mid=0.5*(eta[:-1]+eta[1:]); dphm=0.5*(dph[:-1]+dph[1:])
    num=np.trapezoid(dphm**2/mid**3,mid); den=np.trapezoid(dphm**2/mid**2,mid)
    r.append(num/den if den else 0)
print("integral ratio r_k = <phi'^2/xi^3>/<phi'^2/xi^2>:",", ".join(f"{v:.4f}" for v in r[1:]))

# ---- isolate the three constants via controlled couplings ----
print("\n  variant           c_k/lam_k (relative rate constant), k=1..4, at N=1600/6400/25600")
def relconst(couplingfn):
    out={}
    for N in NS:
        x,u=odd_system(N); sN=math.sqrt(N); jtop=int(2.6*sN)+5
        al,be=lanczos(x,u,jtop); j1,j2=int(x1*sN),int(x2*sN); m=j2-j1+1
        j=np.arange(j1,j2); w=couplingfn(j,sN,N,be)
        ev=layer_eigs_w(w,m,KMAX)
        out[N]=[math.sqrt(N)*(ev[k]-lam_inf[k])/lam_inf[k] for k in range(1,KMAX+1)]
    return out
variants={
 "(i) node   c@xi_j    ": lambda j,sN,N,be: N/(16*(j/sN)**2),
 "(i+ii)edge c@xi_{j+.5}": lambda j,sN,N,be: N/(16*((j+0.5)/sN)**2),
 "(all) actual be_j     ": lambda j,sN,N,be: N*N*be[j],
}
res={}
for name,fn in variants.items():
    res[name]=relconst(fn)
    vals=res[name][NS[-1]]  # richest N
    print(f"  {name}: "+", ".join(f"{v:.3f}" for v in vals)+f"   (mean {np.mean(vals):.3f})")

# ---- the derived decomposition ----
mn=lambda name: np.mean(res[name][NS[-1]])
Ci=mn("(i) node   c@xi_j    "); Cie=mn("(i+ii)edge c@xi_{j+.5}"); Call=mn("(all) actual be_j     ")
print(f"\n  ISOLATED:  (i)={Ci:.3f}   (i+ii)={Cie:.3f}   (all)={Call:.3f}")
print(f"             => (ii)=(i+ii)-(i)={Cie-Ci:+.3f}   (iii)=(all)-(i+ii)={Call-Cie:+.3f}")

rbar=np.mean(r[1:])
print(f"\n  DERIVED (first-order perturbation, r_bar={rbar:.4f}):")
print(f"    (ii) half-step node->edge:  delta(c)/c = -h/xi (c=1/16xi^2, c'=-1/8xi^3)")
print(f"         predicted (ii) = -1 * r_bar = {-rbar:.3f}   vs isolated {Cie-Ci:+.3f}")
print(f"    (iii) S3 coeff error, leading -5/(2 xi sqrtN) (PROVEN 5/2, C2 s4):")
print(f"         predicted (iii) = -(5/2)*r_bar = {-2.5*rbar:.3f}   vs isolated {Call-Cie:+.3f}")
# domain-mismatch check
for N in NS:
    sN=math.sqrt(N); print(f"    domain check N={N}: xi_j1={int(x1*sN)/sN:.4f} (x1={x1}), xi_j2={int(x2*sN)/sN:.4f} (x2={x2})  offset={'ZERO' if abs(int(x1*sN)/sN-x1)<1e-12 and abs(int(x2*sN)/sN-x2)<1e-12 else 'NONZERO'}")

# ---- derive (i): the node-coefficient grid error. domain-mismatch=0 here, so it is
#      interior-FD (O(h^2)) + boundary mass-lumping (plain l^2 over-weights the 2 end
#      half-cells by h/2 each => O(h) eigenvalue error). Test the boundary-mass model. ----
print("\n  (i) grid error -- test boundary mass-lumping model:")
print("     plain-l^2 mass weights end nodes w=1 like interior; proper trapezoid gives 1/2.")
print("     over-mass at 2 ends = (h/2)(phi(x1)^2+phi(x2)^2); delta_lam/lam = -over/ ||phi||^2")
print("     => constant (i)_pred = -(phi(x1)^2+phi(x2)^2)/(2 int phi^2)  (h*sqrtN=1)")
for k in range(1,KMAX+1):
    ph=vec[:,k]; nrm=np.trapezoid(ph**2,eta)
    bmodel=-(ph[0]**2+ph[-1]**2)/(2*nrm)
    print(f"     k={k}: isolated (i)={res['(i) node   c@xi_j    '][NS[-1]][k-1]:+.3f}   "
          f"boundary-mass pred={bmodel:+.3f}   phi(x1)^2={ph[0]**2/nrm:.3f} phi(x2)^2={ph[-1]**2/nrm:.3f} (/||phi||^2)")
