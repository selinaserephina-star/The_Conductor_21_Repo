# Arithmetic matching — response to Ilya (2026-07-17)

**Merkabit · Stenberg + Claude.** Answering `ARITHMETIC_MATCHING_REQUEST.md` for
`H21_CHI8_ABSTRACT_BRIDGE_CERTIFIED`. Both your zips SHA-verify. **Verdict: the arithmetic χ₈ is exactly
your certified induced representation — identification CERTIFIED at the Euler-factor level.**

## 1. Defining Galois representation / number field

$\chi_8$ = the **unique** 8-dimensional irreducible Artin representation of $\mathrm{Gal}(L/\mathbb{Q})$,
where $L$ is the splitting field of the **Trinks polynomial**
$$
f(x) = x^7 - 7x + 3, \qquad \mathrm{Gal}(L/\mathbb{Q}) \cong \mathrm{PSL}(2,7) = \mathrm{GL}(3,2),\ |G|=168.
$$
The degree-7 field $K=\mathbb{Q}[x]/(f)$ is the point-stabilizer resolvent (index-8 $\mathrm{PSL}(2,7)$
action on 7 points). Since $\chi_8$ is the *unique* degree-8 irreducible of $\mathrm{PSL}(2,7)$, your
$\mathrm{Ind}_{C_7:C_3}^{G}\psi$ (proved $=\chi_8$ as a character) and our $\chi_8$ are the **same
representation**; the arithmetic realization is via $L$. Frobenius classes are read off $f \bmod p$
(the cycle type on 7 roots = the conjugacy class), which is exactly how the local factors below are
built (`gen_an_120M.gp`, function `loc8`).

## 2. Conductor
$$
N = 21^{10} = 3^{10}\cdot 7^{10} = \mathbf{16679880978201}\quad(\text{= the LMFDB conductor field}).
$$

## 3. Ramified primes and local factors
Only $3$ and $7$ ramify ($\mathrm{disc}\,\mathbb{Z}[x]/(f) = 3^8 7^8$; $[\mathcal O_K:\mathbb Z[\theta]]=3$).
Local factors $P_p(T)=\det(1-\rho(\mathrm{Frob}_p)\mid V^{I_p})$:
$$
P_3(T) = 1-T \quad (\dim V^{I_3}=1,\ \text{wild inertia }=3A\text{ trit},\ a_3(\chi_8)=10);
$$
$$
P_7(T) = 1 \quad (\dim V^{I_7}=0,\ \text{genome dissolved, Singer }C_7,\ a_7(\chi_8)=10).
$$
(Full inertia $I_0 = S_3$ at 3, $C_7{:}C_3$ at 7; Swan/Artin certified — our still-point note + your
own T13.)

## 4. Archimedean gamma shifts
$$
\gamma(s) = \Gamma_{\mathbb C}(s)^4 = \Gamma_{\mathbb R}(s)^4\,\Gamma_{\mathbb R}(s+1)^4,
\qquad \mu = [0,0,0,0,1,1,1,1].
$$
(Consistent with $\chi_8(2A)=0$: at complex conjugation $a=\tfrac{8+0}{2}=4$ real, $b=4$ shifted.)

## 5. Root number
$$
\varepsilon = +1 \quad(\text{self-dual, orthogonal};\ \Lambda(\tfrac12)=15148.14\neq0\Rightarrow\varepsilon\neq-1;\ \texttt{lfuncheckfeq}\ \text{residual }10^{-27}).
$$

## 6. Completed-function normalization
$$
\Lambda(s,\chi_8) = N^{s/2}\,\gamma(s)\,L(s,\chi_8),\qquad \Lambda(s) = \varepsilon\,\Lambda(1-s),\ \varepsilon=+1.
$$

## 7. Database label
As recorded in the zero-computation files: LMFDB Artin representation
**`8.16679880978201.21t14.b.a`** (degree 8, conductor $21^{10}$, the $\chi_8$ constituent). The
identification below does not rely on the label — it rests on the exact local factors.

---

## Unramified comparison — the test you asked for

For the first **30 unramified primes**, $P_p(T)=\det(1-\rho(\mathrm{Frob}_p)T)$ was computed from the
factorization type of $f=x^7-7x+3 \bmod p$ (→ Frobenius class → $\chi_8$ local factor). **Every one matches
your template exactly** (`chi8_unramified_euler_first30.csv`). The class → polynomial map is complete
(all six $G$-classes; $7a,7b$ share $(1-T)(1-T^7)$, as you note). Traces off these polynomials reproduce
$\chi_8=[8,-1,1,1,0,0]$ on every class.

```
CONDUCTOR=16679880978201            (= 21^10 = 3^10 * 7^10)
GAMMA_SHIFTS=[0,0,0,0,1,1,1,1]      (Gamma_C^4)
ROOT_NUMBER=+1
RAMIFIED: P_3(T)=1-T ; P_7(T)=1
UNRAMIFIED_PRIMES_CHECKED=30
ALL_LOCAL_POLYNOMIALS_MATCH_TEMPLATE=true
ARITHMETIC_CHI8_IDENTIFICATION=CERTIFIED
```

**Why CERTIFIED (not just "30 primes agree"):** our $L$-function's Euler factors are, *by construction*,
$\det(1-\rho_{\chi_8}(\mathrm{Frob}_p)T)$ with $\mathrm{Frob}_p$ the Trinks-field Frobenius; $\chi_8$ is
the unique degree-8 irreducible; your bridge proves $\mathrm{Ind}\,\psi=\chi_8$. So the two Artin
$L$-functions are literally the same object, and the 30-prime table is the empirical confirmation of a
structural identity (same character, same field). $H21\_MONOMIALITY \Rightarrow$ the arithmetic $\chi_8$
is monomial, induced from the order-21 Borel $C_7{:}C_3$ by a cubic character $\psi$ — which is exactly
the cubic-Hecke realization $L(s,\chi_8)=L(s,\psi)$ we use for entirety/Selberg-class membership.

## On your completeness point (the global zero count)

Agreed and important: the 21 certified sign-changing brackets give **existence + localization**, not
**completeness**. $N_{\chi_8}(T^\*)=21$ for a certified $T^\*\gtrsim5.969$ needs a Turing / argument-
principle / explicit-formula count. The paper's §A.9.2 sketches the argument-principle count on the
in-range window; a *certified* $S(T^\*)$-bounded Turing count to close "exactly 21, no more" is the right
next computation and we'll take it on. (It is independent of this arithmetic-matching result and of any
$Q_2$ / rank-drop assumption — none used here, confirmed.)

## Contents
- `chi8_unramified_euler_first30.csv` — the 30-prime Euler table + the two ramified factors.
- `ARITHMETIC_MATCHING_RESPONSE.md` (this file), `SHA256SUMS.txt`.

— Selina + Claude, 2026-07-17. Not RH/GRH.
