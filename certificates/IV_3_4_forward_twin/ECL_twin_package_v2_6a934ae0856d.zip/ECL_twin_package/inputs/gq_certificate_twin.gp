\\ TWIN certificate: Q(t)=Xi'^2-Xi*Xi'' for L(s, chi8 (x) (./-7)), covering the tight pair (3.333,3.450).
\\ Twist: good-prime factor = chi8 factor with X -> kronecker(-7,p)*X; bad factor (1+X) at 3, trivial at 7.
default(parisize, 14*10^9);
default(parisizemax, 44*10^9);
default(realbitprecision, 32);
OUT = "gq_curve_twin.txt"; VAL = "gq_validate_twin.txt";
wr(f,s) = { print(s); write(f, s); }
fpoly = w^7 - 7*w + 3;
uf(p) = { my(fl=factormod(fpoly,p), dl=List(), part); for(i=1,#fl[,1], for(k=1,fl[i,2], listput(dl,poldegree(fl[i,1])))); part=vecsort(Vec(dl)); \
  if(part==[1,1,1,1,1,1,1],(1-X)^8, part==[1,1,1,2,2],(1-X^2)^4, part==[1,3,3],(1-X)^2*(1+X+X^2)^3, part==[1,2,4],(1-X^4)^2, part==[7],(1-X)*(1-X^7), error("bad ",part)); }
LFt(p) = if(p==3, 1/(1+X), p==7, 1, my(s=kronecker(-7,p)); 1/subst(uf(p), X, s*X));
N = 3^10*7^10;
gettime(); B = 85000000;
v = direuler(p=2, B, LFt(p)); print("direuler B=", B, " [", gettime(), " ms]");
L0 = lfuncreate([v, 0, [0,0,0,0,1,1,1,1], 1, N, 1]);
fq = lfuncheckfeq(L0); print("feq = ", fq);
L = lfuninit(L0, [1/2, 0, 3.75]); print("lfuninit [", gettime(), " ms]");
Xi(tt) = real(lfunlambda(L, 1/2 + I*tt));

\\ twin zeros (21 total; those <= 3.7 used for the validation anchors)
zerT = [0.7008726,1.117190,1.435961,1.663117,2.035373,2.399427,2.718802,3.048931,3.333481,3.449676,3.620594,3.970986,4.169789,4.302873,4.558104,4.790972,5.061900,5.171572,5.479779,5.572594,5.957655];
X0 = Xi(0.0); h = 0.003;
wr(VAL, Strprintf("TWIN  feq (log10 residual) = %d  [<=-20 PASS]", fq));
wr(VAL, Strprintf("Xi(0) = Lambda(1/2, twin) = %.6f   (central value; the +/-7 twin's own number)", X0));
wr(VAL, Strprintf("Xi'(0) = %.4e   (should be ~0: Xi even)", (Xi(h)-Xi(-h))/(2*h)));
wr(VAL, "Xi at twin zeros <= 3.7 (each ~0 relative to Xi(0)):");
{ for(i=1,11, my(xz=Xi(zerT[i])); wr(VAL, Strprintf("   %.5f :  Xi = %+.4e   (rel %.1e)", zerT[i], xz, abs(xz/X0)))); }

\\ Q(t) on [0,3.7] step 0.02
wr(OUT, "# TWIN  t        Xi              Q=Xi'^2-Xi*Xi''    Q/Xi^2");
minQ=1e99; minT=0;
{ forstep(t0=0.0, 3.7, 0.02,
    my(xm=Xi(t0-h), x0=Xi(t0), xp=Xi(t0+h), x1=(xp-xm)/(2*h), x2=(xp-2*x0+xm)/h^2, Q=x1^2-x0*x2, m=Q/x0^2);
    if(Q<minQ, minQ=Q; minT=t0);
    wr(OUT, Strprintf("%.2f  %+.6e  %+.6e  %.4f", t0, x0, Q, m))); }
wr(OUT, Strprintf("# min Q on [0,3.7] = %.6e at t = %.2f", minQ, minT));

\\ refine the TIGHT PAIR dip [3.28,3.50] step 0.005 (the twin's tightest wall, gap 0.116)
wr(OUT, "# --- tight-pair dip refine [3.28,3.50] step 0.005 (zeros 3.333, 3.450) ---");
minQd=1e99; minTd=0; minMd=1e99; minMt=0;
{ forstep(t0=3.28, 3.50, 0.005,
    my(xm=Xi(t0-h), x0=Xi(t0), xp=Xi(t0+h), x1=(xp-xm)/(2*h), x2=(xp-2*x0+xm)/h^2, Q=x1^2-x0*x2, m=Q/x0^2);
    if(Q<minQd, minQd=Q; minTd=t0); if(m<minMd, minMd=m; minMt=t0)); }
wr(OUT, Strprintf("# refined min Q on tight pair = %.6e at t=%.3f ;  min margin Q/Xi^2 = %.3f at t=%.3f", minQd, minTd, minMd, minMt));

\\ margin identity: Q/Xi^2 =?= sum over all 21 zeros [1/(t-g)^2+1/(t+g)^2]
wr(OUT, "# margin identity  Q/Xi^2  vs  sum(21 zeros)  [close mid-range; sum is lower bound]");
{ foreach([0.5,1.2,2.0,2.8,3.4], t0,
    my(xm=Xi(t0-h), x0=Xi(t0), xp=Xi(t0+h), x1=(xp-xm)/(2*h), x2=(xp-2*x0+xm)/h^2, lhs=(x1^2-x0*x2)/x0^2,
       rhs=sum(i=1,21, 1/(t0-zerT[i])^2 + 1/(t0+zerT[i])^2));
    wr(OUT, Strprintf("   t=%.1f :  Q/Xi^2 = %.4f   sum_21 = %.4f   ratio = %.4f", t0, lhs, rhs, lhs/rhs))); }
quit;
