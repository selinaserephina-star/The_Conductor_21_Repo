# ECL twin package — Envelope Comb protocol, artifact-backed

**For:** Ilya Balashov · **From:** Selina + Claude (avatar session) · **2026-07-02**
**Object:** the genome CM-twin χ₈⊗(·/−7) — companion package to `ECL_chi8_package` (same structure).

## Protocol compliance map

| item | file(s) |
|---|---|
| 1. Passport | `passport_twin.json` — conductor **preserved at 21¹⁰** (the Mumford–Tate signature, feq-search-pinned 06-28), bad factors (1+X) at 3 / trivial at 7, density law (log N, d) from which ρ derives |
| 2. Zero table | `zeros_twin.csv` — 11 anchored zeros ≤ 3.7 with Ξ-residuals (used for gaps) + 10 more to T=6 from the 06-28 zeros run (used in the identity sum only), status per row |
| 3. Gap minima | `outputs/gap_minima_twin.csv` |
| 4. Envelope overlay | `outputs/envelope_overlay_twin.csv` + `outputs/envelope_summary_twin.json` |
| 5. Artifacts | `envelope_overlay.py`, raw inputs under `inputs/`, `MANIFEST.json`, `SHA256SUMS.txt` |

## Result (rerun-verified)

- **Q > 0 at all 186 grid points** on [0, 3.7], through the tight pair (3.33348, 3.44968).
- **ECL-1 bound:** holds everywhere except one benign dip (t=1.68, ratio 0.99996 — 0.017 from a
  5-digit zero, where a 1e−5 γ-error moves the sum ~0.1%; rounding, documented in the summary JSON).
- **ECL-2 overlay: 10 gaps, ratios 0.943–1.084.** Unlike χ₈ (all above 1), the twin's mid-range runs
  slightly *below* prediction — exactly its three consecutive wider-than-mean gaps (1.66–2.72, a
  locally sparser comb): the ECL-3 Err_comb term with visible sign, not noise.
- **Which-wall (first of its kind):** twin margin ≈ 676 inside its tight pair vs χ₈'s ≈ 205 at its
  tightest — the twin's wall measured **~3× tighter**, matching the zero-gap prediction.
- **Combined with χ₈: 17 gaps across two objects on one shell, all within ±8.4% of the
  parameter-free comb formula.**

## Audit protocol (order matters — per IB, 2026-07-02)

```
sha256sum -c SHA256SUMS.txt       # 1. verify the SHIPPED bytes first
python envelope_overlay.py        # 2. rerun (rewrites outputs/)
                                  # 3. compare numerical outputs to the shipped values
sha256sum -c SHA256SUMS.txt       # 4. outputs byte-deterministic (JSON forced LF+UTF-8)
```

## Caveats (honest)

The raw twin curve carries (t, Ξ, Q, Q/Ξ²) only — Q was not recomputable from separate Ξ′/Ξ″ columns
as in the χ₈ package (checked instead: margin ≡ Q/Ξ² to printing precision, plus the identity bound
against 21 independent zeros). Zeros 12–21 are from the earlier 24-bit T≤6 run (no fresh residuals);
they enter only the identity sum, where their effect is the small positive tail. Scope unchanged:
in-range positivity, not RH.
