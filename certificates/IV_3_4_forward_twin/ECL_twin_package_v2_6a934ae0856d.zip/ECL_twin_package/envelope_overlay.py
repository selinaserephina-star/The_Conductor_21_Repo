"""ENVELOPE COMB protocol — twin package overlay (protocol items 3 + 4).

Reads:  inputs/gq_curve_twin.txt   (claude2's raw curve: t, Xi, Q, Q/Xi^2 — 4 columns;
                                    unlike the chi8 file it does not carry Xi'/Xi'' separately)
        zeros_twin.csv             (item 2: 11 anchored zeros <=3.7 for gaps; 21 total for the identity sum)
        passport_twin.json         (item 1: rho DERIVED from log_N, d — not fitted)

Checks: (i) Q > 0 at every grid point; (ii) margin column == Q/Xi^2 (printing precision);
        (iii) ECL-1 lower bound Q/Xi^2 >= sum over ALL 21 known zeros of [1/(t-g)^2 + 1/(t+g)^2]
        at every point >= 0.015 from a zero.  Known benign exception: t=1.68 dips 3.8e-5 below 1 —
        it sits 0.017 from a 5-digit zero where a 1e-5 gamma error moves the sum ~0.1% (rounding).

Emits:  outputs/gap_minima_twin.csv, outputs/envelope_overlay_twin.csv, outputs/envelope_summary_twin.json

Deterministic; stdlib only; rerun with:  python envelope_overlay.py
"""
import re, math, json, csv, os

HERE = os.path.dirname(os.path.abspath(__file__))
P = json.load(open(os.path.join(HERE, "passport_twin.json")))
LOG_N = P["density_law"]["log_N"]; DEG = P["density_law"]["d"]
TWOPI = 2*math.pi
def rho(t): return (LOG_N + DEG*math.log(t/TWOPI)) / TWOPI

zr = list(csv.DictReader(open(os.path.join(HERE, "zeros_twin.csv"))))
Z_gaps = [float(r["gamma_j"]) for r in zr if r["status"] == "numerical_anchored"]   # 11, <=3.7
Z_all  = [float(r["gamma_j"]) for r in zr]                                          # 21, for identity
assert len(Z_gaps) == 11 and len(Z_all) == 21

rows = []
for line in open(os.path.join(HERE, "inputs", "gq_curve_twin.txt")):
    line = line.strip()
    if not line or line.startswith("#"): continue
    p = re.sub(r'\s+e(?=[+-]?\d)', 'e', line).split()
    if len(p) == 4: rows.append([float(x) for x in p])

assert all(q > 0 for _, _, q, _ in rows), "Q<=0 somewhere!"
col_err = max(abs(q/xi**2 - m)/abs(m) for _, xi, q, m in rows if xi and m)
S = lambda t: sum(1/(t-g)**2 + 1/(t+g)**2 for g in Z_all)
dips = [(t, round(m/S(t), 7)) for t, _, _, m in rows
        if min(abs(t-g) for g in Z_all) >= 0.015 and m/S(t) < 1]

gaps = []
for i in range(len(Z_gaps)-1):
    a, b = Z_gaps[i], Z_gaps[i+1]; g = b - a; mid = (a+b)/2
    inside = [r for r in rows if a + 0.02 < r[0] < b - 0.02]
    if not inside: continue
    mmin = min(r[3] for r in inside)
    tmin = [r[0] for r in inside if r[3] == mmin][0]
    pred = 8/g**2 + (math.pi**2 - 8)*rho(mid)**2
    gaps.append(dict(gap_index=i+1, gamma_lo=a, gamma_hi=b, g=round(g,5),
                     midpoint=round(mid,5), t_at_min=tmin, measured_min=round(mmin,4),
                     rho_mid=round(rho(mid),6), predicted=round(pred,4),
                     ratio_measured_over_predicted=round(mmin/pred,4)))

os.makedirs(os.path.join(HERE, "outputs"), exist_ok=True)
with open(os.path.join(HERE, "outputs", "gap_minima_twin.csv"), "w", newline="") as f:
    w = csv.DictWriter(f, ["gap_index","gamma_lo","gamma_hi","g","t_at_min","measured_min"])
    w.writeheader()
    for r in gaps: w.writerow({k: r[k] for k in w.fieldnames})
with open(os.path.join(HERE, "outputs", "envelope_overlay_twin.csv"), "w", newline="") as f:
    w = csv.DictWriter(f, list(gaps[0].keys())); w.writeheader(); w.writerows(gaps)

summary = dict(
    object="chi8 CM-twin", protocol="ENVELOPE COMB (ECL-2/ECL-5)", grid_points=len(rows),
    t_range=[rows[0][0], rows[-1][0]],
    Q_positive_at_all_points=True,
    margin_column_max_rel_err=float(f"{col_err:.2e}"),
    identity_lower_bound_dips=dips,
    identity_note="21-zero truncated sum = strict lower bound; the single t=1.68 dip (0.99996) is "
                  "5-digit zero-position rounding (0.017 from gamma_4), not a violation",
    envelope_formula="8/g^2 + (pi^2-8)*rho(mid)^2, rho from passport (log_N=%.6f, d=%d), zero fitted parameters" % (LOG_N, DEG),
    ratio_min=min(r["ratio_measured_over_predicted"] for r in gaps),
    ratio_max=max(r["ratio_measured_over_predicted"] for r in gaps),
    which_wall_note="twin margin ~676 inside its tight pair (3.33348,3.44968) vs chi8 ~205 at its "
                    "tightest: the twin's wall is ~3x tighter, as zero-gaps predicted",
)
json.dump(summary, open(os.path.join(HERE, "outputs", "envelope_summary_twin.json"), "w", newline="\n", encoding="utf-8"), indent=1)

print(json.dumps(summary, indent=1))
print("\ngap overlay:")
for r in gaps:
    print(f"  gap {r['gap_index']}: ({r['gamma_lo']},{r['gamma_hi']}) g={r['g']}  "
          f"meas={r['measured_min']} pred={r['predicted']} ratio={r['ratio_measured_over_predicted']}")
