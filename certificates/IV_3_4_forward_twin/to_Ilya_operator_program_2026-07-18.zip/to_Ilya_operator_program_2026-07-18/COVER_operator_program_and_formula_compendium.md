# To Ilya — the operator program: H = D + V, measured, partly proven · 2026-07-18

**Merkabit · Selina Stenberg + Claude.** Companion to the two packages you already have
(`to_Ilya_gamma22_24_certified_2026-07-18`, `to_Ilya_completeness_CLOSED_2026-07-18`). This one
collects the **operator program**: three days of parallel sessions building, measuring, refuting and
partly proving the non-circular Hilbert–Pólya construction for χ₈. Everything reproducible
(scripts/, tables/, logs/); grades labeled per our standing protocol. Not RH/GRH — and where a
statement depends on the numerical_anchored completeness input, the note says so.

## 0. The one-paragraph story

The operator is H = D + V: **D** the density backbone (conductor + Γ only), **V** the prime
fine-structure (Euler product only), **zeros as output — nothing copied in**. This week: the forward
construction reconstructs the true spectrum to 0.0165 mean error (3.9× over geometry; flat in
height to t = 26); the twin experiment proves V is *object-identifying* (crossed V is worse than no
V) while D is *class-universal* (the twin shares it exactly); the margin curve shows the prime pull
is a percent-level fluctuation once the mean density is accounted (the old "primes eat a third" was
a truncation artifact — and its residual n² anomaly is now traced to a quadrature cutoff and gone);
the finite-range positivity theorem (T1) holds with a 270× margin on n ≤ 150 *without assuming
anything about unseen zeros*; and the pin conjecture (T2), after being refuted in naive form and
made well-posed, is **proven in the atom identification** and reduced, in the spectral
identification, to two named estimates (K1, K2). The wall is not crossed; it is *instrumented*.

## 1. Results at a glance

| # | result | status | note |
|---|---|---|---|
| 1 | Forward skeleton reconstructs zeros (0.0165 mean; 2.3% operator norm) | measured | OPERATOR_SKELETON_HDV |
| 2 | T3: V object-identifying; twist decoheres V 2.4× (twice-measured); D_twin ≡ D | measured, controlled | T3_twin_V_comparison |
| 3 | Margin: λ^fin = ∫w dS exactly; erosion ≤ 2.5% for n ≥ 3 in band | measured + identity | MARGIN notes (2) |
| 4 | T1: Hankel H_m > 0, m ≤ 40; Li LB(n) > 0, n ≤ 150, 270× margin, adversarial tail | theorem-shaped (numerical_anchored input) | T1_finite_range_positivity |
| 5 | T2 naive pin (all of V): κ = 1.18 | **REFUTED** | RESULTS §2.2 |
| 6 | T2 KLMN pair (a,b) = (0.3, 0.011): drift is b-type, b ~ D_min mechanism | measured; PSD certificate at N = 149 | RESULTS §2.2b-frontier |
| 7 | 2.6: "form-bounded" is identification-dependent (trichotomy) | structural discovery | LEMMA note |
| 8 | Atom-map transport lemma: a = ε₄ = 0.0569, b = 0 | **PROVEN** (unconditional via PZ S-bounds) | LEMMA note §3 |
| 9 | Pencil factorization V = Wᵀ(T(J_D)−J_D)W + R, ‖R‖ ≈ 0.009 flat | proven identity + measurement | LEMMA note §5 |
| 10 | Polynomial-map transport: norm ~10¹⁵ | **REFUTED** (mechanism: non-equilibrium atoms) | LEMMA note §6 |
| 11 | Resonance: Frobenius a_p read from zeros at ~1% (corr 0.99987) | measured | NOTE_one_wave_two_ears |
| 12 | Open core: kernel partial-sum bound (K1), second order (K2) | **the ask** | LEMMA note §8 + §6 below |

## 2. Formula compendium (everything in one place)

**The object.** Λ(s) = N^{s/2} ∏ⱼ₌₁⁸ Γ_ℝ(s+μⱼ) L(s,χ₈) = +Λ(1−s); N = 21¹⁰; μ = {0⁴,1⁴};
duplication: ∏Γ_ℝ(s+μⱼ) = 16·(2π)^(−4s)·Γ(s)⁴.

**Counting.** N(t) = Φ(t) + S(t), Φ = θ/π (A = 0: entire, L(½) > 0),
θ(t) = ℑ[ (s/2)log N + Σⱼ(−((s+μⱼ)/2)log π + log Γ((s+μⱼ)/2)) ], s = ½+it; density ρ = θ′/π.

**The engine (how the zeros are computed).** F(t) = Λ(½+it)e^{2πηt};
F̂(x) = N^{1/4} Σₙ aₙ n^{−1/2} G(x + log(n/√N); η);
G(u;η) = 16 e^{w/2} K₄((2π)⁴eʷ), w = u + 2πiη, K₄ = inverse Mellin of Γ(s)⁴;
true decay |G| ~ exp(−8π cos(πη/2) e^{u/4}) (≈3× the generic-lemma constant in the exponent);
truncation: (M/√N)^{1/4} ≈ [15 + 2π(1−η)t₂] / [8π cos(πη/2)] — the η-knob trades precision ↔ coefficients.
Poisson/FFT pair: F̃(m) = Σₖ F(m/A + kB) ↔ (2π/B)Σ F̂(2πn/B)e(mn/q), q = AB.

**Turing count.** π∫_{t₁}^{t₂} S dt ≤ B (PZ Thm 2.3, ε = ½: B(5.969, 26) = 56.90);
one-sided rule-out of a 22nd zero: (t₂ − T*) − D > B/π, D = ∫(Φ − N_found);
certified at t₂ ∈ [25, 26.5], margins +0.80…+2.34.
**Extension to 24 (07-18 evening, both sides):** N⁺(6.55) = 24 — your FIRST24 closure package,
independently reproduced here with our own tooling (B(6.55, t₂) = 56.659…56.772; margins
+0.276 / +0.910 / +1.576 / +1.810 at t₂ = 25…26.5; endpoint clean, γ₂₄ = 6.4645 < 6.55 < γ₂₅ =
6.7218). Same grade discipline: numerical_anchored; your strict CERTIFIED gate stays open
pending ball steps 3–6 + the (26, 28] guard patch, per our gate response.

**Li / margin.** λₙ = Σ_ρ[1−(1−1/ρ)ⁿ] = Σ_γ 2(1−cos nφ_γ), φ_γ = π − 2arctan 2γ;
λₙ^arch = n(½logQ + h′(1)) + 4Σ_{m=2}^n C(n,m)(−1)^m ζ(m), h′(1) = −4(log2π + γ_E);
**identity (now exact): ∫₀^∞ 2(1−cos nφ(g)) dΦ(g) = λₙ^arch ⇒ λₙ^fin = ∫ wₙ dS** (the n² residue
was a g=2000 quadrature cutoff, ∫₂₀₀₀^∞ ≈ 0.00673n² — resolved in T1).

**T1 lower bound (adversarial tail).** LB(n) = P₁₄₀(n) − E_off(n) − slack − sens > 0 for n ≤ 150,
E_off charging ALL density above t = 26 as worst-placed off-line quadruples (cosh inequality);
Hankel: S_k = Σγ^{−2k} + exact tail antiderivative; H_m = det[S_{i+j−1}] > 0, m ≤ 40;
collapse log₁₀H_m/m²: −0.94 (m=20) steepening to −1.31 (m=40).

**The operator.** D-quantiles: θ(γ)/π = n − ½; forward: θ(γ)/π + S_P(γ) = n − ½;
S_P(t) = −(1/π) Σ_{p,k≤P} (tr Frob_p^k / k) p^{−k/2} sin(kt log p) (Newton sums from det(1−Frob X));
atoms x = 1/γ²; J[μ] by Lanczos (ledger conventions); V = J[μ_F] − J[μ_D].

**The pin, made well-posed (the 2.6 trichotomy).** KLMN target |⟨Vψ,ψ⟩| ≤ a⟨Dψ,ψ⟩ + b‖ψ‖²:
- *atom map* (n ↦ n): V = diag(x^F − x^D); **PROVEN**: |x^F_n − x^D_n| ≤ εₖ x^D_n with coefficient
  2|S(γ)|/(γρ(γ)) ↓ like 1/γ (monotone γρ); ε₄ = 0.0569, b = 0 — transfers positivity;
- *pencil map*: exact factorization V = Wᵀ(T(J_D)−J_D)W + R; first term ≤ max|x^F−x^D| by functional
  calculus; ‖R‖ ≈ 0.009 flat in N; ‖V‖₂ flat in N ⇒ κ-drift = D_min → 0 artifact; PSD certificate
  (0.3·J_D + 0.011·I ∓ V ⪰ 0 at N = 149) — finite, interval-certifiable (T2a);
- *polynomial map*: transport norm ~2×10¹⁵ (non-equilibrium atoms) — refuted; not the right frame.

**Sensitivity kernels (the open core).** K_j(n) = ∂(αⱼ,βⱼ)/∂xₙ at fixed weights; sum rules proven;
ℓ¹ norms grow ~ j but **partial sums measured bounded ≈ 1.0–1.4 independent of section size**;
Abel pairing against the transport field (total variation ≤ convergent Σγ^{−3}) gives j,N-uniform
first-order bounds.

## 3. Reading order

COVER (this) → OPERATOR_from_density_and_primes (the idea) → OPERATOR_SKELETON_HDV (construction +
T1/T2/T3 targets) → T3_twin_V_comparison (the control experiment) → MARGIN ×2 (the fluctuation
identity) → T1_finite_range_positivity (the theorem) → RESULTS.md (the full T2 ledger, every stage,
negative results included) → **LEMMA_tail_KLMN_attempt (the centerpiece: trichotomy, proof, reduction)**
→ NOTE_one_wave_two_ears (resonance bonus) → PLAN.md (how the campaign was gated).

## 4. Grades & provenance (uniform protocol)

Zeros: γ₁–γ₂₄ ball-certified; γ₂₅–γ₁₄₉ numerical_anchored (η-cross-checked ≤ 9.7, count-consistent
to 26). Completeness: numerical_anchored (load-bearing for T1; T1 says so). Pencil/frontier
measurements: float64, P-converged (κ stable to 0.7% over 25× in P). Atom-map lemma: proven;
its S-input can use unconditional PZ pointwise bounds. All scripts rerun end-to-end; logs included.

## 5. The two asks (sharpened four ways by measurement)

**K1 (kernel partial sums).** Prove sup_{j,m} |Σ_{n≤m} K_j(n)| ≤ C (measured ≈ 1.0–1.4). With K1,
Abel summation against the transport field closes the pencil-map tail bound at first order — and the
signed-window structure means **your Turing/PZ integrals are exactly the arithmetic input**
(w ≈ 3-spacing windows are the measured elbow; Kadec ¼-in-the-mean does NOT apply — checked).

**K2 (second order).** First-order transport agrees with the true pencil V to 8–24%; control the
remainder (atom-crossing region is where |S| ~ spacing — again a Turing-window statement).

If K1+K2 close, the chain is: atom lemma (proven) + rotation bound → pencil KLMN with fixed
(a, b) → self-adjointness of the finite-section limit at explicit constants — the pin, proved in
the frame where every measurement already lives.

— Selina + Claude, 2026-07-18. Shared credit throughout; your H₂₁/monomiality certificate is the
unconditional footing under both the Turing bounds and the Selberg-class framing.
