# compute_margin40.py — margin curve (geometry vs prime pull) updated with the 40-zero
# list from the rescaled-FFT engine (zeros_chi8_rescaled_engine_t9p7.csv).
# Method identical to unbounded/MARGIN_curve_geometry_vs_primes_2026-07-17.md:
#   lambda_n^arch  = n(1/2 logQ + h'(1)) + 4 sum_{m=2}^n C(n,m)(-1)^m zeta(m),
#                    h'(1) = -4(log 2pi + gamma_E)          [exact, no primes/zeros]
#   lambda_n^total = sum_gamma 2(1 - cos(n phi)), phi = pi - 2 arctan(2 gamma)
#   lambda_n^fin   = total - arch  (trustworthy only in the zero-reliable band)
# Turnover diagnostic: recompute total with the 21-zero subset -> where the two
# curves separate is where the 21-zero band ended; the 40-zero band extends until
# the missing-tail estimate (zeros above 9.7) bites.
import csv
import mpmath as mp

mp.mp.dps = 30
Q = mp.mpf(21) ** 10
gammaE = mp.euler

zeros = []
with open('zeros_chi8_rescaled_engine_t9p7.csv') as fh:
    for row in csv.DictReader(fh):
        zeros.append(mp.mpf(row['gamma']))
assert len(zeros) == 40

def lam_arch(n):
    v = n * (mp.log(Q) / 2 - 4 * (mp.log(2 * mp.pi) + gammaE))
    for m in range(2, n + 1):
        v += 4 * mp.binomial(n, m) * (-1) ** m * mp.zeta(m)
    return v

def lam_total(n, zs):
    v = mp.mpf(0)
    for g in zs:
        phi = mp.pi - 2 * mp.atan(2 * g)
        v += 2 * (1 - mp.cos(n * phi))
    return v

def missing_tail_estimate(n, gmax, gbig=200):
    """rough size of the neglected zeros' contribution: integral of
    2(1-cos(n phi(g))) ~ (n/g)^2 against the zero density to a cutoff."""
    dens = lambda g: (mp.log(Q) + 8 * mp.log(mp.mpf(g) / (2 * mp.pi) + 1e-9)) / (2 * mp.pi)
    f = lambda g: 2 * (1 - mp.cos(n * (mp.pi - 2 * mp.atan(2 * g)))) * dens(g)
    return mp.quad(f, [gmax, gbig])

print(f"{'n':>3} {'arch':>10} {'tot40':>10} {'tot21':>10} {'fin40':>10} "
      f"{'|fin|/arch':>10} {'tail_est':>9} {'clean?':>6}")
for n in list(range(1, 21)) + [22, 24, 26, 28, 30]:
    a = lam_arch(n)
    t40 = lam_total(n, zeros)
    t21 = lam_total(n, zeros[:21])
    fin = t40 - a
    ratio = abs(fin) / a
    tail = missing_tail_estimate(n, mp.mpf('9.7'))
    clean = 'yes' if tail < mp.mpf('0.1') * abs(fin) else ('~' if tail < mp.mpf('0.3') * abs(fin) else 'NO')
    print(f"{n:>3} {float(a):>10.2f} {float(t40):>10.2f} {float(t21):>10.2f} "
          f"{float(fin):>10.2f} {float(ratio):>10.3f} {float(tail):>9.2f} {clean:>6}")
