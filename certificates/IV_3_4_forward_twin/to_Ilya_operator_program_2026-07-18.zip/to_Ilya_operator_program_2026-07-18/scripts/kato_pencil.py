# kato_pencil.py — T2 stages 2.1/2.3: true form-ratio kappa_m of the pencil V psi = lambda D psi.
# D = Jacobi(density quantiles), Hfwd = Jacobi(quantiles of theta/pi + S_P), V = Hfwd - D.
# kappa_m = max |eig( L^-1 V_m L^-T )|, D_m = L L^T  (D_m pos-def: spectrum = atoms > 0).
# Usage: python kato_pencil.py <zeros.csv> [--P 200000] [--tail-drop 0] [--out kato.csv]
import sys, os, csv, argparse
import numpy as np
import mpmath as mp

HERE = os.path.dirname(os.path.abspath(__file__))
for cand in [HERE,
             os.path.join(HERE, '..', 'T3_twin_skeleton_2026-07-17'),
             os.path.join(HERE, '..', '.claude', 'worktrees',
                          'ilya-riemanns-completeness-452d5d', 'completeness_engine_2026-07-17')]:
    if os.path.exists(os.path.join(cand, 'operator_skeleton_hdv.py')):
        sys.path.insert(0, cand); break
from operator_skeleton_hdv import quantile, build_prime_data, jacobi_from_atoms

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('zeros_csv')
    ap.add_argument('--P', type=int, default=200000)
    ap.add_argument('--tail-drop', type=int, default=0,
                    help='drop the k largest atoms (smallest gammas) from sections')
    ap.add_argument('--twin', action='store_true',
                    help='use the twin local factors (chi8 x chi_{-7}, same D) for S_P')
    ap.add_argument('--out', default=None)
    a = ap.parse_args()

    local_factor = None
    if a.twin:
        from operator_skeleton_twin import twin_local_factor
        local_factor = twin_local_factor

    gam = []
    with open(a.zeros_csv) as fh:
        rd = csv.DictReader(fh)
        col = 'gamma' if 'gamma' in (rd.fieldnames or []) else rd.fieldnames[0]
        for row in rd:
            try: gam.append(float(row[col]))
            except ValueError: pass
    gam = sorted(gam)
    n_z = len(gam)
    print(f"{n_z} zeros from {a.zeros_csv}  (P={a.P}, tail_drop={a.tail_drop}, twin={a.twin})")

    S_P, nterms = build_prime_data(a.P, local_factor=local_factor)
    print(f"{nterms} prime-power terms")
    gD = [quantile(n) for n in range(1, n_z + 1)]
    gF = [quantile(n, extra=lambda g: mp.mpf(S_P(g))) for n in range(1, n_z + 1)]
    k0 = a.tail_drop
    atomsD = [1 / float(g) ** 2 for g in gD][k0:]
    atomsF = [1 / float(g) ** 2 for g in gF][k0:]

    rows = []
    for m in range(2, len(atomsD) + 1):
        JD = jacobi_from_atoms(atomsD, m)
        JF = jacobi_from_atoms(atomsF, m)
        V = JF - JD
        L = np.linalg.cholesky(JD)
        Li = np.linalg.inv(L)
        kappa = np.abs(np.linalg.eigvalsh(Li @ V @ Li.T)).max()
        rows.append((m, kappa))
    out = a.out or f"kato_table_{os.path.splitext(os.path.basename(a.zeros_csv))[0]}.csv"
    with open(out, 'w', newline='') as fh:
        w = csv.writer(fh); w.writerow(['m', 'kappa'])
        w.writerows(rows)
    ks = [k for _, k in rows]
    print(f"kappa_m: min {min(ks):.4f}  max {max(ks):.4f}  last(m={rows[-1][0]}) {rows[-1][1]:.4f}")
    for m, k in rows:
        if m in (2, 5, 10, 15, 20, 25, 30, 40, 60, 100, rows[-1][0]):
            print(f"  m={m:>3}  kappa = {k:.4f}   {'<1 OK' if k < 1 else '>=1  **'}")
    print(f"table -> {out}")

if __name__ == '__main__':
    main()
