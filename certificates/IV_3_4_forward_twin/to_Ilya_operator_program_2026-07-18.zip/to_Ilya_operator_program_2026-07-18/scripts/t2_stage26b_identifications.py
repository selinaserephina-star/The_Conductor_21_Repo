# t2_stage26b_identifications.py — stage 2.6 second pass: the three identifications.
#
# Finding of pass 1 (t2_stage26_lemma_verify.py): the basis-free (same-polynomial) form
# explodes at full degree (Lagrange amplification ||E||_2 ~ 1e15, real, mpmath-validated).
# Low-degree numbers in pass 1 were contaminated by that ill-conditioning; here every
# polynomial value is computed by the STABLE three-term recurrence (validated degree range).
#
# Objects measured, per tail section (drop k, prefix N, M = N-k atoms):
#  (I)   atom-map identification:  V_atom = diag(x^F - x^D); KLMN trivial, a = eps_k.
#  (II)  Jacobi/Lanczos identification (the pencil): V = J(mu_F) - J(mu_D);
#        - ||V||_2 and the tridiagonal row bound max_j(|da_j|+|db_{j-1}|+|db_j|) vs N
#        - da_j, db_j profiles (the object a future lemma must control)
#  (III) polynomial identification, degree-filtered with STABLE evaluation:
#        kappa_Q(d, btilde), eta(d, btilde); the crossing degree d_c where kappa_Q > 1.
#
# Plus: window averages of S_P restricted to the tail (n >= k+1), and the counting-
# transport identity check with a recurrence-evaluated test polynomial.
import os, sys, csv
import numpy as np
import mpmath as mp

HERE = os.path.dirname(os.path.abspath(__file__))
for cand in [HERE, os.path.join(HERE, '..', 'completeness_engine_2026-07-17'),
             os.path.join(HERE, '..', 'T3_twin_skeleton_2026-07-17')]:
    if os.path.exists(os.path.join(cand, 'operator_skeleton_hdv.py')):
        sys.path.insert(0, cand); break
from operator_skeleton_hdv import theta, build_prime_data, jacobi_from_atoms

P_CUT = 200000
DROPS = [1, 4]
PREFIXES = [60, 100, 149]

gD_all, gF_all = [], []
with open(os.path.join(HERE, 'quantiles_production.csv')) as fh:
    for row in csv.DictReader(fh):
        gD_all.append(float(row['gamma_D'])); gF_all.append(float(row['gamma_fwd']))
gD_all = np.array(gD_all); gF_all = np.array(gF_all)
NALL = len(gD_all)
S_P, nterms = build_prime_data(P_CUT)
print(f"ladder {NALL}, {nterms} prime-power terms")

_rc = {}
def rho(t):
    t = float(t)
    if t not in _rc: _rc[t] = float(mp.diff(theta, mp.mpf(t)) / mp.pi)
    return _rc[t]

def lanczos_full(atoms):
    x = np.asarray(atoms, float); M = len(x)
    v = np.ones(M) / np.sqrt(M)
    al, be, Vs = [], [], [v]
    w = x * v; a0 = v @ w; al.append(a0); w = w - a0 * v
    for j in range(1, M):
        b = np.linalg.norm(w)
        if b < 1e-14: break
        be.append(b)
        vn = w / b
        for u in Vs: vn = vn - (u @ vn) * u
        vn /= np.linalg.norm(vn)
        Vs.append(vn)
        w = x * vn - b * Vs[-2]
        a = vn @ w; al.append(a); w = w - a * vn
    return np.array(al), np.array(be), np.array(Vs)

def op_eval(al, be, y, dmax):
    """orthonormal polys P_0..P_dmax at points y via the three-term recurrence."""
    y = np.asarray(y, float)
    P = np.zeros((dmax + 1, len(y)))
    P[0] = 1.0
    if dmax >= 1:
        P[1] = (y - al[0]) / be[0]
    for j in range(1, dmax):
        P[j + 1] = ((y - al[j]) * P[j] - be[j - 1] * P[j - 1]) / be[j]
    return P

# ---------- [A] window averages of S_P restricted to the tail ----------
print("\n== [A] signed window averages of S_P over TAIL windows only ==")
grid = np.arange(0.30, 30.0, 0.001)
Sg = np.empty_like(grid)
for i in range(0, len(grid), 2000):
    Sg[i:i + 2000] = [S_P(t) for t in grid[i:i + 2000]]
Fsig = np.concatenate([[0.0], np.cumsum((Sg[1:] + Sg[:-1]) / 2 * np.diff(grid))])
def win_avg(a, b):
    ia, ib = np.interp([max(a, grid[0]), min(b, grid[-1])], grid, Fsig)
    return (ib - ia) / (b - a)
rho_lad = np.array([rho(g) for g in gD_all])
for k in DROPS:
    line = f"   k={k} (n>={k+1}, t>={gD_all[k]:.2f}): "
    for w in (1.0, 3.0, 5.0, 10.0):
        As = max(abs(win_avg(gD_all[n] - w / (2 * rho_lad[n]), gD_all[n] + w / (2 * rho_lad[n])))
                 for n in range(k, NALL))
        line += f" A{w:g}={As:.3f}"
    sup_tail = np.abs(Sg[grid >= gD_all[k] - 0.3]).max()
    print(line + f"   sup|S_P| on range = {sup_tail:.3f}")

# ---------- [B] the three identifications ----------
sum_rows = []
print("\n== [B] identifications I (atom map) and II (Jacobi map) per section ==")
for k in DROPS:
    for N in PREFIXES:
        gD = gD_all[k:N]; gF = gF_all[k:N]; M = N - k
        xD = 1.0 / gD ** 2; xF = 1.0 / gF ** 2
        eps_k = np.max(np.abs(xF - xD) / xD)      # atom map: |<V_atom psi,psi>| <= eps <D psi,psi>
        eps_kF = np.max(np.abs(xF - xD) / xF)
        alD, beD, VsD = lanczos_full(xD)
        alF, beF, VsF = lanczos_full(xF)
        JD = np.diag(alD) + np.diag(beD, 1) + np.diag(beD, -1)
        JF = np.diag(alF) + np.diag(beF, 1) + np.diag(beF, -1)
        V = JF - JD
        da = alF - alD; db = beF - beD
        normV = np.linalg.norm(V, 2)
        rowb = max(abs(da[j]) + (abs(db[j - 1]) if j > 0 else 0) + (abs(db[j]) if j < M - 1 else 0)
                   for j in range(M))
        L = np.linalg.cholesky(JD); Li = np.linalg.inv(L)
        kap = np.abs(np.linalg.eigvalsh(Li @ V @ Li.T)).max()
        # KLMN frontier point at a=0: b = ||V||; at measured a: b_needed via bisection
        Dmin = xD.min()
        print(f"   k={k} N={N:>3}: eps_atom={eps_k:.4f}  kappa_pencil={kap:.4f}  "
              f"||V||_2={normV:.4f}  rowbound={rowb:.4f}  D_min={Dmin:.5f}")
        sum_rows.append((k, N, eps_k, eps_kF, kap, normV, rowb, Dmin))
        if N == PREFIXES[-1]:
            j5 = min(5, M); jm = M // 2
            print(f"      |da_j|: first5 max {np.abs(da[:j5]).max():.4f}, "
                  f"mid {np.abs(da[jm-2:jm+3]).max():.4f}, last5 max {np.abs(da[-5:]).max():.4f}")
            print(f"      |db_j|: first5 max {np.abs(db[:j5]).max():.4f}, "
                  f"mid {np.abs(db[jm-2:jm+3]).max():.4f}, last5 max {np.abs(db[-5:]).max():.4f}")
            arg = int(np.abs(da).argmax())
            print(f"      argmax|da_j| = {arg} of {M-1}; argmax|db_j| = {int(np.abs(db).argmax())} of {M-2}")

with open(os.path.join(HERE, 't2_stage26b_identifications.csv'), 'w', newline='') as fh:
    w = csv.writer(fh)
    w.writerow(['k', 'N', 'eps_atom_vsD', 'eps_atom_vsF', 'kappa_pencil',
                'normV_2', 'V_rowbound', 'D_min'])
    w.writerows(sum_rows)

# ---------- [C] identification III: degree-filtered basis-free form, STABLE eval ----------
print("\n== [C] polynomial identification, stable recurrence eval: kappa_Q(d, btilde) ==")
deg_rows = []
for k in DROPS:
    N = PREFIXES[-1]
    gD = gD_all[k:N]; gF = gF_all[k:N]; M = N - k
    xD = 1.0 / gD ** 2; xF = 1.0 / gF ** 2
    alD, beD, VsD = lanczos_full(xD)
    PD_lan = np.sqrt(M) * VsD
    dmax_try = M - 1
    PD_rec = op_eval(alD, beD, xD, dmax_try)
    relerr = np.array([np.abs(PD_rec[j] - PD_lan[j]).max() /
                       max(np.abs(PD_lan[j]).max(), 1e-30) for j in range(len(PD_lan))])
    d_stable = int(np.argmax(relerr > 1e-8) - 1) if np.any(relerr > 1e-8) else dmax_try
    print(f"\n   k={k}: recurrence-vs-Lanczos rel err: d_stable(1e-8) = {d_stable} of {dmax_try}")
    PF = op_eval(alD, beD, xF, min(d_stable, dmax_try))
    PD = PD_rec[:d_stable + 1]
    d_c = {}
    for bt in (0.0, 0.01, 0.1):
        prev_ok = None
        for d in [0, 1, 2, 3, 5, 8, 10, 15, 20, 30, 40, 60, 80, 100, 120, d_stable]:
            if d > d_stable: continue
            Pd = PD[:d + 1]; Pf = PF[:d + 1]
            A_D = (Pd * xD[None, :]) @ Pd.T / M
            A_H = (Pf * xF[None, :]) @ Pf.T / M
            dP = Pf - Pd
            Wd = (dP * xD[None, :]) @ dP.T / M
            G = Pd @ Pd.T / M
            Bmat = A_D + bt * G
            Lb = np.linalg.cholesky(Bmat); Lbi = np.linalg.inv(Lb)
            kQd = np.abs(np.linalg.eigvalsh(Lbi @ (A_H - A_D) @ Lbi.T)).max()
            etad = np.sqrt(max(np.abs(np.linalg.eigvalsh(Lbi @ Wd @ Lbi.T)).max(), 0.0))
            deg_rows.append((k, bt, d, kQd, etad))
            if bt not in d_c and kQd >= 1.0: d_c[bt] = d
            if d in (0, 1, 2, 3, 5, 10, 20, 40, 80, 120, d_stable):
                print(f"      bt={bt:5.2f} d={d:>3}: kappa_Q={kQd:12.4f}  eta={etad:12.4f}")
    print(f"   k={k}: first tested d with kappa_Q >= 1:  " +
          ", ".join(f"btilde={b}: d_c={d}" for b, d in d_c.items()))

with open(os.path.join(HERE, 't2_stage26b_degree_table.csv'), 'w', newline='') as fh:
    w = csv.writer(fh)
    w.writerow(['k', 'btilde', 'd', 'kappa_Q_d', 'eta_d'])
    w.writerows(deg_rows)

# ---------- [D] counting-transport identity, recurrence-evaluated test polynomial ----------
print("\n== [D] counting-function transport identity (recurrence p, deg 10) ==")
k, N = 4, 60
gD = gD_all[k:N]; gF = gF_all[k:N]; M = N - k
xD = 1.0 / gD ** 2; xF = 1.0 / gF ** 2
alD, beD, _ = lanczos_full(xD)
coef = np.zeros(11); coef[10] = 1.0; coef[3] = 0.5
def pval(y):
    P = op_eval(alD, beD, np.atleast_1d(y), 10)
    return coef @ P
def gfun(t):
    return float(pval(1.0 / t ** 2)[0] ** 2 / t ** 2)
lhs = float(np.sum(pval(xF) ** 2 * xF - pval(xD) ** 2 * xD))
jumps = sorted([(g, +1) for g in gF] + [(g, -1) for g in gD])
rhs, dN, tprev = 0.0, 0, jumps[0][0] - 0.05
for t1, sgn in jumps:
    if dN != 0:
        rhs += -dN * (gfun(t1) - gfun(tprev))
    dN += sgn; tprev = t1
print(f"   LHS (sum of f-transport, f=x p^2)      = {lhs:.6e}")
print(f"   RHS (-int g' dDeltaN, piecewise exact) = {rhs:.6e}   rel diff = {abs(rhs-lhs)/abs(lhs):.1e}")
print("\ndone.")
