# window_norm_knee.py — stage 2.5/2.6 pre-lemma numerics (skeleton session, 2026-07-18).
#
# Question (J3(O)-motivated): the S-norm lemma wants  form-bound(V) <= C * ||S||*_w  with
# ||S||*_w a windowed-average norm of S (window w mean zero-spacings).  The octonion frame
# nominates w = 3 (one J3(O) block).  Before any lemma exists we can measure the empirical
# constant  C_needed(w) = kappa / A_w  where
#   kappa = pencil form-ratio max|eig(L^-1 V L^-T)|  (T2 instrument, kato_pencil.py),
#   A_w   = max_n (1/|I_n|) int_{I_n} |S_P(t)| dt,  I_n = window of w spacings at quantile n
#   (w = 0 means pointwise: max_n |S_P(gamma_n^D)|).
# A knee in C_needed(w) at w ~ 3 would say: 3-spacing averages are the coarsest S-data that
# still controls the form bound — sharpening the question for IB.
#
# Also delivers the stage-2.5 check: V^lin (transport delta_n = -S/rho at density quantiles)
# vs the true V = J(Hfwd) - J(D), entrywise and in the pencil.
#
# Zeros are used NOWHERE here — everything is geometry + Euler side (n_max fixed at 40 to
# match the T2 tables).
import os, sys, csv
import numpy as np
import mpmath as mp

HERE = os.path.dirname(os.path.abspath(__file__))
for cand in [HERE,
             os.path.join(HERE, '..', 'T3_twin_skeleton_2026-07-17'),
             os.path.join(HERE, '..', 'completeness_engine_2026-07-17')]:
    if os.path.exists(os.path.join(cand, 'operator_skeleton_hdv.py')):
        sys.path.insert(0, cand); break
from operator_skeleton_hdv import theta, quantile, build_prime_data, jacobi_from_atoms

N_MAX = 40
P_CUT = 200000
WINDOWS = [0.25, 0.5, 1.0, 2.0, 3.0, 4.0, 5.0, 7.0, 10.0]
DROPS = [0, 4]          # full and the tail object (T2 synthesis: the tail is the burden)

def pencil_kappa(V, D):
    L = np.linalg.cholesky(D)
    Li = np.linalg.inv(L)
    return np.abs(np.linalg.eigvalsh(Li @ V @ Li.T)).max()

def main():
    print(f"== window-knee test: n_max={N_MAX}, P={P_CUT}, windows={WINDOWS}, drops={DROPS} ==")
    S_P, nterms = build_prime_data(P_CUT)
    print(f"   {nterms} prime-power terms")

    gD = [quantile(n) for n in range(1, N_MAX + 1)]
    gF = [quantile(n, extra=lambda g: mp.mpf(S_P(g))) for n in range(1, N_MAX + 1)]
    rho = [float(mp.diff(theta, g) / mp.pi) for g in gD]
    gDf = np.array([float(g) for g in gD]); gFf = np.array([float(g) for g in gF])

    # ---- stage 2.5: linearized transport vs true forward quantiles ----
    Svals = np.array([S_P(g) for g in gDf])
    delta = -Svals / np.array(rho)
    gLin = gDf + delta
    qerr = np.abs(gLin - gFf)
    print(f"\n== stage 2.5 check: linearized quantiles vs true Hfwd quantiles ==")
    print(f"   max|gamma_lin - gamma_fwd| = {qerr.max():.2e}   mean = {qerr.mean():.2e}"
          f"   (mean shift scale {np.abs(delta).mean():.3f})")

    atomsD = 1.0 / gDf ** 2
    atomsF = 1.0 / gFf ** 2
    atomsL = 1.0 / gLin ** 2

    # ---- S on a grid + cumulative integral of |S| ----
    tmax = gDf[-1] + 1.2 / rho[-1] * (max(WINDOWS) / 2 + 1)
    grid = np.arange(0.0, tmax, 0.001)
    Sg = np.empty_like(grid)
    for i in range(0, len(grid), 1000):
        blk = grid[i:i + 1000]
        Sg[i:i + 1000] = [S_P(t) for t in blk]
    F = np.concatenate([[0.0], np.cumsum((np.abs(Sg[1:]) + np.abs(Sg[:-1])) / 2 * np.diff(grid))])
    def avg_absS(a, b):
        a = max(a, grid[0]); b = min(b, grid[-1])
        ia, ib = np.interp([a, b], grid, F)
        return (ib - ia) / (b - a)

    # ---- the C(w) table ----
    print(f"\n== empirical C_needed(w) = kappa / A_w  (m = {N_MAX} sections) ==")
    out_rows = []
    for k0 in DROPS:
        D = jacobi_from_atoms(list(atomsD[k0:]), N_MAX - k0)
        kapV = pencil_kappa(jacobi_from_atoms(list(atomsF[k0:]), N_MAX - k0) - D, D)
        kapL = pencil_kappa(jacobi_from_atoms(list(atomsL[k0:]), N_MAX - k0) - D, D)
        print(f"\n   tail_drop={k0}:  kappa(V) = {kapV:.4f}   kappa(V^lin) = {kapL:.4f}"
              f"   [pencil agreement {abs(kapV-kapL)/kapV:.1%}]")
        ns = range(k0, N_MAX)
        A0 = max(abs(Svals[n]) for n in ns)
        print(f"   {'w':>6} {'A_w':>8} {'C=kapV/A_w':>11} {'C_lin':>8}")
        print(f"   {'pt':>6} {A0:8.4f} {kapV/A0:11.3f} {kapL/A0:8.3f}")
        out_rows.append((k0, 0.0, A0, kapV / A0, kapL / A0))
        for w in WINDOWS:
            Aw = max(avg_absS(gDf[n] - w / (2 * rho[n]), gDf[n] + w / (2 * rho[n])) for n in ns)
            print(f"   {w:6.2f} {Aw:8.4f} {kapV/Aw:11.3f} {kapL/Aw:8.3f}")
            out_rows.append((k0, w, Aw, kapV / Aw, kapL / Aw))

    with open(os.path.join(HERE, 'window_knee_table.csv'), 'w', newline='') as fh:
        wcsv = csv.writer(fh)
        wcsv.writerow(['tail_drop', 'w_spacings', 'A_w', 'C_needed_V', 'C_needed_Vlin'])
        wcsv.writerows(out_rows)
    print("\n   table -> window_knee_table.csv")

if __name__ == '__main__':
    main()
