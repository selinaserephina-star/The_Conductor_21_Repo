# t2_stage22b_frontier.py — T2 stage 2.2b-frontier: is the kappa_tail(N) drift a-type or b-type?
# KLMN allows <V psi,psi> <= a <D psi,psi> + b ||psi||^2.  For each prefix N of the production
# quantile ladder and each drop-k tail section, compute the frontier
#     a(b) = max( lam_max(L^-1 (V - bI) L^-T), lam_max(L^-1 (-V - bI) L^-T) )
# (two-sided: KLMN needs |<V psi,psi>| bounded; b subtracted in the ORIGINAL coordinates,
#  i.e. before the Cholesky reduction D = L L^T).  Both branches are monotone decreasing in b,
# so b_needed(a_target) is found by bisection.  Verdict object: does a(b*) at fixed moderate b*
# stop drifting with N (b-type, absorbable) or keep the drift of a(0)=kappa (a-type, bad)?
# Usage: python t2_stage22b_frontier.py  (reads quantiles_production.csv in this folder)
import os, sys, csv
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
for cand in [HERE, os.path.join(HERE, '..', 'T3_twin_skeleton_2026-07-17')]:
    if os.path.exists(os.path.join(cand, 'operator_skeleton_hdv.py')):
        sys.path.insert(0, cand); break
from operator_skeleton_hdv import jacobi_from_atoms

QUANT = os.path.join(HERE, 'quantiles_production.csv')
PREFIXES = [40, 60, 80, 100, 120, 140, 149]
DROPS = [1, 4]
B_GRID = [0.0, 0.001, 0.002, 0.005, 0.01, 0.02, 0.03, 0.05, 0.075,
          0.1, 0.15, 0.2, 0.3, 0.5, 0.75, 1.0]
A_TARGETS = [0.3, 0.5]

def load_quantiles(path):
    gD, gF = [], []
    with open(path) as fh:
        for row in csv.DictReader(fh):
            gD.append(float(row['gamma_D'])); gF.append(float(row['gamma_fwd']))
    return np.array(gD), np.array(gF)

def pencil_pieces(gD, gF, N, k):
    atomsD = (1.0 / gD[:N] ** 2)[k:]
    atomsF = (1.0 / gF[:N] ** 2)[k:]
    m = len(atomsD)
    JD = jacobi_from_atoms(atomsD, m)
    JF = jacobi_from_atoms(atomsF, m)
    V = JF - JD
    L = np.linalg.cholesky(JD)
    Li = np.linalg.inv(L)
    return V, Li, m

def a_of_b(V, Li, b):
    I = np.eye(V.shape[0])
    lp = np.linalg.eigvalsh(Li @ (V - b * I) @ Li.T).max()
    lm = np.linalg.eigvalsh(Li @ (-V - b * I) @ Li.T).max()
    return max(lp, lm), ('+' if lp >= lm else '-')

def b_needed(V, Li, a_target, b_hi=4.0, tol=1e-6):
    a0, _ = a_of_b(V, Li, 0.0)
    if a0 <= a_target:
        return 0.0
    lo, hi = 0.0, b_hi
    while a_of_b(V, Li, hi)[0] > a_target:
        hi *= 2
        if hi > 1e4: return float('inf')
    while hi - lo > tol:
        mid = 0.5 * (lo + hi)
        if a_of_b(V, Li, mid)[0] > a_target: lo = mid
        else: hi = mid
    return 0.5 * (lo + hi)

def main():
    gD, gF = load_quantiles(QUANT)
    print(f"{len(gD)} quantiles from {os.path.basename(QUANT)}")
    curve_rows, need_rows = [], []
    for k in DROPS:
        for N in PREFIXES:
            V, Li, m = pencil_pieces(gD, gF, N, k)
            kap, br0 = a_of_b(V, Li, 0.0)
            Dmin = 1.0 / gD[N - 1] ** 2   # smallest atom in the section
            line = [f"drop{k} N={N:>3} (m={m:>3})  kappa={kap:.4f}[{br0}]  D_min={Dmin:.5f} "]
            for b in B_GRID:
                a, br = a_of_b(V, Li, b)
                curve_rows.append((k, N, m, b, a, br))
            needs = []
            for at in A_TARGETS:
                bn = b_needed(V, Li, at)
                need_rows.append((k, N, m, at, bn))
                needs.append(f"b_needed(a={at})={bn:.5f}")
            print(line[0] + '  '.join(needs))
    with open(os.path.join(HERE, 'frontier_ab_curves.csv'), 'w', newline='') as fh:
        w = csv.writer(fh); w.writerow(['drop', 'N', 'm', 'b', 'a', 'branch'])
        w.writerows(curve_rows)
    with open(os.path.join(HERE, 'frontier_b_needed.csv'), 'w', newline='') as fh:
        w = csv.writer(fh); w.writerow(['drop', 'N', 'm', 'a_target', 'b_needed'])
        w.writerows(need_rows)

    # drift check at fixed moderate b, and log-N fits of b_needed
    print("\n--- a(b*) drift across N at fixed b* ---")
    for k in DROPS:
        for bstar in [0.01, 0.03, 0.1]:
            vals = [a for (kk, N, m, b, a, br) in curve_rows if kk == k and abs(b - bstar) < 1e-12]
            Ns = [N for (kk, N, m, b, a, br) in curve_rows if kk == k and abs(b - bstar) < 1e-12]
            slope = np.polyfit(np.log(Ns), vals, 1)[0]
            print(f" drop{k} b*={bstar:<5}: a = " +
                  ' '.join(f"{v:.4f}" for v in vals) + f"   slope/e-fold = {slope:+.4f}")
    print("\n--- b_needed(N) fits (vs log N) ---")
    for k in DROPS:
        for at in A_TARGETS:
            pts = [(N, bn) for (kk, N, m, a, bn) in need_rows if kk == k and a == at]
            Ns = np.array([p[0] for p in pts]); bs = np.array([p[1] for p in pts])
            if np.all(bs == 0):
                print(f" drop{k} a={at}: b_needed = 0 for all N"); continue
            c1, c0 = np.polyfit(np.log(Ns), bs, 1)
            print(f" drop{k} a={at}: b_needed = " + ' '.join(f"{b:.5f}" for b in bs) +
                  f"   fit b = {c0:+.5f} {c1:+.5f}*logN  (slope/e-fold {c1:+.5f})")
    print("\ntables -> frontier_ab_curves.csv, frontier_b_needed.csv")

if __name__ == '__main__':
    main()
