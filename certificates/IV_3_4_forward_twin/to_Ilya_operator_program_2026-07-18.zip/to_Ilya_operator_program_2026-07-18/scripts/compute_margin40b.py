# compute_margin40b.py — margin curve with mean-density tail correction.
#   lambda_n^total(corrected) = partial sum over known zeros (<= gmax)
#                             + int_{gmax}^inf 2(1-cos(n phi(g))) dens(g) dg
# dens(g) = theta'(g)/pi (exact smooth density for chi8; fluctuation neglected).
# Internal validation: the corrected curve from the 21-zero set (gmax=5.9695)
# must agree with the corrected curve from the 40-zero set (gmax=9.7).
import csv
import mpmath as mp

mp.mp.dps = 25
Q = mp.mpf(21) ** 10
gammaE = mp.euler
LOGQ = mp.log(Q)
MU = [0, 0, 0, 0, 1, 1, 1, 1]

def theta(t):
    s = mp.mpf('0.5') + 1j * t
    v = (s / 2) * LOGQ
    for m in MU:
        v += -((s + m) / 2) * mp.log(mp.pi) + mp.loggamma((s + m) / 2)
    return mp.im(v)

def dens(g):
    return mp.diff(theta, g) / mp.pi

zeros = []
with open('zeros_chi8_rescaled_engine_t9p7.csv') as fh:
    for row in csv.DictReader(fh):
        zeros.append(mp.mpf(row['gamma']))

def lam_arch(n):
    v = n * (LOGQ / 2 - 4 * (mp.log(2 * mp.pi) + gammaE))
    for m in range(2, n + 1):
        v += 4 * mp.binomial(n, m) * (-1) ** m * mp.zeta(m)
    return v

def lam_partial(n, zs):
    return sum(2 * (1 - mp.cos(n * (mp.pi - 2 * mp.atan(2 * g)))) for g in zs)

def tail(n, gmax):
    f = lambda g: 2 * (1 - mp.cos(n * (mp.pi - 2 * mp.atan(2 * g)))) * dens(g)
    return mp.quad(f, [gmax, gmax * 4, gmax * 20, mp.mpf(2000)])

print(f"{'n':>3} {'arch':>9} {'tot40+tail':>10} {'tot21+tail':>10} {'agree%':>7} "
      f"{'fin(corr)':>10} {'ratio(corr)':>11}")
for n in list(range(1, 17)) + [18, 20, 22, 25]:
    a = lam_arch(n)
    c40 = lam_partial(n, zeros) + tail(n, mp.mpf('9.7'))
    c21 = lam_partial(n, zeros[:21]) + tail(n, mp.mpf('5.9695'))
    fin = c40 - a
    agree = 100 * abs(c40 - c21) / c40
    print(f"{n:>3} {float(a):>9.2f} {float(c40):>10.2f} {float(c21):>10.2f} "
          f"{float(agree):>6.2f}% {float(fin):>10.2f} {float(abs(fin)/a):>11.3f}")
