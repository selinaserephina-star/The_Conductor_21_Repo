# t2_stage22_production.py — Stage 2.2: the production-scale run (skeleton session, 2026-07-18).
# Zero list: to_Ilya_completeness_CLOSED_2026-07-18/zeros/zeros_found.csv (149 zeros to t=28;
# complete to t = 26 per the verdict's honest-scope note — ~4 guard-dropped zeros in (26, 28]).
# Zeros enter ONLY as (a) section count and (b) fwd-vs-true validation truth on the complete range.
# Computes ONCE the D- and Hfwd-quantile ladders n = 1..N, then:
#   1. kappa_m curves for tail_drop in {0, 1, 2, 4}  (kato_table_production_drop{k}.csv)
#   2. skeleton fwd-vs-true at scale (mean |gamma_fwd - gamma_true|, n <= complete range)
#   3. window-knee C(w) table at m = N (window_knee_production.csv)
import os, sys, csv, time
import numpy as np
import mpmath as mp

HERE = os.path.dirname(os.path.abspath(__file__))
ENG = os.path.join(HERE, '..', 'completeness_engine_2026-07-17')
sys.path.insert(0, ENG)
from operator_skeleton_hdv import theta, quantile, build_prime_data, jacobi_from_atoms

ZCSV = os.path.join(HERE, '..', 'to_Ilya_completeness_CLOSED_2026-07-18', 'zeros', 'zeros_found.csv')
T_COMPLETE = 26.0
P_CUT = 200000
DROPS = [0, 1, 2, 4]
WINDOWS = [0.5, 1.0, 2.0, 3.0, 4.0, 5.0, 7.0, 10.0, 15.0]

def pencil_kappa(V, D):
    L = np.linalg.cholesky(D)
    Li = np.linalg.inv(L)
    return np.abs(np.linalg.eigvalsh(Li @ V @ Li.T)).max()

def main():
    t0 = time.time()
    gam = sorted(float(r['gamma']) for r in csv.DictReader(open(ZCSV)))
    N = len(gam)
    n_comp = sum(1 for g in gam if g <= T_COMPLETE)
    print(f"{N} production zeros (complete to t={T_COMPLETE}: first {n_comp})", flush=True)

    S_P, nterms = build_prime_data(P_CUT)
    print(f"{nterms} prime-power terms", flush=True)

    gD, gF = [], []
    for n in range(1, N + 1):
        gD.append(float(quantile(n)))
        gF.append(float(quantile(n, extra=lambda g: mp.mpf(S_P(g)))))
        if n % 25 == 0:
            print(f"  quantiles {n}/{N}  ({time.time()-t0:.0f}s)", flush=True)
    gD = np.array(gD); gF = np.array(gF)
    np.savetxt(os.path.join(HERE, 'quantiles_production.csv'),
               np.column_stack([np.arange(1, N + 1), gD, gF]),
               header='n,gamma_D,gamma_fwd', delimiter=',', comments='')

    # ---- 2. skeleton fwd-vs-true at scale (complete range only) ----
    gt = np.array(gam[:n_comp])
    eD = np.abs(gD[:n_comp] - gt); eF = np.abs(gF[:n_comp] - gt)
    print(f"\n== skeleton at scale: n = 1..{n_comp} (complete range) ==", flush=True)
    print(f"   mean|gamma_D - true| = {eD.mean():.4f}   mean|gamma_fwd - true| = {eF.mean():.4f}"
          f"   improvement {eD.mean()/eF.mean():.1f}x")
    print(f"   by height: n 1-40: {eF[:40].mean():.4f}   41-90: {eF[40:90].mean():.4f}"
          f"   91-{n_comp}: {eF[90:].mean():.4f}")

    # ---- 1. kappa_m curves, all drops, one quantile ladder ----
    print(f"\n== kappa_m curves (production, m up to {N}) ==", flush=True)
    for k0 in DROPS:
        aD = list(1.0 / gD[k0:] ** 2); aF = list(1.0 / gF[k0:] ** 2)
        rows = []
        for m in range(2, len(aD) + 1):
            JD = jacobi_from_atoms(aD, m)
            V = jacobi_from_atoms(aF, m) - JD
            rows.append((m, pencil_kappa(V, JD)))
        with open(os.path.join(HERE, f'kato_table_production_drop{k0}.csv'), 'w', newline='') as fh:
            w = csv.writer(fh); w.writerow(['m', 'kappa']); w.writerows(rows)
        ks = dict(rows)
        pick = [m for m in (10, 20, 40, 60, 80, 100, 120, rows[-1][0]) if m in ks]
        print(f"   drop={k0}: " + "  ".join(f"m={m}:{ks[m]:.4f}" for m in pick)
              + f"   {'FLAT/OK' if max(ks.values()) < 1 else '**>=1**'}", flush=True)

    # ---- 3. window-knee at scale ----
    print(f"\n== window-knee at production scale (m = {N}) ==", flush=True)
    rho = np.array([float(mp.diff(theta, g) / mp.pi) for g in gD])
    tmax = gD[-1] + (max(WINDOWS) / 2 + 1) / rho[-1]
    grid = np.arange(0.0, tmax, 0.002)
    Sg = np.array([S_P(t) for t in grid])
    F = np.concatenate([[0.0], np.cumsum((np.abs(Sg[1:]) + np.abs(Sg[:-1])) / 2 * np.diff(grid))])
    def avg_absS(a, b):
        a = max(a, grid[0]); b = min(b, grid[-1])
        ia, ib = np.interp([a, b], grid, F)
        return (ib - ia) / (b - a)
    Sq = np.array([S_P(g) for g in gD])
    with open(os.path.join(HERE, 'window_knee_production.csv'), 'w', newline='') as fh:
        wcsv = csv.writer(fh)
        wcsv.writerow(['tail_drop', 'w_spacings', 'A_w', 'C_needed'])
        for k0 in (0, 4):
            D = jacobi_from_atoms(list(1.0 / gD[k0:] ** 2), N - k0)
            kap = pencil_kappa(jacobi_from_atoms(list(1.0 / gF[k0:] ** 2), N - k0) - D, D)
            ns = range(k0, N)
            A0 = max(abs(Sq[n]) for n in ns)
            print(f"   drop={k0} kappa={kap:.4f}:  pt A={A0:.3f} C={kap/A0:.3f}", flush=True)
            wcsv.writerow([k0, 0.0, f"{A0:.4f}", f"{kap/A0:.4f}"])
            for w in WINDOWS:
                Aw = max(avg_absS(gD[n] - w / (2 * rho[n]), gD[n] + w / (2 * rho[n])) for n in ns)
                print(f"      w={w:5.1f}  A_w={Aw:.4f}  C={kap/Aw:.3f}", flush=True)
                wcsv.writerow([k0, w, f"{Aw:.4f}", f"{kap/Aw:.4f}"])
    print(f"\ndone ({time.time()-t0:.0f}s)")

if __name__ == '__main__':
    main()
