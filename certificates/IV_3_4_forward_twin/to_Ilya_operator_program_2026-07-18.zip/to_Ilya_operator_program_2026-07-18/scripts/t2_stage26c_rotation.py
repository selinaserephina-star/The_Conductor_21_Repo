# t2_stage26c_rotation.py — stage 2.6 third pass: the exact factorization
#     V := J(mu_F) - J(mu_D) = W^T (T(J_D) - J_D) W  +  (W^T J_D W - J_D)
# where T is the atom map x_n^D -> x_n^F, T(J_D) = Q diag(x^F) Q^T (functional calculus,
# J_D = Q diag(x^D) Q^T), and W = the Lanczos unitary of T(J_D) w.r.t. e_0 (W e_0 = e_0).
#
# Facts checked here:
#   (i)   J(mu_F) == Tri_{e0}(T(J_D))  — the unitary-equivalence theorem, numerically
#   (ii)  ||T(J_D) - J_D|| == max_n |x_F - x_D|  (functional calculus; exact)
#   (iii) rotation term R := W^T J_D W - J_D: ||R||, and C_rot = ||V|| / max|x_F-x_D|
#   (iv)  PSD certificates: a*J_D + b*I -/+ V >= 0 for candidate KLMN pairs
#   (v)   r_j = |da_j| + |db_{j-1}| + |db_j| profile (first 10) for the note
import os, sys, csv
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
gD_all, gF_all = [], []
with open(os.path.join(HERE, 'quantiles_production.csv')) as fh:
    for row in csv.DictReader(fh):
        gD_all.append(float(row['gamma_D'])); gF_all.append(float(row['gamma_fwd']))
gD_all = np.array(gD_all); gF_all = np.array(gF_all)

def lanczos_tri(A, M, v0=None):
    """Lanczos of matrix A from v0 (default e_0) with full reorth; returns (J, W)."""
    n = A.shape[0]
    if v0 is None:
        v = np.zeros(n); v[0] = 1.0
    else:
        v = v0 / np.linalg.norm(v0)
    al, be, Vs = [], [], [v]
    w = A @ v; a0 = v @ w; al.append(a0); w = w - a0 * v
    for j in range(1, M):
        b = np.linalg.norm(w)
        if b < 1e-14: break
        be.append(b)
        vn = w / b
        for u in Vs: vn = vn - (u @ vn) * u
        vn /= np.linalg.norm(vn)
        Vs.append(vn)
        w = A @ vn - b * Vs[-2]
        a = vn @ w; al.append(a); w = w - a * vn
    J = np.diag(al) + np.diag(be, 1) + np.diag(be, -1)
    return J, np.array(Vs).T

def lanczos_atoms(x):
    """Jacobi matrix of the uniform-mass atomic measure (cyclic vector = ones/sqrt(M))."""
    x = np.asarray(x, float); M = len(x)
    return lanczos_tri(np.diag(x), M, v0=np.ones(M))[0]

print("== the rotation term, per section ==")
rows = []
for k in (1, 4):
    for N in (60, 100, 149):
        gD = gD_all[k:N]; gF = gF_all[k:N]; M = N - k
        xD = 1.0 / gD ** 2; xF = 1.0 / gF ** 2
        JD = lanczos_atoms(xD)
        JF = lanczos_atoms(xF)
        V = JF - JD
        # T(J_D) by functional calculus and its re-tridiagonalization
        ev, Q = np.linalg.eigh(JD)
        # eigenvalues come sorted ascending = xD sorted ascending; match atoms by value
        order = np.argsort(xD)
        TJD = Q @ np.diag(xF[order]) @ Q.T
        Jtri, W = lanczos_tri(TJD, M)
        thm_err = np.abs(Jtri - JF).max()
        tmax = np.abs(xF - xD).max()
        R = W.T @ JD @ W - JD
        nV = np.linalg.norm(V, 2); nR = np.linalg.norm(R, 2)
        print(f"   k={k} N={N:>3}: ||V||={nV:.4f}  max|xF-xD|={tmax:.4f}  C_rot=||V||/max={nV/tmax:.3f}"
              f"  ||R||={nR:.4f}  [thm check |Tri(T(JD))-JF|_max = {thm_err:.1e}]")
        rows.append((k, N, nV, tmax, nV / tmax, nR, thm_err))
        if N == 149:
            da = np.diag(V); db = np.diag(V, 1)
            r = [abs(da[j]) + (abs(db[j-1]) if j > 0 else 0) + (abs(db[j]) if j < M-1 else 0)
                 for j in range(min(10, M))]
            print("      r_j (j=0..9): " + " ".join(f"{v:.4f}" for v in r))
            # PSD certificates
            for (a_, b_) in [(0.3, 0.011), (0.3, 0.0001), (0.0, nV * 1.0001),
                             (0.2, 0.02), (0.1, 0.02)]:
                lam1 = np.linalg.eigvalsh(a_ * JD + b_ * np.eye(M) - V).min()
                lam2 = np.linalg.eigvalsh(a_ * JD + b_ * np.eye(M) + V).min()
                ok = 'PSD OK' if min(lam1, lam2) >= -1e-12 else 'FAILS'
                print(f"      cert (a={a_}, b={b_:.4f}): min eig (-V) {lam1:+.2e}, "
                      f"(+V) {lam2:+.2e}   {ok}")

with open(os.path.join(HERE, 't2_stage26c_rotation.csv'), 'w', newline='') as fh:
    w = csv.writer(fh)
    w.writerow(['k', 'N', 'normV', 'max_dx', 'C_rot', 'normR', 'thm_check_err'])
    w.writerows(rows)
print("table -> t2_stage26c_rotation.csv\ndone.")
