"""T1 deliverable 2 — tail-corrected Li positivity lambda_n up to n ~ 150.

Method = completeness_engine_2026-07-17/compute_margin40b.py:
  lambda_n^total(corrected) = partial sum over the certified-complete zero list
                            + int_{gmax}^inf 2(1-cos(n phi(g))) dens(g) dg
  phi(g) = pi - 2 atan(2g) = 2 atan(1/(2g)),  dens(g) = theta'(g)/pi (exact).
Zero list: the 140 zeros below t = 26 of zeros_found.csv (complete-in-range set,
completeness numerical_anchored). Internal check: same correction from the
21-certified-only list (gmax = 5.9695) — agreement % defines the truncation-safe band.

New for T1 (the theorem-shaped part): an explicit WORST-CASE bound on what zeros
above t = 26 can subtract from lambda_n, with NO reality assumption on them.
A hypothetical off-line quadruple {beta +- i t, 1-beta +- i t} contributes
  >= 4 - 2(r^n + r^{-n}) = -4(cosh(n log r) - 1),  |log r| <= delta(t) = (1/2)log(1+1/t^2)
(max over beta in [0,1]). Worst case = ALL density above 26 off-line:
  E_off(n) = int_{26}^inf 2(cosh(n delta(t)) - 1) dens(t) dt      [2 upper zeros/quadruple]
plus a count-fluctuation slack of 5 extra worst-placed zeros at t = 26.
Zero-position sensitivity: |d/dgamma 2(1-cos(n phi))| <= 2n/(gamma^2+1/4);
budgeted at delta_gamma = 1e-5 per zero (measured agreement vs certified table ~1e-9).

Lower bound: LB(n) = P140(n) - E_off(n) - slack(n) - sens(n).
LB(n) > 0  ==>  lambda_n > 0 given only (i) the 140-zero list is complete below 26
and (ii) those zeros are on the line — no assumption above t = 26 at all.
"""
import csv
from pathlib import Path
import mpmath as mp

REPO = Path(__file__).resolve().parents[2]
ZEROS_CSV = REPO / "to_Ilya_completeness_CLOSED_2026-07-18" / "zeros" / "zeros_found.csv"
OUT_CSV = Path(__file__).resolve().parent / "t1_li_positivity_results.csv"

mp.mp.dps = 30
Q = mp.mpf(21) ** 10
LOGQ = mp.log(Q)
gammaE = mp.euler
MU = [0, 0, 0, 0, 1, 1, 1, 1]
G_CUT = mp.mpf(26)
T21 = mp.mpf("5.9695")
NMAX = 150
DELTA_GAMMA = mp.mpf("1e-5")   # budgeted per-zero position error (conservative)
SLACK_ZEROS = 5                # count-fluctuation slack near t=26 (|S|<=0.7 observed)

def theta(t):
    s = mp.mpf("0.5") + 1j * t
    v = (s / 2) * LOGQ
    for m in MU:
        v += -((s + m) / 2) * mp.log(mp.pi) + mp.loggamma((s + m) / 2)
    return mp.im(v)

def dens(g):
    # theta'(g)/pi analytically: theta'(t) = Re[ logQ/2 + sum_m (psi((s+m)/2) - log pi)/2 ]
    s = mp.mpf("0.5") + 1j * g
    v = LOGQ / 2
    for m in MU:
        v += (mp.digamma((s + m) / 2) - mp.log(mp.pi)) / 2
    return mp.re(v) / mp.pi

def phi(g):
    return 2 * mp.atan(1 / (2 * g))

def lam_arch(n):
    with mp.workdps(int(0.4 * n) + 40):
        v = n * (LOGQ / 2 - 4 * (mp.log(2 * mp.pi) + gammaE))
        for m in range(2, n + 1):
            v += 4 * mp.binomial(n, m) * (-1) ** m * mp.zeta(m)
        return +v

def lam_partial(n, zs):
    return sum(2 * (1 - mp.cos(n * phi(g))) for g in zs)

def tail_nodes(n, gmax):
    """Integration nodes: one per quarter-oscillation of cos(n phi(g)), then far field."""
    nodes = [gmax]
    ktop = int(mp.floor(n * phi(gmax) / (mp.pi / 2)))
    for k in range(ktop, 0, -1):
        c = (k * mp.pi / 2) / n
        g = 1 / (2 * mp.tan(c / 2))
        if g > nodes[-1] * mp.mpf("1.000001"):
            nodes.append(g)
    for fac in [4, 20, 100, 500]:
        if gmax * fac > nodes[-1]:
            nodes.append(gmax * fac)
    nodes.append(mp.inf)
    return nodes

def tail(n, gmax):
    f = lambda g: 2 * (1 - mp.cos(n * phi(g))) * dens(g)
    return mp.quad(f, tail_nodes(n, gmax))

def delta_off(t):
    return mp.log(1 + 1 / (t * t)) / 2

def E_off(n):
    f = lambda t: 2 * (mp.cosh(n * delta_off(t)) - 1) * dens(t)
    return mp.quad(f, [G_CUT, 2 * G_CUT, 6 * G_CUT, 30 * G_CUT, mp.inf])

def main():
    zeros = []
    with open(ZEROS_CSV) as fh:
        for row in csv.DictReader(fh):
            g = mp.mpf(row["gamma"])
            if g < G_CUT:
                zeros.append(g)
    assert len(zeros) == 140, len(zeros)

    # sanity: analytic dens vs numerical derivative
    d_num = mp.diff(theta, mp.mpf("7.3")) / mp.pi
    assert abs(dens(mp.mpf("7.3")) - d_num) < mp.mpf("1e-20"), (dens(mp.mpf("7.3")), d_num)

    # predicted vs found count in [26, 27.9] (density sanity)
    pred = (theta(mp.mpf("27.9")) - theta(G_CUT)) / mp.pi
    print(f"density sanity: theta-predicted count in [26,27.9] = {float(pred):.2f} "
          f"(production list found 9, ~4 dropped by amplitude guard noted in cover)")

    sens_unit = sum(2 / (g * g + mp.mpf("0.25")) for g in zeros)  # * n * delta_gamma

    rows = []
    hdr = (f"{'n':>3} {'arch':>10} {'tot140+tail':>12} {'tot21+tail':>12} {'agree%':>8} "
           f"{'P140':>10} {'E_off':>9} {'LB':>10} {'LB>0':>5}")
    print(hdr)
    safe_edge = 0
    safe_broken = False
    for n in range(1, NMAX + 1):
        a = lam_arch(n)
        P140 = lam_partial(n, zeros)
        P21 = lam_partial(n, zeros[:21])
        t140 = tail(n, G_CUT)
        t21 = tail(n, T21)
        c140 = P140 + t140
        c21 = P21 + t21
        agree = 100 * abs(c140 - c21) / c140
        e = E_off(n)
        slack = SLACK_ZEROS * 2 * (mp.cosh(n * delta_off(G_CUT)) - 1)
        sens = n * DELTA_GAMMA * sens_unit
        lb = P140 - e - slack - sens
        if not safe_broken:
            if agree <= mp.mpf("0.5"):
                safe_edge = n
            else:
                safe_broken = True
        rows.append(dict(n=n, arch=mp.nstr(a, 10), tot140=mp.nstr(c140, 10),
                         tot21=mp.nstr(c21, 10), agree_pct=mp.nstr(agree, 4),
                         P140=mp.nstr(P140, 10), tail140=mp.nstr(t140, 8),
                         E_off=mp.nstr(e, 6), slack=mp.nstr(slack, 4),
                         sens=mp.nstr(sens, 4), LB=mp.nstr(lb, 8),
                         LB_positive=bool(lb > 0)))
        if n <= 16 or n % 10 == 0 or n in (18, 20, 22, 25):
            print(f"{n:>3} {float(a):>10.2f} {float(c140):>12.2f} {float(c21):>12.2f} "
                  f"{float(agree):>7.3f}% {float(P140):>10.2f} {float(e):>9.4f} "
                  f"{float(lb):>10.2f} {'Y' if lb > 0 else 'N':>5}")

    n_lb_ok = max(r["n"] for r in rows if r["LB_positive"])
    all_lb = all(r["LB_positive"] for r in rows)
    print(f"\nLB(n) > 0 for all n = 1..{NMAX}: {all_lb} (max verified n with LB>0: {n_lb_ok})")
    print(f"21-vs-140 agreement <= 0.5% holds for n = 1..{safe_edge} (first break after that)")
    worst = max(rows, key=lambda r: float(mp.mpf(r["agree_pct"])))
    print(f"worst agreement: {worst['agree_pct']}% at n = {worst['n']}")

    with open(OUT_CSV, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"wrote {OUT_CSV}")

if __name__ == "__main__":
    main()
