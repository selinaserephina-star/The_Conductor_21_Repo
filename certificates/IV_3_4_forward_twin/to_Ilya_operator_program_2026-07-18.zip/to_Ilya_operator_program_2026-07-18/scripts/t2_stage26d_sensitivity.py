# t2_stage26d_sensitivity.py — stage 2.6 fourth pass: the ell^1-Lipschitz constants of the
# Jacobi map at fixed weights (the proof-shaped form of the rotation bound H-ROT).
#
#   kappa_j^alpha := sum_n |d alpha_j / d x_n|,   kappa_j^beta := sum_n |d beta_j / d x_n|
#   (uniform weights 1/M; finite differences, h = 1e-7 * x_n)
#
# If kappa_j = O(1) uniformly in j and M, then |d alpha_j|, |d beta_j| <= kappa * max|dx|
# at first order, i.e. the tridiagonal row bound — hence ||V|| <= 3 kappa max|dx| — follows.
# Also: first-order prediction sum_n (xF-xD)_n * dJ/dx_n vs the measured V (linearization
# quality of V in atom shifts, in the CORRECT identification).
import os, csv
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
gD_all, gF_all = [], []
with open(os.path.join(HERE, 'quantiles_production.csv')) as fh:
    for row in csv.DictReader(fh):
        gD_all.append(float(row['gamma_D'])); gF_all.append(float(row['gamma_fwd']))
gD_all = np.array(gD_all); gF_all = np.array(gF_all)

def jacobi(x):
    x = np.asarray(x, float); M = len(x)
    v = np.ones(M) / np.sqrt(M)
    al, be, Vs = [], [], [v]
    w = x * v; a0 = v @ w; al.append(a0); w = w - a0 * v
    for j in range(1, M):
        b = np.linalg.norm(w)
        if b < 1e-14: break
        be.append(b)
        vn = w / b
        for u in Vs: vn = vn - (u @ vn) * u
        vn /= np.linalg.norm(vn)
        Vs.append(vn)
        w = x * vn - b * Vs[-2]
        a = vn @ w; al.append(a); w = w - a * vn
    return np.array(al), np.array(be)

for k, N in [(4, 60), (1, 60), (4, 100)]:
    gD = gD_all[k:N]; gF = gF_all[k:N]; M = N - k
    xD = 1.0 / gD ** 2; xF = 1.0 / gF ** 2
    al0, be0 = jacobi(xD)
    JMAX = 12
    Sal = np.zeros((JMAX + 1, M)); Sbe = np.zeros((JMAX + 1, M))
    for n in range(M):
        h = 1e-7 * xD[n]
        xp = xD.copy(); xp[n] += h
        alp, bep = jacobi(xp)
        Sal[:, n] = (alp[:JMAX + 1] - al0[:JMAX + 1]) / h
        Sbe[:, n] = (bep[:JMAX + 1] - be0[:JMAX + 1]) / h
    ka = np.abs(Sal).sum(axis=1); kb = np.abs(Sbe).sum(axis=1)
    print(f"k={k} N={N} (M={M}):")
    print("   j        : " + " ".join(f"{j:>6}" for j in range(JMAX + 1)))
    print("   kappa_a_j: " + " ".join(f"{v:6.3f}" for v in ka))
    print("   kappa_b_j: " + " ".join(f"{v:6.3f}" for v in kb))
    print(f"   max over j<=12:  kappa_alpha = {ka.max():.3f}   kappa_beta = {kb.max():.3f}")
    # first-order prediction of dalpha, dbeta from the actual shifts
    dx = xF - xD
    da_pred = Sal @ dx; db_pred = Sbe @ dx
    alF, beF = jacobi(xF)
    da_true = alF[:JMAX + 1] - al0[:JMAX + 1]
    db_true = beF[:JMAX + 1] - be0[:JMAX + 1]
    ra = np.abs(da_pred - da_true).max() / max(np.abs(da_true).max(), 1e-30)
    rb = np.abs(db_pred - db_true).max() / max(np.abs(db_true).max(), 1e-30)
    print(f"   first-order V^lin vs V (Jacobi entries, j<=12): rel err alpha {ra:.1%}, beta {rb:.1%}")
    # directional gain: |da_true| vs kappa * max|dx| (how much the ell^1 bound loses)
    print(f"   max|da_true| = {np.abs(da_true).max():.4f} vs kappa_a*max|dx| = "
          f"{ka.max() * np.abs(dx).max():.4f};  max|dx| = {np.abs(dx).max():.4f}")
    print()
print("done.")
