# t2_stage26_lemma_verify.py — stage 2.6: numerical verification of every step of the
# tail-KLMN lemma attempt (LEMMA_tail_KLMN_attempt_2026-07-18.md in unbounded/).
#
# Objects (tail section: prefix N of the production ladder, drop top k atoms, M = N-k):
#   basis-free forms on polynomials p of degree <= M-1, parametrized by their VALUES
#   v_n = p(x_n^D) at the D-atoms (a degree-(M-1) polynomial IS its M values):
#     ||p||^2 = sum v^2 / M          <D p,p> = sum x^D v^2 / M
#     q_H(p)  = sum x^F p(x^F)^2 / M          Q(p) = q_H - <D>   (the perturbation form)
#   p(x^F) = E v  with E the exact Lagrange-evaluation (barycentric) matrix D-atoms -> F-atoms.
#
# Lemma chain measured here:
#   Q = T1 + T2 (exact),  T1 = sum (x^F-x^D) p(x^F)^2/M,  T2 = sum x^D [p(x^F)^2-p(x^D)^2]/M
#   |T1| <= eps * q_H            eps = max_n |x^F/x^D ratio - 1|-type  (PROVABLE, coeff 2|S|/(g rho))
#   |T2| <= (2 eta + eta^2)(<D> + btilde ||p||^2)   with eta = eta(btilde) the oscillation
#          constant (H-K hypothesis; measured as a generalized eigenvalue)
#   => |Q| <= a <D> + b ||p||^2,  a = (eps+2eta+eta^2)/(1-eps),  b = (2eta+eta^2)*btilde/(1-eps)
#
# Also: per-n check of |delta_n| <= |S(g^F)|/rho(min), rho>0 and increasing, g*rho increasing,
# signed vs |.| window averages of S (Avdonin 1/4-in-the-mean test), counting-transport identity,
# degree-filtration curves (Runge diagnostic for the basis-free form), effective degree of the
# maximizer, E-matrix validation vs mpmath dps-80.
#
# Data: quantiles_production.csv (149-quantile ladder; zeros used NOWHERE). P = 2e5.
import os, sys, csv
import numpy as np
import mpmath as mp

HERE = os.path.dirname(os.path.abspath(__file__))
for cand in [HERE, os.path.join(HERE, '..', 'completeness_engine_2026-07-17'),
             os.path.join(HERE, '..', 'T3_twin_skeleton_2026-07-17')]:
    if os.path.exists(os.path.join(cand, 'operator_skeleton_hdv.py')):
        sys.path.insert(0, cand); break
from operator_skeleton_hdv import theta, build_prime_data, jacobi_from_atoms

P_CUT = 200000
DROPS = [1, 4]
PREFIXES = [60, 100, 149]
BTILDES = [0.0, 1e-4, 3e-4, 1e-3, 3e-3, 0.01, 0.03, 0.1]
WINDOWS = [1.0, 2.0, 3.0, 4.0, 5.0, 7.0, 10.0]

# ---------------- load ladder ----------------
gD_all, gF_all = [], []
with open(os.path.join(HERE, 'quantiles_production.csv')) as fh:
    for row in csv.DictReader(fh):
        gD_all.append(float(row['gamma_D'])); gF_all.append(float(row['gamma_fwd']))
gD_all = np.array(gD_all); gF_all = np.array(gF_all)
NALL = len(gD_all)
print(f"ladder: {NALL} quantiles (gamma_D, gamma_fwd), P={P_CUT}")

S_P, nterms = build_prime_data(P_CUT)
print(f"{nterms} prime-power terms")

# ---------------- rho = theta'/pi ----------------
_rho_cache = {}
def rho(t):
    t = float(t)
    if t not in _rho_cache:
        _rho_cache[t] = float(mp.diff(theta, mp.mpf(t)) / mp.pi)
    return _rho_cache[t]

# ---------------- section 0: geometry hypotheses (rho > 0, increasing; g*rho increasing) ----
print("\n== [0] geometry hypotheses on rho(t) = theta'(t)/pi ==")
tg = np.arange(0.5, 30.001, 0.1)
rg = np.array([rho(t) for t in tg])
print(f"   rho on [0.5,30]: min {rg.min():.4f} at t={tg[rg.argmin()]:.1f}; "
      f"monotone increasing: {bool(np.all(np.diff(rg) > 0))}")
grho = tg * rg
print(f"   g*rho(g) increasing: {bool(np.all(np.diff(grho) > 0))}")

# ---------------- S_P on a grid: sup, primitive, windows ----------------
print("\n== [1] S_P profile: sup, signed vs |.| window averages (Avdonin test) ==")
grid = np.arange(0.30, 30.0, 0.001)
Sg = np.empty_like(grid)
for i in range(0, len(grid), 2000):
    blk = grid[i:i + 2000]
    Sg[i:i + 2000] = [S_P(t) for t in blk]
Fsig = np.concatenate([[0.0], np.cumsum((Sg[1:] + Sg[:-1]) / 2 * np.diff(grid))])
Fabs = np.concatenate([[0.0], np.cumsum((np.abs(Sg[1:]) + np.abs(Sg[:-1])) / 2 * np.diff(grid))])
def win_avg(F, a, b):
    a = max(a, grid[0]); b = min(b, grid[-1])
    ia, ib = np.interp([a, b], grid, F)
    return (ib - ia) / (b - a)
sup_S_grid = np.abs(Sg).max()
print(f"   sup|S_P| on [0.3,30] grid = {sup_S_grid:.4f} at t = {grid[np.abs(Sg).argmax()]:.3f}")
print(f"   (Kadec 1/4 threshold: pointwise relative shift = |S|; sup exceeds 1/4: {sup_S_grid > 0.25})")
rho_lad = np.array([rho(g) for g in gD_all])
print(f"   {'w':>5} {'max|signed avg|':>16} {'max |.| avg':>12}   (max over ladder windows, n=2..149)")
w_star = None
for w in WINDOWS:
    As = max(abs(win_avg(Fsig, gD_all[n] - w / (2 * rho_lad[n]), gD_all[n] + w / (2 * rho_lad[n])))
             for n in range(1, NALL))
    Aa = max(win_avg(Fabs, gD_all[n] - w / (2 * rho_lad[n]), gD_all[n] + w / (2 * rho_lad[n]))
             for n in range(1, NALL))
    mark = ' < 1/4' if As < 0.25 else ' > 1/4'
    if w_star is None and As < 0.25: w_star = w
    print(f"   {w:5.1f} {As:16.4f} {Aa:12.4f}{mark}")
print(f"   smallest tested w with max|signed avg| < 1/4:  w* = {w_star}")

# ---------------- section 2: per-n transport bounds (delta, eps) ----------------
print("\n== [2] per-n transport bounds: |delta_n| <= |S(gF)|/rho(min), eps_n and its bound ==")
delta_all = gF_all - gD_all
S_at_F = np.array([S_P(g) for g in gF_all])
viol_d = viol_e = 0
eps_all = np.abs(delta_all) * (gF_all + gD_all) / gD_all ** 2   # = |1 - (gF/gD)^2| exactly
eps_bound_all = np.empty(NALL)
for n in range(NALL):
    rmin = rho(min(gD_all[n], gF_all[n]))
    if abs(delta_all[n]) > abs(S_at_F[n]) / rmin * (1 + 1e-9) + 1e-12: viol_d += 1
    eps_bound_all[n] = abs(S_at_F[n]) / rmin * (gF_all[n] + gD_all[n]) / gD_all[n] ** 2
    if eps_all[n] > eps_bound_all[n] * (1 + 1e-9) + 1e-15: viol_e += 1
print(f"   |delta_n| <= |S(gF_n)|/rho(min(gD,gF)):  violations {viol_d}/{NALL}")
print(f"   eps_n <= |S(gF_n)|(gF+gD)/(gD^2 rho(min)): violations {viol_e}/{NALL}")
print(f"   relative shift in cells rho*|delta|: max {np.max(rho_lad*np.abs(delta_all)):.4f} "
      f"mean {np.mean(rho_lad*np.abs(delta_all)):.4f}")

# ---------------- barycentric Lagrange evaluation matrix ----------------
def bary_E(xD, xF):
    """E[a,i]: exact evaluation at xF[a] of the degree<=M-1 interpolant through (xD, v)."""
    M = len(xD)
    XD = xD[:, None] - xD[None, :]
    np.fill_diagonal(XD, 1.0)
    logw = -np.sum(np.log(np.abs(XD)), axis=1)
    sgnw = np.prod(np.sign(XD), axis=1)
    E = np.zeros((len(xF), M))
    ill = 0
    for a_ in range(len(xF)):
        d = xF[a_] - xD
        hit = np.where(np.abs(d) < 1e-15)[0]
        if len(hit):
            E[a_, hit[0]] = 1.0; continue
        lt = logw - np.log(np.abs(d))
        st = sgnw * np.sign(d)
        lt -= lt.max()
        tau = st * np.exp(lt)
        ssum = tau.sum()
        if abs(ssum) < 1e-12 * np.abs(tau).sum(): ill += 1
        E[a_, :] = tau / ssum
    return E, ill

def mp_bary_check(xD, xF, E, ntest=3, npts=4, dps=80):
    """validate float64 E rows against dps-80 barycentric on random value vectors."""
    rng = np.random.default_rng(7)
    M = len(xD)
    idx = rng.choice(len(xF), size=min(npts, len(xF)), replace=False)
    worst = 0.0
    with mp.workdps(dps):
        xDm = [mp.mpf(x) for x in xD]
        wm = [1 / mp.fprod([xDm[i] - xDm[j] for j in range(M) if j != i]) for i in range(M)]
        for _ in range(ntest):
            v = rng.standard_normal(M)
            vm = [mp.mpf(x) for x in v]
            for a_ in idx:
                y = mp.mpf(xF[a_])
                num = mp.fsum([wm[i] * vm[i] / (y - xDm[i]) for i in range(M)])
                den = mp.fsum([wm[i] / (y - xDm[i]) for i in range(M)])
                ref = float(num / den)
                got = float(E[a_] @ v)
                if ref != 0:
                    worst = max(worst, abs(got - ref) / max(1.0, abs(ref)))
    return worst

# ---------------- lanczos (local copy: need the basis vectors) ----------------
def lanczos_full(atoms):
    x = np.asarray(atoms, float); M = len(x)
    v = np.ones(M) / np.sqrt(M)
    al, be, Vs = [], [], [v]
    w = x * v; a0 = v @ w; al.append(a0); w = w - a0 * v
    for j in range(1, M):
        b = np.linalg.norm(w)
        if b < 1e-14: break
        be.append(b)
        vn = w / b
        for u in Vs: vn = vn - (u @ vn) * u
        vn /= np.linalg.norm(vn)
        Vs.append(vn)
        w = x * vn - b * Vs[-2]
        a = vn @ w; al.append(a); w = w - a * vn
    return np.array(al), np.array(be), np.array(Vs)

def pencil_max(Amat, Bdiag):
    """max |eig| of the pencil A v = lam B v with B = diag(Bdiag) > 0 (all forms /M cancel)."""
    s = 1 / np.sqrt(Bdiag)
    return np.abs(np.linalg.eigvalsh(Amat * s[:, None] * s[None, :])).max()

# ---------------- main measurement loop ----------------
out_rows = []
print("\n== [3] the lemma constants per (k, N, btilde) ==")
for k in DROPS:
    for N in PREFIXES:
        gD = gD_all[k:N]; gF = gF_all[k:N]; M = N - k
        xD = 1.0 / gD ** 2; xF = 1.0 / gF ** 2
        eps_meas = eps_all[k:N].max()
        eps_bnd = eps_bound_all[k:N].max()
        s_range = np.abs(Sg[grid >= gD[0] - 0.3]).max()
        eps_unif = 2 * s_range / (gD[0] * rho(gD[0])) * (1 + s_range / (rho(gD[0]) * gD[0]))
        E, ill = bary_E(xD, xF)
        mono_err = max(np.abs(E @ (xD ** j) - xF ** j).max() /
                       max(np.abs(xF ** j).max(), 1e-300) for j in range(9))
        # pencil kappa (Jacobi route) for cross-reference
        JD = jacobi_from_atoms(list(xD), M)
        JF = jacobi_from_atoms(list(xF), M)
        L = np.linalg.cholesky(JD); Li = np.linalg.inv(L)
        kap_pencil = np.abs(np.linalg.eigvalsh(Li @ (JF - JD) @ Li.T)).max()
        # forms in value coordinates
        A_H = (E * xF[None, :].T).T @ E if False else E.T @ (xF[:, None] * E)
        A_Q = A_H - np.diag(xD)
        E1 = E - np.eye(M)
        Wm = E1.T @ (xD[:, None] * E1)
        CF2 = np.abs(np.linalg.eigvalsh(E.T @ E)).max()
        print(f"\n   -- k={k} N={N} (M={M}): eps_meas={eps_meas:.4f} eps_bnd(per-n)={eps_bnd:.4f} "
              f"eps_unif={eps_unif:.4f}")
        print(f"      E: ill-rows {ill}, monomial(j<=8) relerr {mono_err:.1e}, "
              f"C_F=||E||_2 = {np.sqrt(CF2):.3e};  pencil kappa (Jacobi) = {kap_pencil:.4f}")
        for bt in BTILDES:
            Bd = xD + bt
            kQ = pencil_max(A_Q, Bd)
            eta = np.sqrt(max(pencil_max(Wm, Bd), 0.0))
            if eps_meas < 1:
                a_lem = (eps_meas + 2 * eta + eta ** 2) / (1 - eps_meas)
                b_lem = (2 * eta + eta ** 2) * bt / (1 - eps_meas)
            else:
                a_lem = b_lem = float('inf')
            print(f"      btilde={bt:8.4f}  kappa_Q={kQ:10.4f}  eta={eta:10.4f}  "
                  f"a_lem={a_lem:10.4f}  b_lem={b_lem:8.5f}")
            out_rows.append((k, N, bt, eps_meas, eps_bnd, eta, kQ, kap_pencil, a_lem, b_lem))
        if N == PREFIXES[-1]:
            werr = mp_bary_check(xD, xF, E)
            print(f"      mpmath dps-80 validation of E (3 random v, 4 pts): max relerr {werr:.1e}")

with open(os.path.join(HERE, 't2_stage26_lemma_table.csv'), 'w', newline='') as fh:
    w = csv.writer(fh)
    w.writerow(['k', 'N', 'btilde', 'eps_meas', 'eps_bound', 'eta', 'kappa_Q',
                'kappa_pencil', 'a_lemma', 'b_lemma'])
    w.writerows(out_rows)
print("\n   table -> t2_stage26_lemma_table.csv")

# ---------------- section 4: degree filtration (Runge diagnostic + effective degree) ----
print("\n== [4] degree filtration at N=149: kappa_Q(d), eta(d)  [btilde = 0.01] ==")
for k in DROPS:
    N = PREFIXES[-1]
    gD = gD_all[k:N]; gF = gF_all[k:N]; M = N - k
    xD = 1.0 / gD ** 2; xF = 1.0 / gF ** 2
    al, be, Vs = lanczos_full(xD)
    PD = np.sqrt(M) * Vs                       # PD[j,n] = P_j(x_n^D), exactly orthonormal
    E, _ = bary_E(xD, xF)
    PF = PD @ E.T                              # P_j at F-atoms (exact interp of deg<=M-1)
    orth = np.abs(PD @ PD.T / M - np.eye(len(PD))).max()
    print(f"\n   -- k={k}: {len(PD)} orthonormal polys, max|Gram - I| = {orth:.1e}")
    bt = 0.01
    ds = [d for d in [5, 10, 20, 40, 60, 80, 100, 120, M - 1] if d <= M - 1]
    for d in ds:
        Pd, Pf = PD[:d + 1], PF[:d + 1]
        A_D = (Pd * xD[None, :]) @ Pd.T / M
        A_H = (Pf * xF[None, :]) @ Pf.T / M
        dP = Pf - Pd
        Wd = (dP * xD[None, :]) @ dP.T / M
        Bmat = A_D + bt * (Pd @ Pd.T / M)
        Lb = np.linalg.cholesky(Bmat); Lbi = np.linalg.inv(Lb)
        kQd = np.abs(np.linalg.eigvalsh(Lbi @ (A_H - A_D) @ Lbi.T)).max()
        etad = np.sqrt(max(np.abs(np.linalg.eigvalsh(Lbi @ Wd @ Lbi.T)).max(), 0.0))
        print(f"      d={d:>3}:  kappa_Q(d) = {kQd:10.4f}   eta(d) = {etad:10.4f}")
    # effective degree of the full-degree maximizer (in the OP/degree basis)
    A_D = (PD * xD[None, :]) @ PD.T / M
    A_H = (PF * xF[None, :]) @ PF.T / M
    Bmat = A_D + bt * (PD @ PD.T / M)
    Lb = np.linalg.cholesky(Bmat); Lbi = np.linalg.inv(Lb)
    ev, U = np.linalg.eigh(Lbi @ (A_H - A_D) @ Lbi.T)
    imax = np.abs(ev).argmax()
    psi = Lbi.T @ U[:, imax]
    psi = psi / np.linalg.norm(psi)
    cum = np.cumsum(psi ** 2)
    d90 = int(np.searchsorted(cum, 0.90))
    print(f"      maximizer (btilde=0.01): kappa = {abs(ev[imax]):.4f}, "
          f"effective degree d90 = {d90} of {M-1}")

# ---------------- section 5: counting-transport identity check ----------------
print("\n== [5] counting-function transport identity (Lemma 1) ==")
k, N = 4, 60
gD = gD_all[k:N]; gF = gF_all[k:N]; M = N - k
xD = 1.0 / gD ** 2
al, be, Vs = lanczos_full(xD)
PD = np.sqrt(M) * Vs
vvals = PD[10] + 0.5 * PD[3]                    # p = P_10 + 0.5 P_3, via its D-values
E, _ = bary_E(xD, 1.0 / gF ** 2)
pF = E @ vvals
g_of = {}
def gfun(t):
    if t not in g_of:
        # evaluate p at x=1/t^2 by barycentric from D-values
        Erow, _ = bary_E(xD, np.array([1.0 / t ** 2]))
        g_of[t] = float((Erow @ vvals) ** 2 / t ** 2)
    return g_of[t]
lhs = float(np.sum(pF ** 2 / gF ** 2 - vvals ** 2 / gD ** 2))
jumps = sorted([(g, +1) for g in gF] + [(g, -1) for g in gD])
ts = [jumps[0][0] - 0.05] + [j[0] for j in jumps]
rhs, dN = 0.0, 0
for i in range(len(jumps)):
    t0 = ts[i]; t1 = jumps[i][0]
    if dN != 0:
        rhs += -dN * (gfun(t1) - gfun(t0))
    dN += jumps[i][1]
print(f"   p = P_10 + 0.5 P_3 (k=4, N=60):  LHS sum = {lhs:.6e}")
print(f"   RHS -int g' dDeltaN (exact piecewise) = {rhs:.6e}   relerr = {abs(rhs-lhs)/abs(lhs):.1e}")

# monotonicity of u_F = theta/pi + S_P (needed for the floor-formula form of N_F)
th_g = np.array([float(theta(t) / mp.pi) for t in grid[::20]])
uF = th_g + Sg[::20] + 0.5
frac_nonmono = float(np.mean(np.diff(uF) < 0))
dS = np.diff(Sg) / np.diff(grid)
print(f"   u_F monotone? fraction of coarse-grid steps with du_F<0: {frac_nonmono:.3f}; "
      f"sup|S_P'| (grid) = {np.abs(dS).max():.1f}, rho range [{rg.min():.2f},{rg.max():.2f}]")
print("\ndone.")
