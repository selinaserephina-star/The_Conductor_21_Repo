"""T1 deliverable 1 — K-modulus Hankel ledger on the certified-complete zero list.

Conventions = kmodulus_m17.py (repo root): atoms x = 1/gamma^2, unit masses,
S_k = sum 1/gamma^{2k}, H_m = det[S_{i+j-1}]_{i,j=1..m} (Stieltjes),
density tail rho(t) = (1/2pi)(log N + 8 log(t/2pi)) with N = 21^10,
exact antiderivative for the tail moments.

Inputs (read-only): to_Ilya_completeness_CLOSED_2026-07-18/zeros/zeros_found.csv,
the 140 zeros below t = 26 = the complete-in-range set (completeness verdict
N(T*)=21 numerical_anchored; tail list complete to t = 26). Tail cut T0 = 26.

Precision: dets shrink ~10^{-0.94 m^2}; main ladder at dps 2000 for m <= 40
(cancellation ~10^{-1500} at m=40), verification ladder at dps 2300.

Ladders computed:
  A  140 atoms + tail(26)      dps 2000   <- the ledger
  B  140 atoms, no tail        dps 2000   (kmodulus-style companion column)
  C  21 atoms + tail(5.9695)   dps 2000   (cross-agreement check, margin-note style)
  D  ladder A with all gammas jittered +-1e-6 (alternating)  <- zero-error robustness
  E  ladder A at dps 2300      <- precision verification
"""
import csv, time
from pathlib import Path
from mpmath import mp, mpf, matrix, det, log, pi, log10

REPO = Path(__file__).resolve().parents[2]
ZEROS_CSV = REPO / "to_Ilya_completeness_CLOSED_2026-07-18" / "zeros" / "zeros_found.csv"
OUT_CSV = Path(__file__).resolve().parent / "t1_hankel_ledger_results.csv"

G_CUT = 26.0
MMAX = 40
DPS_MAIN = 2000
DPS_CHECK = 2300

def load_zeros():
    zs = []
    with open(ZEROS_CSV) as fh:
        for row in csv.DictReader(fh):
            zs.append(float(row["gamma"]))
    return zs

def powersums(zeros, kmax):
    """S[k-1] = S_k = sum 1/gamma^{2k}, k = 1..kmax."""
    S = [mpf(0)] * kmax
    for z in zeros:
        r = 1 / (z * z)
        p = mpf(1)
        for k in range(kmax):
            p *= r
            S[k] += p
    return S

def tail_moment(k, T0, N):
    # int_{T0}^inf rho(t)/t^{2k} dt, rho(t)=(1/2pi)(log N + 8 log(t/2pi)); exact antiderivative
    a = log(N); c = mpf(8); p = 2 * k
    I1 = T0 ** (1 - p) / (p - 1)
    I2 = (T0 ** (1 - p) / (p - 1)) * (log(T0 / (2 * pi)) + mpf(1) / (p - 1))
    return (a * I1 + c * I2) / (2 * pi)

def Hm(S, m):
    M = matrix(m)
    for i in range(m):
        for j in range(m):
            M[i, j] = S[i + j]
    return det(M)

def ladder(zeros, mmax, T0=None, label=""):
    """Return [None, H_1, ..., H_mmax]. T0 = tail cut (None = no tail)."""
    t0 = time.time()
    N = mpf(21) ** 10
    kmax = 2 * mmax - 1
    S = powersums([mpf(z) for z in zeros], kmax)
    if T0 is not None:
        S = [S[k - 1] + tail_moment(k, mpf(T0), N) for k in range(1, kmax + 1)]
    H = [None]
    for m in range(1, mmax + 1):
        H.append(Hm(S, m))
    print(f"  ladder {label}: {time.time()-t0:.1f}s (dps {mp.dps})")
    return H

def main():
    allz = load_zeros()
    zeros = [z for z in allz if z < G_CUT]
    assert len(zeros) == 140, f"expected 140 zeros below {G_CUT}, got {len(zeros)}"
    print(f"{len(allz)} zeros in production list, {len(zeros)} below t = {G_CUT} (complete-in-range set)")

    # legacy implementation cross-check vs kmodulus_m17 note values (11 zeros, no tail):
    # note: H_7 in 6.884..6.935e-27, H_11 in 5.574..5.955e-94
    mp.dps = 120
    Hleg = ladder(zeros[:11], 11, T0=None, label="legacy-11z")
    print(f"  legacy check: H_7(11z) = {mp.nstr(Hleg[7], 6)}  (kmodulus note: 6.884..6.935e-27)")
    print(f"  legacy check: H_11(11z) = {mp.nstr(Hleg[11], 6)}  (kmodulus note: 5.574..5.955e-94)")

    mp.dps = DPS_MAIN
    HA = ladder(zeros, MMAX, T0=26.0, label="A 140+tail(26)")
    HB = ladder(zeros, MMAX, T0=None, label="B 140 no-tail")
    HC = ladder(zeros[:21], MMAX, T0=5.9695, label="C 21+tail(5.9695)")
    zjit = [z * (1 + (1e-6 if i % 2 == 0 else -1e-6)) for i, z in enumerate(zeros)]
    HD = ladder(zjit, MMAX, T0=26.0, label="D jitter 1e-6")

    mp.dps = DPS_CHECK
    HE = ladder(zeros, MMAX, T0=26.0, label="E dps-check")
    mp.dps = DPS_MAIN

    rows = []
    print(f"\n{'m':>3} {'H_m (140+tail26)':>18} {'log10H/m^2':>11} {'no-tail':>12} "
          f"{'21z+tail':>12} {'21vs140%':>9} {'jit_rel':>9} {'dps_rel':>9}")
    for m in range(1, MMAX + 1):
        hA, hB, hC, hD, hE = HA[m], HB[m], HC[m], HD[m], HE[m]
        assert hA > 0 and hB > 0 and hC > 0, f"nonpositive det at m={m}"
        collapse = log10(hA) / m ** 2
        agree = abs(hA - hC) / hA * 100
        jit = abs(hA - hD) / hA
        dpsrel = abs(hA - hE) / hA
        rows.append(dict(m=m, H_tail=mp.nstr(hA, 12), log10H=mp.nstr(log10(hA), 8),
                         collapse=mp.nstr(collapse, 6), H_notail=mp.nstr(hB, 12),
                         H_21tail=mp.nstr(hC, 12), agree_21v140_pct=mp.nstr(agree, 4),
                         jitter_relshift=mp.nstr(jit, 3), dps_relshift=mp.nstr(dpsrel, 3)))
        print(f"{m:>3} {mp.nstr(hA, 6):>18} {mp.nstr(collapse, 5):>11} {mp.nstr(hB, 5):>12} "
              f"{mp.nstr(hC, 5):>12} {mp.nstr(agree, 3):>9} {mp.nstr(jit, 2):>9} {mp.nstr(dpsrel, 2):>9}")

    with open(OUT_CSV, "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"\nwrote {OUT_CSV}")
    print(f"all H_m > 0 for m = 1..{MMAX} in ladders A, B, C")

if __name__ == "__main__":
    main()
