# operator_skeleton_twin.py — T3: the H = D + V skeleton on the TWIN, V_twin vs V_genome.
# (WORKORDER_T3_twin_skeleton_2026-07-17.md; shares all machinery with operator_skeleton_hdv.py.)
#
# TWIN IDENTITY (verified from repo, 3 independent sources — do not edit without re-verifying):
#   twin = chi8 (x) (./-7), the Kronecker character of Q(sqrt(-7))
#   conductor N = 3^10 * 7^10 = 21^10  PRESERVED (feq search 06-28: only k=10,s3=-1,s7=0 passes;
#     D:\L-function family\tw_RESULTS_for_Selina.md)
#   Gamma factor Gamma_C(s)^4, VGA [0,0,0,0,1,1,1,1] — IDENTICAL to chi8
#     => theta_twin(t) == theta_genome(t) => D_twin == D_genome exactly
#   root number eps = +1; self-dual (ECL_twin_package/passport_twin.json)
#   bad Euler factors: p=3 -> (1+X)  [a_3 = -1, chi8's (1-X) flipped by chi_{-7}(3) = -1]
#                      p=7 -> 1     [a_7 = 0]  (twin_gap20_audit_2026-07-12 LFtw convention)
#   unramified p: local factor = chi8 factor with X -> chi_{-7}(p) X
#     => tr(Frob_twin^k) = chi_{-7}(p)^k * tr(Frob_chi8^k)  (enters via the local_factor hook)
#   zeros: 21 to T=6, ~7 digits (24-bit lfunzeros 06-28); grades in zeros_twin_21_from_0628run.csv
#     (j=1..11 Xi-residual-anchored 07-02, j=12..21 numerical only)
import csv
import numpy as np
import mpmath as mp
from operator_skeleton_hdv import (theta, quantile, jacobi_from_atoms, hankel_ledger,
                                   build_prime_data, Q, LOGQ)
from gen_an_chi8 import LOC8, frob_class

# chi_{-7} = kronecker(-7, .): since -7 = 1 mod 4 this is the conductor-7 quadratic character,
# chi(p) = +1 iff p mod 7 in {1,2,4}; chi(2) = +1 consistent with -7 = 1 mod 8.
QR7 = {1, 2, 4}
def chi_m7(p):
    return 0 if p == 7 else (1 if p % 7 in QR7 else -1)

TWIN_BAD = {3: [1, 1], 7: [1]}   # (1+X) at 3, trivial at 7 — the feq-pinned winners

def twin_local_factor(p):
    if p in TWIN_BAD:
        return TWIN_BAD[p]
    c = chi_m7(p)
    loc = LOC8[frob_class(p)]
    return [co * (c ** i) for i, co in enumerate(loc)]   # X -> chi(p) X

def load_zeros(path):
    with open(path) as fh:
        return [mp.mpf(row['gamma']) for row in csv.DictReader(fh)]

def pearson(a, b):
    a = np.asarray(a, float); b = np.asarray(b, float)
    return float(np.corrcoef(a, b)[0, 1])

def tridiag_entries(M):
    return np.concatenate([np.diag(M), np.diag(M, 1)])

if __name__ == '__main__':
    # sanity spot-checks against the passport before anything runs
    assert chi_m7(3) == -1 and chi_m7(7) == 0 and chi_m7(2) == 1 and chi_m7(5) == -1
    assert twin_local_factor(3) == [1, 1] and twin_local_factor(7) == [1]

    zeros_twin = load_zeros('zeros_twin_21_from_0628run.csv')       # 21, ~7 digits
    zeros_gen = load_zeros('zeros_chi8_rescaled_engine_t9p7.csv')   # 40, engine-grade
    NTWIN = len(zeros_twin)
    M_SEC = 40   # Euler-side quantiles need no zeros; run both objects at full 40

    print("== T3 twin skeleton: chi8 (x) (./-7), N = 21^10, Gamma_C^4, eps = +1 ==")
    print(f"   twin zeros loaded: {NTWIN} (grades: 11 anchored + 10 numerical, ~7 digits, T<=6)")

    print("\n== prime data (Euler side, p^k <= 2e5): genome and twin ==")
    S_gen, n_gen = build_prime_data(200000)
    S_twin, n_twin = build_prime_data(200000, local_factor=twin_local_factor)
    print(f"   genome: {n_gen} prime-power terms   twin: {n_twin} terms (same support)")

    print("\n== quantiles: D (shared geometry) + Hfwd for both objects ==")
    gD, gFg, gFt = [], [], []
    for n in range(1, M_SEC + 1):
        gD.append(quantile(n))
        gFg.append(quantile(n, extra=lambda g: mp.mpf(S_gen(g))))
        gFt.append(quantile(n, extra=lambda g: mp.mpf(S_twin(g))))

    # --- validation vs true zeros, common window n = 1..21 ---
    eD_t = [float(abs(a - b)) for a, b in zip(gD[:NTWIN], zeros_twin)]
    eF_t = [float(abs(a - b)) for a, b in zip(gFt[:NTWIN], zeros_twin)]
    eD_g = [float(abs(a - b)) for a, b in zip(gD[:NTWIN], zeros_gen[:NTWIN])]
    eF_g = [float(abs(a - b)) for a, b in zip(gFg[:NTWIN], zeros_gen[:NTWIN])]
    print(f"\n== forward-vs-true zero errors, common window n = 1..{NTWIN} ==")
    print(f"   TWIN  : mean|gamma_D - true| = {np.mean(eD_t):.4f}   mean|gamma_fwd - true| = "
          f"{np.mean(eF_t):.4f}   improvement {np.mean(eD_t)/np.mean(eF_t):.1f}x")
    print(f"   GENOME: mean|gamma_D - true| = {np.mean(eD_g):.4f}   mean|gamma_fwd - true| = "
          f"{np.mean(eF_g):.4f}   improvement {np.mean(eD_g)/np.mean(eF_g):.1f}x")
    # falsifiability cross-check: the WRONG object's primes must not help (V carries identity)
    xg = np.mean([float(abs(a - b)) for a, b in zip(gFg[:NTWIN], zeros_twin)])
    xt = np.mean([float(abs(a - b)) for a, b in zip(gFt[:NTWIN], zeros_gen[:NTWIN])])
    print(f"   CROSSED: mean|fwd_gen - true_twin| = {xg:.4f}   mean|fwd_twin - true_gen| = {xt:.4f}"
          f"   (vs D alone {np.mean(eD_t):.4f}/{np.mean(eD_g):.4f}: wrong V is WORSE than no V)")

    # --- Jacobi sections, 21-atom convention (only window where twin truth exists) ---
    print(f"\n== Jacobi sections on {NTWIN} atoms (common convention): fwd vs true ==")
    aT_t = [1 / g ** 2 for g in zeros_twin]
    aF_t = [1 / g ** 2 for g in gFt[:NTWIN]]
    aT_g = [1 / g ** 2 for g in zeros_gen[:NTWIN]]
    aF_g = [1 / g ** 2 for g in gFg[:NTWIN]]
    for m in (5, 10, 15, 20):
        et = np.linalg.norm(jacobi_from_atoms(aF_t, m) - jacobi_from_atoms(aT_t, m), 2) \
           / np.linalg.norm(jacobi_from_atoms(aT_t, m), 2)
        eg = np.linalg.norm(jacobi_from_atoms(aF_g, m) - jacobi_from_atoms(aT_g, m), 2) \
           / np.linalg.norm(jacobi_from_atoms(aT_g, m), 2)
        print(f"   m={m:>2}: ||Hfwd-Htrue||/||Htrue||  twin = {et:.4f}   genome(21-atom) = {eg:.4f}")

    # --- V-structure comparison, full 40-atom sections (Euler side only, no zeros) ---
    print("\n== V = Hfwd - D, 40-atom sections: twin vs genome ==")
    atomsD = [1 / g ** 2 for g in gD]
    atomsFg = [1 / g ** 2 for g in gFg]
    atomsFt = [1 / g ** 2 for g in gFt]
    for m in (5, 10, 15, 20):
        JD = jacobi_from_atoms(atomsD, m)
        Vg = jacobi_from_atoms(atomsFg, m) - JD
        Vt = jacobi_from_atoms(atomsFt, m) - JD
        katog = np.linalg.norm(Vg, 2) / np.linalg.norm(JD, 2)
        katot = np.linalg.norm(Vt, 2) / np.linalg.norm(JD, 2)
        eg = np.abs(Vg).mean() / np.abs(JD).mean()
        et = np.abs(Vt).mean() / np.abs(JD).mean()
        print(f"   m={m:>2}: ||V||/||D||  gen {katog:.4f}  twin {katot:.4f}   "
              f"mean|V|/mean|D|  gen {eg:.4f}  twin {et:.4f}")

    m = 20
    JD = jacobi_from_atoms(atomsD, m)
    Vg = jacobi_from_atoms(atomsFg, m) - JD
    Vt = jacobi_from_atoms(atomsFt, m) - JD
    tg, tt = tridiag_entries(Vg), tridiag_entries(Vt)
    dV = tt - tg
    print(f"\n== V_twin vs V_genome at m={m} (tridiagonal entries) ==")
    print(f"   corr(V_twin, V_genome)            = {pearson(tt, tg):.4f}")
    print(f"   corr(diagonals only)              = {pearson(np.diag(Vt), np.diag(Vg)):.4f}")
    print(f"   corr(off-diagonals only)          = {pearson(np.diag(Vt,1), np.diag(Vg,1)):.4f}")
    print(f"   ||dV|| / ||V_genome||             = {np.linalg.norm(dV)/np.linalg.norm(tg):.4f}")
    print(f"   mean|dV| / mean|V_genome|         = {np.abs(dV).mean()/np.abs(tg).mean():.4f}")
    dd = np.diag(Vt) - np.diag(Vg)
    lag1 = pearson(dd[:-1], dd[1:])
    print(f"   dV diagonal lag-1 autocorrelation = {lag1:.4f}   (noise ~ 0, structure > 0)")

    # --- the structural prediction: quantile shift = twist-supported prime sum / density ---
    # theta(g)/pi + S(g) = n - 1/2 for both objects (same theta) implies to first order
    #   gamma_twin(n) - gamma_gen(n)  ~  -[S_twin - S_gen](gamma) / rho(gamma),  rho = theta'/pi
    print("\n== structured-difference test: dgamma vs -(S_twin - S_gen)/rho ==")
    dgam = np.array([float(a - b) for a, b in zip(gFt, gFg)])
    pred = []
    for g in gFg:
        rho = float(mp.diff(theta, g) / mp.pi)
        pred.append(-(S_twin(g) - S_gen(g)) / rho)
    pred = np.array(pred)
    print(f"   corr(dgamma, prediction) over n=1..{M_SEC} = {pearson(dgam, pred):.4f}")
    print(f"   rms(dgamma) = {np.sqrt((dgam**2).mean()):.4f}   rms(pred) = {np.sqrt((pred**2).mean()):.4f}"
          f"   rms(residual) = {np.sqrt(((dgam-pred)**2).mean()):.4f}")

    # --- Hankel ledger for the twin: 21 atoms + density tail from T0 = 6.0 ---
    print("\n== twin Hankel ledger (21 atoms + density tail, T0 = 6.0, dps 150) ==")
    Ht = hankel_ledger(zeros_twin, 20, mp.mpf('6.0'))
    for mm in (5, 10, 15, 17, 18, 19, 20):
        h = Ht[mm - 1]
        print(f"   m={mm:>2}: H_m = {mp.nstr(h, 4)}   {'>0 OK' if h > 0 else '<= 0  **COLLAPSE**'}")

    # --- dump per-n table for the report ---
    with open('t3_twin_comparison_table.csv', 'w', newline='') as fh:
        w = csv.writer(fh)
        w.writerow(['n', 'gamma_D', 'gamma_fwd_gen', 'gamma_fwd_twin', 'gamma_true_gen',
                    'gamma_true_twin', 'Vdiag_gen', 'Vdiag_twin', 'dgamma', 'dgamma_pred'])
        dg = np.diag(Vg); dt = np.diag(Vt)
        for i in range(M_SEC):
            w.writerow([i + 1, f"{float(gD[i]):.6f}", f"{float(gFg[i]):.6f}", f"{float(gFt[i]):.6f}",
                        f"{float(zeros_gen[i]):.6f}" if i < len(zeros_gen) else '',
                        f"{float(zeros_twin[i]):.6f}" if i < NTWIN else '',
                        f"{dg[i]:.6e}" if i < m else '', f"{dt[i]:.6e}" if i < m else '',
                        f"{dgam[i]:.6f}", f"{pred[i]:.6f}"])
    print("\n   per-n table written: t3_twin_comparison_table.csv")

    print("\n== caveats (grades) ==")
    print("   twin zeros: ~7-digit, 24-bit lfunzeros T<=6; j=1..11 Xi-anchored, j=12..21 numerical")
    print("   S_P truncation p^k <= 2e5 for both objects (identical support => fair comparison)")
    print("   fwd-vs-true only on n=1..21 (twin truth window); V-comparison zero-free, full n=1..40")
    print("   Hankel: twin tail from T0=6.0 assumes the 21-zero list complete on [0,6] (density-consistent)")
