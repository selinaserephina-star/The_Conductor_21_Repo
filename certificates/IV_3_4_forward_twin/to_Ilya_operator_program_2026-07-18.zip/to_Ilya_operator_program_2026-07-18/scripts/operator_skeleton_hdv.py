# operator_skeleton_hdv.py — runnable skeleton of the H = D + V operator
# (OPERATOR_from_density_and_primes_2026-07-16.md, made concrete).
#
# Ledger conventions follow kmodulus_m17.py: atoms x = 1/gamma^2, unit mass each;
# Jacobi matrix via Lanczos on diag(atoms); spectrum of J_m = atoms (validation).
#
# Three operators, all FINITE SECTIONS of size m:
#   D    — geometry only: atoms at density-law quantiles  theta(g)/pi = n - 1/2
#   Hfwd — geometry + primes, NON-CIRCULAR: quantiles of theta(g)/pi + S_P(g) = n - 1/2,
#          S_P computed from the Euler product (Frobenius traces, p^k <= P), no zeros used
#   Htrue— actual 40 zeros from the rescaled-FFT engine (OUTPUT check only)
#
# Measured skeleton quantities:
#   V = Hfwd - D (tridiagonal entries)      — the prime fine-structure in operator form
#   kato(m) = ||V_m||_2 / ||D_m||_2         — the finite-section Kato ratio
#   zero-level agreement: spec(Hfwd) vs spec(Htrue) (i.e. gamma_fwd vs gamma_true)
#   Hankel ledger H_m extended with 40 atoms + density tail (was m=17 with 17 zeros)
import csv
import numpy as np
import mpmath as mp
from flint import nmod_poly

mp.mp.dps = 40
Q = mp.mpf(21) ** 10
LOGQ = mp.log(Q)
MU = [0, 0, 0, 0, 1, 1, 1, 1]

# ---------- geometry: theta and quantiles ----------
def theta(t):
    s = mp.mpf('0.5') + 1j * t
    v = (s / 2) * LOGQ
    for m_ in MU:
        v += -((s + m_) / 2) * mp.log(mp.pi) + mp.loggamma((s + m_) / 2)
    return mp.im(v)

def quantile(n, extra=None):
    """solve theta(g)/pi + extra(g) = n - 1/2   (extra=None -> geometry only)"""
    f = (lambda g: theta(g) / mp.pi - (n - mp.mpf('0.5'))) if extra is None else \
        (lambda g: theta(g) / mp.pi + extra(g) - (n - mp.mpf('0.5')))
    g0 = mp.mpf('1.0') + mp.mpf('0.22') * n   # crude seed; refined by solver
    return mp.findroot(f, g0, tol=mp.mpf('1e-24'))  # S_P side is float64; 1e-12-level roots suffice

# ---------- primes: S_P(t) from the Euler product (no zeros anywhere) ----------
from gen_an_chi8 import LOC8, frob_class   # validated local-factor recipe, PARI-matched

def newton_power_sums(loc, kmax):
    """tr(Frob^k) from det(1 - Frob X) = sum loc[i] X^i via Newton's identities:
    e_i = (-1)^i loc[i];  p_k = (-1)^{k-1} k e_k + sum_{i=1}^{k-1} (-1)^{i-1} e_i p_{k-i}."""
    deg = len(loc) - 1
    e = [((-1) ** i) * loc[i] for i in range(len(loc))]
    p = [0] * (kmax + 1)
    for k in range(1, kmax + 1):
        s = ((-1) ** (k - 1)) * k * e[k] if k <= deg else 0
        for i in range(1, min(k - 1, deg) + 1):
            s += ((-1) ** (i - 1)) * e[i] * p[k - i]
        p[k] = s
    return p[1:]

def build_prime_data(P, local_factor=None):
    """local_factor(p) -> coeff list of det(1 - Frob_p X); default = genome chi8.
    A twist enters purely through this hook (e.g. twin: X -> chi(p) X, fresh bad factors)."""
    if local_factor is None:
        local_factor = lambda p: LOC8[frob_class(p)]
    isp = np.ones(P + 1, dtype=bool); isp[:2] = False
    for q_ in range(2, int(P ** 0.5) + 1):
        if isp[q_]: isp[q_ * q_::q_] = False
    terms = []  # (k*log p, tr(Frob_p^k)/k * p^{-k/2})
    for p in np.nonzero(isp)[0]:
        p = int(p)
        kmax = 1
        while p ** (kmax + 1) <= P: kmax += 1
        tr = newton_power_sums(local_factor(p), kmax)
        for k in range(1, kmax + 1):
            terms.append((k * np.log(p), tr[k - 1] / k * p ** (-k / 2)))
    lg = np.array([t[0] for t in terms]); co = np.array([t[1] for t in terms])
    def S_P(t):
        return float(-(1 / np.pi) * np.sum(co * np.sin(float(t) * lg)))
    return S_P, len(terms)

# ---------- atoms -> Jacobi (Lanczos, unit weights) ----------
def jacobi_from_atoms(atoms, m):
    x = np.array([float(a) for a in atoms])
    Nn = len(x)
    v = np.ones(Nn) / np.sqrt(Nn)
    al, be = [], []
    Vs = [v]
    w = x * v
    a0 = v @ w; al.append(a0)
    w = w - a0 * v
    for j in range(1, m):
        b = np.linalg.norm(w)
        if b < 1e-14: break
        be.append(b)
        vn = w / b
        for u in Vs: vn = vn - (u @ vn) * u   # full reorthogonalization
        vn /= np.linalg.norm(vn)
        Vs.append(vn)
        w = x * vn - b * Vs[-2]
        a = vn @ w; al.append(a)
        w = w - a * vn
    J = np.diag(al) + np.diag(be, 1) + np.diag(be, -1)
    return J

# ---------- Hankel ledger with 40 atoms + density tail ----------
def hankel_ledger(gammas, mmax, gmax):
    # dets shrink like 10^{-0.77 m^2}; need high working precision (cf. kmodulus_m17 dps 60)
    with mp.workdps(150):
        # density tail via the exact antiderivative (kmodulus_m17.tail_moment):
        # rho(t) ~ (1/2pi)(log N + 8 log(t/2pi));  int_T0^inf t^{-2k} rho dt closed-form
        def tail_moment(k, T0):
            a = mp.log(Q); c = mp.mpf(8); p = 2 * k
            I1 = T0 ** (1 - p) / (p - 1)
            I2 = (T0 ** (1 - p) / (p - 1)) * (mp.log(T0 / (2 * mp.pi)) + mp.mpf(1) / (p - 1))
            return (a * I1 + c * I2) / (2 * mp.pi)
        S = []
        for k in range(1, 2 * mmax):
            s = sum(mp.mpf(1) / mp.mpf(g) ** (2 * k) for g in gammas)
            s += tail_moment(k, mp.mpf(gmax))
            S.append(s)
        out = []
        for m in range(1, mmax + 1):
            M = mp.matrix(m)
            for i in range(m):
                for j in range(m):
                    M[i, j] = S[i + j]
            out.append(mp.det(M))
        return out

if __name__ == '__main__':
    zeros_true = []
    with open('zeros_chi8_rescaled_engine_t9p7.csv') as fh:
        for row in csv.DictReader(fh):
            zeros_true.append(mp.mpf(row['gamma']))
    M_SEC = 40

    print("== building prime data (Euler side, p^k <= 2e5) ==")
    S_P, nterms = build_prime_data(200000)
    print(f"   {nterms} prime-power terms")

    print("== D quantiles (geometry) and Hfwd quantiles (geometry+primes) ==")
    gD, gF = [], []
    for n in range(1, M_SEC + 1):
        gD.append(quantile(n))
        gF.append(quantile(n, extra=lambda g: mp.mpf(S_P(g))))
    errD = [float(abs(a - b)) for a, b in zip(gD, zeros_true)]
    errF = [float(abs(a - b)) for a, b in zip(gF, zeros_true)]
    print(f"   mean |gamma_D - gamma_true|   = {np.mean(errD):.4f}  (geometry alone)")
    print(f"   mean |gamma_fwd - gamma_true| = {np.mean(errF):.4f}  (geometry + Euler primes)")
    print(f"   improvement factor: {np.mean(errD) / np.mean(errF):.1f}x  <- the r=0.981 effect, operator-grade")

    print("\n== Jacobi sections: D, Hfwd, Htrue; V = Hfwd - D ==")
    atomsD = [1 / g ** 2 for g in gD]
    atomsF = [1 / g ** 2 for g in gF]
    atomsT = [1 / g ** 2 for g in zeros_true]
    for m in (5, 10, 15, 20):
        JD = jacobi_from_atoms(atomsD, m)
        JF = jacobi_from_atoms(atomsF, m)
        JT = jacobi_from_atoms(atomsT, m)
        V = JF - JD
        kato = np.linalg.norm(V, 2) / np.linalg.norm(JD, 2)
        # spectral-norm ratio saturates on the top atom; entrywise mean is the
        # finer fine-structure measure (the beta_n-deviation scale of R-211)
        entry = np.abs(V).mean() / np.abs(JD).mean()
        fwd_err = np.linalg.norm(JF - JT, 2) / np.linalg.norm(JT, 2)
        print(f"   m={m:>2}: ||V||/||D|| = {kato:.4f}   mean|V|/mean|D| = {entry:.4f}   "
              f"||Hfwd-Htrue||/||Htrue|| = {fwd_err:.4f}")

    print("\n== Hankel ledger extension (40 atoms + density tail), was m=17 ==")
    H = hankel_ledger(zeros_true, 20, mp.mpf('9.7'))
    for m in (5, 10, 15, 17, 18, 19, 20):
        h = H[m - 1]
        print(f"   m={m:>2}: H_m = {mp.nstr(h, 4)}   {'>0 OK' if h > 0 else '<= 0  **COLLAPSE**'}")
