# The operator-skeleton path: where it stands, and one question for you

**Merkabit Research · 2026-07-18 · Selina + Claude.** Short status on the H = D + V program.
Not RH/GRH anywhere below; grades stated per result.

## The object

Finite Jacobi sections built ledger-style (atoms 1/γ², unit mass, Lanczos):

- **D** — geometry only: atoms at density quantiles θ(γ)/π = n − ½ (θ from conductor + Γ-factor).
- **H_fwd** — geometry + primes: quantiles of θ/π + S_P = n − ½, with S_P from the Euler
  product (Frobenius traces, p^k ≤ 2·10⁵). **No zeros enter the forward side anywhere.**
- **V = H_fwd − D** — the prime fine-structure, in operator form. True zeros are used only
  as the answer key.

## Three results (all 2026-07-17)

**1. V carries the object, D carries the class (T3, twin comparison).** The CM-twin
χ₈⊗(·/−7) preserves N = 21¹⁰ and Γ_ℂ⁴ (your conductor-preservation result), so
**D_twin ≡ D_genome exactly** — all discrimination must live in V. Measured (common window
n = 1..21): matched primes predict own zeros at 0.0105 (genome) / 0.0229 (twin) mean error;
**crossed pairings give 0.109 / 0.107 — worse than geometry alone** (0.080 / 0.063). The
between-object quantile shift is 96%-correlated with −(S_twin − S_gen)/ρ, i.e. the difference
is supported exactly on the twist-flipped primes. New finding: **the twist decoheres V** —
V_twin ≈ 2.4× smaller entrywise; the twin's zeros sit correspondingly closer to the pure
density law. [`T3_twin_skeleton_2026-07-17/`; twin zeros ~7-digit numerical, 11 of 21
Ξ-anchored.]

**2. The pin measurement (T2), now at production scale (149 zeros to t = 28, the
completeness run): the naive pin is REFUTED, the refined pin survives emphatically.**
Pencil Vψ = λDψ: the FULL form-ratio crosses 1 at production scale (κ = 1.182, flat
m = 20..149) — no norm of S can bound the top block (pointwise C = 1.37), so any lemma is
necessarily a *tail* lemma. But splitting off finitely many top atoms restores it: drop-1
κ = 0.431, drop-2 = 0.294, drop-4 = 0.309, each **dead flat over m = 10..148** — the
uniformity-in-m claim could not look cleaner. Bounded finite-rank V_top cannot break
self-adjointness (KLMN + finite-rank stability), so the burden is exactly the measured tail
bound 0.29–0.43. One honest open point: the tail ratio grew with atom-list length
(0.19 at 40 atoms → 0.31 at 149); saturation in list length is now the sharpest empirical
question. Twin control (same D, twin local factors): κ_twin/κ_genome = 2.35 — **the 2.4×
twist-decoherence reproduced by an independent instrument.** Forward-prediction at scale:
mean |γ_fwd − γ_true| = 0.0185 over 140 zeros, height-flat (0.0165/0.0187/0.0198 by
thirds). [`T2_pin_conjecture_2026-07-17/`; production zeros numerical_anchored, complete
to t = 26.]

**2b. The zeros sing the primes back (resonance check).** With the production window the
explicit-formula duality resolves line by line: fitting the zero-side fluctuation spectrum
at the known frequencies k·log p (amplitudes free), the fitted coefficients reproduce the
Frobenius data the zero side never saw — 12 interior lines, **corr 0.99987, rms 0.008**;
the ramified 7 fits at 0.002 ≈ 0; the class-3A sign flips at 17, 19 come out negative.
[`unbounded/resonance_spectrum_2026-07-18/`.]

**3. Rigor ladder step 1 shipped: ball-certified G-kernel.** The Γ_ℂ⁴ Mellin kernel
G^(k)(u;η), k ≤ 13, on the production grid, as certified acb enclosures (residue series over
the order-4 poles of Γ(s)⁴ + a Lemma-5.1-style tail bound; 1500 bits). **All radii ≤ 1e-72**
(spec 1e-30), builds in ~2 s, validated by two independent methods. Side-effect: it exposed
genuine errors in the float G-table at k = 10..13 (O(1) at row scale, 278 entries) —
harmless to the float64 pipeline (weights ε^k/k! ≤ 2e-20) but now superseded.
[`completeness_engine_2026-07-17/G_KERNEL_ARB_RESULTS_2026-07-17.md`.]

## The shape of the program now

V = V_top (finite block, provably harmless) + V_tail with κ(V_tail) ≈ 0.29–0.43 measured,
flat in m: self-adjointness in the limit reduces to **one inequality — a uniform form-bound
on the tail** (plus the list-length saturation question above). The analytic object is the
linearized transport form δ_n = −S(γ_n)/ρ(γ_n) (verified: it reproduces the pencil κ to
5–7%), and the empirical window study says averaging S costs little up to ~3 mean spacings
(the constant rises 0.36 → 0.50 from pointwise to 3-window, then saturates ≈ 0.78 by w = 15,
all < 1 on the tail) — which is where the unconditional Turing/PZ machinery (the same
B ≈ 57.9 constant as the completeness certificate) could become an unconditional input.

**The question for you, sharpened by the measurements:** *what is the weakest
windowed-average norm of S that controls the quantile-transport form-bound of the TAIL —
and can it be taken against SIGNED window integrals of S (what Turing actually certifies)
rather than |S|?* The form pairs neighbouring atoms with smooth weights, so signed ~3-spacing
averages look consumable in principle; if that closes, the completeness engine's certified
bounds plug directly into self-adjointness (T2a: certified κ < 1 on explicit ranges — the
ball-arithmetic pieces exist as of this week).

Everything reproducible from the folders cited; run logs and per-row grades included.

— Selina + Claude, 2026-07-18
