# One wave, two ears — the prime wave and the zero wave compared

**Merkabit · 2026-07-18 · Selina + Claude.** `resonance_spectrum.py`, data: 39 genome zeros
to t = 9.55 (rescaled engine) + Euler side p^k ≤ 2×10⁵. Not RH/GRH.

## The two waves (independent data)

- **Prime wave** S_P(t): superposition of sines, one per prime power, frequency k·log p,
  amplitude tr(Frob_p^k)/(k p^{k/2}). Euler product only — no zeros.
- **Zero wave** S_true(t) = N(t) − θ(t)/π: the counting staircase minus the smooth law.
  Zero list + geometry only — no primes.

## Result

Apply the *identical* Hann-windowed sine transform to both waves:

- **The two spectra are the same function: correlation 1.0000 over x ∈ [0.1, 3.0],
  agreement ~10⁻³ at every frequency sampled** (e.g. at x = log 2: −0.3069 vs −0.3063;
  at x = log 11: −0.4062 vs −0.4053). Two waves built from disjoint data, one spectrum.
- Time domain, raw (no window): corr = 0.76 — dragged by the staircase jumps and the low-t
  edge; the spectral statement is the clean one.

## The honest subtlety: lines not yet resolved

At window T = 9.55 the spectral resolution is ~2π/T ≈ 0.66 in x, while the prime lines are
spaced ~0.1–0.4 apart (log 5 − log 4 = 0.22; the 7/8/9 cluster spans 0.25). So individual
overtone heights are BLENDED — the measured value at "log 7" is a smear of neighbours, and
a naive line-by-line comparison to c_pk is meaningless at this window (it comes out −0.48
and should be ignored; both spectra agree that's what the smeared value is). What IS
established: the zeros' wave carries exactly the primes' spectrum as seen through any
common lens.

## What the production zeros unlock

With zeros to t = 28 (AWS run), resolution → ~0.22: log 4 / log 5 separate, the 7/8/9
cluster splits. Then the line heights become individually extractable and the table
"a_p read off the zero list, checked against Frobenius classes" becomes a real deliverable —
hearing the individual overtones, not just the chord. Flagged for post-2.2.

## UPDATE 2026-07-18 (same day): the overtones RESOLVED — production zeros

The production run landed (140 zeros complete to t = 26, `to_Ilya_completeness_CLOSED_2026-07-18`).
`resonance_production.py`: fit the zero-side spectrum as a least-squares combination of
known-frequency line kernels (frequencies k·log p fixed, amplitudes free), 320 spectrum
samples, 16 lines, residual/signal 0.7%. Result, **zeros-only fitted amplitudes vs Frobenius
coefficients the zero side never saw** (12 interior lines, x ≤ 3.0):

> **corr = 0.99987, rms error 0.0076, max error 0.015** — the Frobenius classes read off the
> zero list at ~1% precision.

Signature rows: the ramified prime 7 fits at **0.0016 vs exactly 0** (the zeros know 7 is
ramified); a₁₃ fits −0.011 vs 0; the class-3A sign flips at 17 and 19 (−0.255 vs −0.2425,
−0.245 vs −0.2294) come out negative as they must. The 4 boundary lines (x > 3.0) are
contaminated by out-of-model neighbours (31, 2⁵, …) — extendable by widening the model window.
Table: `overtone_table_production.csv`. The chord is now heard note by note.

## Reading

"Resonance" is close, but the precise statement is Fourier duality: each wave is the
spectrum of the other. The zeros sit where the prime waves interfere constructively
(that is the quantile mechanism T3 tested; the twist decoherence was detuned interference,
observed at 2.4×). And symmetrically, the primes are the overtone lines of the zeros' song.
One object, heard from both ends.

— Selina + Claude, 2026-07-18
