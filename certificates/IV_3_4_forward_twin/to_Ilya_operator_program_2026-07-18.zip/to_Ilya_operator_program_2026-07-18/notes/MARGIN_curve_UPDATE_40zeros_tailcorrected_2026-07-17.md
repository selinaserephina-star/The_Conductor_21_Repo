# Margin curve, updated: 40 zeros + exact mean-density tail — the "erosion" was the artifact

**Merkabit · 2026-07-17 (same day, evening) · Stenberg + Claude.** Update to
`MARGIN_curve_geometry_vs_primes_2026-07-17.md`, using (a) the 40-zero list from the new rescaled-FFT
engine (γ₁–γ₄₀, t ≤ 9.59; `completeness_engine_2026-07-17/zeros_chi8_rescaled_engine_t9p7.csv`) and
(b) the missing-tail correction by the **exact smooth density** dens(g) = θ′(g)/π. Scripts:
`completeness_engine_2026-07-17/compute_margin40.py`, `compute_margin40b.py`. Not RH/GRH.

## 1. Raw partial sums first (no correction): the turnover moved as predicted

λ^total from 21 zeros peaked at n ≈ 11; from 40 zeros it peaks at n ≈ 22 — caveat 1 of the
original note confirmed mechanically. In the old "clean band" the apparent erosion ratio *drops*
with more zeros (n=3: 0.28 → 0.19; n=5: 0.37 → 0.24; n=8: 0.54 → 0.375). The climb toward 1 was
receding as resolution improved — the signature of a partial-sum artifact, now measured.

## 2. The tail-corrected curve: the erosion essentially vanishes

Correct the partial sum by the mean-density tail ∫_{γmax}^∞ 2(1−cos nφ(g))·θ′(g)/π dg:

| n | λ^arch | λ^total corr. | λ^fin corr. | ratio |
|---|---|---|---|---|
| 1 | 5.56 | 4.31 | −1.25 | 0.225 |
| 2 | 17.70 | 15.93 | −1.77 | 0.100 |
| 3 | 31.62 | 31.71 | +0.09 | 0.003 |
| 5 | 63.03 | 64.58 | +1.56 | 0.025 |
| 8 | 115.94 | 115.32 | −0.62 | 0.005 |
| 12 | 193.41 | 192.34 | −1.07 | 0.006 |
| 16 | 276.30 | 274.55 | −1.75 | 0.006 |
| 20 | 363.24 | 360.39 | −2.85 | 0.008 |
| 25 | 476.37 | 470.33 | −6.05 | 0.013 |

**|λ^fin| ≤ ~6 across n ≤ 25, ratio ≤ 2.5% for n ≥ 3** (n=1: 22%, n=2: 10%, then collapse).
Sign-alternating, no trend toward 1.

**Internal validation (the reason to believe this):** the same correction applied to the
**21-certified-only** list (γmax = 5.9695) reproduces the 40-zero corrected curve to
**0.00–0.07% at every n ≤ 25**. Two different zero sets, two different tail cutoffs, same answer —
the correction is doing exactly what it claims. Note this means the conclusion stands on the
**ball-certified 21 alone**; the 40-zero list (numerical grade) is confirmation, not load-bearing.

## 3. Why: the identity behind it

Numerically, ∫₀^∞ 2(1−cos nφ(g))·θ′(g)/π dg = λ_n^arch − 0.0067·n² (checked n = 1…12; the
residual is *exactly* ∝ n², a clean boundary term, ≤ 0.5%). So to that precision:

**λ_n^fin = ∫ w_n(g) dS(g)** — the prime pull is *purely the S(t)-fluctuation integral*.
The mean zero density is geometry's (it is θ′, conductor+Γ); the primes only contribute the
oscillation of the counting function around its mean. "Primes eat a third of the margin" compared
a complete geometry term against an incomplete zero sum; completed, the competition is
**geometry + its own mean spectrum vs a percent-level bounded oscillation**.

## 4. Revised reading of the crux

- The original crux — "does the erosion ratio stabilize below 1 or climb to 1?" — is **resolved in
  range: it was never climbing.** In the resolved band (weights dominated by γ ≤ 9.7, i.e. n ≲ ~15–20)
  the true erosion is ≤ ~2%, oscillating.
- The RH-relevant content relocates: λ_n ≥ 0 is, in range, carried overwhelmingly by geometry+mean
  density; the dangerous object is the **cumulative S-fluctuation at large n** (weights w_n probe
  γ ~ n-scale, where S can conspire). That is the same wall as always — but the margin curve now says
  the wall is *not* being approached linearly in the measured band; it would have to arrive through
  fluctuation growth, not steady erosion.
- Knife-edge status (⟨a²⟩ = 1, Λ = 0) unchanged as a global statement; what changed is that the
  *measured* band shows no tightening.

## Caveats

1. λ^fin(corr.) assumes zero fluctuation above γmax — it is the fluctuation *resolved from* γ ≤ 9.7
   (resp. 5.97). For n ≳ 20 unresolved fluctuations can contribute; the 21-vs-40 agreement bounds
   this empirically below 0.1% of λ^total in the overlap band.
2. γ₂₂–γ₄₀ are numerical grade (rescaled-FFT engine, η-cross-checked to ~10⁻⁵, count matches Φ to
   ±0.05 through t = 9.7). Per §2 the conclusion does not depend on them.
3. ~~The −0.0067·n² boundary term is identified numerically, not yet derived~~ **RESOLVED
   (2026-07-18, T1 session):** it was not a boundary term at all — it is exactly the g = 2000
   quadrature truncation in `compute_margin40b.py` (∫₂₀₀₀^∞ ≈ 0.00673·n², verified at n = 3, 8, 12,
   25). With integration to ∞ (phase-based nodes, cross-checked to 10⁻²⁹) the n² drift vanishes and
   the identity ∫w dΦ = λ_arch — hence λ^fin = ∫w dS — holds with no residual term. See
   `T1_finite_range_positivity_2026-07-18.md`.

*WIP — no SHA. Direct payoff of the rescaled-FFT engine into the operator program: the margin
curve's clean band roughly doubled, and the erosion story corrected. — Stenberg + Claude, 2026-07-17.*
