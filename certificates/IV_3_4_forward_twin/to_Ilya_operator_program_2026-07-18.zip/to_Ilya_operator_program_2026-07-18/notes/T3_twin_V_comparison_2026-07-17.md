# T3 — the H = D + V skeleton on the twin: V carries the object, D carries the class

**Merkabit Research · 2026-07-17 · Selina Stenberg + Claude.** Execution of
`WORKORDER_T3_twin_skeleton_2026-07-17.md` (rigidity test T3 from
`OPERATOR_SKELETON_HDV_2026-07-17.md`). Not RH/GRH — a finite-section, falsifiable
comparison of two degree-8 L-functions on the same shell. Shared-credit conventions.

## Verdict line

**STRUCTURED, not noise.** The difference V_twin − V_genome is (i) predicted to 96%
correlation by the twist-supported Euler terms alone, (ii) sign-coherent (positive lag-1
autocorrelation), and (iii) *object-identifying*: each V forward-predicts its **own**
zeros (errors 0.0105 / 0.0229) while the crossed pairings are **worse than geometry
alone** (0.109 / 0.107 vs D-alone 0.080 / 0.063). And the twin is the sharpest possible
testbed: its conductor and Γ-factor are **identical** to the genome's, so D_twin ≡
D_genome *exactly* — every bit of discrimination between the two objects lives in V.

## 1. The twin, verified from the repo (not from memory)

| item | value | source |
|---|---|---|
| object | χ₈ ⊗ (·/−7), Kronecker char of ℚ(√−7) | `ECL_twin_package/passport_twin.json` |
| twist character | conductor-7 quadratic char; χ(p)=+1 iff p mod 7 ∈ {1,2,4} (−7≡1 mod 4; χ(2)=+1 from −7≡1 mod 8) | verified against passport spot-values χ(3)=−1, χ(5)=−1 |
| conductor | **N = 3¹⁰·7¹⁰ = 21¹⁰ PRESERVED** (feq search 06-28: only k=10, s3=−1, s7=0 passes, feq −27 at 32-bit) | `D:\L-function family\tw_RESULTS_for_Selina.md` |
| Γ-factor | Γ_ℂ(s)⁴, VGA [0,0,0,0,1,1,1,1] — identical to χ₈ | passport + `twin_gap20_audit_2026-07-12/twin_ffull_audit.gp` |
| root number | ε = +1 (lfunrootres); self-dual; L(½) = 1.8739 ≠ 0 | tw_RESULTS §3 |
| bad factors | p=3: (1+X), a₃=−1 (χ₈'s (1−X) flipped by χ(3)=−1); p=7: trivial, a₇=0 | feq table (all six (s3,s7) combos tested, one winner) |
| unramified p | local factor = χ₈ factor with X → χ(p)X ⇒ tr(Frob^k) picks up χ(p)^k | gap-20 audit `LFtw(p)` convention |
| zeros | **21 zeros, T ≤ 6, ~7 digits** (24-bit lfunzeros, ε passed explicitly); grades: j=1..11 Ξ-residual-anchored (rel 7.4e-9 … 1.5e-16), j=12..21 numerical only | `tw_zeros_list.txt` (06-28) + `ECL_twin_package/zeros_twin.csv` (07-02) |

Consistency across three independent records (06-28 D:-drive results, 07-02 ECL twin
package, 07-12 gap-20 audit): all agree. Zero list frozen into
`completeness_engine_2026-07-17/zeros_twin_21_from_0628run.csv` with per-row grades.

Because N and Γ are identical, θ_twin(t) ≡ θ_genome(t): **the density backbone D is not
merely "class-universal" here — it is the same operator, entry for entry.**

## 2. Genome baseline reproduced (required gate)

Rerun of `operator_skeleton_hdv.py` (this worktree copy, after the backward-compatible
`local_factor` hook was added):

- mean |γ_fwd − γ_true| = **0.0165**, improvement **3.9×** over geometry (0.0650) ✓
- ‖H_fwd − H_true‖/‖H_true‖ = **2.25%** ✓
- entrywise mean|V|/mean|D| = **0.458 → 0.353** declining (m=5→20) ✓
- Hankel ledger positive through **m=20** at dps 150 (H₂₀ ≈ 1.0e-376 > 0) ✓

All four baseline numbers match the work order.

## 3. Twin skeleton run (`operator_skeleton_twin.py`)

Same code path: same θ, same quantile solver, same Lanczos/ledger conventions, same
S_P truncation p^k ≤ 2·10⁵ (18,120 prime-power terms for both objects — identical
support, so the comparison is fair). Only the local-factor hook differs.

**Forward zero prediction, common window n = 1..21:**

| pairing | mean \|γ_fwd − γ_true\| | vs D alone | verdict |
|---|---|---|---|
| genome primes → genome zeros | **0.0105** | 0.0797 (7.6×) | matched V works |
| twin primes → twin zeros | **0.0229** | 0.0629 (2.7×) | matched V works |
| genome primes → twin zeros | 0.1090 | 0.0629 | **wrong V is worse than no V** |
| twin primes → genome zeros | 0.1067 | 0.0797 | **wrong V is worse than no V** |

(Genome's 21-window error 0.0105 is smaller than its 40-window 0.0165 because the fwd
scheme is most accurate low; twin at 0.0229 on ~7-digit zeros is unambiguous signal —
the improvement over D and the crossed-pairing failure are both ~5σ-scale effects
relative to the zero-list precision of 1e-6.)

**Jacobi sections, 21-atom convention:** ‖H_fwd − H_true‖/‖H_true‖ = **3.0%** (twin) vs
**2.3%** (genome at the same convention), stable in m = 5..20.

**Twin Hankel ledger** (21 atoms + density tail from T0 = 6.0, dps 150): positive
through **m = 20** (H₅ ≈ 9.3e-4, H₁₀ ≈ 2.0e-48, H₂₀ ≈ 1.1e-352, all > 0) — the twin's
first Hankel/Li-type positivity ledger, same depth as the genome's.

## 4. The comparison: V_twin vs V_genome

40-atom sections (V = H_fwd − D is Euler-side only — no zero lists touched), m = 20:

| measure | genome | twin |
|---|---|---|
| ‖V‖/‖D‖ (Kato ratio) | 0.627 | **0.231** |
| mean\|V\|/mean\|D\| (m=5→20) | 0.458 → 0.353 declining | 0.162 → 0.147 flat |

**Entrywise structure of the difference (m=20 tridiagonal):**

- corr(V_twin, V_genome) = **0.981** (diagonals 0.986, off-diagonals 0.921) — the two
  V's share one envelope: prime fine-structure transported to the operator the same way.
- ‖ΔV‖/‖V_genome‖ = 0.637, mean|ΔV|/mean|V_genome| = 0.757 — the difference is *large*
  (comparable to V itself), yet:
- ΔV diagonal lag-1 autocorrelation = **+0.23** — sign-coherent, not white.
- **Prediction test:** to first order the quantile shift must be γ_twin(n) − γ_gen(n) ≈
  −[S_twin − S_gen](γ)/ρ(γ), where S_twin − S_gen is supported *only* on χ(p) = −1
  primes (odd powers) and the p=3 flip. Measured over n = 1..40:
  **corr = 0.9625; rms(Δγ) = 0.113, rms(residual) = 0.032.** The between-object
  difference is ~96% explained by the twist-supported part of the Euler product.

**The amplitude finding (new, not in the work order's predictions):** V_twin is ~2.4×
smaller than V_genome entrywise, and the twin's zeros sit correspondingly closer to the
pure density law (D-alone error 0.063 vs genome's 0.080). Mechanism visible at n=1: the
genome's all-coherent prime sum pushes γ₁ from the density position 0.629 up to 0.997
(true 0.986); the twin's sum, sign-decohered on the ~half of primes with χ(p) = −1,
produces the weaker push 0.629 → 0.711 (true 0.701). **The twist decoheres the prime
sum; smaller V; zeros nearer the backbone.** Both objects' V/D ratios and both
improvement factors (7.6× vs 2.7×) are consistent with this single mechanism.

## 5. What T3 establishes (and doesn't)

Established, finite-section grade:
1. **D is class-rigid** in the strongest sense available: identical conductor+Γ ⇒
   identical D, while the two true zero lists differ throughout (0.701… vs 0.986…).
2. **V is object-identifying**: matched V predicts zeros (no zero input anywhere on the
   forward side); crossed V is worse than geometry alone.
3. **The V-difference is arithmetic, not noise**: 96%-predicted by the χ-supported Euler
   terms; the residual 0.032 is at the scale of the linearization + S_P truncation.
4. Twin Hankel/Li ledger positive to m=20 (dps 150), matching the genome's depth.

Not established: anything about zeros beyond T=6 for the twin; any infinite-section
statement; RH/GRH for either object.

## 6. Honest caveats

- **Twin zero grades:** all 21 are ~7-digit numerical (24-bit lfunzeros, T ≤ 6); j=1..11
  carry 07-02 Ξ-residual anchors (rel ≤ 7.4e-9), j=12..21 do not. No twin zero is
  certified-grade. Zero-truth enters *only* the fwd-vs-true validation and the twin
  Hankel ledger — the V-comparison itself (§4) never touches a zero list.
- **S_P truncation:** p^k ≤ 2·10⁵ for both objects. The residual 0.032 in the prediction
  test bundles linearization error and this truncation; it was not separated.
- **m-range:** sections to m=20 on 40 Euler-side atoms (both objects); fwd-vs-true
  restricted to the twin's truth window n ≤ 21. Genome numbers at the 21-atom convention
  are reported alongside for like-for-like comparison.
- **Twin Hankel tail:** T0 = 6.0 assumes the 21-zero list is complete on [0,6]
  (density predicts ~21 there; lfunzeros scan was [0,6]; not independently certified).
- If the twin ever needs high zeros: the rescaled-FFT engine ports (same conductor ⇒
  same √N budget as the genome; see `SCALING_MEMO_production_spec.md`). Out of scope here.

## 7. Files / reproduction

In `completeness_engine_2026-07-17/` (this branch):
- `operator_skeleton_twin.py` — the twin run + comparison (imports everything from
  `operator_skeleton_hdv.py`; the only new logic is the twin local factor and χ₋₇).
- `operator_skeleton_hdv.py` — one backward-compatible edit: `build_prime_data(P,
  local_factor=None)` hook (default reproduces the genome byte-for-byte; §2 rerun confirms).
- `zeros_twin_21_from_0628run.csv` — frozen 21-zero list with per-row grades/provenance.
- `t3_twin_comparison_table.csv` — per-n table (γ_D, γ_fwd both objects, truths, V
  diagonals, Δγ, Δγ-prediction).

Run: `python operator_skeleton_twin.py` (≈ minutes; deps numpy/mpmath/python-flint).

— Selina + Claude, 2026-07-17
