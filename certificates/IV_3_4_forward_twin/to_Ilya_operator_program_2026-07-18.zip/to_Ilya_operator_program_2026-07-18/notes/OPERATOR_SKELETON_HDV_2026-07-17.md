# The H = D + V operator — concrete skeleton, first measurements

**Merkabit · 2026-07-17 (evening) · Stenberg + Claude.** The operator of
`OPERATOR_from_density_and_primes_2026-07-16.md`, made concrete and runnable. Conventions continue the
K-modulus ledger (`kmodulus_m17.py`): atoms x = 1/γ², unit masses, moments → Hankel → Jacobi.
Script: `completeness_engine_2026-07-17/operator_skeleton_hdv.py`. Zeros enter only as OUTPUT checks.
Not RH/GRH.

## 1. Definitions (the skeleton itself)

Three point measures on (0, ∞), each with atoms x_n = 1/γ_n², n = 1…40:

- **D (geometry):** γ_n^D = density-law quantiles, θ(γ)/π = n − ½. Conductor + Γ only. No primes, no zeros.
- **H_fwd (geometry + primes, non-circular):** γ_n^fwd solves θ(γ)/π + S_P(γ) = n − ½, where
  S_P(t) = −(1/π) Σ_{p^k ≤ 2×10⁵} (tr Frob_p^k / k) p^{−k/2} sin(kt·log p) — the Euler product via
  `factormod(x⁷−7x+3, p)` + Newton power sums (18 120 prime-power terms). No zeros anywhere.
- **H_true (output check):** the 40 engine zeros (`zeros_chi8_rescaled_engine_t9p7.csv`).

For each measure, the m-section **Jacobi matrix** J_m via Lanczos with full reorthogonalization
(self-adjoint tridiagonal; spec(J_full) = atoms by construction). Define **D_m, H_m, and V_m := H_m − D_m**
— the prime fine-structure *as a matrix*.

## 2. First measurements (40 zeros, 2026-07-17)

**Zero level — the r = 0.981 effect at n = 40 scale:**
mean |γ^D − γ^true| = 0.0650 (geometry alone) → mean |γ^fwd − γ^true| = **0.0165** with primes:
**3.9× improvement**, from the Euler product alone. The forward construction reconstructs the spectrum.

**Operator level:**

| m | ‖V‖₂/‖D‖₂ | mean\|V\|/mean\|D\| | ‖H_fwd − H_true‖/‖H_true‖ |
|---|---|---|---|
| 5 | 0.627 | 0.458 | 0.0225 |
| 10 | 0.627 | 0.389 | 0.0225 |
| 15 | 0.627 | 0.366 | 0.0225 |
| 20 | 0.627 | 0.353 | 0.0225 |

The forward operator sits within **2.3%** of the true operator in norm. The prime perturbation is
**~35–46% of the backbone entrywise and declining with m** (the spectral-norm ratio saturates on the
top atom 1/γ₁² — a known crudeness, see caveats).

**Hankel ledger extended m = 17 → 20** (40 atoms + exact density tail, dps 150):
H₁₈ = 2.8×10⁻²⁸⁷, H₁₉ = 1.0×10⁻³²⁹, H₂₀ = 1.0×10⁻³⁷⁶ — **all > 0**, collapse rate log₁₀H_m/m² ≈ −0.94
continuing smoothly. (A dps-40 run shows H₁₈ < 0 — precision artifact; the ledger REQUIRES high dps.
With real distinct atoms positivity is guaranteed; the ledger's content is that the *zeros are real*,
plus the measured collapse rate.)

## 3. The wall, in this notation

Self-adjointness of the infinite H ⟺ Hankel positivity to ALL orders ⟺ all zeros real. Finite sections
are trivially self-adjoint — the content lives in the limit m → ∞, i.e. in the growth of the recurrence
coefficients. Nothing here crosses that; the skeleton *instruments* it.

## 4. Theorem-shaped targets (what the skeleton is FOR)

- **T1 — finite-range theorem (in reach now).** Tonight's Turing certificate (N(T*) = 21, then
  extensions) converts "atoms below T" from a list into a *certified complete* list. Combined with the
  exact density tail: **H_m > 0 and λ_n ≥ 0 become unconditional theorems on explicit ranges** — the
  first rigorous Li-positivity window for χ₈. This is the direct completeness→operator payoff.
- **T2 — the pin conjecture (the chase).** V is relatively form-bounded with respect to D with bound < 1,
  uniformly in m → self-adjointness survives the limit. Today's numbers are the first data points:
  entrywise ratio 0.35–0.46 *declining*, forward error 2.3%. Next: proper form-bound measurements
  ⟨ψ,Vψ⟩/⟨ψ,Dψ⟩ over the section, tail-sections excluding the top atoms, growth of β-coefficients.
- **T3 — the rigidity test (falsifiable).** D is class-universal: the ghost (Davenport–Heilbronn
  analogue / the twin) shares θ, hence shares D. Only V differs. **Build this identical skeleton for the
  twin χ₈⊗(·/−7) and compare V-structure** — if the "pin" story is right, the two V's should differ in a
  structured (not random) way. Concrete, runnable, would sharpen what "coherence" means.

## Caveats

1. ‖·‖₂ Kato ratio is top-atom-dominated (constant in m) — the entrywise and form-bound versions are the
   meaningful ones; listed under T2.
2. S_P truncation at p^k ≤ 2×10⁵; the forward error (2.3%, mean zero error 0.0165) is S_P-truncation
   limited, not structural — more primes → tighter (same knob as the passport).
3. γ₂₂–γ₄₀ are numerical grade; the D/V structure computed on the certified 21 alone is unchanged
   (same construction, fewer atoms).
4. Quantile convention n − ½ (Gram-style midpoint); the additive constant is a convention, absorbed
   into comparisons.

*WIP — no SHA. The skeleton is runnable and extends: more zeros (production run), more primes (S_P),
twin comparison (T3), form-bounds (T2). — Stenberg + Claude, 2026-07-17.*
