# T2 results ledger

Every entry: zero list + grade, P, m-range, tool. Negative results are results.

## 2026-07-17 — Stage 2.1: pencil κ_m, 40 genome zeros
- data: `zeros_chi8_rescaled_engine_t9p7.csv` (γ1–21 match ball-certified; γ22–40 numerical,
  η-cross-checked), P = 2×10⁵ (18,120 terms), m = 2…40, `kato_pencil.py`.
- **κ_m = 0.690 (m=2) → 0.7595 by m≈10, then FLAT through m=40. Plateau < 1, no creep.**
- table: `kato_table_zeros_chi8_rescaled_engine_t9p7.csv`.
- caveats: plateau may be top-atom-dominated (run --tail-drop variants, stage 2.1b);
  P-convergence unchecked (stage 2.3); m ≤ 40 only — production list (stage 2.2) is the
  real trend test.

## 2026-07-17 — Stage 2.1b: tail-drop variants (is the plateau top-atom-dominated?)
- data: `zeros_chi8_rescaled_engine_t9p7.csv` (γ1–21 ball-cert-matched; γ22–40 numerical,
  η-cross-checked), P = 2×10⁵, `kato_pencil.py --tail-drop {1,2,4}`, m = 2…(40−k).
- **YES — strongly top-atom-dominated.** Plateau κ: full 0.7595 → drop-1 **0.3526** →
  drop-2 **0.2549** → drop-4 **0.1889**. Each variant plateaus flat again (drop-4 has small
  steps 0.144→0.189 near m≈25, then flat). All far below 1.
- reading: the form-bound is set by the largest atoms (lowest zeros), NOT by bulk
  accumulation — κ_m does not creep with m at any drop level. Good for uniformity-in-m:
  the sup over sections is pinned by a fixed finite top block, and the tail's own ratio
  is small (≈0.19 and falling with k).
- tables: `kato_table_40zeros_taildrop{1,2,4}.csv`.

## 2026-07-17 — Stage 2.3: prime-cutoff convergence κ(P)
- data: same 40-zero genome list, tail_drop = 0, m = 2…40, P ∈ {2×10⁵, 10⁶, 5×10⁶}
  (18,120 / 78,734 / 348,940 prime-power terms).
- **κ plateau: 0.7595 (P=2e5) → 0.7596 (P=1e6) → 0.7646 (P=5e6).** Stable: total spread
  0.005 (~0.7%), non-monotone step sizes (+0.0001 then +0.0050), no trend toward 1.
- reading: κ is converged in the Euler data at the ~10⁻² level; quote κ ≈ 0.76 ± 0.01.
  No P-extrapolation needed at current precision.
- tables: `kato_table_40zeros_P{1e6,5e6}.csv` (P=2e5 baseline is the stage-2.1 table).

## 2026-07-17 — Stage 2.4: twin control (same D, twin local factors)
- data: `zeros_twin_21_from_0628run.csv` (21 zeros, ~7 digits: j=1–11 Xi-residual-anchored,
  j=12–21 numerical; zeros used ONLY for section count — quantiles are Euler-side),
  P = 2×10⁵, m = 2…21, `kato_pencil.py --twin` (new flag: passes
  `operator_skeleton_twin.twin_local_factor` into `build_prime_data`; D identical to genome
  since Γ_ℂ⁴ and N = 21¹⁰ are preserved).
- **κ_m^twin plateaus at 0.3233 by m≈10, flat through m=21 — YES, still < 1, comfortably.**
- overlay: genome κ on the same m-window is 0.7595 (flat), so κ^genome/κ^twin = 2.35 —
  numerically matching T3's ~2.4× twist-decoherence factor. Resolves the PLAN's "2.4× louder"
  wording: the twin V is 2.4× QUIETER in the pencil (decohered, as the T3 verdict said),
  not louder. The pencil ratio reproduces the T3 factor from an independent measurement.
- table: `kato_table_twin21.csv`.

## 2026-07-18 — Stage 2.5 (partial) + 2.6 pre-numerics: the window-knee test [skeleton session]
- data: NO zeros anywhere — geometry + Euler only (n_max = 40 sections to match the T2
  tables), P = 2×10⁵, `window_norm_knee.py` (new, this folder). Question (J₃(𝕆)-motivated,
  see `unbounded/doubling_test_2026-07-16/OPERATOR_J3O_result.md`): measure the empirical
  constant C_needed(w) = κ / A_w, A_w = max windowed average of |S_P| over w mean spacings,
  before any lemma exists. Does w ≈ 3 (one J₃(𝕆) block) play a role?
- **Stage 2.5 check:** V^lin (transport δ_n = −S/ρ) vs true V: pencil-level agreement
  **7.2% (full) / 4.6% (tail_drop 4)** — the form-bound is linearization-stable, and more so
  on the tail, as the synthesis predicted. Quantile-level agreement is worse (mean 27% of
  shift scale, dominated by the lowest quantiles where shifts are large) — linearize the
  TAIL, not the top block. κ(V^lin) = 0.7052 / 0.1801 vs κ(V) = 0.7595 / 0.1889.
- **The C(w) curve (tail_drop 4, the object that matters):** averaging is FREE below one
  spacing (C: 0.268 pt → 0.273 at w=1), mild to w=3 (0.330, +21%), then the cost
  accelerates (0.408 at w=4, 0.487 at w=5) and **saturates ≈ 0.56 by w = 7–10, still < 1**.
  Full-section curve has the same shape (1.08 → 1.33 at w=3 → 2.25 at w=10).
- reading: an **elbow at w ≈ 3, not a sharp knee** — 3 spacings is the last "cheap" window;
  beyond it the norm loses form-relevant information at an accelerating rate until
  saturation. And even the crudest statement survives: κ_tail = 0.19 ≤ 0.56 × A₁₀ with
  A₁₀ = 0.34 ≈ the bulk mean of |S| — an average-norm lemma is NOT empirically excluded at
  any window length tested; w ≈ 3 is where the constant is still comfortable (0.33).
- **refinement for the 2.6 question to IB:** A_w here uses |S|; the Turing/PZ machinery
  bounds SIGNED window integrals of S. Since the quadratic form pairs neighboring atoms
  with smooth weights, the form may actually consume signed averages (which are much
  smaller, by cancellation). Sharpest version: *can the transport form-bound be written
  against signed w≈3-window averages of S?* If yes, the certified Turing bounds plug in
  directly.
- tables: `window_knee_table.csv`. m ≤ 40 only — rerun at production scale when 2.2 opens
  (more S-oscillations per window is exactly where an average norm gets stronger).

## 2026-07-18 — Stage 2.2: PRODUCTION SCALE — pin conjecture REFUTED for full V; tail version survives [skeleton session]
- data: `to_Ilya_completeness_CLOSED_2026-07-18/zeros/zeros_found.csv` (149 zeros to t=28,
  numerical_anchored; complete to t=26 → truth window n ≤ 140), P = 2×10⁵,
  `t2_stage22_production.py` (computes the 149-quantile ladder once; 34 s total).
  Zeros used ONLY for section count + fwd-vs-true truth; quantiles Euler-side.
- **κ_full = 1.1822 ≥ 1, dead flat m = 20..149.** The original pin statement ("form-bound < 1
  uniformly" for ALL of V) is REFUTED at production scale — the top block pushes over 1.
  Negative result, recorded as such.
- **The refined (synthesis) version SURVIVES emphatically:** drop-1 κ = 0.4310, drop-2 =
  0.2937, drop-4 = 0.3090 — each perfectly flat m = 10..148. One atom of top-block splitting
  restores < 1; uniformity-in-m is as clean as it could be. KLMN route intact: bounded
  finite-rank V_top cannot break self-adjointness; the burden is the tail bound, measured
  0.29–0.43.
- **NEW sharpest open point — list-length growth:** tail ratios grew with atom-list length
  (drop-4: 0.189 at the 40-atom list → 0.309 at 149; drop-1: 0.353 → 0.431). Flat in m at
  fixed list, NOT yet shown convergent in list length. This is now the empirical core of T2:
  does κ_tail(list) saturate? Needs longer lists (engine can extend) or the analytic lemma.
- **Skeleton at scale:** mean|γ_fwd − γ_true| = 0.0185 over n ≤ 140, nearly height-flat
  (0.0165 / 0.0187 / 0.0198 by thirds) — the Euler-quantile scheme does not degrade with
  height. D-alone error 0.0523 (improvement 2.8×; ratio compresses as density rises).
- **Window-knee at scale** (`window_knee_production.csv`): elbow at w ≈ 3 persists
  (drop-4 C: 0.359 pt → 0.501 at w=3 → 0.775 saturated at w=15, ALL < 1). For full V,
  pointwise C = 1.37 > 1: **no norm of S can bound the top block — the ‖S‖* lemma is
  necessarily a TAIL lemma.** Measured, no longer assumed.
- tables: `kato_table_production_drop{0,1,2,4}.csv`, `quantiles_production.csv`,
  `window_knee_production.csv`, log `t2_stage22_run.log`.
- companion result (resonance side, `unbounded/resonance_spectrum_2026-07-18/`): with the
  production zeros the overtone lines RESOLVE — Frobenius coefficients read off the zero
  list at ~1% (12 interior lines, corr 0.99987, rms 0.0076; ramified 7 reads 0.002 ≈ 0).

## pending gates
- 2.2b: κ_tail(list-length) saturation — extend the zero list (engine ports; or rerun at
  t₂ > 28 later) and track drop-k plateaus vs N_atoms. THE empirical question now.
- 2.5: linearized-V note (pencil-level check done 07-18 AM; entrywise note pending).
- 2.6: ‖S‖* lemma question → Ilya — now sharpened THREE ways: tail-only (mandatory, measured),
  signed vs |S| windows, w ≈ 3 elbow (persists at production scale).

## 2026-07-18 — Stage 2.2b: kappa_tail vs list length (prefix scan of the production ladder)
- data: quantiles_production.csv (149-quantile ladder, Euler-side), prefixes N = 40..149,
  drop-k in {1,4,8}. Zeros used nowhere (ladder is geometry+primes).
- **NOT saturated in range.** drop1: 0.353→0.431; drop4: 0.189→0.309; drop8: 0.168→0.252
  (last step negative). Per-e-fold slope ≈ 0.06–0.09 — consistent with slow LOG growth
  (naive extrapolation reaches 1 near N ~ 1e5–1e7 atoms), equally consistent with
  saturation just beyond range (1.3 e-folds measured — cannot distinguish).
- **Correct next object (not more N yet): the KLMN (a,b) frontier.** KLMN allows
  <Vpsi,psi> <= a<Dpsi,psi> + b|psi|^2 — additive b absorbs growth. If the observed drift
  is a b-term (per-mode bounded), the pin survives with a < 1 fixed; if it is genuinely
  multiplicative (a grows), the tail lemma needs an N-dependent structure. Measure the
  frontier: for each N, min over b of max-eig((V - b)· pencil ...) — i.e., a(b) curve.
- 2.2b remains open pending (i) the (a,b) frontier fit, (ii) longer lists (t2 > 28 run).

## 2026-07-18 — Stage 2.2b-frontier: the KLMN (a,b) frontier — the drift is b-TYPE (absorbable)
- data: `quantiles_production.csv` (149-quantile ladder, Euler-side, P = 2×10⁵ inherited from
  stage 2.2; zeros used nowhere), prefixes N ∈ {40,60,80,100,120,140,149}, drop-k ∈ {1,4},
  full-section pencil m = N−k, `t2_stage22b_frontier.py`. Frontier is TWO-SIDED (KLMN needs
  |⟨Vψ,ψ⟩| ≤ a⟨Dψ,ψ⟩ + b‖ψ‖²): a(b) = max over ±V of λ_max(L⁻¹(±V − bI)L⁻ᵀ), D = LLᵀ,
  b subtracted in the original coordinates before Cholesky; both branches monotone ↓ in b,
  b_needed(a) by bisection (tol 1e-6). Sanity: a(0) reproduces the 2.2b κ values exactly.
- **VERDICT: b-type.** At fixed moderate b* the drift is GONE — a(b*) across N = 40→149:
  drop1 b*=0.01: 0.3022→0.2993 (slope −0.0026/e-fold); b*=0.03: 0.2647→0.2637 (−0.0008);
  b*=0.1: 0.1729→0.1732 (+0.0002). drop4 b*=0.01: 0.0244→0.0241 (−0.0002). Compare the
  b=0 slope +0.06–0.09/e-fold: the entire N-drift lives in the additive term.
- **b_needed is bounded and NON-INCREASING in N.** drop1, a=0.3: b = 0.01084 (N=40) →
  0.00974 (N=149), fit slope −0.00096/e-fold; a=0.5: b = 0 for all N. drop4: b = 0 for
  a=0.3 through N=140 (0.00004 at 149), 0 everywhere for a=0.5. Fixed pairs working for
  ALL N measured: (a,b) = (0.3, 0.011) at drop1; (0.3, 0.0001) at drop4.
- scale of b: tiny. The knee of a(b) sits at b ~ D_min = 1/γ_N² (0.0013 at N=149): drop4
  N=149 a: 0.309 (b=0) → 0.199 (b=0.001) → 0.024 (b=0.01). b = 0.001 is below the SMALLEST
  atom in the section — the drifting modes live where D itself vanishes, exactly the modes
  an additive b dominates. Mechanism, not accident.
- branch note: drop1's binding side is the NEGATIVE branch (−⟨Vψ,ψ⟩) at all N; drop4's is
  positive at small b and flips to negative by b = 0.01. Recorded in the curves table.
- reading: the pin conjecture in proper KLMN form — ∃ fixed a < 1, b < ∞ with
  |⟨Vψ,ψ⟩| ≤ a⟨Dψ,ψ⟩ + b‖ψ‖² uniformly in section — is SUPPORTED at production scale with
  a = 0.3, b ≈ 0.01. The stage-2.2b "not saturated" alarm is defused: κ_tail(N) growth is
  an artifact of forcing b = 0. The ‖S‖* tail lemma (2.6) should target the PAIR (a,b),
  which is a strictly weaker (and now empirically flat) object than κ alone.
- caveat: 1.3 e-folds of N measured, as before — but unlike κ(N), b_needed(N) is flat-to-
  falling with no growth to extrapolate; a longer list (t₂ > 28) would upgrade this from
  "no drift in range" to a real saturation claim. Grade: numerical, float64 pencil.
- tables: `frontier_ab_curves.csv` (full a(b) grid, 16 b-values × 14 sections),
  `frontier_b_needed.csv`; log `t2_stage22b_frontier_run.log`.

## pending gates (updated after 2.2b-frontier)
- 2.2b(ii) longer lists: still worthwhile but DOWNGRADED from "THE empirical question" —
  the frontier answer removes the urgency; rerun the frontier (not bare κ) when a t₂ > 28
  list exists.
- 2.5: linearized-V entrywise note (pencil-level check done 07-18 AM).
- 2.6: ‖S‖* lemma question → Ilya — now sharpened FOUR ways: tail-only, signed vs |S|
  windows, w ≈ 3 elbow, and target the (a,b) PAIR with b ~ D_min rather than pure a.
