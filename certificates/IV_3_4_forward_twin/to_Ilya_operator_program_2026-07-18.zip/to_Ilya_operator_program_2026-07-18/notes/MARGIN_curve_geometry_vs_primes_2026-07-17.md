# The margin curve — geometry's positivity vs the prime pull

**Merkabit · 2026-07-17 · Stenberg + Claude.** Step #1 of the operator program: turn "does H = D + V stay
self-adjoint (Hankel positive) forever" into a *measured competition*. In Li-coefficient form,
`λ_n = λ_n^arch + λ_n^fin`, RH ⟺ `λ_n ≥ 0 ∀n`; `λ^arch` is the geometry (D, conductor+Γ, no primes),
`λ^fin` the primes (V, Euler). We computed the curve. Plot: `scratchpad/margin_curve.png`.

## Method

- **`λ_n^arch` (geometry) — EXACT.** From `log(Q^{s/2}γ(s))` at s=1: `λ_n^arch = n(½logQ + h'(1)) +
  4·Σ_{m=2}^n C(n,m)(−1)^m ζ(m)`, with `Q=21¹⁰`, `h'(1) = −4(log2π + γ)` (the `Γ_ℂ⁴` factor, μ=[0⁴,1⁴];
  `h^{(m)}(1)=4(−1)^m(m−1)!ζ(m)` for m≥2). No primes, no zeros.
- **`λ_n^total` — from the 21 certified zeros:** `Σ_γ 2(1−cos(nφ_γ))`, `φ_γ=π−2arctan(2γ)`. Partial sum.
- **`λ_n^fin = λ_n^total − λ_n^arch`** — the prime pull, trustworthy only in the zero-reliable band.

## Result

| n | λ^arch (geom) | λ^total (zeros) | λ^fin (prime pull) | \|fin\|/arch |
|---|---|---|---|---|
| 1 | 5.56 | 3.31 | −2.26 | 0.41 |
| 3 | 31.62 | 22.71 | −8.91 | **0.28** (min) |
| 5 | 63.03 | 39.85 | −23.18 | 0.37 |
| 8 | 115.94 | 53.62 | −62.32 | 0.54 |
| 11 | 173.46 | 61.42 (peak) | −112.03 | 0.65 ← turnover begins |

- **Geometry margin `λ^arch`: exact, positive, grows ~ n log n.** Unconditional. Generous absolutely.
- **Prime pull `λ^fin`: negative**, magnitude ~⅓–½ of the geometry margin in the reliable band.
- **Erosion ratio `|fin|/arch`: minimum 0.28 at n=3, then climbs.** Geometry dominates by ~2–3× in range
  — the margin holds (RH in range) but is *not* comfortable: exactly the knife-edge (⟨a²⟩=1, Λ=0).

## Honest caveats

1. **The rise past n≈8 is confounded.** With only 21 zeros, `λ^total` under-counts (peaks n≈11 then
   turns over), which *inflates* the apparent prime pull. The clean signal is **n ≲ 8** (ratio 0.28–0.54);
   the apparent climb toward 1 beyond that is partly a partial-sum artifact, not established trend.
2. **The direct prime-sum route to `λ^fin` DIVERGES.** `g^{(m)}(1)=Σ_{p,k} t_{p^k}(−log p)^m k^{m−1}p^{−k}`
   grows ~10^m and disagrees between P=10⁵ and 10⁶ for m≥3 (conditional convergence at s=1, truncation
   error ~(log P)^m). This is *why* Li coefficients are computed from zeros — and it means the prime
   fluctuation is the genuinely intractable term. **That is the wall, located precisely.**

## What it establishes and what's next

**Establishes:** the geometry-vs-primes competition is now an actual curve. Geometry provides a growing
positive margin; the primes eat ~a third of it in range — the knife-edge, quantified. RH ⟺ the erosion
ratio stays below 1 to all orders.

**The measurable crux:** does the true erosion ratio **stabilize below 1** (evidence RH holds) or **climb
to 1** (knife-edge tightening)? Undecidable from 21 zeros — the clean band ends at n≈8. **Extending the
certified zeros (γ22–25, overnight run) pushes the turnover up and lengthens the clean curve** — the one
concrete measurement that would show the trend. This is the direct payoff of the AWS run into the operator
program.

*WIP — no SHA. Step #1 of the H=D+V operator program (`OPERATOR_from_density_and_primes_2026-07-16.md`).
`scratchpad/{compute_margin.py,margin_plot.py,compute_lifin.gp}`. Measures the crux; does not cross it.
Not RH/GRH. — Stenberg + Claude, 2026-07-17.*
