# T1 — Finite-range positivity for L(s,χ₈): Hankel ledger to m = 40 and a Li lower bound to n = 150

**Merkabit · 2026-07-18 · Stenberg + Claude.** Executes target **T1** of
`OPERATOR_SKELETON_HDV_2026-07-17.md` — the direct completeness→operator payoff. Inputs: the
completeness verdict **N(T\*) = 21** (T\* = 5.969, certified at t₂ ∈ [25, 26.5], grade
**numerical_anchored**; `to_Ilya_completeness_CLOSED_2026-07-18`) and the production zero list
`zeros/zeros_found.csv`, whose **140 zeros below t = 26 form the complete-in-range set** (γ₁–γ₂₄
ball-certified; γ₂₅–γ₁₄₀ numerical grade). Scripts + full tables:
`unbounded/T1_positivity_2026-07-18/` (`t1_hankel_ledger.py`, `t1_li_positivity.py`, two CSVs, logs).
Conventions: K-modulus ledger (`kmodulus_m17.py`) and margin-curve method
(`completeness_engine_2026-07-17/compute_margin40b.py`). **Not RH/GRH** — certified-in-range
statements with explicit grades, plus one worst-case bound that needs *no* assumption above t = 26.

## 0. The input evidence chain, graded

| input | grade | source |
|---|---|---|
| γ₁–γ₈ positions | CERTIFIED_EXACT | ECL low-zero table (master CSV) |
| γ₉–γ₂₄ positions | CERTIFIED_BALL (brackets) | s26b/Channel-B + γ₂₂₋₂₄ package 07-18 |
| γ₂₅–γ₁₄₀ positions | numerical (η-checked ~10⁻⁵) | rescaled-FFT production run 07-18 |
| completeness below T\* = 5.969 (N = 21) | **numerical_anchored** (Turing/PZ, 4 t₂'s, margins +0.80…+2.34) | completeness_CLOSED package |
| completeness (T\*, 26] | numerical (list tracks Φ to \|S\| ≤ 0.7) | production log / cover, gap analysis |
| zeros above t = 26 | **no assumption** in the Li lower bound; mean density + slack for counting only | — |

Position accuracy, measured: the production list agrees with the 8 exact-certified zeros to
**≤ 3.7×10⁻¹⁰**; every error budget below charges δγ = 10⁻⁵ per zero (≥ 2.7×10⁴× headroom).

## 1. Deliverable 1 — the K-modulus Hankel ledger, m ≤ 20 → **m ≤ 40**

Measure: μ = Σ_{γ ≤ 26} δ_{1/γ²} (140 unit atoms) **+ exact density tail above t = 26**:
S_k = Σ γ^{−2k} + ∫₂₆^∞ ρ(t) t^{−2k} dt, ρ(t) = (1/2π)(log N + 8 log(t/2π)), N = 21¹⁰, by the
exact antiderivative (kmodulus convention). H_m = det[S_{i+j−1}]. Main ladder **dps 2000**,
verification ladder dps 2300 (the collapse warning ~10^{−0.94 m²} taken seriously: dps ≥ 40m at m = 40,
and in fact ~50× the naive need — see precision audit).

| m | H_m (140 + tail 26) | log₁₀H_m/m² | 21z+tail vs 140z (%) |
|---|---|---|---|
| 5 | 1.789×10⁻⁸ | −0.310 | 0.03 |
| 10 | 6.012×10⁻⁶² | −0.612 | 0.10 |
| 15 | 5.974×10⁻¹⁸⁰ | −0.797 | 0.43 |
| 17 | 2.853×10⁻²⁴⁸ | −0.857 | 0.02 |
| **20** | 1.001×10⁻³⁷⁵ | **−0.9375** | 0.02 |
| 25 | 1.369×10⁻⁶⁵⁹ | −1.054 | 0.25 |
| 30 | 2.670×10⁻¹⁰³⁷ | −1.152 | 5.6 |
| 35 | 2.029×10⁻¹⁵¹⁵ | −1.237 | 9.5 |
| **40** | 3.024×10⁻²¹⁰⁰ | **−1.312** | 35.2 |

**All H_m > 0, m = 1…40** (also in the no-tail and 21-atom ladders; full table in
`t1_hankel_ledger_results.csv`). Readings:

- **Continuity anchor:** at m = 20 the collapse rate is −0.9375 — the skeleton note's −0.94
  (40 atoms + tail 9.7) reproduced on the certified-complete measure; H₂₀ itself lands within one
  order (10⁻³⁷⁵ vs 10⁻³⁷⁶).
- **The new measurement:** the collapse is **not a pure 10^{−0.94 m²} law** — the global ratio
  log₁₀H_m/m² steepens smoothly from −0.61 (m = 10) to −1.31 (m = 40); the local increment at
  m = 39→40 is −125.6 digits over Δ(m²) = 79, i.e. **−1.59 per unit m²** locally. The richer measure
  (140 atoms, denser spacing) collapses faster than the 40-atom section did. This is a direct probe
  of the recurrence-coefficient decay — T2's object — now measured over 4× the previous m-range.
- **Truncation-safe band for the values:** the 21-atom + tail(5.9695) ledger reproduces the 140-atom
  ledger to ≤ 1.7% through **m ≤ 24** (oscillating, mostly ≪ 1%), degrading to 5.6% at m = 30 and
  35% at m = 40. So values through m ≈ 24 stand on the ball-certified 21 alone (margin-note style);
  m = 25–40 values are 140-list measurements (numerical grade), positivity unaffected.
- The tail is load-bearing: at m = 40 the with-tail determinant exceeds the no-tail one by 17 orders —
  the completeness cut at t = 26 + exact antiderivative is what makes the measure canonical rather
  than list-truncated.

**Precision audit.** dps-2000 and dps-2300 ladders agree to relative ~10⁻¹⁸⁷² at m = 40: the Hankel
LU loses only ~130 digits, not the naive 2100 (pivots = H_m/H_{m−1} shrink gradually; the Stieltjes
structure keeps each step's relative condition moderate). Jittering every γ by ±10⁻⁶ (alternating)
moves H_m by ≤ 1.4×10⁻⁴ relative — consistent with the all-positive-terms expansion of a Stieltjes
Hankel det in distinct atoms; **the signs are nowhere near threatened by zero-position error**.
Implementation cross-check: the 11-zero legacy run reproduces the kmodulus_m17 note's corner ranges
(H₇ = 6.910×10⁻²⁷ ∈ [6.884, 6.935]×10⁻²⁷; H₁₁ = 5.76×10⁻⁹⁴ ∈ [5.574, 5.955]×10⁻⁹⁴).

*What is a theorem here:* for **real distinct atoms plus a positive density tail, H_m > 0 is
automatic to all orders** — positivity itself is not the discovery. The theorem-grade content is
(i) the atoms **are** real: ball-certified for j ≤ 24, numerical for the rest, complete-in-range at
the stated grades; and (ii) the measured values and collapse law, which quantify how fast the
Jacobi/recurrence data of the genome measure degenerates — the quantity T2's form-bound has to beat.

## 2. Deliverable 2 — tail-corrected Li positivity to n = 150, with an unconditional-shaped lower bound

λ_n = Σ_ρ [1 − (1 − 1/ρ)ⁿ] over all nontrivial zeros of Λ(s,χ₈). For an on-line pair ρ = ½ ± iγ the
contribution is 2(1 − cos nφ(γ)) ≥ 0, φ(γ) = 2 atan(1/(2γ)). Three quantities per n
(`t1_li_positivity_results.csv`, n = 1…150):

- **P₁₄₀(n)** — partial sum over the 140 complete-in-range zeros (each term ≥ 0);
- **λ̂_n = P₁₄₀(n) + tail(n)** — the margin-note estimate, tail = ∫₂₆^∞ 2(1 − cos nφ(g)) θ′(g)/π dg
  (exact smooth density, quadrature to ∞);
- **LB(n) = P₁₄₀(n) − E_off(n) − slack(n) − sens(n)** — the lower bound (below).

**The worst-case off-line tail bound (the theorem-shaped step).** A hypothetical off-line quadruple
{β ± it, 1−β ± it} contributes ≥ 4 − 2(rⁿ + r⁻ⁿ) ≥ −4(cosh(n δ(t)) − 1) with
|log r| ≤ δ(t) = ½ log(1 + 1/t²) (maximized over β ∈ [0,1], i.e. anywhere in the strip). Charging the
**entire** mean density above 26 as off-line quadruples (2 upper zeros each):

  E_off(n) = ∫₂₆^∞ 2(cosh(n δ(t)) − 1) θ′(t)/π dt,

plus slack(n) = five extra worst-placed zeros at t = 26 (observed count fluctuation \|S\| ≤ 0.7;
5 is generous), plus sens(n) = n·10⁻⁵·Σ 2/(γ²+¼) for zero-position error. **E_off needs no
information about where zeros above 26 actually are.**

| n | λ_arch | λ̂_n (140+tail) | 21-vs-140 agree | P₁₄₀ | E_off | **LB** |
|---|---|---|---|---|---|---|
| 1 | 5.56 | 4.32 | 0.001% | 4.01 | 3×10⁻⁵ | **4.01** |
| 5 | 63.03 | 64.75 | 0.003% | 57.13 | 0.0008 | **57.13** |
| 12 | 193.41 | 193.31 | 0.016% | 149.64 | 0.005 | **149.63** |
| 25 | 476.37 | 474.61 | 0.055% | 288.36 | 0.021 | **288.34** |
| 50 | 1091.40 | 1088.34 | 0.075% | 391.26 | 0.084 | **391.17** |
| 56 | 1247.75 | 1252.17 | 0.091% (worst) | 396.70 | 0.105 | **396.59** |
| 100 | 2460.06 | 2456.79 | 0.048% | 256.90 | 0.335 | **256.53** |
| 150 | 3933.37 | 3922.97 | 0.034% | 228.79 | 0.755 | **227.97** |

**Result: LB(n) > 0 for every n = 1, …, 150.** Minimum LB(1) = 4.01; LB(n) ≥ 14.7 for n ≥ 2;
P₁₄₀ stays in [215, 397] for n ≥ 50 while E_off + slack + sens reaches only 0.83 at n = 150 —
a **~270× margin** at the band edge.

**Theorem L (finite-range Li positivity, numerical_anchored).** *Assume (i) the 140-entry list is
exactly the set of zeros of Λ(s,χ₈) with 0 < Im ρ < 26 [completeness: certified N(T\*) = 21 at
numerical_anchored grade; (T\*, 26] at numerical grade, \|S\| ≤ 0.7]; (ii) each listed zero lies on
Re s = ½ [ball-certified j ≤ 24, numerical j = 25…140] with position error ≤ 10⁻⁵ [measured
≤ 4×10⁻¹⁰ on the exact-certified overlap]; (iii) the upper-half zero count above t = 26 does not
exceed the mean θ′/π by more than 5 zeros in the worst position [observed \|S\| ≤ 0.7 to t = 26].
Then, with NO assumption on where the zeros above t = 26 lie in the strip,*

  **λ_n ≥ LB(n) > 0 for all 1 ≤ n ≤ 150.**

*Grade: inherits numerical_anchored from (i); every other term in the budget is either
ball-certified, measured with ≥ 10⁴× headroom, or a rigorous inequality (the E_off derivation and
term-positivity are unconditional mathematics).*

This is the first Li-positivity window for χ₈ that is **one-sided safe in every direction**: a
missed on-line zero below 26 only *raises* λ_n; an off-line intruder below 26 is excluded by the
count (grade of (i)); off-line zeros above 26 are already charged at their worst. The estimate
λ̂_n additionally tracks λ_arch to ≤ 3.7% for n = 3…10 and **≤ 0.76% for every n = 11…150**
(n = 1, 2 keep the margin note's 22%/10% — small-n is arch-dominated by construction) — the
margin-curve "erosion ≈ percent-level oscillation" story now extends 6× beyond the old n ≤ 25 band,
tightening rather than eroding as n grows.

**Truncation-safe band, internal check.** The 21-certified-only curve (tail cut 5.9695) reproduces
the 140-zero curve to **≤ 0.091% at every n ≤ 150** (worst at n = 56) — two zero sets, two cutoffs,
same answer; the estimate stands on the ball-certified 21 alone at that accuracy. The check bounds
the *resolved* fluctuation (5.97 → 26); for the estimate's absolute accuracy above 26 only the mean
density is available (fluctuation unresolved — same caveat as the margin note). The lower bound LB
does not use the tail estimate at all, so its validity band is the full n ≤ 150.

## 3. Error budget (worst case over the band, evaluated at n = 150)

| term | size | how bounded | grade |
|---|---|---|---|
| P₁₄₀ arithmetic | < 10⁻²⁰ rel | finite sum, dps 30 | rigorous given inputs |
| zero positions → sens(n) | 0.012 | n·δγ·Σ2/(γ²+¼), δγ = 10⁻⁵ (measured 4×10⁻¹⁰) | measured + 10⁴× headroom |
| off-line tail → E_off(n) | 0.755 | cosh-quadruple bound, all density charged | unconditional inequality vs mean count |
| count slack above 26 | 0.062 | 5 worst zeros at t = 26 (obs. \|S\| ≤ 0.7) | numerical_anchored |
| tail quadrature (λ̂ only) | ~10⁻²⁹ rel | two independent node systems agree | verified |
| Hankel dets precision | ~10⁻¹⁸⁷² rel | dps 2000 vs 2300 ladders | verified |
| Hankel zero-error | ≤ 1.4×10⁻⁴ rel | ±10⁻⁶ jitter ladder | measured |
| completeness below 26 | one-sided | missed on-line zero ⇒ λ_n larger | structural |

## 4. Bonus: the margin note's −0.0067·n² "boundary term" is resolved

`MARGIN_curve_UPDATE_40zeros_tailcorrected_2026-07-17.md` §3 reported
∫₀^∞ w_n dens = λ_arch − 0.0067 n² and flagged the n² residual as underived (caveat 3). Identified:
it is the **[2000, ∞) truncation of compute_margin40b's quadrature**. The missing piece is
∫₂₀₀₀^∞ 2(1 − cos nφ) ρ dg ≈ n² ∫₂₀₀₀^∞ ρ/g² dg = 0.00673 n² (exact antiderivative), and direct
quadrature confirms: 0.0606 / 0.4306 / 0.9689 / 4.205 at n = 3/8/12/25 vs 0.0067n² =
0.0603 / 0.429 / 0.965 / 4.19. The present tables integrate to ∞ (nodes per quarter-oscillation,
cross-checked against a dense geometric ladder to 10⁻²⁹), and correspondingly λ̂_n shows **no n²
drift against λ_arch**. Margin-note caveat 3 can be closed; its λ̂ values carry a −0.0067n² bias
(0.9% at n = 25) that does not affect any of its conclusions.

## 5. What is unconditional vs numerical — plainly

- **Unconditional mathematics:** the E_off quadruple inequality; term-positivity of on-line
  contributions; H_m > 0 for any positive measure with enough support; the exact tail
  antiderivatives; the density sanity θ-count.
- **Ball-certified:** γ₁–γ₂₄ on-line locations (brackets); the arb kernel of the engine (ladder step 1).
- **Numerical_anchored:** the completeness verdict N(T\*) = 21 and the counting slack — **the
  load-bearing assumption of Theorem L**; it is not yet ball arithmetic, and the theorem says so.
- **Numerical:** γ₂₅–γ₁₄₀ (float64 sign changes, η-checked); the (T\*, 26] gap analysis.
- **The one sign-critical numerical lean:** excluding an off-line intruder *below* 26 rests on the
  count tracking (an extra quadruple would shift S by +2 against observed \|S\| ≤ 0.7). Everything
  above 26 is worst-cased; everything on-line is one-sided.

**Upgrade path (bounded engineering, no new ideas needed):** rigor-ladder steps 2–6
(`engine/SCALING_MEMO` §5) promote (i) to ball-certified ⇒ Theorem L becomes a fully rigorous
computer-assisted theorem on its stated band; folding an explicit unconditional S(t) bound (the
genome is a Hecke L-function — Ilya's monomiality certificate — so standard Riemann–von Mangoldt
machinery applies) replaces assumption (iii); the ~270× margin absorbs both replacements. Extending
the band: P₁₄₀ oscillates around 2·140 = 280 while E_off grows ~n² from 0.755 — the crossover is
roughly n ~ 2×10³, so n ≤ 150 is deeply conservative; more n is only compute.

## 6. Honest caveats

1. **Not RH/GRH**, and not close: this is positivity on an explicit finite band from an explicit
   finite certified region. The Li criterion needs all n; the band grows only as fast as certified
   completeness grows (linearly in hardware, per the ladder).
2. Theorem L's grade is capped by its weakest input — completeness, numerical_anchored. Calling it
   "theorem-shaped" rather than "theorem" until ladder steps 2–6 land is deliberate.
3. The λ̂_n *estimate* above t = 26 uses the mean density; unresolved S-fluctuation above 26 is not
   bounded by the 21-vs-140 check (which only resolves 5.97→26). The *lower bound* is immune by
   construction.
4. Hankel positivity is automatic given real atoms — §1 claims measurements (values, collapse law,
   robustness), not a positivity discovery. The m = 25–40 values depend on the numerical-grade
   γ₂₅–γ₁₄₀ at the several-% level (agreement column); signs do not.
5. slack = 5 zeros is a chosen generosity (7× the observed \|S\|); it is not derived from an
   unconditional S-bound. See upgrade path.
6. The production list's own cover notes ~4 guard-dropped zeros in (26, 28] — irrelevant here by
   construction (cut at 26), but it is why the cut is 26 and not 28.

## Reproduction

`unbounded/T1_positivity_2026-07-18/`: `t1_hankel_ledger.py` (~50 s total: five ladders, dps
2000/2300, mpmath 1.3.0) and `t1_li_positivity.py` (~10 min: n = 1…150, dps 30, arch sums at
workdps 0.4n+40); outputs `t1_hankel_ledger_results.csv` (m = 1…40, all ladders + audits),
`t1_li_positivity_results.csv` (n = 1…150, all columns incl. E_off/slack/sens/LB), run logs.
Inputs read-only from the sealed completeness package.

*WIP — no SHA. T1 of the skeleton executed: the completeness certificate converted into (1) a
Hankel ledger at 2× the m-frontier with a measured collapse law and (2) the first one-sided-safe
Li-positivity window for χ₈, n ≤ 150 with ~270× margin at the edge. T2's question — whether the
recurrence decay measured in §1 admits a uniform form-bound — is unchanged and now better
instrumented. — Stenberg + Claude, 2026-07-18. Shared-credit conventions.*
