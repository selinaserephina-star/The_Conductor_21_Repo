# T2 — the pin conjecture: execution plan (gated on incoming data)

**Merkabit · Stenberg + Claude · 2026-07-17.** T2 from `unbounded/OPERATOR_SKELETON_HDV_2026-07-17.md`:
**V relatively form-bounded by D with bound < 1, uniformly in section size** ⇒ (KLMN) self-adjointness
survives the m→∞ limit. This folder is the standing plan; each stage has a GATE (what data must exist),
an ACTION (runnable), and a DELIVERABLE. Execute stages as gates open — any session can pick one up.
Working folder — no SHA until something ships. Not RH/GRH.

Context notes: T3 verdict (V object-identifying, D_twin ≡ D_genome, twist decoheres V 2.4×) in
`T3_twin_skeleton_2026-07-17/`. Engine + skeleton: `completeness_engine_2026-07-17/` (worktree
`ilya-riemanns-completeness-452d5d`). Certified-zero master: `chi8_certified_zeros_MASTER_2026-07-14/`.

---

## Stage 2.1 — pencil κ_m on current data   [GATE: none — ready now]
ACTION: `python kato_pencil.py <zeros.csv> [--tail-drop k] [--P 200000]` (this folder; needs
numpy/mpmath/flint + `operator_skeleton_hdv.py` importable — copy in `T3_twin_skeleton_2026-07-17/`).
Computes the true form-ratio κ_m = max eig of the pencil Vψ = λDψ (Cholesky-reduced), m = 2..len(zeros),
plus tail-section variants (drop top-k atoms) to kill top-atom domination.
DELIVERABLE: `kato_table_40zeros.csv` + 3-line reading in `RESULTS.md` (κ_m plateau vs creep).

## Stage 2.2 — κ_m at production scale   [GATE: turing_run verdict + zeros_found.csv, ~210 zeros to t=28]
The single highest-value T2 measurement. When `completeness_engine_2026-07-17/turing_run_results/`
lands (see `aws_retrieve_turing.sh`):
ACTION: rerun `kato_pencil.py turing_run_results/zeros_found.csv` → κ_m to m ≈ 100–200.
Also rerun `operator_skeleton_hdv.py` pointing at the production list (fwd-error and V/D at scale).
DELIVERABLE: `kato_table_production.csv`; the κ_m(m) curve is T2's first real trend line.
NOTE: production zeros are numerical grade until the ball-certified upgrade; record grade in RESULTS.

## Stage 2.3 — prime-cutoff convergence   [GATE: none — ready; ~30 min compute]
Is the measured κ converged in the Euler data?
ACTION: `kato_pencil.py <zeros> --P 200000 | 1000000 | 5000000` (flint factoring ~31 µs/prime; 5e6 ≈ 11 s
of factoring, S_P eval cost grows linearly in terms).
DELIVERABLE: κ_m(P) stability column in RESULTS; if drifting, quote the P-extrapolated value.

## Stage 2.4 — twin control   [GATE: none — T3 artifacts exist]
ACTION: `kato_pencil.py` with the twin local-factor hook (see `T3_twin_skeleton_2026-07-17/
operator_skeleton_twin.py`) on `zeros_twin_21_from_0628run.csv`. Same D — clean comparison.
DELIVERABLE: κ_m^twin vs κ_m^genome overlay. Question: does the 2.4× louder V still sit below 1?

## Stage 2.5 — linearized V (the forward formula)   [GATE: none — math, no compute]
Write the transport form: δ_n = −S(γ_n^D)/ρ(γ_n^D), V^lin = d/dε J[μ_D + ε·shift]. Verify numerically
V^lin ≈ V (entrywise, current data). This is the object the analytic lemma will bound.
DELIVERABLE: `LINEARIZED_V_note.md` + a check cell in kato_pencil (--linearized flag, later).

## Stage 2.6 — the ‖S‖* lemma (the bridge; involve Ilya)   [GATE: 2.1–2.5 give the empirical shape]
Target lemma: form-bound of V^lin ≤ C·‖S‖* with ‖S‖* a WINDOWED-AVERAGE norm — because the
unconditional Turing/PZ machinery (π∫S ≤ B = 57.89, the same constant the completeness cert uses)
bounds AVERAGES of S, not pointwise values. If the lemma closes with an average norm, the completeness
engine's bounds become unconditional inputs to self-adjointness. Sharp question for Ilya:
*what is the weakest average norm of S that controls the quantile-transport form-bound?*
DELIVERABLE: joint note / problem statement; then T2a below.

## SYNTHESIS after 2.1b/2.3/2.4 (2026-07-17 evening) — read before 2.5/2.6
The measurements impose a decomposition: **V = V_top (fixed finite block, the lowest zeros) + V_tail**,
with κ(V_tail) ≈ 0.19 and *falling* with the drop level, flat in m everywhere; κ converged in P
(0.76 ± 0.01); twin pencil reproduces the 2.4× decoherence independently. Consequences:
- **Finite-rank triviality:** V_top can never break self-adjointness in the limit — the entire KLMN
  burden is on V_tail. T2 = "bound the TAIL form-ratio < 1 uniformly," measured at ~0.19.
- Stage 2.5 should linearize the TAIL (where δ_n = −S/ρ transport is most accurate — small shifts,
  dense spectrum), and 2.6's ‖S‖* lemma should target tail sections: averaged-S norms are natural
  exactly there (many quantiles per S-oscillation).
- Production κ_m (stage 2.2) should be run with the same tail-drop grid {0,1,2,4} to confirm the
  top-block stays FIXED as m grows (the uniformity claim's empirical core).

## Theorem targets (the point of all of it)
- **T2a (weeks):** certified κ_m < 1 on explicit m-ranges — completeness certificate + certified ∫S
  + interval arithmetic on the pencil. First rigorous finite-range self-adjointness for χ₈.
- **T2b (prize-shape):** "windowed S-averages ≤ c₀ ⇒ Hankel positivity to all orders." Likely
  RH-equivalent — the value is exposing exactly what the PSL(2,7)/twist rigidity must supply (T3's
  structure result is the input slot).

## Standing rules
- Every RESULTS entry records: zero list used + its grade, P, m-range, dps.
- Negative/flat results are results — record them.
- The wall is not evaded anywhere here; stages shrink the unproven part to one inequality.
