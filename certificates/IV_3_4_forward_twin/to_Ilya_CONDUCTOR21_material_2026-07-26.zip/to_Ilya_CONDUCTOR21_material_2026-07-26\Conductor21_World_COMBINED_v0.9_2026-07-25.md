# The Conductor-21 World

*Stenberg · Balashov — shared work; authorship details open and not final.*


### A Self-Similar L-function Family of PSL(2,7): the Anatomy of Its Wall, the Certified Envelope, and the Finite Machine

**Selina Stenberg** · Merkabit Research
**Ilya Balashov** · ORCID 0009-0001-1954-8872 · OSF [10.17605/OSF.IO/3TFNY](https://doi.org/10.17605/OSF.IO/3TFNY)
*Computational work performed with Claude (Anthropic).*
**Draft — June 2026; expanded July 2026 (Parts III–IV). v0.9 — 2026-07-25 (Stenberg + Claude
upgrade pass, from v0.8 frozen 2026-07-12).**

> **What changed in v0.9 (2026-07-13 → 07-25).** (i) Part III is rewritten to the
> **certified-spectrum era**: 152 ball-certified zero brackets on $[0,27.92]$ and **CERTIFIED**
> one-sided Turing counts $N^+(5.969)=21$, $N^+(6.55)=24$ (§C.8.1b), produced by the rescaled-FFT
> completeness engine, superseding the seventeen/twenty-one-zero tables (kept in dated notes).
> (ii) A new zero-free analytic layer: the **unconditional pointwise $|S(t)|$ bound** for $\chi_8$
> off Palojärvi–Zhao Thm 2.3 (§C.8.3). (iii) Parts II and IV now **cite the operator trilogy**
> (Paper A, the finite-section engine; Paper B, the $H=D+V$ companion; the Aion Reformulation
> Lemma R-011a) instead of pre-echoing it. (iv) The REV5 registry reconciliation (2026-07-13) is
> folded in (T8 point/line closure; assembly conditional only on $b_8$; $H_1/H_2$ orientation
> resolved). (v) Honest ledgers (§B.11, §C.9, §D.10, Conclusion) are flipped with dated brackets.
> (vi) IB's exact-$\mathbb Q$ certified geometry-bridge chain (2026-07-18→20) is **staged, not yet
> integrated** — see the [v0.9 note] markers. No RH/GRH claim is made anywhere, as before.

---

## Abstract

We study the complete family of Artin L-functions of the simple group $G=\mathrm{PSL}(2,7)$ at conductor
$21$, realized through the Trinks field $x^7-7x+3$. **Part I** maps the family as a single self-similar
structure: the six irreducible L-functions and their CM twins are the tensor algebra of one cuspidal
representation — the quark $\chi_3$, with the genome $\chi_8=|\chi_3|^2-1$; the family inherits a
Mumford–Tate torus from its CM root and embeds in the $E_7$ minuscule geometry. Their conductors nest in
self-similar shells whose scaling exponent is computed *exactly* up to degree $91$, while a single
Riemann–von Mangoldt density law fits the computed zeros across a factor of $16$ in density. The genome's
degree-$8$ L-function is a catalogued classical object — its conductor $3^{10}7^{10}$, root number $+1$,
and character independently confirmed against the LMFDB. The organizing dichotomy is that every *structural*
invariant is determined and self-similar, while the *location* of the zeros is the single arithmetic feature
the geometry does not fix.

**Part II** anatomizes that feature for $\chi_8$. A finite, exactly-positive generating cell is unwound by a
time-reversal arrow into an infinite never-closing flow (a de Branges canonical system); the Euler product
is proved *necessary* to hold the zeros to the line (Davenport–Heilbronn); the wall is *forced* abelian
($\chi_8$ realized explicitly as a cubic Hecke L-function, $\mathrm{RH}(\chi_8)\iff\mathrm{GRH}(\psi)$); and
the Hypothesis is located as the survival of the finite positivity across the infinite flow, in four
equivalent forms. We give **two complementary roads** to this margin — the operator/de Branges road and a
finite-level analytic operator (skeleton zeros, with their convergence to the Riemann zeros *proved*) — show
they reduce to one positivity condition while the quantitative bridge between their margins is *not* an
equivalence, and bound them both by a precise **no-go**: the density is geometric and free at all heights,
but the zero *positions* are prime-locked — the primes are recovered directly from the zero spectrum (a
Fourier-duality, every resonance at a prime $\log p^k$). **We do not prove the Riemann Hypothesis**; we give,
for one explicit family, the sharpest localization we can of where the difficulty lies — and a precise
account of why the finite geometry cannot, by itself, cross it.

**Part III** makes the envelope *certified*. The family's structural regularity becomes finite,
machine-checkable certificates: a comb-law family envelope across forty-seven gap-rows and a
sixteen-interval positivity certificate; a **certified spectrum** for $\chi_8$ — 152 ball-certified
zero brackets on $[0,27.92]$ (median radius $4\times10^{-6}$; one bracket, #144, still numerical) with
**CERTIFIED one-sided Turing counts** $N^+(5.969)=21$ and $N^+(6.55)=24$, so "no zeros missing below the
Turing heights" is now itself a certified statement — grown from the first-version set of twenty-one, five
of which ($\gamma_{13}$–$\gamma_{17}$) were pre-registered *blind* from the passport density law and scored
three HIT, one NEAR, one bonus under a frozen protocol (Appendix G); an **unconditional pointwise
$|S(t)|$ bound** on $[7,30]$ with no zero-location input; and a finite
void-pressure **K-modulus ledger** (Hankel/Li) certified positive through $m=17$. Each is an explicit
finite certificate on the genome's own zeros — sharp in-range evidence, never a claim on the infinite tail.

**Part IV** exhibits the finite machine beneath the wall. The genome's representation theory gives an
exact-rational **certified descent ladder** $168\to24\to8\to7\to1\to0$, on which a single equivariant
*throat* opens a door proved unique to one rung — the $F^{(5)}\!\to\!F^{(4)}$ bottleneck (the
*Door-Uniqueness Criterion*). There the trit fixes a canonical key (the *Still-Point Key Theorem*), its
hidden sector is perfectly ternary-balanced (the *Equipartition Theorem*, $\ker=6\oplus6\oplus6$), and
three transported copies reassemble the next rung (the *Assembly Theorem*, certified on the exceptional
chart by symbolic elimination of an explicit Eisenstein quadric). The finite mechanism contributes its
dynamics at exactly one joint; above it the ladder is rigid certified descent, and the infinite flow of
Part II remains the single open wall.

Across all four parts the discipline is uniform: every structural and spectral fact is a **finite,
verifiable certificate** — ball-arithmetic, exact-rational, or symbolic — and the Riemann Hypothesis
itself is nowhere claimed.

---

# Part I — The Map

*A self-similar family of Artin L-functions generated by a single cuspidal representation.*

---

## §A.1 — Introduction

Let $G=\mathrm{PSL}(2,7)$, the simple group of order $168=2^3\cdot3\cdot7$, isomorphic to
$\mathrm{GL}(3,\mathbb F_2)$ and to the automorphism group of the Fano plane. We realize it as the Galois
group of the Trinks field $K=\mathbb Q[x]/(x^7-7x+3)$, whose Galois closure $L$ has
$\mathrm{Gal}(L/\mathbb Q)\cong G$ and which is ramified only at $3$ and $7$. To each of the six
irreducible representations of $G$ — of dimensions $1,3,3,6,7,8$ — one attaches an Artin L-function
$L(s,\rho)=\prod_p\det(1-\rho(\mathrm{Frob}_p)p^{-s})^{-1}$, and to the quadratic twist by the CM
character of $\mathbb Q(\sqrt{-7})$ two further L-functions. These are the **conductor-$21$ family**.

This part **maps the family completely** — not as eight separate L-functions, but as a single,
finitely-generated, self-similar structure. The map rests on one organizing fact, established in §A.5:

> Every member of the family is a tensor construction of a single three-dimensional cuspidal
> representation, the **quark** $\chi_3$.

From this, four structural results follow, and together they are the content of Part I.

**1. The tensor tower (§A.5).** The family is generated from $\chi_3$ by the tensor operations:
$\mathrm{Sym}^2\chi_3=\chi_6$, $\Lambda^2\chi_3=\bar\chi_3$, and the genome
$\chi_8=|\chi_3|^2-1$ (equivalently $\chi_3\otimes\bar\chi_3=\mathbf 1\oplus\chi_8$). Because $G$ is
finite, the *a priori* infinite symmetric-power tower $\{\mathrm{Sym}^k\chi_3\}$ collapses onto the six
irreducibles: every $L(s,\mathrm{Sym}^k\chi_3)$ is a finite product of the six.

**2. The Mumford–Tate torus (§A.6).** $\chi_3$ has complex multiplication by $\mathbb Q(\sqrt{-7})$ — it
is the $H^0$ of the Klein quartic, whose Jacobian is CM. The quadratic twist $\chi_3\otimes(\tfrac{\cdot}{-7})$
*preserves* the conductor $21^4$: the CM L-functions lie on a closed orbit at fixed conductor, a
Mumford–Tate torus, which the family inherits.

**3. The scaling law (§A.7).** Writing the *shell* of a member as $\sigma=\log_{21}N$, the conductors
nest — $\sigma/\deg$ lies in the tight band $[1.14,1.33]$ — and the zero density obeys a *single*
Riemann–von Mangoldt law, $\rho(T)=\tfrac1{2\pi}(\log N+d\log\tfrac{T}{2\pi})$, reproducing the observed
density of every member to within $7\%$ across a factor of $16$. The self-similarity persists, with exact
conductors, up the symmetric-power tower to degree $91$ and into the exceptional geometry.

**4. The exceptional containment (§A.8).** Via the action on the $2$-torsion of the Klein Jacobian,
$G\hookrightarrow\mathrm{Sp}(6,2)=W(E_7)/\{\pm1\}$. The $28$ bitangents of the Klein quartic and the $56$
of the $E_7$ minuscule representation decompose entirely into the six L-functions: the family is the
arithmetic substrate of the $E_7$ geometry.

Two explicit tools make all of this computable. A **Fano-line resolvent** (§A.3) recovers the full
Frobenius class at each prime — including the chirality that the genome's trace cannot see — so every
member's coefficients are exact. And the analytic data (conductor, gamma factor, sign) of each member is
fixed by the higher-ramification structure of the single field $K$ (§A.4).

### The thesis

One observation unifies the map. **Every structural invariant of the family — degree, conductor, gamma
factor, root number, the fusion algebra, the scaling exponent, the symmetry type — is determined by the
pair $(G,K)$, and is self-similar across the family and up the symmetric-power tower.** The single feature
the structure does *not* fix is the location of the non-trivial zeros: that they lie on
$\mathrm{Re}(s)=\tfrac12$. We state this as the organizing dichotomy of the whole work:

> *The envelope is geometric and self-similar; the line is arithmetic.*

Part I establishes the envelope — the complete, self-similar geometry of the family. Part II takes up the
line, for the distinguished member $\chi_8$, and anatomizes its Riemann Hypothesis. Part III turns the
envelope into finite certificates — the family law, the certified zeros, the K-modulus ledger. Part IV
exhibits the finite machine beneath the wall — the certified descent ladder and its theorems. A closing
section draws the four together.

### Conventions and scope

We use $\Gamma_{\mathbb R}(s)=\pi^{-s/2}\Gamma(s/2)$, $\Gamma_{\mathbb C}(s)=\Gamma_{\mathbb R}(s)\Gamma_{\mathbb R}(s+1)$,
and $\Lambda(s,\rho)=N^{s/2}\gamma(s)L(s,\rho)=\varepsilon\,\Lambda(1-s,\bar\rho)$.

**Grade tags.** Every claim carries one: $[C]$ (computed and reproduced), $[T]$ (standard theory),
$[P]$ (proved here), $[R]$ (interpretive reading), $[\mathrm{OPEN}]$ (= RH/GRH — never claimed). A
result whose $[C]$ or $[P]$ rests on a **machine-checkable certificate** is additionally marked
**CERTIFIED**, and its method is named:
- **ball-arithmetic** — rigorous interval enclosures (Arb/acb), machine-checked end to end: the
  certified zero brackets (152 on $[0,27.92]$, with certified Turing counts; §C.8) and the K-modulus
  positivity (Part III);
- **exact-rational** — exact arithmetic over $\mathbb Q$ (GAP, no floating point): the finite-machine
  descent and its theorems (Part IV);
- **symbolic elimination** — Gröbner/ideal certificates (Singular): the chart65 assembly locus (Part IV);
- **externally confirmed** — cross-checked against an outside authority: the $\chi_8$ analytic data,
  verified against the LMFDB (Part I, catalogued as `8.16679880978201.21t14.b.a`).

Thus *certified* means verifiable, not merely computed; *proved* $[P]$ means a paper-grade argument;
$[T]$ is cited, not re-proved; $[R]$ is a reading, marked as such. **We do not prove RH**: every
"in-range" or CERTIFIED statement is a finite, verifiable certificate, not a claim on the infinite tail.

**Structure.** The main text is Parts I–IV (§A–§D), followed by the Conclusion. Three companion
appendices are referenced by name and letter, relettered so they do not collide with the main-text
parts: **Appendix E** — the Registry Protocol (in preparation, Balashov); **Appendix F** — the Claims
Register, the master grade table every $[R\text{-}xxx]$ citation resolves to; and **Appendix G** — the
Grading Protocol, the pre-registration and certification rules used in §C.8. Part I proceeds: the substrate and the six
characters (§A.2), the Fano-line resolvent for the full Frobenius class (§A.3), the analytic data of the
six L-functions (§A.4), the tensor tower (§A.5), the Mumford–Tate torus and the twins (§A.6), the scaling
law and self-similarity (§A.7), the exceptional containment (§A.8), the in-range verification (§A.9), and
the thesis that hands off to Part II (§A.10).

---

## §A.2 — The Substrate: the Group, the Field, and the Genome

### A.2.1 The group and its characters

$G=\mathrm{PSL}(2,7)\cong\mathrm{GL}(3,\mathbb F_2)$ has order $168$, six conjugacy classes
$1A,2A,3A,4A,7A,7B$ of sizes $1,21,56,42,24,24$, and six irreducible representations of dimensions
$1,3,3,6,7,8$ with $\sum d_i^2=168$. With $\sigma=\tfrac{-1+i\sqrt7}{2}$ (a root of $X^2+X+2$):

$$
\begin{array}{c|cccccc}
 & 1A & 2A & 3A & 4A & 7A & 7B\\\hline
\mathbf 1 & 1 & 1 & 1 & 1 & 1 & 1\\
\chi_3 & 3 & -1 & 0 & 1 & \sigma & \bar\sigma\\
\bar\chi_3 & 3 & -1 & 0 & 1 & \bar\sigma & \sigma\\
\chi_6 & 6 & 2 & 0 & 0 & -1 & -1\\
\chi_7 & 7 & -1 & 1 & -1 & 0 & 0\\
\chi_8 & 8 & 0 & -1 & 0 & 1 & 1
\end{array}
$$

The rows are orthonormal and $\sum d_i^2=168$ $[C,\text{ first-party}]$. The Frobenius–Schur indicators are
$\nu(\chi_3)=\nu(\bar\chi_3)=0$ — the pair is **non-self-dual**, of unitary symmetry type — and $\nu=+1$
for $\mathbf 1,\chi_6,\chi_7,\chi_8$ (orthogonal) $[C,\text{ first-party}]$. The $\chi_3$ pair carries the
only complex character values; it is the cuspidal pair, and §A.5 shows it generates the rest. $\chi_8$ is
the eight-dimensional **genome**, $\chi_7$ the Steinberg, $\chi_6$ the six-dimensional standard
representation.

### A.2.2 The Trinks field

We realize $G$ as $\mathrm{Gal}(L/\mathbb Q)$, $L$ the splitting field of $f=x^7-7x+3$ (Trinks). The field
$K=\mathbb Q[x]/(f)$ is ramified only at $3$ and $7$: the polynomial discriminant is $3^8 7^8$, while the
field discriminant is $\mathrm{disc}(K)=3^6 7^8$ — the maximal order drops the $3$-exponent by
$\mathrm{index}^2=9$ (non-maximal at $3$) $[C]$. That the group is $G$ and not the $A_7$ which a
discriminant-sibling field would carry is confirmed arithmetically: over $12000$ primes the factorization
of $f\bmod p$ realizes **only** the five $G$-cycle types $1^7,\ 1^3 2^2,\ 1\cdot 3^2,\ 1\cdot 2\cdot 4,\ 7$,
with zero $5$-cycles (an $A_7$ field would force them) $[C]$.

### A.2.3 The genome and the shared Frobenius datum

For a prime $p\nmid 21$, the class of $\mathrm{Frob}_p\in G$ is read from the factorization type of
$f\bmod p$:

$$
1^7\!\to\!1A,\quad 1^3 2^2\!\to\!2A,\quad 1\cdot 3^2\!\to\!3A,\quad 1\cdot 2\cdot 4\!\to\!4A,\quad 7\!\to\!7A\text{ or }7B.
$$

The **genome** is $a_p=\chi_8(\mathrm{Frob}_p)\in\{8,0,-1,1\}$, and every member of the family is built
from this *single* sequence of Frobenius classes — **one prime sequence, six spectra**. By Chebotarev the
classes are equidistributed by class measure, matching the sizes$/168$ to within $1\%$, and the genome has
mean $0$ and variance $1$ $[C]$ (§A.5 and Part II §B.2 recover both from $\chi_8\perp\mathbf 1$,
$\|\chi_8\|=1$). The cycle type does not separate $7A$ from $7B$ — every transitive action of $G$ gives
both a $7$-cycle — which is the obstruction §A.3 resolves.

---

---

## §A.3 — The Full Frobenius Class: a Fano-Line Resolvent

To compute the coefficients of any member whose character is complex on $7A,7B$ — in particular $\chi_3$
and the twins — one needs the *fine* class, the **chirality**. The genome's trace cannot see it
($\chi_8(7A)=\chi_8(7B)=1$), and neither can any permutation representation. This section gives an
explicit, elementary resolvent for it. The construction and all its verifications are first-party.

### A.3.1 The obstruction

$7A$ and $7B$ carry the same cycle type in every transitive action of $G$ (each a $7$-cycle on $7,8,21,28,56$
points), so no factorization-degree pattern separates them; only the irreducible $\chi_3$ does, with
$\chi_3(7A)=\sigma\neq\bar\sigma=\chi_3(7B)$.

### A.3.2 The Fano-line resolvent

Let $r_0,\dots,r_6$ be the roots of $f$. The degree-$35$ triple-sum resolvent

$$
R(y)=\prod_{0\le i<j<k\le 6}\big(y-(r_i+r_j+r_k)\big)\in\mathbb Z[y]
$$

factors over $\mathbb Q$ as $R=R_7\cdot R_{28}$, with $\deg R_7=7$, $\deg R_{28}=28$, and

$$
\boxed{\,R_7(y)=y^{7}+14y^{4}-42y^{2}-21y+9\,.}
$$

The seven roots of $R_7$ are the line-sums of the seven Fano lines of $G$ acting on $\{r_i\}$; the $28$
roots of $R_{28}$ are the anti-flag sums. Computed at $90$-digit precision (rounding error $<10^{-82}$),
the split $35=7+28$ is exact and reflects the orbit decomposition of $G$ on the $35$ unordered triples
$[C,\text{ first-party}]$.

### A.3.3 The chirality per prime

For a prime $p$ with $f$ irreducible mod $p$ ($\mathrm{Frob}_p$ of order $7$), work in
$\mathbb F_{p^7}=\mathbb F_p[t]/(f)$ and label the roots $\theta_i=\theta^{p^i}$ ($\theta=t$), on which
Frobenius acts by the canonical shift $i\mapsto i+1$. A triple $\{i,j,k\}$ is a **Fano line** iff
$\theta_i+\theta_j+\theta_k$ is a root of $R_7$ in $\mathbb F_{p^7}$. The seven lines are the translates of
a planar $(7,3,1)$ difference set, which is either the quadratic-residue set $\{1,2,4\}$ (chirality $+1$,
class $7A$) or its complement $\{3,5,6\}$ (chirality $-1$, class $7B$). This binary, in the canonical
Frobenius coordinate, is the fine class.

### A.3.4 The chirality is not a congruence

**Theorem A.3 $[P]$.** There is no modulus $N$ for which $7A/7B$ is determined by $p\bmod N$.

*Proof.* The classes $7A,7B$ are separated only by the irreducible $\chi_3$. Since $G$ is simple it has no
non-trivial abelian quotient, so the distinguishing datum cannot factor through any abelian — hence
congruence — quotient of $\mathrm{Gal}(L/\mathbb Q)$. $\square$

**Verification $[C,\text{ first-party}]$.** Over the $1198$ primes below $4\times10^4$ with
$\mathrm{Frob}_p$ of order $7$, the chirality splits $49.0\%/51.0\%$ and is statistically flat against
every congruence tested — $p\bmod 7$, $p\bmod 21$, the symbols $(\tfrac p7)$ and $(\tfrac{-7}{p})$ — each
cell within one standard deviation of $\tfrac12$, and in particular uncorrelated with the CM symbol
$(\tfrac{-7}{p})$ (confirming Theorem A.3 empirically). The chirality is the *non-abelian* core of the
family, equidistributed and congruence-free.

With the chirality in hand, $\mathrm{Frob}_p$ is fully determined for every $p\nmid 21$, hence so is the
local factor of every member. This is the tool that makes the coefficients of $\chi_3$ and the twins —
and therefore the whole family — exact.

*[v0.9 note: IB's exact-$\mathbb Q$ certified bridge chain (2026-07-18→20 — PSL(2,7)→Fano geometry
bridge, Fano→Klein Hurwitz, Fano-incidence→arithmetic-$\chi_8$, arithmetic-$\chi_8$→completed-$L$,
and the $Q_2$ stratification certificates) will anchor this section's geometric statements at
certificate grade — integration staged.]*

---

---

## §A.4 — Analytic Data of the Family

### A.4.1 The conductor via higher ramification

For an Artin representation $\rho$ and a prime $p$ with ramification filtration $G_0\supseteq G_1\supseteq\cdots$
(lower numbering), the local conductor exponent is

$$
a_p(\rho)=\sum_{i\ge 0}\frac{|G_i|}{|G_0|}\big(\dim\rho-\dim\rho^{G_i}\big).
$$

For the Trinks field the inertia data are: at $p=3$, $G_0=S_3$, $G_1=\mathbb Z/3$ (a single wild break),
$G_2=1$; at $p=7$, $G_0=7{:}3$, $G_1=\mathbb Z/7$ (single wild break), $G_2=1$. Evaluating
$\dim\rho^{G_i}=\langle 1,\mathrm{Res}_{G_i}\rho\rangle$ from the character table gives, first-party:

$$
\begin{array}{c|cc|c}
\rho & a_3 & a_7 & N=q(\rho)\\\hline
\chi_3,\ \bar\chi_3 & 4 & 4 & 21^{4}\\
\chi_6 & 6 & 8 & 3^{6}7^{8}\\
\chi_7 & 8 & 8 & 21^{8}\\
\chi_8 & 10 & 10 & 21^{10}
\end{array}
\qquad [C,\text{ first-party}]
$$

The computation is **validated** independently: since the $7$-point permutation representation is
$\mathbf 1\oplus\chi_6$, one has $\zeta_K(s)=\zeta(s)L(s,\chi_6)$ and hence $q(\chi_6)=|\mathrm{disc}\,K|$;
the values $a_3(\chi_6)=6,\,a_7(\chi_6)=8$ reproduce $\mathrm{disc}(K)=3^6 7^8$ exactly (§A.2.2).

### A.4.2 Gamma factors and root numbers

Complex conjugation lies in $2A$; its eigenvalues on $\rho$ are $\pm1$ with multiplicities
$n_\pm=\tfrac12(\dim\rho\pm\chi_\rho(2A))$, so $\gamma(s,\rho)=\Gamma_{\mathbb R}(s)^{n_+}\Gamma_{\mathbb R}(s+1)^{n_-}$.
The $\chi_3$ pair is non-self-dual (dual $\bar\chi_3$, paired under $s\leftrightarrow1-s$); the others are
self-dual. The root number of $\chi_8$ is $\varepsilon=+1$, forced by a short ladder of Dedekind-zeta
factorizations: every Dedekind zeta has root number $+1$, and root numbers are multiplicative over the
factors. From the degree-$7$ and degree-$8$ subfields,

$$
\zeta_{K_7}=\zeta\,L(\chi_6)\ \Rightarrow\ W(\chi_6)=+1,
\qquad
\zeta_{K_H}=\zeta\,L(\chi_7)\ \Rightarrow\ W(\chi_7)=+1;
$$

then over the $28$-bitangent field $\zeta_{K_{28}}=\zeta\,L(\chi_6)^2 L(\chi_7)L(\chi_8)$, every factor but
$L(\chi_8)$ already has root number $+1$, forcing $W(\chi_8)=+1$. The archimedean factor agrees,
$i^{-n_-}=i^{-4}=+1$. So the functional equation is even, with no forced central zero.

### A.4.3 The family

$$
\begin{array}{c|c|c|c|c}
\rho & d & N & \gamma(s) & \text{type}\\\hline
\zeta & 1 & 1 & \Gamma_{\mathbb R}(s) & \mathrm{O}\\
\chi_3,\ \bar\chi_3 & 3 & 21^{4} & \Gamma_{\mathbb R}(s)\Gamma_{\mathbb R}(s+1)^2 & \mathrm{U}\ (\text{non-self-dual})\\
\chi_3\otimes(\tfrac{\cdot}{-7}) & 3 & 21^{4} & \Gamma_{\mathbb R}(s)^2\Gamma_{\mathbb R}(s+1) & \mathrm{U}\\
\chi_6 & 6 & 3^6 7^8 & \Gamma_{\mathbb R}(s)^4\Gamma_{\mathbb R}(s+1)^2 & \mathrm{O}\\
\chi_7 & 7 & 21^{8} & \Gamma_{\mathbb R}(s)^3\Gamma_{\mathbb R}(s+1)^4 & \mathrm{O}\\
\chi_8 & 8 & 21^{10} & \Gamma_{\mathbb C}(s)^4 & \mathrm{O}\\
\chi_8\otimes(\tfrac{\cdot}{-7}) & 8 & 21^{10} & \Gamma_{\mathbb C}(s)^4 & \mathrm{O}
\end{array}
$$

Two features of the table organize all of Part I. The conductors are powers of $21$ — the family nests in
self-similar shells (§A.7). And the two twins carry the **same conductor as their parents** ($21^4$ and
$21^{10}$): the conductor-preservation signature of the Mumford–Tate torus (§A.6). Every quantity here is
fixed by the single pair $(G,K)$; nothing is fitted.

### A.4.4 External validation (LMFDB)

The genome's analytic data is not only derived but **independently catalogued**. The degree-$8$
representation is the LMFDB Artin representation
[`8.16679880978201.21t14.b.a`](https://www.lmfdb.org/ArtinRepresentation/8.16679880978201.21t14.b.a)
(the label's $16679880978201=21^{10}$ is the conductor, $\mathtt{21t14}$ the Galois type), and every
invariant derived above matches it: conductor $3^{10}7^{10}$, field discriminant $3^6 7^8$, orthogonal
type, the character, and **root number $+1$** $[C]$. Two of these were genuinely delicate. The conductor
turns on the **non-maximality at $3$**: the polynomial discriminant $3^8 7^8$ would point to the wrong
filtration ($3^{12}7^{10}$), and only the maximal-order drop to field discriminant $3^6$ — the higher-
ramification filtration of §A.4.1, which LMFDB confirms — yields $\mathfrak n(\chi_8)=21^{10}$. The root
number $+1$ comes from the Dedekind-zeta chain through the $28$-bitangent field (§A.4.2) and lands exactly
on the catalogued value. The subtle ramification analysis was correct; the genome's L-function is a real,
classical, externally-verified object.

---

---

## §A.5 — The Tensor Tower

This section establishes the organizing fact of Part I: the family is generated, by tensor and symmetric
powers, from the single cuspidal representation $\chi_3$.

### A.5.1 The quark and the generating identities

$\chi_3$ is the smallest faithful representation. Three identities — each verified on all six classes,
first-party — generate the family from it:

$$
\Lambda^2\chi_3=\bar\chi_3,\qquad \mathrm{Sym}^2\chi_3=\chi_6,\qquad \chi_3\otimes\bar\chi_3=\mathbf 1\oplus\chi_8.
$$

The first two follow from $\chi_{\mathrm{Sym}^2}(g)=\tfrac12(\chi_3(g)^2+\chi_3(g^2))$ and
$\chi_{\Lambda^2}(g)=\tfrac12(\chi_3(g)^2-\chi_3(g^2))$; indeed $\Lambda^2\chi_3=\chi_3^\vee\otimes\det\chi_3=\bar\chi_3$
since $\det\chi_3=\mathbf 1$ ($G$ is perfect). $[P;\,C\text{ on all classes, first-party}]$

### A.5.2 The Born relation

The third identity reads, on Frobenius:

$$
\boxed{\,a_p(\chi_8)=|a_p(\chi_3)|^2-1\,}\qquad(p\nmid 21),\qquad\text{i.e.}\qquad
L(s,\chi_3\times\bar\chi_3)=\zeta(s)\,L(s,\chi_8).
$$

*Proof.* As class functions $\chi_3\bar\chi_3=\mathbf 1+\chi_8$ (checked: $|3|^2=1+8,\ |\!-\!1|^2=1+0,\
|0|^2=1-1,\ |1|^2=1+0,\ |\sigma|^2=2=1+1$); and $\bar\chi_3(\mathrm{Frob}_p)=\overline{\chi_3(\mathrm{Frob}_p)}$.
$\square$ Verified on the $301$ primes below $2000$ with no exception $[C]$. **The genome is the squared
intensity of the quark.** The Steinberg $\chi_7$ enters one level higher ($\chi_3\otimes\chi_6\supset\chi_7$),
so all six members are reached from $\chi_3$.

### A.5.3 The symmetric-power tower

Because $G$ is finite, every $\mathrm{Sym}^k\chi_3$ is a genuine representation and decomposes into the
six, with $\dim\mathrm{Sym}^k\chi_3=\binom{k+2}{2}$:

$$
\begin{array}{c|l}
k & \mathrm{Sym}^k\chi_3\\\hline
0 & \mathbf 1\\
1 & \chi_3\\
2 & \chi_6\\
3 & \bar\chi_3\oplus\chi_7\\
4 & \mathbf 1\oplus\chi_6\oplus\chi_8\\
5 & \chi_3\oplus\bar\chi_3\oplus\chi_7\oplus\chi_8\\
6 & \mathbf 1\oplus 2\chi_6\oplus\chi_7\oplus\chi_8\\
7 & \chi_3\oplus\bar\chi_3\oplus 2\chi_7\oplus 2\chi_8\\
8 & \mathbf 1\oplus\chi_3\oplus 3\chi_6\oplus\chi_7\oplus 2\chi_8
\end{array}
$$

Consequently each symmetric-power $L$-function **factors into the six**:

$$
L(s,\mathrm{Sym}^k\chi_3)=\prod_i L(s,\chi_i)^{\,m_{k,i}},\qquad m_{k,i}=\langle\mathrm{Sym}^k\chi_3,\chi_i\rangle.
$$

The *a priori* infinite tower $\{\mathrm{Sym}^k\chi_3\}$ therefore **collapses onto the six**: every
$L(s,\mathrm{Sym}^k\chi_3)$ is a finite product of family members, and RH for the whole tower is equivalent
to GRH for the six. The genome $\chi_8$ first appears at $\mathrm{Sym}^4$; all six are present by
$\mathrm{Sym}^4$, after which the tower re-mixes them with multiplicities growing like
$\dim(\chi_i)\cdot\dim(\mathrm{Sym}^k)/168$. $[C,\text{ first-party}]$

The family is the **tensor algebra of one quark** — a single degree-$3$ representation and its tensor
powers. This is what makes "finitely-generated and self-similar" precise, and §A.7 shows the same
self-similarity in the analytic shells.

### A.5.4 The moments and the Rankin–Selberg square

The genome's self-products are exact representation theory. Each power-moment of $a_p=\chi_8(\mathrm{Frob}_p)$
is a character inner product, hence a closed integer:

$$
\langle a_p^k\rangle=\frac1{|G|}\sum_g\chi_8(g)^k=\langle\chi_8^{\otimes k},\mathbf 1\rangle
=\frac{8^k+56(-1)^k+48}{168},
$$

giving $\langle a_p^k\rangle=0,\,1,\,3,\,25,\,195,\,1561$ for $k=1,\dots,6$ $[C,\text{ first-party}]$. The mean
is $0$ and the variance $1$ (the genome is a unit character orthogonal to the trivial); the third moment
$3\neq0$ records that the per-prime law is **skewed**, not Gaussian — the rare value $+8$ on the identity
stratum dominates the odd moments.

These closed integers are now confirmed at scale. A fast-Frobenius sweep of the genome to $x=10^{11}$
($\approx4.1\times10^{9}$ primes, exact integer arithmetic — no precision wall) gives
$\langle a_p^2\rangle=0.99996$ against the character-theoretic $1$, with the class frequencies matching
Chebotarev equidistribution to the same grade. The genome's statistics are not asymptotic hopes; they are
measured at four billion primes. $[C,\text{ first-party}]$

The variance has a spectral reading. The Rankin–Selberg square decomposes, first-party,

$$
\chi_8\otimes\chi_8=\mathbf 1\oplus\chi_3\oplus\bar\chi_3\oplus 2\chi_6\oplus 3\chi_7\oplus 3\chi_8\quad(\dim 64),
\qquad
L(s,\chi_8\times\chi_8)=\zeta\,L(\chi_3)L(\bar\chi_3)\,L(\chi_6)^2 L(\chi_7)^3 L(\chi_8)^3 .
$$

The trivial constituent appears **exactly once**; its $\zeta$-factor is the single simple pole at $s=1$,
whose residue is precisely $\langle a_p^2\rangle=1$ — the variance read as a Rankin–Selberg pole. Every other
constituent is a non-trivial irreducible, so $L(s,\rho)$ is holomorphic at $s=1$ (Aramata–Brauer) and carries
no pole. This multiplicity-one fact returns in Part II as the reason the prime-pairing is diagonal (§B.6.5).

---

## §A.6 — The Mumford–Tate Torus

The cuspidal quark $\chi_3$ that generates the family has complex multiplication, and this single fact
organizes the family's deepest geometry — a torus on which its CM L-functions lie, which Part II identifies
as the analytic wall.

### A.6.1 The CM root

$\chi_3$ is the representation of $G$ on $H^0(X(7),\Omega^1)$, the holomorphic differentials of the Klein
quartic. Its Jacobian is isogenous to $E^3$, with $E$ the elliptic curve of conductor $49$ ($j=-3375$)
having complex multiplication by $\mathbb Q(\sqrt{-7})$ ($a_p(E)=0$ exactly when $p$ is inert, $(\tfrac{-7}{p})=-1$,
verified over $9591$ primes $[C]$). The **full** CM field, however, is the cyclotomic $\mathbb Q(\zeta_7)$
(degree $6$), not merely this quadratic subfield: point-counting the Klein quartic $C:x^3y+y^3z+z^3x$ gives

$$
a_p(C)=a_p(E)\big(1+\chi(p)+\chi^2(p)\big),\qquad \chi=\text{the cubic character mod }7,
$$

(verified first-party on test primes, and $429$ primes by claude2), so the Jacobian's L-function is the
explicit algebraic Hecke Grossencharacter
$L(\mathrm{Jac}\,C)=L(E)\,L(E\otimes\chi)\,L(E\otimes\chi^2)=L(\eta)$ over $\mathbb Q(\zeta_7)$, with
$\mathbb Q(\sqrt{-7})\subset\mathbb Q(\zeta_7)$ the quadratic piece carried by $E$. The generating motive is
thus CM by the cyclotomic torus. By §A.5 the whole family is a tensor construction of this CM root; and CM motives
are closed under $\otimes,\mathrm{Sym}^k,\Lambda^k$ with the Mumford–Tate torus preserved $[T$: Deligne;
Shimura–Taniyama$]$. Hence **every member of the family is CM**, its Mumford–Tate group a sub-torus of the
$\mathbb Q(\zeta_7)$-torus.

### A.6.2 The twin and conductor preservation

Twisting $\chi_3$ by the CM character $(\tfrac{\cdot}{-7})$ — the Kronecker character of
$\mathbb Q(\sqrt{-7})$, conductor $7$ — yields a degree-$3$ L-function whose functional equation closes
(numerically $|\mathrm{feq}|<10^{-49}$) for conductor **exactly $21^4$, identical to $\chi_3$**; among
candidates $3^4\cdot 7^k$ only $k=4$ closes it $[C,\text{ first-party}]$. The gamma factor flips parity to
$\Gamma_{\mathbb R}(s)^2\Gamma_{\mathbb R}(s+1)$ (the CM character is odd), and the twin's zeros differ from
$\chi_3$'s — so it is a genuinely new L-function, neither $\chi_3$ nor $\bar\chi_3$. The CM twist adds **no
ramification**.

### A.6.3 The closed orbit

Conductor-preservation under the CM twist is the signature of the Mumford–Tate torus. The four degree-$3$
CM L-functions

$$
\{\chi_3,\ \bar\chi_3,\ \chi_3\otimes(\tfrac{\cdot}{-7}),\ \bar\chi_3\otimes(\tfrac{\cdot}{-7})\}
$$

all sit at conductor $21^4$, and twisting **rotates within this closed orbit** without leaving it. The
torus is confirmed by the Frobenius distribution: the Sato–Tate measure is the torus, not
$\mathrm{SU}(2)$ — over $8972$ split primes the normalized angles are uniform (Kolmogorov–Smirnov
$0.0095$, below the critical $0.0143$) and the second moment $\langle(a_p/\sqrt p)^2\rangle=1.99\approx 2$
(the torus value; the semicircle is rejected at KS $0.162$) $[C]$.

The family thus inherits a closed CM torus from its quark root. In Part I this is one more determined,
self-similar feature — the twins sit *exactly* on their parents' conductor shells (§A.7). In Part II the
*same* torus is the analytic **wall**: because the Mumford–Tate group is a torus, every member is an
abelian Hecke L-function and the symmetric-power lever is structurally absent. The geometry's tidiest
object and the analysis's hardest obstruction are one torus, seen from two sides.

---

---

## §A.7 — The Scaling Law and Self-Similarity

The conductors of §A.4 are powers of $21$, and the family nests in self-similar shells governed by a
single law. This is the clearest statement of "the envelope is geometric and self-similar."

### A.7.1 The shells

Define the **shell** of a member as $\sigma(\rho)=\log_{21}N_\rho$. The family: $\zeta$ at $21^0$, the
$\chi_3$ family and both twins at $21^4$, $\chi_6$ at $21^{7.28}$, $\chi_7$ at $21^8$, $\chi_8$ at
$21^{10}$. The shells nest, ordered by degree, the conductor growing as $\sim 21^{1.25\,d}$ — a scaling
exponent $\sigma/d$ in the tight band $[1.14,\,1.33]$.

### A.7.2 The density law

By Riemann–von Mangoldt, the mean zero density of a degree-$d$, conductor-$N$ L-function at height $T$ is
$\rho(T)=\tfrac1{2\pi}\big(\log N+d\log\tfrac{T}{2\pi}\big)$. Against the density of the computed zeros
(§A.9):

$$
\begin{array}{c|cc|cc|c}
\rho & d & \sigma & \rho_{\mathrm{pred}} & \rho_{\mathrm{obs}} & \text{ratio}\\\hline
\zeta & 1 & 0.0 & 0.206 & 0.213 & 1.03\\
\chi_3 & 3 & 4.0 & 1.403 & 1.486 & 1.06\\
\chi_3\otimes(\tfrac{\cdot}{-7}) & 3 & 4.0 & 1.216 & 1.480 & 1.22\\
\chi_6 & 6 & 7.28 & 2.809 & 2.703 & 0.96\\
\chi_7 & 7 & 8.0 & 2.527 & 2.636 & 1.04\\
\chi_8 & 8 & 10.0 & 3.299 & 3.631 & 1.10
\end{array}
$$

Across a factor of $16$ in density the mean ratio is $1.07\pm0.08$ $[C,\text{ first-party}]$. One law,
from the shell and degree alone, sets the spectral density of every member.

### A.7.3 Self-similarity to degree 91

The exponent $\sigma/d$ is computable **exactly** for the symmetric powers (whose conductors are products
of the six, §A.5), even where their zeros are not. Up the tower and into the exceptional objects,

$$
\frac{\sigma}{d}\in[1.14,\,1.33]\quad\text{for}\quad\mathrm{Sym}^k\chi_3\ (k\le 12,\ \deg\le 91),\ \text{the }28\text{-bitangent, the }56\text{-minuscule,}
$$

with values $1.200\ (\mathrm{Sym}^3),\ 1.163\ (\mathrm{Sym}^6),\ 1.223\ (\mathrm{Sym}^9),\ 1.191\ (\mathrm{Sym}^{12})$,
and $1.163\ (28),\ 1.189\ (56)$. The conductors are exact; **the self-similarity of the envelope is verified
far past the horizon at which any zero can be computed** $[C,\text{ first-party}]$.

### A.7.4 The value $4/3$ at the quark

The exponent is governed at $p=7$ by the wild break of the trit. With $\mathrm{inv}_i=\dim\rho^{G_i}$ at
$7$ ($G_0=7{:}3$, $G_1=\mathbb Z/7$, $|G_1|/|G_0|=\tfrac13$),

$$
a_7(\rho)=\Big(1+\tfrac13\Big)\big(\dim\rho-\mathrm{inv}_0\big)\quad\text{when }\mathrm{inv}_0=\mathrm{inv}_1,
$$

and the factor $1+\tfrac13=\tfrac43$ is the wild contribution of the order-$3$ quotient $G_0/G_1$. The
quark $\chi_3$ has $\mathrm{inv}_0=\mathrm{inv}_1=0$ — fully active — so $a_7(\chi_3)/\dim=\tfrac43$ and its
shell exponent is **exactly $4/3$**. The seed carries the four-thirds undiluted; the genome deviates to
$a_7/\dim=\tfrac54$ through its two-dimensional Singer-invariant. $[C,\text{ first-party}]$

The envelope is self-similar — one density law, nested shells, the same scaling exponent from degree $3$
to $91$. The single feature this self-similar geometry leaves undetermined is, once again, the line.

---

---

## §A.8 — The Exceptional Containment

The number $28=1+3+3+6+7+8$ is the sum of the irreducible dimensions of $G$; it is also the number of
bitangents of the Klein quartic and half the minuscule $56$ of $E_7$. The coincidence is structural: the
family is the arithmetic substrate of the $E_7$ minuscule geometry.

### A.8.1 The embedding

$G$ acts on the $2$-torsion of the Klein Jacobian, $\mathrm{Jac}(X(7))[2]\cong\mathbb F_2^6$, preserving
the symplectic form — giving an embedding

$$
G=\mathrm{PSL}(2,7)\ \hookrightarrow\ \mathrm{Sp}(6,2)=W(E_7)/\{\pm1\},
$$

with $|\mathrm{Sp}(6,2)|=1451520=2^9 3^4 5\cdot 7$ and $|W(E_7)|=2\cdot 1451520$ $[T]$. The $28$ bitangents
are an $\mathrm{Sp}(6,2)$-orbit; the $56$ minuscule weights of $E_7$ are $28+28$.

### A.8.2 The $28$ and the $56$

The permutation characters decompose entirely into the six, first-party:

$$
\pi_{28}=\mathbf 1\oplus 2\chi_6\oplus\chi_7\oplus\chi_8,\qquad
\pi_{56}=\mathbf 1\oplus\chi_3\oplus\bar\chi_3\oplus 2\chi_6\oplus 3\chi_7\oplus 2\chi_8.
$$

Equivalently $\zeta_{K_{28}}=\zeta\,L(\chi_6)^2 L(\chi_7)L(\chi_8)$ over the $28$-bitangent field — the same
field that fixes the root number of $\chi_8$ (§A.4.2) — and the $56$-minuscule L-function, restricted to
$G$, is $\zeta\,L(\chi_3)L(\bar\chi_3)L(\chi_6)^2 L(\chi_7)^3 L(\chi_8)^2$ $[C,\text{ first-party}]$.

### A.8.3 Scope

This is a **containment**, verified: the $E_7$ minuscule geometry, restricted to $G$, is built from the
six L-functions. It is **not** a new L-function — the $56$ restricted to $G$ factors back into the six. A
genuine $E_7$ *automorphic* L-function (Langlands for a rank-$7$ exceptional group) is a different and far
larger object, outside the Artin formalism and outside this work. What is established is structural: the
family is the arithmetic substrate of $E_7$'s minuscule representation, and the full ascent
$\zeta\to\chi_3\to\text{the six}\to\mathrm{Sp}(6,2)=W(E_7)$ is one self-similar tower (§A.7), seeded by the
quark.

---

---

## §A.9 — In-Range Verification

Every member of the family is exhibited on the critical line in range, with its functional equation
verified and no missing zeros. This is RH-in-range — finite evidence, not a proof.

### A.9.1 The zeros

For each member the completed $\Lambda(s)$ was assembled from the exact coefficients (§A.3) and the
analytic data (§A.4), the functional equation verified by the self-consistency $\Lambda(s)=\varepsilon\Lambda(1-s)$,
and the low-lying zeros located on $\mathrm{Re}(s)=\tfrac12$:

$$
\begin{array}{c|c|l}
\rho & \log_{10}|\mathrm{feq}| & \text{first ordinates }\gamma\\\hline
\zeta & - & 14.135,\ 21.022,\ 25.011\ (\text{classical})\\
\chi_3 & -58 & 0.856,\ 1.821,\ 2.294,\ 2.794,\ 3.547\\
\chi_3\otimes(\tfrac{\cdot}{-7}) & -51 & 0.266,\ 1.520,\ 1.783,\ 2.456,\ 2.969\\
\chi_6 & -123 & 0.770,\ 1.698,\ 1.790,\ 2.300,\ 2.694,\dots\\
\chi_7 & -35 & 1.004,\ 1.398,\ 1.713,\ 2.133,\ 2.560,\ 2.901\\
\chi_8 & \approx-4 & 0.986,\ 1.269,\ 1.562,\ 1.961,\ 2.116,\ 2.368,\ 2.607,\ 2.914\\
\chi_8\otimes(\tfrac{\cdot}{-7}) & -27 & 0.701,\ 1.40,\ 1.71,\dots\ (21\text{ to }T=6)
\end{array}
$$

The non-self-dual $\chi_3$ pair has zeros **asymmetric in $\pm\gamma$** — the signature of $\chi_3\neq\bar\chi_3$
— while the self-dual members are symmetric.

The $\chi_8$ row deserves a word on provenance. Its skeleton — the Satake/Frobenius data — is catalogued in the
LMFDB as Artin representation `8.16679880978201.21t14.b.a`, but the analytic conductor is far too large for the
database to carry zeros; the ordinates above are therefore **first-party**, located by the Hardy $Z$-function and
pinned in *count* by the argument principle (§A.9.2). Because the approximate functional equation at conductor
$21^{10}$ demands $\sim\!5.6\times10^{7}$ coefficients, the functional-equation residual is **conductor-limited**:
the FE self-check is $\approx4\times10^{-5}$ at a $2\times10^{6}$-coefficient cutoff (hence the $\approx-4$ in the
table, against $<-27$ for the lower-conductor members). The first ordinate $\gamma_1=0.986$ is **independently
cross-checked** by the second author's Dokchitser / Hardy-phase computation ($\gamma_1\approx0.985$, the Hardy
phase moving the raw estimate *toward* $0.986$); the higher ordinates are preliminary at this cutoff. The
argument-principle pin of §A.9.2 — eight zeros in $[0,3]$, all on the line — does **not** depend on the per-zero
precision. $[C,\text{ first-party} + \text{cross-checked}]$

*The certified extension.* Since the first version of this table, the $\chi_8$ row has been extended by nine
zeros at **certified-bracket grade** (ball arithmetic end to end; Part III, §C.8):

$$
\gamma_9\in[3.126,3.128],\ \gamma_{10}\in[3.338,3.342],\ \gamma_{11}\in[3.700,3.702],\ \gamma_{12}\in[3.952,3.954],
$$
$$
\gamma_{13}\in[4.081,4.087],\ \gamma_{14}\in[4.357,4.379],\ \gamma_{15}\in[4.548,4.550],\
\gamma_{16}\in[4.692,4.696],\ \gamma_{17}\in[4.886,4.890].
$$

$\gamma_9$–$\gamma_{11}$ were **predicted from the primes first** (explicit-formula extraction at $10^{11}$,
§B.9.2) and certified on the $L$-side after; $\gamma_{12}$ carries no prime seed at all — its window came from
the passport density law of §A.7 alone, and the certified zero sits inside it. $\gamma_{13}$–$\gamma_{16}$ then
extend the pure-prediction record under a **frozen pre-registration** (scored **3 HIT + 1 NEAR**), with
$\gamma_{17}$ a bonus. Seventeen zeros to $t=4.888$; the count-pinning of §A.9.2 and the interval certificate of
Part III cover the first eleven. $[C]$

*[Updated 2026-07-19/25 — the verification base is now the certified spectrum.]* The bracket lists above
are the historical record of the prediction eras; the current base for every in-range statement in this
paper is the **certified spectrum of §C.8.1b**: 152 ball-certified zero brackets on $[0,27.92]$, median
radius $4\times10^{-6}$, all seventeen brackets above reproduced inside the new enclosures, with one
honest caveat carried throughout — bracket #144 ($t\approx26.45$) remains numerical, its certification
pending, so ordinals $\ge145$ are stated modulo #144. $[C,\ \mathrm{CERTIFIED}]$

### A.9.2 No gaps: the argument principle

For $\chi_8$ the count is pinned exactly. With the smooth count $M(T)=\tfrac1\pi\arg[N^{(1/2+iT)/2}\Gamma_{\mathbb C}(\tfrac12+iT)^4]$
and $S(T)=\tfrac1\pi\arg L(\tfrac12+iT)$, the number of zeros in the strip up to $T$ is $N(T)=M(T)+S(T)$. At
$T=3$: $S(3)=0.089$, $M(3)=7.911$, so $N(3)=8.000$ exactly. Eight zeros were located on the line; the strip
count being $8$ means **all eight are on $\mathrm{Re}=\tfrac12$, none off — RH pinned in $[0,3]$** $[C]$. The
genome twin follows to $T=6$ ($N(6)=21$). For every member the smooth count tracks the found zeros with no
gap, $\max_n|(n-\tfrac12)-M(\gamma_n)|<1.3$, so the exhibited zeros are *all* of them in range.

*[Upgraded 2026-07-19.]* For $\chi_8$ the no-gap statement is no longer only argument-principle tracking:
the one-sided **Turing counts $N^+(5.969)=21$ and $N^+(6.55)=24$ are CERTIFIED** — every error term in the
chain a proven bound (§C.8.1b) — so "no zeros missing below the Turing heights" is a certified statement,
not a numerical one. $[C,\ \mathrm{CERTIFIED}]$

### A.9.3 Methods, positivity, scope

Zeros were located by sign changes of the Hardy $Z$-function (self-dual members) and by minima of $|L|$ on
the line, ternary-refined (the non-self-dual $\chi_3$ pair). The Weil/Li coefficients $\mathrm{Re}(\lambda_n)$
are positive for $n=1,\dots,8$ for every member.

*Provenance.* First-party: $\zeta$ (classical), $\chi_3$, the $\chi_3$-twin, $\chi_6$, $\chi_7$, and the
uniform Li and $M(T)$ tracking. Reproduced on the 32 GB machine: $\chi_8$ and the genome twin (conductor
$21^{10}$, the argument-principle pinning).

*Scope.* In-range RH is *verified* — zeros exhibited, no-gap tracking, $\chi_8$ argument-principle-pinned —
not RH itself; there is no off-line exclusion beyond the computed range. The $\chi_7$ ordinates, at conductor
$21^8$, are located but low-precision (the rigorous statement for $\chi_7$ is its functional equation). The
family is, end to end, on the critical line in range. Part III strengthens this section's grade on $[0,3.2]$:
the derivative-level certificate $Q>0$ there (Theorem C.7) is interval arithmetic, not verification — the
"preliminary at this cutoff" caveat above is superseded on that range.

---

---

## §A.10 — The Thesis: the Envelope and the Line

Part I has mapped the conductor-$21$ family of $\mathrm{PSL}(2,7)$ as a single structure. We collect the
result and state the thesis that hands to Part II.

**What is determined.** Every structural invariant of the family is fixed by the pair $(G,K)$:

- the six characters and their symmetry types (§A.2);
- the full Frobenius datum, via the Fano-line resolvent (§A.3);
- the analytic data — conductor, gamma factor, sign — of all eight members (§A.4);
- the generation: the family is the tensor algebra of the quark $\chi_3$, with $\chi_8=|\chi_3|^2-1$, and
  the symmetric-power tower collapsing onto the six (§A.5);
- the Mumford–Tate torus inherited from the CM root, with the twins conductor-locked (§A.6);
- the scaling law: nested shells, one density law across a factor of $16$, self-similar to degree $91$, the
  $4/3$ at the quark (§A.7);
- the $E_7$ containment via $\mathrm{Sp}(6,2)=W(E_7)/\{\pm1\}$ (§A.8).

Each of these is exact and self-similar; none required the location of a single zero.

**What is not.** The one feature the structure does not fix is the location of the non-trivial zeros —
that they lie on $\mathrm{Re}(s)=\tfrac12$. Part I exhibits them there, in range, for every member (§A.9),
but that is finite evidence; the structure is silent on whether it holds throughout.

**The thesis.**

> *The envelope is geometric and self-similar; the line is arithmetic.*

Every shape — the shells, the densities, the fusion algebra, the tori, the scaling exponent — is determined
by $(G,K)$ and extends self-similarly to arbitrary degree. The location of the zeros is the unique feature
on which the geometry is silent; it is carried by the primes, through the explicit formula, and is the
content of the Riemann Hypothesis for the family.

Part II takes up this single open feature for the distinguished member $\chi_8$. It anatomizes
$\mathrm{RH}(\chi_8)$ — separating what is forced from what is open — and locates the Hypothesis as the
survival of an exact finite positivity across an infinite flow, equivalently as GRH for one explicit cubic
Hecke character. **The map is Part I; the line is Part II.**

---

# Part II — The Anatomy of the Wall

*Riemann's Hypothesis for the genome L-function as a finite cell carried by an infinite flow.*

---

## §B.1 — Introduction

Part I assembled the six Artin L-functions of $G=\mathrm{PSL}(2,7)$ at conductor $21$ — together with
their CM twins — into a single object: a finitely-generated, self-similar family, every member exhibited
on the critical line in range, every structural invariant (degree, conductor, gamma factor, sign, the
fusion algebra, the scaling exponent) fixed by the pair $(G,K)$ of the group and the Trinks field. The
family was shown to be the tensor tower of one cuspidal representation, the quark $\chi_3$, with the
genome $\chi_8=|\chi_3|^2-1$ its squared intensity. The closing thesis of Part I was a dichotomy: *every
geometric feature is determined and self-similar; the single feature the structure does not fix is that
the zeros lie on $\mathrm{Re}(s)=\tfrac12$.*

Part II is about that single feature, for the distinguished member $\chi_8$. We ask the only question
Part I left open: **where, precisely, does the Riemann Hypothesis live for this object, and what can be
proved around it?** We state at once that **we do not prove RH.** What we do is *anatomize the wall* —
exhibit, for one explicit L-function, the complete structure surrounding its Riemann Hypothesis, separate
everything that is proved or forced from the one statement that is open, and give that statement in
several equivalent forms. The result is not a theorem toward RH but a localization: the sharpest
available account of where, and only where, the difficulty lies.

### A finite cell carried by an infinite flow

One tension organizes the whole anatomy, and resolving it is the spine of Part II.

The machine that generates $\chi_8$ is **finite**. The group $G$ has order $168$; the Frobenius datum at
each prime is one of six conjugacy classes; the genome $a_p=\chi_8(\mathrm{Frob}_p)$ takes values in the
finite alphabet $\{8,0,-1,1\}$. The algebra is finite too: the imaginary octonion units are the Fano
matroid $F_7=\mathrm{PG}(2,2)$, and their Cayley–Dickson doubling — the sedenion, the dark cone — is
$\mathrm{PG}(3,2)$, exactly fifteen Fano planes. The associated "void operator'' is an explicit
self-adjoint matrix with a known characteristic polynomial, and it carries an exact sum-of-squares
positivity. There is nothing infinite, or even large, in the apparatus.

Yet RH is irreducibly a statement about the **infinitely many primes** — through the explicit formula,
the zeros are determined by the infinite sum $\sum_p a_p\,(\log p)\,p^{-s}$, and the prime alphabet
$\{\log p\}$ is linearly independent over $\mathbb Q$ (Baker), an infinite-rank structure. A naive
no-go follows: a finite operator has finite rank and cannot reproduce $\{\log p\}$; the operator route
to RH appears closed.

The resolution — and it is the de Branges picture, reached here from the arithmetic — is that the
operator attached to $\chi_8$ is **not a finite matrix but a finite cell carried by an infinite flow**:
a canonical system $H(t)$, $t\in[0,\infty)$, whose Hamiltonian is a finite cell at each instant and whose
*variation along the flow* encodes the primes. No single instant holds $\{\log p\}$; the unending run
does. The finite, self-dual, closing clock of the machine is *unwound* into this flow by the
time-reversal arrow (the chirality $K\neq 0$), and it never closes because the trit (order $3$) and the
Singer cycle (order $7$) are coprime — the holonomy $z_3\,\sigma\,z_3^{-1}=\sigma^r$ ($r\in\{2,4\}$, $r^3\equiv1$) never returns to
its start. The flow is aperiodic, hence infinite. In this language the Riemann Hypothesis acquires its
sharpest form:

> **RH for $\chi_8$ is the statement that the cell's exact, finite positivity survives the infinite,
> never-closing flow.**

The finiteness Part II establishes is real and it is the *entire structure*; what is open is only whether
the balance, exact at every finite instant, ever tips across the infinite run.

### The anatomy: four facts established, one open statement in four forms

Around that single open statement, four facts are established, each tagged where it is computed $[C]$,
forced by standard theory $[T]$, or interpretive $[R]$:

1. **The cell is finite and exactly balanced.** $[C]$ The void operator and its sum-of-squares
   positivity are exact; the genome is the unique integer dimension-$8$ unit character orthogonal to
   the trivial; the dark cone is fifteen Fano matroids.
2. **The Euler product is necessary.** $[C]$ The functional equation supplies the symmetry axis but not
   the line: a self-dual functional equation *without* an Euler product admits an off-line zero, exhibited
   (Davenport–Heilbronn) to $38$ digits. The Euler product is the multiplicative binding the flow requires.
3. **The wall is forced to be abelian.** $[C\to T]$ $\chi_8$ has complex multiplication by
   $\mathbb Q(\sqrt{-7})$; it is realized explicitly as $L_{K_H}(s,\psi)$ for a *cubic* (order-$3$) Hecke
   character $\psi$; its Sato–Tate law is the torus. Hence $\mathrm{RH}(\chi_8)\iff\mathrm{GRH}(\psi)$, and
   no non-CM lever can reach it.
4. **RH holds in range.** $[C]$ By the argument principle the strip count is pinned exactly
   ($N(3)=8$, all on the line); the whole family follows with no missing zeros and positive Weil/Li
   coefficients.

The single open statement then appears in four equivalent forms, which §B.10 shows are one:

$$
\underbrace{\mathcal A \text{ self-adjoint}}_{\text{Aion / operator}}\ \Longleftrightarrow\
\underbrace{|K_L(s)|=1\iff \mathrm{Re}(s)=\tfrac12}_{\text{K-modulus / purity}}\ \Longleftrightarrow\
\underbrace{\lambda_n\ge 0\ \forall n}_{\text{Weil/Li positivity}}\ \Longleftrightarrow\
\underbrace{\mathrm{GRH}(\psi)}_{\text{abelian Hecke}} .
$$

A single order-$3$ structure — the *trit* — threads the anatomy from end to end: it is the ternary
operator of the finite cell (§B.3), the cubic Hecke character $\psi$ of the forced wall (§B.5), and
the channel along which the genome reads its floor value $-1$ (§B.10). The proxy that an earlier
operator computation borrowed — a *quadratic* character — is retired in §B.6, where the load-bearing
positivity is recomputed on $\chi_8$'s own cubic zeros.

### Conventions and roadmap

We use $\Gamma_{\mathbb R}(s)=\pi^{-s/2}\Gamma(s/2)$ and write $\Lambda(s)=N^{s/2}\gamma(s)L(s)$ for the
completed L-function, with $\Lambda(s)=\varepsilon\,\Lambda(1-s)$. Claims are tagged $[C]$ (computed and
reproduced), $[T]$ (standard theory invoked), $[P]$ (proved here), $[R]$ (interpretive), and
$[\mathrm{OPEN}]$ for RH itself; in-range verification is always $[C]$, never a proof.

Part II proceeds as follows. §B.2 fixes the finite cell — the gate, the two cones, the void operator and
its positivity. §B.3 unwinds it into the Aion flow and states the finite-to-infinite mechanism. §B.4
proves the Euler product necessary. §B.5 proves the wall forced and abelian. §B.6 defines the kernel
$K_L$ as the structure function of the Aion canonical system and recomputes the purity on the genome
itself. §B.7 presents the **second, complementary road** (Balashov's skeleton operator, Theorem M74, the
sign-count Re-Bound); §B.8 shows the two roads meet at one margin (and why the bridge between them is not
an equivalence); §B.9 states the **no-go** that bounds them both and exhibits the primes falling out of the
zeros. §B.10 assembles the synthesis — RH as the survival of a finite positivity across the infinite flow —
and shows the four faces are one. §B.11 is the honest ledger, and §B.12 the conclusion.

---

## §B.2 — The Finite Cell

This section fixes the finite apparatus that generates $\chi_8$: the gate, the two cones of its algebra,
and the void operator with its exact positivity. Everything here is finite and computed; nothing is
asymptotic. The cell defined here is the object that §B.3 will unwind into the infinite flow.

### B.2.1 The gate and the genome

For a prime $p\nmid 21$, the Frobenius class $\mathrm{Frob}_p\in G$ is read from the factorization type
of $f=x^7-7x+3 \bmod p$. The **genome** $a_p=\chi_8(\mathrm{Frob}_p)$ takes only four values:

$$
\begin{array}{c|c|c}
\text{class} & \text{cycle type of }f\bmod p & a_p=\chi_8\\\hline
1A & 1^7 & 8\\
2A & 1^3 2^2 & 0\\
3A & 1\cdot 3^2 & -1\\
4A & 1\cdot 2\cdot 4 & 0\\
7A,7B & 7 & 1
\end{array}
$$

— an infinite sequence over the **finite alphabet** $\{8,0,-1,1\}$. By Chebotarev it is equidistributed
by class measure, with mean $0$ and variance $1$ (since $\chi_8\perp\mathbf 1$ and $\|\chi_8\|=1$). The
local Euler factor at $p$ is fixed by the eight eigenvalues of $\rho_8(\mathrm{Frob}_p)$ — roots of unity,
the Satake parameters, the *states* of the gate — whose power sums $\sum_i\lambda_i^m=\chi_8(\mathrm{Frob}_p^m)$
are the von Mangoldt coefficients. The genome is the $m=1$ throughput; the full gate is the local factor.

Grouped by value (class sizes $1,21,56,42,24,24$), the genome's Chebotarev distribution is
$\{\,8:\tfrac1{168},\ 0:\tfrac{63}{168},\ -1:\tfrac13,\ 1:\tfrac{48}{168}\,\}$ — in particular
**$a_p=-1$ on exactly one prime in three** (the trit class $3A$, where the cubic amplitude $a_p(\chi_3)=0$).
The Born relation $a_p=|a_p(\chi_3)|^2-1$ (§A.5.2) makes this value a **floor**: $a_p\ge -1$ for every prime,
$-1$ being the total annihilation of $\chi_3$. The distribution holds to $\sim1\%$ over $3360$ primes near
$10^{60}$ (61-digit), with $\sum a_p=0$ exactly in sample — the mean-zero genome made visible $[C]$. (This
is the *floor*, fixed by the finite process; RH is the *fluctuation* around it.)

The value vector is rigid: $(8,0,-1,0,1,1)$ is the **unique** integer dimension-$8$ unit character of $G$
orthogonal to the trivial $[C]$. The alphabet is not chosen — it is forced.

### B.2.2 The two cones

The eight-dimensional $\chi_8$ is the octonion: seven imaginary units (the Fano points) and one real
unit (the void). Reading a *line* off the Cayley–Dickson table as a triple $\{a,b,c\}$ with
$e_ae_b=\pm e_c$:

- **Light cone (octonion).** The seven imaginary units give $7$ points, $7$ lines, $3$ per point, every
  pair on one line — the $2$-$(7,3,1)$ design $\mathrm{PG}(2,2)$, the **Fano matroid $F_7$**. The octonion
  is a division algebra (Hurwitz): no zero-divisors, every line associative. The light cone is *one* Fano
  plane, wall to wall. $[C]$
- **Dark cone (sedenion).** The doubling $\mathbb O\to\mathbb O\oplus\mathbb O$ has fifteen imaginary
  units: $15$ points, $35$ lines, $7$ per point — the $2$-$(15,3,1)$ design $\mathrm{PG}(3,2)$, containing
  **exactly fifteen Fano sub-planes** (the octonion subalgebras, the fifteen hyperplanes of
  $\mathrm{PG}(3,2)$). The sedenion is the first Cayley–Dickson algebra with **zero-divisors**; of its
  $455$ triples, $252$ ($55\%$) are non-associative. The dark cone is the last projective skeleton,
  riddled with the tears the zero-divisors make. Its zero-divisors are organized by the conductor:
  there are $84=4\cdot 21$ products $(e_a+e_b)(e_c+e_d)=0$ on distinct indices, i.e. $42=2\cdot 21$
  unordered pairs (verified by direct Cayley–Dickson computation). $[C]$

The two cones are *build* and *annihilation*: the octonion (division, no zero-divisors) is the matter
side; the sedenion (zero-divisors, pairing) is where annihilation lives. §B.10 reads this as the
forward/inverse of the Weil/Li sum.

### B.2.3 The void operator and its positivity

The gate's action on the seven-dimensional cell is governed by a self-adjoint **void operator**
$\mathcal O=C+iK$. Here $C$ (the *build*) is real symmetric with constant row sums $18$ — the all-ones
*void* eigenvector — and $K$ (the *chirality*) is the antisymmetric, time-reversal-breaking part
assembled from $P(g)-P(g^{-1})$ over the cones. Its characteristic polynomial is exact:

$$
\chi_{\mathcal O}(x)=(x-18)\,(x^2-4x-4)^2\,(x^2+8x+8),
$$

with spectrum $\{\,18,\ 2\pm 2\sqrt2\ (\text{double}),\ -4\pm 2\sqrt2\,\}$ $[C,\text{ first-party; char poly}$
$\text{independent of the }z_3\text{ choice}]$.
The $\sqrt2$ throughout is the characteristic-$2$ (quadratic) signature of the strata; the eigenvalue $18$
is the build.

The cell carries an **exact positivity**. The two-cone (AHK isotropy) form

$$
F(m,n)=\sum_{k=1}^{m-1}2\Big(1-\cos\tfrac{2\pi kn}{m}\Big)=\sum_{k=1}^{m-1}\big|\zeta_m^{kn}-1\big|^2
$$

is a **manifest sum of squares** in the $m$-th roots of unity $\zeta_m$ — the weight-$0$ Satake values of
B.2.1 — hence $F(m,n)\ge 0$ for every $n$, with $F(7,n)=14$ and $F(3,n)=6$ for $n\not\equiv 0$. This
positivity is **character-independent and exact** — a finite, proved theorem about the cell, not an
in-range numerical fact. $[C,\text{ first-party}]$

This is the load-bearing finite statement of Part II: the cell is positive — not approximately, not in
range, but exactly. The Riemann Hypothesis, in the form §B.10 reaches, is whether this exact finite
positivity *survives* when the cell is unwound into the infinite flow. We turn to that unwinding next.

---

---

## §B.3 — The Infinite Flow (the Aion)

The cell of §B.2 is finite and exactly positive. Yet the Riemann Hypothesis concerns infinitely many
primes. This section resolves the tension by unwinding the finite cell into an infinite flow — a de
Branges canonical system — and by locating, precisely, where the infinitude resides: not in any instant
of the flow, but in its variation.

### B.3.1 The closing clock and its unwinding

The void operator $\mathcal O=C+iK$ of §B.2.3 is a clock. Its build part $C$ is real symmetric; were the
chirality absent ($K=0$), $\mathcal O$ would be self-adjoint and *closed* — a compact rotation with a
discrete, periodic spectrum, an object entirely finite. The chirality $K\neq 0$ — the
time-reversal-breaking part — tips this closed clock into **directed motion**. Passing to the Cayley
transform $U=(\mathcal O-i)(\mathcal O+i)^{-1}$ carries the operator from the line to the circle and back;
applied to the directed (non-self-adjoint-perturbed) clock, it unwinds the compact rotation onto the
half-line $t\in[0,\infty)$. The finite clock becomes a flow. $[R$; the Cayley map is standard $T]$

### B.3.2 Why the flow never closes

The clock has two hands of coprime order: the **trit** $z_3$ (order $3$) and the **Singer** cycle
$\sigma$ (order $7$). They do not commute — the holonomy is

$$
z_3\,\sigma\,z_3^{-1}=\sigma^{r},\quad r\in\{2,4\},\ r^{3}\equiv 1\ (\mathrm{mod}\ 7),\ r\neq 1, \qquad [C,\text{ first-party}]
$$

— and $\gcd(3,7)=1$. A composite rotation of coprime, non-commuting orders has no common period: the
flow is **aperiodic** and never returns to its start. The finite clock, once unwound, runs **forever**.
That unending run is the flow's time parameter $t$; in the framework's reading the flow *is* time, and
its inexhaustibility is exactly the coprimality of the trit and the Singer refusing to resolve. $[C/R]$

*A terminology guard, now enforced by a theorem.* The **trit clock** (the order-3 hand, its $\omega$-tick,
its transport on the Singer dial) and the **canonical Aion** $\mathcal A$ (the unwound de Branges flow of
§B.3.3) are distinct objects and must not be conflated: the strict identification "clock $=$ heat flow" was
tested and **fails** (a proven GAP negative; Part IV, §D.4). What the trit does is *select* — a fixed point,
a key, a class — not flow. The definitions of this section were always so; the negative makes the
distinction empirical. $[T/C]$

### B.3.3 The canonical system

Formally, the unwound cell is a **de Branges canonical system**: a Hamiltonian $H(t)\succeq 0$ on
$t\in[0,\infty)$, a finite (matrix) cell at each instant, with an entire **structure function** $E(s)$.
The completed L-function is recovered from $E$ — $\Lambda(s,\chi_8)$ is its symmetric part — and the
non-trivial zeros are the **spectrum of the system**, the eigenvalues of the self-adjoint operator
$\mathcal A$ it defines. This is the Aion. That a self-dual L-function of Selberg class admits such a
representation is the de Branges framework $[T]$; the specific Hamiltonian seeded by the cell of §B.2 is
the construction proposed here.

In this language the Hilbert–Pólya dream is precise: the zeros lie on the line iff $E$ is
**Hermite–Biehler** (all its zeros in one half-plane) iff $H(t)\succeq 0$ for all $t$ iff $\mathcal A$ is
self-adjoint. The Riemann Hypothesis is the **positivity of the flow**.

### B.3.4 How the flow carries the primes

A natural objection closes the naive operator route and must be met head-on. By the explicit formula the
zeros encode the prime alphabet $\{\log p\}$, which is $\mathbb Q$-linearly independent (Baker) — an
object of **infinite rank**. A finite operator has finite rank and cannot reproduce it. For a finite
*matrix*, this is decisive.

It does not touch the canonical system. $H(t)$ is finite at each instant, but the **map** $t\mapsto H(t)$
— the *variation of the cell along the flow* — is an infinite object, and it is precisely there that the
primes are encoded. No single instant holds $\{\log p\}$; the unending run does. The Aion is therefore
**finite-per-instant, infinite-in-flow**: the apparent paradox of a finite machine carrying an infinite
arithmetic dissolves once one distinguishes the cell (finite, at each $t$) from its history (infinite,
over all $t$).

### The statement, and the guard

Collecting §§B.2–B.3:

> The cell is finite and exactly positive (§B.2.3). It is unwound by the arrow into an infinite,
> never-closing flow (§B.3.1–2), a de Branges canonical system whose spectrum is the zeros (§B.3.3), with
> the prime data carried in the flow's variation (§B.3.4). **RH$(\chi_8)$ is the statement that the
> cell's exact finite positivity survives as the positivity of the flow**, $H(t)\succeq 0$ for all $t$.

Two honest cautions attach to this and are carried for the rest of Part II. First, *relocating* RH to the
flow's positivity does not prove it: de Branges' own program shows this positivity is exactly as hard as
RH, because it **is** RH. Second — the circularity guard — the Hamiltonian $H(t)$ must be constructed from
the cell and the gate, **not** from the zeros; an operator built from the zero list reproduces them
trivially and proves nothing. The content of the operator route is entirely in whether the flow can be
built *forward*, from the finite arithmetic of §B.2, without knowing where its spectrum will fall.

*[Formalized 2026-07-14.]* The equivalence chain sketched here is now a **stated, proven lemma**: the
**Aion Reformulation Lemma** [R-011a] proves, *conditionally on the hypothesis (H) that a matrix de
Branges canonical system representing $\Lambda(s,\chi_8)$ exists*, the six-form equivalence
($\mathcal A$ self-adjoint $\iff E$ Hermite–Biehler $\iff H(t)\succeq0\ \forall t\iff|K_L|=1$ only on
$\mathrm{Re}\,s=\tfrac12\iff\lambda_n\ge0\ \forall n\iff\mathrm{GRH}(\chi_8)$), with (H) displayed —
not positivity-assuming — and the entirety of $L(s,\chi_8)$ unconditional via the cubic-Hecke
realization of §B.5.3. The lemma *relocates* the Hypothesis; it decides nothing: the construction of
the representing system from the cell (C1–C3) and the positivity itself remain exactly as open as this
section states [R-209]. We cite it rather than restate it. $[P,\ \text{conditional on (H)}]$

What forces that flow to keep the zeros on the line — rather than merely to have a symmetry axis there —
is the subject of §B.4: the Euler product.

---

---

## §B.4 — The Euler Product Is Necessary

§B.3 unwound the cell into a flow whose structure function carries the functional equation. But a
functional equation fixes the symmetry *axis* at $\mathrm{Re}(s)=\tfrac12$; it does not, by itself, fix
the *zeros* there. This section proves that the ingredient holding the zeros to the line is the **Euler
product**, by exhibiting a function with everything *except* an Euler product that fails the Hypothesis.

### B.4.1 The axis is not the line

The completed L-function satisfies $\Lambda(s)=\varepsilon\,\Lambda(1-s)$, so its non-trivial zeros are
symmetric under $s\mapsto 1-s$: a zero at $\beta+i\gamma$ is paired with one at $1-\beta+i\gamma$. This
makes $\mathrm{Re}(s)=\tfrac12$ the *axis of symmetry* — but a pair with $\beta\neq\tfrac12$ is fully
consistent with it. The functional equation constrains the zeros to a symmetric configuration, not to a
line. [exposition]

### B.4.2 The Davenport–Heilbronn witness

That this gap is real — that a self-dual functional equation alone admits off-line zeros — is a theorem
of **Davenport and Heilbronn (1936)**. Let $\chi$ be the quartic character modulo $5$ ($\chi(2)=i$).
Neither $L(s,\chi)$ nor $L(s,\bar\chi)$ is self-dual, but a specific combination

$$
f(s)=c\,L(s,\chi)+\bar c\,L(s,\bar\chi),
$$

with $c$ chosen so the completed function is self-dual (Titchmarsh, *Theory of the Riemann Zeta-function*,
§10.25), satisfies a clean functional equation $\xi(s)=\xi(1-s)$ in the *same* $\Gamma$-factor class as a
genuine Dirichlet L-function. But $f$ is a **sum** of two L-functions, and a sum is not multiplicative:
**$f$ has no Euler product.** Davenport and Heilbronn proved $f$ has infinitely many zeros with
$\mathrm{Re}(s)\neq\tfrac12$. One such zero, computed to $38$ digits — reproducing the classical value:

$$
s=0.808517182456637\ldots+85.6993484853776\ldots\,i,\qquad
\mathrm{Re}(s)=0.8085\neq\tfrac12,\qquad |f(s)|\approx 3\times10^{-38}.
$$

$[T$ (the theorem, classical) $+\ C$ (the value, reproduced)$]$. Everything is present — the functional
equation, the symmetry axis, the gamma class — except the Euler product, and the zero leaves the line.
The obstruction is visible *locally*: the prime-power Hankel $[a_{p^{i+j}}]$ is rank-$1$ (a single Satake
tone, positive-semidefinite) at every prime exactly when the Euler product is genuine, and breaks to rank
$\ge 2$ (indefinite) precisely at the complex-character primes of the Davenport–Heilbronn two-tone — a
prime-by-prime filter that flags the non-Euler case at the first such prime $[C$, joint$]$. The general
invariant behind this filter is **Kronecker rank**: a coefficient string $(a_{p^k})$ is a genuine degree-$d$
Euler factor exactly when its Hankel $[a_{p^{i+j}}]$ has finite rank $d$ (equivalently, an order-$d$ linear
recurrence). The *rank-$1$, positive-semidefinite* reading above is the **degree-$1$ instance** — the single
Satake tone driving the Davenport–Heilbronn comparison; for degree $\ge 2$ a genuine Euler factor is
generically **indefinite** (Ramanujan's $\tau$, unitary by Deligne, already has an indefinite $2\times2$
Hankel; $\chi_8$'s own degree-$8$ factors likewise), so it is the **rank, not positivity**, that is the
Euler signature, and the non-multiplicative sum is caught as the rank *jump* $1\to2$ at the first
complex-character prime. $[T$: Kronecker; ours$]$

### B.4.3 The Euler product forbids the escape

The complementary constraint is elementary and points the same way. An Euler product
$L(s)=\prod_p\prod_i(1-\lambda_{i,p}\,p^{-s})^{-1}$ with $|\lambda_{i,p}|\le 1$ converges absolutely for
$\mathrm{Re}(s)>1$ and is there bounded away from $0$: it has **no zeros in $\mathrm{Re}(s)>1$** at all.
The functional equation reflects this to $\mathrm{Re}(s)<0$ (off the trivial zeros), and the critical
strip is what remains. For $\chi_8$ the Euler product *is* the octonion gate of §B.2; so $\chi_8$ has no
zeros outside the strip, and inside it — in range, pinned (§B.10) — the zeros sit on the line. Same gamma
class as the Davenport–Heilbronn function, **opposite fate**: the only difference is the gate. [T,
elementary]

### B.4.4 A companion where the Hypothesis is a theorem

The Davenport–Heilbronn function is a symmetric object *without* a self-adjoint origin that fails the
Hypothesis. There is a complementary object — *with* a self-adjoint origin — for which the Hypothesis is a
**theorem**, and it is assembled from the very same local data as $\chi_8$. It isolates exactly what the
arithmetic side lacks.

Write $\mathrm{PSL}(2,7)=\Delta/\Gamma$, where $\Delta=\Delta(2,3,7)$ is the $(2,3,7)$ triangle group acting
on the hyperbolic plane $\mathbb H$ and $\Gamma$ is its surface kernel; the quotient orbifold
$\mathcal O=\mathbb H/\Delta$ has the Klein quartic $X(7)=\mathbb H/\Gamma$ (genus $3$, automorphism group
$\mathrm{PSL}(2,7)$) as its minimal smooth cover. The eight-dimensional representation $\rho_8$ realizing
$\chi_8$ pulls back along $\Delta\twoheadrightarrow\mathrm{PSL}(2,7)$ to a unitary representation of $\Delta$,
and the associated **twisted Selberg zeta function**

$$
Z(s,\chi_8)=\prod_{\gamma}\prod_{k\ge0}\det\!\Big(I_8-\rho_8(\mathrm{hol}\,\gamma)\,e^{-(s+k)\,\ell(\gamma)}\Big),
$$

a product over the primitive closed geodesics $\gamma$ of $\mathcal O$ (length $\ell(\gamma)$, holonomy
$\mathrm{hol}\,\gamma\in\mathrm{PSL}(2,7)$), is entire and satisfies a functional equation $s\mapsto 1-s$.
Its non-trivial zeros are $s=\tfrac12\pm i\sqrt{\lambda_n-\tfrac14}$, where $\{\lambda_n\}$ is the spectrum of
the **self-adjoint** Laplacian on the flat bundle $\rho_8$ over $\mathcal O$. Real eigenvalues force every such
zero onto $\mathrm{Re}(s)=\tfrac12$ (with at most finitely many on the segment $(0,1)$, from any eigenvalues
below $\tfrac14$): **the Riemann Hypothesis for $Z(s,\chi_8)$ is a theorem** (Selberg). $[T]$

The two objects share their entire local structure. The geodesic factor and the arithmetic Euler factor are
the *same* polynomial evaluated at different arguments: for a conjugacy class $C\subset\mathrm{PSL}(2,7)$,

$$
\det\!\big(I_8-\rho_8(C)\,t\big),\qquad t=e^{-\ell}\ \ (\text{geodesic})\quad\text{vs.}\quad t=p^{-s}\ \ (\text{prime}),
$$

and these five polynomials — one per class,
$(1-t)^8,\ (1-t)^4(1+t)^4,\ (1-t)^2(1+t+t^2)^3,\ (1-t)^2(1+t)^2(1+t^2)^2,\ (1-t)^2(1+t+\cdots+t^6)$ —
are precisely the local factors of $L(s,\chi_8)$, verified directly from the character table. $[C]$ Furthermore
the geodesic holonomies and the prime Frobenius classes equidistribute by the *same* Chebotarev measure
$|C|/168$ over $\mathrm{PSL}(2,7)$. $[T]$

So $L(s,\chi_8)$ and $Z(s,\chi_8)$ are built from identical group-theoretic ingredients, and on the geodesic
side the Hypothesis holds because a self-adjoint operator supplies it. The two are **not** the same function —
their zeros are different numbers — and we do not identify them. Indeed they **cannot** be the same operator:
the geodesic zeros come from a two-dimensional hyperbolic Laplacian, whose Weyl law gives a zero density
$\sim T^2$, whereas $L(s,\chi_8)$ carries the Riemann–von Mangoldt density $\sim T\log T$ (§A.7). The
density-matched Hilbert–Pólya vehicle for a $T\log T$ count is therefore not a Laplacian but the
**Berry–Keating/Connes $\hat x\hat p$** Hamiltonian — consistent with the quantum-chaotic (GUE) statistics of
§B.10, and complementary to the no-go of §B.9. The gap is exactly the dictionary
$p\leftrightarrow e^{\ell}$ together with an operator realizing the prime side: a self-adjoint operator whose
spectrum is the zeros of $L(s,\chi_8)$. This is the Hilbert–Pólya formulation, here equipped with a concrete
twin — the missing ingredient for $\chi_8$ is not a symmetry or a positivity it already possesses, but the
**self-adjoint operator** its geometric companion has outright. Whether such an operator exists over
$\mathbb Q$ is the Hypothesis; the no-go of §B.9 is precisely the obstruction to importing it from the
geometry. We prove nothing about $L(s,\chi_8)$ here; the companion only names the missing ingredient.
$[\text{exposition; } \mathrm{OPEN}]$

### Conclusion

The Euler product is **necessary**: it is the multiplicative binding that holds the flow's zeros to the
axis the functional equation supplies. In the language of §B.3, the functional equation gives the flow
its mirror symmetry, but only the Euler product — the gate, binding all primes at once — keeps the flow's
spectrum real. Remove it, and the spectrum demonstrably leaves the line. The *necessity* is proved here;
the *sufficiency* — Euler product $\Rightarrow$ every zero on the line — is the Riemann Hypothesis, taken
up in §B.10. Three objects in the same gamma class bracket that open statement: the Davenport–Heilbronn
function (functional equation, no Euler product) fails it; the geometric companion $Z(s,\chi_8)$ of §B.4.4
(a self-adjoint operator) satisfies it as a theorem; and $L(s,\chi_8)$ — Euler product present, operator not
yet exhibited — sits between them, which is exactly where the Hypothesis lives.

---

---

## §B.5 — The Wall Is Forced

§B.4 located the missing ingredient; this section identifies the *nature* of the wall it leaves. We show
that $\chi_8$'s Riemann Hypothesis is not an arbitrary analytic statement but a **forced** one: $\chi_8$ is
generated by a CM motive, is realized explicitly as an abelian Hecke L-function, and admits no non-CM
realization — so $\mathrm{RH}(\chi_8)$ is exactly $\mathrm{GRH}$ for one explicit *cubic* Hecke character.
The computations of this section were performed on the 32 GB machine and are cited as such; the
propagation between them is standard.

### B.5.1 The root is CM

The generating quark $\chi_3$ is CM, as established in §A.6.1: it is $H^0(X(7),\Omega^1)$ with Jacobian
isogenous to $E^3$, $E$ of conductor $49$ ($j=-3375$) having complex multiplication by $\mathbb Q(\sqrt{-7})$
— the CM visible arithmetically as $a_p(E)=0\iff p$ inert in $\mathbb Q(\sqrt{-7})$. The generating motive of
the family is CM $[C]$.

### B.5.2 CM propagates through the tower

Part I established that every family member is a tensor construction of $\chi_3$: $\mathrm{Sym}^2\chi_3=\chi_6$,
$\Lambda^2\chi_3=\bar\chi_3$, and $\chi_3\otimes\bar\chi_3=\mathbf 1\oplus\chi_8$ (the Born relation,
confirmed on $6055$ primes $[C]$). CM motives form a Tannakian subcategory closed under
$\otimes,\mathrm{Sym}^k,\Lambda^k$, with the Mumford–Tate torus preserved $[T$: Deligne; Shimura–Taniyama$]$.
Hence each member, a tensor word in the CM root, is itself CM — its Mumford–Tate group a sub-torus of the
$\mathbb Q(\zeta_7)$-torus.

### B.5.3 The explicit Hecke realization

For $\chi_8$ the consequence is made concrete. The monomial reduction $\chi_8=\mathrm{Ind}_{7:3}^{G}\psi$
gives, by Artin's induction invariance, $L(s,\chi_8)=L_{K_H}(s,\psi)$, a degree-$1$ Hecke L-function over
the octic field $K_H$. The octic field is the LMFDB field $K_H=$ `8.0.37822859361.1`, $K_H=\mathbb Q[x]/(x^8-4x^7+7x^6-7x^5+7x^4-7x^3+7x^2+5x+1)$,
with $\mathrm{polgalois}=[168,\mathrm{PSL}(2,7)]$, $\mathrm{disc}(K_H)=3^8 7^8$, class group $\mathbb Z/4$.
Of its $26$ cubic ray-class characters, **exactly two** — $\psi,\bar\psi$ — have conductor norm
$N\mathfrak f=441=3^2 7^2$; the channel is thus uniquely selected, and the conductor–discriminant formula
gives $\mathfrak n(\chi_8)=N\mathfrak f\cdot\mathrm{disc}(K_H)=441\cdot 3^8 7^8=21^{10}$. The resulting Hecke
L is verified equal to $L(s,\chi_8)$: same conductor, same gamma $\Gamma_{\mathbb C}(s)^4$, same functional
equation. Two determinations of $a_p$ — **Path A** (Frobenius cycle type of $x^7-7x+3 \to$ character table)
and **Path B** ($a_p$ of the Hecke $L(s,\psi)$) — agree on **all $166$ unramified primes $p<1000$ with zero
mismatches**, and all $120$ Dirichlet coefficients are identical $[C]$. Two L-functions of the same degree
and conductor agreeing on every Euler factor are the same L-function. Therefore

$$
\boxed{\ \mathrm{RH}(\chi_8)\iff\mathrm{GRH}(\psi),\quad \psi\ \text{an explicit cubic Hecke character of }K_H.\ }
$$

Equivalently the lift is automorphic: $\chi_8=\mathrm{AI}_{K_H/\mathbb Q}(\psi)$ is the automorphic
induction of $\psi$ to a unique cuspidal automorphic representation of $\mathrm{GL}(8)/\mathbb Q$ $[T]$. The
trit reappears here: $\psi$ has **order $3$** — the same order-$3$ structure as the finite ternary operator
of §B.3. The order-$3$ thread runs unbroken from the cell to the analytic object.

### B.5.4 Sato–Tate is the torus

The CM is confirmed by the Frobenius distribution: for a CM motive the Sato–Tate measure is the **torus**,
not $\mathrm{SU}(2)$, so the second moment $\langle(a_p/\sqrt p)^2\rangle=2$, not $1$. This was computed in
§A.6.3 (over $8972$ split primes: uniform angles, Kolmogorov–Smirnov $0.0095$; the semicircle rejected;
$\langle(a_p/\sqrt p)^2\rangle=1.99$) $[C]$ — the Mumford–Tate torus confirmed empirically.

### B.5.5 No lever, hence forced

A CM (torus-MT) motive has **no non-CM realization**: its symmetric and tensor powers factor into abelian
Hecke L-functions (Tate-twisted to weight $0$), so there is no auxiliary positive-weight, Deligne-pure
motive from which to import positivity. The "no shortcut" the program repeatedly met is therefore not a
gap in the analysis but a structural feature — the Deligne lever is **provably absent** $[C\to T]$.

The distinction is load-bearing: the *analytic wall* is abelian — the L-function **equals** $L(\psi)$, an
abelian Hecke L, by induction — yet the Artin *representation* $\chi_8$ is itself genuinely non-abelian, and
no $\mathbb Q$-side reciprocity reaches it either. The genome $a_p$ is provably **not** a function of $p\bmod 21$: e.g.
$a_2=+1\neq a_{23}=-1$ though $2\equiv23\equiv 2\pmod{21}$ (over $107$ primes, $71$ such residue-class
disagreements) $[C]$. And although $\psi$ takes values in $\mu_3$ (the trit), $K_H$ is primitive and
$\mathbb Q(\omega)\not\subset K_H$ ($G$ simple, the tower $\omega$-free), so there is no cubic-reciprocity
identity to exploit — the character is *Eisenstein in value but not in field*. Both the geometric lever
(no Deligne pure motive) and the arithmetic lever (no reciprocity) are absent.

### The necessity theorem

> **Theorem (the structure is forced).** The genome family is generated by a CM motive (§B.5.1), closed
> under the tensor operations that build it (§B.5.2); $\chi_8$ is realized explicitly as the abelian Hecke
> L-function of a cubic character $\psi$ over $K_H$ (§B.5.3), with Sato–Tate the torus (§B.5.4); and no
> non-CM realization exists (§B.5.5). Hence $\mathrm{RH}(\chi_8)\iff\mathrm{GRH}(\psi)$, and nothing weaker
> than GRH for an abelian Hecke L reaches it.

Items (B.5.1, B.5.3, B.5.4) are computed; (B.5.2, B.5.5) are standard CM propagation resting on them. The
*structure* is forced; RH is not thereby proved. "We found no shortcut" is upgraded to "there provably is
none" — the attainable half of *it could not be otherwise*. What remains is exactly $\mathrm{GRH}(\psi)$,
taken up among the equivalent faces of §B.10.

---

---

## §B.6 — The K-modulus: the Flow's Balance as Purity

The Aion of §B.3 is a de Branges canonical system, and its positivity is the Riemann Hypothesis. This
section makes that positivity into an explicit **modulus** condition — the K-modulus — by reading off the
system's structure function, and verifies the condition *in range, on the genome's own zeros*, retiring
the quadratic proxy of an earlier computation.

### B.6.1 The kernel $K_L$ as the Aion's structure function

A de Branges canonical system $H(t)$ has an entire **structure function** $E(s)$, and the completed
L-function is recovered from its decomposition into real-entire parts: writing
$\Lambda(\tfrac12-iz,\chi_8)=A(z)-iB(z)$ with $A,B$ real entire, the structure function is $E=A-iB$.
Define the deposit kernel

$$
K_L(s)=\frac{E^*(s)}{E(s)},\qquad E^*(s)=\overline{E(\bar s)}.
$$

This is the scattering ratio of the Aion: on the critical line ($z$ real) numerator and denominator are
complex conjugates, so $|K_L|=1$ identically; off the line its modulus measures the deviation of the flow
from positivity. $K_L$ is not shorthand — it is the structure function of the canonical system *proposed*
in §B.3 (whose cell-seeded Hamiltonian is the construction conjectured there, not yet built). $[T$: de
Branges$]$

### B.6.2 The K-modulus theorem

The Hermite–Biehler condition states that $E$ has all its zeros in the lower half-plane iff the canonical
system is positive, $H(t)\succeq 0$ — equivalently $|E^*(z)|<|E(z)|$, i.e. $|K_L|<1$, throughout the open
upper half-plane. Translated to $s$:

$$
|K_L(s)|=1\ \Longleftrightarrow\ \mathrm{Re}(s)=\tfrac12,\qquad\text{iff}\quad\mathrm{RH}(\chi_8).
$$

The modulus is $1$ on the line by construction; the content is that it is $1$ **only** there — an off-line
zero $\rho$ would produce a second point with $|K_L(\rho)|=1$. RH is the *purity* statement that the
modulus-$1$ locus is exactly the line. For $\chi_8$ (degree $8$, $\gamma=\Gamma_{\mathbb C}(s)^4$) the
canonical system is matrix-valued, so $E$ and $K_L=E^{-1}E^*$ are matrices and the purity is the
**unitarity of an eight-dimensional scattering matrix** on the line (the Schur form) — not the scalar purity of a degree-$1$
L-function. $[T$; RH-equivalent$]$

### B.6.3 Local purity and its survival

The purity splits into a free local half and an open global half. Locally, the Satake parameters of
§B.2.1 — the eight eigenvalues of $\rho_8(\mathrm{Frob}_p)$ — are roots of unity, of modulus exactly $1$
at every prime (for an Artin L-function the Ramanujan bound is automatic), so every local factor is
unitary. The K-modulus is whether this per-prime modulus-$1$ **assembles**, through the infinite Euler
product (§B.4) along the flow (§B.3), into a globally modulus-$1$ scattering matrix on the line:

$$
\mathrm{RH}(\chi_8)\ =\ \big[\ \text{local modulus-1 (Satake) survives as global modulus-1 } (K_L)\text{ on the line}\ \big].
$$

This is the finite-cell / infinite-flow dichotomy of §B.3 in purity language: the local purity is free (a
theorem), the global purity is the survival (RH).

### B.6.4 The proxy retired — positivity on the genome's own zeros

An earlier operator computation demonstrated the in-range positivity through a *tame quadratic* stand-in,
the character $(\tfrac{\cdot}{21})$, because $\chi_8$'s wild ramification then blocked its zeros. With
$\chi_8$ now realized as the **cubic** Hecke $L(\psi)$ (§B.5.3) and its zeros computed, the positivity is
recomputed on the genome itself. The void-pressure moments $S_k=\sum_n \gamma_n^{-2k}$ ($\gamma_n$ the
ordinates of $\chi_8$'s zeros) form a Stieltjes sequence iff the ordinates are real; their Hankel
determinants $H_m=\det[\,S_{i+j+1}\,]_{i,j=0}^{m-1}$, on $\chi_8$'s own zeros, are

$$
H_1=2.985,\quad H_2=1.057,\quad H_3=1.95\times10^{-2},\quad H_4=8.8\times10^{-6},\quad H_5=6.0\times10^{-11},
$$

all positive and collapsing Gaussian-fast — the marginal *knife-edge* (the de Bruijn–Newman edge
$\Lambda_{\mathrm{dBN}}=0$ of §B.10.2; not to be confused with the completed L-function $\Lambda(s)$) — at
the genome's first ordinate $\gamma_1=0.986$, not the proxy's $2.316$. $[C,\text{ first-party}]$. The order-$3$ thread is now
complete: the finite ternary operator (§B.3), the cubic Hecke $\psi$ (§B.5), and this positivity are one
object, computed on the trit genome throughout.

*The ledger, extended to certified grade.* With the seventeen certified zeros of §A.9.1/§C.8, this table now
runs ten levels deeper and at a stronger grade: every $H_m$, $m\le17$, is evaluated over all $2^9=512$
bracket-corner combinations of the certified zeros — **positive at every corner** (spreads $\le5\%$ through
$m=13$, growing to $37\%$ at $m=17$, driven by the widest bracket $\gamma_{14}\in[4.357,4.379]$; positivity is
robust, only the high-$m$ *value* is bracket-limited) — and the density-tail-corrected sequence — the
non-automatic content — stays positive through $m=17$. The collapse profile $\log_{10}H_m/m^2$ drifts to
$-0.966$ at $m=17$, **reconciling** the earlier "$\approx-0.8$" extrapolation with the original eight-zero rate
fit $c\approx0.99$ (one curve at different depths); the zero-side Li partials lift toward the prime-side values
above with turnover at $n\approx10$ (peak $\approx51$). Full tables in §C.8.2. **Certified finite ledger
through $m=17$: finite positivity and margin profile only** — the gap between "positive through
$m=17$" and "positive for all $m$" is, as ever, the wall. $[C]$ *(Dated note, 2026-07-19/25: the
certified atom supply has since grown from seventeen brackets to the 152-bracket certified spectrum of
§C.8.1b; the ledger's $m\le17$ evaluation is unchanged and stands as computed — its extension on the
deeper certified atoms is staged, not claimed.)*

That Hankel positivity is read from the *zeros*, and is in that sense weak — on the line $|1-1/\rho|=1$, so
it half-assumes what it tests. The **same** positivity read from the **prime side** is not circular. The
Weil/Li coefficients $\lambda_n=\sum_\rho\big[1-(1-1/\rho)^n\big]$ can be evaluated directly from $-L'/L$ and
its derivatives at $s=1$ — i.e. from the Satake/genome data, **no zeros used**; over $n=1,\dots,10$ this gives
$\lambda_n=4.3,\,16.0,\,31.8,\,48.6,\,64.7,\,80.6,\,97.3,\,115.7,\,135.5,\,155.4$, all positive (the method
validated on $\chi_{-4}$ to $10^{-6}$) $[C]$. Since the primes carry no knowledge of where the zeros lie,
$\lambda_n>0$ *from the prime side* is genuine arithmetic positivity, not the tautology of the spectral side.

### B.6.5 The diagonality is forced (Aramata–Brauer)

The positivity has a representation-theoretic backbone independent of the numerics. The Weil prime-pairing
acts on the modes of $\chi_8\otimes\chi_8$, which by §A.5.4 decomposes as $\mathbf 1\oplus(\text{five
non-trivial irreducibles})$. The trivial part is $\zeta$, whose simple pole at $s=1$ supplies a positive
diagonal constant $c=\langle a_p^2\rangle=1$; every non-trivial constituent $\rho$ has $L(s,\rho)$
**holomorphic at $s=1$** by Aramata–Brauer, contributing no pole and no diagonal mass. Hence on the
prime-mode span the pairing is

$$
W=c\cdot I,\qquad c=1>0,
$$

diagonal and positive — the off-diagonal "prime conspiracy" *cannot* occur, because multiplicity-one
($\langle\chi_8\otimes\chi_8,\mathbf 1\rangle=1$) leaves exactly one pole. The in-range Hankel positivity of
§B.6.4 is the analytic shadow of this exact algebraic fact $[C\to T]$ (the multiplicity computed first-party,
Aramata–Brauer standard). What it does *not* settle is the survival of $W=c\cdot I$ on the **full** flow, not
only the finite prime-mode cell.

### Scope

The K-modulus is RH-equivalent, not a proof: $|K_L|=1$ on the line and the Hankel positivity are checked
*in range* (originally to $m=5$, an extended zero set to $m\approx7$; now, with the certified zero table,
to $m=17$ at bracket-corner grade — §B.6.4, §C.8.2), and "positive through $m=17$" is not
"positive for all $m$," which is RH. The de Branges program is candid that this canonical-system positivity
is exactly as hard as RH, because it *is* RH. What §B.6 supplies is the precise object — $K_L$ as the
Aion's structure function — and its verification, in range, on the genome rather than a proxy. The faces
this assembles are unified in §B.10.

---

---

## §B.7 — The Second Road: Skeleton Zeros and the Sign-Count (Balashov)

Part II's operator road (§B.3–B.6) is one of *two* complementary finite-level constructions that reduce the
Hypothesis to a positivity surviving a limit. The second, due to Balashov, is analytic rather than
operator-theoretic; it is built on the classical Riemann object $\Xi$, and it is included here because the
two roads meet at one wall (§B.8) and are bounded by one no-go (§B.9).

### B.7.1 The finite-level operator $\tilde M_N$

The Theta–Hurwitz operator at level $N$,

$$
\tilde M_N(t)=4\sum_{n=1}^N\int_0^\infty\Phi_n(u)\cos(tu)\,du,\qquad
\Phi_n(u)=\big(2\pi^2 n^4 e^{9u/2}-3\pi n^2 e^{5u/2}\big)e^{-\pi n^2 e^{2u}},
$$

is a finite truncation converging to $\Xi(t)=\xi(\tfrac12+it)$ on the real axis; the oscillatory integral
admits a closed form via the incomplete gamma function (a computational device of the road). The **skeleton
zeros** $\{t_j^{(N)}\}$ are the real zeros of $\tilde M_N$ — by construction, on the line. $[C$, Balashov$]$

### B.7.2 Theorem M74 — the skeleton zeros converge to the Riemann zeros

**Theorem (M74, Fixed-Zero Convergence).** For each simple zero $\gamma_j$ of $\Xi$ and all $N\ge N_0(j)$
there is a unique skeleton zero $t_j^{(N)}$ with $|t_j^{(N)}-\gamma_j|<\tfrac13\min_{k\neq j}|\gamma_k-\gamma_j|$;
hence $t_j^{(N)}\to\gamma_j$.

The proof is Rouché on a disk $D_j$ around $\gamma_j$: the tail bound $|\Xi-\tilde M_N|\le C(N+1)^2 e^{-\pi(N+1)^2}$
holds on $D_j$ (super-exponentially small) and drops below $\min_{\partial D_j}|\Xi|$ once $N\ge N_0(j)$, so
$\tilde M_N$ has exactly one zero in $D_j$. (Numerically $N=2$ already gives tail $\le5.9\times10^{-11}\ll
\varepsilon_1=1.4\times10^{-5}$.) Conditional on simplicity of $\gamma_j$, known for all computed zeros.
$[T/C$, Balashov; independently reproduced$]$

The theorem's disks now carry **interval-grade certificates in batch**: for $\gamma_1,\dots,\gamma_{40}$ of
$\zeta$, the Rouché comparison $A_{N,j}<B_j$ was certified with ball arithmetic end to end —
$B_j=\inf_{C_j}|\Xi|$ by arc-chunk ball enclosures (an arc inside an acb ball makes the enclosure itself the
proof; no separate modulus-of-continuity argument), $A_{N,j}$ by monotone incomplete-gamma tail bounds with a
certified geometric closure. All 40 disks certify, with margins $B/A$ from $10^{1}$ to $2\times10^{15}$; and
$\gamma_1$ is certified **twice, by disjoint methods** (arc-chunk balls; adaptive subpatches
$[$Balashov$]$) — the two implementations auditing each other at the first zero. The canonical-skeleton
normalization handshake is **confirmed by computation** (2026-07-11): our canonical $\theta$-AFE
$\tilde M_N=\tfrac{s(s-1)}2\big[\sum_n((\pi n^2)^{-s/2}\Gamma(s/2,\pi n^2)+(\pi n^2)^{-(1-s)/2}\Gamma(\tfrac{1-s}2,\pi n^2))-\tfrac1s-\tfrac1{1-s}\big]$
reproduces Balashov's $M_3$ to $\sim\!10^{-20}$ on the $\gamma_1$ contour (up to his stated $\Xi/2$ factor),
so the $40/40$ table is on his M74 operator; only Balashov's exact-convention one-liner remains before the
batch enters the registry. $[C$, joint; Part III appendix artifacts$]$

The skeleton tracks the true zeros; what remains is that none strays off the line as $N\to\infty$ — the
Re-Bound.

### B.7.3 The Re-Bound, in sign-count form

The natural finite-$N$ margin — the *edge gap*, the distance from the last skeleton zero to the spectral
wall at $0.58\,S_N$ — **fails as a floor**. The wall sweeps $\sim 36$ zero-spacings per $N$-step through an
incommensurate set, so it equidistributes and the running minimum $\to 0$ (the near-misses, edge gap
$=0.029$ at $N=44$, are the trend, not a fluctuation). A continuous distance the geometry drives to zero
cannot carry a positivity floor. The failure is not a defect but a **fingerprint of GUE**: the wall samples
a GUE *flow*, not a lattice, and the coprimality $3\perp 7$ (lattice step $3$, Singer flow $7$) forces the
incommensurate equidistribution. A positive floor would require the zeros to be lattice-like; their
GUE-rigidity (§B.10.2) is exactly why no floor exists. $[C$, joint$]$

The correct invariant is **discrete**: a zero landing near the wall is still counted; what would violate RH
is a *miscount* — a zero on the wrong side. So the road's condition is a sign-count:

> **Re-Bound (sign-count form).** For all $N$, the number of real zeros of $\tilde M_N$ below the wall (its
> sign-changes, by construction on the line) equals the total zero-count of $\Xi$ below the wall.

This count decomposes exactly,

$$
R_N=\underbrace{\bar N(\text{wall})}_{\text{geometry, }\pm O(1)}+\underbrace{S(\text{wall})}_{\text{primes}},
\qquad S(T)=\tfrac1\pi\arg\zeta(\tfrac12+iT),
$$

the geometry supplying the smooth count to $\pm O(1)$, the prime term $S$ supplying the last unit that fixes
the exact integer. **Local RH is the statement that the real count equals the total — a condition on $S$.**
The sign-count is robust exactly where the edge gap is fragile (at $N=36,44$ the integer $R_N$ is clean
though the gap collapses), and it lands in the **Levinson–Conrey** family — counting real zeros of a real
model by mollified moments, where on-the-line counting has produced theorems (positive proportion $>41\%$
for $\zeta$). $[C/R$, joint$]$ This is no free lunch — count-match *is* local RH — but it places the entire
residual difficulty in the explicit prime object $S$, which §B.9 shows is exactly where it must sit.

Concretely, the invariant is the **buoy defect** $B_N(c)=N_{\mathrm{total}}(T)-R_{\mathrm{line}}(T)$ at the
wall $T=c\,S_N$ — the total zero-count below the wall (argument principle) minus the line-zero count: $B_N=0$
is "no wrong-side crossing," $B_N\neq0$ a miscount. Across the candidate walls $c\in[0.58,0.585]$, $B_N=0$
holds for **all $N=8,\dots,70$** — no wrong-side event, even at the sharpest timing near-misses (gap
$\sim10^{-3}$) — a finite computational confirmation, not a proof $[C$, Balashov$]$.

*[v0.9 — the operator program, cited not re-proved.]* Since v0.8 the finite-level operator material has
become its own campaign, carried at higher grade in the **operator companion papers** (Paper A, the
finite-section/model-lattice engine, assembled 2026-07-25; Paper B, the $H=D+V$ companion, architecture
2026-07-23). Paper B carries the full non-circular $H=D+V$ construction for $\chi_8$ — $D$ from conductor
and gamma factor alone, $V$ from the Euler product alone, zeros as *output* — with its controls:
forward reconstruction to $0.0165$ mean error ($3.9\times$ over geometry, flat in height over the
certified range); the T3 twin control ($V$ object-identifying — a crossed $V$ is *worse* than no $V$ —
while $D_{\text{twin}}\equiv D$ exactly); Frobenius resonance read back from the zeros ($0.99987$, the
1% level); the finite-range positivity theorem T1 at [P-cond] on the certified inputs; and the transport
trichotomy (atom-map identification PROVEN; pencil identification interval-certified at the production
section, $\hat\kappa=5.5956$; polynomial route refuted). This paper keeps only what is Part II's own —
the two-roads framing, the margin comparison of §B.8, and the no-go — and cites the companion for the
construction and its proofs. $[C/P$, cited$]$

---

## §B.8 — The Two Roads Meet at One Margin

The operator road (§B.3–B.6) and the analytic road (§B.7) are distinct — different objects (a de Branges
system on $\chi_8$ versus the Theta–Hurwitz truncation on $\Xi$), different finite parameters, different
margins — yet both reduce to the same kind of statement: **a finite-level positivity must survive a limit.**

| | operator road (Stenberg) | analytic road (Balashov) |
|---|---|---|
| object | Aion / de Branges system | Theta–Hurwitz $\tilde M_N$ |
| finite parameter | matrix order $m$ | level $N$ |
| margin | $\det H_m$ (Gaussian $\sim10^{-1.6m^2}$) | sign-count surplus / edge structure |
| tracking theorem | $t_j^{(N)}\to\gamma_j$ analogue | M74 (proved) |
| condition | $\det H_m>0$ as $m\to\infty$ | real count $=$ total count, $\forall N$ |
| equals | $\mathcal A$ self-adjoint | the Re-Bound |

**The bridge is not an equivalence.** It is tempting to identify the two margins: if $m\sim\log N$, the
Gaussian decay $\det_m\sim10^{-1.6m^2}$ would become the power-law edge decay. *We tested this and it is
false.* $\det_m\to0$ is generic for any Hankel matrix (a Gram determinant of a collapsing basis), while the
edge gap is a distance; the ratio drifts $\sim6$ orders over $N=10..50$, with at best a transient
$\sqrt{\log N}$ scaling. The two margins are **independent sufficient conditions for the same conclusion**,
not two encodings of one quantity. $[C$, joint$]$

There is, however, one place the roads genuinely **combine** rather than merely agree — in range. The analytic
road's surviving-limit condition is, in frequency form, an Ingham-type phase-frame lower bound on the zero
system, $\big\|\sum_i c_i\,e^{iq\gamma_i\tau}\big\|^2\ge C\|c\|^2$. The proved diagonality $W=c\cdot I$ of
§B.6.5 — equivalently the restricted-range GUE pair correlation $F(\alpha)=|\alpha|$ for $|\alpha|<1$ (§B.10.2),
which *is* the averaged off-diagonal phase Gram — supplies exactly that frame bound on $|\alpha|<1$. So on the
restricted range the analytic margin needs only its detector definition: the analytic input is supplied
unconditionally by the operator road's diagonality. (The link is the pair correlation, not the flow-stiffness
$\mathcal S=\sum 1/\text{gap}^2$, which bounds neighbour spacing, not the frame.) Past the range
($|\alpha|>1$) the frame bound becomes the off-diagonal prime-pair cancellation — the shared wall of §B.9. The
combination holds in range only; the wall is not crossed. $[C$, joint$]$

So the picture is not one road in two languages but **two genuinely different roads arriving at one wall.**
Why the wall is the same — and why neither margin can cross it — is §B.9.

---

## §B.9 — The No-Go, and the Primes in the Zeros

Both roads stall at the same place, for the same reason. This section states the boundary precisely and
exhibits it.

### B.9.1 The no-go, quantified

The **density** of the zeros is geometric and free: the Riemann–von Mangoldt term
$\bar N(T)=\tfrac{T}{2\pi}\big(\log\tfrac{T}{2\pi}-1\big)+\tfrac78$ pins the count to $\pm O(1)$ at every
height with **no prime input** ($|\bar N-(n-1)|<1$ verified from $\gamma_{11}$ to $\gamma_{1200}$). The
**positions** are not: reconstructing the zeros from the prime/main-sum, the height reached grows with the
number of primes used, and to reach *any* height needs $\pi(L)\to\infty$ primes — rigorously, the
Riemann–Siegel main sum of length $\nu=\sqrt{T/2\pi}$. $[C/T$, joint$]$

> **The no-go.** The envelope — density, scale, spacing — is reachable from the finite geometry; the
> *positions* of the zeros require the full prime alphabet $\{\log p\}$, which is $\mathbb Q$-linearly
> independent (Baker) and of unbounded rank. No finite-rank object — neither a Hankel margin nor a skeleton
> edge — can encode it.

This is one fact in four guises: it is *why* the edge-gap floor fails (the wall sweeps an incommensurate
set), *why* the $m\sim\log N$ bridge is not an equivalence (finite rank $\neq$ infinite rank), *why* the
sign-count's difficulty sits in the prime term $S$, and *why* the K-modulus positivity (§B.6) collapses to a
knife-edge rather than to a provable floor.

### B.9.2 The primes fall out of the zeros

The no-go has a literal demonstration. Form the spectrum of the zeros $F(x)=\sum_n\cos(x\gamma_n)$ (mild
taper) and scan $x$: **every resonance sits at $x=\log p^k$, and nowhere else.** From the first $1200$
zeros, to $\sim 4$ decimals:

$$
\begin{array}{c|c|c}
x_{\text{peak}} & \log p^k & |\text{err}|\\\hline
0.6932 & \log 2 & 1\times10^{-4}\\
1.0986 & \log 3 & 0\\
1.6094 & \log 5 & 0\\
1.9459 & \log 7 & 0\\
2.3978 & \log 11 & 1\times10^{-4}\\
1.3862 & \log 2^2 & 1\times10^{-4}\ (\text{weaker},\ \propto\Lambda(n)/\sqrt n)\\
\text{6, 10, 12, 14, 15} & \text{composite} & \text{flat — no peak}
\end{array}
$$

This is the dual of the explicit formula (Guinand–Weil) made visible, and it shows three things at once:
the fine structure of *where the zeros sit*, Fourier-transformed, **is** the prime spectrum (weights
$\propto\Lambda(n)/\sqrt n$); the peaks have **no common period** (the logs are $\mathbb Q$-independent), so
the zeros are an incommensurate point process, **never a lattice** at any scale; and only the *prime*
alphabet appears (composites vanish, $\Lambda=0$). $[C$, this work$]$

The duality now stands demonstrated **on the genome itself, in both directions.** Zeros $\to$ primes is the
table above. Primes $\to$ zeros: from the exact genome $a_p=\chi_8(\mathrm{Frob}_p)$ computed to $x=10^{11}$
(fast Frobenius, integer arithmetic — the same sweep as §A.5.4), the weighted prime sum $\psi_\chi$ in
$u=\log x$ resolves the genome's zeros as sinusoids. A structured fit with amplitudes locked to
$-1/(\tfrac14+i\gamma)$ recovers $\gamma_1,\dots,\gamma_8$ to $\pm0.03$–$0.07$ and confirms five on the line
($|\beta|\le0.015$) at $x=2\times10^7$; at $10^{11}$ the resolution suffices to *predict* $\gamma_9$–$\gamma_{11}$
— predictions subsequently **certified** by an independent $L$-side ball certificate (§A.9.1, §C.8) that takes no input from the prime-side prediction (its Dirichlet coefficients are of course prime-built — the point is the two roads are independent). The primes of the
genome know its zeros, and the zeros know its primes, to the exact resolution the no-go prescribes: prime
range buys zero height, and nothing else does. (The predictions themselves are graded corroborative only —
the sinusoid form assumes what it probes; certification is always $L$-side.) $[C/M$, this work$]$

The line is, and the no-go says must be, the primes'. Both roads reach the envelope; the positions — the
content of RH — are prime data the finite geometry provably cannot manufacture. The one direction *through*
the wall is to carry the prime information *in*: a positive-weight motive for $\chi_8$ (§B.5.5), which is RH
itself.

---

## §B.10 — The Synthesis: RH as a Finite Positivity Surviving an Infinite Flow

This section assembles Part II. The finite cell, the infinite flow, the necessary gate, the forced wall,
and the purity kernel combine into a single statement of $\mathrm{RH}(\chi_8)$; the four reformulations
that have appeared — operator, purity, positivity, abelian — are shown to be one; and that statement is
placed alongside the second road (§B.7) and the no-go that bounds them both (§B.9).

### B.10.1 The assembly

Collecting what is established:

- the cell is finite and **exactly positive** (§B.2.3, the AHK sum-of-squares);
- it is unwound into an infinite, never-closing flow — a de Branges canonical system whose spectrum is
  the zeros (§B.3);
- the **Euler product is necessary** to hold that spectrum to the line (§B.4, Davenport–Heilbronn);
- the wall is **forced abelian**: $\mathrm{RH}(\chi_8)\iff\mathrm{GRH}(\psi)$ for an explicit cubic Hecke
  $\psi$ (§B.5);
- the **purity** $|K_L|=1\iff\mathrm{Re}=\tfrac12$ expresses the flow's positivity, verified in range on
  the genome (§B.6);
- a **second, complementary road** (§B.7): Balashov's finite-level $\tilde M_N$, with M74 proved (skeleton
  zeros $\to$ Riemann zeros) and the Re-Bound carried in robust sign-count form — both roads reducing to one
  margin (§B.8);
- the **no-go** (§B.9) that bounds them both: the density is geometric and free, but the positions are
  prime-locked (the primes fall out of the zeros), so no finite-rank structure closes the survival by itself.

The first five entries are proved or forced; the last two place the open survival between a complementary
second road and a precise boundary.

Since the first version of this assembly, two parts have been added on top of it, and belong in its
accounting. **Part III** certifies the boundary's geography at derivative level: the envelope law across the
family (nothing fitted), the five-slot error budget, and $Q>0$ on $[0,3.2]$ for the genome at interval grade,
with — as of 2026-07-19 — the **certified spectrum**: 152 ball-certified zero brackets on $[0,27.92]$ and
certified Turing counts $N^+(5.969)=21$ / $N^+(6.55)=24$ (§C.8.1b) — the two-method handshake of §B.9.2 closed **three times over** ($\gamma_9$–$\gamma_{11}$:
primes predict, balls certify), once with no seed at all ($\gamma_{12}$, the density law alone), and extended by
the frozen pre-registered batch $\gamma_{13}$–$\gamma_{17}$ (3 HIT + 1 NEAR + bonus). **Part IV**
gives the finite cell its dynamics — one door, one canonical key, a proven equipartition, an assembly rule —
and proves its own ceiling: no finite label spans the wall. Neither part moves the wall; both sharpen exactly
where and what it is. The remaining content is a single statement:

> **$\mathrm{RH}(\chi_8)$:** the finite cell's exact positivity survives, through the necessary Euler
> binding, as the positivity of the infinite flow.

### B.10.2 The four faces are one

The statement has appeared in four guises. These are not independent results but **one statement recast**,
joined by a cycle of equivalences — three of them classical RH-criteria, the fourth the explicit reduction
of §B.5:

$$
\underbrace{\mathcal A\ \text{self-adjoint}}_{\text{operator (Aion)}}
\ \Longleftrightarrow\
\underbrace{|K_L(s)|=1\iff\mathrm{Re}(s)=\tfrac12}_{\text{purity (K-modulus)}}
\ \Longleftrightarrow\
\underbrace{\lambda_n\ge 0\ \forall n}_{\text{positivity (Weil/Li)}}
\ \Longleftrightarrow\
\underbrace{\mathrm{GRH}(\psi)}_{\text{abelian (Hecke)}} .
$$

Reading the cycle: the Aion's self-adjointness and the K-modulus are the operator and the structure
function of the *same* canonical system ($\mathcal A$ self-adjoint $\iff H(t)\succeq 0\iff E$
Hermite–Biehler $\iff|K_L|=1$ on the line, §B.6.1–2); de Branges positivity is equivalent to the Weil/Li
positivity $\lambda_n=\sum_\rho\big[1-(1-1/\rho)^n\big]\ge 0$ (Li, 1997); and
$\mathrm{RH}(\chi_8)\iff\mathrm{GRH}(\psi)$ is the explicit Hecke realization (§B.5.3). Each face is the
others in different language; none is weaker, because each *is* $\mathrm{RH}(\chi_8)$.

The contribution is not new equivalences — Hilbert–Pólya/de Branges, Li, and abelian reduction are
classical — but that **all four are exhibited for one object, each grounded**: the operator on the finite
cell (§B.3), the kernel as its structure function (§B.6.1), the positivity computed on the genome's own
zeros (§B.6.4), the abelian character $\psi$ constructed explicitly (§B.5.3). The wall is the same from
every side.

These are all specializations of one classical statement — the **Weil explicit-formula positivity**

$$
W(f)=\mathrm{ARCH}(f)-\mathrm{PRIME}(f)\ \ge\ 0\quad\text{for all admissible }f,\qquad
\mathrm{PRIME}(f)=\sum_n\frac{\Lambda(n)}{\sqrt n}\,K_f(\log n),
$$

(Weil 1952; Bombieri), in which the prime side is given **by the primes alone**, not the zeros. Li's
$\lambda_n\ge0$ is $W$ on a particular basis; $\mathrm{GRH}(\psi)$ is the same wall named arithmetically. And
**Balashov's analytic road (§B.7) — distinct from the operator construction, using none of its machinery —
reduces by the same explicit formula to exactly this $W\ge0$**: his "no wrong-side crossing" ($B_N=0$, §B.7.3) is the in-range face of
$\mathrm{ARCH}\succeq\mathrm{PRIME}$. So the **two roads converge on one classical wall** — the
de Branges/operator road and the Theta–Hurwitz/sign-count road both land on $W=\mathrm{ARCH}-\mathrm{PRIME}\ge0$,
gated identically by the no-go (§B.9). The ceiling is sharp and we state it plainly: $W\ge0$ *from the primes*
is not a step toward RH — it **is** RH, the principal classical equivalent, and the no-go says no finite or
diagonal datum supplies it. $[T$: Weil/Bombieri; the two-road convergence $C$, joint$]$

A fifth dialect names *why* the edge is marginal. For $\zeta$ the de Bruijn–Newman constant
$\Lambda_{\mathrm{dBN}}$ obeys $\mathrm{RH}\iff\Lambda_{\mathrm{dBN}}\le 0$, while Rodgers–Tao (2020) proved
the matching lower bound $\Lambda_{\mathrm{dBN}}\ge 0$; the two together force $\Lambda_{\mathrm{dBN}}=0$ —
the Hypothesis is not that the heat-flow lands *somewhere* safe but that it is **critically damped**, sitting
exactly on the boundary, neither over- nor under-shot. For the genome the lower bound is not a transfer but a
theorem in its own right: $\chi_8$ is entire — the Rankin–Selberg factorization
$L(\chi_3\times\bar\chi_3)=\zeta\cdot L(\chi_8)$ of §A.5 places it in the **extended Selberg class**
$\mathcal S^\sharp$ — and **Dobner (2020) proved $\Lambda_F\ge0$ for every $F\in\mathcal S^\sharp$**,
arithmetic-blind and with no use of the Euler product, so $\Lambda(\chi_8)\ge0$ holds outright. The genome
therefore sits at exact **parity with $\zeta$**: both have the lower bound as a theorem, and for both the
remaining half $\Lambda\le0$ *is* the Hypothesis. Read on the genome's flow, this is the same marginal
rigidity as the four faces: the Hankel knife-edge of §B.6.4 and the never-closing balance of §B.3 are the
dynamical face of $\mathcal A$ self-adjoint $=|K_L|=1=\lambda_n\ge0=\mathrm{GRH}(\psi)$. $[T$ for $\zeta$
(Rodgers–Tao) and for $\chi_8$ (Dobner, $\mathcal S^\sharp$); the $\Lambda\le0$ half $=$ RH, open for both$]$.

The spectral statistics corroborate the chaos this implies. The computable weight-$6$ avatar of $\chi_8$ — a
classical degree-$2$ level-$7$ newform with $a_2=-10$, sharing the genome's bad prime — yields $369$ zeros
to height $300$ whose unfolded spacings fit the GUE law (Kolmogorov–Smirnov $0.053$, not rejected; Poisson
rejected at $0.334$; level repulsion $P(s<0.3)=0.016$); the spectrum is quantum-chaotic, consistent with
$\mathrm{Re}=\tfrac12$ as the Berry–Keating Lyapunov-$\tfrac12$ line, and by universality the weight-$0$
genome would match. $[C]$

Beyond the avatar numerics, the restricted-range statistics are a **theorem**. With
$\chi_8=\mathrm{AI}_{K_H/\mathbb Q}(\psi)$ cuspidal on $\mathrm{GL}(8)/\mathbb Q$ (§B.5.3) and the
Rankin–Selberg variance $\langle a_p^2\rangle=1$ — the diagonality of §B.6.5, confirmed on the genome to
$\langle a_p^2\rangle=1.00006$ over $1.27\times10^6$ primes — as its exact hypothesis, Rudnick–Sarnak (1996)
give the Montgomery pair-correlation form factor $F(\alpha)=|\alpha|$ for $|\alpha|<1$: GUE level repulsion in
the restricted range, **unconditionally**. The full range $|\alpha|>1$ is the off-diagonal prime-pair part —
the wall of §B.9 again, now in spectral-statistics form. $[T$, restricted range; $C$ for the variance$]$

### B.10.3 The two cones as the Li bowtie

The light and dark cones of §B.2.2 are the two halves of the positivity. The Li sum pairs each zero $\rho$
— *forward*, the build: the octonion, a division algebra, no annihilation — with its reflection $1-\rho$
— *inverse*, the annihilation: the sedenion, the zero-divisor channel. On the critical line $\rho$ and
$1-\rho$ are conjugate, the paired contribution to $\lambda_n$ is non-negative — $2(1-\cos n\theta_\rho)\ge
0$, the per-pair positivity, solved precisely because $|1-1/\rho|=1$ there. The doubling
$\mathbb O\to\mathbb O\oplus\mathbb O$ that carries each build into its paired annihilation is the Born
relation $\chi_3\otimes\bar\chi_3=\mathbf 1\oplus\chi_8$ (§B.5.2): the genome is the amplitude paired with
its reverse, reading its floor value $-1$ exactly where the trit cancels (the class $3A$, one prime in
three). $[C$ facts; the cone reading $R]$

In this image the Riemann Hypothesis is that **every forward build meets its inverse annihilation on the
line** — no off-line pair — across the whole infinite flow.

### The statement, complete

> $\mathrm{RH}(\chi_8)$ is that the exact, finite, sum-of-squares positivity of the cell (§B.2), unwound by
> the arrow into the de Branges flow (§B.3), bound by the necessary Euler product (§B.4), forced to the
> abelian Hecke wall $\mathrm{GRH}(\psi)$ (§B.5), and expressed as the purity $|K_L|=1$ on the line (§B.6),
> **survives undimmed across the infinite, never-closing run.**

---

---

## §B.11 — Honest Ledger

Part II has separated what is established from what is open. The ledger collects it, with the provenance
of each verification. (Parts III and IV carry their own ledgers — §C.9, §D.10 — and the paper-wide Claims
Register, Appendix F, is the master table; this section remains Part II's own accounting.)

**Proved or forced.**

- *The finite cell* $[C]$: the genome alphabet $\{8,0,-1,1\}$ and its rigidity; the two cones — the
  octonion Fano $F_7$ and the sedenion $\mathrm{PG}(3,2)$ with fifteen Fano subplanes and $84/42$
  zero-divisors; the void operator spectrum $\{18,\,2\pm2\sqrt2,\,-4\pm2\sqrt2\}$; the AHK sum-of-squares
  positivity.
- *The unwinding* $[C/T]$: the holonomy $z_3\sigma z_3^{-1}=\sigma^r$ ($r\in\{2,4\}$, order-$3$ multiplier mod $7$); the coprimality $3\perp 7$; the
  Cayley transform.
- *The Euler product necessary* $[T+C]$: Davenport–Heilbronn — self-dual functional equation, no Euler
  product, off-line zero at $0.8085+85.699\,i$.
- *The wall forced* $[C\to T]$: the CM root by the cyclotomic $\mathbb Q(\zeta_7)$-torus (Grossencharacter
  $L(\mathrm{Jac}\,C)=L(E)L(E\otimes\chi)L(E\otimes\chi^2)=L(\eta)$, $\mathbb Q(\sqrt{-7})\subset\mathbb Q(\zeta_7)$);
  the explicit cubic Hecke realization $\chi_8=L(\psi)$ over $K_H=$`8.0.37822859361.1` ($\psi$ one of two
  cubic ray-class characters of conductor norm $441$; Path-A/Path-B $a_p$ match on $166$ primes); equivalently
  the automorphic induction $\mathrm{AI}_{K_H/\mathbb Q}(\psi)$ on $\mathrm{GL}(8)/\mathbb Q$; Sato–Tate the
  torus; the character genuinely non-abelian ($a_2\neq a_{23}$); no Deligne lever and no reciprocity lever;
  hence $\mathrm{RH}(\chi_8)\iff\mathrm{GRH}(\psi)$.
- *The moments and diagonality* $[C\to T]$: $\langle a_p^k\rangle=(8^k+56(-1)^k+48)/168=0,1,3,25,195,1561$;
  the Rankin–Selberg square $\chi_8\otimes\chi_8=\mathbf 1\oplus\chi_3\oplus\bar\chi_3\oplus2\chi_6\oplus3\chi_7\oplus3\chi_8$
  has the trivial with multiplicity one, so the prime-pairing is $W=c\cdot I$ ($c=1$) by Aramata–Brauer —
  the off-diagonal conspiracy is forbidden, not merely unobserved.
- *RH in range* $[C]$: the argument principle pins $N(3)=8$, all on the line; the family follows with
  positive Weil/Li coefficients.
- *The K-modulus and positivity* $[C]$: $K_L$ as the Aion's structure function; the void-pressure positivity
  recomputed on $\chi_8$'s own cubic zeros (Hankel positive through $m=5$); and the Weil/Li coefficients read
  from the **prime side** ($-L'/L$ at $s=1$, no zeros) $\lambda_1\dots\lambda_{10}=4.3\dots155.4>0$ — genuine
  arithmetic positivity, not the spectral tautology.
- *The genome distribution* $[C]$: the value law $\{8:\tfrac1{168},0:\tfrac{63}{168},-1:\tfrac13,1:\tfrac{48}{168}\}$,
  the Born floor $a_p\ge-1$ (annihilation on the trit class, one prime in three), verified to $61$-digit primes.
- *The second road* $[T/C$, Balashov$]$: the finite-level $\tilde M_N$ and its closed form; **Theorem M74**
  (skeleton zeros $\to$ Riemann zeros, by Rouché, conditional on simplicity); the Re-Bound carried in
  sign-count / buoy form $B_N=0$ (edge-gap floor retracted — its failure is the GUE fingerprint of $3\perp7$;
  $B_N=0$ verified for all $N\le70$), with the Levinson–Conrey link.
- *The two roads, one classical wall* $[T+C$, joint$]$: both the operator/de Branges road and the
  $\tilde M_N$/sign-count road reduce to the **Weil positivity** $W=\mathrm{ARCH}-\mathrm{PRIME}\ge0$ (Weil
  1952; Bombieri) $=\mathrm{GRH}(\psi)=$ the off-diagonal prime-pair; $W\ge0$ from the primes *is* RH, gated
  by the no-go.
- *The primes in the zeros* $[C]$: $F(x)=\sum_n\cos(x\gamma_n)$ resonates at $x=\log p^k$ to $\sim10^{-4}$
  (first $1200$ zeros) and nowhere else; composites flat — the experimental face of the no-go.
- *GUE spectral statistics* $[C]$: the computable weight-$6$ avatar of $\chi_8$ (a degree-$2$ level-$7$
  newform, $a_2=-10$) gives $369$ zeros to height $300$ with unfolded spacings KS-to-GUE $=0.053$ (not
  rejected), KS-to-Poisson $=0.334$ (rejected), level repulsion $P(s<0.3)=0.016$ — the family spectrum is
  quantum-chaotic (GUE), consistent with $\mathrm{Re}=\tfrac12$ as the Lyapunov-$\tfrac12$ line
  (Berry–Keating). By universality the weight-$0$ genome would match.
- *External validation* $[C]$: every analytic invariant of $\chi_8$ — conductor $3^{10}7^{10}$, field
  discriminant $3^6 7^8$, orthogonal type, character, root number $+1$ — matches the LMFDB Artin
  representation `8.16679880978201.21t14.b.a` (§A.4.4). The object is real, classical, and catalogued.

**Standard theory invoked $[T]$.** De Branges canonical systems and Hermite–Biehler; Li's criterion
(1997); CM propagation (Deligne; Shimura–Taniyama); Aramata–Brauer (holomorphy of $\zeta_K/\zeta$); the
de Bruijn–Newman constant with $\mathrm{RH}\iff\Lambda\le0$ and Rodgers–Tao's $\Lambda\ge0$ (2020); Baker's
theorem; the Cayley transform; Davenport–Heilbronn (1936).

**Interpretive $[R]$.** The identifications *light cone $\leftrightarrow$ CM torus*, *dark cone
$\leftrightarrow$ GUE*; build/annihilation as forward/inverse; the flow as time. These are readings
consistent with the computed facts, not theorems.

**Formalized or upgraded since v0.8 [dated flips, 2026-07-13 → 07-25].**

- *The Aion equivalence is now a lemma* [2026-07-14]: the Aion Reformulation Lemma R-011a states and
  proves the six-form equivalence conditionally on the displayed hypothesis (H) (a representing matrix
  de Branges canonical system exists); see the §B.3 note. The wall itself — the positivity, and the
  deficiency-$(0,0)$ / essential-self-adjointness question for the constructed operator [R-209] —
  is **unchanged and OPEN**.
- *The operator program exists at higher grade* [2026-07-23/25]: Papers A and B of the operator trilogy
  carry the $H=D+V$ construction, its controls, the finite-range positivity, and the transport
  trichotomy (§B.7 note); Part II cites them and keeps its framing role.
- *The in-range verification base is certified* [2026-07-19]: the 152-bracket certified spectrum and
  the certified Turing counts (§C.8.1b) supersede the numerical-anchored zero inputs quoted in v0.8;
  and the finite-range self-adjointness certificate on the certified inputs (the G-C1 chain, delivered
  2026-07-24) closes the "numerical-anchored completeness input" caveat of the operator lane.
- *A zero-free analytic layer* [2026-07-25]: the unconditional pointwise $|S(t)|$ bound of §C.8.3
  (one flagged proof-structure condition on the lower side, IB confirmation pending).

**Open $[\mathrm{OPEN}]$.** $\mathrm{GRH}(\psi)=\mathrm{RH}(\chi_8)=$ the survival of the cell's positivity
across the infinite flow. The four faces of §B.10 are this one statement, and both roads (§B.8) reduce to it.

**The no-go, stated precisely $[$joint$]$.** A finite-rank object cannot reproduce the prime alphabet
$\{\log p\}$ ($\mathbb Q$-independent, Baker). Part II does not contradict this: the Aion is not a finite
operator but a finite cell carried by an infinite flow, and the prime data lies in the flow's *variation*
(§B.3.4). §B.9 makes the boundary quantitative — the density is geometric and free to $\pm O(1)$ at all
heights, the positions cost $\pi(\sqrt{T/2\pi})\to\infty$ primes, and the primes fall directly out of the
zero positions (the Fourier-duality). The no-go bounds what *either* road can do — neither margin closes the
survival by itself — and is consistent with the finite cell's positivity being **necessary but not
sufficient**. The one route through it is the positive-weight motive of §B.5.5.

**Provenance.** *First-party (this work):* the cone counts and zero-divisors, the genome statistics, the
void-pressure Hankel on $\chi_8$'s zeros, the Fourier-duality and the no-go cost curve. *Balashov:* the
$\tilde M_N$ operator, Theorem M74, the edge-gap data (the sign-count reformulation and the bridge/floor
analysis are joint). *Reproduced on the 32 GB machine, cited as such:* the CM check, the Hecke realization,
the Sato–Tate test, the argument-principle pinning. *Classical, cited:* Davenport–Heilbronn, Li, de Branges,
Baker.

---

## §B.12 — Conclusion

Part II has anatomized the Riemann Hypothesis of one explicit L-function. The generating machine is
**finite** — a gate of six classes, an octonion light cone and a sedenion dark cone of fifteen Fano
matroids, a void operator with an exact sum-of-squares positivity. That finite cell is **unwound** by the
time-reversal arrow into an infinite, never-closing **flow** — a de Branges canonical system — and the
flow never closes because the trit and the Singer cycle are coprime and refuse to resolve. The **Euler
product** is the necessary binding that holds the flow's spectrum to the line, proved by a function that
lacks it and fails. The wall that binding leaves is **forced** to be classical and abelian: GRH for one
explicit cubic Hecke character $\psi$, with no non-CM lever to reach it. And the single open statement —
that the cell's exact finite positivity survives the infinite flow — appears in **four equivalent,
grounded forms**: the Aion self-adjoint, the K-modulus pure, the Weil/Li coefficients positive,
$\mathrm{GRH}(\psi)$.

This operator road does not stand alone. A **second, complementary road** — Balashov's finite-level skeleton
operator $\tilde M_N$, with the skeleton zeros *proved* to converge to the true zeros (M74) and the Re-Bound
carried in robust sign-count form — reaches the same margin from the classical side. And a precise **no-go**
marks the boundary the two roads share: the geometry reaches the envelope — density, scale, spacing — for
free at every height, but the zero *positions* are the primes', and they fall, literally, out of the zeros
(the Fourier-duality, every resonance at a prime log). The only route through that boundary is to carry the
prime information in — a positive-weight motive for $\chi_8$ — which is RH itself.

We have not proved the Riemann Hypothesis, and we have marked at each step the line between what is
established and what is not. What Part II offers is the sharpest localization we can give: for this object,
RH is neither vague nor distributed — it is the **survival of an exact finite positivity across an
infinite, never-closing run**, and it is, equivalently, GRH for a single cubic Hecke character. The machine
is finite and known; the flow is necessary and forced; the balance is exact at every instant. The
Hypothesis is the one thing the structure does not settle — whether the balance, exact forever in the
finite, tips once across the infinite.

*Finite-flowed-infinitely: the line is whether the flow holds.*

---



---

# Part III — The Certified Envelope

---


## §C.1 — Introduction: from measured to certified

Part I mapped the family and its envelope; Part II dissected the wall. This part does
something different in kind: it takes the envelope of Part I down to **derivative
level** and replaces measurement with **certificate**. Every central statement below
is either a theorem (pen-and-paper, machine-checked arithmetic at most), a certified
computation (interval arithmetic end to end, hashed artifact, independent audit), or a
measurement with a priced error budget — and each carries its grade openly, per the
Claims Register (Appendix F). The part's arc:

1. the Laguerre–Turán quantity $Q=\Xi'^2-\Xi\Xi''$ is ported off $\zeta$ and measured
   across the family (§C.2);
2. its envelope obeys one law — the Envelope Comb — proved together with the
   side-lemma stack that makes grid data speak for continuous intervals (§C.3);
3. the law is tested on 45 gaps across the family, degrees 1 through 8, with nothing
   fitted (§C.4);
4. what the law does *not* explain is priced, term by term, in a five-slot error
   ledger, leaving a single named open slot (§C.5);
5. the certificates transfer up the tensor tower (§C.6);
6. and the flagship: $Q>0$ on $[0,3.2]$ for the genome $\chi_8$ at interval grade —
   the first theorem-grade Laguerre certificate for a degree-8 Artin $L$-function
   (§C.7), with its extensions (§C.8): the **certified spectrum** — 152 ball-certified
   zero brackets on $[0,27.92]$ with certified Turing counts $N^+(5.969)=21$ /
   $N^+(6.55)=24$ (§C.8.1b) — grown from the twenty-one-zero set, among them the
   program's first pure-prediction discovery ($\gamma_{12}$) and a frozen
   pre-registered batch scored 3 HIT + 1 NEAR ($\gamma_{13}$–$\gamma_{16}$); the
   finite K-modulus ledger to $m=17$ (§C.8.2); and the unconditional pointwise
   $|S(t)|$ bound, the zero-free analytic layer (§C.8.3).

The thesis of the part, in one line: **the envelope is geometric and lawful; the
line is arithmetic — and at derivative level the boundary between them is now an
equation, with a certificate on each side.**

---

## §C.2 — The Certificate on the Family

### C.2.1 The quantity

For a completed $L$-function $\Lambda$ with $\Xi(t)=\Lambda(\tfrac12+it)$ real, the
Laguerre inequality
$$Q(t)\;=\;\Xi'(t)^2-\Xi(t)\,\Xi''(t)\;>\;0$$
holds wherever the zeros of $\Xi$ are real and simple; a failure of $Q>0$ flags a
zero off the line or a degeneracy. $Q$ is thus a *local, derivative-level detector*
— the same quantity for every member of the family, from $\zeta$ (degree 1) to
$\chi_8$ (degree 8, conductor $21^{10}$).

### C.2.2 What was measured

[R-307, R-008, R-009] $Q$ was computed on dense grids for six objects over their
in-range zero fields: $\zeta$, the $\chi_3$-pair, $\chi_6$, $\chi_7$, the genome
$\chi_8$, and the CM twin $\chi_8\otimes\chi_{-7}$ — whose conductor is **preserved**
at $21^{10}$ under the twist (the Mumford–Tate signature of §A.6, verified), so that
genome and twin share one shell and differ only arithmetically. This is, to our
knowledge, the **first Turán/Laguerre dataset for degree-8 Artin $L$-functions**.
Outputs per object: margin minima per gap, the which-wall identification (which
neighbouring zero pair binds each minimum), and the passport data ($N$, degree,
$\Gamma$-shape) that the law of §C.3 consumes.

| object | degree | gaps | ratio band (§C.4) |
|---|---|---|---|
| $\zeta$ | 1 | 9 | $[0.9976,\,1.0518]$ |
| $\chi_3$-pair | 3 | 8 | $[0.9515,\,1.0938]$ |
| $\chi_6$ | 6 | 5 | $[0.9998,\,1.1216]$ |
| $\chi_7$ | 7 | 6 | $[0.9971,\,1.0389]$ |
| $\chi_8$ | 8 | 7 | $[1.0126,\,1.0702]$ |
| $\chi_8\otimes\chi_{-7}$ | 8 | 10 | $[0.9426,\,1.0619]$ |

*(bands at effective grid resolution — refined rows superseding coarse tight-gap
rows; full table in §C.4; source: `family_certificate.csv` in the hashed package.)*

### C.2.3 Honest caveats, stated up front

- The **twin comparison** uses gap-minimum to gap-minimum; the corrected twin factor
  is $\approx 1.8\times$ [M]. Earlier which-wall mis-pairings are documented in the
  audit trail and corrected here.
- Grid data alone certifies nothing about the continuum between grid points; the
  passage from grid to interval is exactly what §C.3's lemma stack prices, and what
  §C.7 closes for $\chi_8$.
- Accidental near-degeneracies inflate $Q$'s dips without arithmetic meaning; they
  are flagged per-row in the artifact. [M]

---

## §C.3 — The Envelope Comb Law and Its Side-Lemma Stack

### C.3.1 The law

> **Envelope Comb Law** [IB; R-301; registry: ENVELOPE-COMB, CLOSED]. For a gap of
> width $g$ between consecutive zeros, with local zero density $\rho$ evaluated at
> the gap midpoint from the passport (never fitted),
> $$M_{\text{pred}}\;=\;\frac{8}{g^2}\;+\;(\pi^2-8)\,\rho(\text{mid})^2 .$$
> The first term is the two-wall comb floor; the second is the collective field of
> all other zeros, with the **universal constant $\pi^2-8$** [R-302].

The constant is not fitted and not family-dependent: it is forced by the comb
midpoint computation [IB side lemma, R-302]. $\rho$ comes from the passport density
law of §A.7 — the same law verified across the family to $1.07\pm0.08$ — so the
prediction chain contains **no free parameter anywhere**.

### C.3.2 The stack that makes grids speak for intervals

Four further lemmas, each registry-closed [IB], turn the law into an instrument:

| Lemma | Content | Row |
|---|---|---|
| TAIL-COMPOSITION | $B_{\sup}(I)=2S_1\delta c_1+\delta c_1^2+S_0\delta c_2+S_2\delta c_0+\delta c_0\delta c_2$: how truncation tails compose into a $Q$-certificate | [R-303] |
| Grid-to-interval | derivative-corrected grid bounds certify the continuum | [R-304] |
| Tight-gap sampling inflation | a sampled minimum overestimates the true gap minimum by at most $\frac{1+(h/g)^2}{(1-(h/g)^2)^2}$ | [R-305] |
| Comb-perturbation | conditional; perturbation constant $C(\theta)\le 10$ | [R-306, CONDITIONAL] |

[TODO: IB's registry names/numbers per lemma, from his markup pass.]

The sampling-inflation lemma deserves emphasis, because it *predicted its own
vindication*: the two apparent violations of the law in the first scans were exactly
the two tightest gaps, where the lemma prices the largest inflation — and both
collapsed on refined scan (§C.4). A law whose failures are pre-priced by its own
error theory is behaving like physics. [M→T]

---

## §C.4 — The Representation-Family Law: 45 Gaps, One Formula

[R-307; artifact ECL_FAMILY_THEOREM_v1_8a93b634854f.zip; status: delivered,
Step-3B audited; registry closure ECL-FAMILY-1 **pending** — TODO: IB's line.]

The test: for every scanned gap of every family member, form the ratio
$M_{\text{obs}}/M_{\text{pred}}$. One formula, six $L$-functions, degrees 1 through
8, conductors 1 through $21^{10}$, zero densities spanning a factor of $\sim 20$ —
and passports only, nothing fitted:

> **Result** [M]. All 45 gap ratios lie in $[0.9426,\,1.1216]$ at effective grid
> resolution.

The certificate carries 47 rows: 45 gaps, of which the two tightest ($g<0.1$) appear
twice — the coarse-grid row retained and flagged `tight-grid-limited`, and the
`refined-midpoint` row that supersedes it. Nothing is deleted; supersession is a
recorded event, per protocol.

| object | gap | $g$ | $\rho(\mathrm{mid})$ | $M_{\mathrm{obs}}$ | $M_{\mathrm{pred}}$ | ratio | status |
|---|---|---|---|---|---|---|---|
| $\zeta$ | 1 | 6.8873 | 0.1637 | 0.2301 | 0.2188 | 1.0518 | grid‑resolved |
| $\zeta$ | 2 | 3.9888 | 0.2066 | 0.5834 | 0.5826 | 1.0013 | grid‑resolved |
| $\zeta$ | 3 | 5.4140 | 0.2362 | 0.3898 | 0.3773 | 1.0332 | grid‑resolved |
| $\zeta$ | 4 | 2.5102 | 0.2575 | 1.390 | 1.394 | 0.9976 | grid‑resolved |
| $\zeta$ | 5 | 4.6511 | 0.2745 | 0.5210 | 0.5107 | 1.0201 | grid‑resolved |
| $\zeta$ | 6 | 3.3325 | 0.2916 | 0.8915 | 0.8793 | 1.0139 | grid‑resolved |
| $\zeta$ | 7 | 2.4083 | 0.3028 | 1.550 | 1.551 | 0.9998 | grid‑resolved |
| $\zeta$ | 8 | 4.6781 | 0.3157 | 0.5697 | 0.5519 | 1.0324 | grid‑resolved |
| $\zeta$ | 9 | 1.7687 | 0.3265 | 2.756 | 2.757 | 0.9999 | grid‑resolved |
| $\chi_3$-pair | 1 | 0.3742 | 1.7370 | 68.57 | 62.77 | 1.0923 | grid‑resolved |
| $\chi_3$-pair | 2 | 0.2716 | 2.1133 | 120.7 | 116.8 | 1.0333 | grid‑resolved |
| $\chi_3$-pair | 3 | 0.6934 | 2.4919 | 27.86 | 28.25 | 0.9864 | grid‑resolved |
| $\chi_3$-pair | 4 | 0.4729 | 2.8102 | 55.01 | 50.53 | 1.0887 | grid‑resolved |
| $\chi_3$-pair | 5 | 0.0698 | 2.9285 | 1991 | 1658 | 1.2006 | tight‑grid‑limited |
| $\chi_3$-pair | 6 | 0.4308 | 3.0260 | 65.87 | 60.22 | 1.0938 | grid‑resolved |
| $\chi_3$-pair | 7 | 0.4885 | 3.1827 | 49.91 | 52.46 | 0.9515 | grid‑resolved |
| $\chi_3$-pair | 8 | 0.2641 | 3.2942 | 134.8 | 135.0 | 0.9988 | grid‑resolved |
| $\chi_6$ | 1 | 0.9284 | 1.9723 | 17.31 | 16.55 | 1.0460 | grid‑resolved |
| $\chi_6$ | 2 | 0.0917 | 2.3027 | 981.5 | 961.7 | 1.0206 | tight‑grid‑limited |
| $\chi_6$ | 3 | 0.5101 | 2.4547 | 47.12 | 42.01 | 1.1216 | grid‑resolved |
| $\chi_6$ | 4 | 0.3939 | 2.6454 | 64.99 | 64.64 | 1.0053 | grid‑resolved |
| $\chi_6$ | 5 | 0.3242 | 2.7737 | 91.01 | 90.47 | 1.0059 | grid‑resolved |
| $\chi_7$ | 1 | 0.3941 | 2.0333 | 61.26 | 59.23 | 1.0342 | grid‑resolved |
| $\chi_7$ | 2 | 0.3147 | 2.3213 | 92.97 | 90.86 | 1.0232 | grid‑resolved |
| $\chi_7$ | 3 | 0.4201 | 2.5575 | 58.54 | 57.55 | 1.0171 | grid‑resolved |
| $\chi_7$ | 4 | 0.4267 | 2.7791 | 58.22 | 58.39 | 0.9971 | grid‑resolved |
| $\chi_7$ | 5 | 0.3410 | 2.9479 | 87.99 | 85.06 | 1.0344 | grid‑resolved |
| $\chi_7$ | 6 | 0.2188 | 3.0566 | 191.8 | 184.6 | 1.0389 | grid‑resolved |
| $\chi_8$ | 1 | 0.2824 | 2.6583 | 115.0 | 113.5 | 1.0126 | grid‑resolved |
| $\chi_8$ | 2 | 0.2934 | 2.9479 | 111.3 | 109.2 | 1.0192 | grid‑resolved |
| $\chi_8$ | 3 | 0.3985 | 3.2262 | 74.48 | 69.85 | 1.0663 | grid‑resolved |
| $\chi_8$ | 4 | 0.1550 | 3.4120 | 360.5 | 354.8 | 1.0160 | grid‑resolved |
| $\chi_8$ | 5 | 0.2529 | 3.5335 | 158.9 | 148.5 | 1.0702 | grid‑resolved |
| $\chi_8$ | 6 | 0.2384 | 3.6658 | 171.0 | 165.9 | 1.0311 | grid‑resolved |
| $\chi_8$ | 7 | 0.3071 | 3.7983 | 114.4 | 111.8 | 1.0234 | grid‑resolved |
| $\chi_8\otimes\chi_{-7}$ | 1 | 0.4163 | 2.3840 | 58.34 | 56.78 | 1.0273 | grid‑resolved |
| $\chi_8\otimes\chi_{-7}$ | 2 | 0.3188 | 2.8164 | 96.91 | 93.56 | 1.0358 | grid‑resolved |
| $\chi_8\otimes\chi_{-7}$ | 3 | 0.2272 | 3.0631 | 177.1 | 172.6 | 1.0260 | grid‑resolved |
| $\chi_8\otimes\chi_{-7}$ | 4 | 0.3723 | 3.2882 | 77.53 | 77.95 | 0.9946 | grid‑resolved |
| $\chi_8\otimes\chi_{-7}$ | 5 | 0.3641 | 3.5194 | 78.73 | 83.52 | 0.9426 | grid‑resolved |
| $\chi_8\otimes\chi_{-7}$ | 6 | 0.3194 | 3.7019 | 98.29 | 104.1 | 0.9446 | grid‑resolved |
| $\chi_8\otimes\chi_{-7}$ | 7 | 0.3301 | 3.8540 | 97.23 | 101.2 | 0.9610 | grid‑resolved |
| $\chi_8\otimes\chi_{-7}$ | 8 | 0.2846 | 3.9829 | 136.4 | 128.5 | 1.0619 | grid‑resolved |
| $\chi_8\otimes\chi_{-7}$ | 9 | 0.1162 | 4.0605 | 637.4 | 623.3 | 1.0226 | grid‑resolved |
| $\chi_8\otimes\chi_{-7}$ | 10 | 0.1709 | 4.1132 | 323.7 | 305.5 | 1.0596 | grid‑resolved |
| $\chi_6$ | 2′ | 0.0917 | 2.3027 | 961.5 | 961.7 | **0.9998** | refined‑midpoint |
| $\chi_3$-pair | 5′ | 0.0698 | 2.9285 | 1659 | 1658 | **1.0003** | refined‑midpoint |

*(source: `family_certificate.csv`, package `ECL_FAMILY_THEOREM_v1_8a93b634854f.zip`.)*

The two rows that once stood outside — the tight gaps at ratio $1.2006$
($\chi_3$-pair gap 5, $g=0.0698$) and $1.0206$ ($\chi_6$ gap 2, $g=0.0917$) —
collapsed to $1.0003$ and $0.9998$ on refined-midpoint scan [R-308], precisely as
the sampling-inflation lemma prices (the coarse step $0.02$ cannot sample the
midpoint of a gap of width $0.07$); the surviving band edges are grid-resolved and
carried in the ledger of §C.5. The law also passes the **jitter test**: the largest
genuine family deviation is $100.4\%$ explained by the measured jitter–error link
[R-310, IB].

Interpretation, calibrated: this is the thesis of §A.10 — envelope geometric, line
arithmetic — promoted to a *quantitative law of the family at derivative level*. It
is measured (45 gaps), lawful (one formula), and priced (§C.5). It is not, and is
not claimed to be, a positivity proof for any member. [M]

---

## §C.5 — The Error-Budget Ledger

[R-309; framework IB, data joint.] Everything the comb law does not capture is
decomposed into five priced slots:

$$\Delta_{\text{ECL}}\;=\;R_{\text{finite}}\;+\;B_{\text{tail}}\;+\;B_\rho\;+\;B_{\text{grid}}\;+\;B_{\text{eval}}$$

| Slot | Content | Status | Row |
|---|---|---|---|
| $R_{\text{finite}}$ | genuine finite-size deviation | **measured**; jitter link explains the largest instance to $100.4\%$ | [R-310] |
| $B_\rho$ | density-law error entering through $\rho(\text{mid})^2$ | **closed analytically** from the passport law | [R-309] |
| $B_{\text{grid}}$ | sampling inflation | **priced** by the tight-gap lemma; refined scans confirm | [R-305, R-308] |
| $B_{\text{eval}}$ | evaluation error of the curves | column-rounding $3\times10^{-6}$; **zero** for $\chi_8$ on $[0,3.2]$ (interval arithmetic) | [R-309] |
| $B_{\text{tail}}$ | window-truncation tails | **open on [TODO: n] rows**, each sharply quantified | [R-311] |

> **The one open slot** [R-311, OPEN]. The surviving $B_{\text{tail}}$ rows reduce to
> an Erdős–Turán-type discrepancy bridge, with a quantified target of at most a few
> per cent of the predicted value per row. [TODO: IB's preferred formulation and
> naming; this paragraph is his.]

A budget in which four of five slots are closed or priced, and the fifth is a named
classical problem with a numerical target, is the honest boundary of the law — and
the program's forward pointer on the analytic side.

---

## §C.6 — The Tower Transfer

[R-314, IB packages, audited.] The comb law and its stack were proved for a single
cell; the family is a tensor tower (§A.5). Six transfer certificates carry the
certificate machinery up the single-cell build tower — [TODO: enumerate the six
certificates with registry names from IB's markup] — so that the envelope law is not
an accident of one object but a property transported by the tower's own structure.
What does *not* transfer is the molecule: the composite of cells where cross-terms
enter. That is the same wall as everywhere else in this paper, met in its
tower-transfer guise. [T (IB), scope-limited]

---

## §C.7 — The χ₈ Interval Theorem

The section Part III exists for. Everything before it measures and prices; this
certifies.

> **Theorem C.7 (computer-assisted; [R-312, R-313]).** Let $\Xi$ be the completed
> $L$-function of the genome $\chi_8$ (degree 8, conductor $21^{10}$,
> $\Gamma_{\mathbb C}(s)^4$, $\varepsilon=+1$) on the critical line, and
> $Q=\Xi'^2-\Xi\Xi''$. Then
> $$Q(t)\;>\;0\qquad\text{for all }t\in[0,\,3.2],$$
> with every bound computed in ball arithmetic end to end. Minimum certified margin:
> $6.638\times10^{-7}$, at the binding interval $[3.0,3.2]$ — $98\%$ of the
> grid-truth value there, i.e. the certificate is nearly sharp exactly where it is
> hardest.
>
> *Status: CERTIFIED; artifact `CHI8_MAIN_JETS_0_3p2_v1_f6b1df63868e.zip`; all 16
> intervals pass the assembly validator; registry closure CHI8-INTERVAL-1 [TODO:
> IB's registry line].*

### C.7.1 Architecture of the certificate

The proof is a composition of two independent, separately-audited components:

**(i) The $\Gamma_{\mathbb C}^4$ tail lemma** [R-312; P2.1–2.3; IB FULL LOCAL AUDIT,
CLOSED]. The smoothed approximate functional equation for $\Lambda(s,\chi_8)$ leaves
mode tails beyond any finite horizon $M$; the lemma bounds them $t$-uniformly on
$[0,3.2]$ by the Rankin device
$$dc_k(M)\;=\;32\,\min_\sigma\,\zeta(\sigma)^8\,(M{+}1)^\sigma\,I_k(A_{M+1}),$$
with $I_k$ in closed form (no quadrature anywhere). The $\delta c_k$ enter the
certificate solely through the TAIL-COMPOSITION lemma of §C.3.2 — Part III uses IB's
lemma stack as *load-bearing infrastructure*, which is the two-roads composition of
§B.8 made concrete.

**(ii) Theorem-grade main jets** [R-313]. On each of 16 covering intervals
($[0,0.2],\dots,[3.0,3.2]$), modal jets $\xi_k$ to order $K=16$ are computed at the
interval centre in Arb ball arithmetic (precision 256), from exact integer
coefficients ($N_{\text{live}}$ up to $8\times10^6$ modes) and a **closed-form
residue series** for the quadruple-pole kernel (cubic-in-log terms; no numerical
integration). Taylor remainders over each interval are bounded by a $t$-uniform
derivative table ($U_{K+1}\,r^{K+1}/(K{+}1)!$ with the derivative shift for $Q$'s
factors); the mode band between $N_{\text{live}}$ and the tail horizon is bounded by
true-$|a_n|$ blocks. Polynomial sup/inf bounds on $[-r,r]$ are grid-plus-
mean-value-corrected, hence rigorous.

| $I$ | $[a,b]$ | $N_{\mathrm{live}}$ | $S_0$ | $S_1$ | $S_2$ | $\inf Q_{\mathrm{main}}$ | $B_{\sup}$ | margin |
|---|---|---|---|---|---|---|---|---|
| 1 | $[0.0,0.2]$ | 250,000 | 4.722e+04 | 7.481e+04 | 4.447e+05 | 1.5044e+10 | 1.91e-03 | 1.5044e+10 |
| 2 | $[0.2,0.4]$ | 250,000 | 3.907e+04 | 9.093e+04 | 2.434e+05 | 5.4540e+09 | 1.08e-03 | 5.4540e+09 |
| 3 | $[0.4,0.6]$ | 250,000 | 2.169e+04 | 8.748e+04 | 2.195e+05 | 9.2943e+08 | 9.73e-04 | 9.2943e+08 |
| 4 | $[0.6,0.8]$ | 250,000 | 7.482e+03 | 5.069e+04 | 2.183e+05 | 6.3851e+07 | 9.44e-04 | 6.3851e+07 |
| 5 | $[0.8,1.0]$ | 250,000 | 1.258e+03 | 1.486e+04 | 1.232e+05 | 1.1680e+06 | 5.24e-04 | 1.1680e+06 |
| 6 | $[1.0,1.2]$ | 4,000,000 | 5.185e+01 | 1.156e+03 | 2.546e+04 | 5.9793e+04 | 1.07e-04 | 5.9793e+04 |
| 7 | $[1.2,1.4]$ | 1,000,000 | 1.611e+01 | 3.032e+02 | 2.223e+03 | 4.2157e+03 | 9.48e-06 | 4.2157e+03 |
| 8 | $[1.4,1.6]$ | 1,000,000 | 6.213e+00 | 4.486e+01 | 5.831e+02 | 4.0411e+02 | 2.47e-06 | 4.0411e+02 |
| 9 | $[1.6,1.8]$ | 1,000,000 | 1.257e+00 | 1.494e+01 | 2.633e+02 | 2.4715e+01 | 1.11e-06 | 2.4715e+01 |
| 10 | $[1.8,2.0]$ | 4,000,000 | 5.954e-01 | 6.412e+00 | 3.965e+01 | 3.3090e-01 | 1.70e-07 | 3.3090e-01 |
| 11 | $[2.0,2.2]$ | 4,000,000 | 2.516e-02 | 3.351e-01 | 1.491e+01 | 4.2768e-02 | 6.25e-08 | 4.2768e-02 |
| 12 | $[2.2,2.4]$ | 4,000,000 | 1.468e-02 | 1.231e-01 | 2.994e+00 | 5.3338e-03 | 1.26e-08 | 5.3338e-03 |
| 13 | $[2.4,2.6]$ | 4,000,000 | 3.886e-03 | 5.609e-02 | 1.033e+00 | 7.8510e-04 | 4.35e-09 | 7.8509e-04 |
| 14 | $[2.6,2.8]$ | 4,000,000 | 1.458e-03 | 2.919e-02 | 2.831e-01 | 1.0724e-04 | 1.20e-09 | 1.0724e-04 |
| 15 | $[2.8,3.0]$ | 4,000,000 | 9.214e-04 | 9.750e-03 | 7.221e-02 | 5.1628e-06 | 3.08e-10 | 5.1625e-06 |
| 16 | $[3.0,3.2]$ | 8,000,000 | 1.642e-04 | 1.596e-03 | 3.675e-02 | 6.6395e-07 | 1.55e-10 | **6.6380e-07** |

*(source: `chi8_final_interval_certificate.csv` in the hashed package; all 16 rows
pass. The margin column is $\inf Q_{\text{main}} - B_{\sup}(\delta c_k(80\mathrm M))$
per the TAIL-COMPOSITION split. Note the sixteen-order-of-magnitude descent of the
margin from $[0,0.2]$ to $[3.0,3.2]$: the certificate tracks the collapsing scale of
$\Xi$ itself, and the $N_{\text{live}}$ plan — 250k modes at the bottom, 8M at the
top — is the visible cost of holding rigor against that collapse.)*

### C.7.2 What the theorem does and does not say

It says: no real zero of $Q$ — hence no off-line zero pair or degeneracy signature
of $\Xi$ — exists at derivative level in $[0,3.2]$, an interval containing the first
eleven zeros of the genome. It is *not* a re-proof of something classical: no CNV or
comparable verification exists for $\chi_8$. And it is a **finite certificate**: it
says nothing beyond $t=3.2$, and nothing about RH or GRH. $[C]$

---

## §C.8 — Extensions of the Certificate: the Certified Spectrum and the Finite Ledger

*(v0.8 title: "Seventeen Zeros and the Finite Ledger" — superseded 2026-07-19 by the certified
spectrum of §C.8.1b; the prediction-era tables below are kept as the frozen historical record.)*

### C.8.1 The certified zero table

The same engine, pointed at individual windows, certifies sign changes of the
ball-enclosed $\Xi$ (IVT over points of certified sign):

| zero | bracket | seed | grade | row |
|---|---|---|---|---|
| $\gamma_9$ | $[3.126,3.128]$ | prime-side prediction | CERTIFIED_ZERO | [R-104] |
| $\gamma_{10}$ | $[3.338,3.342]$ | prime-side prediction | CERTIFIED_ZERO | [R-105] |
| $\gamma_{11}$ | $[3.700,3.702]$ | prime-side prediction | CERTIFIED_ZERO | [R-106] |
| $\gamma_{12}$ | $[3.952,3.954]$ | **none — density law only** | CERTIFIED_ZERO | [R-107] |
| $\gamma_{13}$ | $[4.081,4.087]$ | density law (pre-registered) | CERTIFIED_ZERO / **HIT** | [R-110] |
| $\gamma_{14}$ | $[4.357,4.379]$ | density law (pre-registered) | CERTIFIED_ZERO / **HIT** | [R-111] |
| $\gamma_{15}$ | $[4.548,4.550]$ | density law (pre-registered) | CERTIFIED_ZERO / **HIT** | [R-112] |
| $\gamma_{16}$ | $[4.692,4.696]$ | density law (pre-registered) | CERTIFIED_ZERO / **NEAR** | [R-113] |
| $\gamma_{17}$ | $[4.886,4.890]$ | density law (bonus) | CERTIFIED_ZERO | [R-114] |

$\gamma_9$–$\gamma_{11}$ close three instances of the two-method handshake [R-205]:
predicted from the primes by the explicit-formula extraction [R-108, seeds graded
CORROBORATIVE_PRIME_SEED_ONLY — the sinusoid form assumes RH, so seeds are never
certificates], then certified on the $L$-side by an independent ball certificate (which takes no input from the prime-side seed).

$\gamma_{12}$ is different in kind: **the first pure-prediction certified zero from
the passport density law, without a prime-side seed** — the target window came from
the density law alone, and the certified zero sits inside it, with no other sign
change and no ambiguous point in the window. The passport law now predicts zeros it
has never seen, at certified grade. It remains a finite certificate, not RH/GRH. $[C]$

**Update (2026-07-15) — the certified set is now complete to $t\le5.95$.** The table above is the frozen
pre-registration record; the *current* certified brackets extend and tighten it. All of
$\gamma_1$–$\gamma_{21}$ are now ball-certified (arb, prec 256): $\gamma_{18}$–$\gamma_{21}$ — previously
`numerical_anchored` — were certified by the Channel-B block-cutoff method ($\gamma_{18}$/$\gamma_{19}$ at
16M/32M jets and a 120M cutoff; $\gamma_{20}$/$\gamma_{21}$ needed a 160M cutoff, floor $7.4\times10^{-13}$,
$\gamma_{21}$'s peak $|\Xi|=1.75\times10^{-12}$ cleared with $\sim2.4\times$ margin). The two widest
brackets tightened: $\gamma_{13}$ $[4.081,4.087]\to[4.0835,4.0840]$ ($\sim9\times$), $\gamma_{14}$
$[4.357,4.379]\to[4.366,4.368]$ ($\sim11\times$). The frozen HIT/NEAR scores are unchanged (the tightened
brackets still lie inside the pre-registered windows). Authoritative table:
`chi8_certified_zeros_MASTER` / the all-21 certificate package. $[C]$

### C.8.1a The pre-registered batch $\gamma_{13}$–$\gamma_{16}$, and a new certification lever

[R-110–115, R-506.] $\gamma_{13}$–$\gamma_{16}$ were predicted, windowed (PRIMARY
$\pm0.10$, SECONDARY $\pm0.20$), and scored (HIT/NEAR/MISS) under a **frozen
pre-registration** hash-anchored *before any computation* (Axiom-L discipline; the
counterparty received the note on freeze). Verdict, scored strictly: **three HITs
($\gamma_{13},\gamma_{14},\gamma_{15}$) and one NEAR ($\gamma_{16}$)** — the passport
law is now five-for-five blind ($\gamma_{13}$–$\gamma_{17}$, counting NEAR as a
law-consistent $S(T)$ excursion), squarely inside the pre-declared "$\sim$3–4 of 4 in
PRIMARY." $\gamma_{16}$ falls $9/1000$ below the PRIMARY edge $4.703$; it was
**pre-committed in writing as NEAR** — no rescue, no re-window. $\gamma_{17}$ is an
unregistered bonus.

The batch also produced a **method result** [R-115]. At the frozen $K=16$ engine the
$\gamma_{15}/\gamma_{16}$ windows first returned UNRESOLVED: the completed $\Xi$'s
amplitude ($\sim2.5\times10^{-9}$) had sunk below the certification floor
($\sim4\times10^{-9}$) around $t\approx4.5$. Decomposing that floor
$=\text{band}+U_{K+1}r^{K+1}/(K{+}1)!+\text{mtail}$ shows the jet-order term
($\sim10^{-16}$ at $r=0.05$) and the mode band ($\sim4\times10^{-13}$) are both
negligible: the floor is **entirely the Rankin $d_8$ tail beyond the $80$M block
cutoff**. Extending that cutoff to $120$M drops the floor to $1.98\times10^{-11}$
($\times210$), and — since the expensive modal jets are unchanged and the tail enters
the enclosure only additively — the windows recertify **from the cached jets** by
exact halfwidth-differencing, with no re-computation. This is reported as a declared
**post-registration channel** (strictly tighter bound, frozen windows and scoring
untouched, never backfilled into the pre-registered UNRESOLVED result [R-506]). The
practical upshot: the certification wall at higher $t$ is set by the block cutoff, not
by jet order or mode count — a cheap lever for pushing the certified zero table
deeper. $[C]$; not RH/GRH. *(That lever, industrialized, became the completeness engine
of §C.8.1b — the jets-era method's successor for everything above $t\approx6$.)*

The full grading discipline invoked here — Axiom-L pre-registration, the HIT/NEAR/MISS
scoring rule, the two-channel honesty protocol, and the block-cutoff method [R-115] — is
stated once, formally, in **Appendix G** (grading protocol), with the $\gamma_{13}$–$\gamma_{17}$
batch scored there in a single table.

### C.8.1b The certified spectrum: 152 brackets and CERTIFIED Turing counts (2026-07-19)

[Package `to_Ilya_CERTIFIED_spectrum_2026-07-19`, SEALED and SENT; `TURING_RESULT.json` filled at
CERTIFIED status under IB's strict completeness gate.] The jets-era zero table above is superseded in
reach — and confirmed in content — by a single certified run of the **rescaled-FFT completeness
engine** (the Booker §5 / Palojärvi–Zhao §5 architecture: exact integer coefficients $a_n$ to
$n\le1.15\times10^{11}$, arb-residue Mellin kernels with proven tail bounds, a direct Poisson ball
sum in place of the FFT, and a total non-ball tail of $5.57\times10^{-9}$ against a smallest used
signal of $\sim3\times10^{-5}$). Two headline results:

**(A) 152 ball-certified zero brackets on $[0,27.92]$**, median radius $4\times10^{-6}$ (versus
$\sim10^{-3}$ in the jets era) — each bracket a certified sign change of the ball-enclosed
$F(t)=\Lambda(\tfrac12+it)e^{2\pi\eta t}$. All sixteen previously jets-certified brackets
($\gamma_1$–$\gamma_{24}$ line) are reproduced inside the new enclosures: the counting engine and the
jets engine confirm each other at ball grade, and $\gamma_{25}$ onward are certified for the first
time. **Honest caveat, carried everywhere it matters:** one bracket did not certify — **#144, at
$t\approx26.45$** (a weak-amplitude zero at the enclosure floor); its location remains
numerical-grade, its certification pending, and ordinals $\ge145$ are stated modulo #144. Its absence
only *strengthens* the one-sided count verdicts below (an uncounted zero enlarges the defect). Nothing
is claimed above $t=27.92$. $[C,\ \mathrm{CERTIFIED}]$

**(B) CERTIFIED one-sided Turing counts.** With the Turing constant $B=57.89$ evaluated as a
certified ball from Palojärvi–Zhao (arXiv:2508.03023, Thm 2.3) at the $\chi_8$ Selberg data, the
one-sided counts

$$N^+(5.969)=21\qquad\text{and}\qquad N^+(6.55)=24$$

are **CERTIFIED** — every error term in the chain a proven bound, no numerical grades anywhere —
with rule-out margins $+0.80\ldots+2.92$ and $+0.27\ldots+2.39$ respectively over $t_2$ up to $28$.
The statement "**no zeros are missing below the Turing heights**" — which §A.9.2 could previously
assert only at argument-principle tracking grade — is therefore now itself a certified statement.
Uniqueness/simplicity per interval and off-line exclusion below $6.55$ follow at certified grade by
IB's FIRST24 bridge argument with the certified count substituted. $[C,\ \mathrm{CERTIFIED}]$

Downstream effect inside this paper: every margin or count in §§C–D quoted at the seventeen- or
twenty-one-zero era is superseded by this set; the old values are retained only inside dated notes
(per protocol, nothing deleted). The certified spectrum changes *no* numerics in the operator-lane
results (zeros enter there only as counts/atoms; values confirmed to $\sim10^{-6}$) — it upgrades
their *grade*, replacing `numerical_anchored` inputs by certified ones. $[C]$

### C.8.2 The finite K-modulus ledger

[R-206; CERTIFIED FINITE LEDGER through $m=17$ (07-11 extension).] With seventeen
certified atoms $1/\gamma^2$, the void-pressure Hankel determinants
$H_m=\det[S_{i+j-1}]$ are evaluated over all $2^9=512$ bracket-corner combinations of
the nine bracket-certified zeros $\gamma_9$–$\gamma_{17}$: every $H_m$, $m\le17$, is
**positive at every corner**, and the density-tail-corrected sequence (the
non-automatic content) stays positive through $m=17$. Corner spreads remain
$\le5\%$ through $m=13$ and grow to $37\%$ at $m=17$, driven by the widest certified
bracket ($\gamma_{14}$'s pass-1 interval $[4.357,4.379]$); positivity is robust
throughout while the *value* precision at high $m$ is bracket-limited. The collapse
profile $\log_{10}H_m/m^2$ drifts monotonically to $-0.966$ at $m=17$ — **reconciling**
the m$\le$12 notes' extrapolated "$\approx-0.8$" with the original eight-zero rate fit
$c\approx0.99$: they are one curve at different depths. Li partials lift toward the
prime-side values with the truncation turnover pushed to $n\approx10$ (peak partial
$\approx51$, up from $\approx35$ at twelve zeros) [R-207, M].

Honesty note, as in §B.6: for a finitely-atomic measure, positivity of $H_m$ for
$m\le\#\text{atoms}$ is automatic; the content is the *values* — the margin profile
of the knife-edge — and the tail-corrected column. Finite positivity and margin
profile only; the difference between "positive through $m=12$" and "positive for
all $m$" **is** the wall. $[C]$

*(Dated note, 2026-07-25: the certified atom supply is now the 152-bracket spectrum of §C.8.1b; the
$m\le17$ ledger stands as computed on the seventeen-bracket set, and its extension on the deeper
certified atoms is staged, not claimed.)*

### C.8.3 The unconditional pointwise $|S(t)|$ bound — the zero-free analytic layer (2026-07-25)

[`T2_GC2_true_S_2026-07-25/FINDINGS_GC2_true_S_pointwise.md`; grade displayed-rigorous.] The
certified spectrum of §C.8.1b is sharp but *computed*; this subsection adds the complementary layer —
an explicit pointwise bound on $S(t)=\tfrac1\pi\arg L(\tfrac12+it,\chi_8)$ that uses **no
zero-location input anywhere in its analytic chain**. Palojärvi–Zhao (arXiv:2508.03023) contains no
pointwise theorem — Thms 2.1–2.3 bound $\pi\int_{t_1}^{t_2}S\,dt$ only — so the pointwise bound is
*derived*: the classical **Turing sandwich** applied on both sides of PZ Thm 2.3 (the
polynomial-Euler-product form) at the $\chi_8$ Selberg data ($\lambda_j=\tfrac12$ (×8),
$\mu_j\in\{0^{\times4},\tfrac12^{\times4}\}$, $N=21^5/\pi^4$, $\ell=8$, entire), using the
monotonicity of $N(t)$ and the certified convexity of the phase ($\min\theta''=+0.125>0$ on
$[5,32]$). The result:

$$|S(t)|\ \le\ \approx13.8\text{–}15.9\quad\text{on }t\in[7,30]
\qquad(\sup_{[7,30]}\le15.899;\ \text{floor }t>5.27\text{ inherent to the theorem's hypothesis}),$$

roughly flat because the $\log Q_L$ growth is slow on this range; the table in the findings file *is*
the bound (a $c_1+c_2\log t$ fit is not meaningful on so short a range). The constants are crude
($|S|\lesssim16$ against measured $|S|\approx0.86$) — their value is **logical, not sharp**: with
them, the atom-map positivity transfer of the operator companion (Paper B, Theorem A / KLMN) holds
**unconditionally in true $S$** for every tail cut $k\ge k^*=24$ ($\varepsilon_k$ from $0.99$ down to
$0.18$ at $k=140$, $b=0$), with *no computed spectrum in the hypotheses*; the head ($k<24$, below the
PZ floor) composes with the certified route. **One flagged condition:** the lower-side bound uses the
endpoint-swapped reassembly of PZ's proof (the swap-lemma — that the two endpoint integrals are
bounded separately); the upper side is verbatim-theorem. IB's confirmation of the swap reading is
pending; until then the lower side carries that single displayed condition. The certified-zero route
of §C.8.1b remains the sharp instrument on $[0,27.92]$; this layer is what stands *without* it.
$[C/P,\ \text{displayed-rigorous; one flagged condition}]$; not RH/GRH.

---

## §C.9 — Honest Ledger (Part III)

| Claim | Grade | Register |
|---|---|---|
| Envelope Comb Law + side-lemma stack | THEOREM (IB; one lemma CONDITIONAL, $C(\theta)\le10$) | R-301–306 |
| 45-gap family law, band $[0.943,1.122]$, nothing fitted | MEASURED; registry closure pending | R-307, R-308 |
| Five-slot error budget | four slots closed/priced; $B_{\text{tail}}$ OPEN (Erdős–Turán target) | R-309–311 |
| Tower transfer (six certificates) | THEOREM (IB), scope-limited to the build tower | R-314 |
| $\Gamma_{\mathbb C}^4$ tail lemma | CERTIFIED + AUDITED (IB full local audit) | R-312 |
| **$Q>0$ on $[0,3.2]$ for $\chi_8$** | **CERTIFIED**; registry closure pending | R-313 |
| $\gamma_9$–$\gamma_{21}$ | CERTIFIED_ZERO — **all ball-certified to $t\le5.95$** ($\gamma_{12}$ pure prediction; $\gamma_{13}$–$\gamma_{16}$ pre-registered, 3 HIT + 1 NEAR; $\gamma_{15}$–$\gamma_{21}$ via Channel-B block-cutoff extended-tail; $\gamma_{13}$/$\gamma_{14}$ tightened, $\gamma_{18}$–$\gamma_{21}$ certified 2026-07-15) — *superseded in reach by the certified spectrum, 2026-07-19* | R-104–107, R-110–115 |
| **Certified spectrum: 152 ball brackets on $[0,27.92]$** (median $4\times10^{-6}$; #144 numerical, pending) | **CERTIFIED** [2026-07-19] | §C.8.1b |
| **Turing counts $N^+(5.969)=21$, $N^+(6.55)=24$** (margins $+0.80\ldots+2.92$ / $+0.27\ldots+2.39$) | **CERTIFIED** [2026-07-19] | §C.8.1b |
| Unconditional pointwise $\lvert S(t)\rvert\le\approx13.8$–$15.9$ on $[7,30]$ (no zero input) | displayed-rigorous; lower-side swap-lemma flagged, IB pending [2026-07-25] | §C.8.3 |
| K-modulus ledger $m\le17$ | CERTIFIED FINITE LEDGER (atom supply now 152; extension staged) | R-206 |
| Prime-side seeds | CORROBORATIVE only | R-108 |

**Not claimed:** RH; GRH; positivity beyond $t=3.2$; anything above $t=27.92$; the
certification of bracket #144; the lower-side $|S|$ bound past its flagged condition;
Hankel positivity beyond $m=17$; any inference from seeds. The wall stands where
Part II left it; this part measured, priced, and certified the ground in front of it.

---
*[Draft status v0.9, 2026-07-25. Certified-spectrum era folded in (§C.8.1b, §C.8.3;
sources: `to_Ilya_CERTIFIED_spectrum_2026-07-19`, the completeness-engine packages,
`T2_GC2_true_S_2026-07-25`). Still awaiting artifact import and IB's markup: §C.4
table registry line, six tower-certificate names, ECL-FAMILY-1 and CHI8-INTERVAL-1
registry lines, the §C.5 Erdős–Turán paragraph, and IB's swap-lemma confirmation
for §C.8.3.]*


---

# Part IV — The Finite Machine: the Key, the Door, and the Ladder

---


## §D.1 — Introduction: from anatomy to dynamics

Part II's §B.2 presented the finite cell as anatomy: the gate, the genome, the two
cones, the void operator. This part upgrades anatomy to **dynamics with theorems**.
The finite side of the operator road turns out to have a mechanical structure of its
own: a descent ladder with certified rungs, a unique **door** at one rung, a
canonical **key** selected by the trit, a proven partition of what lies
behind the door, and an assembly rule by which the hidden material — three dark
thirds and one still point — rebuilds the next rung of the ladder.

Every structural claim below is proven (character arithmetic, GAP, or exact rational
linear algebra) or certified, with one explicitly named conditional; the audit trail
is two-directional throughout. The interpretive layer — *why* a machine, *why* a
door — is confined to §D.9 and tagged [R]. What the machine can and cannot say about
the infinite flow is stated as a theorem, not a hope, in §D.8.

Throughout: $G=\mathrm{PSL}(2,7)$, $H$ an $S_4$ subgroup (two conjugacy classes:
point-stabilizers and plane-stabilizers of the Fano plane), $K=C_7{\rtimes}C_3$ the
Singer normalizer, $F$ a fixed 3-cycle — **the trit**, the distinguished order-3
element of the finite cell (§B.2/§B.3). Throughout this part the trit is used purely
as a group element; its temporal reading belongs to the interpretive layer (§D.9)
and to nothing here — and it is distinct, as always, from the canonical Aion flow.

---

## §D.2 — The Ladder: the Certified Descent Table

[R-401; joint — IB registry + character arithmetic, sympy-checked.]

The filtration ladder descends from the regular representation through fixed
permutation modules:

$$F^{(7)}=V_{\mathrm{reg}}\ (168)\;\to\;F^{(6)}=\mathbb Q[G/C_7]\ (24)\;\to\;
F^{(5)}=\mathbb Q[G/K]\ (8)\;\to\;F^{(4)}=\mathbb Q[G/S_4]\ (7)\;\to\;
F^{(3)}=\mathbb Q\ (1)\;\to\;0,$$

with dimension drops $[144,16,1,6,1]$ — **proven exact** by character arithmetic;
the ledger identity is $V_{\mathrm{reg}} \ominus (\text{descent})=\operatorname{coker}(\chi_6)$-side
bookkeeping carried in the registry. Two structural facts anchor everything below:

- $F^{(6)}=\mathbb Q[G/C_7]$, the 24-point Singer-coset permutation module, with
  $$F^{(6)}\;=\;\chi_1\oplus\chi_7\oplus 2\chi_8 .$$
  This decomposition is registry theorem **Th-157 [joint, GAP-verified, May 2026]**
  — proved seven weeks before the assembly theorem of §D.6 discovered what it is
  *for*.
- The discriminator $\operatorname{Hom}_G(\chi_8,\chi_7)=0$ resolves the Definition
  3.1 vs TQFT-table tension (two-row erratum recorded); the 49-candidate enumeration
  reconciles as the $\operatorname{Hom}\le2$ subset of the 202, all counts
  reverified. [T]

[TODO: IB's registry names for the descent-table entries.]

---

## §D.3 — The Throat

[R-402, R-405.]

### D.3.1 The object

At the $F^{(5)}\!\to\!F^{(4)}$ rung the descent is carried by a **throat map**: an
$H$-equivariant linear map from the Galois-completed throat module
$$V(25)\;=\;\mathbb Q[G/K]\;\oplus\;\operatorname{Ind}_K^G(W_2)\;\oplus\;\mathbb Q
\qquad(G\text{-content }2\chi_1\oplus\chi_7\oplus2\chi_8)$$
to the Fano permutation module $W(7)=\mathbb Q[G/H]$. Here $W_2$ is the rational
2-dimensional representation of $K/C_7$. The Hom-space is 9-dimensional (Reynolds
averaging over $H$; verified in exact rational arithmetic, dimension 9 on the nose
— `e5_turn_the_key.py`, in-repo). A throat of full rank 7 has an 18-dimensional
kernel: **the hidden sector**.

The torsor lemma **T7B′** [IB, repaired and constructive; R-402] supplies the
structural origin: the frame torsor forces the regular representation, and the
throat is its Galois completion.

### D.3.2 The finite lock theorem

> **Theorem T50018** [IB; THEOREM / AUDITED ✦; R-405]. $q=0$ and
> $\operatorname{rank}(A)=7\;\Rightarrow\;\operatorname{cyclicRank}(A)=8$ over
> $\mathbb Q$ — for every rank-7 throat map $A$, in both $S_4$ classes.
>
> *Proof: 1008 structural charts, Singular pipeline [IB]; independently audited
> (byte-verified package, deterministic rerun) [avatar]. Registry: [TODO: IB line].*

The name is earned: the throat cannot be turned by less than the full cyclic action
— a lock with a definite tumbler count.

---

## §D.4 — The Selector Chain: What the Trit Does and Does Not Do

[R-403, R-404; IB GAP chains T50015–17, audited.]

The naive conjecture — that the trit literally *is* a heat flow on the
throat (the "clock = heat" conjecture, strict form; the name is the conjecture's,
from the exploratory layer) — **fails**: T50015 is a proven negative, and
we keep it. What survives is sharper:

- **T50016/17**: the trit **transports** between conjugate throats and **selects**
  one $S_4$ class; the transport has identity monodromy — no Berry phase at
  Hom-level. Selection without dynamics: the trit does not flow, it *chooses*.
- The honest negative is load-bearing: it is what enforces the trit/Aion distinction
  of §B.3 empirically, and it redirected the bridge search from Hamiltonian mimicry
  to the ledger observables of §C.8/§D.8.

**Notation ($H_1$/$H_2$, resolved intrinsically).** The two $S_4$ classes of
$\mathrm{PSL}(2,7)\cong\mathrm{GL}(3,2)$ are the **point-stabilizers** and the
**plane-stabilizers** of the Fano plane (seven each, swapped by the outer automorphism /
Fano duality). The throat is stated $H_1$-equivariantly, and the canonical key is a
*point*-stabilizer — the stabilizer of the still point $p_0$ (§D.5) — so the natural
binding is $H_1=$ the point-stabilizer class (the throat's own class) and $H_2=$ the
plane-stabilizer class (its Fano-dual). The mathematics is fixed by our results (T50017
selects the class, trit-fixedness the member); IB owes only the **symbol orientation** — if
his convention names $H_2$ the other way, swap the two symbols throughout and nothing else
changes. *[RESOLVED 2026-07-13 — REV5 reconciliation: IB's T14 and our Perlis note agree,
$H_1=$ point, $H_2=$ line; the arithmetic/canonical-key bridge lands on the point class $H_1$
(T500 convention $H^\*=\mathrm{stab}(p_0)$), the locked chart65/Hidx$=2$ realization is the
outer-dual line class $H_2$. The "IB owes symbol orientation" flag is removed. One phrasing
guard from his T14a: arithmetic equivalence does* not *force equal ramification indices
(Mantilla-Soler) — the two resolvents are a Gassmann pair with equal Dedekind zeta, but zeta
and residue-degree data cannot select the point/line label; the ramification facts are
separately certified (T13, §D.5 note). Registry lines for T50015–17 remain his.]*

---

## §D.5 — The Canonical Key at the Still Point

[R-406.]

The trit acts on the seven conjugates of $H$ within its class. The orbit structure
is $1+3+3$: **exactly one conjugate is trit-fixed** — per class, per trit. That
conjugate is $H^\*=\operatorname{stab}(p_0)$, the stabilizer of the trit's unique
fixed point $p_0$ on the Fano plane: the **still point of the Singer dial**.

> **The Still-Point Key Theorem** [T; R-406]. For each $S_4$ class, the trit fixes exactly
> one throat — the one anchored at the still point. The key is not chosen; it is the
> unique fixed point of the trit's action on the space of keys. The throat is thus
> **doubly canonical**: the transport selects the class (T50017), and trit-fixedness selects
> the unique member within it.
>
> *Verified in exact rational arithmetic (orbit count and stabilizer identification,
> `e5_turn_the_key.py`).*

*[Upgraded 2026-07-13 — REV5 T13, CERTIFIED.]* The still point's arithmetic anchor is now an exact
maximal-order result: the Trinks $1+3+3$ splitting at $3$, total ramification at $7$, and the inertia
data are **separately certified** by IB's T13 maximal-order computation — certified facts in their own
right, not consequences of the Gassmann/equal-zeta pairing (which cannot select them; §D.4 note).

---

## §D.6 — The Equipartition Theorem

[R-407; THEOREM ✦ (IB grade, 07-08); candidate registry name T50019a.]

> **Theorem (Equipartition).** Let $A:V(25)\to W(7)$ be ANY rank-7 $H$-equivariant
> throat map (either class), $F\in H$ the trit. Then the hidden sector decomposes
> under $F$ as
> $$\ker A\;=\;6\;\oplus\;6\;\oplus\;6\qquad(\text{eigenvalues }1,\ \omega,\ \omega^2)$$
> — perfect ternary equipartition, independent of the map, the chart, and the class.

*Proof.* (i) $A$ is $H$-equivariant and, at rank 7, surjective, so
$\ker A\cong V|_H\ominus W|_H$ as $H$-modules — the kernel's $H$-type is **forced**:
$\mathrm{sign}\oplus\mathrm{deg2}\oplus2\,\mathrm{std}^+\oplus3\,\mathrm{std}^-$
(point class; the plane class swaps the std multiplicities $2\leftrightarrow3$).
(ii) A 3-cycle's eigenvalue counts per $S_4$-irrep (character values $1,1,-1,0,0$ at
a 3-cycle): $\mathrm{triv}\to(1,0,0)$, $\mathrm{sign}\to(1,0,0)$,
$\mathrm{deg2}\to(0,1,1)$, $\mathrm{std}^\pm\to(1,1,1)$. (iii) Count:
$(1{+}0{+}2{+}3,\;0{+}1{+}2{+}3,\;0{+}1{+}2{+}3)=(6,6,6)$; the other class gives the
same totals. $\blacksquare$

Three remarks, each earned:

1. The balance is an exact conspiracy of the forced multiplicities: sign donates its
   whole dimension to the fixed space, deg2 entirely to $\omega\oplus\omega^2$, and
   the 3-dimensional types are individually balanced. Equipartition is a property of
   the **bottleneck rung's representation theory**, not of any key or map.
2. Each slice has dimension $6=\dim\chi_6$ — the ledger's returnable change (§B.2),
   now an unconditional identity rather than a numerical echo.
3. No sweep, no sample, no genericity: five lines of character arithmetic. It is the
   cheapest theorem in this paper and the one that closes the most questions.

---

## §D.7 — The Assembly Theorem, and the One Condition

[R-408, R-409; CONDITIONAL / SWEEP-IN-PROGRESS ✦; registry T50019.]

Write $V_{23}\subset V$ for the canonical $G$-isotypic $\chi_7\oplus2\chi_8$, and
let $K=\ker A$ for a rank-7 throat.

**Lemma 0** (the kernel avoids the trivial — proven). At rank 7 the trivial Schur
block is invertible; and at this rung — uniquely on the ladder, see §D.8 — the
$H$-trivial isotypic of $V$ equals the $G$-trivial $T_2$. Hence $K\subset V_{23}$.

**Lemma 2** (the $\chi_7$-part is automatic — proven). $K$ contains its forced
sign-isotypic component, and within $V_{23}$ the $H$-type sign occurs **only** in
$\chi_7$ ($\chi_7|_H=\mathrm{sign}\oplus\mathrm{std}^+\oplus\mathrm{std}^-$;
$\chi_8|_H=\mathrm{deg2}\oplus\mathrm{std}^+\oplus\mathrm{std}^-$). Since $\chi_7$
has $G$-multiplicity 1: $\langle G\cdot K\rangle\supseteq\chi_7$, unconditionally.

**The condition (S).** $\chi_8$ has $G$-multiplicity 2, with multiplicity space
$M\cong\mathbb Q^2$; let $U(A)\subseteq M$ be the span of the kernel's
$\chi_8$-multiplicity components. Condition (S): $U(A)=M$ — equivalently a specific
$2\times2$ minor is nonzero, a polynomial condition in the 9 Hom parameters,
extractable from the T50018 projector bases.

> **Theorem (Assembly; proven modulo (S)).** If $\operatorname{rank}(A)=7$ and (S)
> holds, then
> $$\langle G\cdot K\rangle\;=\;V_{23}\;=\;\chi_7\oplus2\chi_8\quad(\dim 23),$$
> and with the still-point marker line,
> $$\langle G\cdot K\rangle\;\oplus\;\mathbb Q_{\text{marker}}\;\cong\;F^{(6)}\;=\;
> \chi_1\oplus\chi_7\oplus2\chi_8 .$$
>
> *Proof.* $\langle G\cdot K\rangle$ is a $G$-submodule of $V_{23}$ (Lemma 0); its
> $\chi_7$-part is full (Lemma 2); its $\chi_8$-part is $\chi_8\otimes U(A)=
> \chi_8\otimes M$ under (S). $\blacksquare$

**Trit saturation** (measured; second condition (S′)). At the declared sample point,
$\Sigma=K+F{\cdot}K+F^2{\cdot}K$ equals $\langle G\cdot K\rangle$ (both 23-dim);
in general $\Sigma\subseteq\langle G\cdot K\rangle$ with equality iff a
triple-intersection determinant (S′) is nonzero. Under (S)+(S′), **the trit 3-cycle
alone performs the whole group's assembly**:

> three dark thirds and one still point make the next rung.

If (S) fails on some chart, the assembly there is $\chi_7\oplus(\chi_8\otimes
\text{line})$, dimension 15 — the theorem says exactly what degrades and by how
much. *Status (T50019-S″ FINAL, 2026-07-10): on **chart65 the assembly locus is now a
CERTIFIED theorem** — $\dim(K{+}FK{+}F^2K)=23 \iff Q_2(b)\neq0$ with
$Q_2=b_5^2{+}b_5b_6{+}b_6^2{-}b_7^2{-}b_7b_8{-}b_8^2$ (the Eisenstein exceptional
quadric), by exact Singular elimination over all five affine charts (principal ideal
$Q_2$ each, no residual component, matching 6/6 data). The universal Open2b and the
$\operatorname{rank}(M_{\mathrm{obs}})<15$ proxy are both **REFUTED** by explicit
rational witnesses; admissibility ($q=0$, $\operatorname{rank}A=7$) is **resolved with
no gap** (built into the chart65 construction). Remaining: the other **503 charts**
(Hidx$=2$ atlas) **OPEN but scope-reduced** — the setup depends only on Hidx, so $Q_2$
is expected shared, reducing the task to 503 cheap nonemptiness checks rather than
independent eliminations (Hidx$\neq2$ and the second $S_4$ class unverified).* Note the
target's decomposition is Th-157 (§D.2): the theorem assembles precisely the module the
joint registry catalogued in May.

*[Updated 2026-07-13 — REV5 reconciliation; supersedes the sweep status above.]* IB's REV5 registry
(T50019 program, T8 CERTIFIED) moved this section's frontier, and we fold in its verdicts:

- **The second-$S_4$-class gap is CLOSED.** IB's **T8** — a matrix-family point/line lift
  $T_{\text{true}}\in\mathrm{GL}_4(\mathbb Q)$ with all residual ranks $0$ — closes the flagged
  "second $S_4$ class" seam *stronger than chart-by-chart*; we **independently reproduced it the same
  day** (FINAL_T8_STATUS=CERTIFIED). One recorded discrepancy: our witness determinants differ from
  his (a basis difference in the underlying `t50o10` defs; same theorem, different valid witness), so
  T8 is quoted here at rank-equivalence level, where the determinant is immaterial, until the
  byte-level witness match is made. A scope guard from his T7: the raw $b_6\leftrightarrow b_7$ swap
  is a *quadric identity only* — the actual family symmetry is $T_{\text{true}}$, not the swap.
- **The 503-chart sweep question is reframed.** Per his T4/T12, the 504-chart (fixed-class) and
  1008-chart (both classes) assembly/DSE are now **conditional ONLY on the fixed-class $b_8$
  residual**: the $b_8=1$ chart is NONUNIT after 27 residuals (Gröbner length 63, residual dim 1),
  the rank-B exclusion shortcut is REFUTED by explicit witness, and an admissible $b_8$ residual is
  certified to *exist*. So the assembly is **not** fully closed — (S)/(S′) "sweep in progress"
  becomes "conditional on $b_8$", the one remaining computational seam.
- **Both class quadrics live in $\mathbb Z[\omega]$.** The point-class quadric is
  $Q_{H_1}=b_5^2-b_6^2+b_5b_7+b_7^2-b_6b_8-b_8^2=N(b_5-b_7\omega)-N(b_6-b_8\omega)$ — like $Q_2$
  (the line-class $Q_{H_2}$), a difference of Eisenstein norms, so the Coda's $\mathbb Z[\omega]$
  reading holds for both classes.

*[v0.9 note: IB's exact-$\mathbb Q$ certified bridge chain (2026-07-18→20) — including the full
projective $Q_2$ stratification and the triple-rowspace mechanism — will anchor this section's
$Q_2$/assembly statements at certificate grade; integration staged, and the measured-grade claims
above stand unmodified until it lands.]*

---

## §D.8 — The Door Criterion, and the Ceiling

### D.8.1 One door

[R-410; proven.] Could the same mechanism — equivariant descent with a trit-selected
key and an assembling hidden sector — exist at other rungs? No:

> **The Door-Uniqueness Criterion** [T; R-410]. Marker separation — the $G$-closure of
> $\ker A$ avoiding the trivial line — holds **iff**
> $\operatorname{mult}_{\mathrm{triv}}(V|_H)\le\operatorname{mult}_{\mathrm{triv}}(W|_H)$
> at the rung's stabilizer, and on this ladder that holds **only** at the
> $F^{(5)}\!\to\!F^{(4)}$ bottleneck — where the target is $\mathbb Q[G/S_4]$, the
> $\chi_6$ ledger-change appears, and the trit selects. Above it, the descent is
> rigid certified $G$-descent with no hidden sector to hide anything in.

The criterion was found the honest way: a rung-climb attempt *failed* (the closure
flooded to 169 — $G$-averaging drags in trivial mass), and the failure, pursued,
became the uniqueness proof. The ladder has one door. [T]

### D.8.2 The ceiling, stated as a theorem

What can the finite machine say about the infinite flow? Two results bound the
bridge honestly:

- **The Hamiltonian-ladder probe is null** [R-411; M, negative]. Under declared
  tests with synthetic-null controls, ladder-derived Hamiltonians are
  edge-dominated: no spectral correspondence with the zero field survives its null.
  The probe's methodological yield: the correct finite$\to$infinite observables are
  the **ledger functionals** (power sums, Hankel margins, Li partials — §C.8), which
  weight small zeros dominantly and converge from below.
- **The finite-label no-go** [R-024; THEOREM, IB]. Finite class data carries at most
  $\log_2 6$ bits per prime, while RH-grade control is unbounded: **no finite label
  can span the wall.** The machine of this part therefore cannot, even in principle,
  close the bridge by itself — and the paper says so as a theorem, not as a
  concession.

The bridge itself — canonical Aion self-adjointness $\Leftrightarrow$ $|K_L|=1$
$\Leftrightarrow$ Weil/Li positivity — remains **OPEN** [R-209], as it must: it is
the wall of Part II in operator dress.

*[v0.9 pointer.]* The door / still-point / ladder material of §§D.3–D.8 keeps its home and its
theorems here; where it feeds the operator program, it is now also carried in the **operator
companion (Paper B, §12, architecture grade 2026-07-23)** — the de Branges face of the $H=D+V$
construction, which instruments exactly which faces of self-adjointness are equivalent to,
sufficient for, or independent of $\mathrm{RH}(\chi_8)$, refutations included. The companion cites
this part for the finite machine; this part cites the companion for the operator dress. Neither
crosses the wall.

---

## §D.9 — What the Machine Means (interpretive; [R])

Confined to one section, tagged, and brief. The finite machine is the program's
answer to *where the structure lives*: the genome's cell is not an inert lookup
table but a mechanism — a lock (T50018), a key selected by time's own fixed point
(§D.5), a hidden sector in perfect ternary balance (§D.6), and an assembly rule that
rebuilds the ladder's next rung from what the throat hides (§D.7). The suggestive
chain — the clock selects, the key opens, the dark thirds assemble — is structural
fact; the *reading* of it as the finite shadow of the infinite flow's balance is
interpretation and is claimed as nothing more. The theorems stand without the
reading; the reading, without the theorems, would be poetry. We keep both, labelled.

---

## §D.10 — Honest Ledger (Part IV)

| Claim | Grade | Register |
|---|---|---|
| Descent table, drops $[144,16,1,6,1]$; $F^{(6)}=\chi_1\oplus\chi_7\oplus2\chi_8$ (Th-157) | THEOREM | R-401 |
| T7B′ torsor $\Rightarrow$ regular rep | THEOREM (IB) | R-402 |
| **T50018: rank 7 $\Rightarrow$ cyclic rank 8 (finite lock)** | **THEOREM / AUDITED** | R-405 |
| T50015 strict clock=heat | proven NEGATIVE (kept) | R-403 |
| T50016/17 trit transport + class selection, identity monodromy | THEOREM (IB, GAP) | R-404 |
| Canonical key (1+3+3, still point) | THEOREM | R-406 |
| **Equipartition $6\oplus6\oplus6$ (T50019a)** | **THEOREM** | R-407 |
| Assembly $=F^{(6)}\ominus\mathrm{triv}$ (T50019) | CONDITIONAL — *flipped 2026-07-13: point/line seam CLOSED by T8 ($T_{\text{true}}$ lift, independently reproduced); now conditional ONLY on the fixed-class $b_8$ residual* | R-408 |
| Trit saturation | CONDITIONAL — *same flip: conditional only on $b_8$ (chart65 $Q_2$ locus certified; 504/1008-chart per REV5 T4/T12)* | R-409 |
| T8 point/line matrix-family lift ($T_{\text{true}}$) | CERTIFIED (IB) + independently reproduced [2026-07-13]; quoted at rank-equivalence level (witness-det basis difference recorded) | §D.7 note |
| Canonical key / $H_1$–$H_2$ orientation | RESOLVED [2026-07-13, REV5 T14]: $H_1=$ point, $H_2=$ line; arithmetic still-point separately certified (T13) | R-406 |
| Door uniqueness | THEOREM | R-410 |
| Hamiltonian-ladder probe | MEASURED, null | R-411 |
| Finite-label no-go ($\le\log_2 6$ bits/prime) | THEOREM (IB) | R-024 |
| Aion / de Branges bridge | **OPEN** | R-209 |

**Not claimed:** RH; GRH; Axiom L; any closure of the bridge; anything at rungs
other than the bottleneck; the $b_8$ residual before it is closed; anything from IB's
staged geometry-bridge chain before its integration.

---
*[Draft status v0.9, 2026-07-25 (was 2026-07-12). **Titles set** (ours, cite-able): the canonical-key
result is **The Still-Point Key Theorem** (§D.5, R-406), the door result is **The Door-Uniqueness
Criterion** (§D.8, R-410). The **$H_1$/$H_2$ orientation is RESOLVED** (2026-07-13, REV5 T14; §D.4
note) — the "IB owes symbol orientation" flag is retired. The (S)/(S′) sweep question is reframed by
REV5: **conditional only on the fixed-class $b_8$ residual** (§D.7 note), the one open computational
seam. Still genuinely awaiting: registry names/lines for §D.2–D.5, $b_8$ closure, and the staged
integration of IB's exact-$\mathbb Q$ bridge chain (2026-07-18→20). The e5 exact-arithmetic script and
the T50018 audit are in-repo and hashed. See the consolidated IB action ledger (register §F.6).]*


---

# Conclusion

---


## What this paper did

Four parts, one object, one discipline.

**Part I** built the map: a self-similar family of $L$-functions grown from one
group, $\mathrm{PSL}(2,7)$, through one field, and verified in range — conductors,
$\Gamma$-shapes, root numbers, zeros, and the scaling law that binds them to one
shell. **Part II** dissected the wall: two genuinely different roads — a de Branges
flow and a finite-level skeleton — arriving at the same obstruction, with the no-go
quantified: the envelope is reachable from finite geometry; the positions of the
zeros require the unbounded prime alphabet. **Part III** replaced measurement with
certificate: an envelope law with no fitted parameter, tested on 45 gaps across
degrees 1 through 8 and priced to a five-slot budget with one named open slot; and,
at its centre, $Q>0$ on $[0,3.2]$ for the genome at interval grade — the first
theorem-grade Laguerre certificate for a degree-8 Artin $L$-function — extended, as of
2026-07-19, by the **certified spectrum**: 152 ball-certified zero brackets on $[0,27.92]$
with certified Turing counts $N^+(5.969)=21$ / $N^+(6.55)=24$, among the brackets
$\gamma_{12}$: predicted by the passport density law alone, with no prime-side seed, and
found where the law said it would be; and by an unconditional pointwise $|S(t)|$ bound
that takes no zero-location input at all.
**Part IV** turned the finite cell's anatomy into dynamics: a certified ladder, one
proven door, a canonical key at the trit's still point, a hidden
sector in exact three-fold balance, and an assembly rule — three dark thirds and one
still point make the next rung — proven modulo one polynomial condition now under
sweep.

Beneath the results sits the method, and we regard it as a result in its own right
(Appendix E): every claim graded, every artifact hashed, every computation
independently rerun, both directions audited, errors caught and *kept* — the failed
clock-heat conjecture, the rung-climb that flooded, the null that voided our own
test. A paper of this kind is only as strong as its weakest ungraded sentence; we
have tried to leave none.

## The thesis, held to

> The envelope is geometric and self-similar; the line is arithmetic — and at
> derivative level the boundary between them is now an equation: the margin's floor
> is the shell's, its dips are the primes'. Beneath both, the finite machine that
> carries the flow has one door, one key, and a proven transition rule — and the
> wall stands exactly where it always did: at the passage from every rung to all of
> them.

Nothing in four parts moved the wall. That is not a failure of the program; it is
its central finding, sharpened until it became theorems: the Euler product is
necessary (§B.4), the wall is forced by the CM root (§B.5), no finite label spans it
(§D.8.2 — at most $\log_2 6$ bits per prime against an unbounded demand), and every
certificate in Part III is, by construction, finite. What changed is the ground in
front of the wall: it is now mapped, priced, certified, and equipped with a
mechanism whose behaviour at the boundary is exact.

## The ternary signature [PROPOSED — [R]]

One pattern runs through the finite machine unbidden. Time enters it as a ternary
clock; the clock's unique fixed point selects the key; the hidden sector behind the
door splits into three equal parts under that clock, by forced representation
theory; the clock's three steps alone reassemble the next rung; and the machine's
information ceiling is $\log_2 6$ bits per prime — the capacity of one trit and one
bit. None of this was designed in. Each item is a theorem, proved independently;
the pattern is their conjunction.

We therefore record, as a structural proposition graded [R] and claimed as nothing
more: **at its bottleneck, the finite machine computes in trits.** Whether the
ternary signature is an accident of $\mathrm{PSL}(2,7)$, a property of descent
bottlenecks generally, or something deeper, is a question for the program, not this
paper. It is falsifiable — other groups' ladders either show it or do not — and it
is registered as open.

## What remains

The honest forward ledger, in one place (dated flips from the v0.8 table marked):

| item | where it stands | register |
|---|---|---|
| (S)/(S′) sweep — closes the Assembly Theorem outright | *[flipped 2026-07-13]* point/line seam CLOSED (T8); now **conditional only on the fixed-class $b_8$ residual** | R-408/409 |
| Erdős–Turán window-tail slot — the one unpriced budget row | open; formulation IB's | R-311 |
| Registry closures CHI8-INTERVAL-1, ECL-FAMILY-1 | pending | R-313, R-307 |
| $\gamma_{13}$ and beyond ($\approx4.20$, pure prediction again); extended twin | *[closed 2026-07-15/19]* $\gamma_{13}$–$\gamma_{21}$ certified, then **superseded by the certified spectrum: 152 brackets to $t=27.92$** (§C.8.1b); extended twin still planned | R-107, R-009 |
| Bracket #144 ($t\approx26.45$) — the one uncertified location | numerical; certification pending | §C.8.1b |
| Lower-side swap-lemma for the $\lvert S(t)\rvert$ bound | flagged; IB confirmation pending | §C.8.3 |
| Far-wing global caustic majorant ($B_0=0.70$ a **working candidate**, not certified) | four-zone tiling structurally complete; two named items remain (uniform Olver/Debye seam remainder; head-scan interval upgrade) | operator ledger |
| IB's exact-$\mathbb Q$ geometry-bridge chain (19 packages, 2026-07-18→20) | received; **integration staged** ([v0.9 note] markers at §A.3, §D.7) | — |
| The bridge: Aion self-adjointness $\Leftrightarrow$ $|K_L|=1$ $\Leftrightarrow$ Weil/Li | **OPEN — the wall itself** (now formalized as R-011a conditional on (H); deficiency-$(0,0)$ open) | R-209 |
| The ternary signature on other ladders | open program question | — |

The wall's operator form is stated with precision — a one-way positivity that no
finite mechanism reaches — and the program's next instruments are named: the ledger
functionals that converge from below, the sweep that closes the last conditional,
and the family widened until the law either holds universally or breaks informatively.
Either outcome is a result; the register is built to record both.

## Closing

Riemann's Hypothesis is not claimed here, and was never the claim. What is claimed —
and graded, hashed, audited, and reproducible from the artifacts — is smaller and,
we believe, durable: **one family, mapped to its shell; one wall, proved to be
forced; one envelope, certified at derivative level to the edge of current reach;
one finite machine, with one door, one key, and an exact account of what it can
never say.** The boundary between the geometric and the arithmetic has been made,
in one corner of mathematics, an equation with a certificate on each side — and
every future claim against it, ours or anyone's, has a register waiting.

The wall stands. The ground in front of it is no longer dark.

## Coda — the conductor was never arbitrary

The number that names this world, $21 = 3\cdot 7$, is not a label but a compositum.
$\mathbb Q(\zeta_{21}) = \mathbb Q(\zeta_3)\cdot\mathbb Q(\zeta_7)$ is the smallest field holding
both cube and seventh roots of unity, and its two factors are **linearly disjoint** over
$\mathbb Q$ — $\mathbb Q(\zeta_3)\cap\mathbb Q(\zeta_7)=\mathbb Q$, because $3\nmid 7$ (Theorem
CYCLO, established earlier in the program). Those factors are the machine's two clocks wearing
their arithmetic names: $\mathbb Q(\zeta_3)=\mathbb Q(\sqrt{-3})$ is the Eisenstein field of the
**trit** — the ternary $\omega$ of §B.3 — and $\mathbb Q(\zeta_7)$ is the complex-multiplication
field of the Jacobian of the **Klein quartic**, the surface whose automorphism group is exactly
$\mathrm{PSL}(2,7)$, the genome's own group. The conductor is the marriage of the two clocks. $[T]$

The marriage is exact all the way down. The trit's $\omega$-grading on the Klein quartic's own
modules is the same grading it carries on the L-function: the **flow-facing** modules — the
holomorphic differentials $H^0(\Omega^1)=\chi_3$, and the 24 heptagons, which are precisely the
assembly target $F^{(6)}$ of §D.7 — are $\omega$-**balanced**, while the Eisenstein asymmetry sits
only strictly inside the descent, module for module as in the arithmetic Eisenstein census. And
the door itself is written in the trit's ring: the finite machine's assembly-failure locus
$Q_2 = b_5^2+b_5b_6+b_6^2-(b_7^2+b_7b_8+b_8^2)$ is a **difference of two Eisenstein norms** over
$\mathbb Z[\omega]$, namely $N(b_5-b_6\omega)-N(b_7-b_8\omega)$ — and this is no accident of one
class: the point-class quadric $Q_{H_1}$ is likewise an Eisenstein norm difference,
$N(b_5-b_7\omega)-N(b_6-b_8\omega)$ (REV5 reconciliation, 2026-07-13; §D.7 note), so the door is
written in $\mathbb Z[\omega]$ from both sides of the Fano duality. Geometry, machine, and conductor
are one $\mathbb Z[\omega]$ structure; the balance is the disjointness $3\nmid 7$, seen module by
module. $[C]$

That completeness is the point of the whole essay. Everything geometric is fixed — the family, the
shell, the machine, the door, down to the cyclotomic field itself — and **the line alone is not.**
The more exactly the determined side is pinned, the more starkly the zeros' positions stand out as
the single undetermined, arithmetic thing: the wall. The same coordinate says from which side a
proof would have to come — not the arithmetic L-function, which has the Euler product and lacks the
operator, but its geometric companion on the $\mathbb Q(\zeta_7)$ branch, where the Klein Jacobian's
complex multiplication supplies the self-adjoint origin the arithmetic side does not (§B.5). That
crossing is not made here. **The wall stands — but we can now see which cyclotomic wall it is, and
from which side the light would have to come.** Not RH.

---
*[Draft ends. The ternary-signature section carries its [PROPOSED] flag until IB
rules in markup; the forward-ledger table imports registry lines as they close. The coda's
cyclotomic bridge (Theorem CYCLO) is early joint program work — exact citation/attribution to be
fixed at freeze; only the rigorous bridge, census, and $Q_2\in\mathbb Z[\omega]$ are imported, not
any physics-corpus material (register scope rule R-021).]*


---

# References (indicative)

- S. Aramata, *Über die Teilbarkeit der Dedekindschen Zetafunktionen*, Proc. Imp. Acad. Tokyo **9** (1933); R. Brauer, *On the zeta-functions of algebraic number fields*, Amer. J. Math. **69** (1947).
- E. Artin, *Über eine neue Art von L-Reihen*, Abh. Math. Sem. Univ. Hamburg **3** (1923).
- A. Baker, *Transcendental Number Theory*, Cambridge Univ. Press (1975).
- I. Balashov, *The M75 registry: skeleton zeros, the buoy sign-count, and the Weil-positivity consolidation* (Theta–Hurwitz operator $\tilde M_N$, Theorem M74), OSF [10.17605/OSF.IO/3TFNY](https://doi.org/10.17605/OSF.IO/3TFNY) (2026).
- M. V. Berry, J. P. Keating, *The Riemann zeros and eigenvalue asymptotics*, SIAM Review **41** (1999).
- A. R. Booker, *Artin's conjecture, Turing's method, and the Riemann hypothesis*, Experiment. Math. **15** (2006) — §5 is the rescaled-FFT completeness architecture instantiated in §C.8.1b.
- E. Bombieri, *Remarks on Weil's quadratic functional in the theory of prime numbers*, Rend. Mat. Acc. Lincei (2000); A. Weil, *Sur les formules explicites...* (1952).
- L. de Branges, *Hilbert Spaces of Entire Functions*, Prentice-Hall (1968).
- J. B. Conrey, *More than two fifths of the zeros of the Riemann zeta function are on the critical line*, J. Reine Angew. Math. **399** (1989).
- H. Davenport, H. Heilbronn, *On the zeros of certain Dirichlet series*, J. London Math. Soc. **11** (1936).
- P. Deligne, *Hodge cycles on abelian varieties* (CM and Mumford–Tate), LNM **900** (1982).
- A. Dobner, *A Proof of Newman's Conjecture for the Extended Selberg Class*, arXiv:2005.05142 (2020).
- P. Erbach, J. Fischer, J. McKay, *Polynomials with PSL(2,7) as Galois group*, J. Number Theory **11** (1979).
- A. P. Guinand, *Summation formulae and self-reciprocal functions*, Quart. J. Math. **18** (1948); A. Weil, *Sur les "formules explicites" de la théorie des nombres premiers* (1952).
- N. Katz, P. Sarnak, *Random Matrices, Frobenius Eigenvalues, and Monodromy*, AMS Colloq. **45** (1999).
- F. Klein, *Über die Transformation siebenter Ordnung der elliptischen Funktionen*, Math. Ann. **14** (1879).
- N. Levinson, *More than one third of zeros of Riemann's zeta-function are on $\sigma=1/2$*, Adv. Math. **13** (1974).
- X.-J. Li, *The positivity of a sequence of numbers and the Riemann Hypothesis*, J. Number Theory **65** (1997).
- The LMFDB Collaboration, *The L-functions and Modular Forms Database*, [https://www.lmfdb.org](https://www.lmfdb.org) (2026); Artin representation [8.16679880978201.21t14.b.a](https://www.lmfdb.org/ArtinRepresentation/8.16679880978201.21t14.b.a).
- A. Odlyzko, *On the distribution of spacings between zeros of the zeta function*, Math. Comp. **48** (1987).
- N. Palojärvi, A. Zhao, *(explicit Turing-method bounds for L-functions in the Selberg class)*, arXiv:2508.03023 — Thm 2.3 supplies the certified Turing constant $B=57.89$ (§C.8.1b) and the integral $S$-bounds behind §C.8.3.
- B. Rodgers, T. Tao, *The de Bruijn–Newman constant is non-negative*, Forum Math. Pi **8** (2020).
- S. Stenberg, I. Balashov, *Exact Finite Sections of the Uniform-Normalization Operator* (Paper A of the operator trilogy), assembled draft 2026-07-25, in preparation; *An Operator from Density and Primes: the H = D + V Construction for the Conductor-21 L-Function* (Paper B), architecture 2026-07-23, in preparation; *The Aion Reformulation Lemma* (R-011a), program note 2026-07-14.
- J.-P. Serre, *Local Fields*, GTM **67**, Springer (1979).
- E. C. Titchmarsh, *The Theory of the Riemann Zeta-function*, 2nd ed. (Riemann–Siegel formula), Oxford Univ. Press (1986).

*Reproducible computations: the Fano-line resolvent and chirality classifier, the finite-cell
re-derivation (`_verify_cell_firstparty.py`), the conductor / tensor-tower / moment / Rankin–Selberg
verifications, the scaling-law density check, the void-pressure positivity on the genome's own zeros, the
Fourier-duality, and the no-go cost curve are described in the text and recoverable from the cited scripts.
The $\tilde M_N$ operator and Theorem M74 are in Balashov's OSF deposit; the $\chi_8$ analytic invariants are
catalogued in the LMFDB (Artin rep 8.16679880978201.21t14.b.a).*

---

## v0.9 upgrade-pass TODO (2026-07-25 — items NOT resolved in this pass, with why)

1. **IB geometry-zip integration (the 19-package exact-$\mathbb Q$ bridge chain, 2026-07-18→20)** —
   explicitly deferred by decision (2026-07-20); staged with [v0.9 note] markers at §A.3 and §D.7.
   Requires its own dedicated triage session (19 SHA verifications + filing + reconciliation note)
   before anything can be cited at certificate grade.
2. **Bracket #144 ($t\approx26.45$) certification** — a weak-amplitude zero at the enclosure floor;
   compute-bound, not editorial. Ordinals $\ge145$ stated modulo #144 wherever they appear.
3. **Lower-side swap-lemma for §C.8.3** — a proof-structure reading of PZ Thm 2.2/2.3 awaiting IB's
   confirmation; not ours to discharge unilaterally. Upper-side bounds are verbatim-theorem.
4. **K-modulus ledger extension onto the 152-atom certified spectrum** — staged; no computation
   exists yet, so §B.6.4/§C.8.2 keep the $m\le17$ ledger as computed (per no-overclaim discipline).
5. **$b_8$ residual closure** — the single open computational seam of the assembly program (§D.7
   note); IB's active front, not ours to close.
6. **T8 witness byte-match** — our reproduction certified T8 with different (valid) witness
   determinants; needs IB's `t50o10` sha to reconcile byte-for-byte; quoted at rank-equivalence
   level meanwhile.
7. **IB markup debts carried from v0.8, still open**: registry names for the §C.3.2 lemma stack and
   §D.2–D.5; ECL-FAMILY-1 and CHI8-INTERVAL-1 closure lines; the six tower-certificate names
   (§C.6); the §C.5 Erdős–Turán paragraph (his formulation).
8. **$B_0=0.70$ global caustic majorant** — deliberately left at WORKING_CANDIDATE grade
   (Conclusion ledger); two named far-wing items remain before any certified statement.
9. **Appendix F (claims register) formal re-issue as v0.9** — the register file already carries the
   REV5 flips (v0.11); a consolidated re-issue synchronized with this draft is a stage-4 task
   (figures, notation, bibliography polish likewise).
