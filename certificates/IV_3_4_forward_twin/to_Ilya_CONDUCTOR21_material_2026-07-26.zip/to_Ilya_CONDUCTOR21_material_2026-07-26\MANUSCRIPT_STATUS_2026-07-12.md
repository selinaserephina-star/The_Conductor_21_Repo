# Manuscript status — "From the χ₈ Certified Envelope to the Finite Transition Machine"

**2026-07-12 · updates the 07-08 snapshot with this week's work.** Register now **v0.8**.
Not claimed: RH, GRH — anywhere.

## Pieces (delta since 07-08 in **bold**)
| piece | file | state |
|---|---|---|
| Part I — The Map | `Conductor21_World_COMBINED.md` §A | stands; **χ₈ analytic base now externally anchored: LMFDB `8.16679880978201.21t14.b.a` (cond 21¹⁰, Γ_ℂ⁴, ε=+1) [R-002/R-101]** |
| Part II — The Anatomy of the Wall | `…COMBINED.md` §B | stands; **§B.7 M74 handshake upgraded "remains" → confirmed by computation (~1e-20); only IB's convention one-liner left [R-204]** |
| Part III — The Certified Envelope | `Paper_PartC_certified_envelope.md` | ~85%; **§C.8.1a now points to the new Appendix G (grading protocol)** |
| Part IV — The Finite Machine | `Paper_PartD_finite_machine.md` | ~90%; **titles set — §D.5 "The Still-Point Key Theorem", §D.8 "The Door-Uniqueness Criterion"; H₁/H₂ resolved intrinsically (IB owes only symbol orientation)** |
| Conclusion | `Paper_Conclusion.md` | ~95%; ternary signature still [PROPOSED] |
| **Appendix G — Grading protocol** | **`Paper_AppG_grading_protocol.md`** | **NEW: Axiom-L pre-registration, HIT/NEAR/MISS, two-channel rule, block-cutoff [R-115], γ₁₃–₁₇ scored** |
| Appendix E — Registry Protocol | — | IB writes (agreed 07-08) |
| Appendix F — Claims Register | `CLAIMS_REGISTER_DRAFT_2026-07-08.md` | **v0.8: +R-412 (constructive T7B′), +§F.6 IB action ledger, R-311 corrected, R-408 503-progress, R-101 LMFDB label** |

## Companion artifacts produced this week (not paper sections; feed the paper / IB)
- **Twin edge-tail audit** — `Ilya Riemanns/twin_gap20_audit_2026-07-12/` (certified, SHA'd):
  gaps 17/19/20 **close** on the edge-tail ledger; F_full precision-audited. [R-311]
- **chi7 zero-table extension** — `Ilya Riemanns/aws_zero_table_extensions_2026-07-11/` (certified, SHA'd). [R-109a]
- **503-chart Assembly progress** — `Ilya Riemanns/T50019_503chart_closure_progress_2026-07-12.md`:
  reduced to a structural corollary + IB's Q2-lock; primal tooling built/validated. [R-408/409]
- **AION reformulation checklist** — `PAPER/AION_reformulation_theorem_checklist_2026-07-12.md`.
- **AION edge document** — `PAPER/AION_the_edge_C1C3_open_problem_2026-07-12.md`: the frontier
  stated precisely (Hilbert–Pólya-for-χ₈ / existence-vs-positivity split / geometric-companion
  route / C2 ⋛ RH risk). *[Deep-thought thread — being carried to a separate session.]*

## Holes remaining — reclassified (what moved this week)
| # | hole (07-08) | status now |
|---|---|---|
| 1 | CHI8-INTERVAL-1, ECL-FAMILY-1 registry wording | **still IB** (we own material; his lines) — §F.6 |
| 2 | (S)/(S′) sweep verdict | **advanced our side**: reduced to structural corollary; IB computing the Q2-lock |
| 3 | M74 skeleton handshake | **closed our side** (computation); IB convention one-liner only |
| 4 | H₁/H₂ convention; canonical-key + door titles | **closed our side** (titles set, H₂ intrinsic); IB owes one-bit symbol orientation |
| 5 | Erdős–Turán formulation | **still IB**; note twin edge rows 17/19/20 now closed (Route B), residual list updated [R-311] |
| 6 | Appendix E text + container-hash case law | **still IB** |
| 7 | Ternary-signature ruling | **still [PROPOSED]** (IB veto welcome) |
| 8 | Register markup pass | **still IB** — consolidated in §F.6 |

**Net:** of the eight 07-08 holes, **two closed our side** (3, 4), **one advanced** (2); five
remain genuinely IB-shaped — all now consolidated in register **§F.6 (IB action ledger)**.

## Assembly pass (when IB's consolidated response lands — one session)
Unchanged from 07-08, plus: fold the twin-audit + 503-closure results into §C.5 / §D.7; add App. G
to the appendix lettering; thread the edge document's frontier statement into the Conclusion
(after the deep-thought session settles the reformulation-lemma write-up). Merge, reletter, freeze
title, regenerate .docx.

**Freeze TODOs (see `FREEZE_TODO_coda_cyclotomic_2026-07-12.md`):** the Conclusion now ends on a
new **Coda — "the conductor was never arbitrary"** (cyclotomic bridge). Before final freeze:
(1) confirm the CYCLO citation/provenance with Ilya (early joint work — attribution placeholder in
the coda + Klein note); (2) reconcile the coda's geometric-companion framing with the AION/edge
deep-thought thread. Neither blocks.

Not claimed: RH, GRH — anywhere.
