# Part IV — The Finite Machine: the Key, the Door, and the Ladder

**DRAFT v0.1 · 2026-07-08 · built register-upward (rows cited as [R-xxx]; grades per
the Claims Register). [TODO] marks items awaiting IB. Lettering note: this part's
sections are §D.x; the appendices currently labelled C/D will be relettered at
assembly to avoid collision. Not claimed anywhere in this part: RH, GRH, Axiom L.**

---

## §D.1 — Introduction: from anatomy to dynamics

Part II's §B.2 presented the finite cell as anatomy: the gate, the genome, the two
cones, the void operator. This part upgrades anatomy to **dynamics with theorems**.
The finite side of the operator road turns out to have a mechanical structure of its
own: a descent ladder with certified rungs, a unique **door** at one rung, a
canonical **key** selected by the trit, a proven partition of what lies
behind the door, and an assembly rule by which the hidden material — three dark
thirds and one still point — rebuilds the next rung of the ladder.

Every structural claim below is proven (character arithmetic, GAP, or exact rational
linear algebra) or certified, with one explicitly named conditional; the audit trail
is two-directional throughout. The interpretive layer — *why* a machine, *why* a
door — is confined to §D.9 and tagged [R]. What the machine can and cannot say about
the infinite flow is stated as a theorem, not a hope, in §D.8.

Throughout: $G=\mathrm{PSL}(2,7)$, $H$ an $S_4$ subgroup (two conjugacy classes:
point-stabilizers and plane-stabilizers of the Fano plane), $K=C_7{\rtimes}C_3$ the
Singer normalizer, $F$ a fixed 3-cycle — **the trit**, the distinguished order-3
element of the finite cell (§B.2/§B.3). Throughout this part the trit is used purely
as a group element; its temporal reading belongs to the interpretive layer (§D.9)
and to nothing here — and it is distinct, as always, from the canonical Aion flow.

---

## §D.2 — The Ladder: the Certified Descent Table

[R-401; joint — IB registry + character arithmetic, sympy-checked.]

The filtration ladder descends from the regular representation through fixed
permutation modules:

$$F^{(7)}=V_{\mathrm{reg}}\ (168)\;\to\;F^{(6)}=\mathbb Q[G/C_7]\ (24)\;\to\;
F^{(5)}=\mathbb Q[G/K]\ (8)\;\to\;F^{(4)}=\mathbb Q[G/S_4]\ (7)\;\to\;
F^{(3)}=\mathbb Q\ (1)\;\to\;0,$$

with dimension drops $[144,16,1,6,1]$ — **proven exact** by character arithmetic;
the ledger identity is $V_{\mathrm{reg}} \ominus (\text{descent})=\operatorname{coker}(\chi_6)$-side
bookkeeping carried in the registry. Two structural facts anchor everything below:

- $F^{(6)}=\mathbb Q[G/C_7]$, the 24-point Singer-coset permutation module, with
  $$F^{(6)}\;=\;\chi_1\oplus\chi_7\oplus 2\chi_8 .$$
  This decomposition is registry theorem **Th-157 [joint, GAP-verified, May 2026]**
  — proved seven weeks before the assembly theorem of §D.6 discovered what it is
  *for*.
- The discriminator $\operatorname{Hom}_G(\chi_8,\chi_7)=0$ resolves the Definition
  3.1 vs TQFT-table tension (two-row erratum recorded); the 49-candidate enumeration
  reconciles as the $\operatorname{Hom}\le2$ subset of the 202, all counts
  reverified. [T]

[TODO: IB's registry names for the descent-table entries.]

---

## §D.3 — The Throat

[R-402, R-405.]

### D.3.1 The object

At the $F^{(5)}\!\to\!F^{(4)}$ rung the descent is carried by a **throat map**: an
$H$-equivariant linear map from the Galois-completed throat module
$$V(25)\;=\;\mathbb Q[G/K]\;\oplus\;\operatorname{Ind}_K^G(W_2)\;\oplus\;\mathbb Q
\qquad(G\text{-content }2\chi_1\oplus\chi_7\oplus2\chi_8)$$
to the Fano permutation module $W(7)=\mathbb Q[G/H]$. Here $W_2$ is the rational
2-dimensional representation of $K/C_7$. The Hom-space is 9-dimensional (Reynolds
averaging over $H$; verified in exact rational arithmetic, dimension 9 on the nose
— `e5_turn_the_key.py`, in-repo). A throat of full rank 7 has an 18-dimensional
kernel: **the hidden sector**.

The torsor lemma **T7B′** [IB, repaired and constructive; R-402] supplies the
structural origin: the frame torsor forces the regular representation, and the
throat is its Galois completion.

### D.3.2 The finite lock theorem

> **Theorem T50018** [IB; THEOREM / AUDITED ✦; R-405]. $q=0$ and
> $\operatorname{rank}(A)=7\;\Rightarrow\;\operatorname{cyclicRank}(A)=8$ over
> $\mathbb Q$ — for every rank-7 throat map $A$, in both $S_4$ classes.
>
> *Proof: 1008 structural charts, Singular pipeline [IB]; independently audited
> (byte-verified package, deterministic rerun) [avatar]. Registry: [TODO: IB line].*

The name is earned: the throat cannot be turned by less than the full cyclic action
— a lock with a definite tumbler count.

---

## §D.4 — The Selector Chain: What the Trit Does and Does Not Do

[R-403, R-404; IB GAP chains T50015–17, audited.]

The naive conjecture — that the trit literally *is* a heat flow on the
throat (the "clock = heat" conjecture, strict form; the name is the conjecture's,
from the exploratory layer) — **fails**: T50015 is a proven negative, and
we keep it. What survives is sharper:

- **T50016/17**: the trit **transports** between conjugate throats and **selects**
  one $S_4$ class; the transport has identity monodromy — no Berry phase at
  Hom-level. Selection without dynamics: the trit does not flow, it *chooses*.
- The honest negative is load-bearing: it is what enforces the trit/Aion distinction
  of §B.3 empirically, and it redirected the bridge search from Hamiltonian mimicry
  to the ledger observables of §C.8/§D.8.

**Notation ($H_1$/$H_2$, resolved intrinsically).** The two $S_4$ classes of
$\mathrm{PSL}(2,7)\cong\mathrm{GL}(3,2)$ are the **point-stabilizers** and the
**plane-stabilizers** of the Fano plane (seven each, swapped by the outer automorphism /
Fano duality). The throat is stated $H_1$-equivariantly, and the canonical key is a
*point*-stabilizer — the stabilizer of the still point $p_0$ (§D.5) — so the natural
binding is $H_1=$ the point-stabilizer class (the throat's own class) and $H_2=$ the
plane-stabilizer class (its Fano-dual). The mathematics is fixed by our results (T50017
selects the class, trit-fixedness the member); IB owes only the **symbol orientation** — if
his convention names $H_2$ the other way, swap the two symbols throughout and nothing else
changes. *[IB: CONFIRM symbol orientation; registry lines for T50015–17 remain his.]*

---

## §D.5 — The Canonical Key at the Still Point

[R-406.]

The trit acts on the seven conjugates of $H$ within its class. The orbit structure
is $1+3+3$: **exactly one conjugate is trit-fixed** — per class, per trit. That
conjugate is $H^\*=\operatorname{stab}(p_0)$, the stabilizer of the trit's unique
fixed point $p_0$ on the Fano plane: the **still point of the Singer dial**.

> **The Still-Point Key Theorem** [T; R-406]. For each $S_4$ class, the trit fixes exactly
> one throat — the one anchored at the still point. The key is not chosen; it is the
> unique fixed point of the trit's action on the space of keys. The throat is thus
> **doubly canonical**: the transport selects the class (T50017), and trit-fixedness selects
> the unique member within it.
>
> *Verified in exact rational arithmetic (orbit count and stabilizer identification,
> `e5_turn_the_key.py`).*

---

## §D.6 — The Equipartition Theorem

[R-407; THEOREM ✦ (IB grade, 07-08); candidate registry name T50019a.]

> **Theorem (Equipartition).** Let $A:V(25)\to W(7)$ be ANY rank-7 $H$-equivariant
> throat map (either class), $F\in H$ the trit. Then the hidden sector decomposes
> under $F$ as
> $$\ker A\;=\;6\;\oplus\;6\;\oplus\;6\qquad(\text{eigenvalues }1,\ \omega,\ \omega^2)$$
> — perfect ternary equipartition, independent of the map, the chart, and the class.

*Proof.* (i) $A$ is $H$-equivariant and, at rank 7, surjective, so
$\ker A\cong V|_H\ominus W|_H$ as $H$-modules — the kernel's $H$-type is **forced**:
$\mathrm{sign}\oplus\mathrm{deg2}\oplus2\,\mathrm{std}^+\oplus3\,\mathrm{std}^-$
(point class; the plane class swaps the std multiplicities $2\leftrightarrow3$).
(ii) A 3-cycle's eigenvalue counts per $S_4$-irrep (character values $1,1,-1,0,0$ at
a 3-cycle): $\mathrm{triv}\to(1,0,0)$, $\mathrm{sign}\to(1,0,0)$,
$\mathrm{deg2}\to(0,1,1)$, $\mathrm{std}^\pm\to(1,1,1)$. (iii) Count:
$(1{+}0{+}2{+}3,\;0{+}1{+}2{+}3,\;0{+}1{+}2{+}3)=(6,6,6)$; the other class gives the
same totals. $\blacksquare$

Three remarks, each earned:

1. The balance is an exact conspiracy of the forced multiplicities: sign donates its
   whole dimension to the fixed space, deg2 entirely to $\omega\oplus\omega^2$, and
   the 3-dimensional types are individually balanced. Equipartition is a property of
   the **bottleneck rung's representation theory**, not of any key or map.
2. Each slice has dimension $6=\dim\chi_6$ — the ledger's returnable change (§B.2),
   now an unconditional identity rather than a numerical echo.
3. No sweep, no sample, no genericity: five lines of character arithmetic. It is the
   cheapest theorem in this paper and the one that closes the most questions.

---

## §D.7 — The Assembly Theorem, and the One Condition

[R-408, R-409; CONDITIONAL / SWEEP-IN-PROGRESS ✦; registry T50019.]

Write $V_{23}\subset V$ for the canonical $G$-isotypic $\chi_7\oplus2\chi_8$, and
let $K=\ker A$ for a rank-7 throat.

**Lemma 0** (the kernel avoids the trivial — proven). At rank 7 the trivial Schur
block is invertible; and at this rung — uniquely on the ladder, see §D.8 — the
$H$-trivial isotypic of $V$ equals the $G$-trivial $T_2$. Hence $K\subset V_{23}$.

**Lemma 2** (the $\chi_7$-part is automatic — proven). $K$ contains its forced
sign-isotypic component, and within $V_{23}$ the $H$-type sign occurs **only** in
$\chi_7$ ($\chi_7|_H=\mathrm{sign}\oplus\mathrm{std}^+\oplus\mathrm{std}^-$;
$\chi_8|_H=\mathrm{deg2}\oplus\mathrm{std}^+\oplus\mathrm{std}^-$). Since $\chi_7$
has $G$-multiplicity 1: $\langle G\cdot K\rangle\supseteq\chi_7$, unconditionally.

**The condition (S).** $\chi_8$ has $G$-multiplicity 2, with multiplicity space
$M\cong\mathbb Q^2$; let $U(A)\subseteq M$ be the span of the kernel's
$\chi_8$-multiplicity components. Condition (S): $U(A)=M$ — equivalently a specific
$2\times2$ minor is nonzero, a polynomial condition in the 9 Hom parameters,
extractable from the T50018 projector bases.

> **Theorem (Assembly; proven modulo (S)).** If $\operatorname{rank}(A)=7$ and (S)
> holds, then
> $$\langle G\cdot K\rangle\;=\;V_{23}\;=\;\chi_7\oplus2\chi_8\quad(\dim 23),$$
> and with the still-point marker line,
> $$\langle G\cdot K\rangle\;\oplus\;\mathbb Q_{\text{marker}}\;\cong\;F^{(6)}\;=\;
> \chi_1\oplus\chi_7\oplus2\chi_8 .$$
>
> *Proof.* $\langle G\cdot K\rangle$ is a $G$-submodule of $V_{23}$ (Lemma 0); its
> $\chi_7$-part is full (Lemma 2); its $\chi_8$-part is $\chi_8\otimes U(A)=
> \chi_8\otimes M$ under (S). $\blacksquare$

**Trit saturation** (measured; second condition (S′)). At the declared sample point,
$\Sigma=K+F{\cdot}K+F^2{\cdot}K$ equals $\langle G\cdot K\rangle$ (both 23-dim);
in general $\Sigma\subseteq\langle G\cdot K\rangle$ with equality iff a
triple-intersection determinant (S′) is nonzero. Under (S)+(S′), **the trit 3-cycle
alone performs the whole group's assembly**:

> three dark thirds and one still point make the next rung.

If (S) fails on some chart, the assembly there is $\chi_7\oplus(\chi_8\otimes
\text{line})$, dimension 15 — the theorem says exactly what degrades and by how
much. *Status (T50019-S″ FINAL, 2026-07-10): on **chart65 the assembly locus is now a
CERTIFIED theorem** — $\dim(K{+}FK{+}F^2K)=23 \iff Q_2(b)\neq0$ with
$Q_2=b_5^2{+}b_5b_6{+}b_6^2{-}b_7^2{-}b_7b_8{-}b_8^2$ (the Eisenstein exceptional
quadric), by exact Singular elimination over all five affine charts (principal ideal
$Q_2$ each, no residual component, matching 6/6 data). The universal Open2b and the
$\operatorname{rank}(M_{\mathrm{obs}})<15$ proxy are both **REFUTED** by explicit
rational witnesses; admissibility ($q=0$, $\operatorname{rank}A=7$) is **resolved with
no gap** (built into the chart65 construction). Remaining: the other **503 charts**
(Hidx$=2$ atlas) **OPEN but scope-reduced** — the setup depends only on Hidx, so $Q_2$
is expected shared, reducing the task to 503 cheap nonemptiness checks rather than
independent eliminations (Hidx$\neq2$ and the second $S_4$ class unverified).* Note the
target's decomposition is Th-157 (§D.2): the theorem assembles precisely the module the
joint registry catalogued in May.

---

## §D.8 — The Door Criterion, and the Ceiling

### D.8.1 One door

[R-410; proven.] Could the same mechanism — equivariant descent with a trit-selected
key and an assembling hidden sector — exist at other rungs? No:

> **The Door-Uniqueness Criterion** [T; R-410]. Marker separation — the $G$-closure of
> $\ker A$ avoiding the trivial line — holds **iff**
> $\operatorname{mult}_{\mathrm{triv}}(V|_H)\le\operatorname{mult}_{\mathrm{triv}}(W|_H)$
> at the rung's stabilizer, and on this ladder that holds **only** at the
> $F^{(5)}\!\to\!F^{(4)}$ bottleneck — where the target is $\mathbb Q[G/S_4]$, the
> $\chi_6$ ledger-change appears, and the trit selects. Above it, the descent is
> rigid certified $G$-descent with no hidden sector to hide anything in.

The criterion was found the honest way: a rung-climb attempt *failed* (the closure
flooded to 169 — $G$-averaging drags in trivial mass), and the failure, pursued,
became the uniqueness proof. The ladder has one door. [T]

### D.8.2 The ceiling, stated as a theorem

What can the finite machine say about the infinite flow? Two results bound the
bridge honestly:

- **The Hamiltonian-ladder probe is null** [R-411; M, negative]. Under declared
  tests with synthetic-null controls, ladder-derived Hamiltonians are
  edge-dominated: no spectral correspondence with the zero field survives its null.
  The probe's methodological yield: the correct finite$\to$infinite observables are
  the **ledger functionals** (power sums, Hankel margins, Li partials — §C.8), which
  weight small zeros dominantly and converge from below.
- **The finite-label no-go** [R-024; THEOREM, IB]. Finite class data carries at most
  $\log_2 6$ bits per prime, while RH-grade control is unbounded: **no finite label
  can span the wall.** The machine of this part therefore cannot, even in principle,
  close the bridge by itself — and the paper says so as a theorem, not as a
  concession.

The bridge itself — canonical Aion self-adjointness $\Leftrightarrow$ $|K_L|=1$
$\Leftrightarrow$ Weil/Li positivity — remains **OPEN** [R-209], as it must: it is
the wall of Part II in operator dress.

---

## §D.9 — What the Machine Means (interpretive; [R])

Confined to one section, tagged, and brief. The finite machine is the program's
answer to *where the structure lives*: the genome's cell is not an inert lookup
table but a mechanism — a lock (T50018), a key selected by time's own fixed point
(§D.5), a hidden sector in perfect ternary balance (§D.6), and an assembly rule that
rebuilds the ladder's next rung from what the throat hides (§D.7). The suggestive
chain — the clock selects, the key opens, the dark thirds assemble — is structural
fact; the *reading* of it as the finite shadow of the infinite flow's balance is
interpretation and is claimed as nothing more. The theorems stand without the
reading; the reading, without the theorems, would be poetry. We keep both, labelled.

---

## §D.10 — Honest Ledger (Part IV)

| Claim | Grade | Register |
|---|---|---|
| Descent table, drops $[144,16,1,6,1]$; $F^{(6)}=\chi_1\oplus\chi_7\oplus2\chi_8$ (Th-157) | THEOREM | R-401 |
| T7B′ torsor $\Rightarrow$ regular rep | THEOREM (IB) | R-402 |
| **T50018: rank 7 $\Rightarrow$ cyclic rank 8 (finite lock)** | **THEOREM / AUDITED** | R-405 |
| T50015 strict clock=heat | proven NEGATIVE (kept) | R-403 |
| T50016/17 trit transport + class selection, identity monodromy | THEOREM (IB, GAP) | R-404 |
| Canonical key (1+3+3, still point) | THEOREM | R-406 |
| **Equipartition $6\oplus6\oplus6$ (T50019a)** | **THEOREM** | R-407 |
| Assembly $=F^{(6)}\ominus\mathrm{triv}$ (T50019) | CONDITIONAL on (S); sweep in progress | R-408 |
| Trit saturation | CONDITIONAL on (S′); sweep in progress | R-409 |
| Door uniqueness | THEOREM | R-410 |
| Hamiltonian-ladder probe | MEASURED, null | R-411 |
| Finite-label no-go ($\le\log_2 6$ bits/prime) | THEOREM (IB) | R-024 |
| Aion / de Branges bridge | **OPEN** | R-209 |

**Not claimed:** RH; GRH; Axiom L; any closure of the bridge; anything at rungs
other than the bottleneck; (S)/(S′) before the sweep says so.

---
*[Draft status 2026-07-12. **Titles set** (ours, cite-able): the canonical-key result is
**The Still-Point Key Theorem** (§D.5, R-406), the door result is **The Door-Uniqueness
Criterion** (§D.8, R-410). The **$H_1$/$H_2$ notation is resolved intrinsically** (§D.5 note):
$H_1=$ point-stabilizer / throat class, $H_2=$ plane-stabilizer / Fano-dual — IB owes only the
symbol orientation, not the mathematics. Still genuinely awaiting IB: registry names/lines for
§D.2–D.5 and the **(S)/(S′) sweep verdict** on the remaining 503 charts. The e5
exact-arithmetic script and the T50018 audit are in-repo and hashed. See the consolidated IB
action ledger (register §D.6).]*
