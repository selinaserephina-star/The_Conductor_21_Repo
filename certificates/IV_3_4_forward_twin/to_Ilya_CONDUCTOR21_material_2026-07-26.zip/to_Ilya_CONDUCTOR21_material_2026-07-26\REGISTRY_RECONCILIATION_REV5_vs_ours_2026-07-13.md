# Reconciliation — Ilya's Scar/Merkabit Registry REV5 (T8 CERTIFIED) ↔ our Claims Register v0.8

**Merkabit Research · 2026-07-13 · Stenberg + Claude.** Maps Ilya's REV5 T50019 registry
(`Scar_Merkabit_Theorem_Registry_REV5_T8_CERTIFIED_2026-07-13`) onto our joint-paper claims
register, records the status changes his closures produce, and folds in three corrections he made.
His registry is the **Scar/Merkabit T50019 program** registry (his T#/B#/R# numbering); ours is the
**joint-paper** register (R-#). They are adjacent and overlap on the assembly / door / census /
Perlis rows. Not RH/GRH.

## Crosswalk (his → ours) and status
| His REV5 | statement | his grade | our row | reconciled note |
|---|---|---|---|---|
| **T1** | Assembly dim identity `dim𝒜 = 8+r_E` (admissible) | PROVEN | R-408 | underlies our Assembly Theorem |
| **T3** | Hidx=2 assembly law `Q₂≠0 ⟺ dim𝒜=23` | CONDITIONAL (on b8) | **R-409** | our chart65 = his **Hidx=2 = LINE = H₂**; our `Q₂` = his `Q_H2` |
| **T4** | shared-obstruction transport over 504 charts (E built before chart loop) | LOGICALLY PROVEN | **R-408** | **this is exactly our structural argument** — he grades it proven; closure blocked by b8 |
| **T7** | Hidx1/Hidx2 quadric equiv `Q_H1(b5,b6,b7,b8)=Q_H2(b5,b7,b6,b8)` | PROVEN (quadric only) | R-409 | **scope correction:** the raw b6↔b7 swap is a *quadric* identity only, **not** a B/E lift |
| **T8** | point/line B/E matrix-family lift via `T_true` | CERTIFIED (session) | **R-408 (new)** | **closes our flagged "second S₄ class" gap**; we independently reproduced it (see below) |
| **T9** | Door Module Identity `F(6)≅χ₁⊕𝒜`, Δω table (F5:+2, F4:+1, F6:0, 𝒜:−1) | VERIFIED | R-407 + Klein census | **identical to our Klein/E7 Eisenstein census** |
| **T10** | Marker-side door selection | PROVEN | **R-410** | our Door-Uniqueness Criterion |
| **T11** | DSE chart65 `M⟺I` | PROVEN mod trit-saturation | R-408/409 | — |
| **T12** | atlas transport of DSE (504 → 1008) | CONDITIONAL on b8 only | R-408 | **1008-chart now conditional only on fixed-class b8** |
| **T13** | Arithmetic still-point (Trinks `1+3+3` at 3, total ram at 7, inertia) | CERTIFIED | R-002/R-406 | new exact maximal-order result |
| **T14** | Perlis–Gassmann point/line resolution + still-point bridge | PROVEN/CERTIFIED | **R-406** | discharges the H₂ question — see corrections |
| **B1** | trit census of irreducibles (χ₁:+1, χ₇:+1, χ₈:−1; χ₃/χ̄₃/χ₆:0) | VERIFIED | Klein census | identical to our irreducible census (E7-O2 Born chain) |
| **B2** | Weyl/Lefschetz cancellation `Σdim(ρ)χ_ρ(F)=1+7−8=0`, `#Fix(F)=2` | THEOREM-GRADE | Klein census | our regular-rep-trace-0 check |
| **R1** | `Q₂` as de Branges canonical-system singular support | **READING** | **coda** | he grades it READING until the canonical system is built — **consistent with our coda's honest framing** |

## Status changes this produces in OUR register
1. **R-406 (canonical key / H₂) — H₂ DISCHARGED.** His T14c + our Perlis note agree: **H₁ = point,
   H₂ = line.** The arithmetic/canonical-key bridge lands on the **point class H₁** (T500 convention:
   `Hstar=stab(p0)`); the locked **chart65 / Hidx=2 realization is the outer-dual line class H₂**.
   The "IB owes symbol orientation" flag is removed — but see correction (1) below on *how* to state
   it.
2. **R-408 (Assembly Theorem) — point/line seam CLOSED.** His **T8** (`T_true ∈ GL₄(ℚ)` B/E
   matrix-family lift, residual ranks all 0), which **we independently reproduced 2026-07-13**
   (FINAL_T8_STATUS=CERTIFIED), closes our flagged "second S₄ class" gap — and stronger than
   chart-by-chart. Per his T4/T12, the **504-chart (fixed class) and 1008-chart (both classes)
   assembly/DSE are now conditional ONLY on the fixed-class `b8` residual.**
3. **The single remaining open seam is `b8`** (his §3.L2, §8): the `b8=1` chart is **NONUNIT after 27
   residuals** (Gröbner length 63, residual dim 1); the rank-B exclusion shortcut is **REFUTED**
   (witness minor cols [8,9,10,11,12]); an **admissible b8 residual is certified to exist**. So the
   assembly is *not* fully closed — record R-408/409 as conditional on b8, not "certified all charts."
4. **R-409 (chart65 Q₂)** — consistent with his T3. Note our `Q₂` is the **line-class (H₂)** quadric;
   the point class has `Q_H1 = b5²−b6²+b5b7+b7²−b6b8−b8²` (the b6↔b7 swap). **Both are Eisenstein
   norm differences over ℤ[ω]** (`Q_H1 = N(b5−b7ω) − N(b6−b8ω)`), so the coda's `Q₂∈ℤ[ω]` point holds
   for both classes.

## Three corrections to fold in (his REV5 makes them)
- **(1) Perlis over-claim — CORRECT IT.** Do **not** write "nothing arithmetic distinguishes
  point/line" or "same ramification follows from equal zeta" (my 07-13 message and the source Perlis
  note used the strong form). His T14a: arithmetic equivalence does **not** force equal ramification
  indices at ramified primes (Mantilla-Soler). **Allowed:** the two resolvents are a Gassmann pair →
  equal Dedekind zeta; **zeta and residue-degree data cannot select the point/line label**; the
  `1+3+3` at 3 and total ram at 7 are **separately certified** by his T13 maximal-order computation,
  not derived from equal zeta. Use this form everywhere (coda provenance, Klein note, R-406).
- **(2) T7 scope.** The raw `b6↔b7` swap is a **quadric identity only** — not the B/E family
  symmetry. The actual family map is **`T_true`** (T8). Don't call the swap the point/line symmetry.
- **(3) det reconciliation (our T8 rerun).** Our independent reproduction certified T8 but with
  **different witness determinants** (ours det C5 = det T_true = −81/6400; his det C5 = −81/800,
  det T_true = −81/1600) — a basis difference (different `t50o10_defs_only.g`; his bundle ships none
  to compare, ours sha `816612d2…`). Same theorem, different valid witness. **Ask Ilya for his
  CoCalc `t50o10` sha** to match witnesses byte-for-byte, or state T8 at rank-equivalence level where
  the det is immaterial. (Details: `Ilya Riemanns/T8_independent_reproduction_2026-07-13/`.)

## Not-yet items (his, that touch our paper)
- **b8 closure** is the one open computational seam gating the whole assembly (his §10.1).
- His **R1** keeps "Q₂ = de Branges singular support" at **READING** — our coda must stay at reading
  grade on that point (it does: the coda states the door *is written in* ℤ[ω]; it does not claim the
  canonical-system identification, which is R1/open).

## Post-REV5 additions to our register (2026-07-15) — for IB review

Three exploration-derived reference points (from `new_direction_exploration\`) were added to the claims
register (v0.11) and folded into the paper. These are **not** REV5 items — they are new ours-side
(Stenberg + Claude), IB-review pending — recorded here so this sync sheet stays current:

- **R-025 — local Euler-detector (Kronecker) + Euler-necessity split.** Corrects the §B.4.2 "rank-1, PSD"
  phrasing: the general invariant is **Kronecker rank $=$ degree**; positivity is degree-1-specific
  (genuine degree $\ge2$ factors — Ramanujan's τ, χ₈'s own — are indefinite). *For IB:* verify the τ
  counterexample and the rank-form, and grade whether it belongs in §B.4.2 as a caveat or a full sub-lemma.
- **R-026 — Λ(χ₈) ≥ 0 is a theorem (Dobner 2020).** χ₈ ∈ extended Selberg class 𝒮♯ (via the Born/
  Rankin–Selberg factorization, R-003), and Dobner proves Λ_F ≥ 0 for all of 𝒮♯ — so §B.10.2's fifth
  dialect upgrades from a ζ-transfer to a genuine χ₈ theorem (genome at parity with ζ). *For IB:* confirm
  the 𝒮♯ membership statement and the citation replaces "[T for ζ; transfer R]".
- **R-027 — companion density mismatch.** §B.4.4's Selberg-zeta companion has Weyl density ~T² vs
  L(χ₈)'s ~T log T; the Hilbert–Pólya vehicle is Berry–Keating $\hat x\hat p$, not the Laplacian.
  *For IB:* verdict on stating this as the quantitative reason the twin's operator can't be imported.

Paper edits applied: §B.4.2 (caveat), §B.10.2 (Dobner), §B.4.4 (density), + Dobner reference. Not RH/GRH.

— Selina + Claude, 2026-07-13 (post-REV5 note appended 2026-07-15)
