# AION reformulation → theorem: a rigor checklist

**Merkabit Research · 2026-07-12 · Stenberg + Claude.** Scoping what it takes to turn the
AION equivalence (Part II §B.3/§B.6) from paper-grade into a theorem — and, honestly, which
parts are bounded citation work and which are the genuinely hard novel content. **Not RH/GRH.**

## The target, stated precisely
The reformulation is the chain (§B.3.3, §B.6.2)
```
𝒜 self-adjoint  ⇔  E Hermite–Biehler  ⇔  H(t) ⪰ 0 ∀t  ⇔  |K_L|=1 only on Re(s)=½  ⇔  λ_n ≥ 0 ∀n  ⇔  GRH(χ₈).
```
Two very different things get called "making the AION a theorem," and the checklist's whole
job is to keep them apart:

- **Level A — the equivalence** ("*if* the AION 𝒜 for χ₈ exists and represents Λ(s,χ₈), *then*
  self-adjoint ⇔ GRH"). This is a reformulation; proving it does **not** prove RH.
- **Level B — self-adjointness / global positivity** (`H(t)⪰0 ∀t`). This **is** GRH — the wall.
  Explicitly out of scope; the paper says so ("global purity is the survival (RH)", §B.6.3).

This checklist is entirely about **Level A**, and it splits Level A into a cheap half (citeable
de Branges theory) and a hard half (the χ₈-specific forward construction).

## The links, tagged

| # | link | status in the paper | what "theorem-grade" needs |
|---|---|---|---|
| L1 | de Branges representation exists for a self-dual Selberg-class L that *admits* one | `[T]` framework (§B.3.3) | cite; verify χ₈ meets the admitting hypotheses (self-dual ✓, Selberg class — needs the standard checklist for this Artin L) |
| L2 | Hermite–Biehler ⇔ `H(t)⪰0` ⇔ `|E*|<|E|` in UHP ⇔ zeros on line | `[T]` (§B.6.2) | cite; **matrix case** (degree 8, Γ_ℂ⁴): the de Branges theory here is **matrix-valued** — verify the matrix Hermite–Biehler / de Branges-space statements, not the scalar ones |
| L3 | `|K_L|=1 ⇔ Re(s)=½` (purity), `K_L=E⁻¹E*` | `[T; RH-equivalent]` (§B.6.2) | cite; for χ₈ this is **unitarity of an 8-dim scattering matrix** (Schur form) — the matrix purity statement must be stated and proven, not the degree-1 scalar one |
| L4 | `|K_L|=1` (purity) ⇔ Weil/Li `λ_n≥0` ⇔ GRH | asserted in the master chain (§B.3.2, line 815–818) | the `K_L ↔ λ_n` analytic bridge for a **matrix** structure function needs to be written out and certified (this is the one analytic link that isn't just "cite de Branges") |
| L5 | local purity: Satake params roots of unity, Ramanujan automatic (Artin) | `[T]` free (§B.6.3) | cite — genuinely done; per-prime modulus-1 is a theorem |

**Level-A verdict:** L1–L3 and L5 are **standard de Branges / Artin theory** — theorem-grade is a
*careful citation + hypothesis-verification pass*, with the one real subtlety that everything is
**matrix-valued (8×8 Schur)**, not the textbook scalar case, so the matrix versions of the
statements must be invoked/checked. L4 (the `K_L ↔ Li` bridge in the matrix setting) is the one
link that needs actual writing. This half is **bounded** — call it the "reformulation lemma."

## The crux — the forward construction (the hard, novel half of Level A)
The equivalence above is **about an object 𝒜 that must first be shown to exist and to be the
right one.** The paper is explicit (§B.3.3, line 988): *"the specific Hamiltonian seeded by the
cell of §B.2 is the construction proposed here"* — i.e. **proposed, not proven.** For the
reformulation to be a theorem *about χ₈* (not about a hypothetical system), three things must be
established, and they are the real content:

- **C1 — existence.** A canonical system `H(t)⪰0` on `[0,∞)`, finite matrix cell at each `t`,
  built **forward from the §B.2 cell + gate** (the arithmetic), with an entire matrix structure
  function `E`.
- **C2 — faithfulness.** `Λ(s,χ₈)` is exactly the symmetric part of that `E` (the system
  represents *this* L-function, with the right functional equation and zero set).
- **C3 — the circularity guard (non-negotiable).** `H(t)` must be constructed from the cell and
  gate, **not from the zero list** (§B.3, line 1020–1023). An operator built from the zeros
  reproduces them trivially and proves nothing; the entire content is a *forward* build "without
  knowing where its spectrum will fall."

**Honest difficulty read.** C1–C3 are **not** a bounded citation pass. A forward, zero-free
construction of a canonical system whose spectrum is the χ₈ zeros is essentially *constructing a
Hilbert–Pólya operator for χ₈ from arithmetic* — the same order of difficulty as the problem the
whole program orbits. It may be genuinely hard or open. The checklist's value is to say this
plainly: **Level-A-minus-crux is bounded; Level-A-with-crux is not obviously bounded.**

## Out of scope (the wall)
`H(t)⪰0 for all t` / global purity survival / `λ_n≥0 ∀n` = **GRH(χ₈)** (§B.6.3, line 1294). No
finite work reaches it. Do not spend effort here.

## Already in-range (evidence, not theorem)
- K-modulus positivity on χ₈'s **own** zeros through **m=17** (Hankel ledger, §B.6.4; R-206) —
  finite, in-range, CERTIFIED-FINITE.
- Li/Weil `Re(λ_n)` positivity in range.
These support the *plausibility* of the wall's positivity; they are not the reformulation theorem.

## Recommended sequencing
1. **Write the "reformulation lemma"** (L1–L5, matrix-valued): a clean statement + proof that,
   *given* a matrix de Branges canonical system representing Λ(s,χ₈), self-adjointness ⇔ 8-dim
   Schur unitarity on the line ⇔ Li-positivity ⇔ GRH. This is bounded, citeable, and a genuine
   theorem — it just isn't a proof of RH. **Do this first; it's real and finishable.**
2. **State C1–C3 as the open construction problem**, with the circularity guard front and centre,
   and record the in-range evidence (m=17 ledger) beside it as motivation. Do **not** claim it.
3. Register: this would refine **R-011** (construction, paper-grade → split into the
   reformulation-lemma [provable] and the forward-construction [open]) and leave **R-209** (the
   wall) exactly as OPEN.

**Bottom line.** The AION *reformulation lemma* (Level A minus the forward construction) is a real,
bounded theorem worth writing — it sharpens the paper's Part II. The AION *as a realized operator
for χ₈* (C1–C3) is the hard novel content and may be open. The AION *self-adjoint* (Level B) is RH.
Owning the operator does not shortcut any of these — but it does make the first one writable.

— Selina + Claude, 2026-07-12
