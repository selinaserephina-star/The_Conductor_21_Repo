# Conclusion

**DRAFT v0.1 · 2026-07-08 · closes the four parts; built register-upward. The ternary
signature is [PROPOSED — IB veto welcome]. Not claimed: RH, GRH, Axiom L.**

---

## What this paper did

Four parts, one object, one discipline.

**Part I** built the map: a self-similar family of $L$-functions grown from one
group, $\mathrm{PSL}(2,7)$, through one field, and verified in range — conductors,
$\Gamma$-shapes, root numbers, zeros, and the scaling law that binds them to one
shell. **Part II** dissected the wall: two genuinely different roads — a de Branges
flow and a finite-level skeleton — arriving at the same obstruction, with the no-go
quantified: the envelope is reachable from finite geometry; the positions of the
zeros require the unbounded prime alphabet. **Part III** replaced measurement with
certificate: an envelope law with no fitted parameter, tested on 45 gaps across
degrees 1 through 8 and priced to a five-slot budget with one named open slot; and,
at its centre, $Q>0$ on $[0,3.2]$ for the genome at interval grade — the first
theorem-grade Laguerre certificate for a degree-8 Artin $L$-function — extended by
twelve certified zeros, among them $\gamma_{12}$: predicted by the passport density
law alone, with no prime-side seed, and found where the law said it would be.
**Part IV** turned the finite cell's anatomy into dynamics: a certified ladder, one
proven door, a canonical key at the trit's still point, a hidden
sector in exact three-fold balance, and an assembly rule — three dark thirds and one
still point make the next rung — proven modulo one polynomial condition now under
sweep.

Beneath the results sits the method, and we regard it as a result in its own right
(Appendix C): every claim graded, every artifact hashed, every computation
independently rerun, both directions audited, errors caught and *kept* — the failed
clock-heat conjecture, the rung-climb that flooded, the null that voided our own
test. A paper of this kind is only as strong as its weakest ungraded sentence; we
have tried to leave none.

## The thesis, held to

> The envelope is geometric and self-similar; the line is arithmetic — and at
> derivative level the boundary between them is now an equation: the margin's floor
> is the shell's, its dips are the primes'. Beneath both, the finite machine that
> carries the flow has one door, one key, and a proven transition rule — and the
> wall stands exactly where it always did: at the passage from every rung to all of
> them.

Nothing in four parts moved the wall. That is not a failure of the program; it is
its central finding, sharpened until it became theorems: the Euler product is
necessary (§B.4), the wall is forced by the CM root (§B.5), no finite label spans it
(§D.8.2 — at most $\log_2 6$ bits per prime against an unbounded demand), and every
certificate in Part III is, by construction, finite. What changed is the ground in
front of the wall: it is now mapped, priced, certified, and equipped with a
mechanism whose behaviour at the boundary is exact.

## The ternary signature [PROPOSED — [R]]

One pattern runs through the finite machine unbidden. Time enters it as a ternary
clock; the clock's unique fixed point selects the key; the hidden sector behind the
door splits into three equal parts under that clock, by forced representation
theory; the clock's three steps alone reassemble the next rung; and the machine's
information ceiling is $\log_2 6$ bits per prime — the capacity of one trit and one
bit. None of this was designed in. Each item is a theorem, proved independently;
the pattern is their conjunction.

We therefore record, as a structural proposition graded [R] and claimed as nothing
more: **at its bottleneck, the finite machine computes in trits.** Whether the
ternary signature is an accident of $\mathrm{PSL}(2,7)$, a property of descent
bottlenecks generally, or something deeper, is a question for the program, not this
paper. It is falsifiable — other groups' ladders either show it or do not — and it
is registered as open.

## What remains

The honest forward ledger, in one place:

| item | where it stands | register |
|---|---|---|
| (S)/(S′) sweep — closes the Assembly Theorem outright | in progress (Route C CEGAR) | R-408/409 |
| Erdős–Turán window-tail slot — the one unpriced budget row | open; formulation IB's | R-311 |
| Registry closures CHI8-INTERVAL-1, ECL-FAMILY-1 | pending | R-313, R-307 |
| $\gamma_{13}$ and beyond ($\approx4.20$, pure prediction again); extended twin | compute-bound (planned) | R-107, R-009 |
| The bridge: Aion self-adjointness $\Leftrightarrow$ $|K_L|=1$ $\Leftrightarrow$ Weil/Li | **OPEN — the wall itself** | R-209 |
| The ternary signature on other ladders | open program question | — |

The wall's operator form is stated with precision — a one-way positivity that no
finite mechanism reaches — and the program's next instruments are named: the ledger
functionals that converge from below, the sweep that closes the last conditional,
and the family widened until the law either holds universally or breaks informatively.
Either outcome is a result; the register is built to record both.

## Closing

Riemann's Hypothesis is not claimed here, and was never the claim. What is claimed —
and graded, hashed, audited, and reproducible from the artifacts — is smaller and,
we believe, durable: **one family, mapped to its shell; one wall, proved to be
forced; one envelope, certified at derivative level to the edge of current reach;
one finite machine, with one door, one key, and an exact account of what it can
never say.** The boundary between the geometric and the arithmetic has been made,
in one corner of mathematics, an equation with a certificate on each side — and
every future claim against it, ours or anyone's, has a register waiting.

The wall stands. The ground in front of it is no longer dark.

---
*[Draft ends. The ternary-signature section carries its [PROPOSED] flag until IB
rules in markup; the forward-ledger table imports registry lines as they close.]*
