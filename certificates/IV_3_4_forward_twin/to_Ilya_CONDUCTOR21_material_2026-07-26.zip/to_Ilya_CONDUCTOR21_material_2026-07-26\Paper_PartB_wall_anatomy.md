# Part II — The Anatomy of the Wall

*Riemann's Hypothesis for the genome L-function as a finite cell carried by an infinite flow.*

---

## §B.1 — Introduction

Part I assembled the six Artin L-functions of $G=\mathrm{PSL}(2,7)$ at conductor $21$ — together with
their CM twins — into a single object: a finitely-generated, self-similar family, every member exhibited
on the critical line in range, every structural invariant (degree, conductor, gamma factor, sign, the
fusion algebra, the scaling exponent) fixed by the pair $(G,K)$ of the group and the Trinks field. The
family was shown to be the tensor tower of one cuspidal representation, the quark $\chi_3$, with the
genome $\chi_8=|\chi_3|^2-1$ its squared intensity. The closing thesis of Part I was a dichotomy: *every
geometric feature is determined and self-similar; the single feature the structure does not fix is that
the zeros lie on $\mathrm{Re}(s)=\tfrac12$.*

Part II is about that single feature, for the distinguished member $\chi_8$. We ask the only question
Part I left open: **where, precisely, does the Riemann Hypothesis live for this object, and what can be
proved around it?** We state at once that **we do not prove RH.** What we do is *anatomize the wall* —
exhibit, for one explicit L-function, the complete structure surrounding its Riemann Hypothesis, separate
everything that is proved or forced from the one statement that is open, and give that statement in
several equivalent forms. The result is not a theorem toward RH but a localization: the sharpest
available account of where, and only where, the difficulty lies.

### A finite cell carried by an infinite flow

One tension organizes the whole anatomy, and resolving it is the spine of Part II.

The machine that generates $\chi_8$ is **finite**. The group $G$ has order $168$; the Frobenius datum at
each prime is one of six conjugacy classes; the genome $a_p=\chi_8(\mathrm{Frob}_p)$ takes values in the
finite alphabet $\{8,0,-1,1\}$. The algebra is finite too: the imaginary octonion units are the Fano
matroid $F_7=\mathrm{PG}(2,2)$, and their Cayley–Dickson doubling — the sedenion, the dark cone — is
$\mathrm{PG}(3,2)$, exactly fifteen Fano planes. The associated "void operator'' is an explicit
self-adjoint matrix with a known characteristic polynomial, and it carries an exact sum-of-squares
positivity. There is nothing infinite, or even large, in the apparatus.

Yet RH is irreducibly a statement about the **infinitely many primes** — through the explicit formula,
the zeros are determined by the infinite sum $\sum_p a_p\,(\log p)\,p^{-s}$, and the prime alphabet
$\{\log p\}$ is linearly independent over $\mathbb Q$ (Baker), an infinite-rank structure. A naive
no-go follows: a finite operator has finite rank and cannot reproduce $\{\log p\}$; the operator route
to RH appears closed.

The resolution — and it is the de Branges picture, reached here from the arithmetic — is that the
operator attached to $\chi_8$ is **not a finite matrix but a finite cell carried by an infinite flow**:
a canonical system $H(t)$, $t\in[0,\infty)$, whose Hamiltonian is a finite cell at each instant and whose
*variation along the flow* encodes the primes. No single instant holds $\{\log p\}$; the unending run
does. The finite, self-dual, closing clock of the machine is *unwound* into this flow by the
time-reversal arrow (the chirality $K\neq 0$), and it never closes because the trit (order $3$) and the
Singer cycle (order $7$) are coprime — the holonomy $z_3\,\sigma\,z_3^{-1}=\sigma^r$ ($r\in\{2,4\}$, $r^3\equiv1$) never returns to
its start. The flow is aperiodic, hence infinite. In this language the Riemann Hypothesis acquires its
sharpest form:

> **RH for $\chi_8$ is the statement that the cell's exact, finite positivity survives the infinite,
> never-closing flow.**

The finiteness Part II establishes is real and it is the *entire structure*; what is open is only whether
the balance, exact at every finite instant, ever tips across the infinite run.

### The anatomy: four facts established, one open statement in four forms

Around that single open statement, four facts are established, each tagged where it is computed $[C]$,
forced by standard theory $[T]$, or interpretive $[R]$:

1. **The cell is finite and exactly balanced.** $[C]$ The void operator and its sum-of-squares
   positivity are exact; the genome is the unique integer dimension-$8$ unit character orthogonal to
   the trivial; the dark cone is fifteen Fano matroids.
2. **The Euler product is necessary.** $[C]$ The functional equation supplies the symmetry axis but not
   the line: a self-dual functional equation *without* an Euler product admits an off-line zero, exhibited
   (Davenport–Heilbronn) to $38$ digits. The Euler product is the multiplicative binding the flow requires.
3. **The wall is forced to be abelian.** $[C\to T]$ $\chi_8$ has complex multiplication by
   $\mathbb Q(\sqrt{-7})$; it is realized explicitly as $L_{K_H}(s,\psi)$ for a *cubic* (order-$3$) Hecke
   character $\psi$; its Sato–Tate law is the torus. Hence $\mathrm{RH}(\chi_8)\iff\mathrm{GRH}(\psi)$, and
   no non-CM lever can reach it.
4. **RH holds in range.** $[C]$ By the argument principle the strip count is pinned exactly
   ($N(3)=8$, all on the line); the whole family follows with no missing zeros and positive Weil/Li
   coefficients.

The single open statement then appears in four equivalent forms, which §B.10 shows are one:

$$
\underbrace{\mathcal A \text{ self-adjoint}}_{\text{Aion / operator}}\ \Longleftrightarrow\
\underbrace{|K_L(s)|=1\iff \mathrm{Re}(s)=\tfrac12}_{\text{K-modulus / purity}}\ \Longleftrightarrow\
\underbrace{\lambda_n\ge 0\ \forall n}_{\text{Weil/Li positivity}}\ \Longleftrightarrow\
\underbrace{\mathrm{GRH}(\psi)}_{\text{abelian Hecke}} .
$$

A single order-$3$ structure — the *trit* — threads the anatomy from end to end: it is the ternary
operator of the finite cell (§B.3), the cubic Hecke character $\psi$ of the forced wall (§B.5), and
the channel along which the genome reads its floor value $-1$ (§B.10). The proxy that an earlier
operator computation borrowed — a *quadratic* character — is retired in §B.6, where the load-bearing
positivity is recomputed on $\chi_8$'s own cubic zeros.

### Conventions and roadmap

We use $\Gamma_{\mathbb R}(s)=\pi^{-s/2}\Gamma(s/2)$ and write $\Lambda(s)=N^{s/2}\gamma(s)L(s)$ for the
completed L-function, with $\Lambda(s)=\varepsilon\,\Lambda(1-s)$. Claims are tagged $[C]$ (computed and
reproduced), $[T]$ (standard theory invoked), $[P]$ (proved here), $[R]$ (interpretive), and
$[\mathrm{OPEN}]$ for RH itself; in-range verification is always $[C]$, never a proof.

Part II proceeds as follows. §B.2 fixes the finite cell — the gate, the two cones, the void operator and
its positivity. §B.3 unwinds it into the Aion flow and states the finite-to-infinite mechanism. §B.4
proves the Euler product necessary. §B.5 proves the wall forced and abelian. §B.6 defines the kernel
$K_L$ as the structure function of the Aion canonical system and recomputes the purity on the genome
itself. §B.7 presents the **second, complementary road** (Balashov's skeleton operator, Theorem M74, the
sign-count Re-Bound); §B.8 shows the two roads meet at one margin (and why the bridge between them is not
an equivalence); §B.9 states the **no-go** that bounds them both and exhibits the primes falling out of the
zeros. §B.10 assembles the synthesis — RH as the survival of a finite positivity across the infinite flow —
and shows the four faces are one. §B.11 is the honest ledger, and §B.12 the conclusion.

---

## §B.2 — The Finite Cell

This section fixes the finite apparatus that generates $\chi_8$: the gate, the two cones of its algebra,
and the void operator with its exact positivity. Everything here is finite and computed; nothing is
asymptotic. The cell defined here is the object that §B.3 will unwind into the infinite flow.

### B.2.1 The gate and the genome

For a prime $p\nmid 21$, the Frobenius class $\mathrm{Frob}_p\in G$ is read from the factorization type
of $f=x^7-7x+3 \bmod p$. The **genome** $a_p=\chi_8(\mathrm{Frob}_p)$ takes only four values:

$$
\begin{array}{c|c|c}
\text{class} & \text{cycle type of }f\bmod p & a_p=\chi_8\\\hline
1A & 1^7 & 8\\
2A & 1^3 2^2 & 0\\
3A & 1\cdot 3^2 & -1\\
4A & 1\cdot 2\cdot 4 & 0\\
7A,7B & 7 & 1
\end{array}
$$

— an infinite sequence over the **finite alphabet** $\{8,0,-1,1\}$. By Chebotarev it is equidistributed
by class measure, with mean $0$ and variance $1$ (since $\chi_8\perp\mathbf 1$ and $\|\chi_8\|=1$). The
local Euler factor at $p$ is fixed by the eight eigenvalues of $\rho_8(\mathrm{Frob}_p)$ — roots of unity,
the Satake parameters, the *states* of the gate — whose power sums $\sum_i\lambda_i^m=\chi_8(\mathrm{Frob}_p^m)$
are the von Mangoldt coefficients. The genome is the $m=1$ throughput; the full gate is the local factor.

Grouped by value (class sizes $1,21,56,42,24,24$), the genome's Chebotarev distribution is
$\{\,8:\tfrac1{168},\ 0:\tfrac{63}{168},\ -1:\tfrac13,\ 1:\tfrac{48}{168}\,\}$ — in particular
**$a_p=-1$ on exactly one prime in three** (the trit class $3A$, where the cubic amplitude $a_p(\chi_3)=0$).
The Born relation $a_p=|a_p(\chi_3)|^2-1$ (§A.5.2) makes this value a **floor**: $a_p\ge -1$ for every prime,
$-1$ being the total annihilation of $\chi_3$. The distribution holds to $\sim1\%$ over $3360$ primes near
$10^{60}$ (61-digit), with $\sum a_p=0$ exactly in sample — the mean-zero genome made visible $[C]$. (This
is the *floor*, fixed by the finite process; RH is the *fluctuation* around it.)

The value vector is rigid: $(8,0,-1,0,1,1)$ is the **unique** integer dimension-$8$ unit character of $G$
orthogonal to the trivial $[C]$. The alphabet is not chosen — it is forced.

### B.2.2 The two cones

The eight-dimensional $\chi_8$ is the octonion: seven imaginary units (the Fano points) and one real
unit (the void). Reading a *line* off the Cayley–Dickson table as a triple $\{a,b,c\}$ with
$e_ae_b=\pm e_c$:

- **Light cone (octonion).** The seven imaginary units give $7$ points, $7$ lines, $3$ per point, every
  pair on one line — the $2$-$(7,3,1)$ design $\mathrm{PG}(2,2)$, the **Fano matroid $F_7$**. The octonion
  is a division algebra (Hurwitz): no zero-divisors, every line associative. The light cone is *one* Fano
  plane, wall to wall. $[C]$
- **Dark cone (sedenion).** The doubling $\mathbb O\to\mathbb O\oplus\mathbb O$ has fifteen imaginary
  units: $15$ points, $35$ lines, $7$ per point — the $2$-$(15,3,1)$ design $\mathrm{PG}(3,2)$, containing
  **exactly fifteen Fano sub-planes** (the octonion subalgebras, the fifteen hyperplanes of
  $\mathrm{PG}(3,2)$). The sedenion is the first Cayley–Dickson algebra with **zero-divisors**; of its
  $455$ triples, $252$ ($55\%$) are non-associative. The dark cone is the last projective skeleton,
  riddled with the tears the zero-divisors make. Its zero-divisors are organized by the conductor:
  there are $84=4\cdot 21$ products $(e_a+e_b)(e_c+e_d)=0$ on distinct indices, i.e. $42=2\cdot 21$
  unordered pairs (verified by direct Cayley–Dickson computation). $[C]$

The two cones are *build* and *annihilation*: the octonion (division, no zero-divisors) is the matter
side; the sedenion (zero-divisors, pairing) is where annihilation lives. §B.10 reads this as the
forward/inverse of the Weil/Li sum.

### B.2.3 The void operator and its positivity

The gate's action on the seven-dimensional cell is governed by a self-adjoint **void operator**
$\mathcal O=C+iK$. Here $C$ (the *build*) is real symmetric with constant row sums $18$ — the all-ones
*void* eigenvector — and $K$ (the *chirality*) is the antisymmetric, time-reversal-breaking part
assembled from $P(g)-P(g^{-1})$ over the cones. Its characteristic polynomial is exact:

$$
\chi_{\mathcal O}(x)=(x-18)\,(x^2-4x-4)^2\,(x^2+8x+8),
$$

with spectrum $\{\,18,\ 2\pm 2\sqrt2\ (\text{double}),\ -4\pm 2\sqrt2\,\}$ $[C,\text{ first-party; char poly}$
$\text{independent of the }z_3\text{ choice}]$.
The $\sqrt2$ throughout is the characteristic-$2$ (quadratic) signature of the strata; the eigenvalue $18$
is the build.

The cell carries an **exact positivity**. The two-cone (AHK isotropy) form

$$
F(m,n)=\sum_{k=1}^{m-1}2\Big(1-\cos\tfrac{2\pi kn}{m}\Big)=\sum_{k=1}^{m-1}\big|\zeta_m^{kn}-1\big|^2
$$

is a **manifest sum of squares** in the $m$-th roots of unity $\zeta_m$ — the weight-$0$ Satake values of
B.2.1 — hence $F(m,n)\ge 0$ for every $n$, with $F(7,n)=14$ and $F(3,n)=6$ for $n\not\equiv 0$. This
positivity is **character-independent and exact** — a finite, proved theorem about the cell, not an
in-range numerical fact. $[C,\text{ first-party}]$

This is the load-bearing finite statement of Part II: the cell is positive — not approximately, not in
range, but exactly. The Riemann Hypothesis, in the form §B.10 reaches, is whether this exact finite
positivity *survives* when the cell is unwound into the infinite flow. We turn to that unwinding next.

---

---

## §B.3 — The Infinite Flow (the Aion)

The cell of §B.2 is finite and exactly positive. Yet the Riemann Hypothesis concerns infinitely many
primes. This section resolves the tension by unwinding the finite cell into an infinite flow — a de
Branges canonical system — and by locating, precisely, where the infinitude resides: not in any instant
of the flow, but in its variation.

### B.3.1 The closing clock and its unwinding

The void operator $\mathcal O=C+iK$ of §B.2.3 is a clock. Its build part $C$ is real symmetric; were the
chirality absent ($K=0$), $\mathcal O$ would be self-adjoint and *closed* — a compact rotation with a
discrete, periodic spectrum, an object entirely finite. The chirality $K\neq 0$ — the
time-reversal-breaking part — tips this closed clock into **directed motion**. Passing to the Cayley
transform $U=(\mathcal O-i)(\mathcal O+i)^{-1}$ carries the operator from the line to the circle and back;
applied to the directed (non-self-adjoint-perturbed) clock, it unwinds the compact rotation onto the
half-line $t\in[0,\infty)$. The finite clock becomes a flow. $[R$; the Cayley map is standard $T]$

### B.3.2 Why the flow never closes

The clock has two hands of coprime order: the **trit** $z_3$ (order $3$) and the **Singer** cycle
$\sigma$ (order $7$). They do not commute — the holonomy is

$$
z_3\,\sigma\,z_3^{-1}=\sigma^{r},\quad r\in\{2,4\},\ r^{3}\equiv 1\ (\mathrm{mod}\ 7),\ r\neq 1, \qquad [C,\text{ first-party}]
$$

— and $\gcd(3,7)=1$. A composite rotation of coprime, non-commuting orders has no common period: the
flow is **aperiodic** and never returns to its start. The finite clock, once unwound, runs **forever**.
That unending run is the flow's time parameter $t$; in the framework's reading the flow *is* time, and
its inexhaustibility is exactly the coprimality of the trit and the Singer refusing to resolve. $[C/R]$

### B.3.3 The canonical system

Formally, the unwound cell is a **de Branges canonical system**: a Hamiltonian $H(t)\succeq 0$ on
$t\in[0,\infty)$, a finite (matrix) cell at each instant, with an entire **structure function** $E(s)$.
The completed L-function is recovered from $E$ — $\Lambda(s,\chi_8)$ is its symmetric part — and the
non-trivial zeros are the **spectrum of the system**, the eigenvalues of the self-adjoint operator
$\mathcal A$ it defines. This is the Aion. That a self-dual L-function of Selberg class admits such a
representation is the de Branges framework $[T]$; the specific Hamiltonian seeded by the cell of §B.2 is
the construction proposed here.

In this language the Hilbert–Pólya dream is precise: the zeros lie on the line iff $E$ is
**Hermite–Biehler** (all its zeros in one half-plane) iff $H(t)\succeq 0$ for all $t$ iff $\mathcal A$ is
self-adjoint. The Riemann Hypothesis is the **positivity of the flow**.

### B.3.4 How the flow carries the primes

A natural objection closes the naive operator route and must be met head-on. By the explicit formula the
zeros encode the prime alphabet $\{\log p\}$, which is $\mathbb Q$-linearly independent (Baker) — an
object of **infinite rank**. A finite operator has finite rank and cannot reproduce it. For a finite
*matrix*, this is decisive.

It does not touch the canonical system. $H(t)$ is finite at each instant, but the **map** $t\mapsto H(t)$
— the *variation of the cell along the flow* — is an infinite object, and it is precisely there that the
primes are encoded. No single instant holds $\{\log p\}$; the unending run does. The Aion is therefore
**finite-per-instant, infinite-in-flow**: the apparent paradox of a finite machine carrying an infinite
arithmetic dissolves once one distinguishes the cell (finite, at each $t$) from its history (infinite,
over all $t$).

### The statement, and the guard

Collecting §§B.2–B.3:

> The cell is finite and exactly positive (§B.2.3). It is unwound by the arrow into an infinite,
> never-closing flow (§B.3.1–2), a de Branges canonical system whose spectrum is the zeros (§B.3.3), with
> the prime data carried in the flow's variation (§B.3.4). **RH$(\chi_8)$ is the statement that the
> cell's exact finite positivity survives as the positivity of the flow**, $H(t)\succeq 0$ for all $t$.

Two honest cautions attach to this and are carried for the rest of Part II. First, *relocating* RH to the
flow's positivity does not prove it: de Branges' own program shows this positivity is exactly as hard as
RH, because it **is** RH. Second — the circularity guard — the Hamiltonian $H(t)$ must be constructed from
the cell and the gate, **not** from the zeros; an operator built from the zero list reproduces them
trivially and proves nothing. The content of the operator route is entirely in whether the flow can be
built *forward*, from the finite arithmetic of §B.2, without knowing where its spectrum will fall.

What forces that flow to keep the zeros on the line — rather than merely to have a symmetry axis there —
is the subject of §B.4: the Euler product.

---

---

## §B.4 — The Euler Product Is Necessary

§B.3 unwound the cell into a flow whose structure function carries the functional equation. But a
functional equation fixes the symmetry *axis* at $\mathrm{Re}(s)=\tfrac12$; it does not, by itself, fix
the *zeros* there. This section proves that the ingredient holding the zeros to the line is the **Euler
product**, by exhibiting a function with everything *except* an Euler product that fails the Hypothesis.

### B.4.1 The axis is not the line

The completed L-function satisfies $\Lambda(s)=\varepsilon\,\Lambda(1-s)$, so its non-trivial zeros are
symmetric under $s\mapsto 1-s$: a zero at $\beta+i\gamma$ is paired with one at $1-\beta+i\gamma$. This
makes $\mathrm{Re}(s)=\tfrac12$ the *axis of symmetry* — but a pair with $\beta\neq\tfrac12$ is fully
consistent with it. The functional equation constrains the zeros to a symmetric configuration, not to a
line. [exposition]

### B.4.2 The Davenport–Heilbronn witness

That this gap is real — that a self-dual functional equation alone admits off-line zeros — is a theorem
of **Davenport and Heilbronn (1936)**. Let $\chi$ be the quartic character modulo $5$ ($\chi(2)=i$).
Neither $L(s,\chi)$ nor $L(s,\bar\chi)$ is self-dual, but a specific combination

$$
f(s)=c\,L(s,\chi)+\bar c\,L(s,\bar\chi),
$$

with $c$ chosen so the completed function is self-dual (Titchmarsh, *Theory of the Riemann Zeta-function*,
§10.25), satisfies a clean functional equation $\xi(s)=\xi(1-s)$ in the *same* $\Gamma$-factor class as a
genuine Dirichlet L-function. But $f$ is a **sum** of two L-functions, and a sum is not multiplicative:
**$f$ has no Euler product.** Davenport and Heilbronn proved $f$ has infinitely many zeros with
$\mathrm{Re}(s)\neq\tfrac12$. One such zero, computed to $38$ digits — reproducing the classical value:

$$
s=0.808517182456637\ldots+85.6993484853776\ldots\,i,\qquad
\mathrm{Re}(s)=0.8085\neq\tfrac12,\qquad |f(s)|\approx 3\times10^{-38}.
$$

$[T$ (the theorem, classical) $+\ C$ (the value, reproduced)$]$. Everything is present — the functional
equation, the symmetry axis, the gamma class — except the Euler product, and the zero leaves the line.
The obstruction is visible *locally*: the prime-power Hankel $[a_{p^{i+j}}]$ is rank-$1$ (a single Satake
tone, positive-semidefinite) at every prime exactly when the Euler product is genuine, and breaks to rank
$\ge 2$ (indefinite) precisely at the complex-character primes of the Davenport–Heilbronn two-tone — a
prime-by-prime filter that flags the non-Euler case at the first such prime $[C$, joint$]$.

### B.4.3 The Euler product forbids the escape

The complementary constraint is elementary and points the same way. An Euler product
$L(s)=\prod_p\prod_i(1-\lambda_{i,p}\,p^{-s})^{-1}$ with $|\lambda_{i,p}|\le 1$ converges absolutely for
$\mathrm{Re}(s)>1$ and is there bounded away from $0$: it has **no zeros in $\mathrm{Re}(s)>1$** at all.
The functional equation reflects this to $\mathrm{Re}(s)<0$ (off the trivial zeros), and the critical
strip is what remains. For $\chi_8$ the Euler product *is* the octonion gate of §B.2; so $\chi_8$ has no
zeros outside the strip, and inside it — in range, pinned (§B.10) — the zeros sit on the line. Same gamma
class as the Davenport–Heilbronn function, **opposite fate**: the only difference is the gate. [T,
elementary]

### Conclusion

The Euler product is **necessary**: it is the multiplicative binding that holds the flow's zeros to the
axis the functional equation supplies. In the language of §B.3, the functional equation gives the flow
its mirror symmetry, but only the Euler product — the gate, binding all primes at once — keeps the flow's
spectrum real. Remove it, and the spectrum demonstrably leaves the line. The *necessity* is proved here;
the *sufficiency* — Euler product $\Rightarrow$ every zero on the line — is the Riemann Hypothesis, taken
up in §B.10.

---

---

## §B.5 — The Wall Is Forced

§B.4 located the missing ingredient; this section identifies the *nature* of the wall it leaves. We show
that $\chi_8$'s Riemann Hypothesis is not an arbitrary analytic statement but a **forced** one: $\chi_8$ is
generated by a CM motive, is realized explicitly as an abelian Hecke L-function, and admits no non-CM
realization — so $\mathrm{RH}(\chi_8)$ is exactly $\mathrm{GRH}$ for one explicit *cubic* Hecke character.
The computations of this section were performed on the 32 GB machine and are cited as such; the
propagation between them is standard.

### B.5.1 The root is CM

The generating quark $\chi_3$ is CM, as established in §A.6.1: it is $H^0(X(7),\Omega^1)$ with Jacobian
isogenous to $E^3$, $E$ of conductor $49$ ($j=-3375$) having complex multiplication by $\mathbb Q(\sqrt{-7})$
— the CM visible arithmetically as $a_p(E)=0\iff p$ inert in $\mathbb Q(\sqrt{-7})$. The generating motive of
the family is CM $[C]$.

### B.5.2 CM propagates through the tower

Part I established that every family member is a tensor construction of $\chi_3$: $\mathrm{Sym}^2\chi_3=\chi_6$,
$\Lambda^2\chi_3=\bar\chi_3$, and $\chi_3\otimes\bar\chi_3=\mathbf 1\oplus\chi_8$ (the Born relation,
confirmed on $6055$ primes $[C]$). CM motives form a Tannakian subcategory closed under
$\otimes,\mathrm{Sym}^k,\Lambda^k$, with the Mumford–Tate torus preserved $[T$: Deligne; Shimura–Taniyama$]$.
Hence each member, a tensor word in the CM root, is itself CM — its Mumford–Tate group a sub-torus of the
$\mathbb Q(\zeta_7)$-torus.

### B.5.3 The explicit Hecke realization

For $\chi_8$ the consequence is made concrete. The monomial reduction $\chi_8=\mathrm{Ind}_{7:3}^{G}\psi$
gives, by Artin's induction invariance, $L(s,\chi_8)=L_{K_H}(s,\psi)$, a degree-$1$ Hecke L-function over
the octic field $K_H$. The octic field is the LMFDB field $K_H=$ `8.0.37822859361.1`, $K_H=\mathbb Q[x]/(x^8-4x^7+7x^6-7x^5+7x^4-7x^3+7x^2+5x+1)$,
with $\mathrm{polgalois}=[168,\mathrm{PSL}(2,7)]$, $\mathrm{disc}(K_H)=3^8 7^8$, class group $\mathbb Z/4$.
Of its $26$ cubic ray-class characters, **exactly two** — $\psi,\bar\psi$ — have conductor norm
$N\mathfrak f=441=3^2 7^2$; the channel is thus uniquely selected, and the conductor–discriminant formula
gives $\mathfrak n(\chi_8)=N\mathfrak f\cdot\mathrm{disc}(K_H)=441\cdot 3^8 7^8=21^{10}$. The resulting Hecke
L is verified equal to $L(s,\chi_8)$: same conductor, same gamma $\Gamma_{\mathbb C}(s)^4$, same functional
equation. Two determinations of $a_p$ — **Path A** (Frobenius cycle type of $x^7-7x+3 \to$ character table)
and **Path B** ($a_p$ of the Hecke $L(s,\psi)$) — agree on **all $166$ unramified primes $p<1000$ with zero
mismatches**, and all $120$ Dirichlet coefficients are identical $[C]$. Two L-functions of the same degree
and conductor agreeing on every Euler factor are the same L-function. Therefore

$$
\boxed{\ \mathrm{RH}(\chi_8)\iff\mathrm{GRH}(\psi),\quad \psi\ \text{an explicit cubic Hecke character of }K_H.\ }
$$

Equivalently the lift is automorphic: $\chi_8=\mathrm{AI}_{K_H/\mathbb Q}(\psi)$ is the automorphic
induction of $\psi$ to a unique cuspidal automorphic representation of $\mathrm{GL}(8)/\mathbb Q$ $[T]$. The
trit reappears here: $\psi$ has **order $3$** — the same order-$3$ structure as the finite ternary operator
of §B.3. The order-$3$ thread runs unbroken from the cell to the analytic object.

### B.5.4 Sato–Tate is the torus

The CM is confirmed by the Frobenius distribution: for a CM motive the Sato–Tate measure is the **torus**,
not $\mathrm{SU}(2)$, so the second moment $\langle(a_p/\sqrt p)^2\rangle=2$, not $1$. This was computed in
§A.6.3 (over $8972$ split primes: uniform angles, Kolmogorov–Smirnov $0.0095$; the semicircle rejected;
$\langle(a_p/\sqrt p)^2\rangle=1.99$) $[C]$ — the Mumford–Tate torus confirmed empirically.

### B.5.5 No lever, hence forced

A CM (torus-MT) motive has **no non-CM realization**: its symmetric and tensor powers factor into abelian
Hecke L-functions (Tate-twisted to weight $0$), so there is no auxiliary positive-weight, Deligne-pure
motive from which to import positivity. The "no shortcut" the program repeatedly met is therefore not a
gap in the analysis but a structural feature — the Deligne lever is **provably absent** $[C\to T]$.

The distinction is load-bearing: the *analytic wall* is abelian — the L-function **equals** $L(\psi)$, an
abelian Hecke L, by induction — yet the Artin *representation* $\chi_8$ is itself genuinely non-abelian, and
no $\mathbb Q$-side reciprocity reaches it either. The genome $a_p$ is provably **not** a function of $p\bmod 21$: e.g.
$a_2=+1\neq a_{23}=-1$ though $2\equiv23\equiv 2\pmod{21}$ (over $107$ primes, $71$ such residue-class
disagreements) $[C]$. And although $\psi$ takes values in $\mu_3$ (the trit), $K_H$ is primitive and
$\mathbb Q(\omega)\not\subset K_H$ ($G$ simple, the tower $\omega$-free), so there is no cubic-reciprocity
identity to exploit — the character is *Eisenstein in value but not in field*. Both the geometric lever
(no Deligne pure motive) and the arithmetic lever (no reciprocity) are absent.

### The necessity theorem

> **Theorem (the structure is forced).** The genome family is generated by a CM motive (§B.5.1), closed
> under the tensor operations that build it (§B.5.2); $\chi_8$ is realized explicitly as the abelian Hecke
> L-function of a cubic character $\psi$ over $K_H$ (§B.5.3), with Sato–Tate the torus (§B.5.4); and no
> non-CM realization exists (§B.5.5). Hence $\mathrm{RH}(\chi_8)\iff\mathrm{GRH}(\psi)$, and nothing weaker
> than GRH for an abelian Hecke L reaches it.

Items (B.5.1, B.5.3, B.5.4) are computed; (B.5.2, B.5.5) are standard CM propagation resting on them. The
*structure* is forced; RH is not thereby proved. "We found no shortcut" is upgraded to "there provably is
none" — the attainable half of *it could not be otherwise*. What remains is exactly $\mathrm{GRH}(\psi)$,
taken up among the equivalent faces of §B.10.

---

---

## §B.6 — The K-modulus: the Flow's Balance as Purity

The Aion of §B.3 is a de Branges canonical system, and its positivity is the Riemann Hypothesis. This
section makes that positivity into an explicit **modulus** condition — the K-modulus — by reading off the
system's structure function, and verifies the condition *in range, on the genome's own zeros*, retiring
the quadratic proxy of an earlier computation.

### B.6.1 The kernel $K_L$ as the Aion's structure function

A de Branges canonical system $H(t)$ has an entire **structure function** $E(s)$, and the completed
L-function is recovered from its decomposition into real-entire parts: writing
$\Lambda(\tfrac12-iz,\chi_8)=A(z)-iB(z)$ with $A,B$ real entire, the structure function is $E=A-iB$.
Define the deposit kernel

$$
K_L(s)=\frac{E^*(s)}{E(s)},\qquad E^*(s)=\overline{E(\bar s)}.
$$

This is the scattering ratio of the Aion: on the critical line ($z$ real) numerator and denominator are
complex conjugates, so $|K_L|=1$ identically; off the line its modulus measures the deviation of the flow
from positivity. $K_L$ is not shorthand — it is the structure function of the canonical system *proposed*
in §B.3 (whose cell-seeded Hamiltonian is the construction conjectured there, not yet built). $[T$: de
Branges$]$

### B.6.2 The K-modulus theorem

The Hermite–Biehler condition states that $E$ has all its zeros in the lower half-plane iff the canonical
system is positive, $H(t)\succeq 0$ — equivalently $|E^*(z)|<|E(z)|$, i.e. $|K_L|<1$, throughout the open
upper half-plane. Translated to $s$:

$$
|K_L(s)|=1\ \Longleftrightarrow\ \mathrm{Re}(s)=\tfrac12,\qquad\text{iff}\quad\mathrm{RH}(\chi_8).
$$

The modulus is $1$ on the line by construction; the content is that it is $1$ **only** there — an off-line
zero $\rho$ would produce a second point with $|K_L(\rho)|=1$. RH is the *purity* statement that the
modulus-$1$ locus is exactly the line. For $\chi_8$ (degree $8$, $\gamma=\Gamma_{\mathbb C}(s)^4$) the
canonical system is matrix-valued, so $E$ and $K_L=E^{-1}E^*$ are matrices and the purity is the
**unitarity of an eight-dimensional scattering matrix** on the line (the Schur form) — not the scalar purity of a degree-$1$
L-function. $[T$; RH-equivalent$]$

### B.6.3 Local purity and its survival

The purity splits into a free local half and an open global half. Locally, the Satake parameters of
§B.2.1 — the eight eigenvalues of $\rho_8(\mathrm{Frob}_p)$ — are roots of unity, of modulus exactly $1$
at every prime (for an Artin L-function the Ramanujan bound is automatic), so every local factor is
unitary. The K-modulus is whether this per-prime modulus-$1$ **assembles**, through the infinite Euler
product (§B.4) along the flow (§B.3), into a globally modulus-$1$ scattering matrix on the line:

$$
\mathrm{RH}(\chi_8)\ =\ \big[\ \text{local modulus-1 (Satake) survives as global modulus-1 } (K_L)\text{ on the line}\ \big].
$$

This is the finite-cell / infinite-flow dichotomy of §B.3 in purity language: the local purity is free (a
theorem), the global purity is the survival (RH).

### B.6.4 The proxy retired — positivity on the genome's own zeros

An earlier operator computation demonstrated the in-range positivity through a *tame quadratic* stand-in,
the character $(\tfrac{\cdot}{21})$, because $\chi_8$'s wild ramification then blocked its zeros. With
$\chi_8$ now realized as the **cubic** Hecke $L(\psi)$ (§B.5.3) and its zeros computed, the positivity is
recomputed on the genome itself. The void-pressure moments $S_k=\sum_n \gamma_n^{-2k}$ ($\gamma_n$ the
ordinates of $\chi_8$'s zeros) form a Stieltjes sequence iff the ordinates are real; their Hankel
determinants $H_m=\det[\,S_{i+j+1}\,]_{i,j=0}^{m-1}$, on $\chi_8$'s own zeros, are

$$
H_1=2.985,\quad H_2=1.057,\quad H_3=1.95\times10^{-2},\quad H_4=8.8\times10^{-6},\quad H_5=6.0\times10^{-11},
$$

all positive and collapsing Gaussian-fast — the marginal *knife-edge* (the de Bruijn–Newman edge
$\Lambda_{\mathrm{dBN}}=0$ of §B.10.2; not to be confused with the completed L-function $\Lambda(s)$) — at
the genome's first ordinate $\gamma_1=0.986$, not the proxy's $2.316$. $[C,\text{ first-party}]$. The order-$3$ thread is now
complete: the finite ternary operator (§B.3), the cubic Hecke $\psi$ (§B.5), and this positivity are one
object, computed on the trit genome throughout.

That Hankel positivity is read from the *zeros*, and is in that sense weak — on the line $|1-1/\rho|=1$, so
it half-assumes what it tests. The **same** positivity read from the **prime side** is not circular. The
Weil/Li coefficients $\lambda_n=\sum_\rho\big[1-(1-1/\rho)^n\big]$ can be evaluated directly from $-L'/L$ and
its derivatives at $s=1$ — i.e. from the Satake/genome data, **no zeros used**; over $n=1,\dots,10$ this gives
$\lambda_n=4.3,\,16.0,\,31.8,\,48.6,\,64.7,\,80.6,\,97.3,\,115.7,\,135.5,\,155.4$, all positive (the method
validated on $\chi_{-4}$ to $10^{-6}$) $[C]$. Since the primes carry no knowledge of where the zeros lie,
$\lambda_n>0$ *from the prime side* is genuine arithmetic positivity, not the tautology of the spectral side.

### B.6.5 The diagonality is forced (Aramata–Brauer)

The positivity has a representation-theoretic backbone independent of the numerics. The Weil prime-pairing
acts on the modes of $\chi_8\otimes\chi_8$, which by §A.5.4 decomposes as $\mathbf 1\oplus(\text{five
non-trivial irreducibles})$. The trivial part is $\zeta$, whose simple pole at $s=1$ supplies a positive
diagonal constant $c=\langle a_p^2\rangle=1$; every non-trivial constituent $\rho$ has $L(s,\rho)$
**holomorphic at $s=1$** by Aramata–Brauer, contributing no pole and no diagonal mass. Hence on the
prime-mode span the pairing is

$$
W=c\cdot I,\qquad c=1>0,
$$

diagonal and positive — the off-diagonal "prime conspiracy" *cannot* occur, because multiplicity-one
($\langle\chi_8\otimes\chi_8,\mathbf 1\rangle=1$) leaves exactly one pole. The in-range Hankel positivity of
§B.6.4 is the analytic shadow of this exact algebraic fact $[C\to T]$ (the multiplicity computed first-party,
Aramata–Brauer standard). What it does *not* settle is the survival of $W=c\cdot I$ on the **full** flow, not
only the finite prime-mode cell.

### Scope

The K-modulus is RH-equivalent, not a proof: $|K_L|=1$ on the line and the Hankel positivity are checked
*in range* (here to $m=5$; an extended zero set reaches $m\approx 7$), and "positive through $m=5$" is not
"positive for all $m$," which is RH. The de Branges program is candid that this canonical-system positivity
is exactly as hard as RH, because it *is* RH. What §B.6 supplies is the precise object — $K_L$ as the
Aion's structure function — and its verification, in range, on the genome rather than a proxy. The faces
this assembles are unified in §B.10.

---

---

## §B.7 — The Second Road: Skeleton Zeros and the Sign-Count (Balashov)

Part II's operator road (§B.3–B.6) is one of *two* complementary finite-level constructions that reduce the
Hypothesis to a positivity surviving a limit. The second, due to Balashov, is analytic rather than
operator-theoretic; it is built on the classical Riemann object $\Xi$, and it is included here because the
two roads meet at one wall (§B.8) and are bounded by one no-go (§B.9).

### B.7.1 The finite-level operator $\tilde M_N$

The Theta–Hurwitz operator at level $N$,

$$
\tilde M_N(t)=4\sum_{n=1}^N\int_0^\infty\Phi_n(u)\cos(tu)\,du,\qquad
\Phi_n(u)=\big(2\pi^2 n^4 e^{9u/2}-3\pi n^2 e^{5u/2}\big)e^{-\pi n^2 e^{2u}},
$$

is a finite truncation converging to $\Xi(t)=\xi(\tfrac12+it)$ on the real axis; the oscillatory integral
admits a closed form via the incomplete gamma function (a computational device of the road). The **skeleton
zeros** $\{t_j^{(N)}\}$ are the real zeros of $\tilde M_N$ — by construction, on the line. $[C$, Balashov$]$

### B.7.2 Theorem M74 — the skeleton zeros converge to the Riemann zeros

**Theorem (M74, Fixed-Zero Convergence).** For each simple zero $\gamma_j$ of $\Xi$ and all $N\ge N_0(j)$
there is a unique skeleton zero $t_j^{(N)}$ with $|t_j^{(N)}-\gamma_j|<\tfrac13\min_{k\neq j}|\gamma_k-\gamma_j|$;
hence $t_j^{(N)}\to\gamma_j$.

The proof is Rouché on a disk $D_j$ around $\gamma_j$: the tail bound $|\Xi-\tilde M_N|\le C(N+1)^2 e^{-\pi(N+1)^2}$
holds on $D_j$ (super-exponentially small) and drops below $\min_{\partial D_j}|\Xi|$ once $N\ge N_0(j)$, so
$\tilde M_N$ has exactly one zero in $D_j$. (Numerically $N=2$ already gives tail $\le5.9\times10^{-11}\ll
\varepsilon_1=1.4\times10^{-5}$.) Conditional on simplicity of $\gamma_j$, known for all computed zeros.
$[T/C$, Balashov; independently reproduced$]$

The skeleton tracks the true zeros; what remains is that none strays off the line as $N\to\infty$ — the
Re-Bound.

### B.7.3 The Re-Bound, in sign-count form

The natural finite-$N$ margin — the *edge gap*, the distance from the last skeleton zero to the spectral
wall at $0.58\,S_N$ — **fails as a floor**. The wall sweeps $\sim 36$ zero-spacings per $N$-step through an
incommensurate set, so it equidistributes and the running minimum $\to 0$ (the near-misses, edge gap
$=0.029$ at $N=44$, are the trend, not a fluctuation). A continuous distance the geometry drives to zero
cannot carry a positivity floor. The failure is not a defect but a **fingerprint of GUE**: the wall samples
a GUE *flow*, not a lattice, and the coprimality $3\perp 7$ (lattice step $3$, Singer flow $7$) forces the
incommensurate equidistribution. A positive floor would require the zeros to be lattice-like; their
GUE-rigidity (§B.10.2) is exactly why no floor exists. $[C$, joint$]$

The correct invariant is **discrete**: a zero landing near the wall is still counted; what would violate RH
is a *miscount* — a zero on the wrong side. So the road's condition is a sign-count:

> **Re-Bound (sign-count form).** For all $N$, the number of real zeros of $\tilde M_N$ below the wall (its
> sign-changes, by construction on the line) equals the total zero-count of $\Xi$ below the wall.

This count decomposes exactly,

$$
R_N=\underbrace{\bar N(\text{wall})}_{\text{geometry, }\pm O(1)}+\underbrace{S(\text{wall})}_{\text{primes}},
\qquad S(T)=\tfrac1\pi\arg\zeta(\tfrac12+iT),
$$

the geometry supplying the smooth count to $\pm O(1)$, the prime term $S$ supplying the last unit that fixes
the exact integer. **Local RH is the statement that the real count equals the total — a condition on $S$.**
The sign-count is robust exactly where the edge gap is fragile (at $N=36,44$ the integer $R_N$ is clean
though the gap collapses), and it lands in the **Levinson–Conrey** family — counting real zeros of a real
model by mollified moments, where on-the-line counting has produced theorems (positive proportion $>41\%$
for $\zeta$). $[C/R$, joint$]$ This is no free lunch — count-match *is* local RH — but it places the entire
residual difficulty in the explicit prime object $S$, which §B.9 shows is exactly where it must sit.

Concretely, the invariant is the **buoy defect** $B_N(c)=N_{\mathrm{total}}(T)-R_{\mathrm{line}}(T)$ at the
wall $T=c\,S_N$ — the total zero-count below the wall (argument principle) minus the line-zero count: $B_N=0$
is "no wrong-side crossing," $B_N\neq0$ a miscount. Across the candidate walls $c\in[0.58,0.585]$, $B_N=0$
holds for **all $N=8,\dots,70$** — no wrong-side event, even at the sharpest timing near-misses (gap
$\sim10^{-3}$) — a finite computational confirmation, not a proof $[C$, Balashov$]$.

---

## §B.8 — The Two Roads Meet at One Margin

The operator road (§B.3–B.6) and the analytic road (§B.7) are distinct — different objects (a de Branges
system on $\chi_8$ versus the Theta–Hurwitz truncation on $\Xi$), different finite parameters, different
margins — yet both reduce to the same kind of statement: **a finite-level positivity must survive a limit.**

| | operator road (Stenberg) | analytic road (Balashov) |
|---|---|---|
| object | Aion / de Branges system | Theta–Hurwitz $\tilde M_N$ |
| finite parameter | matrix order $m$ | level $N$ |
| margin | $\det H_m$ (Gaussian $\sim10^{-1.6m^2}$) | sign-count surplus / edge structure |
| tracking theorem | $t_j^{(N)}\to\gamma_j$ analogue | M74 (proved) |
| condition | $\det H_m>0$ as $m\to\infty$ | real count $=$ total count, $\forall N$ |
| equals | $\mathcal A$ self-adjoint | the Re-Bound |

**The bridge is not an equivalence.** It is tempting to identify the two margins: if $m\sim\log N$, the
Gaussian decay $\det_m\sim10^{-1.6m^2}$ would become the power-law edge decay. *We tested this and it is
false.* $\det_m\to0$ is generic for any Hankel matrix (a Gram determinant of a collapsing basis), while the
edge gap is a distance; the ratio drifts $\sim6$ orders over $N=10..50$, with at best a transient
$\sqrt{\log N}$ scaling. The two margins are **independent sufficient conditions for the same conclusion**,
not two encodings of one quantity. $[C$, joint$]$

So the picture is not one road in two languages but **two genuinely different roads arriving at one wall.**
Why the wall is the same — and why neither margin can cross it — is §B.9.

---

## §B.9 — The No-Go, and the Primes in the Zeros

Both roads stall at the same place, for the same reason. This section states the boundary precisely and
exhibits it.

### B.9.1 The no-go, quantified

The **density** of the zeros is geometric and free: the Riemann–von Mangoldt term
$\bar N(T)=\tfrac{T}{2\pi}\big(\log\tfrac{T}{2\pi}-1\big)+\tfrac78$ pins the count to $\pm O(1)$ at every
height with **no prime input** ($|\bar N-(n-1)|<1$ verified from $\gamma_{11}$ to $\gamma_{1200}$). The
**positions** are not: reconstructing the zeros from the prime/main-sum, the height reached grows with the
number of primes used, and to reach *any* height needs $\pi(L)\to\infty$ primes — rigorously, the
Riemann–Siegel main sum of length $\nu=\sqrt{T/2\pi}$. $[C/T$, joint$]$

> **The no-go.** The envelope — density, scale, spacing — is reachable from the finite geometry; the
> *positions* of the zeros require the full prime alphabet $\{\log p\}$, which is $\mathbb Q$-linearly
> independent (Baker) and of unbounded rank. No finite-rank object — neither a Hankel margin nor a skeleton
> edge — can encode it.

This is one fact in four guises: it is *why* the edge-gap floor fails (the wall sweeps an incommensurate
set), *why* the $m\sim\log N$ bridge is not an equivalence (finite rank $\neq$ infinite rank), *why* the
sign-count's difficulty sits in the prime term $S$, and *why* the K-modulus positivity (§B.6) collapses to a
knife-edge rather than to a provable floor.

### B.9.2 The primes fall out of the zeros

The no-go has a literal demonstration. Form the spectrum of the zeros $F(x)=\sum_n\cos(x\gamma_n)$ (mild
taper) and scan $x$: **every resonance sits at $x=\log p^k$, and nowhere else.** From the first $1200$
zeros, to $\sim 4$ decimals:

$$
\begin{array}{c|c|c}
x_{\text{peak}} & \log p^k & |\text{err}|\\\hline
0.6932 & \log 2 & 1\times10^{-4}\\
1.0986 & \log 3 & 0\\
1.6094 & \log 5 & 0\\
1.9459 & \log 7 & 0\\
2.3978 & \log 11 & 1\times10^{-4}\\
1.3862 & \log 2^2 & 1\times10^{-4}\ (\text{weaker},\ \propto\Lambda(n)/\sqrt n)\\
\text{6, 10, 12, 14, 15} & \text{composite} & \text{flat — no peak}
\end{array}
$$

This is the dual of the explicit formula (Guinand–Weil) made visible, and it shows three things at once:
the fine structure of *where the zeros sit*, Fourier-transformed, **is** the prime spectrum (weights
$\propto\Lambda(n)/\sqrt n$); the peaks have **no common period** (the logs are $\mathbb Q$-independent), so
the zeros are an incommensurate point process, **never a lattice** at any scale; and only the *prime*
alphabet appears (composites vanish, $\Lambda=0$). $[C$, this work$]$

The line is, and the no-go says must be, the primes'. Both roads reach the envelope; the positions — the
content of RH — are prime data the finite geometry provably cannot manufacture. The one direction *through*
the wall is to carry the prime information *in*: a positive-weight motive for $\chi_8$ (§B.5.5), which is RH
itself.

---

## §B.10 — The Synthesis: RH as a Finite Positivity Surviving an Infinite Flow

This section assembles Part II. The finite cell, the infinite flow, the necessary gate, the forced wall,
and the purity kernel combine into a single statement of $\mathrm{RH}(\chi_8)$; the four reformulations
that have appeared — operator, purity, positivity, abelian — are shown to be one; and that statement is
placed alongside the second road (§B.7) and the no-go that bounds them both (§B.9).

### B.10.1 The assembly

Collecting what is established:

- the cell is finite and **exactly positive** (§B.2.3, the AHK sum-of-squares);
- it is unwound into an infinite, never-closing flow — a de Branges canonical system whose spectrum is
  the zeros (§B.3);
- the **Euler product is necessary** to hold that spectrum to the line (§B.4, Davenport–Heilbronn);
- the wall is **forced abelian**: $\mathrm{RH}(\chi_8)\iff\mathrm{GRH}(\psi)$ for an explicit cubic Hecke
  $\psi$ (§B.5);
- the **purity** $|K_L|=1\iff\mathrm{Re}=\tfrac12$ expresses the flow's positivity, verified in range on
  the genome (§B.6);
- a **second, complementary road** (§B.7): Balashov's finite-level $\tilde M_N$, with M74 proved (skeleton
  zeros $\to$ Riemann zeros) and the Re-Bound carried in robust sign-count form — both roads reducing to one
  margin (§B.8);
- the **no-go** (§B.9) that bounds them both: the density is geometric and free, but the positions are
  prime-locked (the primes fall out of the zeros), so no finite-rank structure closes the survival by itself.

The first five entries are proved or forced; the last two place the open survival between a complementary
second road and a precise boundary. The remaining content is a single statement:

> **$\mathrm{RH}(\chi_8)$:** the finite cell's exact positivity survives, through the necessary Euler
> binding, as the positivity of the infinite flow.

### B.10.2 The four faces are one

The statement has appeared in four guises. These are not independent results but **one statement recast**,
joined by a cycle of equivalences — three of them classical RH-criteria, the fourth the explicit reduction
of §B.5:

$$
\underbrace{\mathcal A\ \text{self-adjoint}}_{\text{operator (Aion)}}
\ \Longleftrightarrow\
\underbrace{|K_L(s)|=1\iff\mathrm{Re}(s)=\tfrac12}_{\text{purity (K-modulus)}}
\ \Longleftrightarrow\
\underbrace{\lambda_n\ge 0\ \forall n}_{\text{positivity (Weil/Li)}}
\ \Longleftrightarrow\
\underbrace{\mathrm{GRH}(\psi)}_{\text{abelian (Hecke)}} .
$$

Reading the cycle: the Aion's self-adjointness and the K-modulus are the operator and the structure
function of the *same* canonical system ($\mathcal A$ self-adjoint $\iff H(t)\succeq 0\iff E$
Hermite–Biehler $\iff|K_L|=1$ on the line, §B.6.1–2); de Branges positivity is equivalent to the Weil/Li
positivity $\lambda_n=\sum_\rho\big[1-(1-1/\rho)^n\big]\ge 0$ (Li, 1997); and
$\mathrm{RH}(\chi_8)\iff\mathrm{GRH}(\psi)$ is the explicit Hecke realization (§B.5.3). Each face is the
others in different language; none is weaker, because each *is* $\mathrm{RH}(\chi_8)$.

The contribution is not new equivalences — Hilbert–Pólya/de Branges, Li, and abelian reduction are
classical — but that **all four are exhibited for one object, each grounded**: the operator on the finite
cell (§B.3), the kernel as its structure function (§B.6.1), the positivity computed on the genome's own
zeros (§B.6.4), the abelian character $\psi$ constructed explicitly (§B.5.3). The wall is the same from
every side.

These are all specializations of one classical statement — the **Weil explicit-formula positivity**

$$
W(f)=\mathrm{ARCH}(f)-\mathrm{PRIME}(f)\ \ge\ 0\quad\text{for all admissible }f,\qquad
\mathrm{PRIME}(f)=\sum_n\frac{\Lambda(n)}{\sqrt n}\,K_f(\log n),
$$

(Weil 1952; Bombieri), in which the prime side is given **by the primes alone**, not the zeros. Li's
$\lambda_n\ge0$ is $W$ on a particular basis; $\mathrm{GRH}(\psi)$ is the same wall named arithmetically. And
**Balashov's analytic road (§B.7) — distinct from the operator construction, using none of its machinery —
reduces by the same explicit formula to exactly this $W\ge0$**: his "no wrong-side crossing" ($B_N=0$, §B.7.3) is the in-range face of
$\mathrm{ARCH}\succeq\mathrm{PRIME}$. So the **two roads converge on one classical wall** — the
de Branges/operator road and the Theta–Hurwitz/sign-count road both land on $W=\mathrm{ARCH}-\mathrm{PRIME}\ge0$,
gated identically by the no-go (§B.9). The ceiling is sharp and we state it plainly: $W\ge0$ *from the primes*
is not a step toward RH — it **is** RH, the principal classical equivalent, and the no-go says no finite or
diagonal datum supplies it. $[T$: Weil/Bombieri; the two-road convergence $C$, joint$]$

A fifth dialect names *why* the edge is marginal. For $\zeta$ the de Bruijn–Newman constant
$\Lambda_{\mathrm{dBN}}$ obeys $\mathrm{RH}\iff\Lambda_{\mathrm{dBN}}\le 0$, while Rodgers–Tao (2020) proved
the matching lower bound $\Lambda_{\mathrm{dBN}}\ge 0$; the two together force $\Lambda_{\mathrm{dBN}}=0$ —
the Hypothesis is not that the heat-flow lands *somewhere* safe but that it is **critically damped**, sitting
exactly on the boundary, neither over- nor under-shot. Read on the genome's flow, this is the same marginal
rigidity as the four faces: the Hankel knife-edge of §B.6.4 and the never-closing balance of §B.3 are the
dynamical face of $\mathcal A$ self-adjoint $=|K_L|=1=\lambda_n\ge0=\mathrm{GRH}(\psi)$. $[T$ for $\zeta$;
the transfer to $\chi_8$'s flow is $R]$.

The spectral statistics corroborate the chaos this implies. The computable weight-$6$ avatar of $\chi_8$ — a
classical degree-$2$ level-$7$ newform with $a_2=-10$, sharing the genome's bad prime — yields $369$ zeros
to height $300$ whose unfolded spacings fit the GUE law (Kolmogorov–Smirnov $0.053$, not rejected; Poisson
rejected at $0.334$; level repulsion $P(s<0.3)=0.016$); the spectrum is quantum-chaotic, consistent with
$\mathrm{Re}=\tfrac12$ as the Berry–Keating Lyapunov-$\tfrac12$ line, and by universality the weight-$0$
genome would match. $[C]$

### B.10.3 The two cones as the Li bowtie

The light and dark cones of §B.2.2 are the two halves of the positivity. The Li sum pairs each zero $\rho$
— *forward*, the build: the octonion, a division algebra, no annihilation — with its reflection $1-\rho$
— *inverse*, the annihilation: the sedenion, the zero-divisor channel. On the critical line $\rho$ and
$1-\rho$ are conjugate, the paired contribution to $\lambda_n$ is non-negative — $2(1-\cos n\theta_\rho)\ge
0$, the per-pair positivity, solved precisely because $|1-1/\rho|=1$ there. The doubling
$\mathbb O\to\mathbb O\oplus\mathbb O$ that carries each build into its paired annihilation is the Born
relation $\chi_3\otimes\bar\chi_3=\mathbf 1\oplus\chi_8$ (§B.5.2): the genome is the amplitude paired with
its reverse, reading its floor value $-1$ exactly where the trit cancels (the class $3A$, one prime in
three). $[C$ facts; the cone reading $R]$

In this image the Riemann Hypothesis is that **every forward build meets its inverse annihilation on the
line** — no off-line pair — across the whole infinite flow.

### The statement, complete

> $\mathrm{RH}(\chi_8)$ is that the exact, finite, sum-of-squares positivity of the cell (§B.2), unwound by
> the arrow into the de Branges flow (§B.3), bound by the necessary Euler product (§B.4), forced to the
> abelian Hecke wall $\mathrm{GRH}(\psi)$ (§B.5), and expressed as the purity $|K_L|=1$ on the line (§B.6),
> **survives undimmed across the infinite, never-closing run.**

---

---

## §B.11 — Honest Ledger

Part II has separated what is established from what is open. The ledger collects it, with the provenance
of each verification.

**Proved or forced.**

- *The finite cell* $[C]$: the genome alphabet $\{8,0,-1,1\}$ and its rigidity; the two cones — the
  octonion Fano $F_7$ and the sedenion $\mathrm{PG}(3,2)$ with fifteen Fano subplanes and $84/42$
  zero-divisors; the void operator spectrum $\{18,\,2\pm2\sqrt2,\,-4\pm2\sqrt2\}$; the AHK sum-of-squares
  positivity.
- *The unwinding* $[C/T]$: the holonomy $z_3\sigma z_3^{-1}=\sigma^r$ ($r\in\{2,4\}$, order-$3$ multiplier mod $7$); the coprimality $3\perp 7$; the
  Cayley transform.
- *The Euler product necessary* $[T+C]$: Davenport–Heilbronn — self-dual functional equation, no Euler
  product, off-line zero at $0.8085+85.699\,i$.
- *The wall forced* $[C\to T]$: the CM root by the cyclotomic $\mathbb Q(\zeta_7)$-torus (Grossencharacter
  $L(\mathrm{Jac}\,C)=L(E)L(E\otimes\chi)L(E\otimes\chi^2)=L(\eta)$, $\mathbb Q(\sqrt{-7})\subset\mathbb Q(\zeta_7)$);
  the explicit cubic Hecke realization $\chi_8=L(\psi)$ over $K_H=$`8.0.37822859361.1` ($\psi$ one of two
  cubic ray-class characters of conductor norm $441$; Path-A/Path-B $a_p$ match on $166$ primes); equivalently
  the automorphic induction $\mathrm{AI}_{K_H/\mathbb Q}(\psi)$ on $\mathrm{GL}(8)/\mathbb Q$; Sato–Tate the
  torus; the character genuinely non-abelian ($a_2\neq a_{23}$); no Deligne lever and no reciprocity lever;
  hence $\mathrm{RH}(\chi_8)\iff\mathrm{GRH}(\psi)$.
- *The moments and diagonality* $[C\to T]$: $\langle a_p^k\rangle=(8^k+56(-1)^k+48)/168=0,1,3,25,195,1561$;
  the Rankin–Selberg square $\chi_8\otimes\chi_8=\mathbf 1\oplus\chi_3\oplus\bar\chi_3\oplus2\chi_6\oplus3\chi_7\oplus3\chi_8$
  has the trivial with multiplicity one, so the prime-pairing is $W=c\cdot I$ ($c=1$) by Aramata–Brauer —
  the off-diagonal conspiracy is forbidden, not merely unobserved.
- *RH in range* $[C]$: the argument principle pins $N(3)=8$, all on the line; the family follows with
  positive Weil/Li coefficients.
- *The K-modulus and positivity* $[C]$: $K_L$ as the Aion's structure function; the void-pressure positivity
  recomputed on $\chi_8$'s own cubic zeros (Hankel positive through $m=5$); and the Weil/Li coefficients read
  from the **prime side** ($-L'/L$ at $s=1$, no zeros) $\lambda_1\dots\lambda_{10}=4.3\dots155.4>0$ — genuine
  arithmetic positivity, not the spectral tautology.
- *The genome distribution* $[C]$: the value law $\{8:\tfrac1{168},0:\tfrac{63}{168},-1:\tfrac13,1:\tfrac{48}{168}\}$,
  the Born floor $a_p\ge-1$ (annihilation on the trit class, one prime in three), verified to $61$-digit primes.
- *The second road* $[T/C$, Balashov$]$: the finite-level $\tilde M_N$ and its closed form; **Theorem M74**
  (skeleton zeros $\to$ Riemann zeros, by Rouché, conditional on simplicity); the Re-Bound carried in
  sign-count / buoy form $B_N=0$ (edge-gap floor retracted — its failure is the GUE fingerprint of $3\perp7$;
  $B_N=0$ verified for all $N\le70$), with the Levinson–Conrey link.
- *The two roads, one classical wall* $[T+C$, joint$]$: both the operator/de Branges road and the
  $\tilde M_N$/sign-count road reduce to the **Weil positivity** $W=\mathrm{ARCH}-\mathrm{PRIME}\ge0$ (Weil
  1952; Bombieri) $=\mathrm{GRH}(\psi)=$ the off-diagonal prime-pair; $W\ge0$ from the primes *is* RH, gated
  by the no-go.
- *The primes in the zeros* $[C]$: $F(x)=\sum_n\cos(x\gamma_n)$ resonates at $x=\log p^k$ to $\sim10^{-4}$
  (first $1200$ zeros) and nowhere else; composites flat — the experimental face of the no-go.
- *GUE spectral statistics* $[C]$: the computable weight-$6$ avatar of $\chi_8$ (a degree-$2$ level-$7$
  newform, $a_2=-10$) gives $369$ zeros to height $300$ with unfolded spacings KS-to-GUE $=0.053$ (not
  rejected), KS-to-Poisson $=0.334$ (rejected), level repulsion $P(s<0.3)=0.016$ — the family spectrum is
  quantum-chaotic (GUE), consistent with $\mathrm{Re}=\tfrac12$ as the Lyapunov-$\tfrac12$ line
  (Berry–Keating). By universality the weight-$0$ genome would match.
- *External validation* $[C]$: every analytic invariant of $\chi_8$ — conductor $3^{10}7^{10}$, field
  discriminant $3^6 7^8$, orthogonal type, character, root number $+1$ — matches the LMFDB Artin
  representation `8.16679880978201.21t14.b.a` (§A.4.4). The object is real, classical, and catalogued.

**Standard theory invoked $[T]$.** De Branges canonical systems and Hermite–Biehler; Li's criterion
(1997); CM propagation (Deligne; Shimura–Taniyama); Aramata–Brauer (holomorphy of $\zeta_K/\zeta$); the
de Bruijn–Newman constant with $\mathrm{RH}\iff\Lambda\le0$ and Rodgers–Tao's $\Lambda\ge0$ (2020); Baker's
theorem; the Cayley transform; Davenport–Heilbronn (1936).

**Interpretive $[R]$.** The identifications *light cone $\leftrightarrow$ CM torus*, *dark cone
$\leftrightarrow$ GUE*; build/annihilation as forward/inverse; the flow as time. These are readings
consistent with the computed facts, not theorems.

**Open $[\mathrm{OPEN}]$.** $\mathrm{GRH}(\psi)=\mathrm{RH}(\chi_8)=$ the survival of the cell's positivity
across the infinite flow. The four faces of §B.10 are this one statement, and both roads (§B.8) reduce to it.

**The no-go, stated precisely $[$joint$]$.** A finite-rank object cannot reproduce the prime alphabet
$\{\log p\}$ ($\mathbb Q$-independent, Baker). Part II does not contradict this: the Aion is not a finite
operator but a finite cell carried by an infinite flow, and the prime data lies in the flow's *variation*
(§B.3.4). §B.9 makes the boundary quantitative — the density is geometric and free to $\pm O(1)$ at all
heights, the positions cost $\pi(\sqrt{T/2\pi})\to\infty$ primes, and the primes fall directly out of the
zero positions (the Fourier-duality). The no-go bounds what *either* road can do — neither margin closes the
survival by itself — and is consistent with the finite cell's positivity being **necessary but not
sufficient**. The one route through it is the positive-weight motive of §B.5.5.

**Provenance.** *First-party (this work):* the cone counts and zero-divisors, the genome statistics, the
void-pressure Hankel on $\chi_8$'s zeros, the Fourier-duality and the no-go cost curve. *Balashov:* the
$\tilde M_N$ operator, Theorem M74, the edge-gap data (the sign-count reformulation and the bridge/floor
analysis are joint). *Reproduced on the 32 GB machine, cited as such:* the CM check, the Hecke realization,
the Sato–Tate test, the argument-principle pinning. *Classical, cited:* Davenport–Heilbronn, Li, de Branges,
Baker.

---

## §B.12 — Conclusion

Part II has anatomized the Riemann Hypothesis of one explicit L-function. The generating machine is
**finite** — a gate of six classes, an octonion light cone and a sedenion dark cone of fifteen Fano
matroids, a void operator with an exact sum-of-squares positivity. That finite cell is **unwound** by the
time-reversal arrow into an infinite, never-closing **flow** — a de Branges canonical system — and the
flow never closes because the trit and the Singer cycle are coprime and refuse to resolve. The **Euler
product** is the necessary binding that holds the flow's spectrum to the line, proved by a function that
lacks it and fails. The wall that binding leaves is **forced** to be classical and abelian: GRH for one
explicit cubic Hecke character $\psi$, with no non-CM lever to reach it. And the single open statement —
that the cell's exact finite positivity survives the infinite flow — appears in **four equivalent,
grounded forms**: the Aion self-adjoint, the K-modulus pure, the Weil/Li coefficients positive,
$\mathrm{GRH}(\psi)$.

This operator road does not stand alone. A **second, complementary road** — Balashov's finite-level skeleton
operator $\tilde M_N$, with the skeleton zeros *proved* to converge to the true zeros (M74) and the Re-Bound
carried in robust sign-count form — reaches the same margin from the classical side. And a precise **no-go**
marks the boundary the two roads share: the geometry reaches the envelope — density, scale, spacing — for
free at every height, but the zero *positions* are the primes', and they fall, literally, out of the zeros
(the Fourier-duality, every resonance at a prime log). The only route through that boundary is to carry the
prime information in — a positive-weight motive for $\chi_8$ — which is RH itself.

We have not proved the Riemann Hypothesis, and we have marked at each step the line between what is
established and what is not. What Part II offers is the sharpest localization we can give: for this object,
RH is neither vague nor distributed — it is the **survival of an exact finite positivity across an
infinite, never-closing run**, and it is, equivalently, GRH for a single cubic Hecke character. The machine
is finite and known; the flow is necessary and forced; the balance is exact at every instant. The
Hypothesis is the one thing the structure does not settle — whether the balance, exact forever in the
finite, tips once across the infinite.

*Finite-flowed-infinitely: the line is whether the flow holds.*
