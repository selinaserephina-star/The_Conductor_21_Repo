# Appendix G — Pre-registration, scoring, and the block-cutoff certification method

**Merkabit Research · draft 2026-07-12 · Stenberg + Claude.** This appendix records the
protocol under which the pre-registered zero-predictions γ₁₃–γ₁₇ were scored, and the
block-cutoff method by which the marginal windows were certified. It is a *methodology* record
— every certificate cited is a finite arb-ball certificate, **not** RH or GRH.

## G.1 Axiom-L pre-registration

Each predicted zero is committed *before* the certification run:
- a **prediction** t_pred from the passport density law (no prime-side seed for the pure-
  prediction zeros);
- a **PRIMARY window** (the arb-ball bracket the engine will scan), and where the prediction
  sits near a bracket edge, an explicit **SECONDARY** window;
- the **verdict rule** (below), fixed in writing.

No window is moved, widened, or re-centred after the run; no selector is chosen post-hoc. The
pre-registration file hashes are frozen and match the shipped batch (prereg sha
`caf2326…f982fada`).

## G.2 Scoring — HIT / NEAR / MISS / bonus

For a certified zero γ (a finite `CERTIFIED_ZERO` arb-ball interval on Re = ½):

- **HIT** — γ lands inside the pre-registered **PRIMARY** window.
- **NEAR** — γ lands inside the pre-registered **SECONDARY** (adjacent) window, *and* the NEAR
  outcome was pre-committed in writing before the run; no rescue, no re-windowing.
- **MISS** — γ outside both registered windows.
- **bonus** — a certified zero beyond the pre-registered set (not scored for/against the law).

The score is on the **prediction vs. window**, not on the certification quality; a zero can be
a NEAR yet fully certified.

## G.3 Two-channel honesty (the rigor-upgrade rule)

A single pre-registered engine can return `UNRESOLVED` at the amplitude wall. Certifying such a
window afterwards is legitimate **only** as a *declared, separate channel*:

- **Channel A** — the frozen pre-registered engine (s26b modal-jets, K = 16, 80 M block cutoff,
  declared refinement r). Its verdict (`CERTIFIED` / `UNRESOLVED`) is recorded and **never
  backfilled**.
- **Channel B** — a post-registration rigor upgrade with a **strictly tighter bound** (here the
  block cutoff 80 M → 120 M, §G.4). It may certify a Channel-A `UNRESOLVED` window, reported
  as its own channel. **Scoring stays frozen** (a Channel-B certification does not promote a
  NEAR to a HIT).

Recorded discipline (R-506): the pass-2 addendum's Taylor-remainder hypothesis was tested and
**falsified** (refining r 0.1 → 0.05 did not move the floor); the correct diagnosis was the
Rankin-tail-at-cutoff, which §G.4 acts on. Hypothesis → falsify → correct-diagnosis is recorded
openly.

## G.4 The block-cutoff certification method (R-115)

The s26b certification floor decomposes as
`non_poly_budget = band + U₁₇_r + mtail`, and is **~100 % the Rankin d₈ tail** `δc(> block
cutoff)`: the K jet-order term (~1e-16) and the mode band (~4e-13) are negligible against it.
Therefore the lever is the **block cutoff**, not K and not N_live:

- extending the block-sum coefficient table **80 M → 120 M** drops the floor
  **4.05e-9 → 1.98e-11** (× 210);
- the windows recertify **from cached jets** by exact **halfwidth-differencing** — the
  radius / U₁₇ / mtail contributions carry S(T)-free, so no 18 h engine re-run is needed.

This is what pushes the certification past the amplitude floor that stalled Channel A.

## G.5 The γ₁₃–γ₁₇ batch, scored

| ref | zero | prediction | window (grade) | channel | verdict |
|---|---|---|---|---|---|
| R-110 | γ₁₃ ∈ [4.081, 4.087] | 4.123 | PRIMARY | A (K16, 16 M, pass 1) | CERTIFIED / **HIT** |
| R-111 | γ₁₄ ∈ [4.357, 4.379] | 4.353 | PRIMARY | A (pass 1) | CERTIFIED / **HIT** |
| R-112 | γ₁₅ ∈ [4.548, 4.550] | 4.580 | PRIMARY | A UNRESOLVED → **B** (80→120 M) | CERTIFIED / **HIT** |
| R-113 | γ₁₆ ∈ [4.692, 4.696] | 4.803 | SECONDARY (4.694 is 9/1000 below PRIMARY edge 4.703; **NEAR pre-committed**) | B | CERTIFIED / **NEAR** |
| R-114 | γ₁₇ ∈ [4.886, 4.890] | ≈ 4.887 | unregistered **bonus** | B | CERTIFIED / bonus |

Net: **3 HIT + 1 NEAR (pre-committed) + 1 bonus**, γ₁₅–₁₇ via the declared Channel B. All
IB-audit pending; the grades above are ours-as-scored under this protocol. Not RH/GRH.

— Selina + Claude, 2026-07-12
