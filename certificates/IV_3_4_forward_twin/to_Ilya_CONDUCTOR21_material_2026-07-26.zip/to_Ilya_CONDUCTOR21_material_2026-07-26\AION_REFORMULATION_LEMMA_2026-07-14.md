# The Aion Reformulation Lemma

**Merkabit Research · 2026-07-14 · Stenberg + Claude.** A stated, proven theorem: *given* a
matrix de Branges canonical system representing $\Lambda(s,\chi_8)$, self-adjointness of the Aion is
equivalent to $\mathrm{GRH}(\chi_8)$, through five intermediate forms. This is **Level A** of the
reformulation checklist (2026-07-12) — the bounded, citeable half. It is **not** a proof of RH/GRH;
the existence of the representing system (C1–C3) is stated separately as the open problem, and the
global positivity itself (Level B) is the wall, left exactly OPEN. Refines **R-011**; leaves
**R-209** untouched.

---

## 0. What this lemma is, and is not

The Aion equivalence of Part II (§B.3.3, §B.6.2) is a *chain*
$$
\mathcal A \text{ self-adjoint}\ \Longleftrightarrow\ E\ \text{Hermite–Biehler}\ \Longleftrightarrow\ H(t)\succeq0\ \forall t\ \Longleftrightarrow\ |K_L|{=}1\ \text{only on}\ \mathrm{Re}\,s{=}\tfrac12\ \Longleftrightarrow\ \lambda_n\ge0\ \forall n\ \Longleftrightarrow\ \mathrm{GRH}(\chi_8).
$$
Two statements get conflated under "make the Aion a theorem," and the entire value of this note is
keeping them apart:

- **The equivalence (this lemma).** *If* a matrix de Branges canonical system representing
  $\Lambda(s,\chi_8)$ exists, *then* the six conditions above are equivalent. This is a genuine
  theorem — standard matrix de Branges theory + the Li criterion for the Selberg class — and proving
  it proves **nothing about the truth** of any one condition. It relocates $\mathrm{GRH}(\chi_8)$; it
  does not decide it.
- **The construction and the survival (not this lemma).** That such a system *exists and is built
  forward from arithmetic* (C1–C3, §5) is open. That $H(t)\succeq0$ *actually holds* (Level B) **is**
  $\mathrm{GRH}(\chi_8)$ — the wall. Neither is claimed here.

The lemma is therefore stated **conditionally on a hypothesis (H)**, and the honesty of the whole
exercise lives in that hypothesis being displayed, not hidden.

---

## 1. Hypothesis (H): the representing system

**(H)** *There is a trace-normed matrix Hamiltonian $H(t)=H(t)^\ast\in\mathrm{Mat}_{8}(\mathbb R)$,
$t\in[0,\infty)$, locally integrable, with associated canonical system*
$$
\frac{d}{dt}Y(t,z)=z\,\mathcal J\,H(t)\,Y(t,z),\qquad
\mathcal J=\begin{pmatrix}0&-I_4\\ I_4&0\end{pmatrix},
$$
*whose Weyl–Titchmarsh / de Branges structure function $E(z)$ is entire of matrix type, with*
$$
\Lambda(\tfrac12-iz,\chi_8)=A(z)-iB(z),\qquad E=A-iB,\qquad A,B\ \text{real entire},
$$
*so that the completed L-function $\Lambda(s,\chi_8)$ is the symmetric part of $E$ and the non-trivial
zeros of $\Lambda(s,\chi_8)$ are exactly the spectrum of the multiplication operator $\mathcal A$ in
the de Branges model space $\mathcal H(E)$.*

Two remarks fix the status of (H).

1. **(H) is not positivity.** (H) posits only that a canonical system *represents* $\Lambda$ — that
   the map $s\mapsto E(s)$ carries the functional equation and the zero set. It does **not** posit
   $H(t)\succeq0$. When $H(t)$ is indefinite, $\mathcal H(E)$ is a Pontryagin/Kreĭn space (indefinite
   metric), $\mathcal A$ is symmetric but not self-adjoint in a Hilbert space, and $E$ has zeros off
   the line. So (H) is compatible with the *failure* of every condition in §2 — which is precisely
   why assuming (H) does not assume $\mathrm{GRH}$.

2. **The admitting hypotheses hold for $\chi_8$.** That a self-dual L-function of the Selberg class
   admits a de Branges representation is the de Branges framework [dB68]. $\chi_8$ meets the admitting
   conditions:
   - *Self-dual:* $\varepsilon=+1$ and $\chi_8$ is an orthogonal (real) representation, so
     $\Lambda(s,\chi_8)=\Lambda(1-s,\chi_8)$ with real coefficients (§A.4.2).
   - *Degree, gamma, conductor:* degree $8$, $\gamma=\Gamma_{\mathbb C}(s)^4$, conductor $21^{10}$
     (§A.4) — a standard Selberg-class datum.
   - *Entirety (the one non-formal point):* $L(s,\chi_8)$ is entire. **Unconditionally** so via the
     cubic-Hecke realization $L(s,\chi_8)=L(s,\psi)$ of §B.5.3 (an automorphic $\mathrm{GL}_1$
     L-function over the CM/cubic field is entire), which removes the Artin-holomorphy caveat for
     *this* L-function. Absent that identification the entirety is the standard Artin conjecture for
     $\chi_8$; with §B.5.3 it is a theorem.

   What is **not** free — and is the reason (H) is a hypothesis and not a citation — is that the
   representing $H(t)$ is *the one seeded by the §B.2 cell* and is built **forward** (§5, C1–C3). The
   lemma does not need that stronger fact; it needs only that *some* representing system exists, and it
   proves the equivalence for any such.

---

## 2. The lemma

> **Aion Reformulation Lemma.** Assume (H). Let $Z=\{\rho:\Lambda(\rho,\chi_8)=0\}$ be the non-trivial
> zero set, $E$ the structure function, $H(t)$ the Hamiltonian, $\mathcal A$ the model operator, and
> $$
> K_L(s)=E(s)^{-1}E^\ast(s),\qquad E^\ast(s)=\overline{E(\bar s)}^{\,\top},\qquad
> \lambda_n=\sum_{\rho\in Z}\Big[1-\big(1-\tfrac1\rho\big)^{n}\Big]\ (n\ge1).
> $$
> Then the following are equivalent:
> $$
> \textbf{(a)}\ \mathcal A\ \text{is self-adjoint in the Hilbert-space model}\quad(\text{equiv. the metric of }\mathcal H(E)\text{ is positive});
> $$
> $$
> \textbf{(b)}\ E\ \text{is matrix Hermite–Biehler: } E(z)^\ast E(z)-E^\ast(z)^\ast E^\ast(z)\succ0\ \text{on } \mathrm{Im}\,z>0;
> $$
> $$
> \textbf{(c)}\ H(t)\succeq0\ \text{for a.e. } t\in[0,\infty);
> $$
> $$
> \textbf{(d)}\ K_L(s)\ \text{is unitary exactly on } \mathrm{Re}\,s=\tfrac12\ \text{(the 8-dim Schur/purity form): } K_L^\ast K_L=I \iff \mathrm{Re}\,s=\tfrac12;
> $$
> $$
> \textbf{(e)}\ \lambda_n\ge0\ \text{for all } n\ge1\quad(\text{Weil/Li positivity});
> $$
> $$
> \textbf{(f)}\ \mathrm{GRH}(\chi_8):\ Z\subset\{\mathrm{Re}\,s=\tfrac12\}.
> $$

The proof routes every condition through the single pivot **(f)** — *all non-trivial zeros lie on the
critical line* — so the statement is a six-spoke wheel, not a fragile linear chain.

---

## 3. Proof

Throughout, "on the line" means $\mathrm{Re}\,s=\tfrac12$, i.e. $z\in\mathbb R$ under
$s=\tfrac12-iz$. The zeros of $E$ in the $z$-plane are the images of $Z$; by the functional equation
(§B.4.1) $Z$ is symmetric under $s\mapsto1-s$, i.e. under $z\mapsto\bar z$, so a zero off the line
occurs in a conjugate pair $\{z_0,\bar z_0\}$ with $\mathrm{Im}\,z_0\neq0$.

**(a) $\Leftrightarrow$ (c).** Under (H) the model operator $\mathcal A$ is the canonical-system
differential operator on $\mathcal H(E)$. When $H(t)\succeq0$ a.e., the associated symmetric form is
non-negative, $\mathcal H(E)$ is a genuine Hilbert space, and $\mathcal A$ (with the de Branges
boundary condition) is self-adjoint with real spectrum [dB68, §§40–42; Rem18, Ch. 2–4]. When $H$ is indefinite
on a set of positive measure, the form is indefinite, $\mathcal H(E)$ carries an indefinite metric,
and $\mathcal A$ admits no self-adjoint realization in a Hilbert space. Hence (a) $\Leftrightarrow$
(c).

**(c) $\Leftrightarrow$ (b).** This is the de Branges structure theorem for canonical systems in the
matrix case: the transfer matrix of a system with $H(t)\succeq0$ is $\mathcal J$-contractive in the
upper half-plane, and its structure function $E$ is (matrix) Hermite–Biehler; conversely every matrix
Hermite–Biehler $E$ arises from a unique trace-normed $H(t)\succeq0$ (the inverse spectral / Krein–de
Branges correspondence) [dB68, Thm 40; ArD08, Ch. 2, matrix HB class]. Indefiniteness of $H$ on a
positive-measure set is equivalent to failure of the upper-half-plane inequality in (b).

**(b) $\Leftrightarrow$ (f).** Matrix Hermite–Biehler for $E$ is, by definition, the strict inequality
$E^\ast(z)^\ast E^\ast(z)\prec E(z)^\ast E(z)$ throughout $\mathrm{Im}\,z>0$; equivalently every zero
of $\det E$ lies in the closed lower half-plane $\mathrm{Im}\,z\le0$. Since $\det E=0$ exactly at the
zeros of $\Lambda(\tfrac12-iz,\chi_8)$, and these are $\{z(\rho):\rho\in Z\}$, (b) says every such $z$
has $\mathrm{Im}\,z\le0$. But $Z$ is $z\mapsto\bar z$-symmetric, so "all in the closed lower half-plane"
forces "all on $\mathbb R$": a genuine off-line zero $z_0$ would force its conjugate $\bar z_0$ into
the *upper* half-plane, contradicting (b). Hence (b) $\Leftrightarrow$ $Z\subset\{\mathrm{Re}\,s=\tfrac12\}$,
which is (f).

**(d) $\Leftrightarrow$ (f).** From $K_L=E^{-1}E^\ast$: on the line $z\in\mathbb R$ one has
$E^\ast(z)=\overline{E(\bar z)}^{\top}=E(z)^{\ast}$ in the sense that numerator and denominator are
adjoint, so $K_L(s)^\ast K_L(s)=I$ identically on $\mathrm{Re}\,s=\tfrac12$ — the modulus-1 locus
*contains* the line for free (this is the content of §B.6.1). The substantive direction is *purity*:
$K_L^\ast K_L=I$ holds **only** on the line iff there is no off-line coincidence. A pole/zero of
$\det K_L$ off the line — i.e. an off-line zero $\rho$ of $\Lambda$ — produces, via the functional
equation, a paired point $1-\bar\rho$ at which $K_L$ is again unitary, placing a modulus-1 point off
the line. Conversely if $Z$ is on the line, $K_L$ is a matrix inner function whose only unitary locus
is the boundary $\mathrm{Re}\,s=\tfrac12$. So (d) $\Leftrightarrow$ (f). (This is the 8-dimensional
Schur/scattering form of purity; the argument is the matrix version of the scalar
$|K_L|=1\Leftrightarrow\mathrm{Re}\,s=\tfrac12$, using $K_L^\ast K_L=I$ in place of $|K_L|=1$.)

**(e) $\Leftrightarrow$ (f).** This is the Li criterion in the Bombieri–Lagarias form, valid for any
L-function in the Selberg class (which $\Lambda(s,\chi_8)$ is, by §1 remark 2). Li's theorem states:
$$
\lambda_n=\sum_{\rho\in Z}\Big[1-\big(1-\tfrac1\rho\big)^n\Big]\ge0\ \text{for all } n\ge1
\quad\Longleftrightarrow\quad Z\subset\{\mathrm{Re}\,s=\tfrac12\}
$$
[Li97; BoL99]. Note the Li coefficients are **scalar** (a sum over the zero set), so no matrix
subtlety enters here: the matrix structure lives entirely in (a)–(d), and (e) meets (f) on the common
scalar pivot. Hence (e) $\Leftrightarrow$ (f).

**(f) $=$ GRH.** $\mathrm{GRH}(\chi_8)$ is by definition the statement $Z\subset\{\mathrm{Re}\,s=\tfrac12\}$.
Thus (f) $\Leftrightarrow$ (a)–(e), and all six are equivalent. $\qquad\blacksquare$

---

## 4. Corollary (local purity is free; the survival is the wall)

The **local** half of (d) is a theorem, unconditionally and with no reference to (H): at every prime
$p$ the Satake parameters of $\chi_8$ are the eigenvalues of $\rho_8(\mathrm{Frob}_p)$, roots of unity
of modulus $1$ (Ramanujan is automatic for an Artin L-function, §B.6.3), so every local factor of
$K_L$ is unitary. The lemma's equivalence therefore reads, in one line:
$$
\boxed{\ \mathrm{GRH}(\chi_8)\ \Longleftrightarrow\ \text{per-prime unitarity assembles into global unitarity of } K_L \text{ on the line.}\ }
$$
The assembly — equivalently $H(t)\succeq0$ for **all** $t$, equivalently $\lambda_n\ge0$ for **all**
$n$ — is Level B, the wall (§B.6.3). The lemma does not touch it. What the lemma *does* is certify
that these are all **the same** condition, matrix-de-Branges-exactly, so that any future proof of one
is a proof of $\mathrm{GRH}(\chi_8)$ and no more is owed.

---

## 5. The open problem this lemma does *not* close (C1–C3)

The lemma is conditional on **(H)**. Discharging (H) *forward* is the genuine novel content, and it is
**open**:

- **C1 — existence.** A canonical system $H(t)\succeq0$ on $[0,\infty)$, finite $8\times8$ cell at each
  $t$, built forward from the §B.2 cell + gate (the arithmetic), with entire matrix structure function
  $E$.
- **C2 — faithfulness.** $\Lambda(s,\chi_8)$ is exactly the symmetric part of that $E$ — the *right*
  system, with the correct functional equation and zero set.
- **C3 — the circularity guard (non-negotiable).** $H(t)$ must be built from the cell and gate, **not**
  from the zero list. A system assembled from the zeros reproduces them trivially and proves nothing;
  the entire content is a forward build "without knowing where its spectrum will fall" (§B.3, line
  1065–1068).

**Honest difficulty read (unchanged from the checklist).** C1–C3 amount to constructing a
Hilbert–Pólya operator for $\chi_8$ from arithmetic — the same order of difficulty as the problem the
program orbits; possibly genuinely open. The forward construction is realized only for the reachable
bench $\chi_6$ (R-212), where primes $\to$ moments $\to$ Hankel-PD $\to$ self-adjoint $\to$ spectrum
closes numerically; $\chi_8$ itself ($\sim10^{11}$ coefficients) is out of computational reach. The
in-range evidence — K-modulus Hankel positivity on $\chi_8$'s own zeros through $m=17$ (§B.6.4, R-206),
and Li positivity $\lambda_1,\dots,\lambda_{10}>0$ from the **prime side** (§B.6.4, non-circular) —
supports the *plausibility* of the wall's positivity but is **not** a discharge of (H) and not the
lemma.

---

## 6. Register action

- **R-011** (canonical Aion, was "construction, paper-grade") — **split**:
  - **R-011a — the Aion Reformulation Lemma (this note): THEOREM**, conditional on (H). Grade: proven
    (matrix de Branges [dB68, ArD08] + Li/Bombieri–Lagarias [Li97, BoL99] + §B.5.3 entirety). Not RH.
  - **R-011b — the forward construction (C1–C3): OPEN.** Realized for $\chi_6$ (R-212); $\chi_8$ out of
    reach. Circularity guard front and centre.
- **R-209** (the wall: $\mathcal A$ self-adjoint $\Leftrightarrow$ Weil/Li $\Leftrightarrow$ GRH) —
  **unchanged, OPEN.** The lemma sharpens *what* R-209 asserts (it is now a proven equivalence of six
  forms under (H)); it does not move its status.
- **R-210/211/212** (the explicit operator, de Branges branch) — the lemma is the analytic statement
  the operator branch instantiates: R-210 builds a system *backward* from the zeros (frame), R-011a
  says *any* representing system obeys the equivalence, R-011b/C1–C3 is the forward build still owed.

Nothing here is RH or GRH. The lemma is bounded, finishable, and finished; the two things it borders —
the forward construction and the global positivity — are stated as open in their own words.

---

## References

*(Verified; the paper's master list may renumber these tags.)*

- [dB68] L. de Branges, *Hilbert Spaces of Entire Functions*, Prentice-Hall, 1968 (Hermite–Biehler
  class; canonical systems; Thms 40–42).
- [ArD08] D. Z. Arov and H. Dym, *J-Contractive Matrix Valued Functions and Related Topics*,
  Encyclopedia of Mathematics and its Applications **116**, Cambridge University Press, 2008 (matrix
  $J$-inner functions, matrix Hermite–Biehler class, reproducing-kernel spaces; the inverse spectral
  correspondence for trace-normed canonical systems).
- [Rem18] C. Remling, *Spectral Theory of Canonical Systems*, De Gruyter Studies in Mathematics
  **70**, De Gruyter, 2018 (self-adjoint realizations in Hilbert space; transfer matrices and de
  Branges spaces; the Hilbert-space vs. indefinite-model dichotomy).
- [Li97] X.-J. Li, "The positivity of a sequence of numbers and the Riemann hypothesis," *J. Number
  Theory* **65** (1997), 325–333.
- [BoL99] E. Bombieri and J. C. Lagarias, "Complements to Li's criterion for the Riemann hypothesis,"
  *J. Number Theory* **77** (1999), 274–287 (Selberg-class form).

*— Selina + Claude, 2026-07-14*
