# Figures — caption & placement sheet

*The Conductor-21 World.* Five figures, in `figures/` as standalone SVG (paper palette: black + one blue).
Insert each SVG into Word directly (Insert → Pictures), or export PNG from `Figures.html` (right-click →
Save image). Captions below are publication-ready.

---

**Figure 1 — `figures/fig1_babushka_shells.svg` — place in §A.7 (Part I).**
The conductor shells of the family. Each L-function sits on a ring at radius proportional to
log₂₁(conductor); the conductors nest as powers of 21. The 21⁴ ring is the CM (Mumford–Tate) torus,
carrying the quark χ₃, its conjugate, and their CM-twins; the genome χ₈ sits on the 21¹⁰ shell, and its
twin escapes beyond. Inner ring = unitary (non-self-dual); outer nodes = orthogonal.

**Figure 2 — `figures/fig2_scaling_law_fit.svg` — place in §A.7 (Part I).**
The scaling law verified. Predicted zero-density ρ = (1/2π)[log N + d·log(T/2π)] against the density of the
computed zeros, for each member; all points fall on y = x — one law across a factor of 16 in density (mean
ratio 1.07 ± 0.08).

**Figure 3 — `figures/fig3_tensor_tower.svg` — place in §A.5 (Part I).**
The tensor tower of the quark. Each symmetric power Sym^k χ₃ decomposes into the six irreducibles; all six
appear by Sym⁴, after which the tower only re-mixes them. Because PSL(2,7) is finite, the infinite tower
collapses onto the six L-functions (χ₆ = Sym²χ₃; Born relation χ₈ = |χ₃|² − 1).

**Figure 4 — `figures/fig4_two_cones.svg` — place in §B.2.2 (Part II).**
The two cones. The octonion light cone is the Fano plane F₇ = PG(2,2) (a division algebra, no zero-divisors
— the build); its Cayley–Dickson doubling, the sedenion dark cone, is PG(3,2) — the Fano plane doubled,
fifteen Fano sub-planes, the first algebra with zero-divisors (84 = 4·21 products) — the annihilation.

**Figure 5 — `figures/fig5_ascent_to_e7.svg` — place in §A.8 (Part I).**
The ascent from the void to E₇. Each rung built from the one below, all seeded by the quark χ₃: ζ → χ₃ →
the six → Sp(6,2) = W(E₇)/±1 (via the 28 bitangents) → the E₇ minuscule 56. Lower rungs computed and
verified; the E₇ automorphic L-function at the top is structural only.

**Figure 6 — `figures/fig6_primes_in_zeros.svg` — place in §B.9 (Part II).**
The primes fall out of the zeros. The Fourier spectrum of the zero heights, F(x) = Σₙ cos(x·γₙ) over the
first 1200 Riemann zeros, resonates at exactly x = log pᵏ and nowhere else: tall peaks at primes, shorter
at prime powers (weight ∝ Λ(n)/√n), nothing at composites. No common period — the zeros are incommensurate,
never a lattice. The experimental face of the no-go: the zero positions *are* the primes.

---

*Coverage: Part I gets Figures 1, 2, 3, 5 (scaling, tensor tower, ascent); Part II gets Figures 4 (the two
cones) and 6 (primes in the zeros). All data matches the verified computations in the text.*
