# What we need from Ilya — consolidated, 2026-07-12

**From:** Selina + Claude (Merkabit) · **For:** Ilya Balashov
Everything open across the joint program, in one place, ordered by how much it blocks. Backing
detail and evidence are in the claims register (`CLAIMS_REGISTER_DRAFT_2026-07-08.md`, v0.8,
§D.6 "IB action ledger"). **Nothing certified is waiting on you** — these are unlocks, decisions,
registry wording, and one-line confirmations. Not RH/GRH anywhere.

---

## Tier 1 — the one real unlock (open mathematics)

**1. Your chart65 `Q2` annihilator-elimination script** (your Claude's, 2026-07-10). *[R-408/409]*
- **What it unlocks:** the full all-504-chart (and both-class) closure of the **Assembly
  Theorem** — i.e. the (S)/(S′) sweep, upgrading it from "certified on chart65" to a theorem on
  the whole rank-7 locus.
- **What we already did (07-12, self-serve):** proved the assembly obstruction is
  chart-independent *by construction* (the T50018 Setup is built per-class, before the chart
  loop); confirmed it two ways (Singular: the Mobs obstruction is chart-free `= V(Qproxy)`; GAP:
  `dim(K+FK+F²K)` is a chart-free function of the throat, validated reproducing dim 23 and dim
  21); all 504 charts are admissible (T50018, audited). So the closure reduces to **pinning `Q2`
  in chart coordinates on `{q=0}`**. We located `T50O2_QValue` (the admissibility `q`) but did not
  reconstruct your exact chart-coordinate elimination.
- **What we need:** your `Q2` elimination script (or the chart-coordinate parameterization it
  uses). With it, we finish the sweep. Progress + exact plug-in point:
  `T50019_503chart_closure_progress_2026-07-12.md`.

---

## Tier 2 — decisions only you can make

**2. Twin route A vs B.** *[R-311, R-109a]* — Largely **moot**: you chose B, we executed it, and
the 07-12 audit closed twin gaps 17/19/20 (F_full precision-verified). The only live question is
whether you ever want the optional future **t≈6.5–8 zero table** (Route A; needs a 256 GB box +
quota bump, ~$3–5). Not proof-critical. **Confirm: park Route A?**

**3. Two-channel report framing.** *[R-112/113, R-506]* — For γ₁₅/γ₁₆ the frozen pre-registered
engine returned UNRESOLVED (amplitude wall); a declared post-registration extended-tail
(80M→120M, strictly tighter bound) certified them, reported as a separate channel with scoring
left frozen. **Confirm this is protocol-sound as recorded, or say how you'd frame it.** (No math
hinges on it — the zeros are certified either way.)

---

## Tier 3 — registry lines / grades (your authoritative wording; we own the material)

**4. CHI8-INTERVAL-1** *[R-313]* — the χ₈ interval theorem. Your validator is already all-pass and
we own all material + computation; we need your **formal registry line**.

**5. ECL-FAMILY-1** *[R-307]* — closure of the 45-gap family law. Step-3B passed our side, full
computation done; we need your **closure verdict**.

**6. γ₁₃–γ₁₇ grades** *[R-110–115]* — we go with our grades (3 HIT + 1 NEAR pre-committed + 1
bonus) documented in the new grading-protocol **Appendix G** (`Paper_AppG_grading_protocol.md`).
**Your stricter markup is welcome but not blocking.**

**7. m=17 K-modulus wording** *[R-206]* — confirm the **CERTIFIED-FINITE** wording extends through
m=17 (positivity robust at all 512 corners).

**8. Register markup** — anywhere across the register you'd **grade stricter** than we did. Grade
disputes are what the register is for.

**9. R-201 naming** — a name for the "smoothed AFE for Λ(s,χ₈)" (`[IB name?]`).

---

## Tier 4 — one-line confirmations that unlock finished results

**10. M74 convention one-liner.** *[R-204]* — the handshake is **confirmed by computation** (our
θ-AFE `M̃_N` reproduces your `M₃` to ~1e-20 on the γ₁ contour, up to the stated `Ξ/2` factor). We
need only your **exact normalization convention** in one line. **Unlocks** presenting the
γ₁…γ₄₀ Rouché table as Part II's centerpiece "in the registry."

**11. H₂ symbol orientation.** *[R-406]* — the mathematics is fully pinned by us (H₁ = point-
stabilizer / throat class, H₂ = plane-stabilizer / Fano-dual). We need only which Fano-dual role
your symbol "H₂" names — **notation, not mathematics** (Part IV §5). If your convention is the
other way, we swap the two symbols; nothing else changes.

**12. Titles (FYI — override if you like).** We set two cite-able titles: the canonical-key
result = **"The Still-Point Key Theorem"** (R-406); the door result = **"The Door-Uniqueness
Criterion"** (R-410). Your evocative titles remain the section headers. Say if you'd prefer
different formal names.

---

*Backing: claims register v0.8 §D.6. Bottom line — one real unlock (item 1), two decisions
(2–3), the rest is your signature on work already done or a one-line convention. — S. + C.,
2026-07-12*
