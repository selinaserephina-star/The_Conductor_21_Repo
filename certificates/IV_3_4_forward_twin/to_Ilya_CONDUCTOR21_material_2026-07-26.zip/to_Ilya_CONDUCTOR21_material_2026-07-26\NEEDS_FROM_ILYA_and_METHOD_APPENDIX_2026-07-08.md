# What the paper needs from Ilya — and the Method Appendix built around his protocol

**2026-07-08, refreshed 2026-07-11 · companion to Conductor21_World_ARCHITECTURE_v2 · for sending to IB**
**Status markers ✔ added after IB's 07-08 reply: ✔ = answered/committed in that reply;
open items are the working list. §G (07-11) adds the items that moved after his reply:
γ₁₃–₁₇ certified, m=17 ledger, chart65 CERTIFIED, chi7 done, the twin-route decision.**

## A. Registry lines — GRADED OUR SIDE (07-11 correction); IB markup refines wording, does NOT gate

*These are our computation on our genome; nothing is missing to state them. Listed here so
IB can tighten wording in his markup pass, not as blockers.*

1. **CHI8-INTERVAL-1** — the χ₈ interval theorem [R-313] is ours (arb jets, 16 intervals,
   min margin 6.6e−7); **his validator already ALL-PASSED on the shipped bytes**, its one
   his-component (P2.3 tail lemma) is already CLOSED [R-312], and **IB graded it CERTIFIED
   on 07-08**. We write the registry line CERTIFIED; he refines the exact audit-status
   wording. Not a blocker.
2. **ECL-FAMILY-1** — the 45-gap fit [R-307] is our data (Step-3B PASS) → **MEASURED, we
   grade it now**. The comb law it confirms is IB's prior closed theorem [R-301/302] — we
   cite it. His markup only elevates "measured fit" → "family-theorem" wording. Not a blocker.
3. Already closed and citable as-is: P2.3 tail (his FULL LOCAL AUDIT), the side-lemma
   stack, TIGHT-GAP-REFINEMENT (+ erratum), the assembly theorem T50018, D.3b.

## B. One-line confirmations that unlock finished results

4. **M74 skeleton handshake** — the γ₁…γ₄₀ Rouché table is computed on our canonical
   θ-AFE, but its **A-half** `sup_C|Ξ−M̃_N|` cannot be certified as *his* M74 without his
   formal M̃_N spec (the B-half `inf_C|Ξ|` is entirely ours, CHI8_MAIN_JETS engine). We do
   NOT guess normalizations (the 2⁴ lesson). **Exact ask (from our 07-03 reply,
   `M74_rouche_workpack_received/Reply_..._need_MN_spec`):** (i) mode functions/weights
   (J_n convention + smoothing), (ii) truncation rule N(t) (fixed vs t-dependent RS
   length), (iii) normalization vs the completed Ξ we enclose (any 2^k/π^k conventions),
   (iv) 2–3 reference values M̃_N(t) at stated (N,t) to 15+ digits for engine
   cross-validation. Equivalently, a one-line "your θ-AFE **is** my M74 operator" (or the
   delta) suffices. Then the 40/40 table becomes Part II's two-roads centerpiece.
   **07-11 UPDATE from the M74_GAMMA1_N3 master (sha 56204ad6…) + dry-pilot:** substantial
   progress — (a) **γ₁ is closable BY US now**: IB's γ₁ N=3 adaptive-subpatch ball/tail
   Rouché cert is PASS (safety_ratio ≈2.4e16) and explicitly "pending independent audit"
   → our role; audit the shipped enclosures + cross-check vs our arc-chunk ball → γ₁
   DOUBLE-CERTIFIED [R-203]. (b) **Normalization item resolved**: target = Ξ/2, factor 2
   (the 2^k detail). REMAINING (now a formality): **the handshake is CONFIRMED BY
   COMPUTATION (07-11)** — we ran our own canonical θ-AFE at N=3 and it reproduces IB's M₃
   enclosures to ~1e-20 on the γ₁ contour (with the correct (πn²)^{−s/2}Γ(s/2,πn²) term, in
   his Ξ/2 factor-2 normalization). We don't need his operator — we HAVE the equal one. All
   that's left from IB: **a one-line confirmation of the exact convention** (factor-2 target
   Ξ/2, the "M₃^int" interval construction) so the 40/40 table ships as *his* M74 verbatim.
   γ₁ is already double-certified + independently audited our side [R-203].
5. **H₁/H₂ convention**: which Fano-dual role (point- vs plane-stabilizer) is his H₂.
   Names the canonical key concretely in Part IV §4.
6. **Registry names** for the new items: ✔ largely settled — IB's 07-08 reply uses
   T50019/T50019a and grades them (T50019a THEOREM; T50019 CONDITIONAL /
   SWEEP-IN-PROGRESS). Still open: titles for the canonical-key and door-criterion
   results.

## C. Computations only he can run (his pipelines)

7. **The T50019 sweep**: ✔✔ **chart65 now CERTIFIED** per his FINAL registry line
   (T50019-S″, 07-10): `dim(K+FK+F²K)=23 ⟺ Q₂(b)≠0`, Q₂ the Eisenstein exceptional
   quadric; Open2b(universal) and the rank<15 proxy both REFUTED; admissibility resolved
   (no gap). Assembly Theorem now publishes as CERTIFIED-on-chart65 / the **503-chart
   Hidx=2 sweep scope-reduced** (shared-Q₂ nonemptiness checks, not 503 eliminations).
   **Still needs from him:** the sweep verdict on the remaining 503 charts (+ Hidx≠2 and
   the second S₄ class) — EMPTY-everywhere upgrades the chart65 theorem to the full rank-7
   locus. Registered as R-408/R-409 (v0.7).
   **REFRAMED ASK (07-11): the compute is ours, not his.** Route D (kernel
   bilinearization) runs the whole 504-chart atlas in **~6 min at 0.7 s/chart** (Singular,
   our `routeD_v2.sing`). The only missing input is the **per-chart `Mobs` generator** —
   the T50019 obstruction matrix in his atlas parametrization (i2,j2,i3,j3,k3 / Hidx). So
   we ask him to **ship the generator (a definition), and WE run the sweep** and return the
   per-chart exceptional quadrics — a lighter handshake than "run the 503-sweep," with the
   computation on our side. (We hold chart65's Mobs only; deriving the rest via the
   chart-stabilizer symmetry is possible but convention-sensitive — the R-505 terrain — so
   we do it from his generator, not by guessing the relabeling.) EMPTY-off-quadric on all
   504 upgrades T50019 CONDITIONAL → full THEOREM.
   **EXACT FILES NEEDED (confirmed 07-11 from the C2H tarball `fe4f7f1c…`):** its driver
   `t50019_routeC2h_chart65_pair_heatmap.g` does `Read("t50019_routeC_defs.g")` and
   `Read("t50019_routeC_obstruction_provider.g")` — **those two GAP files are the missing
   dependency** (= the `t50o10_defs_only.g` bundle he already offered in the Route-D reply
   §4.2). Ship those two + the chart parameterization; then our Route-D driver sweeps the
   504-atlas in ~6 min. Nothing else blocks it.
8. Optional enrichments: M75 wall data for the Monge audit-separator (if he wants it
   in the appendix); any further zero-table extensions he considers worth registry
   grade.

## D. His formulation of the open analytic slot

9. **The Erdős–Turán bridge** — the one unpriced budget slot (window-tail rows,
   quantified ≤ few % of predicted). The paper should state it in HIS preferred
   formulation and naming, with whatever partial analytic results he wants recorded.
   This is Part III §4's closing paragraph and the program's forward pointer.

## E. The Method Appendix — dedicated to the protocol he built

✔ AGREED per IB 07-08: he writes the Registry Protocol appendix himself ("not just
administration — part of the mathematical discipline of the project") and will write
the container-hash case-law paragraph in his own words.

Title: **"Appendix C — The Registry Protocol (audit-grade computational
number theory)"**, with design attribution to I.B. explicitly (naming of the protocol
itself: his call — options range from neutral "the registry protocol" to eponymous).
Content plan, mostly assembled from HIS existing documents (listed so he can bless or
amend each):

  C.0 **Lineage**: the protocol descends from IB's Scar-Cat Master Theorem Registry
      (v8.4, June 2026: 264 proven entries, method/status columns, OSF deposit
      10.17605/OSF.IO/3TFNY, redescriptions-rejected policy, negative-results
      section) — cite as the ancestor; the joint paper's Claims Register (Appendix D)
      is its two-author descendant.
  C.1 **Package anatomy**: MANIFEST.json, SHA256SUMS (LF/UTF-8), outer sidecar,
      README_FOR_AUDITOR, in-package generators, deterministic rerun; the
      `<name>_<sha12>.zip` convention. [his Lemma 8 / D.3b practice]
  C.2 **Audit order**: verify shipped bytes FIRST, rerun second, compare numbers,
      regenerate sidecars only if bytes rewritten. [his audit-order note]
  C.3 **Passports and the no-fitting rule**: every prediction passport-derived; ρ
      never fitted; the transfer/fairness rule for cross-candidate claims.
      [his PASSPORT-DENSITY theorem + the Axiom-L protocol's transfer rule]
  C.4 **Status vocabulary**: the closure grammar (CLOSED AS CONDITIONAL ANALYTIC
      THEOREM / PASS candidate / CORROBORATIVE_PRIME_SEED_ONLY / EDGE_TAIL_CAVEAT /
      TAIL_COMPLETED_BY_* / NOT_CLAIMED lists on every artifact). A canonical
      glossary — needs his authoritative table.
  C.5 **Validators as first-class artifacts**: combiner, assembly validator,
      edge-tail and budget validators — shipped, hashed, rerun by the counterparty.
      (Needs: his consent to publish the scripts, license/attribution line.)
  C.6 **Predeclaration discipline**: variables and selection principles registered
      before computation; synthetic nulls mandatory; anti-fitting rules; failed
      variants retained in the log. Canonical anti-fitting demonstration: IB's
      free-Herglotz-cone interpolation diagnostic (registry X.8 — fits 1e−16
      in-sample, fails 1e16× out-of-sample; free positive weights = interpolation,
      not arithmetic structure).
  C.7 **Errata handling**: hashed artifact authoritative over prose; the erratum
      note as a registry object. [his TIGHT-GAP erratum as the template]
  C.8 **Case law (the appendix's teeth)** — four incidents where the protocol caught
      real errors, told by the catcher in each direction: the container-hash
      mismatch (HIS catch; we request 2–3 sentences in his words), the
      cover-message typo vs hashed CSV (our catch, his erratum), the 829× parser
      artifact (our catch, row-counts as the tell), and the rational-relation test
      voided by its own null (the protocol catching its own side). Two-directional
      audit as the norm, demonstrated.

## G. 2026-07-11 additions (results that moved after his 07-08 reply)

10. **Certified zeros extended γ₁₃–γ₁₇** [R-110–115]. The pre-registered batch
    (hash-anchored windows, HIT/NEAR/MISS frozen before any run) scored **3 HIT
    (γ₁₃/₁₄/γ₁₅) + 1 NEAR (γ₁₆, 9/1000 below the primary edge, pre-committed) + γ₁₇
    bonus**. **Needs from him:** confirm the grades, and confirm the two-channel report is
    protocol-sound — the pre-registered K=16/80M engine returned UNRESOLVED for γ₁₅/₁₆
    (amplitude wall); a declared **post-registration** extended-tail (Rankin block cutoff
    80M→120M, strictly tighter bound, frozen windows/scoring untouched) certified them
    [R-115, R-506]. We report both channels, never backfilled. Is this the right way to
    record a rigor-upgrade that certifies a frozen-UNRESOLVED window?

11. **K-modulus ledger extended to m = 17** [R-206, updated]. Positive at all 512
    bracket corners; density-tail-corrected positive through m=17; collapse profile
    reconciled to c ≈ 0.99 (the m≤12 "−0.8 asymptote" was premature). **Needs:** his
    grade-check — same CERTIFIED FINITE LEDGER wording, now through m=17? (Honest caveat
    recorded: corner spread grows to 37% at m=17, γ₁₄-bracket-limited; positivity robust.)

12. **Zero-table extensions completed on AWS** [R-109a]. chi7 → t≤5.0 (12 zeros, feq −21,
    low zeros cross-check PASS, SHA'd), `numerical_anchored`. Feeds the R-311 B_tail
    closure. **Decision he owns — twin route:** to close the twin edge-tail gaps 17/19/20,
    (A) extend the raw zero table to t≈6.5–8.0 (needs a 256 GB box + vCPU-quota bump,
    ~$3–5, anchored grade) or (B) the certified tail bound (`EXTEND_ZERO_TABLE_OR_TAIL_
    BOUND`, |aₙ(twin)|≤|aₙ(χ₈)|, minutes) — see `Q_to_Ilya_twin_extension_route_2026-07-11.md`.

## F. Authorship mechanics (proposal, for discussion)

- Part II/III certificates: joint as per the existing division-of-labor records.
- Part IV: joint (his GAP chains T50015–18 + our python E-series; the audit trail
  attributes each step).
- Appendix C: "protocol design: I. Balashov"; case-law section jointly.

*Everything else the paper needs is already in hand: the certified packages, the
audit trail, the zero tables, the theorem notes, and the registry history.*

Not claimed: RH, GRH — in the paper least of all.
