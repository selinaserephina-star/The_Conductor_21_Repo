# COVER — The Conductor-21 material, current state (for IB, 2026-07-26)

**Merkabit Research · Stenberg + Claude → Balashov.** You asked for the conductor-21
material. It is spread over the PAPER folder and the working repo; this package gathers
the **foundational corpus in its current state** — the claims register (the paper's
spine), the REV5 reconciliation, World v0.9, the architecture doc, the four Part files
+ Conclusion + grading protocol, the manuscript-status and needs notes, the AION
reformulation lemma, and the figures. Everything here is a **byte-identical read-only
copy** of the living file as of 2026-07-26; nothing was edited for this package.

Credit line: this is shared work, ours-and-yours throughout; authorship details remain
open and are not pre-assigned. **Nothing in this package claims RH, GRH, or Axiom L.**

Note on World v0.9: it was already sent to you in the paper draft bundle of 2026-07-25
(World v0.9 + Paper A v3 + Paper B v1, working drafts pending your audit). It is
**included here again in file form** for completeness of the corpus — same file, no
edits since that send.

## 1. Included documents (the corpus)

| file | one-line description | status |
|---|---|---|
| `CLAIMS_REGISTER_DRAFT_2026-07-08.md` (v0.11, updated through 07-15) | Appendix F spine: every claim R-001…R-506 with grade / artifact / audit; F.6 = your open action ledger | INCLUDED — the authority; earlier v0.1 sent 07-08 (PAPER_OPENING), this is the current state |
| `REGISTRY_RECONCILIATION_REV5_vs_ours_2026-07-13.md` | Crosswalk of your Scar/Merkabit REV5 (T8 CERTIFIED) onto our R-# rows; the three corrections folded (Perlis, T7 scope, det reconciliation); b8 = the single open seam | INCLUDED |
| `Conductor21_World_COMBINED_v0.9_2026-07-25.md` | The World paper, v0.9, 28.1k words — Parts I–IV combined, current draft | INCLUDED (also already-sent 2026-07-25 in the paper bundle; same bytes) |
| `Conductor21_World_ARCHITECTURE_v2_2026-07-08.md` | The paper's architecture: register-upward build, part structure, grade vocabulary | INCLUDED — earlier copy sent 07-08 (PAPER_OPENING) |
| `Paper_PartA_map.md` | Part I: the genome and the map (χ₈, cond 21¹⁰, family, scaling law) | INCLUDED |
| `Paper_PartB_wall_anatomy.md` | Part II: the wall's anatomy (AION, Euler necessity, K-modulus, the two roads) | INCLUDED |
| `Paper_PartC_certified_envelope.md` | Part III: the certified envelope (comb law, interval theorem, certified zeros) | INCLUDED |
| `Paper_PartD_finite_machine.md` | Part IV: the finite machine (descent, still-point key, assembly, DSE) | INCLUDED |
| `Paper_Conclusion.md` | Conclusion: what is reached, what the wall is, what is not claimed | INCLUDED |
| `Paper_AppG_grading_protocol.md` | Appendix G: the HIT/NEAR/pre-registration grading protocol | INCLUDED |
| `MANUSCRIPT_STATUS_2026-07-08.md` / `MANUSCRIPT_STATUS_2026-07-12.md` | Manuscript state snapshots (07-08 baseline; 07-12 current-of-record) | INCLUDED |
| `NEEDS_FROM_ILYA_and_METHOD_APPENDIX_2026-07-08.md` | The original needs-from-you list + method appendix seeds | INCLUDED — sent 07-08 (PAPER_OPENING); kept for the method-appendix half |
| `NEEDS_FROM_ILYA_2026-07-12.md` | The updated needs list (07-12) — supersedes the 07-08 needs half | INCLUDED |
| `AION_REFORMULATION_LEMMA_2026-07-14.md` | R-011a: the six-form equivalence lemma, proven conditional on (H); NOT RH | INCLUDED |
| `AION_reformulation_theorem_checklist_2026-07-12.md` | The checklist that drove the lemma | INCLUDED |
| `Figures_captions.md` + `figures/` (6 SVGs, 32 KB) | fig1 babushka shells … fig6 primes-in-zeros, with captions | INCLUDED |
| `SHA256SUMS.txt` | Inner manifest: sha256 of every file in this package | INCLUDED |

## 2. Claims-register status (one paragraph)

Register at **v0.11 (2026-07-15)**: F.0 foundations R-001…R-027 (incl. the three 07-15
additions — Euler-detector/Kronecker R-025, Λ(χ₈)≥0 via Dobner R-026, companion density
mismatch R-027, all your-review pending); F.1 zeros γ₁…γ₁₇ ball-certified (+γ₁₈–₂₁
anchored; the master index and the later γ₂₂–₂₄ extensions live in the sent zero packages);
F.2 operator branch folded (R-210–212 frame, R-209 the wall stays OPEN); F.3 envelope
closed except the four bounded edge excesses (R-311 corrected 07-12); F.4 assembly now
**conditional only on the fixed-class b8 residual** after your T8 (which we independently
reproduced); F.5 case law through R-506; **F.6 = your consolidated action ledger** —
that table is the fastest map of what awaits your confirm/formulate/markup. Register
work after 07-15 moved into the per-package sends (T2/caustic/infinite-side lanes) and
is registered in `LEDGER/AUDIT_REGISTER.md`, not yet folded back into this file.

## 3. Not included — already sent to you (you have these; listed so the corpus map is complete)

- **The paper draft bundle, sent 2026-07-25**: World v0.9 + `PAPER_A_FULL_ASSEMBLED_DRAFT_2026-07-25.md`
  (16.8k) + `PAPER_B_FULL_ASSEMBLED_DRAFT_2026-07-25.md` (9.8k) — working drafts pending
  your audit; only the World file is duplicated here (per your ask for the corpus in file form).
- **`to_Ilya_PAPER_OPENING_2026-07-08`** — claims register v0.1 + ARCHITECTURE_v2 +
  NEEDS_FROM_ILYA 07-08 + the γ₁₃–₁₆ pre-registrations (the register/needs files here
  supersede that snapshot).
- **The ~43 dated `to_Ilya_*` packages (2026-07-02 → 07-25)**, all frozen + hashed, incl.:
  ECL (07-02), ROUTE_D (07-10), GAMMA_BATCH pass1/FINAL (07-10/11), DOOR_IDENTITY_DSE +
  EDGE_C1C3 (07-12), de_Branges_operator_branch + still_point_theorem (07-13),
  family_law (07-14), chi8_ALL21_certified (07-15), arithmetic_matching /
  completeness_* / operator_program / gamma22_24 / turing24 (07-17/18),
  CAUSTIC_THEOREM + CERTIFIED_spectrum (07-19), THEOREM_M1(+HORIZON) + T2a_* (07-21/22),
  INFINITE_SIDE trio (07-22/23/24), CAUSTIC_CLOSED_FORMS + head_reconciliation (07-23),
  LEMMA_A_PRIME_zones + THEOREM_GRADE_closes + T2A_positive_norm_gate + FAR_WING_ARB_PASS
  (07-24), CAUSTIC_C1STAR_ASSEMBLY + COMPONENT_F_CLOSED + FAR_WING_DEBTS + GC2_TRUE_S +
  INTERVAL_OLVER (07-25). Not re-included — re-sending would fork the frozen hashes.

## 4. Not included — your own material (you are the source of record)

- All `*_received*` folders (AION_T500, ECL_* rounds, CHI8_* 07-18 set, ARITHMETIC_bridge,
  Q2_OPERATOR_BRIDGE, FAR_WING 07-24, INDEPENDENT_AUDIT, M74 workpack, SCAR descent, …),
  `SCAR_MERKABIT_REV5_T8_received_2026-07-13`, `theorem_master_registry_v8_4_june2026.md`,
  `Downloads from Ilya/`, and the **19-zip `Outstanding_Ilya_TBD` backlog** (yours; its
  geometry integration into the paper is staged with in-text markers, to be done with you).

## 5. Related working material listed for the map (not copied; ask and we stage any of it)

`CHI8_ZEROS_INDEX_gamma1_to_21_2026-07-13.md`, `chi8_certified_zeros_MASTER_2026-07-14/`,
`KMODULUS_HANKEL_LI_EXTENSION_17ZEROS_2026-07-11.md`, `FANO_IMBALANCE_THEOREM.md`,
`STATE_OF_PLAY_still_point_and_the_bow_2026-07-13.md`, `door_identity_2026-07-12/`,
`Klein_quartic_trit_census_2026-07-12/`, `T50019_503chart_closure_progress_2026-07-12.md`,
`T8_independent_reproduction_2026-07-13/`, PAPER-side seeds
(`E7_OMEGA_SECTOR_PROGRAM_SEED_2026-07-12.md`, `E8_SAME_SHELL_DIFFERENT_SONG_2026-07-12.md`,
`COMPANION_OPERATOR_PAPER_architecture_2026-07-23.md`, `OPERATOR_PAPER_architecture_2026-07-23.md`),
and `LEDGER/AUDIT_REGISTER.md` (the send-of-record ledger).

— S. + C., 2026-07-26. Shared work; authorship details open. Not RH/GRH.
