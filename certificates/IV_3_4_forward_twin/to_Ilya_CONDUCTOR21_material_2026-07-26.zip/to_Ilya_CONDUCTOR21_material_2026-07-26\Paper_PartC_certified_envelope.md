# Part III — The Certified Envelope

**DRAFT v0.2 · 2026-07-08, upd. 2026-07-11 · built register-upward (rows cited as
[R-xxx]; grades per the Claims Register v0.7). [TODO] marks numbers to pull from
hashed artifacts and items awaiting IB. v0.2 (07-11): certified zero table extended
to $\gamma_{17}$ + new §C.8.1a (pre-registered $\gamma_{13}$–$\gamma_{16}$ batch,
3 HIT + 1 NEAR; block-cutoff certification lever [R-115]). Not claimed anywhere in
this part: RH, GRH.**

---

## §C.1 — Introduction: from measured to certified

Part I mapped the family and its envelope; Part II dissected the wall. This part does
something different in kind: it takes the envelope of Part I down to **derivative
level** and replaces measurement with **certificate**. Every central statement below
is either a theorem (pen-and-paper, machine-checked arithmetic at most), a certified
computation (interval arithmetic end to end, hashed artifact, independent audit), or a
measurement with a priced error budget — and each carries its grade openly, per the
Claims Register (Appendix D). The part's arc:

1. the Laguerre–Turán quantity $Q=\Xi'^2-\Xi\Xi''$ is ported off $\zeta$ and measured
   across the family (§C.2);
2. its envelope obeys one law — the Envelope Comb — proved together with the
   side-lemma stack that makes grid data speak for continuous intervals (§C.3);
3. the law is tested on 45 gaps across the family, degrees 1 through 8, with nothing
   fitted (§C.4);
4. what the law does *not* explain is priced, term by term, in a five-slot error
   ledger, leaving a single named open slot (§C.5);
5. the certificates transfer up the tensor tower (§C.6);
6. and the flagship: $Q>0$ on $[0,3.2]$ for the genome $\chi_8$ at interval grade —
   the first theorem-grade Laguerre certificate for a degree-8 Artin $L$-function
   (§C.7), with its extensions: seventeen certified zeros, among them the program's
   first pure-prediction discovery ($\gamma_{12}$) and a frozen pre-registered batch
   scored 3 HIT + 1 NEAR ($\gamma_{13}$–$\gamma_{16}$), and the finite K-modulus
   ledger to $m=17$ (§C.8).

The thesis of the part, in one line: **the envelope is geometric and lawful; the
line is arithmetic — and at derivative level the boundary between them is now an
equation, with a certificate on each side.**

---

## §C.2 — The Certificate on the Family

### C.2.1 The quantity

For a completed $L$-function $\Lambda$ with $\Xi(t)=\Lambda(\tfrac12+it)$ real, the
Laguerre inequality
$$Q(t)\;=\;\Xi'(t)^2-\Xi(t)\,\Xi''(t)\;>\;0$$
holds wherever the zeros of $\Xi$ are real and simple; a failure of $Q>0$ flags a
zero off the line or a degeneracy. $Q$ is thus a *local, derivative-level detector*
— the same quantity for every member of the family, from $\zeta$ (degree 1) to
$\chi_8$ (degree 8, conductor $21^{10}$).

### C.2.2 What was measured

[R-307, R-008, R-009] $Q$ was computed on dense grids for six objects over their
in-range zero fields: $\zeta$, the $\chi_3$-pair, $\chi_6$, $\chi_7$, the genome
$\chi_8$, and the CM twin $\chi_8\otimes\chi_{-7}$ — whose conductor is **preserved**
at $21^{10}$ under the twist (the Mumford–Tate signature of §A.6, verified), so that
genome and twin share one shell and differ only arithmetically. This is, to our
knowledge, the **first Turán/Laguerre dataset for degree-8 Artin $L$-functions**.
Outputs per object: margin minima per gap, the which-wall identification (which
neighbouring zero pair binds each minimum), and the passport data ($N$, degree,
$\Gamma$-shape) that the law of §C.3 consumes.

| object | degree | gaps | ratio band (§C.4) |
|---|---|---|---|
| $\zeta$ | 1 | 9 | $[0.9976,\,1.0518]$ |
| $\chi_3$-pair | 3 | 8 | $[0.9515,\,1.0938]$ |
| $\chi_6$ | 6 | 5 | $[0.9998,\,1.1216]$ |
| $\chi_7$ | 7 | 6 | $[0.9971,\,1.0389]$ |
| $\chi_8$ | 8 | 7 | $[1.0126,\,1.0702]$ |
| $\chi_8\otimes\chi_{-7}$ | 8 | 10 | $[0.9426,\,1.0619]$ |

*(bands at effective grid resolution — refined rows superseding coarse tight-gap
rows; full table in §C.4; source: `family_certificate.csv` in the hashed package.)*

### C.2.3 Honest caveats, stated up front

- The **twin comparison** uses gap-minimum to gap-minimum; the corrected twin factor
  is $\approx 1.8\times$ [M]. Earlier which-wall mis-pairings are documented in the
  audit trail and corrected here.
- Grid data alone certifies nothing about the continuum between grid points; the
  passage from grid to interval is exactly what §C.3's lemma stack prices, and what
  §C.7 closes for $\chi_8$.
- Accidental near-degeneracies inflate $Q$'s dips without arithmetic meaning; they
  are flagged per-row in the artifact. [M]

---

## §C.3 — The Envelope Comb Law and Its Side-Lemma Stack

### C.3.1 The law

> **Envelope Comb Law** [IB; R-301; registry: ENVELOPE-COMB, CLOSED]. For a gap of
> width $g$ between consecutive zeros, with local zero density $\rho$ evaluated at
> the gap midpoint from the passport (never fitted),
> $$M_{\text{pred}}\;=\;\frac{8}{g^2}\;+\;(\pi^2-8)\,\rho(\text{mid})^2 .$$
> The first term is the two-wall comb floor; the second is the collective field of
> all other zeros, with the **universal constant $\pi^2-8$** [R-302].

The constant is not fitted and not family-dependent: it is forced by the comb
midpoint computation [IB side lemma, R-302]. $\rho$ comes from the passport density
law of §A.7 — the same law verified across the family to $1.07\pm0.08$ — so the
prediction chain contains **no free parameter anywhere**.

### C.3.2 The stack that makes grids speak for intervals

Four further lemmas, each registry-closed [IB], turn the law into an instrument:

| Lemma | Content | Row |
|---|---|---|
| TAIL-COMPOSITION | $B_{\sup}(I)=2S_1\delta c_1+\delta c_1^2+S_0\delta c_2+S_2\delta c_0+\delta c_0\delta c_2$: how truncation tails compose into a $Q$-certificate | [R-303] |
| Grid-to-interval | derivative-corrected grid bounds certify the continuum | [R-304] |
| Tight-gap sampling inflation | a sampled minimum overestimates the true gap minimum by at most $\frac{1+(h/g)^2}{(1-(h/g)^2)^2}$ | [R-305] |
| Comb-perturbation | conditional; perturbation constant $C(\theta)\le 10$ | [R-306, CONDITIONAL] |

[TODO: IB's registry names/numbers per lemma, from his markup pass.]

The sampling-inflation lemma deserves emphasis, because it *predicted its own
vindication*: the two apparent violations of the law in the first scans were exactly
the two tightest gaps, where the lemma prices the largest inflation — and both
collapsed on refined scan (§C.4). A law whose failures are pre-priced by its own
error theory is behaving like physics. [M→T]

---

## §C.4 — The Representation-Family Law: 45 Gaps, One Formula

[R-307; artifact ECL_FAMILY_THEOREM_v1_8a93b634854f.zip; status: delivered,
Step-3B audited; registry closure ECL-FAMILY-1 **pending** — TODO: IB's line.]

The test: for every scanned gap of every family member, form the ratio
$M_{\text{obs}}/M_{\text{pred}}$. One formula, six $L$-functions, degrees 1 through
8, conductors 1 through $21^{10}$, zero densities spanning a factor of $\sim 20$ —
and passports only, nothing fitted:

> **Result** [M]. All 45 gap ratios lie in $[0.9426,\,1.1216]$ at effective grid
> resolution.

The certificate carries 47 rows: 45 gaps, of which the two tightest ($g<0.1$) appear
twice — the coarse-grid row retained and flagged `tight-grid-limited`, and the
`refined-midpoint` row that supersedes it. Nothing is deleted; supersession is a
recorded event, per protocol.

| object | gap | $g$ | $\rho(\mathrm{mid})$ | $M_{\mathrm{obs}}$ | $M_{\mathrm{pred}}$ | ratio | status |
|---|---|---|---|---|---|---|---|
| $\zeta$ | 1 | 6.8873 | 0.1637 | 0.2301 | 0.2188 | 1.0518 | grid‑resolved |
| $\zeta$ | 2 | 3.9888 | 0.2066 | 0.5834 | 0.5826 | 1.0013 | grid‑resolved |
| $\zeta$ | 3 | 5.4140 | 0.2362 | 0.3898 | 0.3773 | 1.0332 | grid‑resolved |
| $\zeta$ | 4 | 2.5102 | 0.2575 | 1.390 | 1.394 | 0.9976 | grid‑resolved |
| $\zeta$ | 5 | 4.6511 | 0.2745 | 0.5210 | 0.5107 | 1.0201 | grid‑resolved |
| $\zeta$ | 6 | 3.3325 | 0.2916 | 0.8915 | 0.8793 | 1.0139 | grid‑resolved |
| $\zeta$ | 7 | 2.4083 | 0.3028 | 1.550 | 1.551 | 0.9998 | grid‑resolved |
| $\zeta$ | 8 | 4.6781 | 0.3157 | 0.5697 | 0.5519 | 1.0324 | grid‑resolved |
| $\zeta$ | 9 | 1.7687 | 0.3265 | 2.756 | 2.757 | 0.9999 | grid‑resolved |
| $\chi_3$-pair | 1 | 0.3742 | 1.7370 | 68.57 | 62.77 | 1.0923 | grid‑resolved |
| $\chi_3$-pair | 2 | 0.2716 | 2.1133 | 120.7 | 116.8 | 1.0333 | grid‑resolved |
| $\chi_3$-pair | 3 | 0.6934 | 2.4919 | 27.86 | 28.25 | 0.9864 | grid‑resolved |
| $\chi_3$-pair | 4 | 0.4729 | 2.8102 | 55.01 | 50.53 | 1.0887 | grid‑resolved |
| $\chi_3$-pair | 5 | 0.0698 | 2.9285 | 1991 | 1658 | 1.2006 | tight‑grid‑limited |
| $\chi_3$-pair | 6 | 0.4308 | 3.0260 | 65.87 | 60.22 | 1.0938 | grid‑resolved |
| $\chi_3$-pair | 7 | 0.4885 | 3.1827 | 49.91 | 52.46 | 0.9515 | grid‑resolved |
| $\chi_3$-pair | 8 | 0.2641 | 3.2942 | 134.8 | 135.0 | 0.9988 | grid‑resolved |
| $\chi_6$ | 1 | 0.9284 | 1.9723 | 17.31 | 16.55 | 1.0460 | grid‑resolved |
| $\chi_6$ | 2 | 0.0917 | 2.3027 | 981.5 | 961.7 | 1.0206 | tight‑grid‑limited |
| $\chi_6$ | 3 | 0.5101 | 2.4547 | 47.12 | 42.01 | 1.1216 | grid‑resolved |
| $\chi_6$ | 4 | 0.3939 | 2.6454 | 64.99 | 64.64 | 1.0053 | grid‑resolved |
| $\chi_6$ | 5 | 0.3242 | 2.7737 | 91.01 | 90.47 | 1.0059 | grid‑resolved |
| $\chi_7$ | 1 | 0.3941 | 2.0333 | 61.26 | 59.23 | 1.0342 | grid‑resolved |
| $\chi_7$ | 2 | 0.3147 | 2.3213 | 92.97 | 90.86 | 1.0232 | grid‑resolved |
| $\chi_7$ | 3 | 0.4201 | 2.5575 | 58.54 | 57.55 | 1.0171 | grid‑resolved |
| $\chi_7$ | 4 | 0.4267 | 2.7791 | 58.22 | 58.39 | 0.9971 | grid‑resolved |
| $\chi_7$ | 5 | 0.3410 | 2.9479 | 87.99 | 85.06 | 1.0344 | grid‑resolved |
| $\chi_7$ | 6 | 0.2188 | 3.0566 | 191.8 | 184.6 | 1.0389 | grid‑resolved |
| $\chi_8$ | 1 | 0.2824 | 2.6583 | 115.0 | 113.5 | 1.0126 | grid‑resolved |
| $\chi_8$ | 2 | 0.2934 | 2.9479 | 111.3 | 109.2 | 1.0192 | grid‑resolved |
| $\chi_8$ | 3 | 0.3985 | 3.2262 | 74.48 | 69.85 | 1.0663 | grid‑resolved |
| $\chi_8$ | 4 | 0.1550 | 3.4120 | 360.5 | 354.8 | 1.0160 | grid‑resolved |
| $\chi_8$ | 5 | 0.2529 | 3.5335 | 158.9 | 148.5 | 1.0702 | grid‑resolved |
| $\chi_8$ | 6 | 0.2384 | 3.6658 | 171.0 | 165.9 | 1.0311 | grid‑resolved |
| $\chi_8$ | 7 | 0.3071 | 3.7983 | 114.4 | 111.8 | 1.0234 | grid‑resolved |
| $\chi_8\otimes\chi_{-7}$ | 1 | 0.4163 | 2.3840 | 58.34 | 56.78 | 1.0273 | grid‑resolved |
| $\chi_8\otimes\chi_{-7}$ | 2 | 0.3188 | 2.8164 | 96.91 | 93.56 | 1.0358 | grid‑resolved |
| $\chi_8\otimes\chi_{-7}$ | 3 | 0.2272 | 3.0631 | 177.1 | 172.6 | 1.0260 | grid‑resolved |
| $\chi_8\otimes\chi_{-7}$ | 4 | 0.3723 | 3.2882 | 77.53 | 77.95 | 0.9946 | grid‑resolved |
| $\chi_8\otimes\chi_{-7}$ | 5 | 0.3641 | 3.5194 | 78.73 | 83.52 | 0.9426 | grid‑resolved |
| $\chi_8\otimes\chi_{-7}$ | 6 | 0.3194 | 3.7019 | 98.29 | 104.1 | 0.9446 | grid‑resolved |
| $\chi_8\otimes\chi_{-7}$ | 7 | 0.3301 | 3.8540 | 97.23 | 101.2 | 0.9610 | grid‑resolved |
| $\chi_8\otimes\chi_{-7}$ | 8 | 0.2846 | 3.9829 | 136.4 | 128.5 | 1.0619 | grid‑resolved |
| $\chi_8\otimes\chi_{-7}$ | 9 | 0.1162 | 4.0605 | 637.4 | 623.3 | 1.0226 | grid‑resolved |
| $\chi_8\otimes\chi_{-7}$ | 10 | 0.1709 | 4.1132 | 323.7 | 305.5 | 1.0596 | grid‑resolved |
| $\chi_6$ | 2′ | 0.0917 | 2.3027 | 961.5 | 961.7 | **0.9998** | refined‑midpoint |
| $\chi_3$-pair | 5′ | 0.0698 | 2.9285 | 1659 | 1658 | **1.0003** | refined‑midpoint |

*(source: `family_certificate.csv`, package `ECL_FAMILY_THEOREM_v1_8a93b634854f.zip`.)*

The two rows that once stood outside — the tight gaps at ratio $1.2006$
($\chi_3$-pair gap 5, $g=0.0698$) and $1.0206$ ($\chi_6$ gap 2, $g=0.0917$) —
collapsed to $1.0003$ and $0.9998$ on refined-midpoint scan [R-308], precisely as
the sampling-inflation lemma prices (the coarse step $0.02$ cannot sample the
midpoint of a gap of width $0.07$); the surviving band edges are grid-resolved and
carried in the ledger of §C.5. The law also passes the **jitter test**: the largest
genuine family deviation is $100.4\%$ explained by the measured jitter–error link
[R-310, IB].

Interpretation, calibrated: this is the thesis of §A.10 — envelope geometric, line
arithmetic — promoted to a *quantitative law of the family at derivative level*. It
is measured (45 gaps), lawful (one formula), and priced (§C.5). It is not, and is
not claimed to be, a positivity proof for any member. [M]

---

## §C.5 — The Error-Budget Ledger

[R-309; framework IB, data joint.] Everything the comb law does not capture is
decomposed into five priced slots:

$$\Delta_{\text{ECL}}\;=\;R_{\text{finite}}\;+\;B_{\text{tail}}\;+\;B_\rho\;+\;B_{\text{grid}}\;+\;B_{\text{eval}}$$

| Slot | Content | Status | Row |
|---|---|---|---|
| $R_{\text{finite}}$ | genuine finite-size deviation | **measured**; jitter link explains the largest instance to $100.4\%$ | [R-310] |
| $B_\rho$ | density-law error entering through $\rho(\text{mid})^2$ | **closed analytically** from the passport law | [R-309] |
| $B_{\text{grid}}$ | sampling inflation | **priced** by the tight-gap lemma; refined scans confirm | [R-305, R-308] |
| $B_{\text{eval}}$ | evaluation error of the curves | column-rounding $3\times10^{-6}$; **zero** for $\chi_8$ on $[0,3.2]$ (interval arithmetic) | [R-309] |
| $B_{\text{tail}}$ | window-truncation tails | **open on [TODO: n] rows**, each sharply quantified | [R-311] |

> **The one open slot** [R-311, OPEN]. The surviving $B_{\text{tail}}$ rows reduce to
> an Erdős–Turán-type discrepancy bridge, with a quantified target of at most a few
> per cent of the predicted value per row. [TODO: IB's preferred formulation and
> naming; this paragraph is his.]

A budget in which four of five slots are closed or priced, and the fifth is a named
classical problem with a numerical target, is the honest boundary of the law — and
the program's forward pointer on the analytic side.

---

## §C.6 — The Tower Transfer

[R-314, IB packages, audited.] The comb law and its stack were proved for a single
cell; the family is a tensor tower (§A.5). Six transfer certificates carry the
certificate machinery up the single-cell build tower — [TODO: enumerate the six
certificates with registry names from IB's markup] — so that the envelope law is not
an accident of one object but a property transported by the tower's own structure.
What does *not* transfer is the molecule: the composite of cells where cross-terms
enter. That is the same wall as everywhere else in this paper, met in its
tower-transfer guise. [T (IB), scope-limited]

---

## §C.7 — The χ₈ Interval Theorem

The section Part III exists for. Everything before it measures and prices; this
certifies.

> **Theorem C.7 (computer-assisted; [R-312, R-313]).** Let $\Xi$ be the completed
> $L$-function of the genome $\chi_8$ (degree 8, conductor $21^{10}$,
> $\Gamma_{\mathbb C}(s)^4$, $\varepsilon=+1$) on the critical line, and
> $Q=\Xi'^2-\Xi\Xi''$. Then
> $$Q(t)\;>\;0\qquad\text{for all }t\in[0,\,3.2],$$
> with every bound computed in ball arithmetic end to end. Minimum certified margin:
> $6.638\times10^{-7}$, at the binding interval $[3.0,3.2]$ — $98\%$ of the
> grid-truth value there, i.e. the certificate is nearly sharp exactly where it is
> hardest.
>
> *Status: CERTIFIED; artifact `CHI8_MAIN_JETS_0_3p2_v1_f6b1df63868e.zip`; all 16
> intervals pass the assembly validator; registry closure CHI8-INTERVAL-1 [TODO:
> IB's registry line].*

### C.7.1 Architecture of the certificate

The proof is a composition of two independent, separately-audited components:

**(i) The $\Gamma_{\mathbb C}^4$ tail lemma** [R-312; P2.1–2.3; IB FULL LOCAL AUDIT,
CLOSED]. The smoothed approximate functional equation for $\Lambda(s,\chi_8)$ leaves
mode tails beyond any finite horizon $M$; the lemma bounds them $t$-uniformly on
$[0,3.2]$ by the Rankin device
$$dc_k(M)\;=\;32\,\min_\sigma\,\zeta(\sigma)^8\,(M{+}1)^\sigma\,I_k(A_{M+1}),$$
with $I_k$ in closed form (no quadrature anywhere). The $\delta c_k$ enter the
certificate solely through the TAIL-COMPOSITION lemma of §C.3.2 — Part III uses IB's
lemma stack as *load-bearing infrastructure*, which is the two-roads composition of
§B.8 made concrete.

**(ii) Theorem-grade main jets** [R-313]. On each of 16 covering intervals
($[0,0.2],\dots,[3.0,3.2]$), modal jets $\xi_k$ to order $K=16$ are computed at the
interval centre in Arb ball arithmetic (precision 256), from exact integer
coefficients ($N_{\text{live}}$ up to $8\times10^6$ modes) and a **closed-form
residue series** for the quadruple-pole kernel (cubic-in-log terms; no numerical
integration). Taylor remainders over each interval are bounded by a $t$-uniform
derivative table ($U_{K+1}\,r^{K+1}/(K{+}1)!$ with the derivative shift for $Q$'s
factors); the mode band between $N_{\text{live}}$ and the tail horizon is bounded by
true-$|a_n|$ blocks. Polynomial sup/inf bounds on $[-r,r]$ are grid-plus-
mean-value-corrected, hence rigorous.

| $I$ | $[a,b]$ | $N_{\mathrm{live}}$ | $S_0$ | $S_1$ | $S_2$ | $\inf Q_{\mathrm{main}}$ | $B_{\sup}$ | margin |
|---|---|---|---|---|---|---|---|---|
| 1 | $[0.0,0.2]$ | 250,000 | 4.722e+04 | 7.481e+04 | 4.447e+05 | 1.5044e+10 | 1.91e-03 | 1.5044e+10 |
| 2 | $[0.2,0.4]$ | 250,000 | 3.907e+04 | 9.093e+04 | 2.434e+05 | 5.4540e+09 | 1.08e-03 | 5.4540e+09 |
| 3 | $[0.4,0.6]$ | 250,000 | 2.169e+04 | 8.748e+04 | 2.195e+05 | 9.2943e+08 | 9.73e-04 | 9.2943e+08 |
| 4 | $[0.6,0.8]$ | 250,000 | 7.482e+03 | 5.069e+04 | 2.183e+05 | 6.3851e+07 | 9.44e-04 | 6.3851e+07 |
| 5 | $[0.8,1.0]$ | 250,000 | 1.258e+03 | 1.486e+04 | 1.232e+05 | 1.1680e+06 | 5.24e-04 | 1.1680e+06 |
| 6 | $[1.0,1.2]$ | 4,000,000 | 5.185e+01 | 1.156e+03 | 2.546e+04 | 5.9793e+04 | 1.07e-04 | 5.9793e+04 |
| 7 | $[1.2,1.4]$ | 1,000,000 | 1.611e+01 | 3.032e+02 | 2.223e+03 | 4.2157e+03 | 9.48e-06 | 4.2157e+03 |
| 8 | $[1.4,1.6]$ | 1,000,000 | 6.213e+00 | 4.486e+01 | 5.831e+02 | 4.0411e+02 | 2.47e-06 | 4.0411e+02 |
| 9 | $[1.6,1.8]$ | 1,000,000 | 1.257e+00 | 1.494e+01 | 2.633e+02 | 2.4715e+01 | 1.11e-06 | 2.4715e+01 |
| 10 | $[1.8,2.0]$ | 4,000,000 | 5.954e-01 | 6.412e+00 | 3.965e+01 | 3.3090e-01 | 1.70e-07 | 3.3090e-01 |
| 11 | $[2.0,2.2]$ | 4,000,000 | 2.516e-02 | 3.351e-01 | 1.491e+01 | 4.2768e-02 | 6.25e-08 | 4.2768e-02 |
| 12 | $[2.2,2.4]$ | 4,000,000 | 1.468e-02 | 1.231e-01 | 2.994e+00 | 5.3338e-03 | 1.26e-08 | 5.3338e-03 |
| 13 | $[2.4,2.6]$ | 4,000,000 | 3.886e-03 | 5.609e-02 | 1.033e+00 | 7.8510e-04 | 4.35e-09 | 7.8509e-04 |
| 14 | $[2.6,2.8]$ | 4,000,000 | 1.458e-03 | 2.919e-02 | 2.831e-01 | 1.0724e-04 | 1.20e-09 | 1.0724e-04 |
| 15 | $[2.8,3.0]$ | 4,000,000 | 9.214e-04 | 9.750e-03 | 7.221e-02 | 5.1628e-06 | 3.08e-10 | 5.1625e-06 |
| 16 | $[3.0,3.2]$ | 8,000,000 | 1.642e-04 | 1.596e-03 | 3.675e-02 | 6.6395e-07 | 1.55e-10 | **6.6380e-07** |

*(source: `chi8_final_interval_certificate.csv` in the hashed package; all 16 rows
pass. The margin column is $\inf Q_{\text{main}} - B_{\sup}(\delta c_k(80\mathrm M))$
per the TAIL-COMPOSITION split. Note the sixteen-order-of-magnitude descent of the
margin from $[0,0.2]$ to $[3.0,3.2]$: the certificate tracks the collapsing scale of
$\Xi$ itself, and the $N_{\text{live}}$ plan — 250k modes at the bottom, 8M at the
top — is the visible cost of holding rigor against that collapse.)*

### C.7.2 What the theorem does and does not say

It says: no real zero of $Q$ — hence no off-line zero pair or degeneracy signature
of $\Xi$ — exists at derivative level in $[0,3.2]$, an interval containing the first
eleven zeros of the genome. It is *not* a re-proof of something classical: no CNV or
comparable verification exists for $\chi_8$. And it is a **finite certificate**: it
says nothing beyond $t=3.2$, and nothing about RH or GRH. $[C]$

---

## §C.8 — Extensions of the Certificate: Seventeen Zeros and the Finite Ledger

### C.8.1 The certified zero table

The same engine, pointed at individual windows, certifies sign changes of the
ball-enclosed $\Xi$ (IVT over points of certified sign):

| zero | bracket | seed | grade | row |
|---|---|---|---|---|
| $\gamma_9$ | $[3.126,3.128]$ | prime-side prediction | CERTIFIED_ZERO | [R-104] |
| $\gamma_{10}$ | $[3.338,3.342]$ | prime-side prediction | CERTIFIED_ZERO | [R-105] |
| $\gamma_{11}$ | $[3.700,3.702]$ | prime-side prediction | CERTIFIED_ZERO | [R-106] |
| $\gamma_{12}$ | $[3.952,3.954]$ | **none — density law only** | CERTIFIED_ZERO | [R-107] |
| $\gamma_{13}$ | $[4.081,4.087]$ | density law (pre-registered) | CERTIFIED_ZERO / **HIT** | [R-110] |
| $\gamma_{14}$ | $[4.357,4.379]$ | density law (pre-registered) | CERTIFIED_ZERO / **HIT** | [R-111] |
| $\gamma_{15}$ | $[4.548,4.550]$ | density law (pre-registered) | CERTIFIED_ZERO / **HIT** | [R-112] |
| $\gamma_{16}$ | $[4.692,4.696]$ | density law (pre-registered) | CERTIFIED_ZERO / **NEAR** | [R-113] |
| $\gamma_{17}$ | $[4.886,4.890]$ | density law (bonus) | CERTIFIED_ZERO | [R-114] |

$\gamma_9$–$\gamma_{11}$ close three instances of the two-method handshake [R-205]:
predicted from the primes by the explicit-formula extraction [R-108, seeds graded
CORROBORATIVE_PRIME_SEED_ONLY — the sinusoid form assumes RH, so seeds are never
certificates], then certified on the $L$-side with no prime input.

$\gamma_{12}$ is different in kind: **the first pure-prediction certified zero from
the passport density law, without a prime-side seed** — the target window came from
the density law alone, and the certified zero sits inside it, with no other sign
change and no ambiguous point in the window. The passport law now predicts zeros it
has never seen, at certified grade. It remains a finite certificate, not RH/GRH. $[C]$

### C.8.1a The pre-registered batch $\gamma_{13}$–$\gamma_{16}$, and a new certification lever

[R-110–115, R-506.] $\gamma_{13}$–$\gamma_{16}$ were predicted, windowed (PRIMARY
$\pm0.10$, SECONDARY $\pm0.20$), and scored (HIT/NEAR/MISS) under a **frozen
pre-registration** hash-anchored *before any computation* (Axiom-L discipline; the
counterparty received the note on freeze). Verdict, scored strictly: **three HITs
($\gamma_{13},\gamma_{14},\gamma_{15}$) and one NEAR ($\gamma_{16}$)** — the passport
law is now five-for-five blind ($\gamma_{13}$–$\gamma_{17}$, counting NEAR as a
law-consistent $S(T)$ excursion), squarely inside the pre-declared "$\sim$3–4 of 4 in
PRIMARY." $\gamma_{16}$ falls $9/1000$ below the PRIMARY edge $4.703$; it was
**pre-committed in writing as NEAR** — no rescue, no re-window. $\gamma_{17}$ is an
unregistered bonus.

The batch also produced a **method result** [R-115]. At the frozen $K=16$ engine the
$\gamma_{15}/\gamma_{16}$ windows first returned UNRESOLVED: the completed $\Xi$'s
amplitude ($\sim2.5\times10^{-9}$) had sunk below the certification floor
($\sim4\times10^{-9}$) around $t\approx4.5$. Decomposing that floor
$=\text{band}+U_{K+1}r^{K+1}/(K{+}1)!+\text{mtail}$ shows the jet-order term
($\sim10^{-16}$ at $r=0.05$) and the mode band ($\sim4\times10^{-13}$) are both
negligible: the floor is **entirely the Rankin $d_8$ tail beyond the $80$M block
cutoff**. Extending that cutoff to $120$M drops the floor to $1.98\times10^{-11}$
($\times210$), and — since the expensive modal jets are unchanged and the tail enters
the enclosure only additively — the windows recertify **from the cached jets** by
exact halfwidth-differencing, with no re-computation. This is reported as a declared
**post-registration channel** (strictly tighter bound, frozen windows and scoring
untouched, never backfilled into the pre-registered UNRESOLVED result [R-506]). The
practical upshot: the certification wall at higher $t$ is set by the block cutoff, not
by jet order or mode count — a cheap lever for pushing the certified zero table
deeper. $[C]$; not RH/GRH.

The full grading discipline invoked here — Axiom-L pre-registration, the HIT/NEAR/MISS
scoring rule, the two-channel honesty protocol, and the block-cutoff method [R-115] — is
stated once, formally, in **Appendix G** (grading protocol), with the $\gamma_{13}$–$\gamma_{17}$
batch scored there in a single table.

### C.8.2 The finite K-modulus ledger

[R-206; CERTIFIED FINITE LEDGER through $m=17$ (07-11 extension).] With seventeen
certified atoms $1/\gamma^2$, the void-pressure Hankel determinants
$H_m=\det[S_{i+j-1}]$ are evaluated over all $2^9=512$ bracket-corner combinations of
the nine bracket-certified zeros $\gamma_9$–$\gamma_{17}$: every $H_m$, $m\le17$, is
**positive at every corner**, and the density-tail-corrected sequence (the
non-automatic content) stays positive through $m=17$. Corner spreads remain
$\le5\%$ through $m=13$ and grow to $37\%$ at $m=17$, driven by the widest certified
bracket ($\gamma_{14}$'s pass-1 interval $[4.357,4.379]$); positivity is robust
throughout while the *value* precision at high $m$ is bracket-limited. The collapse
profile $\log_{10}H_m/m^2$ drifts monotonically to $-0.966$ at $m=17$ — **reconciling**
the m$\le$12 notes' extrapolated "$\approx-0.8$" with the original eight-zero rate fit
$c\approx0.99$: they are one curve at different depths. Li partials lift toward the
prime-side values with the truncation turnover pushed to $n\approx10$ (peak partial
$\approx51$, up from $\approx35$ at twelve zeros) [R-207, M].

Honesty note, as in §B.6: for a finitely-atomic measure, positivity of $H_m$ for
$m\le\#\text{atoms}$ is automatic; the content is the *values* — the margin profile
of the knife-edge — and the tail-corrected column. Finite positivity and margin
profile only; the difference between "positive through $m=12$" and "positive for
all $m$" **is** the wall. $[C]$

---

## §C.9 — Honest Ledger (Part III)

| Claim | Grade | Register |
|---|---|---|
| Envelope Comb Law + side-lemma stack | THEOREM (IB; one lemma CONDITIONAL, $C(\theta)\le10$) | R-301–306 |
| 45-gap family law, band $[0.943,1.122]$, nothing fitted | MEASURED; registry closure pending | R-307, R-308 |
| Five-slot error budget | four slots closed/priced; $B_{\text{tail}}$ OPEN (Erdős–Turán target) | R-309–311 |
| Tower transfer (six certificates) | THEOREM (IB), scope-limited to the build tower | R-314 |
| $\Gamma_{\mathbb C}^4$ tail lemma | CERTIFIED + AUDITED (IB full local audit) | R-312 |
| **$Q>0$ on $[0,3.2]$ for $\chi_8$** | **CERTIFIED**; registry closure pending | R-313 |
| $\gamma_9$–$\gamma_{17}$ | CERTIFIED_ZERO ($\gamma_{12}$ pure prediction; $\gamma_{13}$–$\gamma_{16}$ pre-registered, 3 HIT + 1 NEAR; $\gamma_{15}$–$\gamma_{17}$ via post-registration extended-tail) | R-104–107, R-110–115 |
| K-modulus ledger $m\le17$ | CERTIFIED FINITE LEDGER | R-206 |
| Prime-side seeds | CORROBORATIVE only | R-108 |

**Not claimed:** RH; GRH; positivity beyond $t=3.2$; Hankel positivity beyond
$m=17$; any inference from seeds. The wall stands where Part II left it; this part
measured, priced, and certified the ground in front of it.

---
*[Draft ends. §C.4 table, §C.7.1 table, six tower-certificate names, ECL-FAMILY-1
and CHI8-INTERVAL-1 registry lines, and the §C.5 Erdős–Turán paragraph await
artifact import and IB's markup.]*
