# Manuscript status — "From the χ₈ Certified Envelope to the Finite Transition Machine" (working title)

**2026-07-08 · all pieces inventoried · register-alignment verified mechanically**

| piece | file | state | register alignment |
|---|---|---|---|
| Part I — The Map | `Conductor21_World_COMBINED.md` (§A) | stands + 3 upgrades applied (A.5.4 sweep, A.9.1 certified extension, A.9.3 scope) | tag-graded [C]/[T]; mapped by register §D.0 (R-001–017) |
| Part II — The Anatomy of the Wall | `Conductor21_World_COMBINED.md` (§B) | stands + 7 upgrades applied (B.3.2 guard, B.6.4+scope ledger m=12, B.7.2 M74 batch, B.9.2 both-directions duality, B.10.1 pointer, B.11 cross-refs) | tag-graded; mapped by §D.0/D.2 rows |
| Part III — The Certified Envelope | `Paper_PartC_certified_envelope.md` | ~85%: full prose + both artifact tables (47-row family, 16-interval) | **24 rows cited, all resolve** |
| Part IV — The Finite Machine | `Paper_PartD_finite_machine.md` | ~90%: full prose incl. equipartition proof inline | **13 rows cited, all resolve** |
| Conclusion | `Paper_Conclusion.md` | ~95%: arc, thesis, ternary signature [PROPOSED], forward ledger | 7 rows cited, all resolve |
| Appendix C — Registry Protocol | — | **IB writes** (agreed 07-08); outline in NEEDS doc §E (C.0–C.8) | case-law rows R-501–504 reserved for it |
| Appendix D — Claims Register | `CLAIMS_REGISTER_DRAFT_2026-07-08.md` | v0.7, 71 rows, all work locations swept | is the register |
| Architecture (plan) | `Conductor21_World_ARCHITECTURE_v2_2026-07-08.md` | current; titles + governing rule recorded | — |
| Cover/needs (to IB) | `NEEDS_FROM_ILYA…md` + staging folder | sent 07-08 | ✔-marked |

**Mechanical check (07-08):** every R-citation in Parts III/IV/Conclusion resolves to a
register row (0 dangling). Uncited rows are exactly those whose home is Parts I–II
(D.0 foundations, D.1/D.2 items absorbed into §A/§B text) or Appendix C (case law) —
by design, not omission.

## Holes remaining (all IB-shaped)
1. Registry closures: CHI8-INTERVAL-1, ECL-FAMILY-1 → §C.4, §C.7 status lines
2. (S)/(S′) sweep verdict (Route C CEGAR) → §D.7 upgrade or honest conditional stays
3. M74 skeleton handshake → §B.7.2 "handshake remains" clause resolves
4. H₁/H₂ convention; canonical-key + door-criterion registry titles → §D.4/§D.5
5. Erdős–Turán formulation (his paragraph) → §C.5
6. Appendix C text + container-hash case-law paragraph
7. Ternary-signature ruling ([PROPOSED — IB veto welcome]) → Conclusion
8. Register markup pass (overwrite brackets, add his stack, dispute grades)

## Assembly pass (when IB's inputs land — one session)
- Merge parts into one document; reletter appendices (§D.x vs "Appendix D" collision)
- Add R-citations to the upgraded §A/§B passages (currently tag-graded only)
- Freeze title/subtitle; regenerate .docx from the merged .md (docx deliberately
  stale until then); final voice/cross-ref pass; acknowledgments (SB drafts)

Not claimed: RH, GRH — anywhere.
