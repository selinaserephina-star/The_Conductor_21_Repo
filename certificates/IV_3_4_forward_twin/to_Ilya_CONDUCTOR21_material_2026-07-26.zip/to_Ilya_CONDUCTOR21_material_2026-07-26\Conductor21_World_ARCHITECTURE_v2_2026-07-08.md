# "The Conductor-21 World" — architecture v2 (four parts + audit appendix)

**2026-07-08 · Stenberg + Claude (avatar session) · planning note for Stenberg–Balashov**
**Governing rule (IB, 07-08, adopted): the paper is built from the Claims Register
upward** — every claim carries THEOREM / CERTIFIED / AUDITED / MEASURED / CONDITIONAL /
OPEN openly, with artifact hash, audit status, and named conditions.
**Working title candidates (IB, 07-08):** "The Certified Envelope and the Finite
Transition Machine" or "From the χ₈ Certified Envelope to the Finite Transition
Machine" (note: retires "Conductor-21 World" as the *paper* title; it can stay as the
program name). **Subtitle proposal (SB, 07-08) — title names the flagship, subtitle
names the family**: "The Conductor-21 Program, Paper I: the self-similar L-function
family of PSL(2,7) — its envelope law across degrees 1–8, its interval certificates,
and the transition theorems of its finite cell." The family is the paper's scope (the
45-gap law is a family theorem); χ₈ is its flagship.

Updates the three-part proposal against the state of `Ilya Riemanns\` as of today.
Parts I and II stand as drafted (small upgrades listed). Part III is upgraded from
"measured" to "certified" — its aspirational section is now a delivered theorem. A new
Part IV holds the finite-machine arc, which did not exist when the three-part plan was
written. Honesty tags [C]/[T]/[P]/[R]/[OPEN] throughout; RH is never claimed.

---

## Part I — The Map (stands nearly as-is)

As proposed, plus one enrichment beyond the original list:
- §A.5.4: the 10¹¹ Chebotarev statistics (⟨a²⟩ = 0.99996 over 4.1B primes).
- §A.9 tables: not only γ₉ ≈ 3.127 as prime-side seed — the tables now carry
  **seventeen zeros to t = 4.888, the last nine at certified-bracket grade**
  (γ₉ ∈ [3.126, 3.128] … γ₁₂ ∈ [3.952, 3.954], and the 07-11 pre-registered batch
  γ₁₃–γ₁₆ scored **3 HIT + 1 NEAR** plus γ₁₇ bonus). γ₉–γ₁₁ were prime-predicted before
  L-side certification; **γ₁₂ is the program's first pure-prediction certified discovery**
  — no prime seed, target window from the passport density law alone, found at first
  attempt; γ₁₃–γ₁₇ extend the pure-prediction record under a frozen pre-registration
  (γ₁₅–₁₇ via the post-registration block-cutoff certification lever).

## Part II — The Anatomy of the Wall (stands; four upgrades)

1. §B.7–B.8 (the two roads): the D.3b closure and the err16/B_sup 4-digit handshake —
   AND the **M74 Rouché certificates**: γ₁…γ₄₀ of ζ each carrying an interval-grade
   contour certificate (margins 10¹–10¹⁵), with γ₁ certified twice by disjoint methods
   (arc-chunk balls here, adaptive subpatches IB-side) — the two roads' machinery not
   only composes but cross-audits.
2. §B.9 (the no-go): the prime sweep demonstrates the Fourier duality on the genome
   itself, both directions, to 10¹¹ — evidence upgraded from ζ to χ₈.
3. §B.10: the two-method γ₉ handshake, now strengthened to three certified instances
   (γ₉/γ₁₀/γ₁₁: predicted by primes, certified by balls).
4. §B.3/§B.6 (Aion): one terminology precision now on the record — the **trit clock**
   (order-3 Frobenius, ω Berry tick, Singer-dial transport) is distinct from the
   canonical Aion 𝒜 (the unwound de Branges flow); the T50015 GAP negative enforces
   the distinction empirically. The paper's definitions were always correct; the
   precision protects them. K-modulus §B.6: the **void-pressure Hankel ledger now runs
   to m = 17 at certified-bracket grade** (was m = 7; +γ₁₃–₁₇ on 07-11), positive at all
   512 corners; collapse profile drifting to −0.966 at m = 17 (the m≤12 "−0.8 asymptote"
   reconciled to the original c ≈ 0.99 rate); Li turnover at n ≈ 10.

## Part III — The Certified Envelope (upgraded from "Measured")

1. **The certificate on the family** (as proposed): Q = Ξ′²−ΞΞ″ ported off ζ; first
   Turán/Laguerre data for degree-8 Artin L; margins, identities, which-wall — with the
   corrected twin factor (~1.8×, gap-min to gap-min) and the honest caveat set.
2. **The Envelope Comb Theorem + the closed side-lemma stack**: comb-midpoint
   (π²−8 universal), TAIL-COMPOSITION, grid-to-interval, tight-gap sampling-inflation,
   comb-perturbation (conditional, with C(θ) ≤ 10) — each a registry-closed lemma.
3. **The representation-family law — now with the refined scans**: the 45-gap table,
   one formula, ρ from passports, nothing fitted; the two tight-gap "violations"
   collapse at refined step (1.2006 → 1.0003; 1.0206 → 0.9998) exactly as the sampling
   theorem prices them; honest band **[0.943, 1.122] grid-resolved, degree 1→8 across
   20× in density**. The ECL_FAMILY_THEOREM package is delivered and Step-3B audited;
   this section is the thesis-as-law, now evidence-complete.
4. **The error-budget ledger (new section)**: Δ_ECL = R_finite + B_tail + B_ρ + B_grid
   + B_eval, every slot priced or closed — R_finite measured (jitter link: the largest
   genuine family deviation is 100.4% explained), B_ρ closed analytically from the
   passport law, B_grid priced by the sampling theorem, B_eval at column-rounding
   (3e−6) and *zero* for χ₈ on [0,3.2]. Surviving demand: a handful of window-tail
   rows — the Erdős–Turán bridge target, quantified to ≤ a few % of predicted.
5. **The tower transfer** (as proposed): six certificates cover the single-cell build
   tower; the molecule as the wall that remains.
6. **The χ₈ interval theorem — delivered** (was "toward"): the Γ_ℂ⁴ tail lemma
   (P2.1–2.3, audit-closed, δc's t-uniform) + theorem-grade main jets (Arb balls end
   to end, closed-form residue-series kernel, 16-interval cover, all-pass through the
   assembly validator, min margin 6.6e−7 = 98% of grid truth at the binding interval)
   + the assembly theorem. **Q > 0 on [0,3.2] at interval grade** — and the closure is
   not a re-proof: no CNV exists for χ₈. The certified-zero campaign (γ₉–γ₁₇, incl. the
   pure-prediction γ₁₂ and the pre-registered 3 HIT + 1 NEAR batch) and the m = 17 Hankel
   ledger ride in this section as its extensions.

## Part IV — The Finite Machine (new): the Key, the Door, and the Ladder

The operator road's finite half, upgraded from anatomy (Part II §B.2) to dynamics with
theorems. All [C]/[P] with the audit trail; the interpretive layer stays [R]-tagged.

1. **The certified descent table** (Scale A): dimension ledger 168→24→8→7→1→0 proven
   exact (sympy character arithmetic); F(5)/F(6) forcing; the Definition 3.1 vs TQFT
   table discriminator (Hom(χ₈,χ₇) = 0) and the two-row erratum; the 49-candidate
   reconciliation (= the Hom ≤ 2 subset of 202, all counts reverified).
2. **The throat**: T7B′ (torsor ⇒ regular representation, repaired and constructive);
   the Galois-completed throat 25 = 18+1+6; **T50018** — rank 7 ⇒ cyclic rank 8, both
   S₄ classes, 1008 structural charts, independently audited.
3. **The selector chain** (T50015–17): strict "clock = heat" FAILS (the honest
   negative); the trit instead TRANSPORTS between conjugate throats and selects one
   S₄ class — identity monodromy, no Berry phase at Hom level.
4. **The canonical key**: the trit fixes exactly one key per class (orbits 1+3+3) —
   the stabilizer of the Singer dial's still point.
5. **The Equipartition Theorem** (T50019a, proven): every rank-7 throat's hidden
   sector splits 6⊕6⊕6 under the trit — forced by the bottleneck's representation
   theory, both classes, no genericity.
6. **The Assembly Theorem** (T50019): the G-closure of one hidden sector = χ₇ ⊕ 2χ₈ =
   F(6) ⊖ triv; the χ₇-part automatic; three trit-transported sectors saturate;
   **assembly ⊕ still-point marker ≅ F(6)** — "three dark thirds and one still point make
   the next rung." On **chart65 this is now CERTIFIED** (T50019-S″ FINAL, 07-10):
   `dim(K+FK+F²K)=23 ⟺ Q₂(b)≠0` by exact Singular elimination — the assembly locus is an
   explicit Eisenstein quadric; Open2b(universal) and the rank<15 proxy both **REFUTED**;
   admissibility resolved with no gap. Remaining: the 503-chart Hidx=2 sweep, scope-reduced
   to cheap shared-Q₂ nonemptiness checks (CONDITIONAL / SWEEP-IN-PROGRESS).
7. **The door criterion** (proven): the mechanism exists at exactly one rung — the
   F(5)→F(4) bottleneck, where the target is ℚ[G/S₄], the χ₆ change appears, and the
   trit selects. Above: rigid certified G-descent. The ladder has one door.
8. **The bridge, honestly**: the Hamiltonian-ladder probe (declared tests, synthetic
   null, edge-domination finding) redirecting to the Li/Hankel observables — the
   finite machine's certified contact points with the infinite flow — capped by IB's
   **finite-label no-go theorem** (finite class data carries ≤ log₂6 bits/prime; RH
   needs unbounded control): the paper states its own ceiling as a theorem, and the
   exact statement of what stays [OPEN].

## Appendix C — The Registry Protocol (IB writes it; design credited to him)

The methodology AND its live history: hash-anchored packages (manifest, LF sidecars,
deterministic reruns), passports (ρ never fitted), predeclared model selection
(freeze discipline, transferable-recipe fairness, the NULL baseline), anti-fitting
rules — with IB's free-Herglotz-cone interpolation diagnostic (X.8) as the canonical
anti-fitting demonstration — and the recorded cases where the protocol caught real
errors in BOTH directions: the container-hash mismatch (IB's catch, his paragraph),
the cover-message typo vs hashed CSV (erratum, artifact authoritative), the parser
artifact that mimicked an 829× "error" (row counts as the tell), and the
rational-relation test voided by its own synthetic null. Lineage: the protocol
descends from IB's Scar-Cat Master Theorem Registry (v8.4, 264 entries, OSF-deposited)
— cite it as the ancestor. Two-directional independent audit as standard practice for
computational number theory.

## Appendix D — The Claims Register

One row per claim: ID · statement · grade (T theorem / C certified / M measured / A
audited; *cond.* with the condition named) · method · artifact + SHA · audit · registry
status. The narrative cites rows; the register cites the repositories. Draft v0 started
2026-07-08 (`CLAIMS_REGISTER_DRAFT_2026-07-08.md`, ~40 rows populated avatar-side);
IB's registry is authoritative for names and statuses — he extends and corrects.

## Thesis line (revised, hers + one clause)

> "The envelope is geometric and self-similar; the line is arithmetic — and at
> derivative level the boundary between them is now an equation: the margin's floor is
> the shell's, its dips are the primes'. **Beneath both, the finite machine that
> carries the flow has one door, one key, and a proven transition rule — and the wall
> stands exactly where it always did: at the passage from every rung to all of them.**"

— for iteration; Parts I–II unchanged, Part III retitled, Part IV inserted, appendix
expanded. Not claimed anywhere: RH, GRH.
