# COVER — COMPONENT F CLOSED: the osc-side c₂ closed form (and one correction to a sent number)

**Merkabit → IB · Stenberg + Claude · 2026-07-25. Caustic-theorem lane (T2/K1-P1), envelope (iii).
Not RH/GRH. Self-contained; working home stays `INFINITE_SIDE_open_items_2026-07-22/` (living);
this sealed copy is FROZEN.**

## Headline

**Component F — the oscillatory-side (w < −½) c₂ closed form, our map's "one hard open problem" —
is CLOSED.** And the resolution is embarrassingly simple: there was never a hard problem. The
osc-side discrepancy (and three separate downstream mysteries) was a **factor-2 bug in the
Euler–Maclaurin operator** of our c₂ assembly (`olver_ivl_22`): the boundary-derivative term was
written −(h/6)g′; the correct trapezoidal EM coefficient for the atom-anchored half-line lattice sum
Σ_{p≥0} g(w+ph) is **−(h/12)g′** (B₂/2! = 1/12). No Airy connection, no Bleistein uniform integral,
no k=±1 Poisson mode — the corrected plain-EM closed form is valid on BOTH sides of the caustic:

**c₂(w) = (2^{1/3}/30π)[ −9w² + π( 30(π−1)w·Ai² − (10π²−90π+177)w·AiBi − (150−30π)Ai′²
          − 18w²·Ai′Bi − (10π²−90π+75)Ai′Bi′ ) ]**

(only the two π² coefficients change vs the old form — both halved). Equivalently:
c₂ = c₂^{old} + (2^{1/3}π²/3)(w·AiBi + Ai′Bi′) = c₂^{old} + (2^{1/3}π/12)g₀′, g₀ = 2π(AiBi)′.

## Why we believe it (no free parameters anywhere)

The bug's consequence Δ(w) = (2^{1/3}π²/6)(AiBi)″(w) explains, at once:

1. **The window shape residual** we had measured and could not explain (Δκ(w), our §2p):
   predicted 0.0046/0.0082/0.0186/0.0525/0.0620 vs measured 0.005/0.009/0.023/0.042/0.064 at
   w = 5/4/3/2/1. Decisive, because on the window the Poisson modes are exponentially small — no
   connection/Poisson mechanism could produce a window-side residual.
2. **The osc-side failure**: c₂^{old}(−2) = −1.53 → corrected −0.046 vs sum-measured ≈ −0.05…−0.1.
3. **The caustic gap**: corrected c₂(0) = −0.6882 (exact:
   (2^{1/3}/30)[−(150−30π)3^{−2/3} + (10π²−90π+75)3^{−1/6}]/Γ(1/3)²) vs peak-model measured ≈ −0.6.
4. **Why five numerical closed-form fits failed**: they fitted against a wrong baseline.

**Decisive verification** (`olver_ivl_39`, arb Olver ladder j = 4096…65 536, ten anchors w = −1…−8,
pointwise w-scatter-free Richardson): residuals **+0.001…−0.02 near the caustic**, ≤3% deep
(c₃-order), fit residuals 0.000–0.012 — the old form errs by 1–3 at every anchor. Instrument note
worth keeping: the historical "rho_j oscillates in j at fixed anchor" (which we had read as
non-term-domination) was **anchor-atom w-scatter aliasing** — the anchor atom's w moves by ±δ/2 ~
±0.1 across a j-ladder while |c₂′| ~ 30 deep; subtract the closed form at each j's own atom-w before
extrapolating and the ε-series is cleanly term-dominated on the osc side.

## Certified sups (arb ball cells, prec 120)

- **OSC [−16, −0.5]: sup |c₂|/(1+|w|)^{7/4} ≤ 0.4535 ≤ 0.46 < 0.7** — margin 1.54×, worst cell at
  the caustic edge w ≈ −0.50; reproduces our sum-measured 0.43 @ w ≈ −0.55.
- **WINDOW [0, 8]: = 0.6882 < 0.9** — margin 1.31×, worst cell at w = 0.

Envelope (iii) is now closed-form theorem grade at leading-c₂ order on BOTH sides (deep end beyond
the seam covered as before by the mid-Debye vdC O(1) ≈ 0.85; the interval-grade all-j certification
remains the standing authority and is untouched).

## ⚠️ One correction to a number we previously sent

`to_Ilya_INTERVAL_OLVER_sigma_amplitude_2026-07-25` quoted **"closed-form window sup 0.207 (w ≥ 0)"**.
That number came from the same bug and is **superseded: the window closed-form sup is 0.6882**
(still < 0.9; and it now *matches* the data — the old value was hiding the true caustic peak
c₂(0) = −0.688). The earlier retraction of the osc "0.224" stands, now with the mechanism known.
Nothing else in that package changes (A(w), Φ₂, c₀, c₁, the interval-grade certification and its
headroom are all unaffected).

## Honest remaining polish (non-gating)

(a) displayed EM-remainder constant after −(h/12)g′ (O(h³), next Bernoulli term two orders down);
(b) displayed c₃ bound (absorbs the ≤3% deep-anchor residuals); (c) Paper A §8.7 text update.

## Contents

- `COVER_component_F_closed.md` (this file)
- `SESSION_SUMMARY_2026-07-25_F_CLOSED.md` (the full session record incl. what was superseded)
- `WRITEUP_F_osc_connection_derivation.md` (the F derivation framework, with the §6 resolution and
  the superseded-framing banner — kept for the honest record of the route)
- `evidence/olver_ivl_22_c2_EM.py` (+log) — the original assembly (the bug source, for reference)
- `evidence/olver_ivl_36_em12_fix.py` (+log) — toy EM coefficient test + symbolic re-derivation +
  window/osc tables
- `evidence/olver_ivl_37_osc_ladder_verify.py` (+log) — first ladder (mean-anchor instrument;
  superseded by _39, kept for the instrument lesson)
- `evidence/olver_ivl_38_c2fix_sup_demod.py`, `evidence/olver_ivl_38b_recert.py` (+logs) — fine-grid
  sups, demod cross-checks, deep asymptotic envelope, arb interval certification
- `evidence/olver_ivl_39_osc_pointwise_verify.py` (+log) — the decisive pointwise verification
- `SHA256SUMS.txt` (inner manifest)

*— Stenberg + Claude, 2026-07-25. The one hard open problem dissolved into a Bernoulli coefficient;
the lesson we bank: when a wall resists five fits and the smooth side shows a small converged
residual, audit the operator's constants before building uniform-asymptotics machinery.*
