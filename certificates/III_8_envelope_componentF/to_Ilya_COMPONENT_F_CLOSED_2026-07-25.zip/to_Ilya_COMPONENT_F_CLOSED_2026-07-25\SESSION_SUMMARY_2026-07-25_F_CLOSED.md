# SESSION SUMMARY 2026-07-25 (later) — COMPONENT F CLOSED: the osc-c₂ "hard problem" was a factor-2 EM bug

**Stenberg + Claude. Handoff for a fresh session. Not RH/GRH. Orient via
`STATE_OF_PROOF_caustic_theorem.md` (rows E/F + §3 resolution banner); live math in
`FINDINGS_INTERVAL_OLVER_DEBYE.md` §2r; ledger §9 (last dated entry).**

## PURPOSE / OUTCOME

Selina: "can we make a go at F?" — component F = the osc-side (w < −½) c₂ closed form, the map's
"one hard open problem," previously survived two dedicated Bleistein-route sessions and five defeated
fits. **OUTCOME: F is CLOSED, and not by the Bleistein route — the entire discrepancy was a factor-2
bug in `olver_ivl_22`'s Euler–Maclaurin operator.** Envelope (iii) is now closed-form theorem grade
at leading-c₂ order on BOTH sides, with arb-certified sups.

## THE FINDING (one paragraph)

In the Airy variable w the atoms sit on an EXACTLY linear lattice (spacing h = 2^{1/3}πε) and the
accumulating atom Δ_jσ = g₀ + εg₁ + ε²g₂ + … is a sum of ENTIRE Airy-ring functions (g₀ = 2π(AiBi)′)
— so the atom-anchored half-line sum obeys plain trapezoidal EM, whose boundary-derivative
coefficient is **−(h/12)g′** (B₂/2! = 1/12). `_22` used −h/6. The corrected c₂ (only the two π²
coefficients change, HALVED: −20π² → −10π² on w·AiBi and Ai′Bi′) is valid on both sides:

  c₂(w) = (2^{1/3}/30π)[−9w² + π(30(π−1)w·Ai² − (10π²−90π+177)w·AiBi − (150−30π)Ai′²
           − 18w²·Ai′Bi − (10π²−90π+75)Ai′Bi′)]

The no-free-parameter difference Δ(w) = (2^{1/3}π²/6)(AiBi)″(w) explains, at once: §2p's window
"shape residual" (matched point by point — decisive, since on the window Poisson modes are exp-small,
so no connection/Poisson mechanism could produce it); the osc failure (c₂^{EM}(−2) = −1.53 →
corrected −0.046 vs true ≈ −0.05…−0.1); the caustic "~0.4 gap" (corrected c₂(0) = −0.6882 exact vs
measured ≈ −0.6); and all five defeated fits (wrong baseline). The old "rho_j oscillates in j / not
term-dominated" evidence was **anchor-atom w-scatter aliasing** (the anchor atom's w moves ±δ/2 ~
±0.1 across a j-ladder while |c₂′| ~ 30 deep); subtracting the closed form at each j's own atom-w
(`_39`) gives clean convergence — the ε-series IS term-dominated pointwise on the osc side.

## VERIFICATION (all banked)

1. Toy numeric EM: coefficient −0.08333 = −1/12 decisively (`_36` part A).
2. Symbolic: `_22` pipeline re-run; g₀ = 2π(AiBi)′ confirmed; corrected form emitted (`_36` part B).
3. Window Δκ: pred 0.0046/0.0082/0.0186/0.0525/0.0620 vs measured 0.005/0.009/0.023/0.042/0.064
   (w = 5…1).
4. **Pointwise arb ladder (`_39`, the decisive instrument):** r₀ = +0.001/−0.020/−0.002/−0.004/
   −0.012/−0.073/+0.000/−0.202/+0.227/+0.110 at w = −1…−8 (≤0.02 near-caustic; ≤3% deep = c₃-order);
   old formula errs 1–3 everywhere. Fit residuals 0.000–0.012.
5. Demod of the closed form reproduces `_35`'s D/M targets and `_29`'s measured sup 0.43 @ w≈−0.55.
6. **Certified sups (arb cells, prec 120, `_38`/`_38b`): osc [−16,−0.5] UB 0.4535 ≤ 0.46 < 0.7
   (margin 1.54×); window [0,8] UB 0.6882 < 0.9 (margin 1.31×).**

## ⚠️ CORRECTIONS TO BANKED CLAIMS (prominent)

- **"Window closed-form sup 0.207" is SUPERSEDED → 0.6882** (same bug; still < 0.9; now matches the
  measured caustic value). Do not quote 0.207 or 0.224 anywhere.
- The §9-recorded recipe `c₂ = K∫g₂ + ½g₁ − (2^{1/3}π/6)g₀′` → coefficient is (2^{1/3}π/12).
- §2q's mechanism hypothesis (dropped homogeneous/connection piece) REFUTED; §3's Bleistein framing
  and the two F-attempt findings files carry superseded banners (their structural numerics stand).
- §2j's interval numbers, c₀, c₁, Φ₂, and the interval grade are all UNTOUCHED.

## FILES

- NEW: findings **§2r** (the authority), `olver_ivl_36_em12_fix.py` (toy + symbolic + tables),
  `_37_osc_ladder_verify.py` (mean-anchor; superseded by `_39`), `_38_c2fix_sup_demod.py`,
  `_38b_recert.py` (certified sups), `_39_osc_pointwise_verify.py` (decisive), + `_run.log`s.
- UPDATED: findings header + §2o/§2p/§2q banners; `STATE_OF_PROOF` rows E/F, bottom line, §2
  operator line, §3 resolution, reading order; `WRITEUP_F` top banner + §6 resolution;
  `WRITEUP_INTERVAL_OLVER_and_sigma_osc_amplitude.md` §III/§IV; `FINDINGS_F_bleistein_setup_derisk.md`
  + `FINDINGS_F_uniform_airy_attempt.md` banners; `NEXT_SESSION_TASK_c2_theorem_grade.md` (2b/4
  resolved); ledger §9; memory (`lemmaa-reposed-caustic-closure` + index).

## REMAINING (non-gating polish)

1. Displayed EM-remainder constant after −(h/12)g′ (O(h³g‴) on the compact range, à la §2g majorants).
2. Displayed c₃ bound (task item 3) — would also absorb the ≤0.23 deep-anchor r₀.
3. Paper A: update §8.7/lemma text to the corrected c₂ + certified sups when next touched.

## LESSON (baked into memory)

When a "hard analytic wall" resists five fits AND the smooth side shows a small converged residual,
check the operator's CONSTANTS (Bernoulli coefficients, factor-2s) before building uniform-asymptotics
machinery. And: never Richardson against a mean anchor when the target oscillates — subtract the
prediction at each rung's own sample point first.
