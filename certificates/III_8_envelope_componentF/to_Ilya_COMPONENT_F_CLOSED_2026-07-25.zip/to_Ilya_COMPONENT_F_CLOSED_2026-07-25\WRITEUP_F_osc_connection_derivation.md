# DERIVATION FRAMEWORK — component F: the osc-side envelope R via the turning-point uniform expansion

> **[2026-07-25 RESOLUTION — F CLOSED, and NOT by this route. See §6 at the bottom + findings §2r.]**
> The Bleistein/uniform-Airy framing below (§1–§3) chased a phantom: the osc-side discrepancy was a
> factor-2 bug in `olver_ivl_22`'s EM boundary coefficient (−h/6 vs the correct −h/12). The corrected
> plain-EM c₂ is valid on BOTH sides (verified pointwise vs arb; sups certified 0.6882/0.4535).
> §4d's Step-1 normalization facts (phase, B(w), the Δ_jσ↔AiBi identity) remain true and banked.

**Merkabit · Stenberg + Claude · 2026-07-25. The start of the F upgrade (osc-side c₂ / envelope closed
form), after check-existing confirmed F open with A(w)+route in hand and three fitting routes dead
(`olver_ivl_30/31/32`). This file sets up the correct analytic derivation and records the structural
findings that reframe it. Not RH/GRH.**

## 0. The object

C̃_j(m) = Σ_{n≤m} Δ_jσ(z_n), z_n = (n−½)π, ν = 2j, w = 2^{1/3}ν^{−1/3}(ν−z). Residual R = C̃ − P,
P = ν^{1/3}c₀ + c₁ (c₀ = −2^{2/3}AiBi, c₁ = Ψ₀ + S∞, both proven). Goal: closed-form R on w < −½ with
sup_{w<−½}|ν^{1/3}R|/(1+|w|)^{7/4} ≤ 0.7 (lift component F: INTERVAL → THEOREM grade). Osc summand (§2f):
**σ_osc = pref·Re[𝒜 e^{2iΦ_ν}] + DC**, A(w) = pref|𝒜| = **(1−sinθ)/sin2θ**, phase 2Φ_ν,
Φ_ν = √(z²−ν²) − ν·arccos(ν/z) − π/4, **Φ_ν′(z) = sinθ**, θ = arccos(ν/z).

## 1. R is a midpoint-rule error with NO interior stationary point

C̃ − P = the oscillatory (Poisson) part of the midpoint sum: **R = Σ_{k≠0}(−1)^k σ̂(2k)**,
σ̂(ξ) = ∫ σ(z) e^{−iξz} dz (z-lattice spacing π ⟹ Poisson frequencies 2k; the (−1)^k from the
half-integer midpoint offset). For mode k, the phase is 2Φ_ν(z) − 2kz with derivative
**2sinθ − 2k**; on the caustic osc side sinθ ∈ (0, small), so **sinθ = k has NO solution for |k| ≥ 1**
— no interior stationary point. Hence each mode is governed by (a) the **current-atom endpoint** z = z_m
and (b) the **turning point** z = ν (θ = 0), where 2Φ_ν has its Airy (cubic) stationary structure.

## 2. The two-endpoint structure — single endpoint blows up, turning point cancels it (Bleistein)

- **Endpoint (current atom) term** (integration by parts, no stationary point):
  R_endpt ~ Re[ A(w) e^{2iΦ_ν(z_m)} / (e^{2πi sinθ} − 1) ]. As sinθ → 0 (near caustic),
  e^{2πi sinθ}−1 ≈ 2πi sinθ, and A(w) = (1−sinθ)/sin2θ ≈ 1/(2 sinθ), so
  **R_endpt ~ 1/(4π sin²θ) ~ ν^{2/3}/(|w|)** — the documented ν^{+2/3} blow-up (ledger 2026-07-24,
  §2f). A single-endpoint bound is therefore FALSE; the blow-up is spurious.
- **Turning-point term**: near z = ν, 2Φ_ν(z) = −(4/3)·[½(z−ν)·(2/ν)^{1/2}]^{3/2}·… = the Airy cubic
  in w (2Φ_ν ↔ −(2/3)(−w)^{3/2}·2 up to the standard Olver normalization). The mode-k integral over
  this cubic phase + the linear −2kz is an **Airy integral**, giving Ai/Bi of a shifted argument (see §3).
  Its small-sinθ expansion carries the SAME 1/sin²θ singular coefficient with opposite sign ⟹ the two
  cancel, leaving R = O(ε)·(bounded). **This is a Bleistein uniform expansion: the endpoint and turning
  point must be kept together; neither alone is the envelope.**

## 3. Why every closed-form FIT failed — R is Airy at an ALIASED argument, not at w

The mode-k turning-point integral ∫ exp(i[2Φ_ν(z) − 2kz]) dz, in the Airy variable (z = ν − 2^{−1/3}ν^{1/3}w,
dz = −2^{−1/3}ν^{1/3}dw), carries the linear term **−2kz = −2kν + 2k·2^{−1/3}ν^{1/3}·w**. A linear-in-w
term inside an Airy integral **SHIFTS the Airy argument** by δ_k ∝ k·2^{−1/3}ν^{1/3}. So R is a
combination of **Ai, Bi (and products) at the shifted argument w + δ_k**, NOT at w. This is precisely why
`olver_ivl_30` (full ring), `_31` (ring + w-poly), and `_32` (homogeneous {Ai²,AiBi,Bi²} at w) all
failed: the correct osc c₂ is **outside the span of Airy-at-w** — it is aliased (turning-point Poisson)
Airy content. (The apparent paradox — shift ∝ ν^{1/3} → Ai(w+δ) exp-small for δ>0, oscillatory for δ<0 —
is resolved by the endpoint/turning-point cancellation in §2 keeping the net O(ε); the surviving piece is
the sub-leading term of the uniform expansion, the analog of the B₀/A₁ correction on the evanescent side.)

## 4. The concrete remaining computation (the close)

Do the **Bleistein uniform expansion** of R = Σ_{k=±1}(−1)^k [turning-point + endpoint], keeping both:
1. Expand 2Φ_ν(z) about z = ν to cubic order in the Airy variable; carry A(w) = (1−sinθ)/sin2θ to
   sub-leading order (it has a removable 1/θ that pairs with the cubic Jacobian).
2. Evaluate the mode-±1 integrals as uniform Airy integrals (Ai, Ai′ of the shifted/scaled argument);
   the standard Bleistein result gives R = ε·[a(w)Ai(·) + b(w)Ai′(·)] with explicit a, b.
3. The 1/sin²θ endpoint singularity cancels; extract the O(ε) envelope and its (1+|w|)^{7/4} growth
   (from A(w)'s |w|-growth), then sup_{w<−½}|ν^{1/3}R|/(1+|w|)^{7/4} in closed form. Target ≤ 0.7.
4. Cross-checks: (i) reduce to c₂^{EM} as w → 0⁺ (evanescent side, where the turning-point integral goes
   to the standard Airy boundary); (ii) reproduce the `olver_ivl_29` osc amplitude (≈ 0.43 at w ≈ −0.55)
   and the c₂_true values at w = −1…−4 (`olver_ivl_31`, clean); (iii) match the far end onto A(w)/vdC at
   the w ≈ −15.6 Debye seam.

## 4b. The object, precisely — this is the closed form of R_olv (interval-grade ground truth in hand)

The envelope is R = **R_olv** + [C̃ − C̃_olv], where R_olv = C̃_olv − P is the pure-Airy (Olver) accumulated
ε²-Airy term, **arb-certified per octave to radii ~10⁻²⁵⁶** (`olver_ivl_11/12`, §2g/§2h) and [C̃−C̃_olv] ≤
5.6e−5 (§2k). So the derivation target of §4 is exactly **the closed form of R_olv on the osc side**, and
the per-octave arb R_olv (and the `olver_ivl_29/31` osc c₂_true) are the ground truth to check each step
against — this is the "all-j analytic bound on the accumulated ε²-Airy term" route, A(w) feeding in.

## 4c. Immediate next step + a caution (turning-point phase normalization)

The first concrete sub-step is the cubic (Airy) expansion of the mode phase 2Φ_ν(z) − 2kz about z = ν.
A quick pass gives Φ_ν + π/4 ≈ (√2/6)ν^{−1/2}(z−ν)^{3/2} ⟹ 2Φ_ν ≈ (1/3)(−w)^{3/2} − π/2, but the summand
oscillates as AiBi(w) at phase (4/3)(−w)^{3/2} — a factor mismatch that means **the turning-point
normalization (the √2, the Olver ζ ↔ w scaling, and whether σ_osc's e^{2iΦ_ν} is per-atom vs after the
j-difference) must be pinned exactly before the Bleistein integral** — this is the error-prone step to do
carefully and verify against R_olv, not to rush. (The j-difference Δ_jσ, not σ itself, is what accumulates
— its phase/amplitude may differ from σ_osc's by the ∂/∂ν action, which is the likely source of the factor.)

## 4d. STEP 1 DONE — normalization pinned + verified (`olver_ivl_33_normalization.py`)

- **Turning-point phase (analytic + numeric):** Φ_ν + π/4 = ν·(2√2/3)u^{3/2}(1 − 9u/20 + …), u = (z−ν)/ν
  (sympy), ⟹ **Φ_ν ≈ (2/3)(−w)^{3/2} − π/4**, **2Φ_ν = (4/3)(−w)^{3/2} − π/2**. Verified vs the exact
  Debye phase: dev −0.0000 @ w = −0.5 → −0.04 @ w = −8 (the u^{5/2} tail). Per-atom advance 2π sinθ. (My
  earlier "(1/6)" was an arccos-expansion slip; the correct leading coeff is 2√2/3.)
- **Amplitude of the ACCUMULATING object Δ_jσ (not σ):** demodulating Δ_jσ against 2Φ_ν gives
  **B(w) = 4θ·A(w) = 4θ(1−sinθ)/sin2θ**, θ = arccos(ν/z), matched to **< 1%** (w = −2: 1.9018 vs 1.8927;
  w = −4: 1.8457 vs 1.8505; …). B is O(1) (not O(ν^{1/3})): the j-difference ∂/∂ν brings down −2θ ~ ν^{−1/3},
  cancelling σ's ν^{1/3}. Small-θ: **B = 2 − 2^{4/3}ε(−w)^{1/2} + O(ε²)**, θ = 2^{1/3}ε(−w)^{1/2}, ε = ν^{−1/3}.
- **Clean identity (simplifies Step 2):** AiBi(w) = (1/2π)(−w)^{−1/2}cos((4/3)(−w)^{3/2}) for w < 0, so the
  leading summand is **Δ_jσ ≈ −2cos((4/3)(−w)^{3/2}) = −4π√(−w)·AiBi(w)** — the accumulating object is the
  leading Airy profile itself, chirped. The cumulative of this chirp is the Airy integral that builds
  ν^{1/3}c₀ = −ν^{1/3}2^{2/3}AiBi(w); the ε² residual is the osc c₂.
- **Confirms the ν^{2/3} cancellation is unavoidable:** the endpoint Poisson term ~ B/(2 sin(π sinθ)) ~
  ν^{1/3}/√|w| (O(ν^{1/3})), but the true R is O(ε) — so endpoint and turning-point must be resummed
  together (uniform Airy), never split. This is why single-endpoint SBP gave ν^{+2/3}.

## 4e. STEP 2 (next) — the uniform-Airy cumulative

With Δ_jσ = B(w)·(−cos(2Φ_ν+…)), B = 2 − 2^{4/3}ε(−w)^{1/2}+O(ε²), 2Φ_ν = (4/3)(−w)^{3/2}−π/2 + O(ε)-corrections,
the cumulative C̃(w) = Σ_{n≤m}Δ_jσ is a chirp sum through the turning point. Compute it by the **uniform
(Bleistein) Airy representation**: map the chirp to the Airy integral, carry the ε-corrections of B and of
the phase (the u^{5/2} term → the ε-shift of the Airy argument), and read the ε²-order (osc c₂) as the
Ai′/Ai correction. Check each order against R_olv (arb, §2g/§2h) and the `olver_ivl_31` c₂_true.

## 4f. STEP 2 progress — demodulation separates the structure + confirms the envelope (`olver_ivl_34`)

Instead of fitting the oscillation, **demodulate** c₂_true at Ψ = (4/3)(−w)^{3/2} (the AiBi frequency):
c₂_true(w) = **D(w)** [DC] + **M(w)**·cos(Ψ + φ(w)) with D, M, φ slowly varying (j = 65536 fine osc grid).
- **Frequency is Ψ (no leading aliasing):** demodulating at Ψ gives smooth amplitudes (no beating), so the
  osc c₂ oscillates at the AiBi frequency after all. (Refines §3: the "aliasing" is a sub-leading-mode
  effect, not the leading structure.)
- **Why the ring fits failed — now explained:** M(w) ~ 0.42·(−w)^{1.32} GROWS, whereas Ai²/AiBi/Bi² have
  DECAYING (−w)^{−1/2} envelopes. So c₂ = (w-polynomial)·(Airy products) — the polynomial supplies the
  growth; constant-coefficient {Ai²,AiBi,Bi²} (`_32`) cannot, and the full ring (`_31`) was under-
  determined. The correct basis is the ring WITH w-polynomial coefficients + the derivative products
  (Ai′², Ai′Bi′, which grow like (−w)^{+1/2}).
- **Envelope confirmed with margin (the substantive deliverable):** |c₂| ≈ |D| + M gives
  (|D|+M)/(1+|w|)^{7/4} ≈ 0.35 near the caustic edge (consistent with the direct `olver_ivl_29` value
  0.43 @ w ≈ −0.55), falling to ≈ 0.21 deep — **well under 0.7, asymptotic (j→∞) margin ~1.6×, from the
  term-dominated leading c₂** (cleaner than the interval octave-check, which measured the full finite-j R).
- D(w): a real non-oscillating part (−0.5 → −2 over w = −0.8 → −8), the osc-side analog of c₂^{EM}'s
  polynomial DC.

## 4g. STEP 2 FINAL — envelope CONFIRMED; closed form resists ALL numerical ID (`olver_ivl_35`)

Multi-j demod (j = 16384/32768/65536) + Richardson gives clean-ish D(w), M(w) (phase-invariant, so
Richardson is well-posed). Result, two parts:
- **Envelope confirmed (the deliverable):** (|D|+M)/(1+|w|)^{7/4} ≈ 0.35 on [−8,−1.2], ≈ 0.43 at the
  caustic edge — **stable, well under 0.7, asymptotic margin ~1.6×.**
- **Closed form does NOT fall out numerically.** Fitting M(w), D(w) to a Laurent series in s = (−w)^{1/2}
  (k = −1…3) is ILL-CONDITIONED: large alternating coeffs (M: −18.6, +35.5, −22.3, +5.1; RMS 0.12), and
  M/(−w)^{5/4} drifts 0.51→0.61 while M/(−w)^{3/2} drifts 0.41→0.35 — neither a clean law. The exact
  amplitudes are the FULL Airy-function expressions (powers only asymptotically deep), and the Airy
  products are too degenerate on a finite osc window for any fit to resolve them.

**Verdict — numerical identification is defeated (5 attempts: `_30/_31/_32/_34/_35`).** The closed form
must come from the ANALYTIC uniform-Airy coefficient derivation (the Bleistein integral, §4e/§4f) —
deriving the w-poly × Airy-product coefficients from the asymptotic expansion, NOT fitting them. That is
the one remaining step, and it is the genuinely hard analytic core; STEPS 1–2 supply its ingredients
(phase (4/3)(−w)^{3/2}, amplitude B→2, ansatz form, and the D/M numeric targets to verify against).

**What F HAS gained this session (real, banked):** (1) normalization pinned + verified (§4d); (2) the
oscillation structure + why every fit fails (§4f); (3) **the 0.7 osc envelope CONFIRMED asymptotically
with ~1.6× margin from the term-dominated leading c₂** (§4g) — a genuine strengthening of the interval
octave-check, though still numeric (demod), not closed-form. **F's closed-form theorem grade is NOT
achieved**; it awaits the analytic Bleistein integral.

## 6. RESOLUTION (2026-07-25, `olver_ivl_36..39`, findings §2r) — F CLOSED by a coefficient repair

The "one hard open problem" dissolved. The w-space reformulation is the key: at fixed j the atoms sit
on an EXACTLY linear w-lattice (spacing h = 2^{1/3}πε), the accumulating atom is an ENTIRE Airy-ring
function Δ_jσ = g₀ + εg₁ + ε²g₂ + O(ε³) with g₀ = 2π(AiBi)′, and the atom-anchored half-line sum obeys
plain trapezoidal EM: Σ_{p≥0}g(w+ph) = (1/h)∫_w^∞g + ½g(w) − **(h/12)**g′(w) + O(h³). `olver_ivl_22`
wrote −h/6 — a factor-2 slip — and every downstream mystery was this bug: the §2p window "shape
residual" (= the missing (2^{1/3}π/12)g₀′, matched point by point), the osc-side "failure" of c₂^{EM}
(corrected form matches the arb ladder pointwise to +0.001…−0.02 near-caustic), the caustic "~0.4 gap"
(corrected c₂(0) = −0.6882 vs measured ≈ −0.6), and the five defeated fits (they fitted data against a
wrong baseline). The ν^{1/3} "endpoint blow-up needing turning-point cancellation" (§2 above) is an
artifact of splitting the entire atom into e^{±2iΦ} branch pieces on a half-offset z-lattice; anchored
at the current atom in w, the k≠0 Poisson modes reduce exactly to the EM boundary series (endpoint
phases cancel; no stationary point in-window), so no separate Bleistein object exists at this order.
The "rho_j oscillates in j" evidence for non-term-domination was anchor-atom w-scatter aliasing.
**Result: c₂ closed form valid on both sides (§2r), sups arb-certified 0.4535 (osc, <0.7, 1.54×) and
0.6882 (window, <0.9; corrects the banked 0.207). Component F: theorem grade at leading-c₂ order.**

## 5. Status (historical — superseded by §6)

Framework set; obstructions understood (two-endpoint cancellation; aliased-Airy form); target pinned
(closed form of arb-certified R_olv, §4b). **STEP 1 DONE + verified** (§4d): phase 2Φ_ν = (4/3)(−w)^{3/2}−π/2,
amplitude B(w) = 4θ(1−sinθ)/sin2θ → 2, clean summand↔AiBi identity, ν^{2/3}-cancellation confirmed. **STEP 2
IN PROGRESS** (§4f): demodulation separates c₂ = D(w) + M(w)cos(Ψ+φ), Ψ = (4/3)(−w)^{3/2}; oscillation at
the AiBi frequency (not aliased at leading order); ring fits explained (need w-poly coefficients);
**envelope CONFIRMED ~0.43 < 0.7 asymptotically (margin ~1.6×)**. **STEP 2 FINAL** (§4g): numerical
closed-form ID DEFEATED by basis degeneracy (5 attempts) — the exact amplitudes are full Airy expressions;
the closed form needs the ANALYTIC Bleistein integral (§4e), the one remaining hard step. **F's closed-form
theorem grade is NOT achieved this session** (envelope confirmed asymptotically, but numeric not closed-form).
**F remains a POLISH**: envelope (iii) stands at INTERVAL grade
(§2j) + vdC O(1) ≈ 0.85; the theorem is unaffected. Files: `olver_ivl_26..32` (probes + three dead fits);
inputs §2f (A(w), Poisson route), §2g/§2h (R_olv interval machinery), `olver_ivl_29/31` (osc c₂_true).
