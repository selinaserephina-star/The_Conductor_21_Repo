# midzone_landscape.py -- map the FULL C~_j(m) landscape across all four zones via the
# EXACT closure identity sigma_n^(j) = (2/(4j+1)) 2 x^2 R'_{j-1}(x) R_j(x), x=z_n^-2,
# R_j = P_{2j+1}/u^2, u=1/z, z_n=(n-1/2)pi.  Goal: locate the caustic peak (~a_inf (2j)^1/3
# at m~0.637j), the descent, the far-wing lobe (m~0.296 j^2), and MEASURE the mid-oscillatory
# zone's contribution to C~_j(m) -- is it O(1) and below the caustic peak (=> feeds c_0)?
# Identify the genuinely-open sub-region (turning-point transition, q large). Not RH/GRH.
import time, math
import mpmath as mp
mp.mp.dps = 60

def build_R(J, NMAX):
    # P_l via recurrence P_{l+1} = (2l+1) u P_l - P_{l-1}, P_0=u, P_1=u^2; R_j=P_{2j+1}/u^2.
    zs = [(mp.mpf(2*n-1))*mp.pi/2 for n in range(1, NMAX+1)]
    us = [1/z for z in zs]; xs = [u*u for u in us]
    need = {J-1, J, J+1}
    Pp = list(us); Pc = [u*u for u in us]
    R = {}
    def stash(l):
        if l % 2 == 1 and (l-1)//2 in need:
            R[(l-1)//2] = [Pc[i]/xs[i] for i in range(NMAX)]   # /u^2
    stash(1)
    for l in range(1, 2*J+3):
        Pn = [(2*l+1)*us[i]*Pc[i] - Pp[i] for i in range(NMAX)]
        Pp, Pc = Pc, Pn
        stash(l+1)
    return zs, xs, R

def sigma_row(J, xs, R, NMAX):
    # sigma via closure: (2/(4J+1)) 2 x^2 R'_{J-1} R_J. R' from finite difference of the
    # polynomial in x? -- cheaper: use the OTHER closure form 2(j-1)x R_{j-1} - S - T = 2x^2 R'.
    # We instead use the direct product form already validated: sigma = (2/(4J+1)) x^2 * dR * R_J
    # where dR ~ derivative; but simplest exact: reuse the bracket form needs S,T too. For the
    # LANDSCAPE (magnitudes/signs) the leading closure product suffices; use R_{J-1},R_J and a
    # symmetric x-derivative of R_{J-1} across atoms is NOT valid (atoms not uniform in x).
    # -> Use the exact bracket: sigma_n = (2/(4J+1))(2(J-1) x R_{J-1} - S_{J-1} - T_{J-1}) R_J.
    raise NotImplementedError

# Simpler + exact: compute sigma directly from spherical Bessel (the row definition), which is
# unambiguous, at the atoms.  For the mid/far zone (z>2j) Bessel is well-conditioned.
def sj(l, z): return mp.sqrt(mp.pi/(2*z))*mp.besselj(l+mp.mpf(1)/2, z)
def sy(l, z): return mp.sqrt(mp.pi/(2*z))*mp.bessely(l+mp.mpf(1)/2, z)
def sigma(j, n):
    z=(n-mp.mpf(1)/2)*mp.pi
    return float((mp.mpf(2)/(4*j+1))*z*z*sj(2*j+1,z)*(2*(j-1)*sj(2*j-1,z)-z*(sj(2*j-2,z)+sy(2*j-1,z))))

LOG=open(__file__.replace('.py','_run.log'),'w')
def log(s):
    print(s,flush=True);LOG.write(s+'\n');LOG.flush()
log(f"=== mid-Debye landscape: full C~_j(m) profile @ {time.strftime('%Y-%m-%d %H:%M:%S')} ===")
a_inf = 2**(mp.mpf(2)/3)*3**(-mp.mpf(5)/6)/mp.gamma(mp.mpf(2)/3)**2

for J in (24, 48):
    t0=time.time()
    NMAX = int(1.4*J*J) + 50          # reach past the far lobe (m~0.30 J^2)
    # cumulative C~_j(m) = sum_{n<=m} (sigma_{j+1}-sigma_j)(n)
    C = 0.0; prof = []
    caustic_m = int(round(0.6366*J)); farlobe_m = int(round(0.2957*J*J))
    peak = 0.0; peak_m = 0
    Cmid_max = 0.0; Cmid_at = 0
    for n in range(1, NMAX+1):
        d = sigma(J+1, n) - sigma(J, n)
        C += d
        z = (n-0.5)*math.pi
        if abs(C) > abs(peak):
            peak = C; peak_m = n
        # mid-osc zone: 2J < z < (2J)^2, and past the caustic descent (m > 2*caustic)
        if 2*J < z < (2*J)**2 and n > 2*caustic_m:
            if abs(C) > abs(Cmid_max):
                Cmid_max = C; Cmid_at = n
        if n in (caustic_m, 2*caustic_m, farlobe_m) or n % max(1,NMAX//12) == 0:
            prof.append((n, n/(J*J), z/(2*J), C))
    log(f"\n#### J={J}: caustic at m~{caustic_m} (z/2J=1), far lobe at m~{farlobe_m}, NMAX={NMAX} ({time.time()-t0:.0f}s)")
    log(f"   caustic bound a_inf(2J)^1/3 = {float(a_inf*(2*J)**(mp.mpf(1)/3)):.4f}")
    log(f"   PEAK |C~| = {peak:+.5f} at m={peak_m} (m/J={peak_m/J:.3f}, expect ~0.637)")
    log(f"   mid-osc (past descent, 2J<z<(2J)^2) max |C~| = {Cmid_max:+.5f} at m={Cmid_at} "
        f"(m/J^2={Cmid_at/(J*J):.4f})  -- is this O(1) below the peak?")
    log(f"   {'m':>6} {'m/J^2':>7} {'z/2J':>7} {'C~_j(m)':>11}")
    for n, chi, zr, c in prof:
        log(f"   {n:>6} {chi:>7.4f} {zr:>7.3f} {c:>+11.5f}")
log("\ndone.  landscape mapped: caustic peak (grows ~(2j)^1/3), mid-osc tail (O(1)?), far lobe.")
LOG.close()
