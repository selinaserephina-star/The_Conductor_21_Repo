# midzone_abel.py -- mid-Debye TRANSITION zone: the exact trig-sum treatment.
# The transition (Airy edge < chi < X_far, i.e. q=lambda large but past turning point)
# summand is oscillatory: sigma_n^(j) ~ g(lambda)/2j, g(l)=sin^2 l - l sin l cos l
#   = (1-cos2l)/2 - (l/2) sin2l  ->  -(l/2) sin2l for large l  (amplitude ~ lambda !).
# So Delta_j sigma ~ h(lambda)/2j^2, h(l) ~ -2l^2 cos2l -- amplitude ~ lambda^2, UNBOUNDED
# pointwise, but the PARTIAL SUMS are O(1) by oscillatory cancellation (summation-by-parts):
# the phase 2 lambda_n = 4 j^2/((n-1/2)pi) sweeps fast, so Abel against it kills the lambda^2.
# HERE: (A) confirm the transition partial-sum sup is O(1) UNIFORMLY in j (the qualitative
# claim the theorem needs); (B) exhibit the summation-by-parts kernel D_n = sum e^{2i lambda_k}
# is O(1/|phase step|)-bounded => the cancellation is real and quantifiable. Not RH/GRH.
import time, math
import mpmath as mp
mp.mp.dps = 50

def sj(l, z): return mp.sqrt(mp.pi/(2*z))*mp.besselj(l+mp.mpf(1)/2, z)
def sy(l, z): return mp.sqrt(mp.pi/(2*z))*mp.bessely(l+mp.mpf(1)/2, z)
def dsigma(j, n):   # (sigma_{j+1}-sigma_j)(n), exact
    z=(n-mp.mpf(1)/2)*mp.pi
    def sig(J):
        return (mp.mpf(2)/(4*J+1))*z*z*sj(2*J+1,z)*(2*(J-1)*sj(2*J-1,z)-z*(sj(2*J-2,z)+sy(2*J-1,z)))
    return sig(j+1)-sig(j)

LOG=open(__file__.replace('.py','_run.log'),'w')
def log(s):
    print(s,flush=True);LOG.write(s+'\n');LOG.flush()
log(f"=== mid-Debye transition: exact trig-sum / Abel treatment @ {time.strftime('%Y-%m-%d %H:%M:%S')} ===")

# (A) transition partial-sum sup, uniform in j.  Transition = from just past the Airy window
#     (n0 ~ 0.637 j + 3 (2j)^1/3) up to X_far j^2 (X_far=0.15).  Report sup|running sum| and
#     the pointwise amplitude sup (h(lambda)/2j^2 ~ lambda^2/2j^2) to show |sum| << sum|.|.
log("\n-- (A) transition partial-sum sup vs pointwise-magnitude sum (cancellation ratio) --")
log(f"{'j':>5} {'n0':>6} {'n1':>6} {'sup|partial|':>13} {'sum|dsigma|':>13} {'cancel x':>9} {'lam@n0':>8}")
for j in (24, 48, 96):
    t0=time.time()
    caustic = 0.6366*j
    n0 = int(caustic + 4*(2*j)**(1.0/3)) + 1        # just past the Airy window
    n1 = int(0.15*j*j)                               # X_far edge
    S = mp.mpf(0); supS = mp.mpf(0); sumabs = mp.mpf(0)
    for n in range(n0, n1+1):
        d = dsigma(j, n)
        S += d
        if abs(S) > supS: supS = abs(S)
        sumabs += abs(d)
    lam0 = 2*j*j/((n0-0.5)*math.pi)
    log(f"{j:>5} {n0:>6} {n1:>6} {float(supS):13.5f} {float(sumabs):13.5f} "
        f"{float(sumabs/supS):9.1f} {lam0:8.3f}  ({time.time()-t0:.0f}s)")

# (B) the Abel kernel: partial sums of the pure oscillation e^{2 i lambda_n}, lambda_n=2j^2/z_n.
#     If |sum_{k=n0}^n e^{2 i lambda_k}| <= K (bounded), summation-by-parts gives
#     |sum a_n| <= K*(|amp_max| + TV(amp))/... -> O(1) since the lambda^2 amplitude has
#     bounded variation after the /2j^2.  We measure sup|Abel kernel| and its scaling.
log("\n-- (B) Abel kernel sup |sum_{k<=n} e^{2 i lambda_k}| over the transition (bounded => cancellation) --")
log(f"{'j':>5} {'sup|D_n|':>10} {'(2j)^1/3':>9}   [bounded/slowly-growing => oscillatory sum controlled]")
for j in (24, 48, 96, 192):
    caustic = 0.6366*j
    n0 = int(caustic + 4*(2*j)**(1.0/3)) + 1
    n1 = int(0.15*j*j)
    D = mp.mpc(0); supD = 0.0; I = mp.mpc(0, 1)
    for n in range(n0, n1+1):
        lam = 2*mp.mpf(j)*j/((n-mp.mpf(1)/2)*mp.pi)
        D += mp.exp(I*2*lam)                 # pure oscillation e^{2 i lambda_n}
        ad = abs(D)
        if ad > supD: supD = float(ad)
    log(f"{j:>5} {supD:10.4f} {(2*j)**(1.0/3):9.4f}")
log("\ndone.  (A) transition partial sums O(1) & << sum|.| (cancellation); (B) Abel kernel bounded")
log("=> the exact trig-sum route controls the transition at O(1). Rigorous constant = next.")
LOG.close()
