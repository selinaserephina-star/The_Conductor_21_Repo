# FINDINGS — far-wing debt 1: per-atom σ remainder MEASURED + the closure route mapped (checkpoint, not closed)

**Merkabit · Stenberg + Claude · 2026-07-24 (far-wing debt 1, IB's flagged lane, taken
on Selina's go-ahead; built on IB's spherical-Hankel phase theorem + the sealed
σ-calculus). CHECKPOINT: measured confirmation + proven-grade ingredient inventory +
the recommended symbolic route. The displayed W-bound is NOT yet derived — OPEN, staged.
Not RH/GRH.**

## 0. What this is

Debt 1 = turn IB's leading far-wing law into a per-atom remainder bound with the
cancellation of the j-difference preserved:
  **Δ_jσ_j(n) := σ_{j+1}(n) − σ_j(n) = (1/2j²) h(λ_n) + O(j⁻³ · W(n/j²))**, W integrable,
so that Σ_{n>m} r_j(n) = O(1/j) — the 1/j the far zone owes (debt 2 gave the
discretization at O(j⁻⁴); this per-atom remainder is where the 1/j actually lives).
h(λ) = −2λ²cos2λ + (3/2)λsin2λ + ½cos2λ − ½; λ_n = 2j²/z_n; z_n = (n−½)π.

## 1. MEASURED confirmation (`farwing_sigma_remainder.py` + `_run.log`)

Exact rows via spherical Bessel at mpmath dps 40; r_j(n) = Δ_jσ − (1/2j²)h(λ_n).

- **Leading law confirmed (the + sign is right).** 2j²·Δ_jσ at the lobe x = n/j² = 0.30
  reads −3.96 / −1.66 / −0.52 at j = 16/32/64 — a clean **2j²Δ_jσ = h(λ) − 69/j**
  finite-j undershoot converging up to h(λ) ≈ +0.49 (fit residual < 1%). So
  Δ_jσ = (1/2j²)h(λ) + O(j⁻³) holds; the transient negatives were finite-j, not a sign.
- **Remainder is O(j⁻³) with an integrable envelope.** The profile **j³·r_j(n) collapses
  to a stable W(x) across j = 24/48/96** (64× change in j³): e.g. at x = 0.30, j³r =
  −34.6 / −33.3 / −32.4; at x = 0.28, −40.6 / −39.9 / −39.6. W(x) peaks ≈ +166 near
  x = 0.16, dips to ≈ −44 near x = 0.24–0.28, crosses zero near x ≈ 0.52.
- **∫_x |j³ r| dx ≈ 12.85** at j = 96 (step 0.04, window x ∈ [0.16, 0.60]) — finite ⟹
  W integrable ⟹ **Σ_n r_j = O(1/j)** with a bounded constant. GRADE: **MEASURED**.
- Honest caveat: the profile drifts at the inner edge x ≲ 0.20 (residual O(1/j) not yet
  collapsed) — that is the caustic-adjacent region, exactly the "x ≥ X" far-zone domain
  restriction; W is integrable *on the far zone*, and the inner edge is a separate
  (caustic) matching handled by LEMMA A′'s zone map, not debt 1.

## 2. Ingredient inventory — everything for the displayed bound EXISTS at proven grade

(Established via a full-repo Hankel/σ search; check-existing-first.)

| ingredient | file | grade |
|---|---|---|
| exact σ-Laurent; row-sum Σg_k(2²ᵏ−1)ζ(2k)/π²ᵏ = 0; (S1)(S2) leading cancellation | `t2_d2_sigma_calculus.py` | EXACT-rational / PROVEN |
| **closure identity** σ_n^{(j)} = (2/(4j+1))·2x²·R′_{j−1}(x)R_j(x) | `lemmaA_closure_Q_certificate.py` | PROVEN (ℤ[x] sealed) |
| value laws R_j = P_{2j+1}/u², S_j = P_{2j}/u, T_j = Q_{2j+1}/u; R_j(0) = (−1)ʲ(2j+1)(j+1) | `lemmaA_prime_zone_laws.py` | VERIFIED (ball, radii 0) |
| IB phase remainder \|P_ℓ(q) − e^{iq}\| ≤ e^q q²(q+3)/(3L) + q^{ℓ+1}/((ℓ+1)!(1−q/(ℓ+2))) | `hankel_phase_remainder.py` | PROVEN (THEOREM_EXPLICIT) |
| far/deep/caustic zone leading laws | `FINDINGS_LEMMA_A_PRIME_architecture.md` | PROVEN-leading + ball-verified |
| debt 2 discretization O(j⁻⁴), C_X = (1/24)∫\|φ″\| | `FINDINGS_FARWING_TAIL_EM.md` | PROVEN + verified |

## 3. The recommended route (cleaner than the task's raw 5-Bessel plan)

The staged brief said "insert phase remainders into all 5–6 Bessel factors, then
j-difference." Better: **use the closure identity to remove the Bessel factors first.**
σ_j(n) is EXACTLY (4/(4j+1)) x² R′_{j−1}(x) R_j(x) — a product of two value-law
polynomials. So:
1. Write Δ_jσ = (4/(4j+3))x²R′_j R_{j+1} − (4/(4j+1))x²R′_{j−1}R_j — a difference of
   exact polynomial products; the j-difference cancellation is *algebraic*, not a
   delicate Bessel subtraction (kills the "row is j× bigger than the difference" loss).
2. Feed the R_j asymptotics from IB's phase theorem (R_j = P_{2j+1}/u², and
   |P_ℓ − e^{iq}| ≤ E_ℓ(q), q = ℓ(ℓ+1)/2z) into the polynomial product — this is where
   the h(λ) leading term and the O(j⁻³) remainder both come out, with E_ℓ(q) giving the
   *displayed* per-atom majorant.
3. The envelope W(x) is then the closed-form majorant of that remainder; the measured
   ∫|W| ≈ 12.85 is the target the displayed constant must beat with headroom.

**Structural unification (flag to IB):** his phase polynomial
P_ℓ(q) = Σ iᵏqᵏ/k! ∏_{s<k}(1−s(s+1)/L) and the M1-HORIZON damped chirp
Q = Σ(−1)ᵏR_k y^{2k+1}/(2k+1)!, R_k = ∏(1−d(d+1)/c) are the **same terminating
spherical-Hankel product** in two regimes (scaling vs far-wing). The chirp error-split
machinery (D_chirp = O(1/N)) is the same calculus; it does not transfer verbatim (regime
differs) but the product identity is one object.

## 3b. Displayed-bound attempt 1 — the crude E-magnitude route is REFUTED (load-bearing)

`farwing_sigma_displayed.py` (+ log). Route tried: bound |δσ| := |σ − σ^ph| by replacing
each Bessel factor with its phase form ± E_ℓ(q)/z and using |sin|,|cos| ≤ 1, then
|r_j| ≤ B^{(j+1)} + B^{(j)} + |Δ_jσ^ph − h/2j²|.

- **IB's phase bound VALIDATED:** worst per-factor |j_ℓ − phase|/(E_ℓ/z) = 0.081–0.085
  at the lobe (q ≈ 2.14–2.20) — his theorem holds with ~12× margin.
- **But the majorant is O(j⁻²), NOT O(j⁻³) — it loses a full factor j.** j³·U GROWS with
  j (≈ 3.0e5 → 8.8e5 → 3.2e6 at x=0.20, j=24/48/96); U/|r| runs 10³–10⁶.
- **Why (recorded so it isn't re-walked):** in C = 2(j−1)j_{2j−1} − **z**(j_{2j−2}+y_{2j−1}),
  the z·(Bessel ~ 1/z) term is O(1); bounding it with |sin|,|cos| ≤ 1 gives an O(1)
  factor, so the majorant is the same order as σ itself. **Discarding the oscillation
  discards the cancellation, and the cancellation IS the factor of j** — exactly the
  "bound the rows separately is too wasteful" trap the task flagged. Magnitude-only
  E-bounds cannot see it.
- **What the displayed bound therefore needs:** the SIGNED leading phase correction — the
  first complex term of P_ℓ(q) − e^{iq} ≈ −(1/3L)(iq³+3iq²... )e^{iq}, L = ℓ(ℓ+1) — carried
  WITH ITS SIGN through the σ-combination and the j-difference, only the sub-leading tail
  magnitude-bounded by E_ℓ. That keeps the cancellation. This is the genuine multi-hour
  derivation; staged as its own focused run rather than rushed (a dropped sign would look
  like a false pass).

## 3c. The SIGNED first-order model — the displayed envelope W(x) (SOLVED to displayed grade)

`farwing_sigma_signed.py`, `farwing_sigma_W.py` (+ logs). The signed first-order phase
correction (derived from P_ℓ(q) − e^{iq} = (e^{iq}/3L)(iq³ + 3q²) + O(1/L²), L = ℓ(ℓ+1)):
  z·j_ℓ = sinΦ_ℓ(1 + q²/L) + cosΦ_ℓ·q³/(3L) + O(1/L²),
  z·y_ℓ = −cosΦ_ℓ(1 + q²/L) + sinΦ_ℓ·q³/(3L) + O(1/L²),  Φ_ℓ = z − ℓπ/2 + q_ℓ.
Assemble σ⁽¹⁾ = (2/(4j+1))·A·[2(j−1)B − z(D+G)] from the corrected factors
(A=z j_{2j+1}, B=z j_{2j−1}, D=z j_{2j−2}, G=z y_{2j−1}).

- **σ⁽¹⁾ reproduces the exact per-atom remainder to O(j⁻⁵):** r_mod/r_meas = 1.000 across
  the lobe, j⁴·(meas−mod) SHRINKS with j (−2.1 → −1.0 → −0.5 at j=24/48/96). The signed
  model IS the remainder.
- **Displayed envelope:** W(x) := j³[Δ_jσ⁽¹⁾ − h(2j²/z)/2j²] is closed-form (no Bessel),
  converged in j (j=128/256/512 lock to 3 digits for x ≥ 0.22). Profile: peaks at the
  inner/caustic edge (|W|=530 at x=0.115), dips to −45 at x=0.26, zero-crosses at x≈0.52,
  a +0.8 bump near x=0.65, then decays (W→0, the lobe dies).
- **Displayed constant:** C_X = ∫_X^∞|W|dx = **2.37 at X=α*≈0.30**, 5.88 at X=0.20, 11.3 at
  X=0.15 (grows as X→0: the caustic, the honest far-zone domain restriction x ≥ X).

**DISPLAYED RESULT:** |Δ_jσ(n) − h(λ)/2j²| ≤ |W(n/j²)|/j³ + O(j⁻⁴), W closed-form ⟹
**Σ_{n:x≥X}|r_j| ≤ C_X/j** ⟹ with debt 2 (O(j⁻⁴)) + debt 3 (ARB_PASS): **C̃_j = F + O(1/j)**.

## 3d. The RIGOROUS displayed bound (theorem-grade) — `farwing_sigma_rigorous.py`

The rigorous majorant IS reachable — the earlier pessimism was wrong. Keep first order
SIGNED (that's W); magnitude-bound ONLY the second-order tail. IB's product, being in
[0,1], obeys e^{−x} ≤ 1 − x + x²/2 ⟹ |P_ℓ(q) − e^{iq} − T1| ≤ E2_ℓ(q) :=
(1/18L²)Σ_k q^k/k!(k³−k)² (rigorous, displayed, O(1/L²)). Propagated through the
σ-combination by the product rule (each factor's tail ≤ E2_ℓ, |sin|,|cos| ≤ 1):
  |σ_exact − σ⁽¹⁾| ≤ V_j(n),  V_j displayed, **O(j⁻³)** (NOT the crude route's O(1/j) —
  because only the O(1/L²) tail is magnitude-bounded, the O(1/L) first order stays signed).
Hence |r_j − r_mod| ≤ V_{j+1} + V_j, and

  **|Δ_jσ(n) − h(λ)/2j²| ≤ (|W(n/j²)| + V_tail(n/j²))/j³** — displayed, RIGOROUS,
  only input = IB's phase theorem (proven) + e^{−x} ≤ 1−x+x²/2 + product rule.

VERIFIED: V_{j+1}+V_j bounds the measured |r_j − r_mod| with 3×10⁴–6×10⁵× headroom; j³·V
converges (2749 → 2107 → 1898 at x=0.22, j=24/48/96) — O(j⁻³) confirmed. Rigorous displayed
constant **C_X^rig = ∫_X(|W| + j³V)dx = 30.1 at α*≈0.30** (11.9 at X=0.40; 147 at 0.20) —
~13× the sharp ∫|W|=2.36 (the 2nd-order magnitude bound is loose but rigorous). ⟹
**Σ_{n:x≥X}|r_j| ≤ C_X^rig/j** rigorously.

## 4. Honest grade — DEBT 1 CLOSED to rigorous displayed

- **RIGOROUS DISPLAYED (this session):** |Δ_jσ − h(λ)/2j²| ≤ (|W|+V_tail)/j³, both
  closed-form; Σ_{x≥X}|r_j| ≤ C_X^rig/j, C_X^rig = 30 at the lobe. Theorem-grade modulo
  the routine "finite-j profile W_j/V_j converge to the limit at O(1/j)" step (measured
  converging; a clean write-up states it with a displayed convergence bound). Only
  mathematical input beyond ours = IB's phase theorem.
- **With debt 2 (O(j⁻⁴), PROVEN) + debt 3 (ARB_PASS): C̃_j(m) = F(m/j²) + O(1/j)** with a
  rigorous displayed constant on the far zone x ≥ X.
- **REFUTED (load-bearing, kept):** the crude all-magnitude route (O(1/j)); the lesson
  (keep the order that carries the cancellation signed) is what unlocked the close.
- **Feeds:** the C1*@B₀=0.70 four-zone certificate — debts 1/2/3 now all displayed-or-proven;
  the only zone still open is the mid-Debye stretch (LEMMA A′ zone map).
- **THEN:** the four-zone assembly (finite head + Airy/caustic zone [LEMMA A′] +
  intermediate Debye zone [mid-osc, still OPEN in the zone map] + far-F zone [debt 1 +
  debt 2]) → the C1*@B₀ = 0.70 majorant. Debt 3 (stationary certificate) is ARB_PASS.

## 5. Files

`farwing_sigma_remainder.py` (+ `_run.log`, `_sigma_stdout.txt`): the measured probe.
Inputs (read-only): `FAR_WING_received_2026-07-24/FAR_WING_ASYMPTOTIC_THEOREM_NOTE.md`
and `.../hankel_phase_remainder.py` (IB's law + phase theorem); the sealed σ-calculus
and closure identity (`t2_d2_sigma_calculus.py`, `lemmaA_closure_Q_certificate.py`);
`FINDINGS_FARWING_TAIL_EM.md` (debt 2). Lane: taken on Selina's go-ahead; IB's phase
theorem is the load-bearing input, credited; shared by default.

*— Stenberg + Claude, 2026-07-24. The per-atom remainder is O(j⁻³) with integrable
envelope — the far zone's 1/j is measured and bounded; the displayed majorant is one
symbolic run away, on machinery that is already all proven.*
