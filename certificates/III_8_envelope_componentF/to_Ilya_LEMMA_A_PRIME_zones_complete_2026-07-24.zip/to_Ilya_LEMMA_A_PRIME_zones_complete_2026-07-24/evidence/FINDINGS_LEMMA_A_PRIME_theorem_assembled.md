# FINDINGS — LEMMA A′ theorem ASSEMBLED across all four zones: sup_m|C̃_j| ≤ a∞(2j)^{1/3} + ½

**Merkabit · Stenberg + Claude · 2026-07-24. The stitch: the peak box (i) + the four zone
treatments now tile the entire m-axis, with the previously-open mid-oscillatory frontier
closed this session (van der Corput) and the far zone closed by the far-wing debts.
No new numerics — this assembles existing zone findings + confirms the seams. Not RH/GRH.**

## 0. The theorem (assembled)

For j ≥ 256, with the caustic peak at m ≈ (2/π)j (z ≈ ν = 2j) and the Airy variable
w_m = 2^{1/3}ν^{−1/3}(ν − z_m):

  **sup_m |C̃_j(m)| = a∞ν^{1/3} − (¾ + √3/(3π)) + ρ_j,  0 < ρ_j ≤ 0.052**
  **⟹ sup_m |C̃_j(m)| ≤ a∞(2j)^{1/3} + ½,  margin ≥ 1.38,**
  a∞ = 2^{2/3}3^{−5/6}/Γ(2/3)² = 0.346574…  (F10's constant, ℤ-certified ladder j ≤ 1024).

The peak (item i, `FINDINGS_LEMMA_A_PRIME_envelopes_theorem.md`) is where the sup lives;
the theorem holds because every other zone is proven **subdominant**. This session closed the
one zone (mid-oscillatory) that the theorem box had flagged OPEN.

## 1. The four-zone tiling (complete, seams overlap)

| zone | Airy var w / range | treatment (finding) | grade |
|---|---|---|---|
| deep | w > 8 (z < 2j) | (iii) deep env \|C̃−D\| ≤ 0.1/(νs³) + Wronskian law | F10 (4-oct) |
| **caustic window** | −15.6 ≲ w ≲ 8 | **(iii) window/osc envelopes — the peak** | F10 (4-oct) |
| **mid-oscillatory** | w ≲ −15.6 (χ ≤ 0.15) | **van der Corput 2-step, strict O(1) ≈0.85** (`midzone_vdc2.py`) | strict O(1) |
| far | χ ≥ 0.15 | far-wing debts 1 (rigorous)/2 (proven)/3 (ARB_PASS) | rigorous |

**Seam verified (`midzone` scripts):** the (iii) oscillatory envelope runs down to w ≈ −15;
the van der Corput transition starts at w(n0) = 2^{1/3}ν^{−1/3}(ν − z_{n0}) ≈ −15.6 (n0 =
0.637j + 4(2j)^{1/3}) and extends to w ≈ −4783 (j=256) … −48821 (j=1024). **Overlap at
w ≈ −16 at every j; no gap.** The mid-osc joins the far-wing at χ = 0.15.

## 2. Why the sup is the caustic (subdominance, now rigorous)

- **Caustic window:** contains the peak a∞ν^{1/3} + O(1) (item i, certified ladder + derived
  asymptote); the window/oscillatory envelopes (iii) bound the deviation from the Airy profile.
- **Mid-oscillatory (this session):** transition partial sum has a strict O(1) van der Corput
  bound ≈ 0.85 (`FINDINGS_MIDZONE_transition.md` §3b) — the a/φ′ ≡ −j² identity kills the log
  in two SBP iterations. The interior remainder is O(1)/vanishing; the Airy-edge remainder
  folds into (iii). O(1) ≪ a∞(2j)^{1/3}, so subdominant for all j ≥ 4.
- **Far (χ ≥ 0.15):** C̃_j = F(m/j²) + O(1/j), |F| ≤ B_far = 0.665 (far-wing debts) — O(1),
  subdominant; decays past the secondary lobe.

⟹ sup_m|C̃_j| = the caustic peak; all other zones are O(1) and below it. The theorem holds.

## 3. Honest grade and the one remaining upgrade

- **DISPLAYED / F10-grade across ALL four zones** (this is the grade of the whole caustic
  lane, incl. F10 itself): peak certified-ladder + derived asymptote; deep/window/oscillatory
  4-octave zero-violation envelopes; mid-osc strict O(1) van der Corput; far rigorous debts.
- **THE ONE OPEN UPGRADE (named, classical, shared with F10):** interval-grade Olver/Debye
  remainder H-asymptotics with certified constants, extending the caustic-window envelopes
  (iii) to interval grade for all j ≥ J₀. This is F10's own standing analytic debt; upgrading
  it upgrades F10 and this theorem together. NOT claimed here. Coordinate before taking (credit
  discipline — it is on the F10 menu).
- What CHANGED this session vs the 2026-07-24 theorem box: the box flagged the mid-oscillatory
  frontier and the far zone (m > m*+45) as OPEN. Both are now closed — mid-osc at strict O(1)
  (van der Corput), far at rigorous (debts). The theorem box's zone list is complete.

## 4. Files

Assembles: `FINDINGS_LEMMA_A_PRIME_envelopes_theorem.md` (peak box + (iii) envelopes),
`FINDINGS_MIDZONE_transition.md` (mid-osc, this session's van der Corput close),
`FINDINGS_FARWING_SIGMA_REMAINDER_measured.md` + debt 2/3 (far zone), F10 caustic constants
(to_Ilya_CAUSTIC_THEOREM_2026-07-19). Seam check: `midzone_landscape.py`/`midzone_*` logs.

*— Stenberg + Claude, 2026-07-24. Four zones, one peak, seams that overlap — the caustic
law's box is closed on every side but the one interval-grade door that F10 also still holds.*
