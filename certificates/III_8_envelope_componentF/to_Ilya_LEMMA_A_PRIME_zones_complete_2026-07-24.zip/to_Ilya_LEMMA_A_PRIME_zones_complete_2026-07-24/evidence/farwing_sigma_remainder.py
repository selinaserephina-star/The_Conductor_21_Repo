# farwing_sigma_remainder.py -- far-wing DEBT 1 (IB's flagged lane, taken on Selina's
# go-ahead; built on IB's spherical-Hankel phase theorem + his exact sigma-calculus).
# NUMERICS-FIRST step: measure the per-atom remainder of the j-difference of the exact
# row against IB's LEADING far-wing law, confirm the O(j^{-3}) structure with cancellation
# preserved, and extract the candidate integrable envelope W(x), x = n/j^2.
#
# Exact row (FAR_WING_ASYMPTOTIC_THEOREM_NOTE sec.1), z_n=(n-1/2)pi:
#   sigma_j(n) = (2/(4j+1)) z^2 j_{2j+1}(z) [ 2(j-1) j_{2j-1}(z) - z( j_{2j-2}(z)+y_{2j-1}(z) ) ]
# Leading law (his sec.2):  sigma_{j+1}(n)-sigma_j(n) = (1/(2j^2)) h(lambda_n) + O(j^{-3}),
#   h(l) = -2l^2 cos2l + (3/2) l sin2l + (cos2l-1)/2,  lambda_n = 2 j^2 / z_n  (l=2j).
# DEBT 1 target:  r_j(n) := Delta_j sigma - (1/(2j^2)) h(lambda_n)  =  O(j^{-3} W(n/j^2)),
#   W integrable  ==>  sum_n r_j(n) = O(1/j)  (the 1/j the far zone owes; debt 2 gave the
#   discretization at O(j^{-4})). Here we MEASURE r_j and the profile j^3 * r_j vs x. Not RH/GRH.
import time, math
import mpmath as mp
mp.mp.dps = 40

def sj(l, z):   # spherical Bessel j_l
    return mp.sqrt(mp.pi/(2*z)) * mp.besselj(l + mp.mpf(1)/2, z)
def sy(l, z):   # spherical Bessel y_l (Neumann)
    return mp.sqrt(mp.pi/(2*z)) * mp.bessely(l + mp.mpf(1)/2, z)

def sigma(j, n):
    z = (n - mp.mpf(1)/2)*mp.pi
    br = 2*(j-1)*sj(2*j-1, z) - z*(sj(2*j-2, z) + sy(2*j-1, z))
    return (mp.mpf(2)/(4*j+1)) * z*z * sj(2*j+1, z) * br

def h(l):
    return -2*l*l*mp.cos(2*l) + mp.mpf(3)/2*l*mp.sin(2*l) + (mp.cos(2*l)-1)/2

LOG = open(__file__.replace('.py', '_run.log'), 'w')
def log(s):
    print(s, flush=True); LOG.write(s + '\n'); LOG.flush()
log(f"=== far-wing debt 1 (per-atom sigma remainder) @ {time.strftime('%Y-%m-%d %H:%M:%S')} ===")
log("built on IB's phase theorem + sigma-calculus; taken on Selina's go-ahead (lane flagged).")

# ---- step 0: confirm the leading law itself (Delta_j sigma ~ (1/2j^2) h(lambda)) ----
log("\n-- leading-law check: 2 j^2 * Delta_j sigma  vs  h(lambda_n), lambda=2j^2/z --")
for j in (16, 32, 64):
    x = mp.mpf('0.30'); n = int(mp.nint(x*j*j))
    z = (n - mp.mpf(1)/2)*mp.pi
    lam = 2*j*j/z
    dsig = sigma(j+1, n) - sigma(j, n)
    lead = h(lam)/(2*j*j)
    log(f"j={j:4d} n={n:6d} x={float(n)/(j*j):.4f}: 2j^2*Dsig={float(2*j*j*dsig):+.6f} "
        f"h(lam)={float(h(lam)):+.6f}  ratio={float(2*j*j*dsig/h(lam)):.4f}  "
        f"r=Dsig-lead={float(dsig-lead):+.3e}  j^3*r={float(j**3*(dsig-lead)):+.4f}")

# ---- step 1: the remainder profile j^3 * r_j(n) vs x = n/j^2 across a lobe window ----
log("\n-- remainder profile: is r_j(n) = O(j^{-3}) and j^3*r_j a bounded integrable W(x)? --")
JS = (24, 48, 96)
XS = [mp.mpf(s)/100 for s in range(16, 61, 4)]   # x = 0.16 .. 0.60
prof = {j: {} for j in JS}
for j in JS:
    t0 = time.time()
    for x in XS:
        n = int(mp.nint(x*j*j))
        if n < 2:
            continue
        z = (n - mp.mpf(1)/2)*mp.pi
        lam = 2*j*j/z
        dsig = sigma(j+1, n) - sigma(j, n)
        r = dsig - h(lam)/(2*j*j)
        prof[j][float(x)] = float(j**3 * r)
    log(f"  j={j}: profile computed ({time.time()-t0:.0f}s)")

log(f"\n{'x':>6}" + "".join(f"  j^3*r(j={j})" for j in JS) + "   collapse?")
for x in XS:
    xf = float(x)
    vals = [prof[j].get(xf) for j in JS]
    if any(v is None for v in vals):
        continue
    spread = max(vals) - min(vals)
    log(f"{xf:6.2f}" + "".join(f"  {v:+11.4f}" for v in vals)
        + f"   spread={spread:+.3f} ({'STABLE' if abs(spread) < 0.15*max(1e-9,abs(vals[-1])) else 'drift'})")

# crude integrated envelope on the finest j
jf = JS[-1]
W = [(x, abs(prof[jf][float(x)])) for x in XS if float(x) in prof[jf]]
approxint = sum(W[i][1]*0.04 for i in range(len(W)))   # step 0.04 in x
log(f"\napprox  integral_x |j^3 r| dx  at j={jf}  ~ {approxint:.3f}  "
    f"(finite ==> W integrable ==> sum_n r_j = O(1/j) with this constant)")
log("\ndone.  (next: displayed W-bound via IB's E_ell(q); then four-zone assembly.)")
LOG.close()
