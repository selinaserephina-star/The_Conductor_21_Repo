# midzone_vdc.py -- mid-Debye transition: the DISPLAYED van der Corput constant.
# Rigorous summation-by-parts for the leading transition sum Sum h(lambda_n)/2j^2,
#   h(l) = -2 l^2 cos2l + (3/2) l sin2l + (cos2l-1)/2,  lambda_n = 2j^2/z_n, z_n=(n-1/2)pi.
# Decompose into oscillatory pieces a_n e^{i phi_n}, phi_n = 2 lambda_n, a_n in {lambda^2,
# lambda, 1}, plus the non-oscillatory -1/2.  EXACT summation-by-parts:
#   a_n e^{i phi_n} = c_n (e^{i phi_{n+1}} - e^{i phi_n}),  c_n = a_n/(e^{i(phi_{n+1}-phi_n)}-1)
#   => Sum = c_{n1} e^{i phi_{n1+1}} - c_{n0} e^{i phi_{n0}} - Sum (c_n - c_{n-1}) e^{i phi_n}
#   => |Sum| <= |c_{n1}| + |c_{n0}| + Sum|c_n - c_{n-1}|  (DISPLAYED, rigorous).
# The magic a/phi' = -j^2 const makes the boundary c_n ~ j^2 and the corrector Sum|dc| small
# => after /2j^2 the transition sum is O(1) with a DISPLAYED constant.  Verify vs direct sum,
# uniform in j; also MEASURE the remainder Sum(Delta_j sigma - h/2j^2) over the transition.
import time, math
import mpmath as mp
mp.mp.dps = 40
I = mp.mpc(0, 1)

def sj(l, z): return mp.sqrt(mp.pi/(2*z))*mp.besselj(l+mp.mpf(1)/2, z)
def sy(l, z): return mp.sqrt(mp.pi/(2*z))*mp.bessely(l+mp.mpf(1)/2, z)
def dsigma(j, n):
    z=(n-mp.mpf(1)/2)*mp.pi
    def sig(J): return (mp.mpf(2)/(4*J+1))*z*z*sj(2*J+1,z)*(2*(J-1)*sj(2*J-1,z)-z*(sj(2*J-2,z)+sy(2*J-1,z)))
    return sig(j+1)-sig(j)
def h(l): return -2*l*l*mp.cos(2*l)+mp.mpf(3)/2*l*mp.sin(2*l)+(mp.cos(2*l)-1)/2

def sbp_bound(a_of, n0, n1, lam):
    """|Sum_{n0}^{n1} a_n e^{i phi_n}| <= |c_{n1}|+|c_{n0}|+Sum|dc|, phi_n=2 lam_n. Also return
    the exact SBP value (should match direct)."""
    phi = {n: 2*lam(n) for n in range(n0, n1+2)}
    c = {}
    for n in range(n0, n1+1):
        d = phi[n+1]-phi[n]
        c[n] = a_of(n)/(mp.exp(I*d)-1)
    bnd = abs(c[n1]) + abs(c[n0])
    corr = mp.mpf(0)
    for n in range(n0+1, n1+1):
        corr += abs(c[n]-c[n-1])
    bnd += corr
    val = c[n1]*mp.exp(I*phi[n1+1]) - c[n0]*mp.exp(I*phi[n0])
    for n in range(n0+1, n1+1):
        val -= (c[n]-c[n-1])*mp.exp(I*phi[n])
    return bnd, val, abs(c[n1]), abs(c[n0]), corr

LOG=open(__file__.replace('.py','_run.log'),'w')
def log(s):
    print(s,flush=True);LOG.write(s+'\n');LOG.flush()
log(f"=== mid-Debye van der Corput displayed constant @ {time.strftime('%Y-%m-%d %H:%M:%S')} ===")

log("\n-- SBP displayed bound on Sum h(lambda)/2j^2 over the transition, uniform in j --")
log(f"{'j':>5} {'directSum':>11} {'SBPbound':>10} {'bnd/|sum|':>9} {'|c_n1|/2j2':>10} {'|c_n0|/2j2':>10} {'corr/2j2':>9}")
for j in (24, 48, 96, 192):
    t0=time.time()
    caustic=0.6366*j
    n0=int(caustic+4*(2*j)**(1.0/3))+1; n1=int(0.15*j*j)
    def lam(n): return 2*mp.mpf(j)*j/((n-mp.mpf(1)/2)*mp.pi)
    # direct sum of h/2j^2
    direct = mp.mpf(0)
    for n in range(n0, n1+1):
        direct += h(lam(n))/(2*j*j)
    # three oscillatory components + non-osc -1/2
    # h/2j^2 = (-1/j^2) Re[lam^2 e] + (3/4j^2) Im[lam e] + (1/4j^2) Re[1 e] + (-1/4j^2)*Npts
    b2,v2,cN2,c02,cr2 = sbp_bound(lambda n: lam(n)**2, n0, n1, lam)
    b1,v1,cN1,c01,cr1 = sbp_bound(lambda n: lam(n),    n0, n1, lam)
    b0,v0,cN0,c00,cr0 = sbp_bound(lambda n: mp.mpf(1), n0, n1, lam)
    Npts = n1-n0+1
    # exact SBP reconstruction of Sum h/2j^2:
    recon = (-1/mp.mpf(j*j))*v2.real + (mp.mpf(3)/(4*j*j))*v1.imag + (1/mp.mpf(4*j*j))*v0.real + (-1/mp.mpf(4*j*j))*Npts
    # displayed bound: coeff * component bound
    bound = (1/mp.mpf(j*j))*b2 + (mp.mpf(3)/(4*j*j))*b1 + (1/mp.mpf(4*j*j))*b0 + (1/mp.mpf(4*j*j))*Npts
    log(f"{j:>5} {float(direct):+11.5f} {float(bound):10.4f} {float(bound/abs(direct)):9.2f} "
        f"{float((1/mp.mpf(j*j))*cN2):10.4f} {float((1/mp.mpf(j*j))*c02):10.4f} {float((1/mp.mpf(j*j))*cr2):9.4f}"
        f"  (recon-direct={float(abs(recon-direct)):.1e}, {time.time()-t0:.0f}s)")

log("\n-- remainder Sum(Delta_j sigma - h/2j^2) over the transition (is it O(1)?) --")
for j in (24, 48, 96):
    t0=time.time()
    caustic=0.6366*j; n0=int(caustic+4*(2*j)**(1.0/3))+1; n1=int(0.15*j*j)
    def lam(n): return 2*mp.mpf(j)*j/((n-mp.mpf(1)/2)*mp.pi)
    rem=mp.mpf(0); suprem=mp.mpf(0); running=mp.mpf(0)
    for n in range(n0, n1+1):
        r = dsigma(j,n) - h(lam(n))/(2*j*j)
        running += r
        if abs(running)>suprem: suprem=abs(running)
    log(f"  j={j}: Sum_transition r = {float(running):+.5f}, sup|partial| = {float(suprem):.5f}  ({time.time()-t0:.0f}s)")
log("\ndone.  displayed van der Corput bound on the leading transition sum; remainder O(1) measured.")
LOG.close()
