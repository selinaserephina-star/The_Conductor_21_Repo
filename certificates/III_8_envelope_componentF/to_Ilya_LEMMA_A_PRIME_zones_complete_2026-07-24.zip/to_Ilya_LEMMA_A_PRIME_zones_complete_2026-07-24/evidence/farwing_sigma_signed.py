# farwing_sigma_signed.py -- far-wing DEBT 1, the SIGNED first-order phase model.
# The crude E-magnitude bound lost a factor j (it discarded the oscillation = the
# cancellation). Here we keep the SIGN: expand each z*factor to first order in
# 1/L (L=l(l+1)) with the signed correction from P_l(q)-e^{iq} = (e^{iq}/3L)(iq^3+3q^2)+O(1/L^2):
#     z j_l = sinPhi (1+q^2/L) + cosPhi (q^3/3L) + O(1/L^2)
#     z y_l = -cosPhi(1+q^2/L) + sinPhi (q^3/3L) + O(1/L^2)
#   Phi_l = z - l pi/2 + q_l,  q_l = l(l+1)/2z,  L_l = l(l+1).
# Build sigma^(0) (leading) and sigma^(1) (leading + signed first order); test whether
#   r_j^model := Delta_j sigma^(1) - h(lambda)/2j^2   reproduces the MEASURED
#   r_j := Delta_j sigma^exact - h/2j^2   to O(j^-4).  If yes, sigma^(1) IS the displayed
# remainder (closed form), and the rigorous tail is the O(1/L^2) piece. Not RH/GRH.
import time, math
import mpmath as mp
mp.mp.dps = 40

def sj(l, z): return mp.sqrt(mp.pi/(2*z))*mp.besselj(l+mp.mpf(1)/2, z)
def sy(l, z): return mp.sqrt(mp.pi/(2*z))*mp.bessely(l+mp.mpf(1)/2, z)
def q_(l, z): return mp.mpf(l*(l+1))/(2*z)
def Phi(l, z): return z - l*mp.pi/2 + q_(l, z)

def zj0(l, z): return mp.sin(Phi(l, z))                 # leading z*j_l
def zy0(l, z): return -mp.cos(Phi(l, z))                # leading z*y_l
def zj1(l, z):                                          # + signed first order
    ph = Phi(l, z); q = q_(l, z); L = mp.mpf(l*(l+1))
    return mp.sin(ph)*(1 + q*q/L) + mp.cos(ph)*(q**3/(3*L))
def zy1(l, z):
    ph = Phi(l, z); q = q_(l, z); L = mp.mpf(l*(l+1))
    return -mp.cos(ph)*(1 + q*q/L) + mp.sin(ph)*(q**3/(3*L))

def h(lam): return -2*lam*lam*mp.cos(2*lam)+mp.mpf(3)/2*lam*mp.sin(2*lam)+(mp.cos(2*lam)-1)/2

def sigma_exact(j, n):
    z = (n-mp.mpf(1)/2)*mp.pi
    return (mp.mpf(2)/(4*j+1))*z*z*sj(2*j+1,z)*(2*(j-1)*sj(2*j-1,z)-z*(sj(2*j-2,z)+sy(2*j-1,z)))
def sigma_model(j, n, order):
    # sigma = (2/(4j+1)) * A * [2(j-1)B - z(D+G)],  A=z j_{2j+1}, B=z j_{2j-1},
    #         D=z j_{2j-2}, G=z y_{2j-1}    (since z^2 j_{2j+1} C = A*(zC))
    z = (n-mp.mpf(1)/2)*mp.pi
    zj = zj0 if order == 0 else zj1
    zy = zy0 if order == 0 else zy1
    A = zj(2*j+1, z); B = zj(2*j-1, z); D = zj(2*j-2, z); G = zy(2*j-1, z)
    return (mp.mpf(2)/(4*j+1))*A*(2*(j-1)*B - z*(D + G))

LOG = open(__file__.replace('.py', '_run.log'), 'w')
def log(s):
    print(s, flush=True); LOG.write(s+'\n'); LOG.flush()
log(f"=== far-wing debt 1 SIGNED first-order model @ {time.strftime('%Y-%m-%d %H:%M:%S')} ===")

log("\n-- does the signed model reproduce the measured remainder r_j to O(j^-4)? --")
log("   r_meas = Dj sigma_exact - h/2j^2 ;  r_mod = Dj sigma^(1) - h/2j^2")
log("   key columns: j^3*r_meas, j^3*r_mod (should agree),  j^4*(r_meas-r_mod) (bounded=tail)")
JS = (24, 48, 96)
XS = [mp.mpf(s)/100 for s in range(22, 53, 5)]
for j in JS:
    t0 = time.time()
    log(f"\n  j={j}:   x  |  j^3*r_meas | j^3*r_mod | r_mod/r_meas | j^4*(meas-mod) | (Dj s0 - h/2j2)*2j2")
    for x in XS:
        n = int(mp.nint(x*j*j)); z = (n-mp.mpf(1)/2)*mp.pi
        lam = 2*j*j/z
        hh = h(lam)/(2*j*j)
        rme = (sigma_exact(j+1,n)-sigma_exact(j,n)) - hh
        rmo = (sigma_model(j+1,n,1)-sigma_model(j,n,1)) - hh
        # leading-model discretization (how well sigma^(0) alone gives h):
        s0d = ((sigma_model(j+1,n,0)-sigma_model(j,n,0)) - hh)*2*j*j
        log(f"        {float(x):.2f} | {float(j**3*rme):+9.3f} | {float(j**3*rmo):+9.3f} | "
            f"{float(rmo/rme) if rme!=0 else 0:+7.3f} | {float(j**4*(rme-rmo)):+11.2f} | {float(s0d):+.4f}")
    log(f"     ({time.time()-t0:.0f}s)")
log("\ndone.  if j^3*r_mod tracks j^3*r_meas and j^4*(meas-mod) is bounded, the signed")
log("model is the displayed remainder (closed form); the O(1/L^2) tail is the rigorous error.")
LOG.close()
