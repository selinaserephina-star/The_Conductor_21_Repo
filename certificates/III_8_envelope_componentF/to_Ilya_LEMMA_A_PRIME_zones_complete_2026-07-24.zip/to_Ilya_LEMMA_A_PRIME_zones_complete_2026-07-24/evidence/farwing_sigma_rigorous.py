# farwing_sigma_rigorous.py -- far-wing DEBT 1: the RIGOROUS displayed bound.
# r_j = r_mod + tail,  r_mod = Delta_j sigma^(1) - h/2j^2 (signed first order, = W/j^3),
# and |r_j - r_mod| <= V_{j+1}+V_j with V from the RIGOROUS 2nd-order tail bound
#   |z j_l - (sinPhi + T1)| <= E2_l(q),  E2_l = (1/18L^2) Sum_k q^k/k! (k^3-k)^2,
# via e^{-x} <= 1 - x + x^2/2 on prod(1 - s(s+1)/L).  Propagated by the product rule
# (keeps first order signed, magnitude-bounds only the 2nd-order tail) -> V = O(j^-3),
# the SAME order as W (not the factor-j-losing O(1/j) of the crude all-magnitude route).
# Then |r_j| <= |W(x)|/j^3 + V-bound => Sum_{x>=X}|r_j| <= C_X^rig/j, DISPLAYED & RIGOROUS.
# Verify: bound >= measured |r_j - r_mod| with headroom; j^3*(V+|W|) converges; integral finite.
# Not RH/GRH.
import time, math
import mpmath as mp
mp.mp.dps = 40

def sj(l, z): return mp.sqrt(mp.pi/(2*z))*mp.besselj(l+mp.mpf(1)/2, z)
def sy(l, z): return mp.sqrt(mp.pi/(2*z))*mp.bessely(l+mp.mpf(1)/2, z)
def q_(l, z): return mp.mpf(l*(l+1))/(2*z)
def Phi(l, z): return z - l*mp.pi/2 + q_(l, z)
def t1mag(l, z):   # bound on |T1| for a z-scaled factor: q^2/L + q^3/3L
    q = q_(l, z); L = mp.mpf(l*(l+1)); return q*q/L + q**3/(3*L)
def Ebound(l, z):  # IB's first-order magnitude bound |P_l - e^{iq}| <= E
    q = q_(l, z); L = mp.mpf(l*(l+1)); return mp.e**q*q*q*(q+3)/(3*L)   # 2nd IB term ~0 here
_KMAX = 60
def E2bound(l, z): # rigorous 2nd-order tail: (1/18L^2) Sum q^k/k! (k^3-k)^2
    q = q_(l, z); L = mp.mpf(l*(l+1))
    s = mp.mpf(0); term = mp.mpf(1)
    for k in range(0, _KMAX):
        s += term*(k**3-k)**2; term = term*q/(k+1)
    return s/(18*L*L)

def zj1(l, z):
    ph = Phi(l, z); q = q_(l, z); L = mp.mpf(l*(l+1))
    return mp.sin(ph)*(1 + q*q/L) + mp.cos(ph)*(q**3/(3*L))
def zy1(l, z):
    ph = Phi(l, z); q = q_(l, z); L = mp.mpf(l*(l+1))
    return -mp.cos(ph)*(1 + q*q/L) + mp.sin(ph)*(q**3/(3*L))
def h(lam): return -2*lam*lam*mp.cos(2*lam)+mp.mpf(3)/2*lam*mp.sin(2*lam)+(mp.cos(2*lam)-1)/2

def sigma_ex(j, n):
    z=(n-mp.mpf(1)/2)*mp.pi
    return (mp.mpf(2)/(4*j+1))*z*z*sj(2*j+1,z)*(2*(j-1)*sj(2*j-1,z)-z*(sj(2*j-2,z)+sy(2*j-1,z)))
def sigma_m1(j, n):
    z=(n-mp.mpf(1)/2)*mp.pi
    A=zj1(2*j+1,z);B=zj1(2*j-1,z);D=zj1(2*j-2,z);G=zy1(2*j-1,z)
    return (mp.mpf(2)/(4*j+1))*A*(2*(j-1)*B - z*(D+G))
def Vbound(j, n):
    # rigorous bound on |sigma_ex - sigma_m1| via per-factor E2 + product rule
    z=(n-mp.mpf(1)/2)*mp.pi
    E2A=E2bound(2*j+1,z);E2B=E2bound(2*j-1,z);E2D=E2bound(2*j-2,z);E2G=E2bound(2*j-1,z)
    EB=Ebound(2*j-1,z);ED=Ebound(2*j-2,z);EG=Ebound(2*j-1,z)
    Br_ex = 2*(j-1)*(1+EB) + z*(2 + ED + EG)          # |2(j-1)B - z(D+G)|_exact upper
    A1 = 1 + t1mag(2*j+1, z)                           # |A^(1)| upper
    return (mp.mpf(2)/(4*j+1))*( E2A*Br_ex + A1*(2*(j-1)*E2B + z*(E2D+E2G)) )

LOG=open(__file__.replace('.py','_run.log'),'w')
def log(s):
    print(s,flush=True);LOG.write(s+'\n');LOG.flush()
log(f"=== far-wing debt 1 RIGOROUS bound @ {time.strftime('%Y-%m-%d %H:%M:%S')} ===")
log("keep 1st order signed (=W); rigorously magnitude-bound only the 2nd-order tail (E2).")

log("\n-- does V_{j+1}+V_j rigorously bound |r_j - r_mod|, and stay O(j^-3)? --")
log(f"{'j':>4} {'x':>6} {'|r-rmod|meas':>13} {'V_{j+1}+V_j':>13} {'bound/meas':>10} {'j^3*bound':>10}")
JS=(24,48,96); XS=[mp.mpf(s)/100 for s in range(22,53,5)]
for j in JS:
    t0=time.time()
    for x in XS:
        n=int(mp.nint(x*j*j)); z=(n-mp.mpf(1)/2)*mp.pi; hh=h(2*j*j/z)/(2*j*j)
        rme=(sigma_ex(j+1,n)-sigma_ex(j,n))-hh
        rmo=(sigma_m1(j+1,n)-sigma_m1(j,n))-hh
        meas=abs(rme-rmo)
        bnd=Vbound(j+1,n)+Vbound(j,n)
        log(f"{j:>4} {float(x):6.2f} {float(meas):13.3e} {float(bnd):13.3e} "
            f"{float(bnd/meas) if meas>0 else 0:10.1f} {float(j**3*bnd):10.3f}")
    log(f"    ({time.time()-t0:.0f}s)")

# rigorous C_X = int_X (|W| + j^3*V) dx, using the cheap models at large j
log("\n-- rigorous displayed constant  C_X^rig = int_X (|W(x)| + limit j^3*V) dx --")
def Wlim(j,n):
    z=(n-mp.mpf(1)/2)*mp.pi; return float(j**3*((sigma_m1(j+1,n)-sigma_m1(j,n))-h(2*j*j/z)/(2*j*j)))
def V3(j,n): return float(j**3*(Vbound(j+1,n)+Vbound(j,n)))
j=256; xs=[0.15+0.01*k for k in range(0,120)]
pts=[]
t0=time.time()
for x in xs:
    n=int(round(x*j*j)); pts.append((x, abs(Wlim(j,n)), V3(j,n)))
log(f"  (mapped {len(pts)} pts at j={j}, {time.time()-t0:.0f}s)")
def integ(X,which):
    s=0.0
    for i in range(len(pts)-1):
        if pts[i][0]>=X:
            a=pts[i][which]+pts[i+1][which]; s+=0.5*a*0.01
    return s
for X in (0.15,0.20,0.2957,0.30,0.40):
    cw=integ(X,1); cv=integ(X,2)
    log(f"  X={X:.4f}: int|W|={cw:7.3f}  int(j^3 V)={cv:9.3f}  C_X^rig=|W|+V bound={cw+cv:9.3f}  "
        f"=>  Sum_{{x>=X}}|r_j| <= {cw+cv:.2f}/j")
log("\ndone.  DEBT 1 RIGOROUS: |Delta_j sigma - h/2j^2| <= (|W(x)| + Vtail(x))/j^3, both displayed;")
log("Sum_{x>=X}|r_j| <= C_X^rig/j.  Only input = IB's phase theorem (proven). Not RH/GRH.")
LOG.close()
