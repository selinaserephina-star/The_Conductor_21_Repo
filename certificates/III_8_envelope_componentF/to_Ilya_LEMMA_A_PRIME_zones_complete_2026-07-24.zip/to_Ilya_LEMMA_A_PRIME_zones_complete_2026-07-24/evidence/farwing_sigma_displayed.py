# farwing_sigma_displayed.py -- far-wing DEBT 1, the DISPLAYED per-atom bound via IB's
# phase remainder E_ell(q). Route: sigma's phase-remainder delta_sigma = sigma - sigma^ph
# is ALREADY O(j^-3) (each Bessel factor's remainder is <= E_ell(q)/z, E ~ 1/nu^2 ~ 1/4j^2),
# so bounding the j-difference of delta_sigma by a SUM stays O(j^-3) -- no factor-j loss.
#   r_j(n) = Delta_j sigma - h(lambda)/(2j^2)
#          = [Delta_j sigma - Delta_j sigma^ph] + [Delta_j sigma^ph - h/(2j^2)]
#   |r_j| <= B^{(j+1)} + B^{(j)} + D_ph,  B^{(j)} = E-based majorant of |delta_sigma^{(j)}|,
#   D_ph = |Delta_j sigma^ph - h/(2j^2)| (the phase model's own discretization).
# All three DISPLAYED via E_ell(q) + |sin|,|cos|<=1. Verify: bound >= measured |r_j| with
# headroom, and profile j^3 * bound vs x = n/j^2 integrable -> Sum_n = O(1/j). Not RH/GRH.
import time, math
import mpmath as mp
mp.mp.dps = 40

def sj(l, z): return mp.sqrt(mp.pi/(2*z))*mp.besselj(l+mp.mpf(1)/2, z)
def sy(l, z): return mp.sqrt(mp.pi/(2*z))*mp.bessely(l+mp.mpf(1)/2, z)
def q_of(l, z): return mp.mpf(l*(l+1))/(2*z)
def phase(l, z): return z - l*mp.pi/2 + q_of(l, z)
def jph(l, z): return mp.sin(phase(l, z))/z
def yph(l, z): return -mp.cos(phase(l, z))/z
def E(l, z):
    q = q_of(l, z); L = mp.mpf(l*(l+1))
    t1 = mp.e**q * q*q*(q+3)/(3*L)
    if q < l+2:
        t2 = q**(l+1)/(mp.factorial(l+1)*(1 - q/(l+2)))
    else:
        t2 = mp.mpf(0)   # (not reached at the lobe; q ~ 2.15 << l+2)
    return t1 + t2

def h(lam): return -2*lam*lam*mp.cos(2*lam)+mp.mpf(3)/2*lam*mp.sin(2*lam)+(mp.cos(2*lam)-1)/2

def sigma(j, n):
    z = (n-mp.mpf(1)/2)*mp.pi
    return (mp.mpf(2)/(4*j+1))*z*z*sj(2*j+1,z)*(2*(j-1)*sj(2*j-1,z)-z*(sj(2*j-2,z)+sy(2*j-1,z)))
def sigma_ph(j, n):
    z = (n-mp.mpf(1)/2)*mp.pi
    return (mp.mpf(2)/(4*j+1))*z*z*jph(2*j+1,z)*(2*(j-1)*jph(2*j-1,z)-z*(jph(2*j-2,z)+yph(2*j-1,z)))
def Bbound(j, n):
    # rigorous majorant of |sigma - sigma^ph| via |eps_l| <= E_l/z and |sin|,|cos|<=1
    z = (n-mp.mpf(1)/2)*mp.pi
    eA = E(2*j+1, z)/z
    eC = 2*(j-1)*(E(2*j-1, z)/z) + z*(E(2*j-2, z)/z + E(2*j-1, z)/z)   # |eps_C|
    Aph = 1/z                                                          # |jph_{2j+1}| <= 1/z
    Cph = 2*(j-1)/z + z*(1/z + 1/z)                                    # |C^ph| bound
    return (mp.mpf(2)/(4*j+1))*z*z*(eA*Cph + Aph*eC + eA*eC)

LOG = open(__file__.replace('.py', '_run.log'), 'w')
def log(s):
    print(s, flush=True); LOG.write(s+'\n'); LOG.flush()
log(f"=== far-wing debt 1 DISPLAYED bound via E_ell(q) @ {time.strftime('%Y-%m-%d %H:%M:%S')} ===")

# ---- validate IB's per-factor phase bound |j_l - jph_l| <= E_l/z at the lobe ----
log("\n-- validate |j_l - phase|/(E_l/z) <= 1  (IB phase theorem, at x=0.30 lobe) --")
for j in (16, 32, 64):
    n = int(mp.nint(mp.mpf('0.30')*j*j)); z = (n-mp.mpf(1)/2)*mp.pi
    worst = 0.0
    for l in (2*j-2, 2*j-1, 2*j+1):
        dj = abs(sj(l,z)-jph(l,z))*z/E(l,z); worst = max(worst, float(dj))
    dy = abs(sy(2*j-1,z)-yph(2*j-1,z))*z/E(2*j-1,z)
    log(f"  j={j:3d} n={n:6d} q={float(q_of(2*j,z)):.3f}: worst |err|/(E/z) = "
        f"{max(worst,float(dy)):.3f}  (<=1 confirms IB's bound holds)")

# ---- displayed bound vs measured remainder, profile + headroom ----
log("\n-- displayed U_j(n) = B^{j+1}+B^{j}+D_ph  vs measured |r_j|, and j^3*U profile --")
JS = (24, 48, 96)
XS = [mp.mpf(s)/100 for s in range(20, 57, 4)]   # far-lobe window x=0.20..0.56
for j in JS:
    t0 = time.time(); rows = []
    for x in XS:
        n = int(mp.nint(x*j*j));  z = (n-mp.mpf(1)/2)*mp.pi
        lam = 2*j*j/z
        dsig = sigma(j+1, n) - sigma(j, n)
        r = dsig - h(lam)/(2*j*j)                          # measured remainder
        dph = abs((sigma_ph(j+1,n)-sigma_ph(j,n)) - h(lam)/(2*j*j))
        U = Bbound(j+1, n) + Bbound(j, n) + dph            # displayed upper bound on |r|
        rows.append((float(x), float(abs(r)), float(U), float(j**3*U)))
    log(f"  j={j}  ({time.time()-t0:.0f}s)   x |  |r_j|meas  |  U(disp)  | U/|r| | j^3*U")
    integ = 0.0
    for x, ar, U, jU in rows:
        log(f"        {x:5.2f} | {ar:.4e} | {U:.4e} | {U/max(ar,1e-30):5.2f} | {jU:8.3f}")
        integ += jU*0.04
    log(f"     -> approx integral_x (j^3 U) dx = {integ:.3f}  ==>  Sum_n U_j = O(1/j) at this const")
log("\ndone.")
LOG.close()
