# midzone_remainder.py -- mid-Debye: WHERE does the transition remainder Sum r_j accumulate?
# r_j(n) = Delta_j sigma(n) - h(lambda_n)/2j^2.  Per debt 1, r_j ~ W(chi)/j^3 with W ~ 1/chi^2
# near the Airy edge -> Sum r_j is O(1) but front-loaded near chi_Airy.  If so, the remainder
# merges with the caustic-window Airy estimate (item ii); the mid-osc INTERIOR remainder is
# small.  Measure the running partial sum vs chi, split by chi-decade, to decide. Not RH/GRH.
import time, math
import mpmath as mp
mp.mp.dps = 45
def sj(l,z): return mp.sqrt(mp.pi/(2*z))*mp.besselj(l+mp.mpf(1)/2,z)
def sy(l,z): return mp.sqrt(mp.pi/(2*z))*mp.bessely(l+mp.mpf(1)/2,z)
def dsig(j,n):
    z=(n-mp.mpf(1)/2)*mp.pi
    def s(J): return (mp.mpf(2)/(4*J+1))*z*z*sj(2*J+1,z)*(2*(J-1)*sj(2*J-1,z)-z*(sj(2*J-2,z)+sy(2*J-1,z)))
    return s(j+1)-s(j)
def h(l): return -2*l*l*mp.cos(2*l)+mp.mpf(3)/2*l*mp.sin(2*l)+(mp.cos(2*l)-1)/2

LOG=open(__file__.replace('.py','_run.log'),'w')
def log(s):
    print(s,flush=True);LOG.write(s+'\n');LOG.flush()
log(f"=== mid-Debye remainder accumulation @ {time.strftime('%Y-%m-%d %H:%M:%S')} ===")

for j in (48, 96):
    t0=time.time()
    caustic=0.6366*j; n0=int(caustic+4*(2*j)**(1.0/3))+1; n1=int(0.15*j*j)
    def lam(n): return 2*mp.mpf(j)*j/((n-mp.mpf(1)/2)*mp.pi)
    # partial sums of r_j, and split contribution by chi-band
    run=mp.mpf(0); sup=mp.mpf(0)
    bands=[(0.0,0.05),(0.05,0.08),(0.08,0.11),(0.11,0.15)]
    bandsum={b:mp.mpf(0) for b in bands}
    milestones=[0.05,0.08,0.11,0.15]; runAt={}
    for n in range(n0,n1+1):
        chi=n/(j*j)
        r=dsig(j,n)-h(lam(n))/(2*j*j)
        run+=r
        if abs(run)>sup: sup=abs(run)
        for b in bands:
            if b[0]<=chi<b[1]: bandsum[b]+=r
        for ms in milestones:
            if chi>=ms and ms not in runAt: runAt[ms]=run
    log(f"\n#### j={j} (transition chi in [{n0/(j*j):.4f}, 0.15], {n1-n0+1} atoms, {time.time()-t0:.0f}s)")
    log(f"   total Sum r = {float(run):+.5f}, sup|partial| = {float(sup):.5f}")
    log(f"   running Sum r reaches: " + ", ".join(f"chi={ms}:{float(runAt.get(ms,run)):+.4f}" for ms in milestones))
    log(f"   per-band contribution to Sum r:")
    for b in bands:
        log(f"      chi in [{b[0]:.2f},{b[1]:.2f}): {float(bandsum[b]):+.5f}")
    # front-loaded fraction: |contribution from chi<0.08| / total-abs-ish
    front=abs(bandsum[(0.0,0.05)])+abs(bandsum[(0.05,0.08)])
    back=abs(bandsum[(0.08,0.11)])+abs(bandsum[(0.11,0.15)])
    log(f"   |front (chi<0.08)| = {float(front):.4f} vs |back (chi>0.08)| = {float(back):.4f}  "
        f"-> {'FRONT-LOADED (Airy-edge, merges item ii)' if front>1.5*back else 'spread (needs own vdC)'}")
log("\ndone.")
LOG.close()
