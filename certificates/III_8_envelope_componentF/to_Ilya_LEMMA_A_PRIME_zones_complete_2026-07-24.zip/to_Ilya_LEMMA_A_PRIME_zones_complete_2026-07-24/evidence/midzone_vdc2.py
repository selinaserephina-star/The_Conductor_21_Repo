# midzone_vdc2.py -- mid-Debye transition: SECOND van der Corput iteration -> strict O(1).
# First SBP: Sum a_n e^{i phi_n} = c_{n1}e^{i phi_{n1+1}} - c_{n0}e^{i phi_{n0}}
#            - Sum_{n0+1}^{n1} (c_n - c_{n-1}) e^{i phi_n},   c_n = a_n/(e^{i d phi_n}-1).
# The corrector Sum Dc_n e^{i phi_n} is ITSELF oscillatory -> apply SBP again with
#   c'_n = (c_n - c_{n-1})/(e^{i d phi_n}-1):
#   |corrector| <= |c'_{n1}| + |c'_{n0+1}| + Sum_{n0+2}^{n1} |c'_n - c'_{n-1}|.
# Since a/phi' = -j^2 CONSTANT, Dc_n is 2nd-order small, so the 2nd corrector Sum|Dc'| is
# FLAT in j -> the total bound is strict O(1) (no log).  Verify flatness; report the strict
# displayed constant for Sum h(lambda)/2j^2 over the transition. Not RH/GRH.
import time, math
import mpmath as mp
mp.mp.dps = 45
I = mp.mpc(0, 1)

def h(l): return -2*l*l*mp.cos(2*l)+mp.mpf(3)/2*l*mp.sin(2*l)+(mp.cos(2*l)-1)/2

def sbp2(a_of, n0, n1, lam):
    """two-level SBP.  Returns (bound1, bound2total, corr1abs, corr2abs, exactval)."""
    phi = {n: 2*lam(n) for n in range(n0, n1+2)}
    dphi = {n: phi[n+1]-phi[n] for n in range(n0, n1+1)}
    c = {n: a_of(n)/(mp.exp(I*dphi[n])-1) for n in range(n0, n1+1)}
    # first level
    bnd1 = abs(c[n1]) + abs(c[n0])
    corr1abs = sum(abs(c[n]-c[n-1]) for n in range(n0+1, n1+1))     # loose (|.|) 1st corrector
    # exact value (reconstruction)
    val = c[n1]*mp.exp(I*phi[n1+1]) - c[n0]*mp.exp(I*phi[n0])
    for n in range(n0+1, n1+1):
        val -= (c[n]-c[n-1])*mp.exp(I*phi[n])
    # second level: SBP the corrector Sum_{n0+1}^{n1} Dc_n e^{i phi_n}, Dc_n=c_n-c_{n-1}
    Dc = {n: c[n]-c[n-1] for n in range(n0+1, n1+1)}
    cp = {n: Dc[n]/(mp.exp(I*dphi[n])-1) for n in range(n0+1, n1+1)}
    bnd2 = abs(cp[n1]) + abs(cp[n0+1])
    corr2abs = sum(abs(cp[n]-cp[n-1]) for n in range(n0+2, n1+1))
    bnd2total = bnd1 + bnd2 + corr2abs           # strict two-level bound
    return bnd1, bnd2total, corr1abs, corr2abs, val

LOG=open(__file__.replace('.py','_run.log'),'w')
def log(s):
    print(s,flush=True);LOG.write(s+'\n');LOG.flush()
log(f"=== mid-Debye 2nd van der Corput iteration -> strict O(1) @ {time.strftime('%Y-%m-%d %H:%M:%S')} ===")
log("total bound on Sum h/2j^2 = (1/j^2)B[lam^2] + (3/4j^2)B[lam] + (1/4j^2)B[1] + (1/4j^2)Npts")
log(f"{'j':>5} {'direct':>10} {'1st bound':>10} {'2nd(strict)':>11} {'corr1/2j2':>10} {'corr2/2j2':>10}  flat?")
prev2=None
for j in (24, 48, 96, 192, 384):
    t0=time.time()
    caustic=0.6366*j; n0=int(caustic+4*(2*j)**(1.0/3))+1; n1=int(0.15*j*j)
    def lam(n): return 2*mp.mpf(j)*j/((n-mp.mpf(1)/2)*mp.pi)
    direct=sum(h(lam(n))/(2*j*j) for n in range(n0,n1+1))
    # components
    B=[]; C1=[]; C2=[]
    for a_of in (lambda n: lam(n)**2, lambda n: lam(n), lambda n: mp.mpf(1)):
        b1,b2,cr1,cr2,val = sbp2(a_of,n0,n1,lam); B.append((b1,b2)); C1.append(cr1); C2.append(cr2)
    Npts=n1-n0+1
    co=[1/mp.mpf(j*j), mp.mpf(3)/(4*j*j), 1/mp.mpf(4*j*j)]
    bound1=sum(co[k]*B[k][0] for k in range(3)) + (1/mp.mpf(4*j*j))*Npts
    bound2=sum(co[k]*B[k][1] for k in range(3)) + (1/mp.mpf(4*j*j))*Npts
    c1tot=sum(co[k]*C1[k] for k in range(3)); c2tot=sum(co[k]*C2[k] for k in range(3))
    flat = "" if prev2 is None else f"d={float(bound2-prev2):+.4f}"
    prev2=bound2
    log(f"{j:>5} {float(direct):+10.5f} {float(bound1):10.4f} {float(bound2):11.4f} "
        f"{float(c1tot):10.4f} {float(c2tot):10.5f}  {flat}  ({time.time()-t0:.0f}s)")
log("\nif the 2nd(strict) column FLATTENS (d -> 0) while 1st grows, the 2nd iteration removed")
log("the log => strict O(1) displayed constant for the mid-Debye transition. Not RH/GRH.")
LOG.close()
