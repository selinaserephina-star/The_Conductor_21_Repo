# farwing_sigma_W.py -- far-wing DEBT 1: the DISPLAYED remainder envelope W(x) and C_X.
# The signed first-order model sigma^(1) reproduces the exact per-atom remainder to O(j^-5)
# (farwing_sigma_signed.py). sigma^(1) is closed form (sin/cos of Phi_l, no Bessel), so
#   W_j(x) := j^3 [ Delta_j sigma^(1)(n) - h(2j^2/z)/2j^2 ],  x = n/j^2
# converges to a DISPLAYED envelope W(x); |r_j(n)| <= |W(x)|/j^3 + tail/j^4, and
#   Sum_{n: x>=X} |r_j(n)| <= (1/j) [ int_X^inf |W| dx + o(1) ]  = O(1/j),  C_X = int_X^inf|W|.
# We map W(x) at j=128, 256, 512 (convergence), and integrate |W| from several cutoffs X.
# Not RH/GRH.
import time, math
import mpmath as mp
mp.mp.dps = 40

def q_(l, z): return mp.mpf(l*(l+1))/(2*z)
def Phi(l, z): return z - l*mp.pi/2 + q_(l, z)
def zj1(l, z):
    ph = Phi(l, z); q = q_(l, z); L = mp.mpf(l*(l+1))
    return mp.sin(ph)*(1 + q*q/L) + mp.cos(ph)*(q**3/(3*L))
def zy1(l, z):
    ph = Phi(l, z); q = q_(l, z); L = mp.mpf(l*(l+1))
    return -mp.cos(ph)*(1 + q*q/L) + mp.sin(ph)*(q**3/(3*L))
def h(lam): return -2*lam*lam*mp.cos(2*lam)+mp.mpf(3)/2*lam*mp.sin(2*lam)+(mp.cos(2*lam)-1)/2

def sig1(j, n):
    z = (n-mp.mpf(1)/2)*mp.pi
    A = zj1(2*j+1, z); B = zj1(2*j-1, z); D = zj1(2*j-2, z); G = zy1(2*j-1, z)
    return (mp.mpf(2)/(4*j+1))*A*(2*(j-1)*B - z*(D + G))

def Wj(j, n):
    z = (n-mp.mpf(1)/2)*mp.pi
    lam = 2*j*j/z
    return float(j**3 * ((sig1(j+1, n)-sig1(j, n)) - h(lam)/(2*j*j)))

LOG = open(__file__.replace('.py', '_run.log'), 'w')
def log(s):
    print(s, flush=True); LOG.write(s+'\n'); LOG.flush()
log(f"=== far-wing debt 1: displayed envelope W(x) and C_X @ {time.strftime('%Y-%m-%d %H:%M:%S')} ===")

# --- W(x) convergence in j on a coarse grid ---
log("\n-- W_j(x) convergence (signed model, closed form) --")
XS = [round(0.14 + 0.04*k, 2) for k in range(0, 22)]   # 0.14 .. 0.98
log(f"{'x':>6} {'W(j=128)':>11} {'W(j=256)':>11} {'W(j=512)':>11}")
tab = {}
for x in XS:
    row = []
    for j in (128, 256, 512):
        n = int(round(x*j*j))
        row.append(Wj(j, n) if n >= 2 else float('nan'))
    tab[x] = row
    log(f"{x:6.2f} {row[0]:+11.3f} {row[1]:+11.3f} {row[2]:+11.3f}")

# --- integrate |W| (use j=512, fine grid) from several cutoffs X ---
log("\n-- C_X = int_X^inf |W(x)| dx  (j=512, step 0.005; far-zone cutoff X) --")
j = 512
xs_fine = [0.10 + 0.005*k for k in range(0, 300)]   # 0.10 .. 1.595
Wfine = []
t0 = time.time()
for x in xs_fine:
    n = int(round(x*j*j))
    Wfine.append((x, abs(Wj(j, n)) if n >= 2 else 0.0))
log(f"  (mapped {len(Wfine)} points, {time.time()-t0:.0f}s)")
def CX(X):
    s = 0.0
    for i in range(len(Wfine)-1):
        if Wfine[i][0] >= X:
            s += 0.5*(Wfine[i][1]+Wfine[i+1][1])*0.005
    return s
alpha = 0.2957
for X in (0.15, 0.20, alpha, 0.25, 0.30, 0.40):
    log(f"  X={X:.4f}:  C_X = int_X^inf |W| dx = {CX(X):8.3f}   "
        f"==>  Sum_{{n: x>=X}} |r_j| <= C_X/j + O(1/j^2),  displayed bound |r_j| <= |W(x)|/j^3 + tail")
# peak of |W|
xpk, Wpk = max(Wfine, key=lambda t: t[1])
log(f"\n  peak |W| = {Wpk:.2f} at x = {xpk:.3f};  W -> 0 as x grows (lobe dies): "
    f"|W(1.0)|={abs(Wj(j,int(round(1.0*j*j)))):.3f}, |W(1.5)|={abs(Wj(j,int(round(1.5*j*j)))):.3f}")
log("\ndone.  DEBT 1 displayed: |Delta_j sigma - h(lambda)/2j^2| <= |W(n/j^2)|/j^3 + O(j^-4),")
log("W closed-form (signed phase model), C_X = int_X|W| finite => Sum_n = O(1/j). Not RH/GRH.")
LOG.close()
