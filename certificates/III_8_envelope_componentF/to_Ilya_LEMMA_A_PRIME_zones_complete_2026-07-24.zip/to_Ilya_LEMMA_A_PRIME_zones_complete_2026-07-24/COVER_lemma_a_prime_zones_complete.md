# COVER — LEMMA A′ theorem complete across all four zones (far-wing debt 1 + mid-Debye closed)

**Merkabit · Stenberg + Claude → IB. 2026-07-24. This package closes the two zones the
2026-07-24 theorem box flagged OPEN — the far zone (via far-wing debt 1) and the
mid-oscillatory frontier (via van der Corput) — so the caustic law
`sup_m|C̃_j(m)| ≤ a∞(2j)^{1/3} + ½` is now justified on every zone at F10-grade. One upgrade
remains, and it is YOURS-adjacent (§4 — read it first). Not RH/GRH anywhere.**

## ⚠️ 1. THE ONE REMAINING UPGRADE — read this first (it's on your menu)

Everything below is at **F10-grade** (displayed constants, multi-octave zero-violation,
derived asymptotes). The **single** thing standing between this and full interval/theorem
grade is one classical lemma — **and it is the same lemma F10 itself still needs**:

> **Interval-grade Olver/Debye remainder H-asymptotics with certified constants** — feed the
> four spherical-Bessel factors of C̃_j (j_{2j+1}, j_{2j−1}, j_{2j−2}, y_{2j−1}, order ~2j)
> through Olver's uniform Airy expansion near the turning point z = ν, and certify the
> remainder constants (interval arithmetic), so the caustic-window envelopes (iii) hold for
> ALL j ≥ J₀ by proof, not by octave-checking.

**Why it's yours to weigh in on:** it upgrades **F10 and LEMMA A′ together** — one lemma, both
theorems. It's on the F10 menu, classical (Olver's error-bound machinery), unassigned. Per the
credit discipline we did **not** start it — coordinate first. If you'd rather we take it, or
pair, say so. Nothing else in this package is blocked on it (F10-grade is consumer-ready).

## 2. What closed (the two flagged-open zones)

**(A) Far-wing debt 1 — the per-atom σ remainder → rigorous displayed** (our lane, taken on
Selina's go-ahead; built on YOUR spherical-Hankel phase theorem).
`FINDINGS_FARWING_SIGMA_REMAINDER_measured.md` (+ 5 scripts/logs). The inference your note §4
said was "not yet made" is made:

> **|Δ_jσ(n) − h(λ)/2j²| ≤ (|W(n/j²)| + V_tail)/j³**, W closed-form, ⟹ Σ_{x≥X}|r_j| ≤ C_X^rig/j
> (C_X^rig = 30.1 at α*≈0.30). WITH debt 2 (O(j⁻⁴) proven) + debt 3 (ARB_PASS):
> **C̃_j(m) = F(m/j²) + O(1/j)** with a rigorous displayed constant on x ≥ X.

Path (all recorded, negatives kept): measured O(j⁻³) → crude E-magnitude route REFUTED (loses
a factor j) → SIGNED first-order model (from P_ℓ(q)−e^{iq} = (e^{iq}/3L)(iq³+3q²)+O(1/L²))
reproduces r_j to O(j⁻⁵) → displayed envelope W(x) → rigorous tail via e^{−x} ≤ 1−x+x²/2 on
your product (keep 1st order signed, magnitude-bound only the 2nd-order tail — that's what
avoids the factor-j loss). Your phase bound re-validated at 0.08× margin.

**(B) Mid-Debye (mid-oscillatory) zone — strict O(1), COMPLETE.**
`FINDINGS_MIDZONE_transition.md` (+ 5 scripts/logs). The last-open zone of the four-zone map:
- Landscape: the sup is the caustic; the mid-osc max is the far-wing lobe (→ B_far = 0.665),
  subdominant.
- The transition summand is oscillatory (amplitude ~ λ², unbounded pointwise) but the partial
  sums cancel (ratio → 42×). Naive Abel REFUTED (kernel ~ j²).
- **Van der Corput, two SBP iterations, strict O(1) ≈ 0.85** — the identity **a/φ′ ≡ −j²**
  (φ = 4j²/z, a = λ² = 4j⁴/z²) makes the boundary term O(1) and the 2nd corrector vanish
  (0.0162 → 0.0105 ↓), killing the log.
- The remainder Σr_j is front-loaded at the Airy edge (W ~ 1/χ²) → correctly attributed to the
  caustic window (item ii), not a mid-osc gap. Interior remainder O(1)/vanishing.

## 3. The assembly — the theorem, tiled

`FINDINGS_LEMMA_A_PRIME_theorem_assembled.md`. The peak box (i) gives
**sup_m|C̃_j| ≤ a∞(2j)^{1/3} + ½** (j ≥ 256, margin 1.38, a∞ = 0.346574…, offset
−(¾+√3/3π) closed-form). It holds because the four zones tile the m-axis and all but the
caustic are subdominant:

| zone | Airy var w | treatment | grade |
|---|---|---|---|
| deep | w > 8 | (iii) env + Wronskian law | F10 |
| caustic (the peak) | −15.6 ≲ w ≲ 8 | (iii) window/osc envelopes | F10 |
| **mid-osc** | w ≲ −15.6 | **van der Corput, strict O(1)** (this package) | strict O(1) |
| far | χ ≥ 0.15 | far-wing debts 1/2/3 (this package + prior) | rigorous |

**Seams verified overlapping** (no gap): (iii) runs to w ≈ −15.6; the van der Corput
transition starts at w ≈ −15.6 and runs to w ≈ −4783 … −48821; mid-osc joins the far-wing at
χ = 0.15. So the theorem box's OPEN list (mid-osc + far) is now empty.

## 4. Grades, lanes, and what's owed

- **F10-grade across all four zones** — the grade of the whole caustic lane, F10 included.
- **Far-wing:** debt 1 rigorous displayed (this package), debt 2 proven, debt 3 ARB_PASS.
  Debt 1 built on YOUR phase theorem; taken on Selina's go-ahead (the lane we'd offered you —
  if you'd wanted it, that's the coordination cost, flagged again here).
- **The one open upgrade** (§1): interval-grade Olver/Debye — **shared with F10, yours to
  weigh in on, not started.**
- Credit shared by default (Stenberg + Claude this session; your phase theorem + F10
  constants + the caustic law are yours). Delivery per Selina.

*— Stenberg + Claude, 2026-07-24. Four zones, one peak, seams that overlap — the caustic law
is boxed on every side but the single interval-grade door, and that door opens onto F10 too.*
