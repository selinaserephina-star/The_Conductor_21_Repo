#!/usr/bin/env python3
"""
Combine theorem-grade main interval bounds with the P23 tail constants.

Inputs:
  --main-bounds main_bounds.csv
  --p23-dck outputs/p23v2_dck_chi8.csv

Required columns in main_bounds.csv:
  interval_id,a,b,S0,S1,S2,inf_Q_main

P23 columns:
  M,dc0,dc1,dc2

Formula:
  B_sup = 2*S1*dc1 + dc1^2 + S0*dc2 + S2*dc0 + dc0*dc2
  margin = inf_Q_main - B_sup

Output:
  chi8_final_interval_certificate.csv
  chi8_final_interval_certificate_summary.json
"""

from pathlib import Path
import argparse, json
import pandas as pd

def read_tail_constants(path: str, M: int | None = None):
    df = pd.read_csv(path)
    if M is not None and "M" in df.columns:
        row = df[df["M"].astype(int) == int(M)]
        if row.empty:
            raise RuntimeError(f"M={M} not found in {path}")
        row = row.iloc[0]
    else:
        if "M" in df.columns:
            row = df.sort_values("M").iloc[-1]
        else:
            row = df.iloc[-1]
    return {
        "M": int(row["M"]) if "M" in row else None,
        "dc0": float(row["dc0"]),
        "dc1": float(row["dc1"]),
        "dc2": float(row["dc2"]),
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--main-bounds", required=True)
    ap.add_argument("--p23-dck", required=True)
    ap.add_argument("--M", type=int, default=None)
    ap.add_argument("--out-csv", default="chi8_final_interval_certificate.csv")
    ap.add_argument("--out-json", default="chi8_final_interval_certificate_summary.json")
    args = ap.parse_args()

    tail = read_tail_constants(args.p23_dck, args.M)
    df = pd.read_csv(args.main_bounds)

    required = ["interval_id", "a", "b", "S0", "S1", "S2", "inf_Q_main"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise RuntimeError(f"main_bounds missing required columns: {missing}")

    for c in ["S0", "S1", "S2", "inf_Q_main"]:
        df[c] = pd.to_numeric(df[c], errors="raise")

    dc0, dc1, dc2 = tail["dc0"], tail["dc1"], tail["dc2"]
    df["dc0"] = dc0
    df["dc1"] = dc1
    df["dc2"] = dc2

    df["B_sup"] = (
        2.0 * df["S1"].abs() * dc1
        + dc1**2
        + df["S0"].abs() * dc2
        + df["S2"].abs() * dc0
        + dc0 * dc2
    )
    df["margin"] = df["inf_Q_main"] - df["B_sup"]
    df["pass"] = df["margin"] > 0

    df.to_csv(args.out_csv, index=False)

    worst = df.sort_values("margin").iloc[0].to_dict()
    summary = {
        "tail_constants": tail,
        "intervals": int(len(df)),
        "all_pass": bool(df["pass"].all()),
        "min_margin": float(df["margin"].min()),
        "worst_interval": worst,
        "status": "PASS" if bool(df["pass"].all()) else "FAIL",
        "not_claimed": ["RH", "GRH"],
        "theorem_status": "closed_if_main_bounds_are_theorem_grade" if bool(df["pass"].all()) else "not_closed"
    }
    Path(args.out_json).write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
