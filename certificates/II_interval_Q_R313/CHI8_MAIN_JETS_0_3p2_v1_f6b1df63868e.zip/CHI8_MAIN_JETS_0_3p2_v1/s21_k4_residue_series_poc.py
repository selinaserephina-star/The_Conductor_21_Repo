"""S2.1 proof-of-concept (VALIDATED 2026-07-03): k4 via the Gamma(w)^4 residue series in Arb.

k4(u) = G^{4,0}_{0,4}(u|0,0,0,0) = sum over m>=0 of Res_{w=-m} Gamma(w)^4 u^{-w}.
Each pole is 4th order; with w = -m + e:
    Gamma(-m+e)^4 = Gamma(1+e)^4 / [ e^4 (m!)^4 prod_{j<=m}(1-e/j)^4 ],
    u^{-w} = u^m exp(-e log u),
so the residue is the e^3 Taylor coefficient of the (entire) numerator series — pure
ball arithmetic: log Gamma(1+e) = -gamma e + zeta(2)e^2/2 - zeta(3)e^3/3, harmonic sums,
series exp/mul to order 3. NO quadrature, NO Meijer-G library.

RESULT (ctx.prec=200, M=60 terms): matches mpmath meijerg (dps 30) to 15+ digits at
u in {1e-3, 0.1, 1, 5, 20, 60}; ball radii ~1e-55.

PRODUCTION TODO (S2.1 final): add the rigorous truncation tail for m >= M
(|P_m(log u)| u^m <= explicit bound via (m!)^{-4} growth — add as ball radius), and the
u-range policy (series everywhere A_n*v is needed vs positivity cap beyond).
"""
from flint import acb, arb, ctx
import mpmath as mp
ctx.prec = 200

def k4_series(u, M=60):
    L = arb(u).log()
    g = arb.const_euler()
    z2, z3 = arb(2).zeta(), arb(3).zeta()
    total = acb(0)

    def mulser(a, b):
        return [sum((a[i]*b[k-i] for i in range(k+1)), acb(0)) for k in range(4)]

    lg4 = [acb(0), acb(-4*g), acb(4*z2/2), acb(-4*z3/3)]
    E = [acb(1), lg4[1], lg4[2]+lg4[1]**2/2, lg4[3]+lg4[1]*lg4[2]+lg4[1]**3/6]
    ex = [acb(1), acb(-L), acb(L**2/2), acb(-L**3/6)]
    for m in range(M):
        h1 = sum((arb(1)/j for j in range(1, m+1)), arb(0))
        h2 = sum((arb(1)/(j*j) for j in range(1, m+1)), arb(0))
        h3 = sum((arb(1)/(j*j*j) for j in range(1, m+1)), arb(0))
        lp4 = [acb(0), acb(4*h1), acb(4*h2/2), acb(4*h3/3)]
        Ei = [acb(1), lp4[1], lp4[2]+lp4[1]**2/2, lp4[3]+lp4[1]*lp4[2]+lp4[1]**3/6]
        num = mulser(mulser(E, Ei), ex)
        total += num[3] * (arb(u)**m) / arb.fac_ui(m)**4
    return total

if __name__ == "__main__":
    mp.mp.dps = 30
    k4mp = lambda u: mp.meijerg([[], []], [[0, 0, 0, 0], []], u)
    for u in (0.001, 0.1, 1.0, 5.0, 20.0, 60.0):
        ball = k4_series(u)
        ref = float(k4mp(mp.mpf(u)))
        mid, rad = float(ball.real.mid()), float(ball.real.rad())
        print(f"u={u:>7}: mid={mid:.15e} rad={rad:.1e} mpmath={ref:.15e} "
              f"agree={abs(mid-ref) <= max(rad,1e-25)+1e-13*abs(ref)}")
