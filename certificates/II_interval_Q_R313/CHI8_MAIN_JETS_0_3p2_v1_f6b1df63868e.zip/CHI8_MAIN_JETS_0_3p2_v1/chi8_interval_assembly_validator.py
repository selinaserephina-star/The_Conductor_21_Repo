#!/usr/bin/env python3
"""
Validator for CHI8-INTERVAL-ASSEMBLY v1.

Usage:
  python chi8_interval_assembly_validator.py \
    --main-bounds main_bounds.csv \
    --p23-dck p23v2_dck_chi8.csv \
    --M 80000000

It checks:
  B_sup = 2*S1*dc1 + dc1^2 + S0*dc2 + S2*dc0 + dc0*dc2
  margin = inf_Q_main - B_sup
  pass = margin > 0

It also checks basic interval cover continuity.
"""

from pathlib import Path
import argparse, json
import pandas as pd

def read_tail(path: str, M=None):
    df = pd.read_csv(path)
    if M is not None and "M" in df.columns:
        row = df[df["M"].astype(int) == int(M)]
        if row.empty:
            raise RuntimeError(f"M={M} not found in {path}")
        row = row.iloc[0]
    else:
        row = df.sort_values("M").iloc[-1] if "M" in df.columns else df.iloc[-1]
    return {
        "M": int(row["M"]) if "M" in row else None,
        "dc0": float(row["dc0"]),
        "dc1": float(row["dc1"]),
        "dc2": float(row["dc2"]),
    }

def check_cover(df, start=0.0, end=3.2, tol=1e-12):
    d = df.sort_values(["a", "b"]).reset_index(drop=True)
    issues = []
    if abs(float(d.iloc[0]["a"]) - start) > tol:
        issues.append(f"cover starts at {d.iloc[0]['a']} not {start}")
    if abs(float(d.iloc[-1]["b"]) - end) > tol:
        issues.append(f"cover ends at {d.iloc[-1]['b']} not {end}")
    for i in range(len(d)-1):
        b = float(d.iloc[i]["b"])
        a_next = float(d.iloc[i+1]["a"])
        if a_next - b > tol:
            issues.append(f"gap between intervals {i} and {i+1}: {b} to {a_next}")
        if b - a_next > tol:
            issues.append(f"overlap between intervals {i} and {i+1}: {a_next} < {b}")
    return issues

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--main-bounds", required=True)
    ap.add_argument("--p23-dck", required=True)
    ap.add_argument("--M", type=int, default=80000000)
    ap.add_argument("--out-csv", default="chi8_interval_assembly_certificate.csv")
    ap.add_argument("--out-json", default="chi8_interval_assembly_summary.json")
    args = ap.parse_args()

    tail = read_tail(args.p23_dck, args.M)
    df = pd.read_csv(args.main_bounds)

    required = ["interval_id", "a", "b", "S0", "S1", "S2", "inf_Q_main"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise RuntimeError(f"missing columns in main_bounds: {missing}")

    for c in ["a", "b", "S0", "S1", "S2", "inf_Q_main"]:
        df[c] = pd.to_numeric(df[c], errors="raise")

    dc0, dc1, dc2 = tail["dc0"], tail["dc1"], tail["dc2"]
    df["dc0"] = dc0
    df["dc1"] = dc1
    df["dc2"] = dc2
    df["B_sup"] = (
        2 * df["S1"].abs() * dc1
        + dc1**2
        + df["S0"].abs() * dc2
        + df["S2"].abs() * dc0
        + dc0 * dc2
    )
    df["margin"] = df["inf_Q_main"] - df["B_sup"]
    df["pass"] = df["margin"] > 0

    cover_issues = check_cover(df)

    df.to_csv(args.out_csv, index=False)

    worst = df.sort_values("margin").iloc[0].to_dict()
    summary = {
        "tail": tail,
        "intervals": int(len(df)),
        "cover_ok": not cover_issues,
        "cover_issues": cover_issues,
        "all_pass": bool(df["pass"].all() and not cover_issues),
        "min_margin": float(df["margin"].min()),
        "worst_interval": worst,
        "status": "PASS" if bool(df["pass"].all() and not cover_issues) else "FAIL",
        "theorem_implication": "Q_chi8_positive_on_[0,3.2]" if bool(df["pass"].all() and not cover_issues) else "not_closed",
        "not_claimed": ["RH", "GRH", "global chi8 theorem"]
    }
    Path(args.out_json).write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(summary, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()
