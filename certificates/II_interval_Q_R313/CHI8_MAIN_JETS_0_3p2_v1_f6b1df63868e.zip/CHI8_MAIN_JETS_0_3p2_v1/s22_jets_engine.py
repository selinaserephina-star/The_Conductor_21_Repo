"""S2.2 — chi8 main-jets engine (ball arithmetic end to end, python-flint/Arb).

All closed form — NO numerical quadrature anywhere:
    Xi(t) = 32 Re sum_{n<=N} a_n F_s(A_n) + e_N(t),   s = 1/2 + it,  A_n = (2pi)^4 n / 21^5,
    F_s(A) = A^{-s} [ Gamma(s)^4 - H_s(A) ],          H_s(A) = int_0^A k4(u) u^{s-1} du,
    k4(u)  = sum_m u^m sum_{j<=3} q_{m,j} (log u)^j   [Gamma(w)^4 residue series, 4th-order
             poles at w = -m; q_{m,j} exact balls from the Gamma(1+e)^4 Laurent data],
    [eps^k] int_0^A u^{beta+eps-1} log^j u du = ((j+k)!/k!) s_{j+k},
    S(y) = A^{beta+y}/(beta+y) = A^beta * exp(yL) * 1/(beta+y)   (exact series product).

Jets: t = c + delta, s = s_c + i delta.  Xi(c+delta) = sum_{k<=K} xi_k delta^k + R,
    xi_k = 32 Re(i^k Phi_k),   Phi_k = [eps^k] sum_n a_n F_{s_c+eps}(A_n).
Taylor remainder R and the mode tail e_N are handled by the s23 U-table / block bounds.

m-series truncation is RIGOROUS: computed to M_ser(A) = ceil(3 A^{1/4}) + 25, then the
analytic tail bound (provable, generous constants)
    |q_{m,j}| <= B(m)/(m!)^4,  B(m) = 200 (1 + 4(ln(m+1)+1))^3,
    |[eps^k] int| <= ((j+k)!/k!) A^{m+1/2} e^{|log A|} / (m+1/2),
summed geometrically (ratio <= 2A/(m+1)^4 <= 1/2 past M_ser) and folded into a per-mode
tail budget returned to the caller (added to every jet coefficient's error).
"""
from flint import acb, arb, acb_poly, ctx
import math

def A1_ball():
    return (2*arb.pi())**4 / arb(21)**5

# ------------------------------------------------------------------ k4 residue table
class K4Table:
    def __init__(self, mmax=90):
        g = arb.const_euler()
        z2, z3 = arb(2).zeta(), arb(3).zeta()
        lg4 = [acb(0), acb(-4*g), acb(2*z2), acb(-4*z3/3)]
        E = [acb(1), lg4[1], lg4[2]+lg4[1]**2/2, lg4[3]+lg4[1]*lg4[2]+lg4[1]**3/6]
        self.mmax = mmax
        self.q = []
        h1 = arb(0); h2 = arb(0); h3 = arb(0)
        for m in range(mmax+1):
            if m > 0:
                h1 += arb(1)/m; h2 += arb(1)/(m*m); h3 += arb(1)/(m*m*m)
            lp4 = [acb(0), acb(4*h1), acb(2*h2), acb(4*h3/3)]
            Ei = [acb(1), lp4[1], lp4[2]+lp4[1]**2/2, lp4[3]+lp4[1]*lp4[2]+lp4[1]**3/6]
            gs = [sum((E[i]*Ei[k-i] for i in range(k+1)), acb(0)) for k in range(4)]
            f4 = arb.fac_ui(m)**4
            self.q.append([gs[3]/f4, -gs[2]/f4, gs[1]/(2*f4), -gs[0]/(6*f4)])

def Bmag(m):
    """provable bound on max_j (m!)^4 |q_{m,j}| (generous)."""
    return arb(200) * (1 + 4*(arb(m+1).log() + 1))**3

# ------------------------------------------------------------------ Gamma(s)^4 jets
def gamma4_series(sc, K):
    lg = [4*sc.lgamma(), 4*sc.digamma()]
    for p in range(1, K):
        psi_p = (-1)**(p+1) * arb.fac_ui(p) * acb(p+1).zeta(sc)   # Hurwitz zeta(p+1, sc)
        lg.append(4*psi_p/arb.fac_ui(p+1))
    e = [lg[0].exp()]
    for k in range(1, K+1):
        e.append(sum((j*lg[j]*e[k-j] for j in range(1, k+1)), acb(0))/k)
    return e

# ------------------------------------------------------------------ center context
class CenterContext:
    def __init__(self, c, K, k4tab):
        self.c, self.K, self.k4 = c, K, k4tab
        self.sc = acb(arb(1)/2, arb(c))
        self.g4 = gamma4_series(self.sc, K)
        self.LEN = K + 4
        self.invm = []
        for m in range(k4tab.mmax+1):
            ib = 1/(m + self.sc)
            coeffs, cur = [], ib
            for _ in range(self.LEN):
                coeffs.append(cur); cur = -cur*ib
            self.invm.append(acb_poly(coeffs))

    def F_jets(self, A):
        """(list of K+1 acb jet coeffs of F at s_c, arb tail-budget) for one mode."""
        K, LEN = self.K, self.LEN
        L = A.log()
        cl, cur = [], acb(1)
        for i in range(LEN):
            cl.append(cur); cur = cur*L/(i+1)
        expL = acb_poly(cl)
        Asc = (self.sc*L).exp()                    # A^{s_c}
        Am = Asc
        H = acb_poly([acb(0)])
        Mser = min(self.k4.mmax, int(3*float(A)**0.25) + 25)
        for m in range(Mser+1):
            S = (expL*self.invm[m]).truncate(LEN)*Am
            D = S
            term = D*self.k4.q[m][0]
            for j in (1, 2, 3):
                D = D.derivative()
                term += D*self.k4.q[m][j]
            H += term.truncate(K+1)
            Am = Am*A
        # rigorous m-tail (m > Mser): T(m) = B(m)/(m!)^4 * 4 (K+3)^3 A^{m+1/2} e^{|L|}/(m+1/2)
        m1 = Mser + 1
        eL = L.abs_upper().exp() if hasattr(L, 'abs_upper') else abs(L).exp()
        T1 = Bmag(m1)/arb.fac_ui(m1)**4 * 4*arb((K+3))**3 * A**arb(m1+0.5) * eL / (m1+0.5)
        ratio = 2*A/arb(m1+1)**4
        tailH = 2*T1 if ratio < arb(1)/2 else arb("1e1000")    # never triggers by construction
        # F = A^{-s_c} exp(-eps L) (g4 - H)
        g4mH = acb_poly([self.g4[i] - H[i] for i in range(K+1)])
        clm, cur = [acb(1)], acb(1)
        for i in range(1, K+1):
            cur = cur*(-L)/i
            clm.append(cur)
        F = (acb_poly(clm)*g4mH).truncate(K+1) * (1/Asc)
        # tail propagation through the prefactor: |A^{-s_c}| = A^{-1/2}; exp(-eps L) coeffs sum <= e^{|L|}
        tailF = tailH * eL / A.sqrt()
        return [F[i] for i in range(K+1)], tailF

# ------------------------------------------------------------------ Xi jets driver
def xi_jets(c, K, an, nlive, prec=256, k4tab=None, progress=0):
    ctx.prec = prec
    k4tab = k4tab or K4Table()
    cc = CenterContext(c, K, k4tab)
    A1 = A1_ball()
    Phi = [acb(0)]*(K+1)
    tail = arb(0)
    for n in range(1, nlive+1):
        a = an[n-1]
        if a == 0:
            continue
        f, tf = cc.F_jets(A1*n)
        if a == 1:
            for k in range(K+1): Phi[k] += f[k]
        else:
            for k in range(K+1): Phi[k] += a*f[k]
        tail += abs(a)*tf
        if progress and n % progress == 0:
            print(f"  c={c}: mode {n}/{nlive}", flush=True)
    xi, p, ik = [], acb(1), acb(0, 1)
    for k in range(K+1):
        xi.append(32*(p*Phi[k]).real)
        p = p*ik
    return xi, 32*tail        # xi_k balls + ONE arb tail bound valid for every coefficient

def load_an(path, nmax):
    out = []
    with open(path) as f:
        for i, line in enumerate(f):
            if i >= nmax: break
            out.append(int(line))
    return out
