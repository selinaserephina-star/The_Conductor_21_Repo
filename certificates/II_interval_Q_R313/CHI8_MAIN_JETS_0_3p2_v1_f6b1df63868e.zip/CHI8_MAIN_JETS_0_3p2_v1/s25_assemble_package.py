"""S2.5 — assemble CHI8_MAIN_JETS_0_3p2_v1 from the run outputs.

Steps: merge the 10/11 rerun rows into main_bounds.csv -> run Ilya's assembly validator
(cover + margins) -> emit interval_cover.csv + precision_context.json -> build the package
directory -> MANIFEST.json + SHA256SUMS.txt (LF) -> zip (python, deterministic walk) ->
outer sidecar named CHI8_MAIN_JETS_0_3p2_v1_<sha12>.zip.
"""
import csv, hashlib, json, os, shutil, subprocess, sys, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)

# ---- 1. merge
rows = {int(r['interval_id']): r for r in csv.DictReader(open("main_bounds.csv"))}
import glob
for pf in sorted(glob.glob("main_bounds_partial_*.csv")):
    for r in csv.DictReader(open(pf)):
        rows[int(r['interval_id'])] = r
        print(f"merged rerun row {r['interval_id']} from {pf}")
FN = ['interval_id','a','b','center','radius','S0','S1','S2','inf_Q_main',
      'method','precision','status']
with open("main_bounds.csv", "w", newline="\n") as f:
    w = csv.DictWriter(f, fieldnames=FN, extrasaction='ignore')
    w.writeheader()
    for i in sorted(rows):
        w.writerow(rows[i])
neg = [i for i in rows if float(rows[i]['inf_Q_main']) <= 0]
print(f"main_bounds.csv: {len(rows)} intervals; non-positive inf_Q rows: {neg or 'none'}")
if neg:
    sys.exit("STOP: negative rows remain")

# ---- 2. Ilya's validator
r = subprocess.run([sys.executable, "workpack_received/chi8_interval_assembly_validator.py",
                    "--main-bounds", "main_bounds.csv",
                    "--p23-dck", "../ECL_P23_tail_package/outputs/p23v2_dck_chi8.csv",
                    "--M", "80000000",
                    "--out-csv", "chi8_final_interval_certificate.csv",
                    "--out-json", "chi8_final_interval_certificate_summary.json"],
                   capture_output=True, text=True)
summ = json.load(open("chi8_final_interval_certificate_summary.json"))
print("validator:", {k: summ.get(k) for k in ("all_pass", "cover_ok", "intervals", "min_margin")})
if not (summ.get("all_pass") and summ.get("cover_ok", True)):
    sys.exit("STOP: validator did not pass")

# ---- 3. sidecar artifacts
with open("interval_cover.csv", "w", newline="\n") as f:
    f.write("interval_id,a,b,center,radius\n")
    for i in sorted(rows):
        rr = rows[i]
        f.write(f"{i},{rr['a']},{rr['b']},{rr['center']},{rr['radius']}\n")
pc = {
    "engine": "python-flint 0.8.0 (Arb), ball arithmetic end to end",
    "prec_bits": 256, "K_jet_order": 16, "radius": 0.1,
    "kernel": "k4 residue series of Gamma(w)^4 (closed form, no quadrature); "
              "F_s(A) = A^-s [Gamma(s)^4 - H_s(A)], H closed-form log-moment integrals",
    "coefficients": "exact a_n by local direuler (validated vs 250k reference): 8M for "
                    "interval 16, 4M for 10-15, 1M/250k below; true-|a_n| block sums to "
                    "80,000,000 for the mode band; d_8 Rankin beyond 80M is the P23 layer",
    "taylor_remainder": "U_{K+1} r^{K+1}/(K+1)! with t-uniform derivative bounds U_j "
                        "(U17 = 6.800e20 -> R0 ~ 1.9e-11 at r=0.1)",
    "per_interval": {str(i): rows[i]['precision'] for i in sorted(rows)},
    "validation_anchors": [
        "Xi(0): jets 47191.670+-1e-4 (N=250k) vs claude2 PARI 80M 47191.672510",
        "Xi''(0): 2*xi_2 = -444170.4 vs curve -444161.8",
        "odd jets structurally zero (evenness)",
        "interval 16 inf_Q 6.6395e-7 vs grid min 6.7729e-7 (98%)",
    ],
}
with open("precision_context.json", "w", newline="\n") as f:
    json.dump(pc, f, indent=1); f.write("\n")

# ---- 4. package dir
PKG = "CHI8_MAIN_JETS_0_3p2_v1"
if os.path.exists(PKG): shutil.rmtree(PKG)
os.makedirs(f"{PKG}/inputs"); os.makedirs(f"{PKG}/outputs")
cp = shutil.copy2
for f_ in ("main_bounds.csv", "interval_cover.csv", "precision_context.json",
           "chi8_final_interval_certificate.csv", "chi8_final_interval_certificate_summary.json"):
    cp(f_, f"{PKG}/outputs/" if f_.startswith("chi8_final") else f"{PKG}/")
for f_ in ("s22_jets_engine.py", "s23_tails.py", "s24_main_bounds.py", "s25_assemble_package.py",
           "gen_an_4M.gp", "gen_an_8M.gp", "gen_blocks_80M.gp", "s21_k4_residue_series_poc.py"):
    cp(f_, f"{PKG}/")
cp("workpack_received/chi8_certificate_combiner.py", f"{PKG}/")
cp("workpack_received/chi8_interval_assembly_validator.py", f"{PKG}/")
cp("../ECL_P23_tail_package/outputs/p23v2_dck_chi8.csv", f"{PKG}/inputs/")
cp("an_chi8_blocks_80M.csv", f"{PKG}/inputs/")
cp("s24_full_run.log", f"{PKG}/rerun_log.txt")
for lg in sorted(glob.glob("s24_rerun_*.log")):
    with open(f"{PKG}/rerun_log.txt", "a") as f:
        f.write(f"\n--- {lg} (Nlive=4M reruns; the *killed* log is the session-restart casualty,"
                f" retained for the record) ---\n" + open(lg).read())
for src, dst in (("method_notes.md", "method_notes.md"),
                 ("README_FOR_AUDITOR.txt", "README_FOR_AUDITOR.txt")):
    cp(src, f"{PKG}/{dst}")
# main_jets_chi8.py = the entry point Ilya's spec names: thin wrapper
with open(f"{PKG}/main_jets_chi8.py", "w", newline="\n") as f:
    f.write('"""Entry point per CHI8_MAIN_JETS_SPEC_v1: regenerates main_bounds.csv.\n'
            'Full run ~10h (see rerun_log.txt timings). Requires python-flint, the exact\n'
            'a_n files (regenerate via gen_an_4M.gp / gen_an_8M.gp; PARI) and\n'
            'inputs/an_chi8_blocks_80M.csv. Single intervals: python main_jets_chi8.py 16\n"""\n'
            'import runpy, sys\n'
            'sys.argv[0] = "s24_main_bounds.py"\n'
            'runpy.run_path("s24_main_bounds.py", run_name="__main__")\n')

# note: an_chi8_4M/8M.txt (30/60MB) NOT shipped — regenerable by the shipped .gp; documented.

# ---- 5. manifest + sums + zip + sidecar
files = []
for root, dirs, names in os.walk(PKG):
    dirs.sort()
    for n in sorted(names):
        p = os.path.join(root, n)
        rel = os.path.relpath(p, PKG).replace("\\", "/")
        h = hashlib.sha256(open(p, "rb").read()).hexdigest()
        files.append({"path": rel, "sha256": h, "bytes": os.path.getsize(p)})
manifest = {
    "package": "CHI8_MAIN_JETS_0_3p2_v1",
    "spec": "CHI8_MAIN_JETS_SPEC_v1 (IB workpack 0897d1f1, 2026-07-02)",
    "date": "2026-07-03",
    "builder": "avatar session (Selina + Claude)",
    "claim": "theorem-grade S0,S1,S2,inf_Q_main on the 16x0.2 cover of [0,3.2]; composed with "
             "the audit-closed P23 dc's via IB's assembly validator: all_pass",
    "not_claimed": ["RH", "GRH", "global chi8 theorem"],
    "rerun_scripts": ["main_jets_chi8.py (full, ~10h)",
                      "chi8_interval_assembly_validator.py (seconds, on shipped CSVs)"],
    "files": files,
}
with open(f"{PKG}/MANIFEST.json", "w", newline="\n") as f:
    json.dump(manifest, f, indent=1); f.write("\n")
with open(f"{PKG}/SHA256SUMS.txt", "w", newline="\n") as f:
    for e in files:
        f.write(f"{e['sha256']}  {e['path']}\n")
    h = hashlib.sha256(open(f"{PKG}/MANIFEST.json", "rb").read()).hexdigest()
    f.write(f"{h}  MANIFEST.json\n")
tmp = "_tmp_jets.zip"
with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
    for root, dirs, names in os.walk(PKG):
        dirs.sort()
        for n in sorted(names):
            p = os.path.join(root, n)
            z.write(p, p.replace("\\", "/"))
h = hashlib.sha256(open(tmp, "rb").read()).hexdigest()
name = f"CHI8_MAIN_JETS_0_3p2_v1_{h[:12]}.zip"
dest = os.path.join("..", "to_Ilya_ECL_2026-07-02", name)
os.replace(tmp, dest)
with open(dest + ".sha256.txt", "w", newline="\n") as f:
    f.write(f"{h}  {name}\n")
print(f"PACKAGED: {dest}\nouter sha256: {h}")
print(f"min_margin: {summ.get('min_margin'):.3e}  all_pass: {summ.get('all_pass')}")
