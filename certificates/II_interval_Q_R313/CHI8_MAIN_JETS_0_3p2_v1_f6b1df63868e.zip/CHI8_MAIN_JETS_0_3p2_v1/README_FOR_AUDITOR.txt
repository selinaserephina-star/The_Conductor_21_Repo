CHI8_MAIN_JETS_0_3p2_v1 — README FOR AUDITOR
=============================================
Builder: avatar session (Selina + Claude), 2026-07-03
Spec: CHI8_MAIN_JETS_SPEC_v1 (IB workpack sha 0897d1f1..., 2026-07-02)
Claim: theorem-grade main-term interval bounds S0, S1, S2, inf_Q_main on the
16 x 0.2 cover of [0, 3.2] for the completed chi8 function; composed with the
audit-closed P23 tail constants (dc0/dc1/dc2 at M = 80,000,000) they satisfy
inf_Q_main(I) - B_sup(I) > 0 on every interval of the cover.
NOT claimed: RH, GRH, anything outside [0, 3.2].

AUDIT ORDER (verify shipped bytes FIRST)
----------------------------------------
1. verify the outer .sha256 sidecar of the zip;
2. unzip; sha256sum -c SHA256SUMS.txt   (LF, UTF-8);
3. cheap rerun (seconds): the assembly validator on the shipped CSVs:
     python chi8_interval_assembly_validator.py \
       --main-bounds main_bounds.csv --p23-dck inputs/p23v2_dck_chi8.csv \
       --M 80000000 --out-csv outputs/chi8_final_interval_certificate.csv \
       --out-json outputs/chi8_final_interval_certificate_summary.json
   Expect: all_pass true, cover complete, min_margin as in the shipped summary.
   (Equivalently your combiner chi8_certificate_combiner.py, same arguments.)
4. compare numbers against the shipped outputs/ JSON + CSV;
5. full independent regeneration (OPTIONAL, ~10 h): python main_jets_chi8.py
   — requires python-flint (pip install python-flint) and the exact-coefficient
   files an_chi8_4M.txt / an_chi8_8M.txt, which are NOT shipped (30/60 MB) but
   regenerate deterministically by the shipped PARI scripts gen_an_4M.gp /
   gen_an_8M.gp (validated against the audited 250k reference file byte-wise on
   the overlap). Single intervals: python main_jets_chi8.py 16
   Timings per interval are in rerun_log.txt.

FILE MAP
--------
main_bounds.csv            the deliverable: 16 theorem-grade rows
interval_cover.csv         the cover (contiguous, [0.0, 3.2])
precision_context.json     engine, prec bits, K, per-interval N_live + error terms
method_notes.md            how S0/S1/S2/L_Q are obtained (spec section 5)
rerun_log.txt              full run log incl. the honest 10/11 first-pass failure
outputs/                   validator certificate CSV + summary JSON (all_pass)
inputs/p23v2_dck_chi8.csv  the audit-closed P23 tail table (unchanged bytes)
inputs/an_chi8_blocks_80M.csv  true-|a_n| block sums to 80M (mode-band bounds)
s22_jets_engine.py         modal jet engine (Arb balls, closed forms only)
s23_tails.py               I_k / U-table / band / Rankin machinery
s24_main_bounds.py         per-interval certification driver
s25_assemble_package.py    this package's builder (manifest/sums/zip)
s21_k4_residue_series_poc.py  kernel residue-series validation vs mpmath
gen_an_4M.gp, gen_an_8M.gp, gen_blocks_80M.gp   PARI coefficient generators
main_jets_chi8.py          spec-named entry point (wraps s24)
chi8_certificate_combiner.py, chi8_interval_assembly_validator.py   yours, unchanged
MANIFEST.json, SHA256SUMS.txt

DETERMINISM NOTE
----------------
The certified numbers are ball endpoints at 256-bit precision; the shipped CSVs
are what the shipped code produces on this machine. Cross-platform bit-identity
of a 10 h Arb run is not asserted; the AUDIT contract is (2)+(3)+(4) on shipped
bytes plus optional (5) reproducing the same certified inequalities (any
compliant rerun must yield inf_Q_main within the stated balls or tighter).
