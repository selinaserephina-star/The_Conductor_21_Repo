"""Entry point per CHI8_MAIN_JETS_SPEC_v1: regenerates main_bounds.csv.
Full run ~10h (see rerun_log.txt timings). Requires python-flint, the exact
a_n files (regenerate via gen_an_4M.gp / gen_an_8M.gp; PARI) and
inputs/an_chi8_blocks_80M.csv. Single intervals: python main_jets_chi8.py 16
"""
import runpy, sys
sys.argv[0] = "s24_main_bounds.py"
runpy.run_path("s24_main_bounds.py", run_name="__main__")
