"""S2.4 — theorem-grade main_bounds.csv for the chi8 interval certificate.

Per interval I = [a,b], center c, radius r:
  1. Jets: xi_k (k <= K) balls at c from s22 (N_live modes, exact a_n).
     C0-poly P0(d) = sum xi_k d^k;  P1 = P0' ; P2 = P0''   (exact poly ops on balls).
  2. Taylor remainders over |d| <= r (t-uniform U-table from s23):
     R0 = U_{K+1} r^{K+1}/(K+1)!,  R1 = U_{K+2} r^{K+1}/(K+1)!... NOTE: C1 = Xi', its
     degree-(K-1) Taylor from P1 has remainder U_{K+1} r^K / K!  (derivative shift),
     C2: U_{K+1} r^{K-1}/(K-1)!.  All explicit below.
  3. Mode band N_live -> 80M (true |a_n| blocks):  bk = 32 sum |a_n| I_k(A_n) — a
     t-uniform DERIVATIVE bound (k = 0,1,2).
  4. Output (what Ilya's combiner consumes; the >80M tail is HIS dc application):
     S_k(I)      = sup-bound of |P_k| on [-r,r]  +  R_k  +  b_k          (k = 0,1,2)
     inf_Q_main  = inf-bound of (P1^2 - P0 P2) on [-r,r]
                   - [2 S1 (R1+b1) + (R1+b1)^2 + S0 (R2+b2) + S2 (R0+b0) + (R0+b0)(R2+b2)]
     (TAIL-COMPOSITION applied to the jet-vs-true gap; then his combiner subtracts
      B_sup(dc_k(80M)) on top — the split is documented in method_notes.md.)

Polynomial sup/inf on [-r,r], rigorous: dense grid of G points + mean-value correction
with the exact coefficient bound  max|P'| <= sum k |p_k|_upper r^{k-1}.
"""
from flint import acb, arb, acb_poly, ctx
import sys, csv, time, json
from s22_jets_engine import xi_jets, load_an, K4Table
from s23_tails import load_blocks, band_bounds, rankin_dck, Ik_upper, U_table

def poly_from_jets(xi):
    return [x for x in xi]                       # arb coefficients (real jets)

def poly_derivative(p):
    return [p[k]*k for k in range(1, len(p))]

def poly_eval(p, x):
    v = arb(0)
    for c in reversed(p):
        v = v*x + c
    return v

def poly_bounds(p, r, G=400):
    """(sup|p|, inf p) on [-r, r], rigorous via grid + |p'| coefficient bound."""
    dp = poly_derivative(p)
    dmax = arb(0)
    rr = arb(1)
    for k, c in enumerate(dp):
        dmax += (abs(c).mid()+abs(c).rad())*rr
        rr = rr*r
    h = 2*r/G
    corr = dmax*h/2
    sup = arb('-1e999'); inf = arb('1e999')
    for i in range(G+1):
        x = -r + h*i
        v = poly_eval(p, arb(x))
        vu = v.mid()+v.rad(); vl = v.mid()-v.rad()
        if vu + float(corr.mid()+corr.rad()) > float(sup.mid()): sup = arb(vu) + corr
        if vl - float(corr.mid()+corr.rad()) < float(inf.mid()): inf = arb(vl) - corr
    return abs(sup).max(abs(inf)), inf          # sup|p| upper, inf p lower

def poly_abs_sup(p, r, G=400):
    s, _ = poly_bounds(p, r, G)
    return s

def poly_mul(p, q):
    out = [arb(0)]*(len(p)+len(q)-1)
    for i, a in enumerate(p):
        for j, b in enumerate(q):
            out[i+j] += a*b
    return out

def poly_sub(p, q):
    n = max(len(p), len(q))
    return [(p[i] if i < len(p) else arb(0)) - (q[i] if i < len(q) else arb(0)) for i in range(n)]

def upper(x):  return arb(x.mid()+x.rad())
def lower(x):  return arb(x.mid()-x.rad())

def certify_interval(iid, a, b, an, nlive, blocks, U, K, k4tab, prec=256, progress=0):
    ctx.prec = prec
    c = (a+b)/2; r = (b-a)/2
    t0 = time.time()
    xi, mtail = xi_jets(c, K, an, nlive, prec=prec, k4tab=k4tab, progress=progress)
    P0 = poly_from_jets(xi)
    # fold the (utterly negligible) k4 m-series budget into coefficient radii
    P0 = [p + arb(0, float(upper(mtail))) for p in P0]
    P1 = poly_derivative(P0)
    P2 = poly_derivative(P1)
    rr = arb(r)
    # Taylor remainders over the interval (derivative bounds U_j, t-uniform)
    R0 = U[K+1]*rr**(K+1)/arb.fac_ui(K+1)
    R1 = U[K+1]*rr**K/arb.fac_ui(K)
    R2 = U[K+1]*rr**(K-1)/arb.fac_ui(K-1)
    # mode band N_live -> end of blocks (t-uniform derivative bounds)
    b0, b1, b2 = band_bounds(blocks, nlive, blocks[-1][1], 2, k4tab)
    S0p = poly_abs_sup(P0, r);  S1p = poly_abs_sup(P1, r);  S2p = poly_abs_sup(P2, r)
    E0 = upper(R0+b0); E1 = upper(R1+b1); E2 = upper(R2+b2)
    S0 = upper(S0p + E0); S1 = upper(S1p + E1); S2 = upper(S2p + E2)
    Q = poly_sub(poly_mul(P1, P1), poly_mul(P0, P2))
    _, infQp = poly_bounds(Q, r, G=800)
    comp = 2*S1p*E1 + E1**2 + S0p*E2 + S2p*E0 + E0*E2
    infQ = lower(infQp - comp)
    dt = time.time()-t0
    return {
        'interval_id': iid, 'a': a, 'b': b, 'center': c, 'radius': r,
        'S0': float(S0), 'S1': float(S1), 'S2': float(S2),
        'inf_Q_main': float(infQ),
        'method': f'arb_modal_jets_K{K}_Nlive{nlive}_closedform_residue_series',
        'precision': f'prec{prec}_K{K}_r{r}_Nlive{nlive}_mtail{float(upper(mtail)):.1e}'
                     f'_R0{float(upper(R0)):.1e}_band0{float(upper(b0)):.1e}',
        'status': 'THEOREM_GRADE_PENDING_AUDIT',
        'seconds': round(dt, 1),
    }

NLIVE_PLAN = {  # per interval_id: live-mode horizon (bands from s23 numbers)
    1: 250_000, 2: 250_000, 3: 250_000, 4: 250_000, 5: 250_000, 6: 4_000_000,
    7: 1_000_000, 8: 1_000_000, 9: 1_000_000, 10: 4_000_000, 11: 4_000_000,
    12: 4_000_000, 13: 4_000_000, 14: 4_000_000, 15: 4_000_000, 16: 8_000_000,
}

if __name__ == '__main__':
    which = [int(x) for x in sys.argv[1:]] or list(range(1, 17))
    K = 16
    prec = 256
    ctx.prec = prec
    k4 = K4Table()
    nmax = max(NLIVE_PLAN[i] for i in which)
    src = "an_chi8_8M.txt" if nmax > 4_000_000 else "an_chi8_4M.txt"
    print(f"loading {src} to {nmax} ...", flush=True)
    an = load_an(src, nmax)
    blocks = load_blocks("an_chi8_blocks_80M.csv")
    print("U-table (j<=K+1) ...", flush=True)
    t0 = time.time()
    U, _, _, _ = U_table(an, blocks, min(len(an), 1_000_000), K+1, k4)
    print(f"  {time.time()-t0:.0f}s;  U0={float(U[0]):.3e}  U3={float(U[3]):.3e}  "
          f"U{K+1}={float(U[K+1]):.3e}", flush=True)
    rows = []
    for iid in which:
        a = round(0.2*(iid-1), 1); b = round(0.2*iid, 1)
        nl = min(NLIVE_PLAN[iid], len(an))
        print(f"[{iid}] [{a},{b}] Nlive={nl} ...", flush=True)
        row = certify_interval(iid, a, b, an, nl, blocks, U, K, k4, prec=prec,
                               progress=200_000)
        rows.append(row)
        print(f"  S0={row['S0']:.6e} S1={row['S1']:.6e} S2={row['S2']:.6e} "
              f"infQ={row['inf_Q_main']:.6e}  ({row['seconds']}s)", flush=True)
    out = f"main_bounds_partial_{'_'.join(str(i) for i in which)}.csv" \
          if len(which) < 16 else "main_bounds.csv"
    with open(out, "w", newline="\n") as f:
        w = csv.DictWriter(f, fieldnames=['interval_id','a','b','center','radius',
                                          'S0','S1','S2','inf_Q_main','method',
                                          'precision','status'], extrasaction='ignore')
        w.writeheader()
        for row in rows: w.writerow(row)
    print(f"written {out}")
