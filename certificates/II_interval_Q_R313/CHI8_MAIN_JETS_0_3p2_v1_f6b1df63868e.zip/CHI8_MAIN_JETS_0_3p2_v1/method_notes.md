# CHI8_MAIN_JETS_0_3p2_v1 — method notes

**Per CHI8_MAIN_JETS_SPEC_v1 §5: how S₀, S₁, S₂, L_Q are obtained, per interval.**
Everything below is ball arithmetic (python-flint 0.8.0 / Arb, 256-bit); every stated
bound is the upper (resp. lower) endpoint of a rigorous enclosure. No numerical
quadrature and no heuristic L-evaluation appear anywhere in the certified path.

## 1. The modal jet engine (fixed-center jets, D.3b-style)

Structure (P2.2-anchored, audit-closed conventions):

    Xi(t) = 32 Re Σ_{n≤N} a_n F_s(A_n) + e_N(t),   s = 1/2+it,  A_n = (2π)⁴ n / 21⁵,
    F_s(A) = A^{−s} [Γ(s)⁴ − H_s(A)],               H_s(A) = ∫₀^A k4(u) u^{s−1} du.

Closed forms used (all exact, ball-evaluated):

- **k4 residue series**: k4(u) = Σ_m u^m P_m(log u), P_m cubic, coefficients from the
  Laurent expansion of Γ(w)⁴ at its 4th-order poles w = −m (Euler γ, ζ(2), ζ(3),
  harmonic sums — all balls). Truncation at M_ser(A) = ⌈3A^{1/4}⌉+25 with a certified
  geometric tail (ratio ≤ 2A/(m+1)⁴ ≤ 1/2 past M_ser), folded into every coefficient.
- **H_s(A) jets**: ∫₀^A u^{β+ε−1} log^j u du has the exact ε-series
  [ε^k] = ((j+k)!/k!)·s_{j+k}, where S(y) = A^{β+y}/(β+y) = A^β·exp(yL)·(β+y)^{−1}
  is an exact series product (L = log A).
- **Γ(s)⁴ jets**: lgamma/digamma plus ψ^{(p)}(s) = (−1)^{p+1} p! ζ(p+1, s) (Hurwitz),
  exponentiated by the exact series recurrence.
- **Jets in t**: s = s_c + iδ ⇒ xi_k = 32 Re(i^k Φ_k). Odd coefficients vanish
  structurally at c where Xi is even (verified: exactly 0 at c = 0).

Per interval [a,b]: center c, radius r = 0.1, jet order K = 16.
C₀-polynomial P₀(δ) = Σ xi_k δ^k; P₁ = P₀′, P₂ = P₀″ (exact ball-poly derivatives).

## 2. The three error layers (all t-uniform derivative bounds)

Per-mode bound |d^k/dt^k mode_n| ≤ 32|a_n| I_k(A_n), with I_k(A) evaluated by the same
closed-form machinery (I_k = binomial combination of Γ-jet moments minus H-moments at
s = 1/2), monotone decreasing in A.

- **Taylor remainder** over |δ| ≤ r: R_k = U_{K+1} r^{K+1−k}/(K+1−k)! for C_k, with
  U_j ≥ sup_t |Xi^{(j)}(t)| assembled from: exact |a_n| for n ≤ 1M (chunked block
  bounds) + true-|a_n| 10⁵-block sums to 80M + d₈ Rankin beyond. U₁₇ = 6.800e20 ⇒
  R₀ ≈ 1.9e−11 at r = 0.1.
- **Mode band** N_live → 80M: b_k = 32 Σ_{N_live<n≤80M} |a_n| I_k(A_n), true-coefficient
  block sums (blocks bounded by I_k at the block start; I_k decreasing). N_live per
  interval: 250k (1–6), 1M (7–9), 4M (10–15), 8M (16) — chosen so b-terms are far below
  each interval's margin.
- **>80M tail**: NOT ours — that is exactly the audit-closed P23 δc layer, applied by
  the combiner/validator.

## 3. Interval outputs

- S_k(I) = [rigorous sup of |P_k| on [−r,r]] + R_k + b_k. Polynomial sup/inf via dense
  grid (400/800 pts) + the exact mean-value coefficient bound Σ k|p_k| r^{k−1}·h/2.
- L_Q = inf_Q_main(I) = [rigorous inf of P₁²−P₀P₂ on [−r,r]] − [2S₁'(R₁+b₁) + (R₁+b₁)²
  + S₀'(R₂+b₂) + S₂'(R₀+b₀) + (R₀+b₀)(R₂+b₂)] — the TAIL-COMPOSITION shape applied to
  the jet-vs-truncation gap (S' = poly-sup parts). The alias/remainder ledger of the
  spec is therefore: m-series tail (≤1e−45·budget, folded), Taylor remainder (≈1e−11),
  mode band (dominant, per-interval in precision_context.json), all before the P23 δc's.

## 4. Validation anchors (non-proof cross-checks, independent sources)

- Xi(0): jets give 47191.670 ± 1e−4 at N = 250k vs claude2's independent PARI(80M)
  47191.672510 — the 2.5e−3 difference is the true mode tail, inside our certified band.
- Xi″(0) = 2·xi₂ = −444170.4 vs the audited curve −444161.8.
- Interval 16 (the binding one): certified inf_Q ≥ 6.6395e−7 vs grid minimum 6.7729e−7
  — the enclosure captures 98% of the true margin at the hardest point.
- Intervals 12–15 lower bounds within 1–3% of the grid dip minima.

## 5. History note (photographed in rerun_log.txt)

The first pass ran intervals 10–11 at N_live = 1M; their mode-band term (b₀ ≈ 0.02
against S₂ ≈ 40/15) drove the certified inf_Q negative — the machinery correctly refused
to certify. Rerun at N_live = 4M (b₀ ≈ 9.4e−6) certifies both. The negative first-pass
rows are retained in the log as evidence the bounds bind.

Not claimed: RH, GRH, anything outside t ∈ [0,3.2].
