"""S2.3 — rigorous tail machinery for the chi8 main jets.

Provides, all as rigorous arb upper bounds:
  Ik_upper(A, kmax)   : I_k(A) = int_1^inf k4(Av) v^{-1/2} (log v)^k dv,  k = 0..kmax
                        (per-mode jet-magnitude weight: |[delta^k] mode_n| <= 32|a_n| I_k(A_n)/1)
  band_bounds(...)    : 32 * sum_{N1 < n <= N2} |a_n| I_k(A_n) from the block-sum CSV
                        (block bound: I_k decreasing in A => I_k(A_blockstart) * sum|a_n|)
  rankin_dck(M, kmax) : the >M tail with the d_8 Rankin bound (p23v2 math, any k)
  U_table(...)        : U_j >= sup_t |Xi^(j)(t)| (t-uniform), j = 0..jmax:
                        U_j = j! * 32 [ sum_{n<=N1} |a_n| Ik... ]  -- NOTE convention below.

CONVENTION: Ik_upper returns bounds for the LOG-POWER integrals; the k-th JET (Taylor
coefficient in delta) of a mode is bounded by 32|a_n| I_k(A_n) / k!, and the k-th
DERIVATIVE by 32|a_n| I_k(A_n).  U_j is a derivative bound (with j!).

Identity used (all closed form, no quadrature):
  I_k(A) = A^{-1/2} sum_i C(k,i) (-L)^{k-i} [ Mtil_i - Wtil_i(A) ],   L = log A,
  Mtil_i = int_0^inf k4 u^{-1/2} log^i u du = i! * [eps^i] Gamma(1/2+eps)^4,
  Wtil_i = int_0^A  k4 u^{-1/2} log^i u du = i! * [eps^i] H_{1/2+eps}(A)   (s22 machinery).
"""
from flint import acb, arb, acb_poly, ctx
from s22_jets_engine import K4Table, gamma4_series, A1_ball, Bmag
import math, csv

def _H_series_real(A, kmax, k4tab):
    """[eps^i] H_{1/2+eps}(A) for i=0..kmax (acb balls, sc=1/2), plus rigorous m-tail arb."""
    sc = acb(arb(1)/2)
    LEN = kmax + 5
    L = A.log()
    cl, cur = [], acb(1)
    for i in range(LEN):
        cl.append(cur); cur = cur*L/(i+1)
    expL = acb_poly(cl)
    Asc = (sc*L).exp()
    Am = Asc
    H = acb_poly([acb(0)])
    Mser = min(k4tab.mmax, int(3*float(A)**0.25) + 25)
    for m in range(Mser+1):
        ib = 1/(m + sc)
        coeffs, curv = [], ib
        for _ in range(LEN):
            coeffs.append(curv); curv = -curv*ib
        S = (expL*acb_poly(coeffs)).truncate(LEN)*Am
        D = S
        term = D*k4tab.q[m][0]
        for j in (1, 2, 3):
            D = D.derivative()
            term += D*k4tab.q[m][j]
        H += term.truncate(kmax+1)
        Am = Am*A
    m1 = Mser + 1
    eL = abs(L).exp()
    T1 = Bmag(m1)/arb.fac_ui(m1)**4 * 4*arb(kmax+3)**3 * A**arb(m1+0.5) * eL / (m1+0.5)
    ratio = 2*A/arb(m1+1)**4
    assert ratio < arb(1)/2
    return [H[i] for i in range(kmax+1)], 2*T1

_M_CACHE = {}
def Ik_upper(A, kmax, k4tab, prec=None):
    """rigorous arb upper bounds of I_k(A), k=0..kmax. A: arb > 0."""
    key = ('M', kmax, ctx.prec)
    if key not in _M_CACHE:
        g4 = gamma4_series(acb(arb(1)/2), kmax)
        _M_CACHE[key] = [arb.fac_ui(i)*g4[i].real for i in range(kmax+1)]
    M = _M_CACHE[key]
    Hs, tail = _H_series_real(A, kmax, k4tab)
    W = [arb.fac_ui(i)*Hs[i].real for i in range(kmax+1)]
    L = A.log()
    out = []
    for k in range(kmax+1):
        s = arb(0)
        for i in range(k+1):
            s += arb.bin_uiui(k, i) * (-L)**(k-i) * (M[i] - W[i])
        val = s / A.sqrt() + tail*(1+abs(L))**k / A.sqrt()   # fold m-tail generously
        # I_k >= 0; take the upper bound of the ball
        up = val.mid() + val.rad()
        out.append(arb(up).max(arb(0)))
    return out

def load_blocks(path):
    rows = []
    with open(path) as f:
        r = csv.DictReader(f)
        for row in r:
            rows.append((int(row['block_start']), int(row['block_end']),
                         int(row['sum_abs_an']), int(row['max_abs_an'])))
    return rows

def band_bounds(blocks, n_lo, n_hi, kmax, k4tab):
    """rigorous upper bounds b_k >= 32 sum_{n_lo < n <= n_hi} |a_n| I_k(A_n)   (JET/derivative
    per convention of the caller: these are the I_k-weighted sums; caller divides by k!
    for Taylor-coefficient use).  Uses I_k monotone decreasing in A."""
    A1 = A1_ball()
    tot = [arb(0)]*(kmax+1)
    for (b1, b2, s, mx) in blocks:
        if b2 <= n_lo or b1 > n_hi:
            continue
        lo = max(b1, n_lo+1)
        Astart = A1*lo
        Iks = Ik_upper(Astart, kmax, k4tab)
        for k in range(kmax+1):
            tot[k] += s*Iks[k]
    return [32*t for t in tot]

def rankin_dck(M, kmax, k4tab, sigmas=None):
    """d_8 Rankin tail past M (p23v2 math, arb-rigorous, any k):
       dc_k(M) = 32 min_sigma zeta_upper(sigma)^8 (M+1)^sigma I_k(A_{M+1})."""
    sigmas = sigmas or [1.05 + 0.05*i for i in range(100)]
    A1 = A1_ball()
    Iks = Ik_upper(A1*(M+1), kmax, k4tab)
    NZ = 2000
    zup = {}
    out = []
    for sg in sigmas:
        s = arb(0)
        for n in range(NZ, 0, -1):
            s += arb(n)**arb(-sg)
        zup[sg] = (s + arb(NZ)**arb(1-sg)/(sg-1))**8
    for k in range(kmax+1):
        best = None
        for sg in sigmas:
            v = zup[sg] * arb(M+1)**arb(sg) * Iks[k]
            u = v.mid() + v.rad()
            if best is None or u < best:
                best = u
        out.append(32*arb(best))
    return out

def U_table(an, blocks, n_exact, jmax, k4tab, chunk=200):
    """t-uniform derivative bounds U_j >= sup_t |Xi^(j)(t)|, j=0..jmax:
       U_j = 32 [ sum_{n<=n_exact} |a_n| I_j(A_n)  (chunked block bound on exact coeffs)
                 + band(n_exact..80M blocks) + rankin(80M) ].
       Chunking: I_j decreasing => bound chunk sums by I_j at chunk start."""
    A1 = A1_ball()
    tot = [arb(0)]*(jmax+1)
    n = 1
    while n <= n_exact:
        hi = min(n+chunk-1, n_exact)
        s = sum(abs(an[i-1]) for i in range(n, hi+1))
        if s:
            Iks = Ik_upper(A1*n, jmax, k4tab)
            for j in range(jmax+1):
                tot[j] += s*Iks[j]
        n = hi+1
    live = [32*t for t in tot]
    band = band_bounds(blocks, n_exact, blocks[-1][1], jmax, k4tab)
    rank = rankin_dck(blocks[-1][1], jmax, k4tab)
    return [(live[j] + band[j] + rank[j]) * arb.fac_ui(1) for j in range(jmax+1)], live, band, rank
