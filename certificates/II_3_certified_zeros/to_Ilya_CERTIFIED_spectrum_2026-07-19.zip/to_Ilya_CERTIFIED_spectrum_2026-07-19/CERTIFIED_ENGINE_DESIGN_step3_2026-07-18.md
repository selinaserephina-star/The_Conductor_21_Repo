# Certified engine — step 3 design note (ball S-sums + ball evaluation)

**Merkabit · 2026-07-18 · Selina + Claude.** Rigor-ladder steps 3+5+6-core implemented
(`certified_engine.py`); step 4 (analytic tails) is the next rung and is DECLARED, not
hidden. Not RH/GRH.

## What is now certified (modulo declared tails)

F(t) enclosures from: exact-integer a_n → float64 bucket sums with **rigorous error
radii** → certified G^(k) balls (step 1) → ball assembly → **direct Poisson evaluation**
(no FFT needed for certification: (2π/B)[F̂₀ + 2Σ Re F̂_l e^{ilht}] = Σ_j F(t+jB)
*exactly*, so the ball sum encloses F(t) up to alias terms F(t±B)…, which are step-4
remainder, ~e^{−2π(1+η)(B−t)} at B = 64 — ≥ 40 orders below signal for t ≤ 30).

## The two error-analysis keys

1. **Buckets are contiguous n-slices** (u = log(n/√N) is monotone), so each S_m^(k) is a
   slice-sum → numpy **pairwise summation** with the proven bound (128 + log₂p)·u_mach·Σ|t|,
   instead of `bincount`'s sequential accumulation whose worst-case bound (p·u_mach·Σ|t|,
   p ~ 10⁹ at production) would be fatal. This single algorithmic observation is what makes
   certified radii ~10⁻¹⁴·A_m instead of ~10⁻⁷·A_m.
2. **Per-term ulp budget**: Δterm ≤ |c|[(k+5)u_mach(h/2)^k + k(h/2)^{k−1}·Dd], with
   Dd = 1.6e-14 the absolute error of d (log rounding + exact-h correction: the G-table
   lives on the EXACT grid u = lπ/32, so d must be reckoned against exact h = 2π/64).

## Operating-point analysis for the production run (the η trade, revised)

The certified radius of F scales like  rad(F) ≈ (2π/B)·Σ_l rad(F̂_l), with
rad(F̂) ~ N^{1/4}·Σ_m |G|·Rad_m and Rad_m ∝ A_m ~ Σ_bucket|a_n|/√n ~ e^{u_m/2}·const.
The G-decay kills the large-A buckets for x ≥ 0, leaving a proven noise floor that the
shakedown measures directly. Against it, the signal at the Turing endpoint is
|F(t₂)| ~ F(0)·e^{−2π(1−η)t₂}. Consequences (analytic estimate, to be confirmed by the
measured shakedown profile):

- **η = 0.82, t₂ = 30** (float64-optimal): signal ~10⁻¹¹ abs vs proven noise ~10⁻⁵±1 —
  NOT certifiable with double-precision S-sums. (The float64 pipeline works there because
  its *empirical* noise is √-cancelling; proofs pay worst case.)
- **η ≈ 0.90, t₂ = 30, M ≈ 2.2×10¹⁰**: signal ~10⁻⁴·F(0) — certifiable with margin if the
  measured noise floor lands where the estimate puts it (~10⁻⁵ abs). Coefficients int16
  (max|a_n| asserted), ~45 GB + sieve transient — fits the 128 GB box.
- **Fallback A**: η = 0.92, M ≈ 3.4×10¹⁰ (68 GB, tight but feasible) — 20× more signal.
- **Fallback B**: double-double per-term evaluation in the S-stage (~10× stage cost,
  ~+2 h) drops the noise floor ~30×, buying η = 0.90 comfortable margin or η = 0.86.

**Decision rule**: run the shakedown, read the measured rad(F) profile, extrapolate
A_m-growth to production M, pick the cheapest (η, M, precision) with S/N ≥ 50 at t₂.

## Step-4 checklist (the declared remainder — next session)

1. Coefficient truncation n > M: |a_n| ≤ d₈(n) (unitary Frobenius) + certified G-envelope
   from the step-1 residue-bound machinery (Σ_j MA_j + geometric tail as a rigorous
   |G(u)| upper bound at any u).
2. Bucket-Taylor K-remainder: needs G^(14) balls (extend K_DER 14→15, 2 s rebuild) +
   Booker (5.16)-style sup bound on the interval.
3. Aliasing: F̂-side via the G-envelope at x + 2πAk; F-side via a Lemma-4.1-type convexity
   bound on |Λ| at heights t+jB (the one genuinely new derivation in step 4).
4. Certified B-constant: the PZ c₀(ε) integrals via arb integration or elementary
   monotone bounds (mpmath quad is not rigorous).

## Shakedown protocol (M = 10⁸, η = 3/10, B = 64)

L(½) ball vs reference; rad(F) profile on t ∈ [0.5, 5.5]; certified sign changes at the
ball-certified γ₁…γ₁₀ master brackets — the first zeros of χ₈ certified through the
*counting engine* rather than the jets engine, closing the loop between the two
instruments. Output: `certified_shakedown.log`.

— Selina + Claude, 2026-07-18
