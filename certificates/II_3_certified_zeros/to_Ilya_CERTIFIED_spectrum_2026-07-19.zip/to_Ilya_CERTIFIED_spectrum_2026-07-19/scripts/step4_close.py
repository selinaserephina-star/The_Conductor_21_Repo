# step4_close.py — the two closing bounds of rigor-ladder step 4.
#
# (A) F-SIDE ALIAS BOUND: certified |Lambda(1/2 + iT)| upper bound, hence |F(t + jB)|.
#   Gaussian-localized Cauchy: for delta > 0, g(s) = Lambda(s) e^{delta (s - 1/2 - iT)^2}
#   is entire; on Re s = 2 and Re s = -1 (mirror by Lambda(s) = Lambda(1-s)) the modulus
#   of Lambda is EXACT-elementary: with y = t/2,
#     |Lambda(2+it)| = N |prod_j Gamma_R(2 + mu_j + it)| |L(2+it)|,
#     |L(2+it)| <= zeta(2)^8,   Gamma_R(2+it) = pi^{-(1+iy)} Gamma(1+iy),
#     Gamma_R(3+it) = pi^{-(3/2+iy)} Gamma(3/2+iy),
#     |Gamma(1+iy)|^2 = pi y / sinh(pi y)         (exact),
#     |Gamma(3/2+iy)|^2 = (1/4 + y^2) pi / cosh(pi y)   (exact).
#   Cauchy on the rectangle (arcs vanish: order-1 + PL boundedness in the strip, Gaussian
#   kills the horizontals):
#     |Lambda(1/2+iT)| <= (1/2pi) e^{delta/4?}  -- precisely:
#     |g(1/2+iT)| = |Lambda(1/2+iT)|, and
#     |Lambda(1/2+iT)| <= (1/2pi) [ int_R |Lambda(2+it)| e^{delta(9/4 - (t-T)^2)} / |3/2 + i(t-T)| dt
#                                  + int_R |Lambda(2-it)| e^{delta(9/4 - (t-T)^2)} / |3/2 + i(t-T)| dt ]
#   (second line: Re = -1 edge mapped by the functional equation).  All integrands are
#   elementary-exact and arb-integrable; T-decay e^{-2pi T} enters through the edge moduli
#   localized at t ~ T by the Gaussian.
#   Then |F(t + jB)| = |Lambda(1/2+i(t+jB))| e^{2 pi eta (t+jB)}  for j >= 1, and for
#   j <= -1 use evenness |Lambda(1/2+it')| = |Lambda(1/2-it')|.
#
# (B) CERTIFIED PZ B-CONSTANT: upstream_turing_constant_chi8.py recomputed with rigorous
#   arb integration + elementary tail bounds (log zeta(s) <= -log(1 - 2^{1-s} ...) route:
#   0 <= log zeta(s) <= zeta(s) - 1 <= 2^{1-s} (1 + 2 (2/3)^{s} ...) — we use the clean
#   chain log zeta(s) <= zeta(s) - 1 and zeta(s) - 1 <= 2^{-s} + 3^{-s} + int_3^oo x^{-s} dx,
#   all monotone-explicit), yielding B as a ball; the Turing inequality uses its UPPER end.
import numpy as np
from flint import arb, acb, ctx


# ---------- (A) alias bound ----------
def lambda_edge_abs(t, prec=300):
    """EXACT |Lambda(2+it)| bound (arb): N * prod |Gamma_R| * zeta(2)^8, t arb/float."""
    ctx.prec = prec
    pi = arb.pi()
    t = t if isinstance(t, arb) else arb(t)
    y = t / 2
    N = arb(21) ** 10
    # |Gamma(1+iy)|^2 = pi y / sinh(pi y)  (y=0 limit 1); |Gamma(3/2+iy)|^2 = (1/4+y^2) pi/cosh(pi y)
    py = pi * y
    g1sq = py / py.sinh() if y != 0 else arb(1)
    g32sq = (arb(1) / 4 + y * y) * pi / py.cosh()
    # 4 factors Gamma_R(2+it) = pi^{-(1+iy)}Gamma(1+iy): modulus pi^{-1}|Gamma(1+iy)|
    # 4 factors Gamma_R(3+it) = pi^{-(3/2+iy)}Gamma(3/2+iy): modulus pi^{-3/2}|Gamma(3/2+iy)|
    gam = (pi ** -1) ** 4 * (pi ** -arb(1.5)) ** 4 * g1sq ** 2 * g32sq ** 2
    z2_8 = arb(2).zeta() ** 8
    return N * gam * z2_8


def lambda_half_bound(T, delta=4.0, prec=600):
    """Certified upper bound for |Lambda(1/2 + iT)| via Gaussian-localized Cauchy.
    T may be an arb INTERVAL ball — then the bound covers every T in the interval
    rigorously (used to bound aliases over whole t-ranges in one call)."""
    ctx.prec = prec
    pi = arb.pi()
    T = T if isinstance(T, arb) else arb(T)
    d = arb(delta)
    def f(t, _):
        # integrand on the Re=2 edge (the Re=-1 edge gives the same value by symmetry of
        # |Lambda(2+it)| in t and the functional equation): use 2x one edge.
        tt = t.real
        num = lambda_edge_abs(tt, prec) * (d * (arb(9) / 4 - (tt - T) ** 2)).exp()
        den = (arb(9) / 4 + (tt - T) ** 2).sqrt()
        return acb(num / den)
    # localize: |t - T| <= W where Gaussian kills; W = sqrt((9/4*d + 2piT + 60)/d) generous
    W = ((arb(9) / 4 * d + 2 * pi * T + 60) / d).sqrt() + 2
    lo, hi = float((T - W).mid()), float((T + W).mid())
    pts = np.linspace(lo, hi, max(5, int((hi - lo) / 4) * 2 + 1))
    main = acb(0)
    for i in range(len(pts) - 1):
        seg = acb.integral(f, float(pts[i]), float(pts[i + 1]))
        if not seg.is_finite():
            raise RuntimeError("lambda_half_bound segment failed")
        main += seg
    # outside |t-T| > W: integrand <= max|Lambda-edge|(=value at t=0) * e^{d(9/4 - W^2)} / (3/2),
    # integrated against the Gaussian tail: <= edge(0) * e^{9d/4} * e^{-dW^2}/(dW) * (2/3)
    tail = lambda_edge_abs(arb(0), prec) * (arb(9) / 4 * d).exp() \
        * (-d * W * W).exp() / (d * W) * arb(2) / 3
    return (abs(main) + 2 * tail) * 2 / (2 * pi)      # x2: both edges


def alias_bound(t, B, eta_num, eta_den, jmax=6, prec=300):
    """Certified bound for sum_{j != 0} |F(t + jB)|, F = Lambda(1/2+i.)e^{2 pi eta .}."""
    ctx.prec = prec
    pi = arb.pi()
    eta = arb(eta_num) / eta_den
    tot = arb(0)
    for j in range(1, jmax + 1):
        Tp = arb(t) + j * B                       # right alias
        tot += lambda_half_bound(Tp, prec=prec) * (2 * pi * eta * Tp).exp()
        Tm = j * B - arb(t)                       # left alias (|t - jB|, evenness)
        tot += lambda_half_bound(Tm, prec=prec) * (2 * pi * eta * (arb(t) - j * B)).exp()
    # j beyond jmax: each right-alias term shrinks by e^{-2pi(1-eta)B} < 1e-20; dominate
    q = (-2 * pi * (1 - eta) * B).exp()
    tot += tot * q / (1 - q)
    return tot



def lambda_half_bound_closed(T, delta=4.0, prec=600):
    """CLOSED-FORM certified |Lambda(1/2+iT)| bound (no numeric integration -- v2, fixes
    the ~e^20 acb_calc looseness at magnitudes ~1e-230 that broke the B=96 alias budget).
    Edge Re s = 2, exact moduli, for y = t/2 >= 1/2:
      R(t) = N zeta(2)^8 pi^{-10} |G1|^4 |G32|^4,  |G1(y)|^4 <= (2.1 pi y)^2 e^{-2pi y},
      |G32(y)|^4 <= (2 pi (1/4+y^2))^2 e^{-2pi y}   (sinh/cosh >= e^x * 0.478 for y>=1/2)
      => R(t) <= C_R * (t/2)^2 (1/4 + t^2/4)^2 e^{-2 pi t},  C_R = N zeta(2)^8 pi^{-10} (2.1 pi)^2 (2 pi)^2.
    Gaussian-Cauchy main term (both edges, denominator >= 3/2):
      |Lambda(1/2+iT)| <= (2/(2 pi)) (1/(3/2)) e^{9 delta/4} [ I_main + I_left ],
      I_main = int_1^oo P6(t) e^{-2 pi t - delta (t-T)^2} dt,  P6(t) = C_R (t/2)^2 ((1+t^2)/4)^2
             <= C_R/64 * t^2 (1+t^2)^2  and complete the square: -2pi t - delta(t-T)^2
             = -2 pi T + pi^2/delta - delta (t - c)^2,  c = T - pi/delta;
      with t^2(1+t^2)^2 <= 32 (c^6 + x^6 + ...) crude split (x = t-c):
      int P6 e^{-delta x^2} dx <= C_R/64 * 32 [ (c^2+1)... ] -- we use the clean rigorous form
      t^2 (1+t^2)^2 <= 4 t^6 for t >= 1, and t^6 <= 32 (c^6 + x^6):
      I_main <= (C_R/16) e^{-2 pi T + pi^2/delta} * 32 [ c^6 sqrt(pi/delta)
                + (15/8) sqrt(pi) delta^{-7/2} ].
      I_left (t < 1 strip + left tail): R <= R_edge_max := lambda_edge_abs(0) and Gaussian
      e^{-delta (t-T)^2} <= e^{-delta (T-1)^2} there:
      I_left <= R_edge_max e^{-delta (T-1)^2} * (1 + 1/(2 delta (T-1))).
    All arb; upper ball returned."""
    ctx.prec = prec
    pi = arb.pi()
    T = T if isinstance(T, arb) else arb(T)
    d = arb(delta)
    z2 = arb(2).zeta()
    C_R = (arb(21) ** 10) * z2 ** 8 * pi ** -10 * (arb(21) / 10 * pi) ** 2 * (2 * pi) ** 2
    c = T - pi / d
    main = (C_R / 16) * (-2 * pi * T + pi ** 2 / d).exp() * 32         * (c ** 6 * (pi / d).sqrt() + (arb(15) / 8) * pi.sqrt() * d ** (-arb(7) / 2))
    Redge0 = lambda_edge_abs(arb(0), prec)
    left = Redge0 * (-d * (T - 1) ** 2).exp() * (1 + 1 / (2 * d * (T - 1)))
    return (2 / (2 * pi)) * (2 / arb(3)) * (arb(9) / 4 * d).exp() * (main + left)


# ---------- (B) certified B-constant ----------
def log_zeta_tail(A):
    """Rigorous 0 <= int_A^oo log zeta(s) ds <= 2^{-A}/log 2 + 3^{-A}/log 3 + 3^{1-A}/(A-1)^2-ish.
    Using log zeta(s) <= zeta(s)-1 <= 2^{-s} + 3^{-s} + 3^{1-s}/(s-1) (integral comparison)."""
    A = A if isinstance(A, arb) else arb(A)
    l2, l3 = arb(2).log(), arb(3).log()
    t1 = arb(2) ** -A / l2
    t2 = arb(3) ** -A / l3
    t3 = 3 * arb(3) ** -A / (l3 * (A - 1))        # crude but rigorous for A >= 2
    return t1 + t2 + t3


def certified_B(t1, t2, eps_num=1, eps_den=2, prec=200):
    """PZ Thm 2.3 B(t1, t2) as an arb ball (upper end is the safe value).
    Mirrors upstream_turing_constant_chi8.py with rigorous integration."""
    ctx.prec = prec
    pi = arb.pi()
    e = arb(eps_num) / eps_den
    z = lambda s: arb(s).zeta() if not isinstance(s, arb) else s.zeta()
    # A_eps
    Ae = (arb(1) / 2 + e) * (1 + 1 / (arb(1) / 2 + e)).log() + (arb(3) / 2 + e).log()
    a = 1 + e
    logZ0 = lambda s: s.zeta().log()
    logz0 = lambda s: (2 * s).zeta().log() - s.zeta().log()
    def integ(fn, lo, hi):
        f = lambda t, _: acb(fn(t.real))
        pts = np.linspace(float(lo), float(hi), 9)
        v = acb(0)
        for i in range(len(pts) - 1):
            v += acb.integral(f, float(pts[i]), float(pts[i + 1]))
        return abs(v) if v.real > 0 else -abs(v)   # keep sign via real part
    def integ_signed(fn, lo, hi):
        f = lambda t, _: acb(fn(t.real))
        pts = np.linspace(float(lo), float(hi), 9)
        v = acb(0)
        for i in range(len(pts) - 1):
            v += acb.integral(f, float(pts[i]), float(pts[i + 1]))
        return v.real
    A_INF = arb(40)
    i1 = integ_signed(logZ0, a, A_INF) + log_zeta_tail(A_INF)         # int_a^oo log zeta
    i2 = integ_signed(logz0, a, 2 + e)                                 # int log z0
    i3 = integ_signed(logz0, arb(3) / 2, A_INF)                        # int_{3/2}^oo log z0:
    i3 = i3 + log_zeta_tail(2 * A_INF) + log_zeta_tail(A_INF)          # tail of both pieces
    # (z0 tail: |log z0| <= |log zeta(2s)| + |log zeta(s)|)
    # dlog z0 at a: 2 zeta'(2a)/zeta(2a) - zeta'(a)/zeta(a)  (arb derivative via zeta(s, d=1)?)
    # python-flint: arb has no zeta-derivative; use acb series:
    sa = acb(a)
    za = sa.zeta(); z2a = (2 * sa).zeta()
    h = arb(2) ** -40
    # zeta'(a) and zeta'(2a) by central FD at the ARGUMENT (chain-rule 2 applied once below)
    dz = ((sa + h).zeta() - (sa - h).zeta()) / (2 * h)
    dz2 = ((2 * sa + h).zeta() - (2 * sa - h).zeta()) / (2 * h)
    # FD truncation error h^2/6 |zeta'''| <= 1e-22 near s in [1.5, 3]; generous pad:
    dz = dz.real + arb(0, 1e-12); dz2 = dz2.real + arb(0, 1e-12)
    dlogz0_a = 2 * dz2 / z2a.real - dz / za.real
    c0 = (arb(1) / 2 + e) * za.real.log() + i1 - i2 - i3 + Ae * dlogz0_a
    # Q_L, Xmax, B  (Selberg-normalized data for chi8; mirrors upstream script)
    Nsel = arb(21) ** 5 / pi ** 4
    MU = [arb(0)] * 4 + [arb(1) / 2] * 4
    t1a, t2a = arb(str(t1)), arb(str(t2))
    def logQL(sr, si):
        v = 2 * Nsel.log()
        s = acb(sr, si)
        for m in MU:
            v += abs(s / 2 + m + 1).log()
        return v
    X = (t1a ** 2 - ((2 + e) / 2 + arb(1) / 2) ** 2).sqrt()
    assert X > 5, "PZ Thm 2.3 requires X > 5"
    b = ((arb(1) / 16 + e * (1 + e) / 4) * logQL(1 + e, float(t2a))
         + (Ae - 1) / 2 * logQL(1 + e, float(t1a))
         + 8 * c0
         + (arb(8) / X) * (arb(9) / 10 + 4 * Ae / 5))
    return b


if __name__ == '__main__':
    import time
    ctx.prec = 300
    print("== (A) alias bound sanity ==")
    t0 = time.time()
    for T in (34.0, 64.0, 94.0):
        lb = lambda_half_bound(T)
        print(f"  |Lambda(1/2+{T:.0f}i)| <= {float(lb.mid())+float(lb.rad()):.3e}   "
              f"({time.time()-t0:.0f}s)")
    for t in (0.0, 15.0, 30.0):
        ab = alias_bound(t, 64, 43, 50)     # eta = 0.86
        print(f"  alias sum at t={t:4.1f} (B=64, eta=0.86): "
              f"{float(ab.mid())+float(ab.rad()):.3e}")

    print("\n== (B) certified B vs float reference ==")
    for (t1, t2, ref) in ((5.969, 26.5, 56.940536), (6.55, 26.5, 56.772399)):
        b = certified_B(t1, t2)
        print(f"  B({t1}, {t2}) ball: [{float(b.mid())-float(b.rad()):.6f}, "
              f"{float(b.mid())+float(b.rad()):.6f}]   float ref {ref}")
