# step4_tails.py — rigor-ladder step 4: certified analytic tail bounds (v2, corrected).
#
# v1's Bessel-chain envelope was REFUTED by its own sanity check (ENV < |G|): for eta > 1/2
# the point z = (2pi)^4 e^w crosses the branch cut, so G is the analytic CONTINUATION of K4,
# not the principal branch the positive-kernel bound controls. Lesson recorded.
#
# v2 route — direct Mellin-contour bounds with EXACT Gamma modulus at half-integer sigma:
#   reflection:  |Gamma(1/2+it)|^4 = pi^2 / cosh^2(pi t)                    (exact)
#   recursion:   |Gamma(1/2+r+it)|^4 = prod_{i=0}^{r-1} ((i+1/2)^2+t^2)^2 * pi^2/cosh^2(pi t)
# so on the line Re s = sigma = 1/2 + r (r a nonneg integer):
#   (E1)  |G(u;eta)| <= (16/2pi) e^{u(1/2-sigma)} (2pi)^{-4sigma} I_abs(r),
#         I_abs(r) = int_R prod((i+1/2)^2+t^2)^2 * pi^2/cosh^2(pi t) * e^{2 pi eta t} dt,
#   computed RIGOROUSLY by acb_calc (acb.integral) on [-T,T] + elementary exponential tail.
#   Choosing r near the saddle 2 pi e^{u/4} cos(pi eta/2) recovers the true decay constant;
#   we take a rigorous min over a small r-candidate set.  For u beyond an anchor u0, the
#   fixed-r formula gives the certified geometric domination env(u) <= env(u0) e^{-r(u-u0)}.
#   (E2)  |G^(k)(u;eta)|/k! <= (16/2pi)(2pi)^{-2} * (4 pi^2/k!) *
#              [ k! / (2pi(1-eta))^{k+1} + k! / (2pi(1+eta))^{k+1} ]      (sigma = 1/2,
#         |Gamma|^4 e^{2 pi eta t} <= 4 pi^2 e^{-2pi(1-eta)|t|} on t>0, (1+eta) on t<0)
#         — u-UNIFORM; feeds the bucket-Taylor K-remainder (Booker (5.16)/(5.17) shape).
#
# Tails built on (E1)/(E2):
#   (T2) coefficient truncation n > M: |a_n| <= d8(n), sum_{n<=x} d8(n) <= x(1+ln x)^7
#        (induction), dyadic blocks against the envelope + geometric domination.
#   (T3) Taylor K-remainder per Fhat entry: sum_m A_m (h/2)^K * (E2 with k=K).
#   (T4) l-tail of the Poisson sum: fixed-r geometric decay e^{-r h} per l step.
# DECLARED, still open: F-side aliasing |F(t+jB)| (|Lambda| bound at t+jB) and the
# certified PZ B-constant.
import numpy as np
from flint import arb, acb, ctx


def I_abs(r, eta_num, eta_den, prec=None):
    """Rigorous I_abs(r) = int prod_{i<r}((i+1/2)^2+t^2)^2 pi^2/cosh^2(pi t) e^{2pi eta t} dt.
    Robustness (v2.1): working precision scales with r (the integrand spans ~8r ulp-decades),
    the interval is split into unit-scale segments, and the cutoff solve is bounded."""
    if prec is None:
        prec = 200 + 12 * r
    ctx.prec = prec
    pi = arb.pi()
    eta = arb(eta_num) / eta_den
    a = 2 * pi * (1 - eta)                 # net decay rate on t > 0
    # cutoff T: for t >= T require (2t^2)^{2r} <= e^{a t/2}; solve by doubling then refine
    T = arb(10)
    while not ((2 * T * T).log() * (2 * r) < a * T / 2):
        T *= 2
        if T > 10 ** 6:
            raise RuntimeError("I_abs cutoff runaway")
    def f(t, _):
        v = acb(pi) ** 2 / (pi * t).cosh() ** 2
        for i in range(r):
            v *= (arb(2 * i + 1) ** 2 / 4 + t ** 2) ** 2
        return v * (2 * pi * eta * t).exp()
    # split into segments of length <= 8 (keeps acb_calc's subdivision local and stable)
    Tf = float(T.mid()) + 1
    pts = np.linspace(-Tf, Tf, max(3, int(np.ceil(Tf / 4)) * 2 + 1))
    main = acb(0)
    for i in range(len(pts) - 1):
        seg = acb.integral(f, float(pts[i]), float(pts[i + 1]))
        if not seg.is_finite():
            raise RuntimeError(f"I_abs segment [{pts[i]:.0f},{pts[i+1]:.0f}] failed (r={r})")
        main += seg
    tail = 4 * pi ** 2 * (-a * T / 2).exp() / (a / 2)
    return abs(main) + 2 * tail


def env_G(u, eta_num, eta_den, r_set=None, prec=200):
    """(E1): certified |G(u;eta)| bound, rigorous min over r-candidates. Returns (bound, r*)."""
    ctx.prec = prec
    pi = arb.pi()
    u = u if isinstance(u, arb) else arb(u)
    if r_set is None:
        e = eta_num / eta_den
        r0 = 2 * np.pi * np.exp(float(u.mid()) / 4) * np.cos(np.pi * e / 2)
        r_set = sorted({max(0, int(r0 * s)) for s in (0.6, 1.0, 1.5)})
    best, rbest = None, None
    for r in r_set:
        sig = arb(2 * r + 1) / 2
        b = (16 / (2 * pi)) * (u * (arb(1) / 2 - sig)).exp() * (2 * pi) ** (-4 * sig) \
            * I_abs(r, eta_num, eta_den, prec)
        if best is None or b < best:
            best, rbest = b, r
    return best, rbest


def deriv_bound(k, eta_num, eta_den, prec=200):
    """(E2): u-uniform certified bound for |G^(k)(u;eta)| / k!."""
    ctx.prec = prec
    pi = arb.pi()
    eta = arb(eta_num) / eta_den
    am = 2 * pi * (1 - eta); ap = 2 * pi * (1 + eta)
    return (16 / (2 * pi)) * (2 * pi) ** -2 * 4 * pi ** 2 * (am ** -(k + 1) + ap ** -(k + 1))


def divisor8_cum(x):
    x = x if isinstance(x, arb) else arb(x)
    return x * (1 + x.log()) ** 7


def trunc_tail_rankin(x, M, eta_num, eta_den, sigma_num=5, sigma_den=4, prec=200):
    """(T2, Rankin form — the production bound): for sigma in (1, 3/2],
      N^{1/4} sum_{n>M}|a_n| n^{-1/2} |G(x+u_n)| <= N^{1/4} zeta(sigma)^8 M^{sigma-1/2}
                                                     * env_G(x + u_M) * slack,
    since |a_n| <= d8(n), sum d8(n) n^{-sigma} = zeta(sigma)^8, and n^{sigma-1/2} env(x+u_n)
    is maximized at n = M (env's fixed-r geometric decay rate r0 > sigma-1/2, asserted).
    slack = 1/(1 - e^{-(r0-(sigma-1/2)) h}) covers the sup->sum domination."""
    ctx.prec = prec
    N4 = (arb(21) ** 10).root(4)
    logsqN = (arb(21) ** 10).log() / 2
    sig = arb(sigma_num) / sigma_den
    u_M = arb(M).log() - logsqN
    e0, r0 = env_G(arb(x) + u_M, eta_num, eta_den, prec=prec)
    assert arb(r0) > sig - arb(1) / 2, "Rankin domination needs r0 > sigma - 1/2"
    zs = sig.zeta() ** 8
    slack = 1 / (1 - (-(arb(r0) - (sig - arb(1) / 2))).exp())
    return N4 * zs * arb(M) ** (sig - arb(1) / 2) * e0 * slack


def trunc_tail(x, M, eta_num, eta_den, prec=200):
    """(T2): certified N^{1/4} sum_{n>M} |a_n| n^{-1/2} |G(x + log(n/sqrtN); eta)| bound."""
    ctx.prec = prec
    N4 = (arb(21) ** 10).root(4)
    logsqN = (arb(21) ** 10).log() / 2
    u0 = arb(x) + arb(M).log() - logsqN
    e0, r0 = env_G(u0, eta_num, eta_den, prec=prec)      # anchor envelope
    tot = arb(0)
    for j in range(400):
        lo = arb(M) * 2 ** j
        blk = divisor8_cum(lo * 2) / lo.sqrt()
        du = arb(j) * arb(2).log()                        # u_lo(block j) - u0
        term = N4 * blk * e0 * (-arb(r0) * du).exp()      # fixed-r geometric domination
        tot += term
        if term < arb(10) ** -90:
            break
    return tot


def taylor_remainder_total(sumA, B, eta_num, eta_den, K=14, prec=200):
    """(T3): certified bound for the K-Taylor remainder of ONE Fhat entry, then the
    F-level total: rem_Fhat <= N^{1/4} * sumA * (h/2)^K * deriv_bound(K);
    F-level: (2pi/B)(1 + 2*l_count) * rem_Fhat is the caller's affair — here per-entry."""
    ctx.prec = prec
    N4 = (arb(21) ** 10).root(4)
    h = 2 * arb.pi() / B
    return N4 * arb(sumA) * (h / 2) ** K * deriv_bound(K, eta_num, eta_den, prec) \
        * arb.fac_ui(K)   # deriv_bound is |G^(K)|/K!; remainder needs |G^(K)|/K! * ...


def taylor_remainder_entry(sumA, B, eta_num, eta_den, K=14, prec=200):
    """(T3) per-Fhat-entry: sum_m A_m (h/2)^K sup|G^(K)|/K!  (Booker (5.16))."""
    ctx.prec = prec
    N4 = (arb(21) ** 10).root(4)
    h = 2 * arb.pi() / B
    return N4 * arb(sumA) * (h / 2) ** K * deriv_bound(K, eta_num, eta_den, prec)


def l_tail(l_top, sumA, B, eta_num, eta_den, prec=200):
    """(T4): certified (2pi/B) * 2 * sum_{l>l_top} |Fhat(lh)| via fixed-r geometric decay.
    Crude domination: |Fhat(lh)| <= N^{1/4} sumA * env_G(l h + u_min_arg) with the smallest
    G-argument (l+m_min)h — but m_min buckets have tiny C; we use sumA * env at (l - |m|)h
    conservatively via the anchor at u_anchor = (l_top+1+m_min) h. Caller passes the anchor u."""
    raise NotImplementedError  # superseded: l-tail handled by u_anchor form below


def l_tail_anchor(u_anchor, sumA, B, eta_num, eta_den, prec=200):
    """(T4): (2pi/B)*2*N^{1/4}*sumA * env(u_anchor)/(1 - e^{-r h})  — all l > l_top dominated
    by the envelope at their smallest possible argument u_anchor + (l - l_top - 1) h."""
    ctx.prec = prec
    pi = arb.pi()
    N4 = (arb(21) ** 10).root(4)
    h = 2 * pi / B
    e0, r0 = env_G(arb(u_anchor), eta_num, eta_den, prec=prec)
    q = (-arb(r0) * h).exp()
    return (2 * pi / B) * 2 * N4 * arb(sumA) * e0 / (1 - q)


if __name__ == '__main__':
    ctx.prec = 200
    print("== (E1) envelope sanity vs certified |G| balls (eta = 22/25) ==")
    import g_kernel_arb as ga
    for l in (0, 32, 64, 96):
        ctx.prec = ga.PREC
        g = ga.g_all_k(l, eta_num=22, eta_den=25)[0]
        ctx.prec = 200
        e, r = env_G(arb.pi() * l / 32, 22, 25)
        gm = float(abs(g).mid())
        ok = 'OK' if e > abs(g) else '**ENV < |G| FAIL**'
        print(f"  u={l*np.pi/32:6.2f}: |G|={gm:.3e}  ENV={float(e.mid()):.3e} (r*={r})  "
              f"ratio {float(e.mid())/max(gm,1e-300):.1e}  {ok}")

    print("\n== production tail magnitudes (eta = 22/25, M = 1.7e10, B = 64, K = 14) ==")
    M = int(1.7e10)
    for x in (0.0, 3.0, 6.0):
        t = trunc_tail(x, M, 22, 25)
        print(f"  (T2) trunc tail at x={x:4.1f}: {float(t.mid())+float(t.rad()):.3e}")
    # rigorous cap for sum_m A_m at production: sum d8(n)/sqrt(n), dyadic
    sumA = arb(0)
    lo = arb(1)
    while lo < M:
        hi = min(lo * 2, arb(M))
        sumA += divisor8_cum(hi) / lo.sqrt()
        lo = hi
    print(f"  rigorous cap sum_m A_m <= {float(sumA.mid()):.3e}")
    for K in (14, 16, 18):
        tr = taylor_remainder_entry(sumA, 64, 22, 25, K=K)
        print(f"  (T3) Taylor remainder per Fhat entry, K={K}: {float(tr.mid())+float(tr.rad()):.3e}")
    lt = l_tail_anchor(8.5, sumA, 64, 22, 25)
    print(f"  (T4) l-tail (anchor u=8.5): {float(lt.mid())+float(lt.rad()):.3e}")
    print("\n(declared open: F-side aliasing, certified PZ B-constant)")
