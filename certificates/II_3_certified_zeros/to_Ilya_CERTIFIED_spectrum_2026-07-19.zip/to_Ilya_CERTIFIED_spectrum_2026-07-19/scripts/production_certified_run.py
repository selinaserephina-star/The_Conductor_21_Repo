# production_certified_run.py — THE certified production run (rigor ladder complete).
#
# Locked spec (2026-07-18): eta = 22/25, B = 96, A = 64, K = 16, t2 = 30, M = 5e10 (int16),
# box r7i.8xlarge (256 GB). Deliverables: certified zero brackets for every zero in [0, 30]
# + the CERTIFIED one-sided Turing counts N+(5.969) = 21, N+(6.55) = 24, and the full-range
# count to T* as high as margins allow. Every error term is a proven bound:
#   S-sums: contiguous-slice pairwise radii (chunked)      [certified_engine, chunked here]
#   G-kernel: arb residue series, radii <= 1e-72           [g_kernel_arb]
#   evaluation: direct Poisson ball sum                    [certified_engine.F_ball]
#   coefficient truncation n > M: d8 + contour envelope    [step4_tails.trunc_tail]
#   Taylor K-remainder: exact sigma=1/2 derivative bound   [step4_tails.deriv_bound]
#   l-tail: envelope geometric domination                  [step4_tails.l_tail_anchor]
#   aliasing: Gaussian-localized Cauchy, interval-T        [step4_close.lambda_half_bound]
#   Turing constant B: certified ball, upper end used      [step4_close.certified_B]
#
# Usage:
#   python3 production_certified_run.py sieve  --M 5e10 --out an_chi8_50G.npy
#   python3 production_certified_run.py run    --an an_chi8_50G.npy [--t2 30]
#   python3 production_certified_run.py selftest       (local: M=1e8 vs known results)
import argparse, csv, json, os, sys, time
import numpy as np
import mpmath as mp
from flint import arb, acb, ctx

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from gen_an_chi8 import LOC8, AP, CYCLE_TO_CLASS, frob_class, inv_series, prime_sieve
import certified_engine as ce
import step4_tails as s4
import step4_close as s4c
import g_kernel_arb as ga

ETA_NUM, ETA_DEN = 22, 25
B_PER, A_GRID, K_TAY = 128, 64, 16
LOGSQN = float(mp.log(mp.mpf(21) ** 10) / 2)


# ---------- stage A: int16 sieve with chunked-int64 small-prime arithmetic ----------
def gen_an_int16(M, progress=True, chunk=int(2e8)):
    """gen_an with int16 storage; small-prime updates via int64 chunks (c_k*b overflows
    int32 at M ~ 5e10). Bit-identical to gen_an_chi8.gen_an (validated in selftest)."""
    a = np.zeros(M + 1, dtype=np.int16)
    a[1] = 1
    primes = prime_sieve(M)
    t0 = time.time()
    for i, p in enumerate(primes):
        p = int(p)
        cls = frob_class(p)
        if p * p > M:
            ap = AP[cls]
            if ap:
                mmax = M // p
                a[p:p * mmax + 1:p] += (ap * a[1:mmax + 1]).astype(np.int16)
        else:
            K = 1
            while p ** (K + 1) <= M:
                K += 1
            c = inv_series(LOC8[cls], K)
            b = a[:M // p + 1].copy()
            for k in range(1, K + 1):
                pk = p ** k
                mmax = M // pk
                ck = int(c[k])
                if ck == 0:
                    continue
                # chunked int64: a[pk*j] += ck * b[j], j = 1..mmax
                for j0 in range(1, mmax + 1, chunk):
                    j1 = min(j0 + chunk, mmax + 1)
                    tmp = a[pk * j0: pk * (j1 - 1) + 1: pk].astype(np.int64) \
                        + ck * b[j0:j1].astype(np.int64)
                    mx = np.abs(tmp).max() if len(tmp) else 0
                    assert mx < 32000, f"int16 overflow at p={p} k={k}: {mx}"
                    a[pk * j0: pk * (j1 - 1) + 1: pk] = tmp.astype(np.int16)
            del b
        if progress and (i & 0x3FFFFF) == 0 and i:
            print(f"  sieve {i}/{len(primes)} primes {time.time()-t0:.0f}s", flush=True)
    if progress:
        print(f"  sieve done {len(primes)} primes {time.time()-t0:.0f}s", flush=True)
    return a


# ---------- stage A v2: memory-lean sieve for M ~ 1.2e11 (240 GB int16 array) ----------
# Two structural facts make the big-M sieve fit the box:
#  (1) DISJOINTNESS: at prime p's turn (ascending), a_old is supported on p-free n, and the
#      p-update writes only p-divisible positions. Reads from p-free sources are therefore
#      never clobbered — the b-copy is unnecessary IF reads exclude p-divisible indices.
#      For p <= 31 (where the M/p copy would strain RAM) we enforce that with residue-strided
#      slices: source a[r::p] (r = 1..p-1), target a[p^k r :: p^{k+1}].  For 17 <= p <= sqrtM
#      the copy is <= M/17 ~ 14 GB — keep the simple validated path.
#  (2) UNIQUENESS: for large p > sqrtM, n = p*m has exactly one prime factor > sqrtM, so all
#      scatter targets are distinct — buffered fancy read-add-write is safe (no np.add.at).
#      Large primes are STREAMED in segments (never stored): segmented Eratosthenes +
#      parallel Frobenius classification per segment.
def _classify_range(args):
    lo_idx, plist = args
    from gen_an_chi8 import frob_class, AP
    return [AP[frob_class(int(p))] for p in plist]


def gen_an_int16_v2(M, progress=True, chunk=int(2e8), seg=int(1e9), nproc=None,
                    a_phase1=None, ckpt=None, ckpt_flag=None):
    import math
    sqM = int(math.isqrt(M))
    small = prime_sieve(sqM)
    t0 = time.time()
    if a_phase1 is not None:
        a = a_phase1
        if progress:
            print("  phase 1 skipped (checkpoint)", flush=True)
        return _phase2_v2(M, a, small, progress, seg, nproc, t0)
    a = np.zeros(M + 1, dtype=np.int16)
    a[1] = 1
    # --- phase 1: small primes ---
    for p in small:
        p = int(p)
        cls = frob_class(p)
        K = 1
        while p ** (K + 1) <= M:
            K += 1
        c = inv_series(LOC8[cls], K)
        if p <= 31:
            # residue-strided, no copy; int64 chunked (c_k up to ~3e7)
            for k in range(1, K + 1):
                pk = p ** k
                ck = int(c[k])
                if ck == 0:
                    continue
                jmax = M // pk
                for r in range(1, p):
                    # sources j = r, r+p, ... <= jmax ; targets pk*j
                    nsrc = (jmax - r) // p + 1 if jmax >= r else 0
                    for j0 in range(0, nsrc, chunk):
                        j1 = min(j0 + chunk, nsrc)
                        src = a[r + p * j0: r + p * (j1 - 1) + 1: p].astype(np.int64)
                        ti = pk * r + pk * p * j0
                        tgt = a[ti: ti + pk * p * (j1 - j0 - 1) + 1: pk * p]
                        tmp = tgt.astype(np.int64) + ck * src
                        assert np.abs(tmp).max(initial=0) < 32000, f"ovf p={p} k={k}"
                        a[ti: ti + pk * p * (j1 - j0 - 1) + 1: pk * p] = tmp.astype(np.int16)
        else:
            b = a[:M // p + 1].copy()
            for k in range(1, K + 1):
                pk = p ** k
                mmax = M // pk
                ck = int(c[k])
                if ck == 0:
                    continue
                for j0 in range(1, mmax + 1, chunk):
                    j1 = min(j0 + chunk, mmax + 1)
                    tmp = a[pk * j0: pk * (j1 - 1) + 1: pk].astype(np.int64) \
                        + ck * b[j0:j1].astype(np.int64)
                    assert np.abs(tmp).max(initial=0) < 32000, f"ovf p={p} k={k}"
                    a[pk * j0: pk * (j1 - 1) + 1: pk] = tmp.astype(np.int16)
            del b
    if progress:
        print(f"  phase 1 (p <= {sqM}) done {time.time()-t0:.0f}s", flush=True)
    if ckpt:
        np.save(ckpt, a)
        open(ckpt_flag, 'w').write('phase1')
        if progress:
            print(f"  phase-1 checkpoint saved {time.time()-t0:.0f}s", flush=True)
    return _phase2_v2(M, a, small, progress, seg, nproc, t0)


def _phase2_v2(M, a, small, progress, seg, nproc, t0):
    import math
    sqM = int(math.isqrt(M))
    # --- phase 2: large primes, segmented + classified in parallel ---
    # SPAWN context: fork would copy ~0.5 GB of page tables per worker for the big
    # array's mapping (32 workers = ~15 GB -> OOM, observed twice); spawn workers are
    # fresh ~50 MB processes.
    if progress:
        print(f"  phase 2 starting (spawn pool) {time.time()-t0:.0f}s", flush=True)
    try:
        import multiprocessing as mpr
        nw = min(24, os.cpu_count() or 4) if nproc is None else nproc
        pool = mpr.get_context('spawn').Pool(nw) if nw > 1 else None
    except Exception:
        pool = None
    base = small
    for P0 in range(sqM + 1, M + 1, seg):
        P1 = min(P0 + seg, M + 1)
        sieve_blk = np.ones(P1 - P0, dtype=bool)
        for p in base:
            p = int(p)
            st = (-(P0) % p)
            if P0 + st == p:      # p itself (only when P0 <= p < P1, impossible here)
                st += p
            sieve_blk[st::p] = False
        prims = np.nonzero(sieve_blk)[0] + P0
        if len(prims) == 0:
            continue
        # classify (parallel): AP values per prime
        if pool is not None:
            nsp = 32
            chunks = np.array_split(prims, nsp)
            aps = np.concatenate([np.array(r, dtype=np.int16) for r in
                                  pool.map(_classify_range, [(i, c) for i, c in enumerate(chunks)])])
        else:
            from gen_an_chi8 import AP as _AP
            aps = np.array([_AP[frob_class(int(p))] for p in prims], dtype=np.int16)
        nz = aps != 0
        prims = prims[nz]; aps = aps[nz]
        # scatter: for m = 1.., primes p in this segment with p <= M/m
        mmax = M // P0
        for m in range(1, mmax + 1):
            hi = np.searchsorted(prims, M // m, side='right')
            if hi == 0:
                continue
            am = int(a[m])
            if am == 0:
                continue
            idx = prims[:hi] * m
            a[idx] = (a[idx].astype(np.int32) + aps[:hi].astype(np.int32) * am).astype(np.int16)
        if progress:
            print(f"  phase 2 segment {P0:.2e}: {len(prims)} nonzero-ap primes "
                  f"{time.time()-t0:.0f}s", flush=True)
    if pool is not None:
        pool.close()
    if progress:
        print(f"  sieve v2 done {time.time()-t0:.0f}s", flush=True)
    return a


# ---------- stage B: chunked certified S-sums ----------
def certified_S_chunked(an_file, B, K, chunk=int(5e8), verbose=True):
    """certified_S for coefficient files too large for whole-array float64 staging.
    Chunk over n; per-bucket partials combined with radii accumulated (each chunk's
    pairwise bound + Neumaier-level combine slack)."""
    a = np.load(an_file, mmap_mode='r')
    M = len(a) - 1
    h = 2 * np.pi / B
    m_min = int(np.rint((np.log(1.0) - LOGSQN) / h))
    m_max = int(np.rint((np.log(float(M)) - LOGSQN) / h))
    nbuck = m_max - m_min + 1
    S = np.zeros((K, nbuck)); R = np.zeros((K, nbuck)); Am = np.zeros(nbuck)
    Dd = 1.6e-14
    U = 2.0 ** -53
    t0 = time.time()
    for n0 in range(1, M + 1, chunk):
        n1 = min(n0 + chunk, M + 1)
        n = np.arange(n0, n1, dtype=np.float64)
        cs = np.asarray(a[n0:n1], dtype=np.float64) / np.sqrt(n)
        u = np.log(n) - LOGSQN
        midx = np.rint(u / h).astype(np.int64)
        d = u - midx * h
        assert np.all(np.diff(midx) >= 0)
        lo_m, hi_m = int(midx[0]), int(midx[-1])
        edges = np.searchsorted(midx, np.arange(lo_m, hi_m + 2))
        for mi in range(hi_m - lo_m + 1):
            s0e, s1e = edges[mi], edges[mi + 1]
            if s0e == s1e:
                continue
            p = s1e - s0e
            gm = lo_m + mi - m_min
            css = cs[s0e:s1e]; ds = d[s0e:s1e]
            A = float(np.sum(np.abs(css))) * (1 + 1e-12)
            Am[gm] += A
            sb = (128 + np.log2(max(p, 2))) * U
            dk = np.ones(p)
            for k in range(K):
                S[k, gm] += np.sum(css * dk)
                R[k, gm] += A * ((h / 2) ** k * ((k + 5) * U + sb)
                                 + k * (h / 2) ** (k - 1) * Dd)
                dk = dk * ds
        if verbose and (n0 // chunk) % 10 == 0:
            print(f"  S-chunks {n0}/{M} {time.time()-t0:.0f}s", flush=True)
    # combine slack: <= n_chunks partial adds per bucket, each fl-add error u*|running|
    nch = (M // chunk) + 1
    for k in range(K):
        R[k] += nch * U * np.abs(S[k]) * 2
    if verbose:
        print(f"certified S (chunked): {nbuck} buckets, max rad k=0 {R[0].max():.2e}, "
              f"sumA={Am.sum():.3e}, {time.time()-t0:.0f}s", flush=True)
    return S, R, m_min, m_max, Am


# ---------- stage E-F-G: tails, scan, certify, count ----------
def run(an_file, t2, out_prefix, selftest_eta=None):
    eta_n, eta_d = (ETA_NUM, ETA_DEN) if selftest_eta is None else selftest_eta
    B = B_PER
    print(f"== certified production run: eta={eta_n}/{eta_d}, B={B}, K={K_TAY}, "
          f"t2={t2}, an={an_file} ==", flush=True)
    M = np.load(an_file, mmap_mode='r').shape[0] - 1
    scache = f"scache_M{M}_B{B}_K{K_TAY}.npz"
    if os.path.exists(scache):
        z = np.load(scache)
        S, R, Am = z['S'], z['R'], z['Am']
        m_min, m_max = int(z['mm'][0]), int(z['mm'][1])
        print(f"S-cache loaded: {scache}", flush=True)
    else:
        S, R, m_min, m_max, Am = certified_S_chunked(an_file, B, K_TAY)
        np.savez(scache, S=S, R=R, Am=Am, mm=np.array([m_min, m_max]))
        print(f"S-cache saved: {scache}", flush=True)
    Fhat = ce.certified_fhat(S, R, m_min, m_max, B, eta_n, eta_d)
    l_top = len(Fhat) - 1
    h = 2 * np.pi / B

    # ---- step-4 tail radii (constants added to every F evaluation) ----
    ctx.prec = 300
    sumA = float(Am.sum())
    tay = s4.taylor_remainder_entry(sumA, B, eta_n, eta_d, K=K_TAY)   # per Fhat entry
    tay_F = (2 * np.pi / B) * (1 + 2 * l_top) * (float(tay.mid()) + float(tay.rad()))
    trunc0 = s4.trunc_tail_rankin(0.0, M, eta_n, eta_d)                # worst x = 0
    # geometric domination in x: trunc(x_l) <= trunc0 * e^{-r0 x_l} (env fixed-r property)
    _, r0 = s4.env_G(arb((np.log(M) - LOGSQN)), eta_n, eta_d)
    qx = float((-arb(r0) * h).exp().mid())
    trunc_F = (2 * np.pi / B) * (1 + 2 / (1 - qx)) * (float(trunc0.mid()) + float(trunc0.rad()))
    ltail = s4.l_tail_anchor((l_top + 1 + m_min) * h, sumA, B, eta_n, eta_d)
    ltail_F = float(ltail.mid()) + float(ltail.rad())
    # alias over t in [0, t2]: per-unit-segment scalar bounds, paired growth factors.
    # right alias j: sup over t in [ti, ti+1] of |Lambda(1/2+i(jB+t))| e^{2 pi eta (jB+t)}
    #   <= lambda_bound(jB + ti) * e^{2 pi eta (jB + ti + 1)}   (lambda_bound decreasing);
    # left alias j: T = jB - t in [jB - ti - 1, jB - ti], factor e^{2 pi eta (t - jB)} tiny.
    ctx.prec = 600
    twopieta = 2 * arb.pi() * arb(eta_n) / eta_d
    alias_F = 0.0
    for j in (1, 2):
        seg_max = 0.0
        for ti in range(0, int(np.ceil(t2))):
            lbR = s4c.lambda_half_bound_closed(arb(j * B + ti))
            gR = (twopieta * (j * B + ti + 1)).exp()
            lbL = s4c.lambda_half_bound_closed(arb(j * B - ti - 1))
            gL = (-twopieta * (j * B - ti - 1)).exp()
            # products in ARB first: float64 overflows at e^709 while the arb
            # product tiny*huge is small (the alias-inf root cause, twice)
            pR = (lbR.mid() + lbR.rad()) * gR
            pL = (lbL.mid() + lbL.rad()) * gL
            v = (float((pR.mid() + pR.rad())) + float((pL.mid() + pL.rad()))) * 1.01
            seg_max = max(seg_max, v)
        alias_F += 2 * seg_max
    tail_total = tay_F + trunc_F + ltail_F + alias_F
    print(f"tail radii: taylor {tay_F:.2e}  trunc {trunc_F:.2e}  ltail {ltail_F:.2e}  "
          f"alias {alias_F:.2e}  TOTAL {tail_total:.2e}", flush=True)

    def F_certified(t):
        f = ce.F_ball(t, Fhat, B)
        return f + arb(0, tail_total)

    # ---- scan (float mids) + bisect + ball-certify ----
    print("scanning...", flush=True)
    tg = np.arange(0.05, t2, 1.0 / A_GRID)
    mids = np.array([float(ce.F_ball(t, Fhat, B).mid()) for t in tg])
    sc = np.where(np.diff(np.sign(mids)) != 0)[0]
    sgn = lambda x: 1 if x > 0 else (-1 if x < 0 else 0)
    brackets = []
    for i in sc:
        # certify FIRST at the wide grid interval (|F| at endpoints ~ grid-scale, far
        # above the radius), then refine adaptively while ball signs stay definite —
        # fixed-depth bisection drove endpoints so close to the zero that |F| fell
        # below the certified radius and the high-t brackets lost their signs.
        lo, hi = tg[i], tg[i + 1]
        fl, fh = F_certified(lo), F_certified(hi)
        sl, sh = sgn(fl), sgn(fh)
        if sl * sh != -1:
            brackets.append((lo, hi, False, float(fl.rad()), abs(float(fl.mid()))))
            continue
        for _ in range(12):
            mid = 0.5 * (lo + hi)
            fm = F_certified(mid)
            sm = sgn(fm)
            if sm == 0:
                break                              # radius floor reached: keep last bracket
            if sm == sl:
                lo, fl = mid, fm
            else:
                hi, fh = mid, fm
        brackets.append((lo, hi, True, float(fl.rad()), abs(float(fl.mid()))))
    ncert = sum(1 for b in brackets if b[2])
    print(f"{len(brackets)} sign changes, {ncert} CERTIFIED brackets", flush=True)

    # ---- certified Turing counts ----
    zeros_lo = np.array([b[0] for b in brackets if b[2]])
    zeros_hi = np.array([b[1] for b in brackets if b[2]])
    results = dict(eta=f"{eta_n}/{eta_d}", B=B, K=K_TAY, M=int(M), t2=t2,
                   tail_total=tail_total, n_brackets=len(brackets), n_certified=ncert,
                   brackets=[(float(a), float(b)) for a, b, ok, _, _ in brackets if ok])
    from turing_count import turing_condition, int_phi
    verdicts = []
    for (t1, nb) in ((5.969, 21), (6.55, 24)):
        for t2e in (25.0, 26.5, min(t2 - 1, 29.0)):
            if t2e >= t2:
                continue
            Bball = s4c.certified_B(t1, t2e)
            Bup = float(Bball.mid()) + float(Bball.rad())
            # N_found staircase from certified brackets: count a zero at its UPPER end
            # (conservative for the one-sided rule-out: delays each count)
            zs = zeros_hi[(zeros_hi > t1) & (zeros_hi <= t2e)]
            r = turing_condition(list(zs), t2e, t1=t1, B=Bup, n_below=nb)
            r['B_certified_upper'] = Bup
            r['t1'] = t1; r['n_below'] = nb
            verdicts.append(r)
            print(f"  CERTIFIED Turing t1={t1} n={nb} t2={t2e}: margin "
                  f"{r['lhs']-r['need']:+.4f} {'PASS' if r['certified'] else 'FAIL'}", flush=True)
    results['turing'] = [{k: (float(v) if isinstance(v, (int, float, np.floating)) else v)
                          for k, v in r.items()} for r in verdicts]
    with open(f"{out_prefix}_result.json", 'w') as fh:
        json.dump(results, fh, indent=1)
    with open(f"{out_prefix}_brackets.csv", 'w', newline='') as fh:
        w = csv.writer(fh); w.writerow(['j', 'lo', 'hi', 'certified'])
        for j, (a, b, ok, _, _) in enumerate(brackets, 1):
            w.writerow([j, f"{a:.6f}", f"{b:.6f}", ok])
    print(f"saved {out_prefix}_result.json / _brackets.csv", flush=True)


def selftest():
    """Local: (1) int16 sieve == reference at M=2e6; (2) chunked S == plain S at M=1e8;
    (3) mini-run at eta=3/10, t2=6 against the certified master brackets."""
    print("== selftest 1: int16 sieve vs gen_an_chi8 reference (M=2e6) ==", flush=True)
    ref = np.load(os.path.join(HERE, 'an_chi8_2M.npy'))
    M = len(ref) - 1
    mine = gen_an_int16(M, progress=False)
    assert np.array_equal(ref.astype(np.int64), mine.astype(np.int64)), "sieve mismatch!"
    mine2 = gen_an_int16_v2(M, progress=False, nproc=2)
    assert np.array_equal(ref.astype(np.int64), mine2.astype(np.int64)), "sieve v2 mismatch!"
    print(f"   IDENTICAL, v1 AND v2 ({M} coefficients)", flush=True)
    print("== selftest 2: chunked S vs plain S (M=1e8, B=96, K=16) ==", flush=True)
    S1, R1, m0, m1 = ce.certified_S(os.path.join(HERE, 'an_chi8_100M.npy'), 96, K=16)
    S2, R2, m0b, m1b, Am = certified_S_chunked(os.path.join(HERE, 'an_chi8_100M.npy'), 96, 16)
    assert (m0, m1) == (m0b, m1b)
    dmax = np.abs(S1 - S2).max()
    assert dmax < R1.max() + R2.max() + 1e-12, f"chunked S drift {dmax}"
    print(f"   agree to {dmax:.2e} (radii {R2[0].max():.2e})", flush=True)
    print("== selftest 3: mini certified run (M=1e8, eta=4/5, t2=6) ==", flush=True)
    # eta = 4/5: envelope-valid (cos 2pi*0.8 > 0) and M=1e8 still certifies to t ~ 6
    run(os.path.join(HERE, 'an_chi8_100M.npy'), 6.0, 'selftest', selftest_eta=(4, 5))


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('mode', choices=['sieve', 'run', 'selftest'])
    ap.add_argument('--M', type=float, default=5e10)
    ap.add_argument('--an', default='an_chi8_50G.npy')
    ap.add_argument('--out', default='an_chi8_50G.npy')
    ap.add_argument('--t2', type=float, default=30.0)
    ap.add_argument('--prefix', default='certified_run')
    args = ap.parse_args()
    if args.mode == 'sieve':
        M = int(args.M)
        flag = args.out + '.phase1only'
        if os.path.exists(args.out) and os.path.exists(flag):
            print(f"resuming: loading phase-1 checkpoint {args.out}", flush=True)
            a = np.load(args.out)
            assert len(a) == M + 1, "checkpoint M mismatch"
            a = gen_an_int16_v2(M, a_phase1=a)
        else:
            a = gen_an_int16_v2(M, ckpt=args.out, ckpt_flag=flag)
        np.save(args.out, a)                      # work on disk FIRST
        if os.path.exists(flag):
            os.remove(flag)
        print(f"saved {args.out} ({a.nbytes/1e9:.0f} GB)", flush=True)
        mx = 0                                    # chunked |a|.max: no full-array temp
        for i0 in range(0, len(a), int(2e9)):
            mx = max(mx, int(np.abs(a[i0:i0 + int(2e9)]).max(initial=0)))
        assert mx < 32000, f"global magnitude check failed: {mx}"
        print(f"max|a_n| = {mx}  (int16 headroom OK)", flush=True)
    elif args.mode == 'run':
        run(args.an, args.t2, args.prefix)
    else:
        selftest()
