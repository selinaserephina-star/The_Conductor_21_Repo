Ilya —

A consolidation and two upgrades on the χ₈ zeros, all on your s26b / Channel-B pipeline.

**One folder, all the zeros.** `chi8_zeros_master.csv` + `README_MASTER_certified_zeros.md` now hold the
whole γ₁–γ₂₁ record in one place — value/bracket, grade, method, date, and an evidence pointer per zero.
Standing count: **γ₁–γ₁₈ ball-certified, γ₁₉–γ₂₁ anchored** — 18 of 21, up from 17.

**Two upgrades (2026-07-14), via Channel-B on fresh 16M jets** (full certificate +
scan-CSV evidence: `gamma14_18_channelB_certificate_2026-07-14/`, SHA-sealed):

- **γ₁₄ tightened ~11×**: [4.357, 4.379] → **[4.366, 4.368]**. This was the widest certified bracket and
  the precision floor on the genome operator (it capped R-210/R-211 at ~3 sig figs); it's now ~4.
- **γ₁₈ upgraded**: `numerical_anchored` → **ball-certified [5.142, 5.190]**.

**How** — and a note against my own earlier instinct: a plain tight-window s26b rerun at 16M does *not*
certify these; the binding floor is the Rankin d₈ tail at the 80M block cutoff (4×10⁻⁹), not the U₁₇
Taylor term a tight window shrinks. Your Channel-B fix — extend the cutoff to 120M (dc→1.9×10⁻¹¹) and
re-difference the halfwidth on the *cached* jets (`recert_real.py`, rigorous, no recompute) — is what
recovered them. Same machinery that closed γ₁₅/₁₆/₁₇ on 07-11.

**Honest edge.** γ₁₉/γ₂₀/γ₂₁ stay anchored: at 16M the residual floor is `band(16M→80M) ≈ 3.5×10⁻¹⁰` and
their |Ξ| sits under it. They need a 32M N_live jet run (→ floor ~2×10⁻¹¹) — a ~11 h/zero recompute we've
parked, since they're anchored-grade with nothing downstream. Say the word if you want them closed and
we'll run it.

Nothing here is RH/GRH — in-range ball certification only. Grades and where this slots, let's settle
together as ever.

— Selina
