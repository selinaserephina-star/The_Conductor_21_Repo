# χ₈ genome zeros — master certified table (γ₁–γ₂₁)

**Merkabit · 2026-07-14 · Stenberg + Claude.** Single consolidated record of every χ₈ zero and its
grade. The L-function: degree-8 Artin L of PSL(2,7), conductor 21¹⁰ = 3¹⁰7¹⁰, γ = Γ_ℂ⁴, ε = +1, Trinks
field x⁷−7x+3. LMFDB `8.16679880978201.21t14.b.a` (object catalogued; **zeros not in LMFDB — we are
first**). Data: `chi8_zeros_master.csv`. Not RH/GRH.

## Grade summary

- **γ₁–γ₁₈ — ball-arithmetic CERTIFIED** (γ₁–₈ exact low zeros; γ₉–₁₈ arb interval enclosures).
- **γ₁₉–γ₂₁ — `numerical_anchored`** (PARI lfunzeros, residuals 10⁻²⁷–10⁻³¹; **not** ball-certified).

That is **18 of 21 certified**, up from 17 (γ₁₈ upgraded 2026-07-14).

## Certified brackets

| γ | bracket / value | method |
|---|---|---|
| γ₁–γ₈ | exact (0.98639 … 2.91398) | ECL low-zero |
| γ₉ | [3.126, 3.128] | s26b arb |
| γ₁₀ | [3.338, 3.342] | s26b arb |
| γ₁₁ | [3.700, 3.702] | s26b arb |
| γ₁₂ | [3.952, 3.954] | s26b arb — **first pure prediction** |
| γ₁₃ | [4.0815, 4.086] | s26b arb (fine step) |
| **γ₁₄** | **[4.366, 4.368]** | **Channel-B, 2026-07-14** — tightened ~11× from [4.357,4.379] |
| γ₁₅ | [4.548, 4.550] | Channel-B |
| γ₁₆ | [4.692, 4.696] | Channel-B |
| γ₁₇ | [4.886, 4.890] | Channel-B |
| **γ₁₈** | **[5.142, 5.190]** | **Channel-B, 2026-07-14** — anchored → certified |
| γ₁₉ | 5.4960 | anchored (PARI) |
| γ₂₀ | 5.6848 | anchored (PARI) |
| γ₂₁ | 5.9461 | anchored (PARI) |

## Methods (three certification engines)

1. **ECL exact** — γ₁–₈ low zeros (exact, 2026-06).
2. **s26b arb ball** (`Step2_chi8_main_jets/`) — modal jets, K=16, prec 256; certifies where |Ξ| clears
   the enclosure floor. Direct-certifies γ₉–₁₃ (amplitude high enough).
3. **Channel-B** — for γ₁₄–₁₈ the amplitude wall (|Ξ|≈2.5×10⁻⁹) sinks under the Rankin `dc` tail floor
   (4×10⁻⁹ at the 80M block cutoff). Fix: extend the block cutoff to 120M (dc→1.9×10⁻¹¹) and
   re-difference the cached-jet halfwidth (`recert_real.py`, rigorous). Certificate + evidence:
   `gamma14_18_channelB_certificate_2026-07-14/`.

## Why γ₁₉–γ₂₁ are not yet certified

At 16M N_live the rigorous floor after Channel-B is `band(16M→80M)+mtail ≈ 3.5×10⁻¹⁰`, which the block
extension does not reduce; |Ξ| at those heights sits below it. Certifying them needs **32M N_live**
(→ floor ~2×10⁻¹¹), a ~11 h/zero jet recompute — deferred (anchored-grade, no downstream dependency).

## Evidence map

Each row's `evidence` column points to its certificate/result. The engine (`s22_jets_engine.py`,
`s23_tails.py`, `s26b_gamma_scan.py`) and block tables live in `Step2_chi8_main_jets/`; the master
index with full provenance is `CHI8_ZEROS_INDEX_gamma1_to_21_2026-07-13.md`.

— Stenberg + Claude, 2026-07-14. Method: IB's s26b / Channel-B pipeline; runs across the partnership.
