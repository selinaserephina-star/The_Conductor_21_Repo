# Certificate: γ₂₂, γ₂₃, γ₂₄ of L(s,χ₈) — ball-certified on the critical line

**Merkabit Research · Selina Stenberg + Claude · 2026-07-18.** Extends the certified zero table of
the conductor-21¹⁰ degree-8 L-function (Trinks field x⁷−7x+3, LMFDB `8.16679880978201.21t14.b.a`)
from γ₁–γ₂₁ (package `to_Ilya_chi8_ALL21_certified_2026-07-15`, SHA-sealed) to **γ₁–γ₂₄**.
Same engine, same grading protocol. Not RH/GRH — certified-in-range statements only.

## The certified brackets

| j | bracket | status | windows | # certified sign pts |
|---|---|---|---|---|
| **22** | **[6.1060, 6.1065]** | CERTIFIED_ZERO | w2 | 201, 0 ambiguous |
| **23** | **[6.2985, 6.2995]** | CERTIFIED_ZERO | w4 **and** w5 (independent duplicate) | 200, 1 amb |
| **24** | **[6.4635, 6.4655]** | CERTIFIED_ZERO | w6 **and** w7 (independent duplicate) | 198, 3 amb |
| — | [6.13, 6.23] | **NO_ZERO** (certified empty) | w3 | 201, 0 amb |
| — | [6.61, 6.71] | **NO_ZERO** (certified empty) | w9 | 201, 0 amb |

## Method (identical lineage to the γ₁₉–γ₂₁ certification)

- **arb modal-jets** ball evaluation of Ξ: K = 16, prec 256, **N_live = 64M** coefficients,
  window tiling centers 6.02→6.66 step 0.08, rigorous half-width ±0.05 per window
  (9 windows launched 2026-07-16 21:25 UTC; w1, w8 lost to a memory incident — see Holes).
- **Channel-B block-cutoff extension to 240M**: dc(>80M) = 4.053×10⁻⁹ → dc(>240M) = 4.988×10⁻¹⁶,
  band(80→240M) = 9.584×10⁻¹⁸; regenerated 240M blocks byte-identical to the 80M table on overlap
  (`recert_240.out` [xcheck]). **Final enclosure half-width: 8.096×10⁻¹⁶** per scan point.
- A sign change certifies iff both ball enclosures exclude zero; brackets above are the certified
  sign-change intervals. Raw pre-recert results (floor 4×10⁻⁹) were ambiguous — the entire
  certification power comes from the Channel-B recert, as designed (register R-115).

## Independent cross-validation (two-engine handshake)

The rescaled-FFT engine (Booker §5 / Palojärvi–Zhao; built and validated 2026-07-17,
`completeness_engine_2026-07-17/`: L(½) to 5×10⁻¹⁴, all 21 prior certified zeros in-bracket)
computed these zeros **independently** — different method, different coefficient range (10⁸),
different arithmetic (float64 FFT vs arb balls), two kernel channels (η = 0.30 / 0.55):

| j | rescaled-FFT value | η-channel agreement | certified bracket | inside? |
|---|---|---|---|---|
| 22 | 6.106226 | 3×10⁻⁶ | [6.1060, 6.1065] | ✓ |
| 23 | 6.299144 | 1.3×10⁻⁵ | [6.2985, 6.2995] | ✓ |
| 24 | 6.464544 | 2.1×10⁻⁵ | [6.4635, 6.4655] | ✓ |

Both certified-empty windows also agree (the rescaled engine's zero list has no zero in
[6.13, 6.23] or [6.61, 6.71]; its γ₂₅ = 6.721808 lies just above w9's upper edge).

## Holes and scope (honest)

- **Uncovered strips [5.97, 6.05] and [6.53, 6.63]** (windows w1, w8 died before completion;
  intentionally dropped, `DONE_g22_25.txt`). The rescaled engine finds no zero in either strip;
  that is *numerical* grade, not ball-certified. The strips — and completeness of the whole
  range — are the subject of the Turing-method count in flight (production run, t₂ = 28,
  M = 9×10⁹), which will close them wholesale at numerical grade, with the ball-certified
  completeness upgrade on the rigor ladder.
- γ₂₅ ≈ 6.7218 and beyond: numerical grade (rescaled engine), not covered by this certificate.
- Existence + location certified; **completeness ("exactly 24 below 6.55") is NOT claimed here.**

## Evidence (`evidence/`, 17 files)

`w{2,3,4,5,6,7,9}_certification_result.json` + `..._scan.csv` (raw jet outputs),
`recert_240.out` (Channel-B recert, the certifying step), `DONE_g22_25.txt`,
`master_g22_25.log` (run provenance). Generator lineage: `gen_an_*.gp` PARI direuler recipe,
validated block-for-block against an independent Python/flint implementation (1000/1000 blocks).

## Updated standing table

`chi8_certified_zeros_MASTER_2026-07-14/chi8_zeros_master.csv` now carries rows j = 22, 23, 24.
**All 24 known zeros of L(s,χ₈) below t = 6.55 are ball-certified on the critical line.**

— Selina + Claude, 2026-07-18. Shared-credit conventions; run design Stenberg/Claude, engine
lineage as in the γ₁₉–γ₂₁ addendum, monomiality bridge (entirety) Ilya Balashov's H₂₁ certificate.
