# To Ilya — three more certified zeros: γ₂₂, γ₂₃, γ₂₄ (2026-07-18)

**Selina + Claude.** The certified line extends: **γ₁–γ₂₄ all ball-certified**, brackets

- γ₂₂ ∈ [6.1060, 6.1065]
- γ₂₃ ∈ [6.2985, 6.2995]  (certified twice, independent overlapping windows)
- γ₂₄ ∈ [6.4635, 6.4655]  (certified twice)

plus two **certified-empty** windows [6.13, 6.23] and [6.61, 6.71]. Method: the same arb
modal-jets + Channel-B engine that certified γ₁₉–γ₂₁, at 64M jets / 240M cutoff (enclosure
half-width 8.1×10⁻¹⁶). Full detail: `CERTIFICATE_gamma22_24_2026-07-18.md`; raw evidence in
`evidence/` (17 files); SHA256SUMS.txt seals the package.

Independent cross-check inside: every bracket (and both empty windows) agrees with the new
**rescaled-FFT engine** (Booker §5 — built yesterday, validated on L(½) to 5×10⁻¹⁴ and all 21
prior zeros; it reaches these heights in minutes rather than days). Two engines, no shared code
path, same answers.

Honest scope: two strips ([5.97, 6.05], [6.53, 6.63]) lost their jet windows and are zero-free
only at numerical grade; the completeness count (Turing method, production run in flight as this
is written) addresses completeness wholesale. Not RH/GRH.

— S. + C.
