default(parisizemax, 48000000000);
cyc(p) = { my(g = factormod(x^7 - 7*x + 3, p)); vecsort(vector(matsize(g)[1], i, poldegree(g[i,1]))); }
loc8(p) = if(p==3, 1-X, p==7, 1, my(d=cyc(p)); \
  if(d==[1,1,1,1,1,1,1], (1-X)^8,            d==[1,1,1,2,2], (1-X)^4*(1+X)^4, \
     d==[1,3,3],         (1-X)^2*(1+X+X^2)^3, d==[1,2,4],    (1-X)^2*(1+X)^2*(1+X^2)^2, \
     d==[7],             (1-X)^2*(1+X+X^2+X^3+X^4+X^5+X^6)));
gettime();
av = direuler(p=2, 160000000, 1/loc8(p));
print("built ", #av, "  a2..a8=", vector(7,i,av[i+1]), "  (", gettime(), " ms)");
f2 = fileopen("an_chi8_blocks_160M.csv", "w");
filewrite(f2, "block_start,block_end,sum_abs_an,max_abs_an");
forstep(b=0, 159900000, 100000, my(s=0, mx=0); for(n=b+1, b+100000, s += abs(av[n]); mx = max(mx, abs(av[n]))); filewrite(f2, Str(b+1, ",", b+100000, ",", s, ",", mx)));
fileclose(f2);
print("written an_chi8_blocks_160M.csv  (", gettime(), " ms block-sum)");
quit;
