import csv, os, sys
sys.path.insert(0,"."); os.chdir(os.path.expanduser("~"))
from flint import arb, ctx
from s22_jets_engine import K4Table
from s23_tails import load_blocks, band_bounds, rankin_dck
ctx.prec=256; k4=K4Table()
b120=load_blocks("an_chi8_blocks_120M.csv"); b80=load_blocks("an_chi8_blocks_80M.csv")
mism=sum(1 for a,c in zip(b120[:len(b80)],b80) if a!=c)
print("[xcheck] 120M vs 80M first blocks:", "IDENTICAL" if mism==0 else str(mism)+" MISMATCH")
dc80=rankin_dck(80_000_000,0,k4)[0]; dc120=rankin_dck(120_000_000,0,k4)[0]
b_80_120=band_bounds(b120,80_000_000,120_000_000,0,k4)[0]
delta=-dc80+dc120+b_80_120
print("[floor] dc80=%.3e dc120=%.3e delta=%+.3e"%(float(dc80),float(dc120),float(delta)))
def recert(label):
    rows=[]
    with open(label+"_certification_scan.csv") as fh:
        for r in csv.DictReader(fh): rows.append((float(r["t"]),arb(r["Xi_mid"]),arb(r["enclosure_halfwidth"])))
    signed=[]; amb=[]; hw=None
    for t,mid,old in rows:
        nh=old+delta; hw=float(nh); lo=mid-nh; hi=mid+nh
        s = "+" if float(lo)>0 else ("-" if float(hi)<0 else "0?")
        (amb if s=="0?" else signed).append((t,s) if s!="0?" else t)
    ch=[(signed[i][0],signed[i+1][0]) for i in range(len(signed)-1) if signed[i][1]!=signed[i+1][1]]
    st="CERTIFIED_ZERO" if len(ch)==1 else ("MULTI_ZERO" if ch else ("AMBIGUOUS" if amb else "NO_ZERO"))
    return st,ch,hw,len(signed),len(amb)
print("%15s %11s %16s %7s %5s  bracket"%("window","new_hw","status","#signed","#amb"))
for lab in ["gamma14_tight","gamma17_recert","gamma18_cert","gamma19_cert","gamma20_cert","gamma21_cert"]:
    st,ch,hw,ns,na=recert(lab)
    br=" ".join("[%.4f,%.4f]"%(a,c) for a,c in ch) or "-"
    print("%15s %11.3e %16s %7d %5d  %s"%(lab,hw,st,ns,na,br))
