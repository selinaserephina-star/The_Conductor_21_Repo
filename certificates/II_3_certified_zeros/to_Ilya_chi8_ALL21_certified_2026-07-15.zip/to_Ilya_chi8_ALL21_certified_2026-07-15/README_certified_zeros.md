# χ₈ genome zeros — master certified table (γ₁–γ₂₁)

**Merkabit · 2026-07-14 · Stenberg + Claude.** Single consolidated record of every χ₈ zero and its
grade. The L-function: degree-8 Artin L of PSL(2,7), conductor 21¹⁰ = 3¹⁰7¹⁰, γ = Γ_ℂ⁴, ε = +1, Trinks
field x⁷−7x+3. LMFDB `8.16679880978201.21t14.b.a` (object catalogued; **zeros not in LMFDB — we are
first**). Data: `chi8_zeros_master.csv`. Not RH/GRH.

## Grade summary

- **γ₁–γ₂₁ — ALL ball-arithmetic CERTIFIED** (γ₁–₈ exact low zeros; γ₉–₂₁ arb interval enclosures).

**21 of 21 certified** (complete, 2026-07-15). γ₁₉–₂₁ closed via 32M jets + Channel-B at 160M block
cutoff (`gamma19_21_32M_addendum/`); γ₁₃/γ₁₄ tightened and γ₁₈ certified on 2026-07-14. No anchored-only
zeros remain in the certified window t ≤ 5.95.

## Certified brackets

| γ | bracket / value | method |
|---|---|---|
| γ₁–γ₈ | exact (0.98639 … 2.91398) | ECL low-zero |
| γ₉ | [3.126, 3.128] | s26b arb |
| γ₁₀ | [3.338, 3.342] | s26b arb |
| γ₁₁ | [3.700, 3.702] | s26b arb |
| γ₁₂ | [3.952, 3.954] | s26b arb — **first pure prediction** |
| **γ₁₃** | **[4.0835, 4.0840]** | **Channel-B, 2026-07-14** — tightened ~9× from [4.081,4.087] |
| **γ₁₄** | **[4.366, 4.368]** | **Channel-B, 2026-07-14** — tightened ~11× from [4.357,4.379] |
| γ₁₅ | [4.548, 4.550] | Channel-B |
| γ₁₆ | [4.692, 4.696] | Channel-B |
| γ₁₇ | [4.886, 4.890] | Channel-B |
| **γ₁₈** | **[5.142, 5.190]** | **Channel-B, 2026-07-14** — anchored → certified |
| **γ₁₉** | **[5.4955, 5.4965]** | **Channel-B 32M/160M, 2026-07-15** — anchored → certified |
| **γ₂₀** | **[5.6825, 5.6870]** | **Channel-B 32M/160M, 2026-07-15** — anchored → certified |
| **γ₂₁** | **[5.9310, 5.9690]** | **Channel-B 32M/160M, 2026-07-15** — anchored → certified |

## Methods (three certification engines)

1. **ECL exact** — γ₁–₈ low zeros (exact, 2026-06).
2. **s26b arb ball** (`Step2_chi8_main_jets/`) — modal jets, K=16, prec 256; certifies where |Ξ| clears
   the enclosure floor. Direct-certifies γ₉–₁₃ (amplitude high enough).
3. **Channel-B** — for γ₁₄–₁₈ the amplitude wall (|Ξ|≈2.5×10⁻⁹) sinks under the Rankin `dc` tail floor
   (4×10⁻⁹ at the 80M block cutoff). Fix: extend the block cutoff to 120M (dc→1.9×10⁻¹¹) and
   re-difference the cached-jet halfwidth (`recert_real.py`, rigorous). Certificate + evidence:
   `gamma14_18_channelB_certificate_2026-07-14/`.

## How γ₁₉–γ₂₁ were closed (2026-07-15)

At 16M the Channel-B floor is `band(16M→80M) ≈ 3.5×10⁻¹⁰` (block extension can't touch it), which |Ξ| at
these heights sits below. Fix — two levers, both cheap once the jets exist:
1. **32M N_live jets** (~13 h/zero overnight): kills `band(16M→80M)` → floor becomes `dc(>120M)`-limited
   at ~2×10⁻¹¹. This certified γ₁₉ (peak |Ξ|=6.6×10⁻¹¹) but not γ₂₀ (1.3×10⁻¹¹) or γ₂₁ (1.75×10⁻¹²).
2. **Extend the block cutoff 120M→160M** (~3-min `direuler`, recert on the *same* 32M jets): drops
   `dc(>160M)=3.0×10⁻¹³` → floor **7.4×10⁻¹³**, clearing all three (γ₂₁ margin ~2.4×).

So γ₁₉–₂₁ are certified on 32M jets at the 160M block cutoff — no further jet recompute.

## Evidence map

Each row's `evidence` column points to its certificate/result. The engine (`s22_jets_engine.py`,
`s23_tails.py`, `s26b_gamma_scan.py`) and block tables live in `Step2_chi8_main_jets/`; the master
index with full provenance is `CHI8_ZEROS_INDEX_gamma1_to_21_2026-07-13.md`.

— Stenberg + Claude, 2026-07-14. Method: IB's s26b / Channel-B pipeline; runs across the partnership.
