# χ₈ zero certificate — γ₁₄ (tightened), γ₁₇ (revalidated), γ₁₈ (anchored→certified)

**Merkabit · 2026-07-14 · Stenberg + Claude.** Ball-arithmetic (arb, prec 256) certification of three
χ₈ zeros via the **Channel-B** block-cutoff method applied to fresh s26b modal jets. Grades: **CERTIFIED**
= rigorous arb enclosure. Not RH/GRH.

---

## Certified results

| zero | certified bracket | width | prior state | change |
|---|---|---|---|---|
| **γ₁₄** | **[4.3660, 4.3680]** | 0.002 | CERTIFIED but wide [4.357, 4.379] (0.022) | **tightened ~11×** |
| γ₁₇ | [4.8780, 4.9000] | 0.022 | CERTIFIED [4.886, 4.890] (Channel B, 07-11) | **revalidated** (contains prior) |
| **γ₁₈** | **[5.1420, 5.1900]** | 0.048 | `numerical_anchored` (PARI, not certified) | **anchored → ball-CERTIFIED** |

Each: exactly one certified sign change in its window (single simple zero), no phantom zeros elsewhere.

**Headline:** γ₁₄ was the operator's precision floor (the widest bracket feeding R-210/R-211, capping the
genome operator at ~3 sig figs). At [4.366, 4.368] it is ~4 sig figs (4.367 ± 0.001) — the cap lifts.
The operator's input γ₁₄ = 4.368 sits inside the new bracket (upper edge); optionally use the midpoint
4.367 for a marginal gain. γ₁₈ is upgraded to certified.

## Not certified (honest)

**γ₁₉, γ₂₀, γ₂₁ remain `numerical_anchored`.** At 16M N_live the rigorous floor is
`new_hw = band(16M→80M) + mtail + dc(>120M) ≈ 3.5×10⁻¹⁰`, and |Ξ| at those heights sits below it →
AMBIGUOUS (no certified sign anywhere in-window). The block-cutoff extension does **not** reduce the
`band(16M→80M)` term; only 32M N_live does (→ floor ~2×10⁻¹¹), a ~11 h/zero jet recompute, deferred
(anchored-grade, no downstream dependency).

---

## Method (rigorous chain)

1. **Modal jets** (`s26b_gamma_scan.py`, engine `s22_jets_engine.py` / `s23_tails.py`): K=16 arb modal
   jets at the window center, N_live = 16M (`an_chi8_16M.txt`), prec 256, tight window (±0.03), fine
   scan step 0.0005 (γ₁₄/γ₁₃) or 0.002. Output per scan point: `Xi_mid` and a rigorous enclosure
   halfwidth `old_hw = rad + band(16M→80M) + dc(>80M) + U₁₇r¹⁷/17! + mtail`. (Scan CSVs enclosed.)
2. **Channel-B tail sharpening** (`recert_mine.py`, after `recert_real.py`): the Rankin d₈ tail floor
   `dc(>80M) = 4.053×10⁻⁹` dominates `old_hw`. Extend the block cutoff 80M→120M and re-difference:
   ```
   new_hw = old_hw − dc(>80M) + dc(>120M) + band(80M→120M)
          = old_hw − 4.053e-9 + 1.935e-11 + 9.5e-18     (delta = −4.034×10⁻⁹)
   ```
   The subtracted `dc(>80M)` is the *same deterministic value* baked into `old_hw` (same prec, k4, block
   subset) → bit-identical cancellation, so `new_hw` is a **valid rigorous enclosure halfwidth**.
   Integrity: the regenerated 1→80M blocks are **byte-identical** to `an_chi8_blocks_80M.csv` (xcheck
   IDENTICAL). A sign certifies iff **`|Xi_mid| > new_hw`** (= 3.500×10⁻¹⁰ here).

This is the same rigorous machinery that certified γ₁₅/₁₆/₁₇ on 2026-07-11
(`Step2_chi8_main_jets/RESULTS_gamma13_17_FILLED`); it operates on the cached jets — no recompute.

## Reproduce

`python3 recert_mine.py` (needs `python-flint`, the engine `s22_jets_engine.py`/`s23_tails.py`, and
block tables `an_chi8_blocks_80M.csv` + `an_chi8_blocks_120M.csv`). Engine + 80M blocks live in
`Step2_chi8_main_jets/`; the 120M table regenerates in ~2 min via `gen_an_120M.gp` (a `direuler` pass,
byte-identical to the 80M table on 1→80M). `dc(>M) = rankin_dck(M,0,K4Table())[0]`.

Engine SHA-256 (frozen, repo @ 49884c1):
```
s22_jets_engine.py  9381cb5fd48bc419c4dfc46ea5aa9ec4a698e732a146838796da4a4e17bb57f6
s23_tails.py        9f54e55a0e530e70d5cda612b6ed4408a6beab259442745e3c1518845ebfdbe6
s26b_gamma_scan.py  02d436c7ad89fb98446910f2f24d41c6066e41d5cbab13c8db8a31a0d7ac25f0
```

## Enclosed
- `recert_mine.py`, `recert_mine.out` — the Channel-B recert + its verdict.
- `gamma14_tight`/`gamma17_recert`/`gamma18_cert`_certification_scan.csv — the certified jets (Xi_mid +
  old_hw per point).
- `gamma19_cert`/`gamma20_cert`/`gamma21_cert`_certification_scan.csv — the AMBIGUOUS attempts (honest
  record; certify only under 32M).
- `SHA256SUMS.txt`.

— Stenberg + Claude, 2026-07-14. Shared-registry contribution; method IB's s26b/Channel-B pipeline,
this run ours. Not RH/GRH.
