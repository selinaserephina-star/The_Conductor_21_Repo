# Addendum — γ₁₉, γ₂₀, γ₂₁ certified (2026-07-15). All 21 χ₈ zeros now ball-certified.

**Merkabit · 2026-07-15 · Stenberg + Claude.** Closes the last three anchored zeros via 32M jets +
Channel-B at a 160M block cutoff. Extends `CERTIFICATE_gamma14_17_18_2026-07-14.md`. Not RH/GRH.

## Result

| zero | certified bracket | width |
|---|---|---|
| **γ₁₉** | **[5.4955, 5.4965]** | 0.001 |
| **γ₂₀** | **[5.6825, 5.6870]** | 0.0045 |
| **γ₂₁** | **[5.9310, 5.9690]** | 0.038 |

Each: single certified sign change, rigorous arb enclosure. **γ₁–γ₂₁ are now ball-certified, complete.**

## Method (why 16M failed, 32M+160M succeeds)

The amplitude decays with height: peak |Ξ| = 6.6×10⁻¹¹ (γ₁₉), 1.3×10⁻¹¹ (γ₂₀), **1.75×10⁻¹²** (γ₂₁).
Certification needs the rigorous floor below the peak. Two levers:

1. **32M N_live jets** (overnight, ~13 h; `s26b_fine.py`, K=16, prec 256, an_chi8_32M.txt). Kills the
   `band(16M→80M)` term → old_hw ≈ 4.054×10⁻⁹, dominated by `dc(>80M)`. Raw verdict: AMBIGUOUS (floor
   still dc-limited) — expected.
2. **Channel-B at 160M cutoff.** Regenerate the block table to 160M (`gen_an_160M.gp`, ~3-min `direuler`;
   `a2..a8=[1,1,1,1,1,0,1]`, 1→80M byte-identical to the 80M table). Re-difference on the *same* jets:
   `new_hw = old_hw − dc(>80M) + dc(>160M) + band(80M→160M)`, `dc(>160M)=3.04×10⁻¹³` →
   **new_hw = 7.43×10⁻¹³**. Certifies all three (γ₂₁ margin ~2.4×). `recert_160.py` / `recert_160.out`.

At 120M cutoff (floor 1.98×10⁻¹¹) only γ₁₉ cleared; the 120M→160M extension (dc 1.9×10⁻¹¹ → 3.0×10⁻¹³)
is what closed γ₂₀/γ₂₁ — a ~3-min block regen on jets already computed, no recompute.

## Enclosed
`gamma19_c32`/`gamma20_c32`/`gamma21_c32`_certification_scan.csv (32M jets), `recert_160.py` + `.out`
(the 160M recert), `recert_g19_21.py` (the 120M recert), `gen_an_160M.gp` + `an_chi8_blocks_160M.csv`
(block table), `DONE_g19_21_32M.txt` (overnight auto-run marker).

— Stenberg + Claude, 2026-07-15. Method: IB's s26b / Channel-B pipeline. Not RH/GRH.
