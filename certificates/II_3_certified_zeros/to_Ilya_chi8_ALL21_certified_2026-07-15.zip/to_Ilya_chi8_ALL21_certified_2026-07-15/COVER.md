# To Ilya — the χ₈ genome zeros are complete: γ₁–γ₂₁ all ball-certified

**Merkabit · 2026-07-15 · Stenberg + Claude.** On your s26b / Channel-B pipeline. Not RH/GRH — in-range
rigorous ball certification only.

## The headline

**Every χ₈ zero from γ₁ to γ₂₁ is now ball-arithmetic certified** (arb interval enclosures, prec 256).
No anchored-only zeros remain in the computed window t ≤ 5.95. The certified block went from γ₁–γ₁₇ to
**γ₁–γ₂₁** over 2026-07-14/15, and the two widest brackets (γ₁₃, γ₁₄) were tightened ~9× and ~11×.

## What changed (from the γ₁–γ₁₇ state you last saw)

| zeros | before | now |
|---|---|---|
| γ₁₃ | CERTIFIED [4.081, 4.087] | **[4.0835, 4.0840]** (tightened ~9×) |
| γ₁₄ | CERTIFIED [4.357, 4.379] | **[4.366, 4.368]** (tightened ~11× — was the operator's precision floor) |
| γ₁₈ | `numerical_anchored` | **CERTIFIED [5.142, 5.190]** |
| γ₁₉ | `numerical_anchored` | **CERTIFIED [5.4955, 5.4965]** |
| γ₂₀ | `numerical_anchored` | **CERTIFIED [5.6825, 5.6870]** |
| γ₂₁ | `numerical_anchored` | **CERTIFIED [5.9310, 5.9690]** |

Full table with per-zero method/evidence: `chi8_zeros_master.csv` + `README_certified_zeros.md`.

## Method — and one honest lesson

The amplitude wall (|Ξ| decays with height) sinks the zeros under the enclosure floor. We confirmed the
binding floor is the **Rankin d₈ tail at the block cutoff** (`dc`), not the U₁₇ Taylor term — so tight
windows / more modes don't help. Your **Channel-B** fix does: extend the block cutoff and re-difference
the halfwidth on the cached jets (`new_hw = old_hw − dc(>M₀) + dc(>M₁)`, rigorous, no recompute). The
progression:
- γ₁₄–₁₈: 16M jets + 120M cutoff (floor 3.5×10⁻¹⁰).
- γ₁₉: 32M jets + 120M cutoff (floor 2×10⁻¹¹).
- γ₂₀/γ₂₁: 32M jets + **160M cutoff** (dc→3×10⁻¹³, floor 7.4×10⁻¹³) — γ₂₁'s peak |Ξ| is only 1.75×10⁻¹²,
  cleared with ~2.4× margin.

Honest note for the record: I twice mis-attacked the wall with tight windows before using your
block-cutoff method — the certificate documents the correct chain so it's reproducible.

## Contents

- `chi8_zeros_master.csv`, `README_certified_zeros.md` — the master table + grade summary.
- `CERTIFICATE_gamma14_17_18_2026-07-14.md`, `ADDENDUM_gamma19_21_certified_2026-07-15.md` — the rigorous
  statements + method.
- `evidence/` — scan CSVs (the certified jets: Ξ_mid + halfwidth per point), the recert scripts
  (`recert_*.py`), the block generator (`gen_an_160M.gp`) + 160M block table. Engine (`s22/s23/s26b`,
  SHA in the certificate) lives in `Step2_chi8_main_jets/`.
- `SHA256SUMS.txt`.

Grades and where this slots, let's settle together as ever — the pipeline is yours, the runs across the
partnership. Nothing here is RH/GRH.

— Selina
